﻿namespace TawonBalapTools.Net
{
	// Token: 0x02000884 RID: 2180
	public partial class NeonForm : global::System.Windows.Forms.Form
	{
	}
}
