﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace TawonBalapTools.Net
{
	// Token: 0x02000883 RID: 2179
	public class RoundedPanel : Panel
	{
		// Token: 0x1700017E RID: 382
		// (get) Token: 0x060018C8 RID: 6344 RVA: 0x0000F195 File Offset: 0x0000F195
		// (set) Token: 0x060018C9 RID: 6345 RVA: 0x0000F19D File Offset: 0x0000F19D
		public int CornerRadius { get; set; } = 12;

		// Token: 0x1700017F RID: 383
		// (get) Token: 0x060018CA RID: 6346 RVA: 0x0000F1A6 File Offset: 0x0000F1A6
		// (set) Token: 0x060018CB RID: 6347 RVA: 0x0000F1AE File Offset: 0x0000F1AE
		public Color BorderColor { get; set; } = Color.FromArgb(40, 44, 52);

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x060018CC RID: 6348 RVA: 0x0000F1B7 File Offset: 0x0000F1B7
		// (set) Token: 0x060018CD RID: 6349 RVA: 0x0000F1BF File Offset: 0x0000F1BF
		public int BorderThickness { get; set; } = 1;

		// Token: 0x060018CE RID: 6350 RVA: 0x000C3D64 File Offset: 0x000C3D64
		public RoundedPanel()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.BackColor = Color.FromArgb(24, 26, 32);
		}

		// Token: 0x060018CF RID: 6351 RVA: 0x000C3DB4 File Offset: 0x000C3DB4
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			using (GraphicsPath path = RoundedButton.GetPath(new Rectangle(0, 0, base.Width, base.Height), this.CornerRadius))
			{
				base.Region = new Region(path);
			}
		}

		// Token: 0x060018D0 RID: 6352 RVA: 0x000C3E10 File Offset: 0x000C3E10
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			using (GraphicsPath path = RoundedButton.GetPath(checked(new Rectangle(0, 0, base.Width - 1, base.Height - 1)), this.CornerRadius))
			{
				using (SolidBrush solidBrush = new SolidBrush(this.BackColor))
				{
					graphics.FillPath(solidBrush, path);
				}
				if (this.BorderThickness > 0)
				{
					using (Pen pen = new Pen(this.BorderColor, (float)this.BorderThickness))
					{
						graphics.DrawPath(pen, path);
					}
				}
			}
			base.OnPaint(e);
		}
	}
}
