﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TawonBalapTools.Net
{
	// Token: 0x02000886 RID: 2182
	public partial class FormHXD : NeonForm
	{
		// Token: 0x060018E6 RID: 6374 RVA: 0x000C435C File Offset: 0x000C435C
		public FormHXD()
		{
			this.bytesPerRow = 16;
			this.lastSearchIndex = -1;
			this.undoStack = new Stack<byte[]>();
			this.redoStack = new Stack<byte[]>();
			this.darkBack = Color.FromArgb(18, 18, 22);
			this.darkPanel = Color.FromArgb(24, 26, 32);
			this.darkPanel2 = Color.FromArgb(26, 28, 34);
			this.darkGrid = Color.FromArgb(24, 26, 32);
			this.darkHeader = Color.FromArgb(30, 34, 42);
			this.selectedColor = Color.FromArgb(0, 120, 200);
			this.neonBlue = Color.FromArgb(0, 180, 160);
			this.InitializeComponent();
			this.BuildLogic();
		}

		// Token: 0x060018E8 RID: 6376 RVA: 0x000C5558 File Offset: 0x000C5558
		private void BuildLogic()
		{
			base.FormClosing += this.FormMain_FormClosing;
			base.KeyDown += this.FormMain_KeyDown;
			this.btnOpen.Click += delegate(object s, EventArgs e)
			{
				this.OpenFile();
			};
			this.btnSave.Click += delegate(object s, EventArgs e)
			{
				this.SaveFile();
			};
			this.btnSaveAs.Click += delegate(object s, EventArgs e)
			{
				this.SaveFileAs();
			};
			this.btnUndo.Click += delegate(object s, EventArgs e)
			{
				this.Undo();
			};
			this.btnRedo.Click += delegate(object s, EventArgs e)
			{
				this.Redo();
			};
			this.btnCopy.Click += delegate(object s, EventArgs e)
			{
				this.CopyHex();
			};
			this.btnPaste.Click += delegate(object s, EventArgs e)
			{
				this.PasteHex();
			};
			this.btnSelectAll.Click += delegate(object s, EventArgs e)
			{
				this.SelectAllHex();
			};
			this.btnCompare.Click += delegate(object s, EventArgs e)
			{
				this.CompareFile();
			};
			this.btnChecksum.Click += delegate(object s, EventArgs e)
			{
				this.ChecksumSearch();
			};
			this.btnClose.Click += delegate(object s, EventArgs e)
			{
				base.Close();
			};
			this.cmbEndian.SelectedIndexChanged += delegate(object s, EventArgs e)
			{
				this.currentEndian = ((this.cmbEndian.SelectedIndex == 0) ? FormHXD.EndianType.LittleEndian : FormHXD.EndianType.BigEndian);
				this.UpdateEndianInfo();
			};
			this.cmbDataType.SelectedIndexChanged += delegate(object s, EventArgs e)
			{
				this.currentDataType = (FormHXD.DataType)this.cmbDataType.SelectedIndex;
				this.UpdateEndianInfo();
			};
			this.dgvHex.CellValueNeeded += this.DgvHex_CellValueNeeded;
			this.dgvHex.CellValuePushed += this.DgvHex_CellValuePushed;
			this.dgvHex.CellClick += this.DgvHex_CellClick;
			this.dgvHex.CellDoubleClick += this.DgvHex_CellDoubleClick;
			this.dgvHex.SelectionChanged += this.DgvHex_SelectionChanged;
			this.dgvHex.DataError += this.DgvHex_DataError;
			this.dgvHex.EditingControlShowing += this.DgvHex_EditingControlShowing;
			this.dgvHex.RowPrePaint += this.DgvHex_RowPrePaint;
			this.btnGoTo.Click += this.BtnGoTo_Click;
			this.btnSearch.Click += delegate(object s, EventArgs e)
			{
				this.SearchData(false);
			};
			this.btnFindNext.Click += delegate(object s, EventArgs e)
			{
				this.SearchData(true);
			};
			this.btnReplace.Click += this.BtnReplaceAll_Click;
			this.txtSearch.KeyPress += this.TxtSearch_KeyPress;
			this.nudBytesPerRow.ValueChanged += delegate(object s, EventArgs e)
			{
				if (this.loadingGrid)
				{
					return;
				}
				this.bytesPerRow = (int)this.nudBytesPerRow.Value;
				this.SetupGridColumns();
			};
			base.EnableDragOn(this.headerBar);
			base.EnableDragOn(this.menuStrip);
			this.UpdateButtons();
			this.UpdateEndianInfo();
			this.UpdateStatus("Ready", Color.Gray);
		}

		// Token: 0x060018E9 RID: 6377 RVA: 0x000C582C File Offset: 0x000C582C
		private void SetupGridColumns()
		{
			if (this.dgvHex == null)
			{
				return;
			}
			this.loadingGrid = true;
			checked
			{
				try
				{
					this.dgvHex.Columns.Clear();
					this.dgvHex.Columns.Add(new DataGridViewTextBoxColumn
					{
						HeaderText = "ADDRESS",
						Width = 72,
						ReadOnly = true,
						SortMode = DataGridViewColumnSortMode.NotSortable
					});
					for (int i = 0; i < this.bytesPerRow; i++)
					{
						this.dgvHex.Columns.Add(new DataGridViewTextBoxColumn
						{
							HeaderText = i.ToString("X2"),
							Width = 31,
							MaxInputLength = 2,
							SortMode = DataGridViewColumnSortMode.NotSortable
						});
					}
					this.dgvHex.Columns.Add(new DataGridViewTextBoxColumn
					{
						HeaderText = "ASCII",
						Width = 170,
						ReadOnly = true,
						SortMode = DataGridViewColumnSortMode.NotSortable
					});
					this.RefreshVirtualGrid();
				}
				finally
				{
					this.loadingGrid = false;
				}
			}
		}

		// Token: 0x060018EA RID: 6378 RVA: 0x000C593C File Offset: 0x000C593C
		private async void OpenFile()
		{
			if (!this.IsOperationRunning())
			{
				using (OpenFileDialog ofd = new OpenFileDialog())
				{
					ofd.Filter = "Binary & Hex files (*.bin;*.hex;*.rom;*.eep;*.dat)|*.bin;*.hex;*.rom;*.eep;*.dat|All files (*.*)|*.*";
					ofd.Title = "Open Binary or Intel HEX File";
					if (ofd.ShowDialog(this) != DialogResult.OK)
					{
						return;
					}
					string path = ofd.FileName;
					this.UpdateStatus("Loading " + Path.GetFileName(path) + "...", Color.LightGreen);
					try
					{
						Action <>9__2;
						await Task.Run(delegate()
						{
							byte[] rawData = File.ReadAllBytes(path);
							if (Path.GetExtension(path).ToLowerInvariant() == ".hex")
							{
								try
								{
									string @string = Encoding.ASCII.GetString(rawData);
									if (@string.Contains(":"))
									{
										this.fileData = this.ParseIntelHex(@string);
										Control <>4__this = this;
										Action method;
										if ((method = <>9__2) == null)
										{
											method = (<>9__2 = delegate()
											{
												this.currentFileName = path;
												this.isDataModified = false;
												this.RefreshVirtualGrid();
												this.UpdateButtons();
												this.UpdateStatus("Loaded Intel HEX successfully: " + Path.GetFileName(path), Color.LightGreen);
											});
										}
										<>4__this.Invoke(method);
										return;
									}
								}
								catch
								{
								}
							}
							this.Invoke(new Action(delegate()
							{
								this.fileData = rawData;
								this.currentFileName = path;
								this.isDataModified = false;
								this.RefreshVirtualGrid();
								this.UpdateButtons();
								this.UpdateStatus("Loaded RAW Binary: " + Path.GetFileName(path), Color.LightGreen);
							}));
						});
					}
					catch (Exception ex)
					{
						this.UpdateStatus("Open error: " + ex.Message, Color.Red);
						MessageBox.Show(this, "Failed to open file:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
				OpenFileDialog ofd = null;
			}
		}

		// Token: 0x060018EB RID: 6379 RVA: 0x000C5978 File Offset: 0x000C5978
		private async void SaveFile()
		{
			if (!this.IsOperationRunning())
			{
				if (string.IsNullOrWhiteSpace(this.currentFileName))
				{
					this.SaveFileAs();
				}
				else
				{
					await this.SaveToPathAsync(this.currentFileName);
				}
			}
		}

		// Token: 0x060018EC RID: 6380 RVA: 0x000C59B4 File Offset: 0x000C59B4
		private async void SaveFileAs()
		{
			if (!this.IsOperationRunning())
			{
				using (SaveFileDialog sfd = new SaveFileDialog())
				{
					sfd.Filter = "Binary files (*.bin)|*.bin|Intel HEX files (*.hex)|*.hex|All files (*.*)|*.*";
					sfd.Title = "Save As";
					if (sfd.ShowDialog(this) != DialogResult.OK)
					{
						return;
					}
					await this.SaveToPathAsync(sfd.FileName);
				}
				SaveFileDialog sfd = null;
			}
		}

		// Token: 0x060018ED RID: 6381 RVA: 0x000C59F0 File Offset: 0x000C59F0
		private async Task SaveToPathAsync(string path)
		{
			if (this.fileData != null && this.fileData.Length != 0)
			{
				this.UpdateStatus("Saving " + Path.GetFileName(path) + "...", Color.LightGreen);
				try
				{
					Action <>9__1;
					await Task.Run(delegate()
					{
						this.SaveDataToPath(path);
						Control <>4__this = this;
						Action method;
						if ((method = <>9__1) == null)
						{
							method = (<>9__1 = delegate()
							{
								this.currentFileName = path;
								this.isDataModified = false;
								this.UpdateButtons();
								this.UpdateStatus("Saved successfully: " + Path.GetFileName(path), Color.LightGreen);
							});
						}
						<>4__this.Invoke(method);
					});
				}
				catch (Exception ex)
				{
					this.UpdateStatus("Save error: " + ex.Message, Color.Red);
					MessageBox.Show(this, "Failed to save file:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		// Token: 0x060018EE RID: 6382 RVA: 0x0000F27D File Offset: 0x0000F27D
		private void SaveDataToPath(string path)
		{
			if (this.fileData == null)
			{
				return;
			}
			if (path.EndsWith(".hex", StringComparison.OrdinalIgnoreCase))
			{
				File.WriteAllText(path, this.ConvertToIntelHex(this.fileData));
				return;
			}
			File.WriteAllBytes(path, this.fileData);
		}

		// Token: 0x060018EF RID: 6383 RVA: 0x000C5A40 File Offset: 0x000C5A40
		private void UpdateButtons()
		{
			bool flag = this.fileData != null && this.fileData.Length != 0;
			bool flag2 = this.IsOperationRunning();
			if (this.btnSave != null)
			{
				this.btnSave.Enabled = (!flag2 && flag && this.isDataModified);
			}
			if (this.btnSaveAs != null)
			{
				this.btnSaveAs.Enabled = (!flag2 && flag);
			}
			if (this.btnCompare != null)
			{
				this.btnCompare.Enabled = (!flag2 && flag);
			}
			if (this.btnChecksum != null)
			{
				this.btnChecksum.Enabled = (!flag2 && flag);
			}
			if (this.btnUndo != null)
			{
				this.btnUndo.Enabled = (!flag2 && this.undoStack.Count > 0);
			}
			if (this.btnRedo != null)
			{
				this.btnRedo.Enabled = (!flag2 && this.redoStack.Count > 0);
			}
			if (this.btnPaste != null)
			{
				this.btnPaste.Enabled = (!flag2 && flag);
			}
			if (this.btnReplace != null)
			{
				this.btnReplace.Enabled = (!flag2 && flag);
			}
			if (this.btnSearch != null)
			{
				this.btnSearch.Enabled = (!flag2 && flag);
			}
			if (this.btnFindNext != null)
			{
				this.btnFindNext.Enabled = (!flag2 && flag);
			}
			if (this.btnGoTo != null)
			{
				this.btnGoTo.Enabled = (!flag2 && flag);
			}
		}

		// Token: 0x060018F0 RID: 6384 RVA: 0x000C5BA4 File Offset: 0x000C5BA4
		private void UpdateStatus(string message, Color color)
		{
			if (base.IsDisposed)
			{
				return;
			}
			if (base.InvokeRequired)
			{
				try
				{
					base.BeginInvoke(new Action(delegate()
					{
						this.UpdateStatus(message, color);
					}));
				}
				catch
				{
				}
				return;
			}
			if (this.lblStatus == null)
			{
				return;
			}
			this.lblStatus.Text = (message ?? "");
			this.lblStatus.ForeColor = color;
			if (this.lblStatusColor != null)
			{
				this.lblStatusColor.BackColor = color;
			}
		}

		// Token: 0x060018F1 RID: 6385 RVA: 0x000C5C54 File Offset: 0x000C5C54
		private void DgvHex_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (this.fileData == null || e.RowIndex < 0 || e.ColumnIndex < 1 || e.ColumnIndex > this.bytesPerRow)
			{
				return;
			}
			int num = checked(e.RowIndex * this.bytesPerRow + e.ColumnIndex - 1);
			if (num < 0 || num >= this.fileData.Length)
			{
				return;
			}
			this.currentAddress = num;
			this.txtAddress.Text = num.ToString("X8");
			this.UpdateAsciiPreview(num);
			this.UpdateEndianInfo();
		}

		// Token: 0x060018F2 RID: 6386 RVA: 0x0000F2B5 File Offset: 0x0000F2B5
		private void DgvHex_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
		{
			if (this.fileData == null || e.RowIndex < 0 || e.ColumnIndex < 1 || e.ColumnIndex > this.bytesPerRow)
			{
				return;
			}
			this.dgvHex.BeginEdit(true);
		}

		// Token: 0x060018F3 RID: 6387 RVA: 0x0000F2ED File Offset: 0x0000F2ED
		private void DgvHex_SelectionChanged(object sender, EventArgs e)
		{
			this.UpdateEndianInfo();
		}

		// Token: 0x060018F4 RID: 6388 RVA: 0x0000F2F5 File Offset: 0x0000F2F5
		private void DgvHex_DataError(object sender, DataGridViewDataErrorEventArgs e)
		{
			e.ThrowException = false;
		}

		// Token: 0x060018F5 RID: 6389 RVA: 0x000C5CDC File Offset: 0x000C5CDC
		private void DgvHex_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
		{
			if (this.fileData == null || checked(e.RowIndex * this.bytesPerRow) >= this.fileData.Length)
			{
				return;
			}
			e.InheritedRowStyle.BackColor = ((e.RowIndex % 2 == 0) ? Color.FromArgb(24, 26, 32) : Color.FromArgb(21, 23, 28));
		}

		// Token: 0x060018F6 RID: 6390 RVA: 0x000C5D38 File Offset: 0x000C5D38
		private void DgvHex_CellValueNeeded(object sender, DataGridViewCellValueEventArgs e)
		{
			if (this.fileData == null || e.RowIndex < 0)
			{
				return;
			}
			checked
			{
				int num = e.RowIndex * this.bytesPerRow;
				if (e.ColumnIndex == 0)
				{
					e.Value = num.ToString("X8");
					return;
				}
				if (e.ColumnIndex >= 1 && e.ColumnIndex <= this.bytesPerRow)
				{
					int num2 = num + e.ColumnIndex - 1;
					e.Value = ((num2 < this.fileData.Length) ? this.fileData[num2].ToString("X2") : "");
					return;
				}
				if (e.ColumnIndex == this.bytesPerRow + 1)
				{
					int num3 = Math.Min(this.bytesPerRow, this.fileData.Length - num);
					if (num3 <= 0)
					{
						e.Value = "";
						return;
					}
					char[] array = new char[num3];
					for (int i = 0; i < num3; i++)
					{
						byte b = this.fileData[num + i];
						array[i] = (char)((b >= 32 && b <= 126) ? b : 46);
					}
					e.Value = new string(array);
				}
			}
		}

		// Token: 0x060018F7 RID: 6391 RVA: 0x000C5E50 File Offset: 0x000C5E50
		private void DgvHex_CellValuePushed(object sender, DataGridViewCellValueEventArgs e)
		{
			if (this.fileData == null || e.RowIndex < 0 || e.ColumnIndex < 1 || e.ColumnIndex > this.bytesPerRow)
			{
				return;
			}
			checked
			{
				int num = e.RowIndex * this.bytesPerRow + e.ColumnIndex - 1;
				if (num < 0 || num >= this.fileData.Length)
				{
					return;
				}
				string text = Convert.ToString(e.Value ?? "").Trim().ToUpperInvariant();
				if (text.Length == 1)
				{
					text = "0" + text;
				}
				byte b;
				if (text.Length != 2 || !byte.TryParse(text, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out b))
				{
					this.UpdateStatus("Invalid HEX byte: " + text, Color.Orange);
					return;
				}
				if (this.fileData[num] == b)
				{
					return;
				}
				this.PushUndo();
				this.fileData[num] = b;
				this.isDataModified = true;
				this.lastSearchIndex = -1;
				this.currentAddress = num;
				this.UpdateButtons();
				this.UpdateAsciiPreview(num);
				this.UpdateEndianInfo();
				this.dgvHex.InvalidateCell(e.RowIndex, e.ColumnIndex);
				this.dgvHex.InvalidateCell(e.RowIndex, this.bytesPerRow + 1);
				this.UpdateStatus(string.Format("Changed 0x{0:X8} -> {1:X2}", num, b), Color.LightGreen);
			}
		}

		// Token: 0x060018F8 RID: 6392 RVA: 0x000C5FAC File Offset: 0x000C5FAC
		private void DgvHex_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
		{
			TextBox textBox;
			if ((textBox = (e.Control as TextBox)) != null)
			{
				textBox.CharacterCasing = CharacterCasing.Upper;
				textBox.MaxLength = 2;
			}
		}

		// Token: 0x060018F9 RID: 6393 RVA: 0x000C5FD8 File Offset: 0x000C5FD8
		private void UpdateAsciiPreview(int address)
		{
			if (this.txtAscii == null)
			{
				return;
			}
			if (this.fileData == null || this.fileData.Length == 0)
			{
				this.txtAscii.Clear();
				return;
			}
			checked
			{
				address = Math.Max(0, Math.Min(address, this.fileData.Length - 1));
				int num = Math.Max(0, address - 32);
				int num2 = Math.Min(this.fileData.Length, address + 64);
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.AppendLine(string.Format("=== ASCII 0x{0:X8} ===\n", address));
				for (int i = num; i < num2; i += 16)
				{
					stringBuilder.Append(i.ToString("X8") + ": ");
					int num3 = Math.Min(16, num2 - i);
					for (int j = 0; j < num3; j++)
					{
						byte b = this.fileData[i + j];
						stringBuilder.Append((char)((b >= 32 && b <= 126) ? b : 46));
					}
					stringBuilder.AppendLine();
				}
				this.txtAscii.Text = stringBuilder.ToString();
				this.txtAscii.SelectionStart = 0;
				this.txtAscii.SelectionLength = 0;
			}
		}

		// Token: 0x060018FA RID: 6394 RVA: 0x000C60F8 File Offset: 0x000C60F8
		private void UpdateEndianInfo()
		{
			if (this.lblEndianInfo == null)
			{
				return;
			}
			if (this.fileData == null || this.fileData.Length == 0 || this.dgvHex.CurrentCell == null)
			{
				this.lblEndianInfo.Text = "Value: -";
				return;
			}
			DataGridViewCell currentCell = this.dgvHex.CurrentCell;
			if (currentCell.ColumnIndex < 1 || currentCell.ColumnIndex > this.bytesPerRow)
			{
				this.lblEndianInfo.Text = "Value: -";
				return;
			}
			checked
			{
				int num = currentCell.RowIndex * this.bytesPerRow + currentCell.ColumnIndex - 1;
				int dataTypeSize = FormHXD.GetDataTypeSize(this.currentDataType);
				if (num < 0 || num + dataTypeSize > this.fileData.Length)
				{
					this.lblEndianInfo.Text = "Value: insufficient bytes";
					return;
				}
				try
				{
					byte[] array = new byte[dataTypeSize];
					Buffer.BlockCopy(this.fileData, num, array, 0, dataTypeSize);
					if (this.currentEndian == FormHXD.EndianType.BigEndian)
					{
						Array.Reverse(array);
					}
					string text;
					switch (this.currentDataType)
					{
					case FormHXD.DataType.Byte:
						text = string.Format("0x{0:X2} ({0})", array[0]);
						break;
					case FormHXD.DataType.Int16:
					{
						short num2 = BitConverter.ToInt16(array, 0);
						text = string.Format("0x{0:X4} ({1})", (ushort)num2, num2);
						break;
					}
					case FormHXD.DataType.Int32:
					{
						int num3 = BitConverter.ToInt32(array, 0);
						text = string.Format("0x{0:X8} ({1})", num3, num3);
						break;
					}
					case FormHXD.DataType.Int64:
					{
						long num4 = BitConverter.ToInt64(array, 0);
						text = string.Format("0x{0:X16} ({1})", num4, num4);
						break;
					}
					case FormHXD.DataType.Single:
						text = BitConverter.ToSingle(array, 0).ToString("F6", CultureInfo.InvariantCulture);
						break;
					case FormHXD.DataType.Double:
						text = BitConverter.ToDouble(array, 0).ToString("F10", CultureInfo.InvariantCulture);
						break;
					default:
						text = "-";
						break;
					}
					this.lblEndianInfo.Text = string.Concat(new object[]
					{
						this.currentDataType,
						" (",
						this.currentEndian,
						")\r\nAddress: 0x",
						num.ToString("X8"),
						"\r\nValue: ",
						text
					});
				}
				catch
				{
					this.lblEndianInfo.Text = "Value: -";
				}
			}
		}

		// Token: 0x060018FB RID: 6395 RVA: 0x000C6368 File Offset: 0x000C6368
		private void PushUndo()
		{
			if (this.fileData == null)
			{
				return;
			}
			this.undoStack.Push((byte[])this.fileData.Clone());
			checked
			{
				while (this.undoStack.Count > 20)
				{
					byte[][] array = this.undoStack.ToArray();
					this.undoStack.Clear();
					for (int i = Math.Min(20, array.Length) - 1; i >= 0; i--)
					{
						this.undoStack.Push(array[i]);
					}
				}
				this.redoStack.Clear();
				this.UpdateButtons();
			}
		}

		// Token: 0x060018FC RID: 6396 RVA: 0x000C63F8 File Offset: 0x000C63F8
		private void Undo()
		{
			if (this.IsOperationRunning() || this.undoStack.Count == 0 || this.fileData == null)
			{
				return;
			}
			this.redoStack.Push((byte[])this.fileData.Clone());
			this.fileData = this.undoStack.Pop();
			this.isDataModified = true;
			this.lastSearchIndex = -1;
			this.RefreshVirtualGrid();
			this.UpdateButtons();
			if (this.fileData.Length != 0)
			{
				this.currentAddress = Math.Max(0, Math.Min(this.currentAddress, checked(this.fileData.Length - 1)));
				this.SelectAddress(this.currentAddress);
			}
			else
			{
				this.txtAscii.Clear();
			}
			this.UpdateEndianInfo();
			this.UpdateStatus("Undo", Color.LightGray);
		}

		// Token: 0x060018FD RID: 6397 RVA: 0x000C64C4 File Offset: 0x000C64C4
		private void Redo()
		{
			if (this.IsOperationRunning() || this.redoStack.Count == 0 || this.fileData == null)
			{
				return;
			}
			this.undoStack.Push((byte[])this.fileData.Clone());
			this.fileData = this.redoStack.Pop();
			this.isDataModified = true;
			this.lastSearchIndex = -1;
			this.RefreshVirtualGrid();
			this.UpdateButtons();
			if (this.fileData.Length != 0)
			{
				this.currentAddress = Math.Max(0, Math.Min(this.currentAddress, checked(this.fileData.Length - 1)));
				this.SelectAddress(this.currentAddress);
			}
			else
			{
				this.txtAscii.Clear();
			}
			this.UpdateEndianInfo();
			this.UpdateStatus("Redo", Color.LightGray);
		}

		// Token: 0x060018FE RID: 6398 RVA: 0x000C6590 File Offset: 0x000C6590
		private void RefreshVirtualGrid()
		{
			if (this.dgvHex == null)
			{
				return;
			}
			this.loadingGrid = true;
			try
			{
				int rowCount = (this.fileData != null && this.fileData.Length != 0) ? (checked(this.fileData.Length + this.bytesPerRow - 1) / this.bytesPerRow) : 0;
				this.dgvHex.RowCount = rowCount;
				this.dgvHex.Invalidate();
			}
			finally
			{
				this.loadingGrid = false;
			}
			if (this.lblFileInfo != null)
			{
				this.lblFileInfo.Text = ((this.fileData == null) ? "No data loaded" : string.Format("File: {0} | Size: {1:N0} bytes | Rows: {2:N0}", string.IsNullOrEmpty(this.currentFileName) ? "Untitled" : Path.GetFileName(this.currentFileName), this.fileData.Length, this.dgvHex.RowCount));
			}
		}

		// Token: 0x060018FF RID: 6399 RVA: 0x0000F2FE File Offset: 0x0000F2FE
		private void TxtSearch_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == '\r')
			{
				this.SearchData(false);
				e.Handled = true;
			}
		}

		// Token: 0x06001900 RID: 6400 RVA: 0x000C6674 File Offset: 0x000C6674
		private void SearchData(bool findNext)
		{
			if (this.fileData == null || this.fileData.Length == 0)
			{
				return;
			}
			string text = this.txtSearch.Text.Trim();
			if (string.IsNullOrEmpty(text))
			{
				return;
			}
			try
			{
				byte[] array = this.ParseSearchBytes(text);
				if (array.Length != 0)
				{
					int startIndex = findNext ? checked(this.lastSearchIndex + 1) : 0;
					int num = FormHXD.FindBytesFast(this.fileData, array, startIndex, CancellationToken.None);
					if (num < 0)
					{
						this.UpdateStatus("Pattern not found.", Color.Orange);
						this.lastSearchIndex = -1;
					}
					else
					{
						this.lastSearchIndex = num;
						this.SelectAddress(num);
						this.UpdateStatus(string.Format("Found at 0x{0:X8}", num), Color.LightGreen);
					}
				}
			}
			catch (Exception ex)
			{
				this.UpdateStatus("Search error: " + ex.Message, Color.Red);
			}
		}

		// Token: 0x06001901 RID: 6401 RVA: 0x000C6754 File Offset: 0x000C6754
		private async void BtnReplaceAll_Click(object sender, EventArgs e)
		{
			if (!this.IsOperationRunning() && this.fileData != null && this.fileData.Length != 0)
			{
				string text = this.txtSearch.Text.Trim();
				string text2 = this.txtReplace.Text.Trim();
				if (!string.IsNullOrEmpty(text) && !string.IsNullOrEmpty(text2))
				{
					try
					{
						byte[] pattern = this.ParseSearchBytes(text);
						byte[] replacement = this.ParseSearchBytes(text2);
						if (pattern.Length != 0 && replacement.Length != 0)
						{
							if (pattern.Length != replacement.Length)
							{
								MessageBox.Show(this, "Search and Replace must have the same byte length.", "Replace All", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
							}
							else
							{
								this.PushUndo();
								try
								{
									await Task.Run(checked(delegate()
									{
										int count = 0;
										int num = 0;
										while ((num = FormHXD.FindBytesFast(this.fileData, pattern, num, CancellationToken.None)) >= 0)
										{
											Buffer.BlockCopy(replacement, 0, this.fileData, num, replacement.Length);
											num += replacement.Length;
											int count2 = count;
											count = count2 + 1;
										}
										this.Invoke(new Action(delegate()
										{
											this.isDataModified = true;
											this.RefreshVirtualGrid();
											this.UpdateButtons();
											this.UpdateStatus(string.Format("Replaced {0} occurrences.", count), Color.LightGreen);
										}));
									}));
								}
								catch (Exception ex)
								{
									this.UpdateStatus("Replace error: " + ex.Message, Color.Red);
								}
							}
						}
					}
					catch (Exception ex2)
					{
						MessageBox.Show(this, ex2.Message, "Replace All", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
			}
		}

		// Token: 0x06001902 RID: 6402 RVA: 0x000C6790 File Offset: 0x000C6790
		private void CopyHex()
		{
			if (this.dgvHex.SelectedCells.Count == 0 || this.fileData == null)
			{
				return;
			}
			checked
			{
				int[] array = (from a in (from DataGridViewCell c in this.dgvHex.SelectedCells
				where c.RowIndex >= 0 && c.ColumnIndex >= 1 && c.ColumnIndex <= this.bytesPerRow
				let a = c.RowIndex * this.bytesPerRow + c.ColumnIndex - 1
				where a >= 0 && a < this.fileData.Length
				select a).Distinct<int>()
				orderby a
				select a).ToArray<int>();
				if (array.Length == 0)
				{
					return;
				}
				StringBuilder stringBuilder = new StringBuilder(array.Length * 3);
				for (int i = 0; i < array.Length; i++)
				{
					if (i > 0)
					{
						stringBuilder.Append(' ');
					}
					stringBuilder.Append(this.fileData[array[i]].ToString("X2"));
				}
				try
				{
					Clipboard.SetText(stringBuilder.ToString());
					this.UpdateStatus("HEX copied (" + array.Length + " bytes)", Color.LightGreen);
				}
				catch (Exception ex)
				{
					this.UpdateStatus("Clipboard error: " + ex.Message, Color.Red);
				}
			}
		}

		// Token: 0x06001903 RID: 6403 RVA: 0x000C68F8 File Offset: 0x000C68F8
		private void PasteHex()
		{
			if (this.fileData == null || this.fileData.Length == 0 || this.dgvHex.SelectedCells.Count == 0)
			{
				return;
			}
			string text;
			try
			{
				text = Clipboard.GetText();
			}
			catch
			{
				return;
			}
			if (string.IsNullOrWhiteSpace(text))
			{
				return;
			}
			byte[] array;
			try
			{
				array = this.ParseSearchBytes(text);
			}
			catch
			{
				MessageBox.Show(this, "Clipboard does not contain valid HEX.", "Paste", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}
			if (array.Length == 0)
			{
				return;
			}
			DataGridViewCell dataGridViewCell = (from DataGridViewCell c in this.dgvHex.SelectedCells
			where c.RowIndex >= 0 && c.ColumnIndex >= 1 && c.ColumnIndex <= this.bytesPerRow
			orderby c.RowIndex, c.ColumnIndex
			select c).FirstOrDefault<DataGridViewCell>();
			if (dataGridViewCell == null)
			{
				return;
			}
			checked
			{
				int num = dataGridViewCell.RowIndex * this.bytesPerRow + dataGridViewCell.ColumnIndex - 1;
				if (num < 0 || num >= this.fileData.Length)
				{
					return;
				}
				this.PushUndo();
				int num2 = Math.Min(array.Length, this.fileData.Length - num);
				Buffer.BlockCopy(array, 0, this.fileData, num, num2);
				this.isDataModified = true;
				this.lastSearchIndex = -1;
				this.RefreshVirtualGrid();
				this.SelectAddress(num);
				this.UpdateButtons();
				this.UpdateStatus(string.Format("Pasted {0:N0} bytes at 0x{1:X8}", num2, num), Color.LightGreen);
			}
		}

		// Token: 0x06001904 RID: 6404 RVA: 0x0000F318 File Offset: 0x0000F318
		private void SelectAllHex()
		{
			if (this.dgvHex.RowCount > 0)
			{
				this.dgvHex.SelectAll();
			}
		}

		// Token: 0x06001905 RID: 6405 RVA: 0x000C6A90 File Offset: 0x000C6A90
		private void BtnGoTo_Click(object sender, EventArgs e)
		{
			if (this.fileData == null || this.fileData.Length == 0)
			{
				return;
			}
			try
			{
				int num = this.ParseAddress(this.txtAddress.Text);
				if (num < 0 || num >= this.fileData.Length)
				{
					this.UpdateStatus("Address out of range.", Color.Orange);
				}
				else
				{
					this.SelectAddress(num);
					this.UpdateStatus(string.Format("Jumped to 0x{0:X8}", num), Color.LightGray);
				}
			}
			catch (Exception ex)
			{
				this.UpdateStatus("Invalid address: " + ex.Message, Color.Red);
			}
		}

		// Token: 0x06001906 RID: 6406 RVA: 0x000C6B38 File Offset: 0x000C6B38
		private void SelectAddress(int address)
		{
			if (this.fileData == null || address < 0 || address >= this.fileData.Length)
			{
				return;
			}
			int num = address / this.bytesPerRow;
			checked
			{
				int index = address % this.bytesPerRow + 1;
				if (num < 0 || num >= this.dgvHex.RowCount)
				{
					return;
				}
				this.currentAddress = address;
				this.txtAddress.Text = address.ToString("X8");
				try
				{
					this.dgvHex.ClearSelection();
					DataGridViewCell dataGridViewCell = this.dgvHex.Rows[num].Cells[index];
					this.dgvHex.CurrentCell = dataGridViewCell;
					dataGridViewCell.Selected = true;
					if (this.chkAutoScroll.Checked && num >= 0 && num < this.dgvHex.RowCount)
					{
						int val = Math.Max(0, num - 5);
						this.dgvHex.FirstDisplayedScrollingRowIndex = Math.Min(val, Math.Max(0, this.dgvHex.RowCount - 1));
					}
				}
				catch
				{
				}
				this.UpdateAsciiPreview(address);
				this.UpdateEndianInfo();
			}
		}

		// Token: 0x06001907 RID: 6407 RVA: 0x0000F333 File Offset: 0x0000F333
		private static int GetDataTypeSize(FormHXD.DataType type)
		{
			switch (type)
			{
			case FormHXD.DataType.Byte:
				return 1;
			case FormHXD.DataType.Int16:
				return 2;
			case FormHXD.DataType.Int32:
				return 4;
			case FormHXD.DataType.Int64:
				return 8;
			case FormHXD.DataType.Single:
				return 4;
			case FormHXD.DataType.Double:
				return 8;
			default:
				return 1;
			}
		}

		// Token: 0x06001908 RID: 6408 RVA: 0x0000F362 File Offset: 0x0000F362
		private Label DarkLabel(string text, Point location)
		{
			return new Label
			{
				Text = text,
				Location = location,
				AutoSize = true,
				ForeColor = Color.White,
				Font = new Font("Segoe UI", 8.5f)
			};
		}

		// Token: 0x06001909 RID: 6409 RVA: 0x000C6C4C File Offset: 0x000C6C4C
		private TextBox DarkTextBox(int width)
		{
			return new TextBox
			{
				Width = width,
				BackColor = Color.FromArgb(40, 44, 52),
				ForeColor = Color.White,
				BorderStyle = BorderStyle.FixedSingle,
				Font = new Font("Consolas", 9f),
				Margin = new Padding(2, 3, 8, 0)
			};
		}

		// Token: 0x0600190A RID: 6410 RVA: 0x000C6CAC File Offset: 0x000C6CAC
		private Button DarkButton(string text, int width)
		{
			return new RoundedButton
			{
				Text = text,
				Width = Math.Max(width, 60),
				Height = 28,
				CornerRadius = 10,
				NeonColor = this.neonBlue,
				HoverColor = Color.FromArgb(0, 240, 255),
				UseNeonGlow = true,
				Font = new Font("Segoe UI Semibold", 8f, FontStyle.Bold),
				Margin = new Padding(2, 3, 8, 0)
			};
		}

		// Token: 0x0600190B RID: 6411 RVA: 0x000C6D34 File Offset: 0x000C6D34
		private void AddAction(FlowLayoutPanel panel, string label, Control textBox, params Control[] buttons)
		{
			panel.Controls.Add(this.DarkLabel(label, new Point(0, 6)));
			panel.Controls.Add(textBox);
			foreach (Control value in buttons)
			{
				panel.Controls.Add(value);
			}
		}

		// Token: 0x0600190C RID: 6412 RVA: 0x000C6D88 File Offset: 0x000C6D88
		private int ParseAddress(string text)
		{
			string text2 = (text ?? "").Trim();
			if (text2.Length == 0)
			{
				throw new FormatException("Empty address.");
			}
			if (text2.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
			{
				return Convert.ToInt32(text2.Substring(2), 16);
			}
			if (text2.StartsWith("$"))
			{
				return Convert.ToInt32(text2.Substring(1), 16);
			}
			if (text2.Any((char c) => (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f')))
			{
				return Convert.ToInt32(text2, 16);
			}
			return int.Parse(text2, CultureInfo.InvariantCulture);
		}

		// Token: 0x0600190D RID: 6413 RVA: 0x000C6E2C File Offset: 0x000C6E2C
		private byte[] ParseSearchBytes(string text)
		{
			text = (text ?? "").Trim();
			if (text.Length == 0)
			{
				return new byte[0];
			}
			if (text.Contains(" ") || text.Contains(",") || text.Contains("\t") || text.Contains("\r") || text.Contains("\n"))
			{
				string[] array = text.Split(new char[]
				{
					' ',
					',',
					'\t',
					'\r',
					'\n'
				}, StringSplitOptions.RemoveEmptyEntries);
				List<byte> list = new List<byte>(array.Length);
				foreach (string text2 in array)
				{
					byte item;
					if (!byte.TryParse(text2.Trim(), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out item))
					{
						throw new FormatException("Invalid HEX byte: " + text2);
					}
					list.Add(item);
				}
				return list.ToArray();
			}
			if (text.Length == 2)
			{
				if (text.All((char c) => Uri.IsHexDigit(c)))
				{
					return new byte[]
					{
						Convert.ToByte(text, 16)
					};
				}
			}
			return Encoding.ASCII.GetBytes(text);
		}

		// Token: 0x0600190E RID: 6414 RVA: 0x0000F39E File Offset: 0x0000F39E
		private bool IsOperationRunning()
		{
			return this.runningOperation != null && !this.runningOperation.IsCompleted;
		}

		// Token: 0x0600190F RID: 6415 RVA: 0x000C6F54 File Offset: 0x000C6F54
		private void CompareFile()
		{
			if (this.fileData == null || this.fileData.Length == 0)
			{
				MessageBox.Show(this, "Open the primary BIN file first.", "Compare", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
			using (FormHXD.FormCompareDialog formCompareDialog = new FormHXD.FormCompareDialog(this.currentFileName, this.fileData))
			{
				if (formCompareDialog.ShowDialog(this) == DialogResult.OK)
				{
					try
					{
						byte[] data = File.ReadAllBytes(formCompareDialog.File2Path);
						using (FormHXD.FormCompareViewer formCompareViewer = new FormHXD.FormCompareViewer(this.fileData, data, Path.GetFileName(formCompareDialog.File1Path), Path.GetFileName(formCompareDialog.File2Path), formCompareDialog.VerticalLayout, this.bytesPerRow))
						{
							base.Hide();
							formCompareViewer.ShowDialog(this);
							base.Show();
							this.UpdateStatus("Comparing: " + Path.GetFileName(formCompareDialog.File1Path) + " vs " + Path.GetFileName(formCompareDialog.File2Path), Color.LightGreen);
						}
					}
					catch (Exception ex)
					{
						base.Show();
						MessageBox.Show(this, "Error loading file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
			}
		}

		// Token: 0x06001910 RID: 6416 RVA: 0x000C7090 File Offset: 0x000C7090
		private void ChecksumSearch()
		{
			if (this.fileData == null || this.fileData.Length == 0)
			{
				MessageBox.Show(this, "Open a binary file first.", "Checksum Search", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
			if (this.IsOperationRunning())
			{
				return;
			}
			checked
			{
				using (NeonForm neonForm = new NeonForm())
				{
					neonForm.Text = "Checksum Search";
					neonForm.Size = new Size(440, 400);
					neonForm.StartPosition = FormStartPosition.CenterParent;
					neonForm.CornerRadius = 18;
					neonForm.NeonColor = this.neonBlue;
					neonForm.BorderThickness = 6;
					neonForm.BackColor = Color.FromArgb(18, 18, 22);
					neonForm.ForeColor = Color.White;
					Panel panel = new Panel
					{
						Dock = DockStyle.Fill,
						BackColor = neonForm.BackColor,
						Padding = new Padding(12)
					};
					neonForm.Controls.Add(panel);
					Label label = new Label
					{
						Text = "Algorithm:",
						Location = new Point(6, 18),
						AutoSize = true,
						ForeColor = Color.White
					};
					ComboBox comboBox = new ComboBox
					{
						Location = new Point(126, 15),
						Width = 210,
						DropDownStyle = ComboBoxStyle.DropDownList,
						BackColor = Color.FromArgb(40, 44, 52),
						ForeColor = Color.White
					};
					comboBox.Items.AddRange(new object[]
					{
						"SUM8",
						"SUM16 LE",
						"SUM16 BE",
						"XOR8"
					});
					comboBox.SelectedIndex = 0;
					Label label2 = new Label
					{
						Text = "Block Size:",
						Location = new Point(6, 63),
						AutoSize = true,
						ForeColor = Color.White
					};
					ComboBox comboBox2 = new ComboBox
					{
						Location = new Point(126, 60),
						Width = 210,
						DropDownStyle = ComboBoxStyle.DropDownList,
						BackColor = Color.FromArgb(40, 44, 52),
						ForeColor = Color.White
					};
					comboBox2.Items.AddRange(new object[]
					{
						"16",
						"32",
						"64",
						"128",
						"256",
						"512",
						"1024"
					});
					comboBox2.SelectedIndex = 3;
					Label label3 = new Label
					{
						Text = "Start Address:",
						Location = new Point(6, 108),
						AutoSize = true,
						ForeColor = Color.White
					};
					TextBox textBox = new TextBox
					{
						Text = "0",
						Location = new Point(126, 105),
						Width = 210,
						BackColor = Color.FromArgb(40, 44, 52),
						ForeColor = Color.White
					};
					Label label4 = new Label
					{
						Text = "End Address:",
						Location = new Point(6, 153),
						AutoSize = true,
						ForeColor = Color.White
					};
					TextBox textBox2 = new TextBox
					{
						Text = Math.Max(0, this.fileData.Length - 1).ToString("X"),
						Location = new Point(126, 150),
						Width = 210,
						BackColor = Color.FromArgb(40, 44, 52),
						ForeColor = Color.White
					};
					Label label5 = new Label
					{
						Text = "Checksum is expected immediately after each data block.",
						Location = new Point(6, 195),
						Size = new Size(380, 40),
						ForeColor = Color.LightGray
					};
					RoundedButton roundedButton = new RoundedButton
					{
						Text = "SEARCH",
						Location = new Point(126, 275),
						Width = 100,
						Height = 32,
						CornerRadius = 12,
						NeonColor = Color.FromArgb(0, 220, 180),
						DialogResult = DialogResult.OK
					};
					RoundedButton roundedButton2 = new RoundedButton
					{
						Text = "CANCEL",
						Location = new Point(236, 275),
						Width = 100,
						Height = 32,
						CornerRadius = 12,
						NeonColor = Color.FromArgb(255, 80, 80),
						DialogResult = DialogResult.Cancel
					};
					panel.Controls.AddRange(new Control[]
					{
						label,
						comboBox,
						label2,
						comboBox2,
						label3,
						textBox,
						label4,
						textBox2,
						label5,
						roundedButton,
						roundedButton2
					});
					neonForm.AcceptButton = roundedButton;
					neonForm.CancelButton = roundedButton2;
					neonForm.EnableDragOn(neonForm);
					if (neonForm.ShowDialog(this) == DialogResult.OK)
					{
						try
						{
							int num = this.ParseAddress(textBox.Text);
							int num2 = this.ParseAddress(textBox2.Text);
							int blockSize = int.Parse(comboBox2.SelectedItem.ToString(), CultureInfo.InvariantCulture);
							num = Math.Max(0, num);
							num2 = Math.Min(this.fileData.Length - 1, num2);
							if (num >= num2 || num < 0)
							{
								MessageBox.Show(this, "Invalid address range.", "Checksum Search", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
							}
							else
							{
								FormHXD.ChecksumType type;
								switch (comboBox.SelectedIndex)
								{
								case 0:
									type = FormHXD.ChecksumType.SUM8;
									break;
								case 1:
									type = FormHXD.ChecksumType.SUM16LE;
									break;
								case 2:
									type = FormHXD.ChecksumType.SUM16BE;
									break;
								default:
									type = FormHXD.ChecksumType.XOR8;
									break;
								}
								this.SearchChecksumCandidatesAsync(num, num2, blockSize, type);
							}
						}
						catch (Exception ex)
						{
							MessageBox.Show(this, "Invalid parameters:\r\n" + ex.Message, "Checksum Search", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
					}
				}
			}
		}

		// Token: 0x06001911 RID: 6417 RVA: 0x000C7660 File Offset: 0x000C7660
		private async void SearchChecksumCandidatesAsync(int start, int end, int blockSize, FormHXD.ChecksumType type)
		{
			if (!this.IsOperationRunning())
			{
				try
				{
					this.UpdateStatus("Searching checksum...", Color.LightGreen);
					await Task.Run(checked(delegate()
					{
						int candidates = 0;
						StringBuilder sb = new StringBuilder();
						for (int i = start; i <= end - blockSize; i += blockSize)
						{
							ulong num = FormHXD.CalculateChecksum(this.fileData, i, blockSize, type);
							ulong num2 = FormHXD.ReadStoredChecksum(this.fileData, i + blockSize, type);
							if (num == num2)
							{
								int candidates2 = candidates;
								candidates = candidates2 + 1;
								sb.AppendLine(string.Format("Match at 0x{0:X8} (Block: 0x{1:X8}-0x{2:X8}, Checksum: 0x{3:X})", new object[]
								{
									i,
									i,
									i + blockSize - 1,
									num
								}));
							}
						}
						this.Invoke(new Action(delegate()
						{
							this.txtResults.Clear();
							this.txtResults.AppendText(string.Format("Search complete. Found {0} potential checksum matches.\n\n", candidates));
							this.txtResults.AppendText(sb.ToString());
							this.UpdateStatus("Checksum search complete.", Color.LightGreen);
						}));
					}));
				}
				catch (Exception ex)
				{
					this.UpdateStatus("Checksum error: " + ex.Message, Color.Red);
				}
			}
		}

		// Token: 0x06001912 RID: 6418 RVA: 0x000C76BC File Offset: 0x000C76BC
		private static ulong CalculateChecksum(byte[] data, int offset, int length, FormHXD.ChecksumType type)
		{
			checked
			{
				if (data == null || offset < 0 || length < 0 || offset + length > data.Length)
				{
					return 0UL;
				}
				switch (type)
				{
				case FormHXD.ChecksumType.SUM8:
				{
					int num = 0;
					for (int i = 0; i < length; i++)
					{
						num = (num + (int)data[offset + i] & 255);
					}
					return (ulong)num;
				}
				case FormHXD.ChecksumType.SUM16LE:
				case FormHXD.ChecksumType.SUM16BE:
				{
					int num2 = 0;
					for (int j = 0; j < length; j++)
					{
						num2 = (num2 + (int)data[offset + j] & 65535);
					}
					return (ulong)num2;
				}
				case FormHXD.ChecksumType.XOR8:
				{
					int num3 = 0;
					for (int k = 0; k < length; k++)
					{
						num3 ^= (int)data[offset + k];
					}
					return (ulong)(num3 & 255);
				}
				default:
					return 0UL;
				}
			}
		}

		// Token: 0x06001913 RID: 6419 RVA: 0x000C7760 File Offset: 0x000C7760
		private static ulong ReadStoredChecksum(byte[] data, int offset, FormHXD.ChecksumType type)
		{
			if (data == null || offset < 0 || offset >= data.Length)
			{
				return 0UL;
			}
			if (type == FormHXD.ChecksumType.SUM8 || type == FormHXD.ChecksumType.XOR8)
			{
				return (ulong)data[offset];
			}
			checked
			{
				if (offset + 1 >= data.Length)
				{
					return 0UL;
				}
				if (type == FormHXD.ChecksumType.SUM16LE)
				{
					return (ulong)((int)data[offset] | (int)data[offset + 1] << 8);
				}
				return (ulong)((int)data[offset] << 8 | (int)data[offset + 1]);
			}
		}

		// Token: 0x06001914 RID: 6420 RVA: 0x000C77B4 File Offset: 0x000C77B4
		private static int FindBytesFast(byte[] data, byte[] pattern, int startIndex, CancellationToken token)
		{
			if (data == null || pattern == null || pattern.Length == 0 || pattern.Length > data.Length)
			{
				return -1;
			}
			startIndex = Math.Max(0, startIndex);
			checked
			{
				if (startIndex > data.Length - pattern.Length)
				{
					return -1;
				}
				if (pattern.Length == 1)
				{
					byte b = pattern[0];
					for (int i = startIndex; i < data.Length; i++)
					{
						if ((i & 65535) == 0)
						{
							token.ThrowIfCancellationRequested();
						}
						if (data[i] == b)
						{
							return i;
						}
					}
					return -1;
				}
				int[] array = new int[256];
				for (int j = 0; j < array.Length; j++)
				{
					array[j] = pattern.Length;
				}
				for (int k = 0; k < pattern.Length - 1; k++)
				{
					array[(int)pattern[k]] = pattern.Length - 1 - k;
				}
				int l = startIndex;
				int num = pattern.Length - 1;
				while (l <= data.Length - pattern.Length)
				{
					if ((l & 65535) == 0)
					{
						token.ThrowIfCancellationRequested();
					}
					int num2 = num;
					while (num2 >= 0 && data[l + num2] == pattern[num2])
					{
						num2--;
					}
					if (num2 < 0)
					{
						return l;
					}
					l += array[(int)data[l + num]];
				}
				return -1;
			}
		}

		// Token: 0x06001915 RID: 6421 RVA: 0x000C78BC File Offset: 0x000C78BC
		private string ConvertToIntelHex(byte[] data)
		{
			if (data == null || data.Length == 0)
			{
				return ":00000001FF\r\n";
			}
			StringBuilder stringBuilder = new StringBuilder();
			int i = 0;
			int num = -1;
			checked
			{
				while (i < data.Length)
				{
					int num2 = i >> 16;
					if (num2 != num)
					{
						num = num2;
						byte[] array = new byte[]
						{
							2,
							0,
							0,
							4,
							(byte)(num2 >> 8 & 255),
							(byte)(num2 & 255)
						};
						int num3 = 0;
						for (int j = 0; j < array.Length; j++)
						{
							num3 += (int)array[j];
						}
						byte b = (byte)(0 - num3 & 255);
						stringBuilder.Append(':');
						for (int k = 0; k < array.Length; k++)
						{
							stringBuilder.Append(array[k].ToString("X2"));
						}
						stringBuilder.Append(b.ToString("X2"));
						stringBuilder.AppendLine();
					}
					int num4 = Math.Min(16, data.Length - i);
					byte b2 = (byte)num4;
					byte b3 = (byte)(i >> 8 & 255);
					byte b4 = (byte)(i & 255);
					byte b5 = 0;
					int num5 = (int)(b2 + b3 + b4 + b5);
					for (int l = 0; l < num4; l++)
					{
						num5 += (int)data[i + l];
					}
					byte b6 = (byte)(0 - num5 & 255);
					stringBuilder.Append(':');
					stringBuilder.Append(b2.ToString("X2"));
					stringBuilder.Append(b3.ToString("X2"));
					stringBuilder.Append(b4.ToString("X2"));
					stringBuilder.Append(b5.ToString("X2"));
					for (int m = 0; m < num4; m++)
					{
						stringBuilder.Append(data[i + m].ToString("X2"));
					}
					stringBuilder.Append(b6.ToString("X2"));
					stringBuilder.AppendLine();
					i += num4;
				}
				stringBuilder.AppendLine(":00000001FF");
				return stringBuilder.ToString();
			}
		}

		// Token: 0x06001916 RID: 6422 RVA: 0x000C7AB8 File Offset: 0x000C7AB8
		private byte[] ParseIntelHex(string hexContent)
		{
			if (string.IsNullOrEmpty(hexContent))
			{
				return new byte[0];
			}
			List<byte> list = new List<byte>();
			string[] array = hexContent.Split(new char[]
			{
				'\r',
				'\n'
			}, StringSplitOptions.RemoveEmptyEntries);
			uint num = 0U;
			string[] array2 = array;
			for (int i = 0; i < array2.Length; i++)
			{
				string text = array2[i].Trim();
				checked
				{
					if (text.Length != 0 && text[0] == ':')
					{
						try
						{
							string text2 = text.Substring(1);
							int num2 = Convert.ToInt32(text2.Substring(0, 2), 16);
							int num3 = Convert.ToInt32(text2.Substring(2, 4), 16);
							int num4 = Convert.ToInt32(text2.Substring(6, 2), 16);
							if (num4 == 0)
							{
								uint num5 = num + (uint)num3;
								while (unchecked((long)list.Count < (long)((ulong)(checked(num5 + (uint)num2)))))
								{
									list.Add(0);
								}
								for (int j = 0; j < num2; j++)
								{
									byte value = Convert.ToByte(text2.Substring(8 + j * 2, 2), 16);
									list[(int)(num5 + (uint)j)] = value;
								}
							}
							else
							{
								if (num4 == 1)
								{
									break;
								}
								if (num4 == 4)
								{
									num = (uint)((uint)Convert.ToInt32(text2.Substring(8, 4), 16) << 16);
								}
							}
						}
						catch
						{
						}
					}
				}
			}
			return list.ToArray();
		}

		// Token: 0x06001917 RID: 6423 RVA: 0x000C7C08 File Offset: 0x000C7C08
		private void FormMain_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Control && e.KeyCode == Keys.G)
			{
				this.txtAddress.Focus();
				this.txtAddress.SelectAll();
				e.SuppressKeyPress = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.F)
			{
				this.txtSearch.Focus();
				this.txtSearch.SelectAll();
				e.SuppressKeyPress = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.H)
			{
				this.txtReplace.Focus();
				this.txtReplace.SelectAll();
				e.SuppressKeyPress = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.O)
			{
				this.OpenFile();
				e.SuppressKeyPress = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.S)
			{
				this.SaveFile();
				e.SuppressKeyPress = true;
				return;
			}
			if (e.Control && e.Shift && e.KeyCode == Keys.S)
			{
				this.SaveFileAs();
				e.SuppressKeyPress = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.Z)
			{
				this.Undo();
				e.SuppressKeyPress = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.Y)
			{
				this.Redo();
				e.SuppressKeyPress = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.C)
			{
				this.CopyHex();
				e.SuppressKeyPress = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.V)
			{
				this.PasteHex();
				e.SuppressKeyPress = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.A)
			{
				this.SelectAllHex();
				e.SuppressKeyPress = true;
				return;
			}
		}

		// Token: 0x06001918 RID: 6424 RVA: 0x000C7DB0 File Offset: 0x000C7DB0
		private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (this.IsOperationRunning())
			{
				if (MessageBox.Show(this, "An operation is still running.\r\n\r\nCancel it and close?", "Close", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
				{
					e.Cancel = true;
					return;
				}
				try
				{
					if (this.operationCts != null)
					{
						this.operationCts.Cancel();
					}
				}
				catch
				{
				}
				e.Cancel = true;
				Task task = this.runningOperation;
				if (task != null)
				{
					task.ContinueWith(delegate(Task t)
					{
						try
						{
							if (!base.IsDisposed)
							{
								base.BeginInvoke(new Action(delegate()
								{
									if (!base.IsDisposed)
									{
										base.Close();
									}
								}));
							}
						}
						catch
						{
						}
					}, TaskScheduler.Default);
				}
				return;
			}
			else
			{
				if (!this.isDataModified || this.fileData == null || this.fileData.Length == 0)
				{
					return;
				}
				DialogResult dialogResult = MessageBox.Show(this, "Data has been modified.\r\n\r\nSave before exit?", "Exit", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
				if (dialogResult == DialogResult.Cancel)
				{
					e.Cancel = true;
					return;
				}
				if (dialogResult == DialogResult.No)
				{
					return;
				}
				try
				{
					if (string.IsNullOrWhiteSpace(this.currentFileName))
					{
						using (SaveFileDialog saveFileDialog = new SaveFileDialog())
						{
							saveFileDialog.Filter = "Binary files (*.bin)|*.bin|Intel HEX files (*.hex)|*.hex|All files (*.*)|*.*";
							if (saveFileDialog.ShowDialog(this) != DialogResult.OK)
							{
								e.Cancel = true;
								return;
							}
							this.SaveDataToPath(saveFileDialog.FileName);
							this.currentFileName = saveFileDialog.FileName;
						}
					}
					this.SaveDataToPath(this.currentFileName);
					this.isDataModified = false;
				}
				catch (Exception ex)
				{
					MessageBox.Show(this, ex.Message, "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					e.Cancel = true;
				}
				return;
			}
		}

		// Token: 0x04001EF6 RID: 7926
		private byte[] fileData;

		// Token: 0x04001EF7 RID: 7927
		private int bytesPerRow;

		// Token: 0x04001EF8 RID: 7928
		private int currentAddress;

		// Token: 0x04001EF9 RID: 7929
		private string currentFileName;

		// Token: 0x04001EFA RID: 7930
		private bool isDataModified;

		// Token: 0x04001EFB RID: 7931
		private int lastSearchIndex;

		// Token: 0x04001EFC RID: 7932
		private bool loadingGrid;

		// Token: 0x04001EFD RID: 7933
		private readonly Stack<byte[]> undoStack;

		// Token: 0x04001EFE RID: 7934
		private readonly Stack<byte[]> redoStack;

		// Token: 0x04001EFF RID: 7935
		private const int MAX_UNDO = 20;

		// Token: 0x04001F00 RID: 7936
		private FormHXD.EndianType currentEndian;

		// Token: 0x04001F01 RID: 7937
		private FormHXD.DataType currentDataType;

		// Token: 0x04001F09 RID: 7945
		private CancellationTokenSource operationCts;

		// Token: 0x04001F0A RID: 7946
		private Task runningOperation;

		// Token: 0x02000887 RID: 2183
		private enum EndianType
		{
			// Token: 0x04001F0C RID: 7948
			LittleEndian,
			// Token: 0x04001F0D RID: 7949
			BigEndian
		}

		// Token: 0x02000888 RID: 2184
		private enum DataType
		{
			// Token: 0x04001F0F RID: 7951
			Byte,
			// Token: 0x04001F10 RID: 7952
			Int16,
			// Token: 0x04001F11 RID: 7953
			Int32,
			// Token: 0x04001F12 RID: 7954
			Int64,
			// Token: 0x04001F13 RID: 7955
			Single,
			// Token: 0x04001F14 RID: 7956
			Double
		}

		// Token: 0x02000889 RID: 2185
		private enum ChecksumType
		{
			// Token: 0x04001F16 RID: 7958
			SUM8,
			// Token: 0x04001F17 RID: 7959
			SUM16LE,
			// Token: 0x04001F18 RID: 7960
			SUM16BE,
			// Token: 0x04001F19 RID: 7961
			XOR8
		}

		// Token: 0x0200088A RID: 2186
		private class FormCompareDialog : NeonForm
		{
			// Token: 0x17000186 RID: 390
			// (get) Token: 0x06001932 RID: 6450 RVA: 0x0000F4EB File Offset: 0x0000F4EB
			// (set) Token: 0x06001933 RID: 6451 RVA: 0x0000F4F3 File Offset: 0x0000F4F3
			public string File1Path { get; private set; }

			// Token: 0x17000187 RID: 391
			// (get) Token: 0x06001934 RID: 6452 RVA: 0x0000F4FC File Offset: 0x0000F4FC
			// (set) Token: 0x06001935 RID: 6453 RVA: 0x0000F504 File Offset: 0x0000F504
			public string File2Path { get; private set; }

			// Token: 0x17000188 RID: 392
			// (get) Token: 0x06001936 RID: 6454 RVA: 0x0000F50D File Offset: 0x0000F50D
			// (set) Token: 0x06001937 RID: 6455 RVA: 0x0000F515 File Offset: 0x0000F515
			public bool VerticalLayout { get; private set; }

			// Token: 0x17000189 RID: 393
			// (get) Token: 0x06001938 RID: 6456 RVA: 0x0000F51E File Offset: 0x0000F51E
			// (set) Token: 0x06001939 RID: 6457 RVA: 0x0000F526 File Offset: 0x0000F526
			public bool CompareAll { get; private set; }

			// Token: 0x0600193A RID: 6458 RVA: 0x000C8074 File Offset: 0x000C8074
			public FormCompareDialog(string currentFile, byte[] currentData)
			{
				base.CornerRadius = 18;
				base.NeonColor = Color.FromArgb(0, 200, 255);
				base.BorderThickness = 6;
				this.BackColor = Color.FromArgb(18, 18, 22);
				this.ForeColor = Color.FromArgb(240, 240, 240);
				this.Text = "RACE TECH Compare";
				base.Size = new Size(600, 400);
				base.StartPosition = FormStartPosition.CenterParent;
				base.TopMost = true;
				base.ShowInTaskbar = false;
				Panel panel = new Panel
				{
					Dock = DockStyle.Fill,
					BackColor = Color.Transparent,
					Padding = new Padding(12)
				};
				base.Controls.Add(panel);
				int num = 10;
				int num2 = 380;
				int width = 40;
				panel.Controls.Add(new Label
				{
					Text = "1. Data source:",
					Location = new Point(10, num),
					AutoSize = true,
					ForeColor = Color.White,
					Font = new Font("Segoe UI", 8.25f)
				});
				checked
				{
					num += 25;
					this.cmbFile1 = new ComboBox
					{
						Location = new Point(10, num),
						Width = num2,
						DropDownStyle = ComboBoxStyle.DropDownList,
						BackColor = Color.FromArgb(40, 44, 52),
						ForeColor = Color.White
					};
					if (!string.IsNullOrEmpty(currentFile))
					{
						this.cmbFile1.Items.Add(currentFile);
						this.cmbFile1.SelectedIndex = 0;
					}
					panel.Controls.Add(this.cmbFile1);
					this.btnBrowse1 = new RoundedButton
					{
						Text = "...",
						Location = new Point(10 + num2 + 5, num - 2),
						Width = width,
						Height = 28,
						CornerRadius = 10,
						NeonColor = Color.FromArgb(0, 200, 255)
					};
					this.btnBrowse1.Click += delegate(object s, EventArgs e)
					{
						this.BrowseFile(1);
					};
					panel.Controls.Add(this.btnBrowse1);
					num += 40;
					panel.Controls.Add(new Label
					{
						Text = "2. Data source:",
						Location = new Point(10, num),
						AutoSize = true,
						ForeColor = Color.White,
						Font = new Font("Segoe UI", 8.25f)
					});
					num += 25;
					this.cmbFile2 = new ComboBox
					{
						Location = new Point(10, num),
						Width = num2,
						DropDownStyle = ComboBoxStyle.DropDownList,
						BackColor = Color.FromArgb(40, 44, 52),
						ForeColor = Color.White
					};
					panel.Controls.Add(this.cmbFile2);
					this.btnBrowse2 = new RoundedButton
					{
						Text = "...",
						Location = new Point(10 + num2 + 5, num - 2),
						Width = width,
						Height = 28,
						CornerRadius = 10,
						NeonColor = Color.FromArgb(0, 200, 255)
					};
					this.btnBrowse2.Click += delegate(object s, EventArgs e)
					{
						this.BrowseFile(2);
					};
					panel.Controls.Add(this.btnBrowse2);
					num += 45;
					GroupBox groupBox = new GroupBox
					{
						Text = "Window arrangement",
						Location = new Point(10, num),
						Size = new Size(220, 70),
						ForeColor = Color.FromArgb(0, 220, 255),
						BackColor = Color.FromArgb(24, 26, 32)
					};
					this.radioVertical = new RadioButton
					{
						Text = "Tile vertically",
						Location = new Point(10, 20),
						AutoSize = true,
						ForeColor = Color.White
					};
					this.radioHorizontal = new RadioButton
					{
						Text = "Tile horizontally",
						Location = new Point(10, 42),
						AutoSize = true,
						Checked = true,
						ForeColor = Color.White
					};
					groupBox.Controls.AddRange(new Control[]
					{
						this.radioVertical,
						this.radioHorizontal
					});
					panel.Controls.Add(groupBox);
					GroupBox groupBox2 = new GroupBox
					{
						Text = "Scope",
						Location = new Point(245, num),
						Size = new Size(155, 70),
						ForeColor = Color.FromArgb(0, 220, 255),
						BackColor = Color.FromArgb(24, 26, 32)
					};
					this.radioAll = new RadioButton
					{
						Text = "All",
						Location = new Point(10, 20),
						AutoSize = true,
						Checked = true,
						ForeColor = Color.White
					};
					this.radioSelected = new RadioButton
					{
						Text = "Selected data",
						Location = new Point(10, 42),
						AutoSize = true,
						ForeColor = Color.White
					};
					groupBox2.Controls.AddRange(new Control[]
					{
						this.radioAll,
						this.radioSelected
					});
					panel.Controls.Add(groupBox2);
					num += 105;
					this.btnOK = new RoundedButton
					{
						Text = "OK",
						Location = new Point(345, num),
						Width = 90,
						Height = 32,
						CornerRadius = 12,
						NeonColor = Color.FromArgb(0, 220, 180),
						DialogResult = DialogResult.OK
					};
					this.btnOK.Click += this.BtnOK_Click;
					panel.Controls.Add(this.btnOK);
					this.btnCancel = new RoundedButton
					{
						Text = "Cancel",
						Location = new Point(450, num),
						Width = 90,
						Height = 32,
						CornerRadius = 12,
						NeonColor = Color.FromArgb(255, 80, 80),
						DialogResult = DialogResult.Cancel
					};
					panel.Controls.Add(this.btnCancel);
					base.AcceptButton = this.btnOK;
					base.CancelButton = this.btnCancel;
					base.EnableDragOn(this);
				}
			}

			// Token: 0x0600193B RID: 6459 RVA: 0x000C86E0 File Offset: 0x000C86E0
			private void BrowseFile(int num)
			{
				using (OpenFileDialog openFileDialog = new OpenFileDialog())
				{
					openFileDialog.Filter = "Binary files (*.bin;*.hex;*.rom;*.eep;*.dat)|*.bin;*.hex;*.rom;*.eep;*.dat|All files (*.*)|*.*";
					openFileDialog.Title = "Select file for comparison";
					if (openFileDialog.ShowDialog(this) == DialogResult.OK)
					{
						ComboBox comboBox = (num == 1) ? this.cmbFile1 : this.cmbFile2;
						if (!comboBox.Items.Contains(openFileDialog.FileName))
						{
							comboBox.Items.Add(openFileDialog.FileName);
						}
						comboBox.SelectedItem = openFileDialog.FileName;
					}
				}
			}

			// Token: 0x0600193C RID: 6460 RVA: 0x000C8774 File Offset: 0x000C8774
			private void BtnOK_Click(object sender, EventArgs e)
			{
				if (this.cmbFile1.SelectedItem == null || this.cmbFile2.SelectedItem == null)
				{
					MessageBox.Show(this, "Please select both files for comparison.", "Compare", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return;
				}
				this.File1Path = this.cmbFile1.SelectedItem.ToString();
				this.File2Path = this.cmbFile2.SelectedItem.ToString();
				this.VerticalLayout = this.radioVertical.Checked;
				this.CompareAll = this.radioAll.Checked;
			}

			// Token: 0x04001F1E RID: 7966
			private ComboBox cmbFile1;

			// Token: 0x04001F1F RID: 7967
			private ComboBox cmbFile2;

			// Token: 0x04001F20 RID: 7968
			private Button btnBrowse1;

			// Token: 0x04001F21 RID: 7969
			private Button btnBrowse2;

			// Token: 0x04001F22 RID: 7970
			private RadioButton radioVertical;

			// Token: 0x04001F23 RID: 7971
			private RadioButton radioHorizontal;

			// Token: 0x04001F24 RID: 7972
			private RadioButton radioAll;

			// Token: 0x04001F25 RID: 7973
			private RadioButton radioSelected;

			// Token: 0x04001F26 RID: 7974
			private Button btnOK;

			// Token: 0x04001F27 RID: 7975
			private Button btnCancel;
		}

		// Token: 0x0200088B RID: 2187
		private class FormCompareViewer : NeonForm
		{
			// Token: 0x06001941 RID: 6465 RVA: 0x000C8800 File Offset: 0x000C8800
			public FormCompareViewer(byte[] data1, byte[] data2, string name1, string name2, bool verticalLayout, int bytesPerRow)
			{
				this.dgv1Sync = true;
				this.dgv2Sync = true;
				this.data1 = data1;
				this.data2 = data2;
				this.bytesPerRow = bytesPerRow;
				this.differences = new List<int>();
				base.CornerRadius = 22;
				base.NeonColor = Color.DarkCyan;
				base.BorderThickness = 8;
				this.BackColor = Color.FromArgb(18, 18, 22);
				this.ForeColor = Color.White;
				base.TopMost = true;
				this.Text = "Compare: " + name1 + " vs " + name2;
				base.ClientSize = new Size(1240, 670);
				base.StartPosition = FormStartPosition.CenterScreen;
				this.FindDifferences();
				Panel panel = new Panel
				{
					Dock = DockStyle.Fill,
					BackColor = Color.Transparent,
					Padding = new Padding(6)
				};
				base.Controls.Add(panel);
				if (verticalLayout)
				{
					this.SetupVerticalLayout(panel, name1, name2);
				}
				else
				{
					this.SetupHorizontalLayout(panel, name1, name2);
				}
				this.AddDifferencePanel(panel);
				RoundedButton btnClose = new RoundedButton
				{
					Text = "✕",
					Width = 34,
					Height = 34,
					CornerRadius = 7,
					NeonColor = Color.FromArgb(255, 80, 80),
					HoverColor = Color.FromArgb(255, 120, 120),
					Anchor = (AnchorStyles.Top | AnchorStyles.Right)
				};
				Action placeClose = checked(delegate()
				{
					int num = Math.Max(2, this.BorderThickness + 6);
					btnClose.Location = new Point(this.ClientSize.Width - btnClose.Width - num, num);
				});
				placeClose();
				btnClose.Click += delegate(object s, EventArgs e)
				{
					base.Close();
				};
				base.Resize += delegate(object s, EventArgs e)
				{
					placeClose();
				};
				base.Controls.Add(btnClose);
				btnClose.BringToFront();
				base.EnableDragOn(this);
			}

			// Token: 0x06001942 RID: 6466 RVA: 0x000C89E0 File Offset: 0x000C89E0
			private void FindDifferences()
			{
				int num = Math.Max(this.data1.Length, this.data2.Length);
				checked
				{
					for (int i = 0; i < num; i++)
					{
						byte b = (i < this.data1.Length) ? this.data1[i] : byte.MaxValue;
						byte b2 = (i < this.data2.Length) ? this.data2[i] : byte.MaxValue;
						if (b != b2)
						{
							this.differences.Add(i);
						}
					}
				}
			}

			// Token: 0x06001943 RID: 6467 RVA: 0x000C8A54 File Offset: 0x000C8A54
			private void AddDifferencePanel(Control host)
			{
				RoundedPanel roundedPanel = new RoundedPanel
				{
					Dock = DockStyle.Bottom,
					Height = 170,
					BackColor = Color.FromArgb(24, 26, 32),
					CornerRadius = 10,
					BorderColor = Color.FromArgb(40, 44, 52),
					BorderThickness = 1,
					Padding = new Padding(8)
				};
				Label value = new Label
				{
					Text = "DIFFERENCE DETAILS",
					Dock = DockStyle.Top,
					Height = 20,
					ForeColor = Color.FromArgb(0, 220, 255),
					Font = new Font("Segoe UI", 8f, FontStyle.Bold),
					TextAlign = ContentAlignment.MiddleLeft
				};
				this.txtDiffDetails = new RichTextBox
				{
					Dock = DockStyle.Fill,
					ReadOnly = true,
					DetectUrls = false,
					WordWrap = false,
					BackColor = Color.FromArgb(16, 16, 20),
					ForeColor = Color.LightGreen,
					Font = new Font("Consolas", 8.5f),
					BorderStyle = BorderStyle.None
				};
				roundedPanel.Controls.Add(this.txtDiffDetails);
				roundedPanel.Controls.Add(value);
				host.Controls.Add(roundedPanel);
				this.GenerateDifferenceReport();
			}

			// Token: 0x06001944 RID: 6468 RVA: 0x000C8B98 File Offset: 0x000C8B98
			private void GenerateDifferenceReport()
			{
				if (this.txtDiffDetails == null || this.txtDiffDetails.IsDisposed)
				{
					return;
				}
				if (this.differences.Count == 0)
				{
					this.txtDiffDetails.Text = "Status: IDENTICAL\r\nNo differences found.";
					return;
				}
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.AppendLine(string.Format("Total Differences: {0}", this.differences.Count));
				stringBuilder.AppendLine(new string('-', 80));
				stringBuilder.AppendLine(string.Format("{0,10} | {1,10} | {2,10} | {3,6} | {4,6}", new object[]
				{
					"ADDRESS",
					"FILE 1 VAL",
					"FILE 2 VAL",
					"ASCII 1",
					"ASCII 2"
				}));
				stringBuilder.AppendLine(new string('-', 80));
				int num = Math.Min(this.differences.Count, 200);
				checked
				{
					for (int i = 0; i < num; i++)
					{
						int num2 = this.differences[i];
						byte b = (num2 < this.data1.Length) ? this.data1[num2] : byte.MaxValue;
						byte b2 = (num2 < this.data2.Length) ? this.data2[num2] : byte.MaxValue;
						char c = (char)((b >= 32 && b <= 126) ? b : 46);
						char c2 = (char)((b2 >= 32 && b2 <= 126) ? b2 : 46);
						stringBuilder.AppendFormat("0x{0:X8} |     0x{1:X2}     |     0x{2:X2}     |   '{3}'    |   '{4}'\r\n", new object[]
						{
							num2,
							b,
							b2,
							c,
							c2
						});
					}
					if (this.differences.Count > 200)
					{
						stringBuilder.AppendLine("... (Truncated, showing first 200 differences) ...");
					}
					this.txtDiffDetails.Text = stringBuilder.ToString();
					this.txtDiffDetails.SelectionStart = 0;
					this.txtDiffDetails.ScrollToCaret();
				}
			}

			// Token: 0x06001945 RID: 6469 RVA: 0x000C8D80 File Offset: 0x000C8D80
			private void SetupVerticalLayout(Control host, string name1, string name2)
			{
				SplitContainer splitContainer = new SplitContainer
				{
					Dock = DockStyle.Fill,
					Orientation = Orientation.Horizontal,
					BackColor = this.BackColor,
					Padding = new Padding(6)
				};
				splitContainer.Panel1.Controls.Add(this.CreateFilePanel(name1, ref this.dgvFile1, this.data1, true));
				splitContainer.Panel2.Controls.Add(this.CreateFilePanel(name2, ref this.dgvFile2, this.data2, false));
				host.Controls.Add(splitContainer);
				this.HookSync(this.dgvFile1, this.dgvFile2, true);
				this.HookSync(this.dgvFile2, this.dgvFile1, false);
			}

			// Token: 0x06001946 RID: 6470 RVA: 0x000C8E34 File Offset: 0x000C8E34
			private void SetupHorizontalLayout(Control host, string name1, string name2)
			{
				SplitContainer splitContainer = new SplitContainer
				{
					Dock = DockStyle.Fill,
					Orientation = Orientation.Vertical,
					BackColor = this.BackColor,
					Padding = new Padding(6)
				};
				splitContainer.Panel1.Controls.Add(this.CreateFilePanel(name1, ref this.dgvFile1, this.data1, true));
				splitContainer.Panel2.Controls.Add(this.CreateFilePanel(name2, ref this.dgvFile2, this.data2, false));
				host.Controls.Add(splitContainer);
				this.HookSync(this.dgvFile1, this.dgvFile2, true);
				this.HookSync(this.dgvFile2, this.dgvFile1, false);
			}

			// Token: 0x06001947 RID: 6471 RVA: 0x000C8EE8 File Offset: 0x000C8EE8
			private void HookSync(DataGridView a, DataGridView b, bool aIsFile1)
			{
				a.Scroll += delegate(object s, ScrollEventArgs e)
				{
					if (!(aIsFile1 ? this.dgv2Sync : this.dgv1Sync) || b.RowCount == 0)
					{
						return;
					}
					int firstDisplayedScrollingRowIndex = a.FirstDisplayedScrollingRowIndex;
					if (firstDisplayedScrollingRowIndex >= 0 && firstDisplayedScrollingRowIndex < b.RowCount)
					{
						b.FirstDisplayedScrollingRowIndex = firstDisplayedScrollingRowIndex;
					}
				};
			}

			// Token: 0x06001948 RID: 6472 RVA: 0x000C8F30 File Offset: 0x000C8F30
			private Panel CreateFilePanel(string title, ref DataGridView dgv, byte[] data, bool isFile1)
			{
				RoundedPanel roundedPanel = new RoundedPanel();
				roundedPanel.Dock = DockStyle.Fill;
				roundedPanel.Padding = new Padding(8);
				roundedPanel.BackColor = Color.FromArgb(24, 26, 32);
				roundedPanel.CornerRadius = 10;
				roundedPanel.BorderColor = Color.FromArgb(40, 44, 52);
				roundedPanel.BorderThickness = 1;
				Label value = new Label
				{
					Text = title,
					Dock = DockStyle.Top,
					Height = 22,
					ForeColor = Color.FromArgb(0, 220, 255),
					Font = new Font("Segoe UI", 9f, FontStyle.Bold)
				};
				dgv = this.CreateDataGridView(data, isFile1);
				dgv.Dock = DockStyle.Fill;
				roundedPanel.Controls.Add(dgv);
				roundedPanel.Controls.Add(value);
				this.PopulateGrid(dgv, data);
				return roundedPanel;
			}

			// Token: 0x06001949 RID: 6473 RVA: 0x000C9004 File Offset: 0x000C9004
			private DataGridView CreateDataGridView(byte[] dataRef, bool isFile1)
			{
				DataGridView dataGridView = new DataGridView();
				dataGridView.VirtualMode = true;
				dataGridView.AllowUserToAddRows = false;
				dataGridView.AllowUserToDeleteRows = false;
				dataGridView.AllowUserToResizeRows = false;
				dataGridView.AllowUserToResizeColumns = false;
				dataGridView.RowHeadersWidth = 72;
				dataGridView.SelectionMode = DataGridViewSelectionMode.CellSelect;
				dataGridView.MultiSelect = true;
				dataGridView.ReadOnly = true;
				dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
				dataGridView.EnableHeadersVisualStyles = false;
				dataGridView.BackgroundColor = Color.FromArgb(18, 18, 22);
				dataGridView.BorderStyle = BorderStyle.None;
				dataGridView.GridColor = Color.FromArgb(35, 38, 44);
				dataGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
				dataGridView.RowHeadersVisible = true;
				dataGridView.Font = new Font("Consolas", 9f);
				dataGridView.DefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = Color.FromArgb(24, 26, 32),
					ForeColor = Color.White,
					SelectionBackColor = Color.FromArgb(0, 120, 200),
					SelectionForeColor = Color.White,
					Alignment = DataGridViewContentAlignment.MiddleCenter
				};
				dataGridView.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
				{
					Font = new Font("Segoe UI Semibold", 8f, FontStyle.Bold),
					BackColor = Color.FromArgb(30, 34, 42),
					ForeColor = Color.FromArgb(0, 220, 255),
					SelectionBackColor = Color.FromArgb(30, 34, 42),
					Alignment = DataGridViewContentAlignment.MiddleCenter
				};
				dataGridView.RowHeadersDefaultCellStyle = new DataGridViewCellStyle
				{
					Font = new Font("Consolas", 8f),
					BackColor = Color.FromArgb(28, 30, 36),
					ForeColor = Color.FromArgb(150, 200, 220)
				};
				dataGridView.CellValueNeeded += delegate(object s, DataGridViewCellValueEventArgs e)
				{
					this.DgvCompare_CellValueNeeded(s, e, dataRef);
				};
				dataGridView.RowPrePaint += delegate(object s, DataGridViewRowPrePaintEventArgs e)
				{
					this.DgvCompare_RowPrePaint(s, e, dataRef);
				};
				dataGridView.DataError += delegate(object s, DataGridViewDataErrorEventArgs e)
				{
					e.ThrowException = false;
				};
				return dataGridView;
			}

			// Token: 0x0600194A RID: 6474 RVA: 0x000C9208 File Offset: 0x000C9208
			private void PopulateGrid(DataGridView dgv, byte[] data)
			{
				dgv.Columns.Clear();
				dgv.Columns.Add(new DataGridViewTextBoxColumn
				{
					HeaderText = "ADDRESS",
					Width = 72,
					ReadOnly = true,
					SortMode = DataGridViewColumnSortMode.NotSortable
				});
				checked
				{
					for (int i = 0; i < this.bytesPerRow; i++)
					{
						dgv.Columns.Add(new DataGridViewTextBoxColumn
						{
							HeaderText = i.ToString("X2"),
							Width = 31,
							SortMode = DataGridViewColumnSortMode.NotSortable
						});
					}
					dgv.Columns.Add(new DataGridViewTextBoxColumn
					{
						HeaderText = "ASCII",
						Width = 170,
						ReadOnly = true,
						SortMode = DataGridViewColumnSortMode.NotSortable
					});
					int rowCount = (data.Length + this.bytesPerRow - 1) / this.bytesPerRow;
					dgv.RowCount = rowCount;
					dgv.Invalidate();
				}
			}

			// Token: 0x0600194B RID: 6475 RVA: 0x000C92EC File Offset: 0x000C92EC
			private void DgvCompare_CellValueNeeded(object sender, DataGridViewCellValueEventArgs e, byte[] data)
			{
				if (e.RowIndex < 0)
				{
					return;
				}
				checked
				{
					int num = e.RowIndex * this.bytesPerRow;
					if (e.ColumnIndex == 0)
					{
						e.Value = num.ToString("X8");
						return;
					}
					if (e.ColumnIndex >= 1 && e.ColumnIndex <= this.bytesPerRow)
					{
						int num2 = num + e.ColumnIndex - 1;
						e.Value = ((num2 < data.Length) ? data[num2].ToString("X2") : "");
						return;
					}
					if (e.ColumnIndex == this.bytesPerRow + 1)
					{
						int num3 = Math.Min(this.bytesPerRow, data.Length - num);
						if (num3 <= 0)
						{
							e.Value = "";
							return;
						}
						char[] array = new char[num3];
						for (int i = 0; i < num3; i++)
						{
							byte b = data[num + i];
							array[i] = (char)((b >= 32 && b <= 126) ? b : 46);
						}
						e.Value = new string(array);
					}
				}
			}

			// Token: 0x0600194C RID: 6476 RVA: 0x000C93E8 File Offset: 0x000C93E8
			private void DgvCompare_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e, byte[] data)
			{
				checked
				{
					if (e.RowIndex * this.bytesPerRow >= data.Length)
					{
						return;
					}
					int num = e.RowIndex * this.bytesPerRow;
					bool flag = false;
					int num2 = 0;
					while (num2 < this.bytesPerRow && num + num2 < data.Length)
					{
						if (this.differences.Contains(num + num2))
						{
							flag = true;
							break;
						}
						num2++;
					}
					e.InheritedRowStyle.BackColor = (flag ? Color.FromArgb(80, 30, 30) : ((e.RowIndex % 2 == 0) ? Color.FromArgb(24, 26, 32) : Color.FromArgb(20, 22, 28)));
				}
			}

			// Token: 0x04001F28 RID: 7976
			private DataGridView dgvFile1;

			// Token: 0x04001F29 RID: 7977
			private DataGridView dgvFile2;

			// Token: 0x04001F2A RID: 7978
			private RichTextBox txtDiffDetails;

			// Token: 0x04001F2B RID: 7979
			private byte[] data1;

			// Token: 0x04001F2C RID: 7980
			private byte[] data2;

			// Token: 0x04001F2D RID: 7981
			private int bytesPerRow;

			// Token: 0x04001F2E RID: 7982
			private List<int> differences;

			// Token: 0x04001F2F RID: 7983
			private bool dgv1Sync;

			// Token: 0x04001F30 RID: 7984
			private bool dgv2Sync;
		}
	}
}
