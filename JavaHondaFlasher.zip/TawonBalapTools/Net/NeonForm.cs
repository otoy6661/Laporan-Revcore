﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace TawonBalapTools.Net
{
	// Token: 0x02000884 RID: 2180
	public partial class NeonForm : Form
	{
		// Token: 0x17000181 RID: 385
		// (get) Token: 0x060018D1 RID: 6353 RVA: 0x0000F1C8 File Offset: 0x0000F1C8
		// (set) Token: 0x060018D2 RID: 6354 RVA: 0x0000F1D0 File Offset: 0x0000F1D0
		public int CornerRadius { get; set; } = 18;

		// Token: 0x17000182 RID: 386
		// (get) Token: 0x060018D3 RID: 6355 RVA: 0x0000F1D9 File Offset: 0x0000F1D9
		// (set) Token: 0x060018D4 RID: 6356 RVA: 0x0000F1E1 File Offset: 0x0000F1E1
		public Color NeonColor { get; set; } = Color.FromArgb(0, 200, 255);

		// Token: 0x17000183 RID: 387
		// (get) Token: 0x060018D5 RID: 6357 RVA: 0x0000F1EA File Offset: 0x0000F1EA
		// (set) Token: 0x060018D6 RID: 6358 RVA: 0x0000F1F2 File Offset: 0x0000F1F2
		public int BorderThickness { get; set; } = 7;

		// Token: 0x060018D7 RID: 6359
		[DllImport("dwmapi.dll")]
		private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

		// Token: 0x17000184 RID: 388
		// (get) Token: 0x060018D8 RID: 6360 RVA: 0x0000F1FB File Offset: 0x0000F1FB
		// (set) Token: 0x060018D9 RID: 6361 RVA: 0x0000F203 File Offset: 0x0000F203
		public bool DragEnabled
		{
			get
			{
				return this._dragEnabled;
			}
			set
			{
				this._dragEnabled = value;
			}
		}

		// Token: 0x060018DA RID: 6362 RVA: 0x000C3EDC File Offset: 0x000C3EDC
		public NeonForm()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.DoubleBuffered = true;
			base.FormBorderStyle = FormBorderStyle.None;
			this.BackColor = Color.FromArgb(18, 18, 22);
			this.ForeColor = Color.White;
			base.Padding = new Padding(this.BorderThickness);
		}

		// Token: 0x17000185 RID: 389
		// (get) Token: 0x060018DB RID: 6363 RVA: 0x0000F20C File Offset: 0x0000F20C
		protected override CreateParams CreateParams
		{
			get
			{
				CreateParams createParams = base.CreateParams;
				createParams.ExStyle |= 33554432;
				return createParams;
			}
		}

		// Token: 0x060018DC RID: 6364 RVA: 0x000C3F64 File Offset: 0x000C3F64
		protected override void OnHandleCreated(EventArgs e)
		{
			base.OnHandleCreated(e);
			try
			{
				int num = 2;
				NeonForm.DwmSetWindowAttribute(base.Handle, 33, ref num, 4);
				int num2 = 1;
				NeonForm.DwmSetWindowAttribute(base.Handle, 20, ref num2, 4);
			}
			catch
			{
			}
		}

		// Token: 0x060018DD RID: 6365 RVA: 0x0000F226 File Offset: 0x0000F226
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.ApplyRegion();
		}

		// Token: 0x060018DE RID: 6366 RVA: 0x000C3FB4 File Offset: 0x000C3FB4
		private void ApplyRegion()
		{
			if (base.WindowState == FormWindowState.Maximized)
			{
				base.Region = null;
				return;
			}
			if (base.Width <= 0 || base.Height <= 0)
			{
				return;
			}
			using (GraphicsPath path = RoundedButton.GetPath(new Rectangle(0, 0, base.Width, base.Height), this.CornerRadius))
			{
				base.Region = new Region(path);
			}
		}

		// Token: 0x060018DF RID: 6367 RVA: 0x000C402C File Offset: 0x000C402C
		public void EnableDragOn(Control c)
		{
			c.MouseDown += delegate(object s, MouseEventArgs e)
			{
				if (e.Button != MouseButtons.Left || !this.DragEnabled)
				{
					return;
				}
				this._dragging = true;
				this._dragOffset = e.Location;
			};
			c.MouseMove += delegate(object s, MouseEventArgs e)
			{
				if (!this._dragging || !this.DragEnabled)
				{
					return;
				}
				if (e.Button != MouseButtons.Left)
				{
					this._dragging = false;
					return;
				}
				Point point = c.PointToScreen(e.Location);
				this.Location = checked(new Point(point.X - this._dragOffset.X, point.Y - this._dragOffset.Y));
			};
			c.MouseUp += delegate(object s, MouseEventArgs e)
			{
				this._dragging = false;
			};
		}

		// Token: 0x060018E0 RID: 6368 RVA: 0x000C4094 File Offset: 0x000C4094
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(10, 10, 12)))
			{
				graphics.FillRectangle(solidBrush, base.ClientRectangle);
			}
		}

		// Token: 0x060018E1 RID: 6369 RVA: 0x000C40EC File Offset: 0x000C40EC
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			checked
			{
				Rectangle rectangle = new Rectangle(1, 1, base.Width - 3, base.Height - 3);
				for (int i = this.BorderThickness + 2; i >= 2; i--)
				{
					using (Pen pen = new Pen(Color.FromArgb(Math.Max(6, 10 + i * 2), this.NeonColor), (float)i))
					{
						Rectangle r = Rectangle.Inflate(rectangle, (0 - i) / 2, (0 - i) / 2);
						if (r.Width > 0 && r.Height > 0)
						{
							using (GraphicsPath path = RoundedButton.GetPath(r, Math.Max(2, this.CornerRadius - i / 2)))
							{
								graphics.DrawPath(pen, path);
							}
						}
					}
				}
				using (GraphicsPath path2 = RoundedButton.GetPath(rectangle, this.CornerRadius))
				{
					using (Pen pen2 = new Pen(this.NeonColor, 1.6f))
					{
						graphics.DrawPath(pen2, path2);
					}
				}
				Rectangle r2 = Rectangle.Inflate(rectangle, -2, -2);
				if (r2.Width > 4 && r2.Height > 4)
				{
					using (GraphicsPath path3 = RoundedButton.GetPath(r2, Math.Max(2, this.CornerRadius - 2)))
					{
						using (Pen pen3 = new Pen(Color.FromArgb(70, this.NeonColor), 1f))
						{
							graphics.DrawPath(pen3, path3);
						}
					}
				}
			}
		}

		// Token: 0x04001EC7 RID: 7879
		private const int DWMWA_WINDOW_CORNER_PREFERENCE = 33;

		// Token: 0x04001EC8 RID: 7880
		private const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;

		// Token: 0x04001EC9 RID: 7881
		private const int DWMWCP_ROUND = 2;

		// Token: 0x04001ECA RID: 7882
		private Point _dragOffset;

		// Token: 0x04001ECB RID: 7883
		private bool _dragging;

		// Token: 0x04001ECC RID: 7884
		private bool _dragEnabled = true;
	}
}
