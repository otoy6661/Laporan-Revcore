﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace TawonBalapTools.Net
{
	// Token: 0x02000882 RID: 2178
	public class RoundedButton : Button
	{
		// Token: 0x1700017A RID: 378
		// (get) Token: 0x060018B8 RID: 6328 RVA: 0x0000F0F2 File Offset: 0x0000F0F2
		// (set) Token: 0x060018B9 RID: 6329 RVA: 0x0000F0FA File Offset: 0x0000F0FA
		public int CornerRadius { get; set; } = 10;

		// Token: 0x1700017B RID: 379
		// (get) Token: 0x060018BA RID: 6330 RVA: 0x0000F103 File Offset: 0x0000F103
		// (set) Token: 0x060018BB RID: 6331 RVA: 0x0000F10B File Offset: 0x0000F10B
		public Color NeonColor { get; set; } = Color.FromArgb(0, 200, 255);

		// Token: 0x1700017C RID: 380
		// (get) Token: 0x060018BC RID: 6332 RVA: 0x0000F114 File Offset: 0x0000F114
		// (set) Token: 0x060018BD RID: 6333 RVA: 0x0000F11C File Offset: 0x0000F11C
		public Color HoverColor { get; set; } = Color.FromArgb(0, 240, 255);

		// Token: 0x1700017D RID: 381
		// (get) Token: 0x060018BE RID: 6334 RVA: 0x0000F125 File Offset: 0x0000F125
		// (set) Token: 0x060018BF RID: 6335 RVA: 0x0000F12D File Offset: 0x0000F12D
		public bool UseNeonGlow { get; set; } = true;

		// Token: 0x060018C0 RID: 6336 RVA: 0x000C3918 File Offset: 0x000C3918
		public RoundedButton()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.FlatStyle = FlatStyle.Flat;
			base.FlatAppearance.BorderSize = 0;
			this.BackColor = Color.Transparent;
			this.ForeColor = this.NeonColor;
			this.Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold);
			this.Cursor = Cursors.Hand;
			base.Size = new Size(90, 30);
		}

		// Token: 0x060018C1 RID: 6337 RVA: 0x0000F136 File Offset: 0x0000F136
		protected override void OnMouseEnter(EventArgs e)
		{
			this._hover = true;
			base.Invalidate();
			base.OnMouseEnter(e);
		}

		// Token: 0x060018C2 RID: 6338 RVA: 0x0000F14C File Offset: 0x0000F14C
		protected override void OnMouseLeave(EventArgs e)
		{
			this._hover = false;
			this._down = false;
			base.Invalidate();
			base.OnMouseLeave(e);
		}

		// Token: 0x060018C3 RID: 6339 RVA: 0x0000F169 File Offset: 0x0000F169
		protected override void OnMouseDown(MouseEventArgs e)
		{
			this._down = true;
			base.Invalidate();
			base.OnMouseDown(e);
		}

		// Token: 0x060018C4 RID: 6340 RVA: 0x0000F17F File Offset: 0x0000F17F
		protected override void OnMouseUp(MouseEventArgs e)
		{
			this._down = false;
			base.Invalidate();
			base.OnMouseUp(e);
		}

		// Token: 0x060018C5 RID: 6341 RVA: 0x000C39CC File Offset: 0x000C39CC
		public static GraphicsPath GetPath(Rectangle r, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			checked
			{
				int num = radius * 2;
				if (num > r.Width)
				{
					num = r.Width;
				}
				if (num > r.Height)
				{
					num = r.Height;
				}
				if (num <= 0)
				{
					graphicsPath.AddRectangle(r);
					return graphicsPath;
				}
				graphicsPath.AddArc(r.X, r.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(r.Right - num, r.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(r.Right - num, r.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(r.X, r.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x060018C6 RID: 6342 RVA: 0x000C3AA4 File Offset: 0x000C3AA4
		protected override void OnPaint(PaintEventArgs pevent)
		{
			Graphics graphics = pevent.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
			using (SolidBrush solidBrush = new SolidBrush(this.GetParentBgColor()))
			{
				graphics.FillRectangle(solidBrush, base.ClientRectangle);
			}
			checked
			{
				Rectangle rectangle = new Rectangle(2, 2, base.Width - 5, base.Height - 5);
				using (GraphicsPath path = RoundedButton.GetPath(rectangle, this.CornerRadius))
				{
					if (this.UseNeonGlow)
					{
						for (int i = 5; i >= 1; i--)
						{
							using (Pen pen = new Pen(Color.FromArgb((this._hover ? 20 : 12) * i / 2, this.NeonColor), (float)i))
							{
								Rectangle r = Rectangle.Inflate(rectangle, (0 - i) / 2, (0 - i) / 2);
								if (r.Width > 0 && r.Height > 0)
								{
									using (GraphicsPath path2 = RoundedButton.GetPath(r, Math.Max(2, this.CornerRadius - i / 2)))
									{
										graphics.DrawPath(pen, path2);
									}
								}
							}
						}
					}
					using (SolidBrush solidBrush2 = new SolidBrush(this._down ? Color.FromArgb(45, 55, 65) : (this._hover ? Color.FromArgb(34, 44, 54) : Color.FromArgb(24, 28, 34))))
					{
						graphics.FillPath(solidBrush2, path);
					}
					using (Pen pen2 = new Pen(this._hover ? this.HoverColor : this.NeonColor, 1.5f))
					{
						graphics.DrawPath(pen2, path);
					}
					TextRenderer.DrawText(graphics, this.Text, this.Font, base.ClientRectangle, this._hover ? this.HoverColor : this.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
				}
			}
		}

		// Token: 0x060018C7 RID: 6343 RVA: 0x000C3D20 File Offset: 0x000C3D20
		private Color GetParentBgColor()
		{
			for (Control parent = base.Parent; parent != null; parent = parent.Parent)
			{
				if (parent.BackColor.A > 0)
				{
					return parent.BackColor;
				}
			}
			return Color.FromArgb(24, 26, 32);
		}

		// Token: 0x04001EBF RID: 7871
		private bool _hover;

		// Token: 0x04001EC0 RID: 7872
		private bool _down;
	}
}
