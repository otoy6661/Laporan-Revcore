﻿namespace TawonBalapTools.Net
{
	// Token: 0x02000886 RID: 2182
	public partial class FormHXD : global::TawonBalapTools.Net.NeonForm
	{
		// Token: 0x060018E7 RID: 6375 RVA: 0x000C4420 File Offset: 0x000C4420
		private void InitializeComponent()
		{
			base.SuspendLayout();
			base.CornerRadius = 22;
			base.NeonColor = this.neonBlue;
			base.BorderThickness = 8;
			this.BackColor = this.darkBack;
			this.ForeColor = global::System.Drawing.Color.Cyan;
			this.Text = "DEPPLOY MAP TUNING HXD EDITOR";
			base.TopMost = true;
			base.ClientSize = new global::System.Drawing.Size(1365, 730);
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			base.KeyPreview = true;
			checked
			{
				int innerInset = global::System.Math.Max(2, base.BorderThickness - 1);
				this.innerPanel = new global::System.Windows.Forms.Panel
				{
					Dock = global::System.Windows.Forms.DockStyle.None,
					BackColor = this.darkBack,
					Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right)
				};
				this.innerPanel.Paint += delegate(object s, global::System.Windows.Forms.PaintEventArgs e)
				{
					global::System.Drawing.Graphics graphics = e.Graphics;
					graphics.SmoothingMode = global::System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
					using (global::System.Drawing.Drawing2D.GraphicsPath path = global::TawonBalapTools.Net.RoundedButton.GetPath(new global::System.Drawing.Rectangle(0, 0, this.innerPanel.Width, this.innerPanel.Height), global::System.Math.Max(2, this.CornerRadius - innerInset - 1)))
					{
						using (global::System.Drawing.SolidBrush solidBrush = new global::System.Drawing.SolidBrush(this.darkBack))
						{
							graphics.FillPath(solidBrush, path);
						}
					}
				};
				this.innerPanel.Resize += delegate(object s, global::System.EventArgs e)
				{
					using (global::System.Drawing.Drawing2D.GraphicsPath path = global::TawonBalapTools.Net.RoundedButton.GetPath(new global::System.Drawing.Rectangle(0, 0, this.innerPanel.Width, this.innerPanel.Height), global::System.Math.Max(2, this.CornerRadius - innerInset - 1)))
					{
						this.innerPanel.Region = new global::System.Drawing.Region(path);
					}
				};
				base.Controls.Add(this.innerPanel);
				this.innerPanel.BringToFront();
				global::System.Action layoutInner = delegate()
				{
					int num = base.BorderThickness + 1;
					this.innerPanel.Bounds = new global::System.Drawing.Rectangle(num, num, global::System.Math.Max(0, base.ClientSize.Width - num * 2), global::System.Math.Max(0, base.ClientSize.Height - num * 2));
				};
				layoutInner();
				base.Resize += delegate(object s, global::System.EventArgs e)
				{
					layoutInner();
				};
				this.headerBar = new global::System.Windows.Forms.Panel
				{
					Dock = global::System.Windows.Forms.DockStyle.Top,
					Height = 42,
					BackColor = this.darkPanel
				};
				this.headerBar.Paint += delegate(object s, global::System.Windows.Forms.PaintEventArgs e)
				{
					global::System.Drawing.Graphics graphics = e.Graphics;
					using (global::System.Drawing.Pen pen = new global::System.Drawing.Pen(global::System.Drawing.Color.FromArgb(40, 44, 52), 1f))
					{
						graphics.DrawLine(pen, 0, this.headerBar.Height - 1, this.headerBar.Width, this.headerBar.Height - 1);
					}
				};
				this.lblTitle = new global::System.Windows.Forms.Label
				{
					Text = "●  DEPPLOY MAP TUNING HXD EDITOR",
					AutoSize = false,
					Dock = global::System.Windows.Forms.DockStyle.Left,
					Width = 400,
					TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft,
					Padding = new global::System.Windows.Forms.Padding(14, 0, 0, 0),
					ForeColor = this.neonBlue,
					Font = new global::System.Drawing.Font("Segoe UI Semibold", 10f, global::System.Drawing.FontStyle.Bold),
					BackColor = global::System.Drawing.Color.Transparent
				};
				this.headerBar.Controls.Add(this.lblTitle);
				this.btnClose = new global::TawonBalapTools.Net.RoundedButton
				{
					Text = "✕",
					Width = 34,
					Height = 34,
					CornerRadius = 7,
					NeonColor = global::System.Drawing.Color.FromArgb(255, 90, 90),
					HoverColor = global::System.Drawing.Color.FromArgb(255, 140, 140),
					Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right)
				};
				this.headerBar.Controls.Add(this.btnClose);
				global::System.Action placeClose = delegate()
				{
					this.btnClose.Location = new global::System.Drawing.Point(this.headerBar.Width - this.btnClose.Width - 10, (this.headerBar.Height - this.btnClose.Height) / 2);
				};
				placeClose();
				this.headerBar.Resize += delegate(object s, global::System.EventArgs e)
				{
					placeClose();
				};
				this.menuStrip = new global::System.Windows.Forms.MenuStrip
				{
					BackColor = this.darkPanel,
					ForeColor = global::System.Drawing.Color.White,
					RenderMode = global::System.Windows.Forms.ToolStripRenderMode.Professional,
					Padding = new global::System.Windows.Forms.Padding(10, 2, 4, 2),
					GripStyle = global::System.Windows.Forms.ToolStripGripStyle.Hidden,
					Dock = global::System.Windows.Forms.DockStyle.Top
				};
				this.menuFile = new global::System.Windows.Forms.ToolStripMenuItem("&File");
				this.btnOpen = new global::System.Windows.Forms.ToolStripMenuItem("&Open...\tCtrl+O");
				this.btnSave = new global::System.Windows.Forms.ToolStripMenuItem("&Save\tCtrl+S");
				this.btnSaveAs = new global::System.Windows.Forms.ToolStripMenuItem("Save &As...\tCtrl+Shift+S");
				this.menuFile.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
				{
					this.btnOpen,
					this.btnSave,
					this.btnSaveAs
				});
				this.menuEdit = new global::System.Windows.Forms.ToolStripMenuItem("&Edit");
				this.btnUndo = new global::System.Windows.Forms.ToolStripMenuItem("&Undo\tCtrl+Z");
				this.btnRedo = new global::System.Windows.Forms.ToolStripMenuItem("&Redo\tCtrl+Y");
				this.menuEdit.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
				{
					this.btnUndo,
					this.btnRedo,
					new global::System.Windows.Forms.ToolStripSeparator()
				});
				this.btnCopy = new global::System.Windows.Forms.ToolStripMenuItem("&Copy\tCtrl+C");
				this.btnPaste = new global::System.Windows.Forms.ToolStripMenuItem("&Paste\tCtrl+V");
				this.btnSelectAll = new global::System.Windows.Forms.ToolStripMenuItem("Select &All\tCtrl+A");
				this.menuEdit.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
				{
					this.btnCopy,
					this.btnPaste,
					this.btnSelectAll
				});
				this.menuTools = new global::System.Windows.Forms.ToolStripMenuItem("&Tools");
				this.btnCompare = new global::System.Windows.Forms.ToolStripMenuItem("&Compare Files...");
				this.btnChecksum = new global::System.Windows.Forms.ToolStripMenuItem("&Checksum Search...");
				this.menuTools.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
				{
					this.btnCompare,
					this.btnChecksum
				});
				this.menuStrip.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
				{
					this.menuFile,
					this.menuEdit,
					this.menuTools
				});
				this.statusStrip = new global::System.Windows.Forms.StatusStrip
				{
					BackColor = this.darkPanel,
					ForeColor = global::System.Drawing.Color.White,
					SizingGrip = false
				};
				this.lblStatusColor = new global::System.Windows.Forms.ToolStripStatusLabel
				{
					Width = 8,
					Height = 16,
					BackColor = global::System.Drawing.Color.Gray,
					Margin = new global::System.Windows.Forms.Padding(6, 3, 4, 0)
				};
				this.lblStatus = new global::System.Windows.Forms.ToolStripStatusLabel
				{
					Text = "Ready",
					ForeColor = global::System.Drawing.Color.Gray,
					Font = new global::System.Drawing.Font("Segoe UI", 8f)
				};
				global::System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel = new global::System.Windows.Forms.ToolStripStatusLabel
				{
					Spring = true
				};
				this.lblProgress = new global::System.Windows.Forms.ToolStripStatusLabel
				{
					ForeColor = global::System.Drawing.Color.LightGreen,
					Font = new global::System.Drawing.Font("Segoe UI", 8f),
					Margin = new global::System.Windows.Forms.Padding(0, 0, 5, 0)
				};
				this.progress = new global::System.Windows.Forms.ToolStripProgressBar
				{
					Width = 120,
					Height = 16,
					Style = global::System.Windows.Forms.ProgressBarStyle.Continuous
				};
				this.statusStrip.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
				{
					this.lblStatusColor,
					this.lblStatus,
					toolStripStatusLabel,
					this.lblProgress,
					this.progress
				});
				this.dgvHex = new global::System.Windows.Forms.DataGridView
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					VirtualMode = true,
					AllowUserToAddRows = false,
					AllowUserToDeleteRows = false,
					AllowUserToResizeRows = false,
					AllowUserToResizeColumns = false,
					RowHeadersWidth = 72,
					SelectionMode = global::System.Windows.Forms.DataGridViewSelectionMode.CellSelect,
					MultiSelect = true,
					ReadOnly = false,
					EditMode = global::System.Windows.Forms.DataGridViewEditMode.EditOnKeystrokeOrF2,
					AutoSizeColumnsMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnsMode.None,
					EnableHeadersVisualStyles = false,
					BackgroundColor = this.darkGrid,
					BorderStyle = global::System.Windows.Forms.BorderStyle.None,
					GridColor = global::System.Drawing.Color.FromArgb(35, 38, 44),
					CellBorderStyle = global::System.Windows.Forms.DataGridViewCellBorderStyle.Single,
					RowHeadersVisible = true,
					AllowUserToOrderColumns = false,
					Margin = new global::System.Windows.Forms.Padding(0)
				};
				this.dgvHex.DefaultCellStyle = new global::System.Windows.Forms.DataGridViewCellStyle
				{
					Font = new global::System.Drawing.Font("Consolas", 9f),
					BackColor = this.darkGrid,
					ForeColor = global::System.Drawing.Color.FromArgb(220, 230, 240),
					SelectionBackColor = this.selectedColor,
					SelectionForeColor = global::System.Drawing.Color.White,
					Alignment = global::System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
				};
				this.dgvHex.ColumnHeadersDefaultCellStyle = new global::System.Windows.Forms.DataGridViewCellStyle
				{
					Font = new global::System.Drawing.Font("Segoe UI Semibold", 8f, global::System.Drawing.FontStyle.Bold),
					BackColor = this.darkHeader,
					ForeColor = global::System.Drawing.Color.FromArgb(0, 220, 255),
					SelectionBackColor = this.darkHeader,
					Alignment = global::System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
				};
				this.dgvHex.RowHeadersDefaultCellStyle = new global::System.Windows.Forms.DataGridViewCellStyle
				{
					Font = new global::System.Drawing.Font("Consolas", 8f),
					BackColor = global::System.Drawing.Color.FromArgb(28, 30, 36),
					ForeColor = global::System.Drawing.Color.FromArgb(150, 200, 220),
					SelectionBackColor = this.selectedColor,
					SelectionForeColor = global::System.Drawing.Color.White
				};
				global::TawonBalapTools.Net.RoundedPanel roundedPanel = new global::TawonBalapTools.Net.RoundedPanel
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					BackColor = this.darkPanel,
					CornerRadius = 10,
					BorderColor = global::System.Drawing.Color.FromArgb(40, 44, 52),
					BorderThickness = 1,
					Padding = new global::System.Windows.Forms.Padding(10)
				};
				global::System.Windows.Forms.Label label = this.DarkLabel("ASCII PREVIEW", new global::System.Drawing.Point(0, 0));
				label.Dock = global::System.Windows.Forms.DockStyle.Top;
				label.Height = 20;
				label.ForeColor = global::System.Drawing.Color.FromArgb(0, 220, 255);
				this.txtAscii = new global::System.Windows.Forms.RichTextBox
				{
					Dock = global::System.Windows.Forms.DockStyle.Top,
					Height = 170,
					ReadOnly = true,
					DetectUrls = false,
					WordWrap = false,
					BackColor = global::System.Drawing.Color.FromArgb(20, 20, 24),
					ForeColor = global::System.Drawing.Color.White,
					BorderStyle = global::System.Windows.Forms.BorderStyle.None,
					Font = new global::System.Drawing.Font("Consolas", 8f),
					Margin = new global::System.Windows.Forms.Padding(0)
				};
				global::System.Windows.Forms.Panel panel = new global::System.Windows.Forms.Panel
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					BackColor = this.darkPanel,
					Padding = new global::System.Windows.Forms.Padding(0, 8, 0, 0)
				};
				panel.Controls.Add(this.DarkLabel("Endian:", new global::System.Drawing.Point(0, 8)));
				this.cmbEndian = new global::System.Windows.Forms.ComboBox
				{
					Location = new global::System.Drawing.Point(70, 5),
					Width = 170,
					DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList,
					BackColor = global::System.Drawing.Color.FromArgb(40, 44, 52),
					ForeColor = global::System.Drawing.Color.White,
					FlatStyle = global::System.Windows.Forms.FlatStyle.Flat
				};
				this.cmbEndian.Items.AddRange(new object[]
				{
					"Little Endian",
					"Big Endian"
				});
				this.cmbEndian.SelectedIndex = 0;
				panel.Controls.Add(this.cmbEndian);
				panel.Controls.Add(this.DarkLabel("Type:", new global::System.Drawing.Point(0, 36)));
				this.cmbDataType = new global::System.Windows.Forms.ComboBox
				{
					Location = new global::System.Drawing.Point(70, 33),
					Width = 170,
					DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList,
					BackColor = global::System.Drawing.Color.FromArgb(40, 44, 52),
					ForeColor = global::System.Drawing.Color.White,
					FlatStyle = global::System.Windows.Forms.FlatStyle.Flat
				};
				this.cmbDataType.Items.AddRange(new object[]
				{
					"Byte",
					"Int16",
					"Int32",
					"Int64",
					"Single",
					"Double"
				});
				this.cmbDataType.SelectedIndex = 0;
				panel.Controls.Add(this.cmbDataType);
				this.lblEndianInfo = new global::System.Windows.Forms.Label
				{
					Location = new global::System.Drawing.Point(0, 63),
					Size = new global::System.Drawing.Size(240, 90),
					ForeColor = global::System.Drawing.Color.LightGreen,
					Font = new global::System.Drawing.Font("Consolas", 8f)
				};
				panel.Controls.Add(this.lblEndianInfo);
				roundedPanel.Controls.Add(panel);
				roundedPanel.Controls.Add(this.txtAscii);
				roundedPanel.Controls.Add(label);
				this.txtAddress = this.DarkTextBox(75);
				this.txtSearch = this.DarkTextBox(130);
				this.txtReplace = this.DarkTextBox(110);
				this.btnGoTo = this.DarkButton("GO", 55);
				this.btnSearch = this.DarkButton("FIND", 62);
				this.btnFindNext = this.DarkButton("NEXT", 62);
				this.btnReplace = this.DarkButton("REPLACE", 82);
				this.nudBytesPerRow = new global::System.Windows.Forms.NumericUpDown
				{
					Width = 50,
					Minimum = 4m,
					Maximum = 32m,
					Value = 16m,
					BackColor = global::System.Drawing.Color.FromArgb(40, 44, 52),
					ForeColor = global::System.Drawing.Color.White,
					BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle,
					Font = new global::System.Drawing.Font("Consolas", 8f),
					Margin = new global::System.Windows.Forms.Padding(2, 3, 8, 0)
				};
				this.chkAutoScroll = new global::System.Windows.Forms.CheckBox
				{
					Text = "Auto Scroll",
					Checked = true,
					AutoSize = true,
					ForeColor = global::System.Drawing.Color.White,
					Margin = new global::System.Windows.Forms.Padding(6, 4, 6, 0)
				};
				this.lblFileInfo = new global::System.Windows.Forms.Label
				{
					Dock = global::System.Windows.Forms.DockStyle.Top,
					Height = 22,
					ForeColor = global::System.Drawing.Color.LightGray,
					Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Bold),
					AutoEllipsis = true,
					Padding = new global::System.Windows.Forms.Padding(4, 2, 0, 0)
				};
				global::System.Windows.Forms.FlowLayoutPanel flowLayoutPanel = new global::System.Windows.Forms.FlowLayoutPanel
				{
					Dock = global::System.Windows.Forms.DockStyle.Top,
					Height = 38,
					WrapContents = false,
					AutoScroll = true,
					BackColor = this.darkPanel,
					Padding = new global::System.Windows.Forms.Padding(2, 4, 0, 2)
				};
				this.AddAction(flowLayoutPanel, "Go:", this.txtAddress, new global::System.Windows.Forms.Control[]
				{
					this.btnGoTo
				});
				this.AddAction(flowLayoutPanel, "Find:", this.txtSearch, new global::System.Windows.Forms.Control[]
				{
					this.btnSearch,
					this.btnFindNext
				});
				this.AddAction(flowLayoutPanel, "Replace:", this.txtReplace, new global::System.Windows.Forms.Control[]
				{
					this.btnReplace
				});
				global::System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2 = new global::System.Windows.Forms.FlowLayoutPanel
				{
					Dock = global::System.Windows.Forms.DockStyle.Top,
					Height = 34,
					WrapContents = false,
					BackColor = this.darkPanel,
					Padding = new global::System.Windows.Forms.Padding(2, 2, 0, 2)
				};
				flowLayoutPanel2.Controls.Add(this.DarkLabel("Bytes/Row:", new global::System.Drawing.Point(0, 6)));
				flowLayoutPanel2.Controls.Add(this.nudBytesPerRow);
				flowLayoutPanel2.Controls.Add(this.chkAutoScroll);
				global::System.Windows.Forms.Label value = new global::System.Windows.Forms.Label
				{
					Text = "COMPARE / CHECKSUM RESULTS",
					Dock = global::System.Windows.Forms.DockStyle.Top,
					Height = 20,
					ForeColor = global::System.Drawing.Color.FromArgb(0, 220, 255),
					Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Bold),
					Padding = new global::System.Windows.Forms.Padding(4, 2, 0, 0)
				};
				this.txtResults = new global::System.Windows.Forms.RichTextBox
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					ReadOnly = true,
					DetectUrls = false,
					WordWrap = false,
					BackColor = global::System.Drawing.Color.FromArgb(16, 16, 20),
					ForeColor = global::System.Drawing.Color.LightGreen,
					Font = new global::System.Drawing.Font("Consolas", 7.5f),
					BorderStyle = global::System.Windows.Forms.BorderStyle.None
				};
				global::TawonBalapTools.Net.RoundedPanel roundedPanel2 = new global::TawonBalapTools.Net.RoundedPanel
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					BackColor = this.darkPanel2,
					CornerRadius = 8,
					BorderColor = global::System.Drawing.Color.FromArgb(40, 44, 52),
					BorderThickness = 1,
					Padding = new global::System.Windows.Forms.Padding(6)
				};
				roundedPanel2.Controls.Add(this.txtResults);
				roundedPanel2.Controls.Add(value);
				global::TawonBalapTools.Net.RoundedPanel roundedPanel3 = new global::TawonBalapTools.Net.RoundedPanel
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					Height = 205,
					BackColor = this.darkPanel,
					CornerRadius = 10,
					BorderColor = global::System.Drawing.Color.FromArgb(40, 44, 52),
					BorderThickness = 1,
					Padding = new global::System.Windows.Forms.Padding(8)
				};
				global::System.Windows.Forms.Panel panel2 = new global::System.Windows.Forms.Panel
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					BackColor = this.darkPanel
				};
				panel2.Controls.Add(roundedPanel2);
				panel2.Controls.Add(flowLayoutPanel2);
				panel2.Controls.Add(flowLayoutPanel);
				panel2.Controls.Add(this.lblFileInfo);
				roundedPanel3.Controls.Add(panel2);
				global::TawonBalapTools.Net.RoundedPanel roundedPanel4 = new global::TawonBalapTools.Net.RoundedPanel
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					BackColor = this.darkGrid,
					CornerRadius = 10,
					BorderColor = global::System.Drawing.Color.FromArgb(40, 44, 52),
					BorderThickness = 1,
					Padding = new global::System.Windows.Forms.Padding(4)
				};
				roundedPanel4.Controls.Add(this.dgvHex);
				global::System.Windows.Forms.TableLayoutPanel tableLayoutPanel = new global::System.Windows.Forms.TableLayoutPanel
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					ColumnCount = 2,
					RowCount = 2,
					BackColor = this.darkBack,
					Padding = new global::System.Windows.Forms.Padding(10, 6, 10, 6)
				};
				tableLayoutPanel.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Percent, 100f));
				tableLayoutPanel.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Absolute, 285f));
				tableLayoutPanel.RowStyles.Add(new global::System.Windows.Forms.RowStyle(global::System.Windows.Forms.SizeType.Percent, 100f));
				tableLayoutPanel.RowStyles.Add(new global::System.Windows.Forms.RowStyle(global::System.Windows.Forms.SizeType.Absolute, 218f));
				tableLayoutPanel.Controls.Add(roundedPanel4, 0, 0);
				tableLayoutPanel.Controls.Add(roundedPanel, 1, 0);
				tableLayoutPanel.Controls.Add(roundedPanel3, 0, 1);
				tableLayoutPanel.SetColumnSpan(roundedPanel3, 2);
				roundedPanel4.Margin = new global::System.Windows.Forms.Padding(0, 0, 8, 8);
				roundedPanel.Margin = new global::System.Windows.Forms.Padding(0, 0, 0, 8);
				roundedPanel3.Margin = new global::System.Windows.Forms.Padding(0);
				this.innerPanel.Controls.Add(tableLayoutPanel);
				this.innerPanel.Controls.Add(this.menuStrip);
				this.innerPanel.Controls.Add(this.headerBar);
				this.innerPanel.Controls.Add(this.statusStrip);
				base.MainMenuStrip = this.menuStrip;
				this.SetupGridColumns();
				base.ResumeLayout(false);
				base.PerformLayout();
			}
		}

		// Token: 0x04001ECF RID: 7887
		private global::System.Windows.Forms.Panel innerPanel;

		// Token: 0x04001ED0 RID: 7888
		private global::System.Windows.Forms.Panel headerBar;

		// Token: 0x04001ED1 RID: 7889
		private global::System.Windows.Forms.Label lblTitle;

		// Token: 0x04001ED2 RID: 7890
		private global::TawonBalapTools.Net.RoundedButton btnClose;

		// Token: 0x04001ED3 RID: 7891
		private global::System.Windows.Forms.DataGridView dgvHex;

		// Token: 0x04001ED4 RID: 7892
		private global::System.Windows.Forms.RichTextBox txtAscii;

		// Token: 0x04001ED5 RID: 7893
		private global::System.Windows.Forms.TextBox txtAddress;

		// Token: 0x04001ED6 RID: 7894
		private global::System.Windows.Forms.TextBox txtSearch;

		// Token: 0x04001ED7 RID: 7895
		private global::System.Windows.Forms.Button btnSearch;

		// Token: 0x04001ED8 RID: 7896
		private global::System.Windows.Forms.Button btnFindNext;

		// Token: 0x04001ED9 RID: 7897
		private global::System.Windows.Forms.Button btnGoTo;

		// Token: 0x04001EDA RID: 7898
		private global::System.Windows.Forms.Label lblFileInfo;

		// Token: 0x04001EDB RID: 7899
		private global::System.Windows.Forms.CheckBox chkAutoScroll;

		// Token: 0x04001EDC RID: 7900
		private global::System.Windows.Forms.NumericUpDown nudBytesPerRow;

		// Token: 0x04001EDD RID: 7901
		private global::System.Windows.Forms.TextBox txtReplace;

		// Token: 0x04001EDE RID: 7902
		private global::System.Windows.Forms.Button btnReplace;

		// Token: 0x04001EDF RID: 7903
		private global::System.Windows.Forms.Label lblEndianInfo;

		// Token: 0x04001EE0 RID: 7904
		private global::System.Windows.Forms.ComboBox cmbEndian;

		// Token: 0x04001EE1 RID: 7905
		private global::System.Windows.Forms.ComboBox cmbDataType;

		// Token: 0x04001EE2 RID: 7906
		private global::System.Windows.Forms.RichTextBox txtResults;

		// Token: 0x04001EE3 RID: 7907
		private global::System.Windows.Forms.MenuStrip menuStrip;

		// Token: 0x04001EE4 RID: 7908
		private global::System.Windows.Forms.StatusStrip statusStrip;

		// Token: 0x04001EE5 RID: 7909
		private global::System.Windows.Forms.ToolStripStatusLabel lblStatusColor;

		// Token: 0x04001EE6 RID: 7910
		private global::System.Windows.Forms.ToolStripStatusLabel lblStatus;

		// Token: 0x04001EE7 RID: 7911
		private global::System.Windows.Forms.ToolStripStatusLabel lblProgress;

		// Token: 0x04001EE8 RID: 7912
		private global::System.Windows.Forms.ToolStripProgressBar progress;

		// Token: 0x04001EE9 RID: 7913
		private global::System.Windows.Forms.ToolStripMenuItem menuFile;

		// Token: 0x04001EEA RID: 7914
		private global::System.Windows.Forms.ToolStripMenuItem menuEdit;

		// Token: 0x04001EEB RID: 7915
		private global::System.Windows.Forms.ToolStripMenuItem menuTools;

		// Token: 0x04001EEC RID: 7916
		private global::System.Windows.Forms.ToolStripMenuItem btnOpen;

		// Token: 0x04001EED RID: 7917
		private global::System.Windows.Forms.ToolStripMenuItem btnSave;

		// Token: 0x04001EEE RID: 7918
		private global::System.Windows.Forms.ToolStripMenuItem btnSaveAs;

		// Token: 0x04001EEF RID: 7919
		private global::System.Windows.Forms.ToolStripMenuItem btnCompare;

		// Token: 0x04001EF0 RID: 7920
		private global::System.Windows.Forms.ToolStripMenuItem btnChecksum;

		// Token: 0x04001EF1 RID: 7921
		private global::System.Windows.Forms.ToolStripMenuItem btnUndo;

		// Token: 0x04001EF2 RID: 7922
		private global::System.Windows.Forms.ToolStripMenuItem btnRedo;

		// Token: 0x04001EF3 RID: 7923
		private global::System.Windows.Forms.ToolStripMenuItem btnCopy;

		// Token: 0x04001EF4 RID: 7924
		private global::System.Windows.Forms.ToolStripMenuItem btnPaste;

		// Token: 0x04001EF5 RID: 7925
		private global::System.Windows.Forms.ToolStripMenuItem btnSelectAll;

		// Token: 0x04001F02 RID: 7938
		private readonly global::System.Drawing.Color darkBack;

		// Token: 0x04001F03 RID: 7939
		private readonly global::System.Drawing.Color darkPanel;

		// Token: 0x04001F04 RID: 7940
		private readonly global::System.Drawing.Color darkPanel2;

		// Token: 0x04001F05 RID: 7941
		private readonly global::System.Drawing.Color darkGrid;

		// Token: 0x04001F06 RID: 7942
		private readonly global::System.Drawing.Color darkHeader;

		// Token: 0x04001F07 RID: 7943
		private readonly global::System.Drawing.Color selectedColor;

		// Token: 0x04001F08 RID: 7944
		private readonly global::System.Drawing.Color neonBlue;
	}
}
