﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace HondaMapEditorPro
{
	// Token: 0x020009CF RID: 2511
	public sealed class LiveTracingOptions
	{
		// Token: 0x170001DB RID: 475
		// (get) Token: 0x06001B0D RID: 6925 RVA: 0x0001029C File Offset: 0x0001029C
		// (set) Token: 0x06001B0E RID: 6926 RVA: 0x000102A4 File Offset: 0x000102A4
		public Color BgDark { get; set; } = Color.FromArgb(15, 20, 30);

		// Token: 0x170001DC RID: 476
		// (get) Token: 0x06001B0F RID: 6927 RVA: 0x000102AD File Offset: 0x000102AD
		// (set) Token: 0x06001B10 RID: 6928 RVA: 0x000102B5 File Offset: 0x000102B5
		public Color BgPanel { get; set; } = Color.FromArgb(20, 28, 40);

		// Token: 0x170001DD RID: 477
		// (get) Token: 0x06001B11 RID: 6929 RVA: 0x000102BE File Offset: 0x000102BE
		// (set) Token: 0x06001B12 RID: 6930 RVA: 0x000102C6 File Offset: 0x000102C6
		public Color BgCard { get; set; } = Color.FromArgb(25, 35, 48);

		// Token: 0x170001DE RID: 478
		// (get) Token: 0x06001B13 RID: 6931 RVA: 0x000102CF File Offset: 0x000102CF
		// (set) Token: 0x06001B14 RID: 6932 RVA: 0x000102D7 File Offset: 0x000102D7
		public Color Fg { get; set; } = Color.FromArgb(220, 230, 240);

		// Token: 0x170001DF RID: 479
		// (get) Token: 0x06001B15 RID: 6933 RVA: 0x000102E0 File Offset: 0x000102E0
		// (set) Token: 0x06001B16 RID: 6934 RVA: 0x000102E8 File Offset: 0x000102E8
		public Color Muted { get; set; } = Color.FromArgb(120, 140, 160);

		// Token: 0x170001E0 RID: 480
		// (get) Token: 0x06001B17 RID: 6935 RVA: 0x000102F1 File Offset: 0x000102F1
		// (set) Token: 0x06001B18 RID: 6936 RVA: 0x000102F9 File Offset: 0x000102F9
		public Color Cyan { get; set; } = Color.FromArgb(0, 200, 220);

		// Token: 0x170001E1 RID: 481
		// (get) Token: 0x06001B19 RID: 6937 RVA: 0x00010302 File Offset: 0x00010302
		// (set) Token: 0x06001B1A RID: 6938 RVA: 0x0001030A File Offset: 0x0001030A
		public Color Gold { get; set; } = Color.FromArgb(230, 180, 40);

		// Token: 0x170001E2 RID: 482
		// (get) Token: 0x06001B1B RID: 6939 RVA: 0x00010313 File Offset: 0x00010313
		// (set) Token: 0x06001B1C RID: 6940 RVA: 0x0001031B File Offset: 0x0001031B
		public Color Green { get; set; } = Color.FromArgb(60, 200, 120);

		// Token: 0x170001E3 RID: 483
		// (get) Token: 0x06001B1D RID: 6941 RVA: 0x00010324 File Offset: 0x00010324
		// (set) Token: 0x06001B1E RID: 6942 RVA: 0x0001032C File Offset: 0x0001032C
		public Color Danger { get; set; } = Color.FromArgb(220, 60, 80);

		// Token: 0x170001E4 RID: 484
		// (get) Token: 0x06001B1F RID: 6943 RVA: 0x00010335 File Offset: 0x00010335
		// (set) Token: 0x06001B20 RID: 6944 RVA: 0x0001033D File Offset: 0x0001033D
		public Color Border { get; set; } = Color.FromArgb(45, 60, 80);

		// Token: 0x170001E5 RID: 485
		// (get) Token: 0x06001B21 RID: 6945 RVA: 0x00010346 File Offset: 0x00010346
		// (set) Token: 0x06001B22 RID: 6946 RVA: 0x0001034E File Offset: 0x0001034E
		public double MinValue { get; set; }

		// Token: 0x170001E6 RID: 486
		// (get) Token: 0x06001B23 RID: 6947 RVA: 0x00010357 File Offset: 0x00010357
		// (set) Token: 0x06001B24 RID: 6948 RVA: 0x0001035F File Offset: 0x0001035F
		public double MaxValue { get; set; } = 100.0;

		// Token: 0x170001E7 RID: 487
		// (get) Token: 0x06001B25 RID: 6949 RVA: 0x00010368 File Offset: 0x00010368
		// (set) Token: 0x06001B26 RID: 6950 RVA: 0x00010370 File Offset: 0x00010370
		public bool SwapAxes { get; set; }

		// Token: 0x170001E8 RID: 488
		// (get) Token: 0x06001B27 RID: 6951 RVA: 0x00010379 File Offset: 0x00010379
		// (set) Token: 0x06001B28 RID: 6952 RVA: 0x00010381 File Offset: 0x00010381
		public string MapTitle { get; set; } = "—";

		// Token: 0x170001E9 RID: 489
		// (get) Token: 0x06001B29 RID: 6953 RVA: 0x0001038A File Offset: 0x0001038A
		// (set) Token: 0x06001B2A RID: 6954 RVA: 0x00010392 File Offset: 0x00010392
		public Func<bool> IsLiveRunning { get; set; } = () => false;

		// Token: 0x170001EA RID: 490
		// (get) Token: 0x06001B2B RID: 6955 RVA: 0x0001039B File Offset: 0x0001039B
		// (set) Token: 0x06001B2C RID: 6956 RVA: 0x000103A3 File Offset: 0x000103A3
		public Func<string, Color, Color, Button> CreateWindowButton { get; set; } = (string text, Color fore, Color back) => new Button
		{
			Text = text,
			ForeColor = fore,
			BackColor = back,
			FlatStyle = FlatStyle.Flat,
			Size = new Size(44, 28)
		};

		// Token: 0x170001EB RID: 491
		// (get) Token: 0x06001B2D RID: 6957 RVA: 0x000103AC File Offset: 0x000103AC
		// (set) Token: 0x06001B2E RID: 6958 RVA: 0x000103B4 File Offset: 0x000103B4
		public Func<Rectangle, int, GraphicsPath> CreateRoundedRect { get; set; } = new Func<Rectangle, int, GraphicsPath>(LiveTracingOptions.MakeRoundedRect);

		// Token: 0x170001EC RID: 492
		// (get) Token: 0x06001B2F RID: 6959 RVA: 0x000103BD File Offset: 0x000103BD
		// (set) Token: 0x06001B30 RID: 6960 RVA: 0x000103C5 File Offset: 0x000103C5
		public Func<float, Color> ColorFromProportion { get; set; } = (float p) => LiveTracingOptions.ColorFromArgbLerp(Color.FromArgb(0, 80, 180), Color.Red, p);

		// Token: 0x06001B31 RID: 6961 RVA: 0x000D1BA0 File Offset: 0x000D1BA0
		private static GraphicsPath MakeRoundedRect(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			checked
			{
				int num = Math.Max(1, radius * 2);
				if (rect.Width < num || rect.Height < num)
				{
					graphicsPath.AddRectangle(rect);
					return graphicsPath;
				}
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x06001B32 RID: 6962 RVA: 0x000D1C6C File Offset: 0x000D1C6C
		private static Color ColorFromArgbLerp(Color a, Color b, float p)
		{
			p = Math.Max(0f, Math.Min(1f, p));
			return checked(Color.FromArgb((int)(unchecked((float)a.R + (float)(checked(b.R - a.R)) * p)), (int)(unchecked((float)a.G + (float)(checked(b.G - a.G)) * p)), (int)(unchecked((float)a.B + (float)(checked(b.B - a.B)) * p))));
		}
	}
}
