﻿using System;

namespace HondaMapEditorPro
{
	// Token: 0x0200085A RID: 2138
	internal static class Glyphs
	{
		// Token: 0x04001E6E RID: 7790
		public const string Folder = "\ud83d\udcc1";

		// Token: 0x04001E6F RID: 7791
		public const string File = "\ud83d\udcc4";

		// Token: 0x04001E70 RID: 7792
		public const string OpenXdf = "\ud83d\udcc2";

		// Token: 0x04001E71 RID: 7793
		public const string Bin = "\ud83d\udcbe";

		// Token: 0x04001E72 RID: 7794
		public const string Bug = "\ud83d\udc1b";

		// Token: 0x04001E73 RID: 7795
		public const string Chart2D = "\ud83d\udcc8";

		// Token: 0x04001E74 RID: 7796
		public const string Chart3D = "\ud83d\udcca";

		// Token: 0x04001E75 RID: 7797
		public const string Pin = "\ud83d\udccd";

		// Token: 0x04001E76 RID: 7798
		public const string Warn = "⚠";

		// Token: 0x04001E77 RID: 7799
		public const string Bolt = "⚡";

		// Token: 0x04001E78 RID: 7800
		public const string Check = "✔";

		// Token: 0x04001E79 RID: 7801
		public const string Close = "✕";

		// Token: 0x04001E7A RID: 7802
		public const string Arrow = "→";

		// Token: 0x04001E7B RID: 7803
		public const string Dot = "●";

		// Token: 0x04001E7C RID: 7804
		public const string Triangle = "▸";
	}
}
