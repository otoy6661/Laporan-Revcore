﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace HondaMapEditorPro
{
	// Token: 0x0200087D RID: 2173
	public class RoundedButton : Button
	{
		// Token: 0x17000174 RID: 372
		// (get) Token: 0x060018A4 RID: 6308 RVA: 0x0000F005 File Offset: 0x0000F005
		// (set) Token: 0x060018A5 RID: 6309 RVA: 0x0000F00D File Offset: 0x0000F00D
		public int CornerRadius { get; set; }

		// Token: 0x17000175 RID: 373
		// (get) Token: 0x060018A6 RID: 6310 RVA: 0x0000F016 File Offset: 0x0000F016
		// (set) Token: 0x060018A7 RID: 6311 RVA: 0x0000F01E File Offset: 0x0000F01E
		public Color BorderColor { get; set; }

		// Token: 0x17000176 RID: 374
		// (get) Token: 0x060018A8 RID: 6312 RVA: 0x0000F027 File Offset: 0x0000F027
		// (set) Token: 0x060018A9 RID: 6313 RVA: 0x0000F02F File Offset: 0x0000F02F
		public float BorderWidth { get; set; }

		// Token: 0x17000177 RID: 375
		// (get) Token: 0x060018AA RID: 6314 RVA: 0x0000F038 File Offset: 0x0000F038
		// (set) Token: 0x060018AB RID: 6315 RVA: 0x0000F040 File Offset: 0x0000F040
		public Color HoverBackColor { get; set; }

		// Token: 0x060018AC RID: 6316 RVA: 0x0000F049 File Offset: 0x0000F049
		public RoundedButton()
		{
			base.FlatStyle = FlatStyle.Flat;
			base.FlatAppearance.BorderSize = 0;
			this.DoubleBuffered = true;
		}

		// Token: 0x060018AD RID: 6317 RVA: 0x000C3628 File Offset: 0x000C3628
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(checked(new Rectangle(0, 0, base.Width - 1, base.Height - 1)), (float)this.CornerRadius))
			{
				using (SolidBrush solidBrush = new SolidBrush(this._isHovering ? this.HoverBackColor : this.BackColor))
				{
					e.Graphics.FillPath(solidBrush, graphicsPath);
				}
				using (Pen pen = new Pen(this.BorderColor, this.BorderWidth))
				{
					e.Graphics.DrawPath(pen, graphicsPath);
				}
			}
			TextRenderer.DrawText(e.Graphics, this.Text, this.Font, base.ClientRectangle, this.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
		}

		// Token: 0x060018AE RID: 6318 RVA: 0x0000F06B File Offset: 0x0000F06B
		protected override void OnMouseEnter(EventArgs e)
		{
			base.OnMouseEnter(e);
			this._isHovering = true;
			base.Invalidate();
		}

		// Token: 0x060018AF RID: 6319 RVA: 0x0000F081 File Offset: 0x0000F081
		protected override void OnMouseLeave(EventArgs e)
		{
			base.OnMouseLeave(e);
			this._isHovering = false;
			base.Invalidate();
		}

		// Token: 0x04001EB7 RID: 7863
		private bool _isHovering;
	}
}
