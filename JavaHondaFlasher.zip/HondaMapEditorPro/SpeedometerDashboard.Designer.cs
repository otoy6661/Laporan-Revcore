﻿namespace HondaMapEditorPro
{
	// Token: 0x02000963 RID: 2403
	public partial class SpeedometerDashboard : global::System.Windows.Forms.Form
	{
	}
}
