﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using FTD2XX_NET;
using Honda_Flash_Tools.Net;
using Plot3D;
using _3D_Chart_Graph;

namespace HondaMapEditorPro
{
	// Token: 0x020007FE RID: 2046
	public partial class MapEditorForm : Form
	{
		// Token: 0x06001521 RID: 5409 RVA: 0x0009EC28 File Offset: 0x0009EC28
		public MapEditorForm()
		{
			this._port = new SerialPort();
			this.tek10 = true;
			this.tek11 = true;
			this.tek13 = true;
			this.tek16 = true;
			this.tek17 = true;
			this.tek20 = true;
			this._rx = new byte[512];
			this.rightPanelLastWidth = 200;
			this.allProfiles = new List<XdfProfile>();
			this.editedTables = new Dictionary<string, bool>();
			this.undoStack = new Stack<byte[]>();
			this.redoStack = new Stack<byte[]>();
			this.minValue = double.MaxValue;
			this.maxValue = double.MinValue;
			this.bgDark = Color.FromArgb(10, 15, 20);
			this.bgPanel = Color.FromArgb(16, 23, 30);
			this.bgCard = Color.FromArgb(20, 28, 36);
			this.cyan = Color.FromArgb(0, 255, 230);
			this.cyanDark = Color.FromArgb(0, 180, 160);
			this.green = Color.FromArgb(0, 255, 150);
			this.purpleXdf = Color.FromArgb(180, 100, 255);
			this.fg = Color.FromArgb(225, 238, 245);
			this.muted = Color.FromArgb(135, 158, 174);
			this.danger = Color.FromArgb(255, 90, 105);
			this.border = Color.FromArgb(30, 45, 60);
			this.orange3D = Color.FromArgb(255, 165, 0);
			this.blue2D = Color.FromArgb(0, 150, 255);
			this.gold = Color.FromArgb(255, 200, 0);
			this.liveRpmValues = new List<double>();
			this.liveColValues = new List<double>();
			this.liveInitialCellValues = new Dictionary<ValueTuple<int, int>, double>();
			this.livePortName = "0";
			this.liveBaudRate = 10400;
			this.liveProtocol = MapEditorForm.LiveProtocol.HondaKLine;
			this.InitializeComponent();
			typeof(DataGridView).InvokeMember("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.SetProperty, null, this.dgvMap, new object[]
			{
				true
			});
			base.KeyDown += this.MapEditorForm_KeyDown;
			base.FormClosing += this.MapEditorForm_FormClosing;
			this.TryAutoLoadXdf();
			this.SetupGridCopyPaste();
			this.AttachLiveOverlayAndGridHook();
			this.dgvMap.Paint += this.DgvMap_CustomPopup_Paint;
			this.dgvMap.CellMouseEnter += delegate(object s, DataGridViewCellEventArgs e)
			{
				this._hoveredRow = e.RowIndex;
				this._hoveredCol = e.ColumnIndex;
				this.dgvMap.Invalidate();
			};
			this.dgvMap.CellMouseLeave += delegate(object s, DataGridViewCellEventArgs e)
			{
				this._hoveredRow = -1;
				this._hoveredCol = -1;
				this.dgvMap.Invalidate();
			};
			this.dgvMap.MouseLeave += delegate(object s, EventArgs e)
			{
				this._hoveredRow = -1;
				this._hoveredCol = -1;
				this.dgvMap.Invalidate();
			};
		}

		// Token: 0x06001523 RID: 5411 RVA: 0x0009F1B8 File Offset: 0x0009F1B8
		private void TryAutoLoadXdf()
		{
			try
			{
				string[] files = Directory.GetFiles(Application.StartupPath, "*.xdf");
				if (files.Length == 0)
				{
					if (this.lblStatus != null)
					{
						this.lblStatus.Text = "⚠ Belum ada XDF — klik \ud83d\udcc2 OPEN XDF.";
					}
					if (this.lblTreeFooter != null)
					{
						this.lblTreeFooter.Text = "▸  [Kompatible Ecu : —]";
					}
				}
				else
				{
					string text = null;
					foreach (string text2 in files)
					{
						if (Path.GetFileName(text2).Equals("profile.xdf", StringComparison.OrdinalIgnoreCase) && MapEditorForm.IsRealXdfFile(text2))
						{
							text = text2;
							break;
						}
					}
					if (text == null)
					{
						foreach (string text3 in files)
						{
							if (MapEditorForm.IsRealXdfFile(text3))
							{
								text = text3;
								break;
							}
						}
					}
					if (text != null)
					{
						this.LoadXdf(text, true);
					}
					else if (this.lblStatus != null)
					{
						this.lblStatus.Text = "⚠ Tidak ada file .xdf valid (XML / hex-dump XDF).";
					}
				}
			}
			catch (Exception ex)
			{
				if (this.lblStatus != null)
				{
					this.lblStatus.Text = "⚠ Auto-load XDF gagal: " + ex.Message;
				}
			}
		}

		// Token: 0x06001524 RID: 5412 RVA: 0x0008EF50 File Offset: 0x0008EF50
		private static GraphicsPath CreateRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			if (rect.Width <= 0 || rect.Height <= 0)
			{
				return graphicsPath;
			}
			checked
			{
				int num = radius * 2;
				if (num > rect.Width)
				{
					num = rect.Width;
				}
				if (num > rect.Height)
				{
					num = rect.Height;
				}
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x06001525 RID: 5413 RVA: 0x0009F2D0 File Offset: 0x0009F2D0
		private void MapEditorForm_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Control && e.KeyCode == Keys.D2)
			{
				this.Open2DBreakpoint();
				e.Handled = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.D3)
			{
				this.Open3DGraph();
				e.Handled = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.D)
			{
				this.ToggleRightPanel();
				e.Handled = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.H)
			{
				this.ToggleRightPanel();
				e.Handled = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.T)
			{
				this.ToggleSwapAxes();
				e.Handled = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.Z)
			{
				this.DoUndo();
				e.Handled = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.Y)
			{
				this.DoRedo();
				e.Handled = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.K)
			{
				this.OpenCompareDialog();
				e.Handled = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.B)
			{
				this.OpenSelectCompareBins();
				e.Handled = true;
				return;
			}
		}

		// Token: 0x06001526 RID: 5414 RVA: 0x0009F400 File Offset: 0x0009F400
		private Button CreateWindowButton(string text, int x, int y, Color accent, Color hover)
		{
			Button b = new Button
			{
				Text = text,
				Size = new Size(32, 28),
				Location = new Point(x, y),
				FlatStyle = FlatStyle.Flat,
				BackColor = Color.Transparent,
				ForeColor = accent,
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				Cursor = Cursors.Hand,
				TabStop = false
			};
			b.FlatAppearance.BorderSize = 0;
			b.FlatAppearance.MouseOverBackColor = Color.Transparent;
			b.FlatAppearance.MouseDownBackColor = Color.Transparent;
			b.Paint += delegate(object s, PaintEventArgs ev)
			{
				Button button = (Button)s;
				ev.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				using (GraphicsPath graphicsPath = MapEditorForm.CreateRoundedPath(checked(new Rectangle(0, 0, button.Width - 1, button.Height - 1)), 6))
				{
					using (Pen pen = new Pen(button.ForeColor, 0.7f))
					{
						ev.Graphics.DrawPath(pen, graphicsPath);
					}
				}
				TextRenderer.DrawText(ev.Graphics, button.Text, button.Font, button.ClientRectangle, button.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			};
			b.MouseEnter += delegate(object s, EventArgs ev)
			{
				b.ForeColor = hover;
				b.Invalidate();
			};
			b.MouseLeave += delegate(object s, EventArgs ev)
			{
				b.ForeColor = accent;
				b.Invalidate();
			};
			return b;
		}

		// Token: 0x06001527 RID: 5415 RVA: 0x0000D5CD File Offset: 0x0000D5CD
		private void TitleBar_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button != MouseButtons.Left)
			{
				return;
			}
			this.dragging = true;
			this.dragStart = Cursor.Position;
			this.formStart = base.Location;
		}

		// Token: 0x06001528 RID: 5416 RVA: 0x0009F530 File Offset: 0x0009F530
		private void TitleBar_MouseMove(object sender, MouseEventArgs e)
		{
			if (!this.dragging)
			{
				return;
			}
			Point position = Cursor.Position;
			base.Location = checked(new Point(this.formStart.X + position.X - this.dragStart.X, this.formStart.Y + position.Y - this.dragStart.Y));
		}

		// Token: 0x06001529 RID: 5417 RVA: 0x0000D5FB File Offset: 0x0000D5FB
		private void TitleBar_MouseUp(object sender, MouseEventArgs e)
		{
			this.dragging = false;
		}

		// Token: 0x0600152A RID: 5418 RVA: 0x0009F598 File Offset: 0x0009F598
		private void BtnOpenXdf_Click(object sender, EventArgs e)
		{
			using (OpenFileDialog openFileDialog = new OpenFileDialog
			{
				Filter = "XDF Definition (*.xdf;*.txt)|*.xdf;*.txt|All Files (*.*)|*.*",
				Title = "Pilih file XDF"
			})
			{
				if (openFileDialog.ShowDialog(this) == DialogResult.OK)
				{
					this.LoadXdf(openFileDialog.FileName, false);
					if (this.binData != null && this.currentProfile != null)
					{
						this.LoadMapView();
					}
				}
			}
		}

		// Token: 0x0600152B RID: 5419 RVA: 0x0009F60C File Offset: 0x0009F60C
		private void LoadXdf(string xdfPath, bool silent)
		{
			string text = null;
			try
			{
				string xdfPath2 = xdfPath;
				if (HexDumpHelper.LooksLikeHexDump(xdfPath))
				{
					byte[] array = HexDumpHelper.DecodeHexDump(xdfPath);
					if (HexDumpHelper.IsXmlPayload(array))
					{
						text = Path.Combine(Path.GetTempPath(), "xdf_decoded_" + Guid.NewGuid().ToString("N") + ".xdf");
						File.WriteAllBytes(text, array);
						xdfPath2 = text;
					}
					else if (!silent)
					{
						MapEditorForm.CustomMessageBox.Show(this, "File terlihat hex-dump tapi tidak mengandung XML XDF valid.", "XDF Invalid", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						return;
					}
				}
				XdfDefinition xdfDefinition = XdfLoader.Parse(xdfPath2);
				this.ApplyAddressOverrides(xdfDefinition);
				if (xdfDefinition.Tables.Count == 0)
				{
					if (!silent)
					{
						MapEditorForm.CustomMessageBox.Show(this, "XDF tidak punya XDFTABLE yang valid.", "XDF Kosong", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
				else
				{
					List<XdfProfile> list = XdfLoader.ToProfiles(xdfDefinition, xdfPath);
					if (list.Count == 0)
					{
						if (!silent)
						{
							MapEditorForm.CustomMessageBox.Show(this, "Gagal konversi XDF → profile.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
					}
					else
					{
						this.loadedXdf = xdfDefinition;
						this.loadedXdfPath = xdfPath;
						this.allProfiles.Clear();
						this.allProfiles.AddRange(list);
						this.cmbProfiles.SelectedIndexChanged -= this.CmbProfiles_SelectedIndexChanged;
						this.cmbProfiles.DataSource = null;
						this.cmbProfiles.DisplayMember = "Name";
						this.cmbProfiles.ValueMember = null;
						this.cmbProfiles.DataSource = this.allProfiles;
						this.cmbProfiles.SelectedIndexChanged += this.CmbProfiles_SelectedIndexChanged;
						this.RebuildTree();
						if (this.allProfiles.Count > 0)
						{
							this.cmbProfiles.SelectedIndex = 0;
						}
						if (this.lblStatus != null)
						{
							this.lblStatus.Text = string.Concat(new object[]
							{
								"\ud83d\udcc2 XDF: ",
								Path.GetFileName(xdfPath),
								" → ",
								xdfDefinition.Tables.Count,
								" tabel | ",
								xdfDefinition.Title
							});
						}
						this.UpdateTreeFooter();
						if (this.binData != null && this.currentProfile != null)
						{
							this.LoadMapView();
						}
						else
						{
							this.Request3DSync();
						}
						if (!silent)
						{
							long num = 0L;
							try
							{
								num = new FileInfo(xdfPath).Length;
							}
							catch
							{
							}
							MapEditorForm.CustomMessageBox.Show(this, string.Concat(new string[]
							{
								"✅ XDF berhasil dimuat\n\nNama file     : ",
								Path.GetFileName(xdfPath),
								"\nUkuran         : ",
								num.ToString("N0"),
								" bytes\nJudul XDF     : ",
								string.IsNullOrEmpty(xdfDefinition.Title) ? "(tanpa judul)" : xdfDefinition.Title,
								"\nJumlah tabel : ",
								xdfDefinition.Tables.Count.ToString("N0")
							}), "XDF Loaded", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
				}
			}
			catch (Exception ex)
			{
				try
				{
					File.AppendAllText(Path.Combine(Path.GetDirectoryName(xdfPath) ?? ".", "xdf_load_error.log"), string.Format("[{0:yyyy-MM-dd HH:mm:ss}] {1}\n{2}\n\n", DateTime.Now, xdfPath, ex));
				}
				catch
				{
				}
				if (!silent)
				{
					MapEditorForm.CustomMessageBox.Show(this, "Gagal parse XDF:\n\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			finally
			{
				try
				{
					if (text != null && File.Exists(text))
					{
						File.Delete(text);
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x0600152C RID: 5420 RVA: 0x0009F9C0 File Offset: 0x0009F9C0
		private void SelectProfile(XdfProfile prof)
		{
			if (prof == null)
			{
				return;
			}
			int num = this.allProfiles.IndexOf(prof);
			if (num >= 0)
			{
				if (this.cmbProfiles.SelectedIndex != num)
				{
					this.cmbProfiles.SelectedIndex = num;
					return;
				}
				this.CmbProfiles_SelectedIndexChanged(this.cmbProfiles, EventArgs.Empty);
				return;
			}
			else
			{
				this.currentProfile = prof;
				this.UpdatePropertiesPanel(prof.Table);
				if (prof.Table != null)
				{
					this.lblMapTitle.Text = "\ud83d\uddfa  " + prof.Table.Title + " — 2D MAP TABLE";
				}
				if (this.binData != null)
				{
					this.LoadMapView();
					return;
				}
				this.SetStatus("\ud83d\udccc Tabel dipilih. Klik \ud83d\udcbe OPEN BIN untuk mulai edit.");
				return;
			}
		}

		// Token: 0x0600152D RID: 5421 RVA: 0x0009FA6C File Offset: 0x0009FA6C
		private void CmbProfiles_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.currentProfile = (this.cmbProfiles.SelectedItem as XdfProfile);
			if (this.currentProfile == null)
			{
				return;
			}
			XdfTable table = this.currentProfile.Table;
			if (table == null)
			{
				return;
			}
			this.swapAxes = false;
			if (this.btnSwapAxes != null)
			{
				this.btnSwapAxes.Text = "\ud83d\udd04 SWAP X/Y";
				this.btnSwapAxes.Invalidate();
			}
			this.lblMapTitle.Text = "\ud83d\uddfa  " + table.Title + " — " + (this.is1DView ? "1D TABLE" : "2D MAP TABLE");
			this.UpdatePropertiesPanel(table);
			if (this.lblStatus != null)
			{
				this.lblStatus.Text = string.Concat(new object[]
				{
					"\ud83d\udccc [",
					table.Category,
					"] ",
					table.Title,
					"  |  Addr: 0x",
					table.Address.ToString("X"),
					"  |  Grid: ",
					table.Rows,
					"×",
					table.Cols
				});
			}
			if (this.binData != null)
			{
				this.LoadMapView();
			}
			if (this.treeViewMaps != null && this.treeViewMaps.Nodes.Count > 0)
			{
				TreeNode treeNode = this.FindNodeByProfile(this.treeViewMaps.Nodes[0], this.currentProfile);
				if (treeNode != null && this.treeViewMaps.SelectedNode != treeNode)
				{
					this.treeViewMaps.SelectedNode = treeNode;
					if (this.binData != null)
					{
						this.LoadMapView();
					}
					if (this.isLiveDataRunning)
					{
						this.BuildLiveAxisCache();
					}
				}
			}
		}

		// Token: 0x0600152E RID: 5422 RVA: 0x0009FC1C File Offset: 0x0009FC1C
		private void BtnDebug_Click(object sender, EventArgs e)
		{
			if (this.loadedXdf == null)
			{
				MapEditorForm.CustomMessageBox.Show(this, "Load XDF dulu!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("XDF: " + this.loadedXdf.Title + " v" + this.loadedXdf.Version);
			stringBuilder.AppendLine("FilePath: " + this.loadedXdf.FilePath);
			stringBuilder.AppendLine("BinSize: " + this.loadedXdf.BinSize.ToString("N0", CultureInfo.InvariantCulture));
			stringBuilder.AppendLine("Tables: " + this.loadedXdf.Tables.Count);
			stringBuilder.AppendLine(new string('-', 70));
			foreach (XdfTable xdfTable in this.loadedXdf.Tables)
			{
				stringBuilder.AppendLine("▸ " + xdfTable.Title);
				stringBuilder.AppendLine(string.Concat(new object[]
				{
					"   Address  : 0x",
					xdfTable.Address.ToString("X"),
					" (",
					xdfTable.Address,
					")"
				}));
				stringBuilder.AppendLine(string.Concat(new object[]
				{
					"   Grid     : ",
					xdfTable.Rows,
					" × ",
					xdfTable.Cols
				}));
				stringBuilder.AppendLine("   ElemSize : " + checked(xdfTable.ElementSize * 8) + "-bit");
				stringBuilder.AppendLine("   Swapped  : " + xdfTable.IsSwapped.ToString());
				stringBuilder.AppendLine("   Signed   : " + xdfTable.IsSigned.ToString());
				stringBuilder.AppendLine("   Float    : " + xdfTable.IsFloat.ToString());
				stringBuilder.AppendLine("   Scale    : " + xdfTable.Scale.ToString("F6", CultureInfo.InvariantCulture));
				stringBuilder.AppendLine("   Equation : " + xdfTable.MathEquation);
				stringBuilder.AppendLine("   PreferRpmOnTop : " + xdfTable.PreferRpmOnTop.ToString());
				stringBuilder.AppendLine(string.Concat(new object[]
				{
					"   XAxis    : 0x",
					xdfTable.XAxisAddress.ToString("X"),
					"  Count=",
					xdfTable.XAxisCount,
					"  Link=",
					xdfTable.XAxisLinkId ?? "-"
				}));
				stringBuilder.AppendLine(string.Concat(new object[]
				{
					"   YAxis    : 0x",
					xdfTable.YAxisAddress.ToString("X"),
					"  Count=",
					xdfTable.YAxisCount,
					"  Link=",
					xdfTable.YAxisLinkId ?? "-"
				}));
				stringBuilder.AppendLine();
			}
			using (Form form = new Form())
			{
				form.Text = "XDF Debug — " + this.loadedXdf.Title;
				form.Size = new Size(780, 600);
				form.StartPosition = FormStartPosition.CenterParent;
				form.BackColor = this.bgCard;
				form.ForeColor = this.cyan;
				form.Controls.Add(new TextBox
				{
					Multiline = true,
					ReadOnly = true,
					ScrollBars = ScrollBars.Both,
					Dock = DockStyle.Fill,
					BackColor = this.bgPanel,
					ForeColor = this.cyan,
					Font = new Font("Consolas", 8.5f),
					WordWrap = false,
					Text = stringBuilder.ToString()
				});
				form.ShowDialog(this);
			}
		}

		// Token: 0x0600152F RID: 5423 RVA: 0x000A0094 File Offset: 0x000A0094
		private void BtnOpenBin_Click(object sender, EventArgs e)
		{
			using (OpenFileDialog openFileDialog = new OpenFileDialog
			{
				Filter = "BIN/ROM Files (*.bin;*.rom;*.txt)|*.bin;*.rom;*.txt|All Files (*.*)|*.*"
			})
			{
				if (openFileDialog.ShowDialog(this) == DialogResult.OK)
				{
					byte[] array;
					try
					{
						if (HexDumpHelper.LooksLikeHexDump(openFileDialog.FileName))
						{
							array = HexDumpHelper.DecodeHexDump(openFileDialog.FileName);
							if (array.Length < 16)
							{
								MapEditorForm.CustomMessageBox.Show(this, "File hex-dump BIN terlalu pendek / tidak valid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
								return;
							}
						}
						else
						{
							array = File.ReadAllBytes(openFileDialog.FileName);
						}
					}
					catch (Exception ex)
					{
						MapEditorForm.CustomMessageBox.Show(this, "Gagal load BIN:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						return;
					}
					this.binData = array;
					this.originalBinData = (byte[])array.Clone();
					this.binFilePath = openFileDialog.FileName;
					this.undoStack.Clear();
					this.redoStack.Clear();
					this.swapAxes = false;
					if (this.btnSwapAxes != null)
					{
						this.btnSwapAxes.Text = "\ud83d\udd04 SWAP X/Y";
						this.btnSwapAxes.Invalidate();
					}
					MapEditorForm.CustomMessageBox.Show(this, string.Concat(new string[]
					{
						"✅ BIN berhasil dimuat\n\nNama file : ",
						Path.GetFileName(this.binFilePath),
						"\nUkuran    : ",
						this.binData.Length.ToString("N0"),
						" bytes"
					}), "BIN Loaded", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					this.SetStatus(string.Concat(new string[]
					{
						"Ready  •  Edit Mode: Relative  •  Step: ±1  •  File: ",
						Path.GetFileName(this.binFilePath),
						"  •  Size: ",
						this.binData.Length.ToString("N0"),
						" bytes"
					}));
					if (this.currentProfile == null)
					{
						this.dgvMap.Rows.Clear();
						this.dgvMap.Columns.Clear();
					}
					else
					{
						this.LoadMapView();
					}
					this.Request3DSync();
				}
			}
		}

		// Token: 0x06001530 RID: 5424 RVA: 0x000A02AC File Offset: 0x000A02AC
		private void BtnSaveBin_Click(object sender, EventArgs e)
		{
			if (this.binData == null)
			{
				MapEditorForm.CustomMessageBox.Show(this, "Belum ada BIN yang dimuat.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
			using (SaveFileDialog saveFileDialog = new SaveFileDialog
			{
				Filter = "BIN Files (*.bin)|*.bin|All Files (*.*)|*.*",
				FileName = "modified_" + Path.GetFileName(this.binFilePath ?? "map.bin")
			})
			{
				if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
				{
					try
					{
						File.WriteAllBytes(saveFileDialog.FileName, this.binData);
						this.lblStatus.Text = "\ud83d\udcbe SAVED: " + saveFileDialog.FileName;
						this.hasUnsavedChanges = false;
						MapEditorForm.CustomMessageBox.Show(this, "BIN berhasil disimpan:\n" + saveFileDialog.FileName, "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					catch (Exception ex)
					{
						MapEditorForm.CustomMessageBox.Show(this, "Gagal save:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
			}
		}

		// Token: 0x06001531 RID: 5425 RVA: 0x000A03B4 File Offset: 0x000A03B4
		private void LoadMapView()
		{
			try
			{
				if (this.binData != null)
				{
					if (this.currentProfile == null)
					{
						this.dgvMap.Rows.Clear();
						this.dgvMap.Columns.Clear();
					}
					else
					{
						XdfTable table = this.currentProfile.Table;
						if (table != null)
						{
							this.suppress3DSync = true;
							this.dgvMap.Rows.Clear();
							this.dgvMap.Columns.Clear();
							this.minValue = double.MaxValue;
							this.maxValue = double.MinValue;
							this.is1DView = false;
							this.currentBaseAddress = table.Address;
							this.currentRows = table.Rows;
							this.currentCols = table.Cols;
							long num = checked(unchecked((long)table.Rows) * unchecked((long)table.Cols) * unchecked((long)Math.Max(1, table.ElementSize)));
							if (table.Address <= 0 || table.Address >= this.binData.Length || (num > 0L && checked(unchecked((long)table.Address) + num) > (long)this.binData.Length))
							{
								if (this.lblStatus != null)
								{
									this.lblStatus.Text = string.Format("⚠ Alamat tabel tidak valid! 0x{0:X} (size {1} byte) vs BIN {2} byte", table.Address, num, this.binData.Length);
								}
								this.suppress3DSync = false;
							}
							else
							{
								if (table.Rows == 1 && table.Cols > 1)
								{
									this.Render1DTable(table, false);
								}
								else if (table.Cols == 1 && table.Rows > 1)
								{
									this.Render1DTable(table, true);
								}
								else if (table.Rows == 1 && table.Cols == 1)
								{
									this.RenderSingleValue(table);
								}
								else
								{
									this.RenderGrid(table);
								}
								try
								{
									this.ClearAllYellowGridHighlights();
									if (this.preview3DGraph != null && !this.preview3DGraph.IsDisposed)
									{
										this.preview3DGraph.ClearSelection();
									}
									if (this.graph3DForm != null && !this.graph3DForm.IsDisposed)
									{
										Plot3D.Graph3D graph3DControl = this.graph3DForm.Graph3DControl;
										if (graph3DControl != null && !graph3DControl.IsDisposed)
										{
											graph3DControl.ClearSelection();
										}
									}
								}
								catch
								{
								}
								this.suppress3DSync = false;
								if (this.xRuler != null)
								{
									this.xRuler.Invalidate();
								}
								if (this.yRuler != null)
								{
									this.yRuler.Invalidate();
								}
								this.UpdateHexView();
								this.UpdateCursorLabel();
								this.SyncSelectionTo3DGraph();
								if (this.graph3DForm != null && !this.graph3DForm.IsDisposed && !this.is1DView)
								{
									this.Sync3DGraph();
									this.graph3DForm.Text = "Graph 3D — " + this.currentProfile.Name;
								}
								this.Request3DSync();
								try
								{
									base.BeginInvoke(new Action(delegate()
									{
										this.Request3DSync();
									}));
								}
								catch
								{
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				this.suppress3DSync = false;
				if (this.lblStatus != null)
				{
					this.lblStatus.Text = "⚠ Error: " + ex.Message;
				}
				MessageBox.Show(this, "Gagal render map:\n\n" + ex.GetType().Name + ": " + ex.Message, "Error LoadMapView", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x06001532 RID: 5426 RVA: 0x000A0714 File Offset: 0x000A0714
		private void RenderSingleValue(XdfTable t)
		{
			this.dgvMap.Columns.Add("Value", "Value");
			double num = this.ReadValueAt(t.Address);
			this.dgvMap.Rows.Add(new object[]
			{
				MapEditorForm.FmtSmart(num)
			});
			this.minValue = num - 1.0;
			this.maxValue = num + 1.0;
		}

		// Token: 0x06001533 RID: 5427 RVA: 0x000A078C File Offset: 0x000A078C
		private void Render1DTable(XdfTable t, bool isRowAxis)
		{
			this.is1DView = true;
			int num = isRowAxis ? t.Rows : t.Cols;
			this.dgvMap.Columns.Add("Index", "Index");
			this.dgvMap.Columns.Add("Value", "Value");
			checked
			{
				for (int i = 0; i < num; i++)
				{
					int num2 = t.Address + i * t.ElementSize;
					if (num2 + t.ElementSize > this.binData.Length)
					{
						break;
					}
					double raw = this.ReadRaw(num2, t.ElementSize, t.IsSwapped, t.IsFloat, t.IsSigned);
					double num3 = MapEditorForm.EvalMathEquation(t.MathEquation, raw);
					this.dgvMap.Rows.Add(new object[]
					{
						i + 1,
						MapEditorForm.FmtSmart(num3)
					});
					if (num3 < this.minValue)
					{
						this.minValue = num3;
					}
					if (num3 > this.maxValue)
					{
						this.maxValue = num3;
					}
				}
				if (this.minValue == this.maxValue)
				{
					this.minValue = 0.0;
					this.maxValue = 1.0;
				}
			}
		}

		// Token: 0x06001534 RID: 5428 RVA: 0x000A08CC File Offset: 0x000A08CC
		private void RenderGrid(XdfTable t)
		{
			if (t.Rows <= 0 || t.Cols <= 0)
			{
				return;
			}
			checked
			{
				long num = unchecked((long)t.Rows) * unchecked((long)t.Cols) * unchecked((long)t.ElementSize);
				if (unchecked((long)t.Address) + num > unchecked((long)this.binData.Length))
				{
					return;
				}
				int rows = t.Rows;
				int cols = t.Cols;
				double[] array = this.ReadAxis(t.YAxisAddress, t.YAxisElementSize, t.YAxisScale, t.YAxisOffset, rows);
				double[] array2 = this.ReadAxis(t.XAxisAddress, t.XAxisElementSize, t.XAxisScale, t.XAxisOffset, cols);
				if (!this.IsMonotonic(array))
				{
					double[] array3 = this.FindDonorAxis(rows, false);
					if (array3 != null)
					{
						array = array3;
					}
				}
				if (!this.IsMonotonic(array2))
				{
					double[] array4 = this.FindDonorAxis(cols, true);
					if (array4 != null)
					{
						array2 = array4;
					}
				}
				bool flag = t.PreferRpmOnTop ^ this.swapAxes;
				int num2 = flag ? cols : rows;
				int num3 = flag ? rows : cols;
				string text = "0";
				string text2 = "0.0";
				double[] array5 = flag ? array2 : array;
				double[] array6 = flag ? array : array2;
				string format = flag ? text2 : text;
				string format2 = flag ? text : text2;
				for (int i = 0; i < num3; i++)
				{
					this.dgvMap.Columns.Add("C" + i, array6[i].ToString(format2, CultureInfo.InvariantCulture));
				}
				for (int j = 0; j < num2; j++)
				{
					this.dgvMap.Rows.Add();
					this.dgvMap.Rows[j].HeaderCell.Value = array5[j].ToString(format, CultureInfo.InvariantCulture);
					for (int k = 0; k < num3; k++)
					{
						int num4 = flag ? k : j;
						int num5 = flag ? j : k;
						int num6 = t.Address + (num4 * cols + num5) * t.ElementSize;
						if (num6 >= 0 && num6 + t.ElementSize <= this.binData.Length)
						{
							double raw = this.ReadRaw(num6, t.ElementSize, t.IsSwapped, t.IsFloat, t.IsSigned);
							double num7 = MapEditorForm.EvalMathEquation(t.MathEquation, raw);
							this.dgvMap[k, j].Value = ((Math.Abs(num7) >= 100.0) ? ((long)Math.Round(num7)).ToString(CultureInfo.InvariantCulture) : num7.ToString("F2", CultureInfo.InvariantCulture));
							if (num7 < this.minValue)
							{
								this.minValue = num7;
							}
							if (num7 > this.maxValue)
							{
								this.maxValue = num7;
							}
						}
					}
				}
				if (this.minValue == this.maxValue)
				{
					this.minValue = 0.0;
					this.maxValue = 1.0;
				}
				this.dgvMap.Refresh();
			}
		}

		// Token: 0x06001535 RID: 5429 RVA: 0x000A0BE0 File Offset: 0x000A0BE0
		private void DgvMap_CellValueChanged(object sender, DataGridViewCellEventArgs e)
		{
			if (this.isLiveDataRunning)
			{
				return;
			}
			if (e == null || e.RowIndex < 0 || e.ColumnIndex < 0)
			{
				return;
			}
			if (this.dgvMap == null || this.binData == null || this.currentProfile == null)
			{
				return;
			}
			XdfTable table = this.currentProfile.Table;
			if (table == null || table.ElementSize <= 0)
			{
				return;
			}
			if (e.RowIndex >= this.dgvMap.Rows.Count || e.ColumnIndex >= this.dgvMap.Columns.Count)
			{
				return;
			}
			if (this.dgvMap.Rows[e.RowIndex].IsNewRow)
			{
				return;
			}
			if (this.is1DView && e.ColumnIndex == 0)
			{
				return;
			}
			object value = this.dgvMap[e.ColumnIndex, e.RowIndex].Value;
			if (value == null || value == DBNull.Value)
			{
				return;
			}
			string text = value.ToString().Trim();
			if (text.Length == 0)
			{
				return;
			}
			double num;
			if (!double.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out num) && !double.TryParse(text, NumberStyles.Any, CultureInfo.CurrentCulture, out num))
			{
				return;
			}
			if (double.IsNaN(num) || double.IsInfinity(num))
			{
				return;
			}
			checked
			{
				int num2;
				if (this.is1DView)
				{
					num2 = table.Address + e.RowIndex * table.ElementSize;
				}
				else
				{
					num2 = this.VisualToByteAddress(table, e.RowIndex, e.ColumnIndex);
				}
				if (this.is1DView && e.ColumnIndex != 1)
				{
					return;
				}
				if (num2 < 0 || num2 > this.binData.Length - table.ElementSize)
				{
					return;
				}
				if (!this.suppress3DSync)
				{
					try
					{
						this.undoStack.Push((byte[])this.binData.Clone());
						this.redoStack.Clear();
					}
					catch
					{
					}
				}
				double value2 = MapEditorForm.SolveRawForEquation(table.MathEquation, num);
				this.WriteRaw(num2, table.ElementSize, table.IsSwapped, table.IsFloat, value2);
				this.hasUnsavedChanges = true;
				if (!this.suppress3DSync && !this.is1DView && this.graph3DForm != null && !this.graph3DForm.IsDisposed)
				{
					try
					{
						this.suppress3DSync = true;
						this.Sync3DGraph();
					}
					catch
					{
					}
					finally
					{
						this.suppress3DSync = false;
					}
				}
				this.Sync3DPreviewFromGrid();
				if ((DateTime.Now - this._lastGraph3DHexUpdate).TotalMilliseconds >= 125.0)
				{
					this._lastGraph3DHexUpdate = DateTime.Now;
					this.UpdateHexView();
					this.UpdateCursorLabel();
				}
			}
		}

		// Token: 0x06001536 RID: 5430 RVA: 0x000A0E84 File Offset: 0x000A0E84
		private void DgvMap_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			if (e.RowIndex < 0 || e.ColumnIndex < 0)
			{
				return;
			}
			if (this.is1DView && e.ColumnIndex == 0)
			{
				return;
			}
			if (e.Value == null)
			{
				return;
			}
			DataGridViewCell dataGridViewCell = this.dgvMap.Rows[e.RowIndex].Cells[e.ColumnIndex];
			string a;
			if (dataGridViewCell != null && (a = (dataGridViewCell.Tag as string)) != null && a == "3D_SELECTED_YELLOW")
			{
				e.CellStyle.BackColor = Color.Yellow;
				e.CellStyle.ForeColor = Color.Black;
				e.CellStyle.SelectionBackColor = Color.Yellow;
				e.CellStyle.SelectionForeColor = Color.Black;
				return;
			}
			if (this.isLiveDataRunning && this.livePointerVisible && e.RowIndex == this.livePointerRow && e.ColumnIndex == this.livePointerCol)
			{
				e.CellStyle.BackColor = Color.Yellow;
				e.CellStyle.ForeColor = Color.Black;
				e.CellStyle.SelectionBackColor = Color.Yellow;
				e.CellStyle.SelectionForeColor = Color.Black;
				return;
			}
			double num;
			if (!double.TryParse(e.Value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out num))
			{
				return;
			}
			double num2 = this.maxValue - this.minValue;
			if (num2 <= 0.0)
			{
				num2 = 1.0;
			}
			float p = (float)((num - this.minValue) / num2);
			e.CellStyle.BackColor = this.ColorFromProportion(p);
			e.CellStyle.ForeColor = Color.Black;
			e.CellStyle.SelectionBackColor = Color.Yellow;
			e.CellStyle.SelectionForeColor = Color.Black;
		}

		// Token: 0x06001537 RID: 5431 RVA: 0x000A1048 File Offset: 0x000A1048
		private Color ColorFromProportion(float p)
		{
			p = Math.Max(0f, Math.Min(1f, p));
			Color[] array = new Color[]
			{
				Color.Blue,
				Color.Aqua,
				Color.FromArgb(0, 255, 0),
				Color.Yellow,
				Color.Orange,
				Color.Red
			};
			checked
			{
				float num = 1f / (float)(array.Length - 1);
				int num2 = (int)(p / num);
				if (num2 >= array.Length - 1)
				{
					num2 = array.Length - 2;
				}
				int num3 = Math.Min(num2 + 1, array.Length - 1);
				float num4 = unchecked(p - (float)num2 * num) / num;
				int red = (int)(unchecked((float)array[num2].R * (1f - num4) + (float)array[num3].R * num4));
				int num5 = (int)(unchecked((float)array[num2].G * (1f - num4) + (float)array[num3].G * num4));
				int blue = (int)(unchecked((float)array[num2].B * (1f - num4) + (float)array[num3].B * num4));
				return Color.FromArgb(red, num5, blue);
			}
		}

		// Token: 0x06001538 RID: 5432 RVA: 0x000A1180 File Offset: 0x000A1180
		private void BatchEditValues(string operation)
		{
			if (this.dgvMap == null || this.dgvMap.SelectedCells.Count == 0)
			{
				return;
			}
			string text = (operation == "add") ? "Tambah nilai:" : ((operation == "sub") ? "Kurangi nilai:" : ((operation == "mul") ? "Persentase (%):" : "Isi dengan nilai:"));
			this._batchInput = 0.0;
			this._batchOk = false;
			double batchInput;
			checked
			{
				using (MapEditorForm.BufferedForm popup = new MapEditorForm.BufferedForm())
				{
					popup.FormBorderStyle = FormBorderStyle.None;
					popup.StartPosition = FormStartPosition.CenterParent;
					popup.BackColor = this.bgDark;
					popup.Width = 320;
					popup.Height = 175;
					popup.ShowInTaskbar = false;
					popup.Padding = new Padding(2);
					popup.HandleCreated += delegate(object s, EventArgs ev)
					{
						if (popup.Width <= 0 || popup.Height <= 0)
						{
							return;
						}
						using (GraphicsPath graphicsPath = MapEditorForm.CreateRoundedPath(new Rectangle(0, 0, popup.Width, popup.Height), 14))
						{
							Region region = popup.Region;
							popup.Region = new Region(graphicsPath);
							if (region != null)
							{
								region.Dispose();
							}
						}
					};
					popup.Resize += delegate(object s, EventArgs ev)
					{
						if (popup.Width <= 0 || popup.Height <= 0)
						{
							return;
						}
						using (GraphicsPath graphicsPath = MapEditorForm.CreateRoundedPath(new Rectangle(0, 0, popup.Width, popup.Height), 14))
						{
							Region region = popup.Region;
							popup.Region = new Region(graphicsPath);
							if (region != null)
							{
								region.Dispose();
							}
						}
					};
					popup.Paint += delegate(object s, PaintEventArgs ev)
					{
						ev.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
						if (popup.Width < 5 || popup.Height < 5)
						{
							return;
						}
						using (GraphicsPath graphicsPath = MapEditorForm.CreateRoundedPath(new Rectangle(2, 2, popup.Width - 5, popup.Height - 5), 14))
						{
							using (Pen pen = new Pen(Color.FromArgb(25, 0, 255, 230), 8f))
							{
								using (Pen pen2 = new Pen(Color.FromArgb(60, 0, 255, 230), 5f))
								{
									using (Pen pen3 = new Pen(Color.FromArgb(120, 0, 255, 230), 2f))
									{
										using (Pen pen4 = new Pen(this.cyan, 1.2f))
										{
											ev.Graphics.DrawPath(pen, graphicsPath);
											ev.Graphics.DrawPath(pen2, graphicsPath);
											ev.Graphics.DrawPath(pen3, graphicsPath);
											ev.Graphics.DrawPath(pen4, graphicsPath);
										}
									}
								}
							}
						}
					};
					Label label = new Label
					{
						Text = "INPUT VALUE",
						ForeColor = this.cyan,
						Font = new Font("Segoe UI", 9f, FontStyle.Bold),
						Location = new Point(16, 10),
						AutoSize = true,
						BackColor = Color.Transparent
					};
					popup.Controls.Add(label);
					Button button = new Button
					{
						Text = "X",
						Size = new Size(26, 24),
						Location = new Point(popup.Width - 42, 8),
						FlatStyle = FlatStyle.Flat,
						BackColor = Color.Transparent,
						ForeColor = this.danger,
						Font = new Font("Segoe UI", 9f, FontStyle.Bold),
						Cursor = Cursors.Hand,
						TabStop = false
					};
					button.FlatAppearance.BorderSize = 0;
					button.FlatAppearance.MouseOverBackColor = Color.Transparent;
					button.FlatAppearance.MouseDownBackColor = Color.Transparent;
					button.Click += delegate(object s, EventArgs ev)
					{
						this._batchOk = false;
						popup.DialogResult = DialogResult.Cancel;
						popup.Close();
					};
					popup.Controls.Add(button);
					Panel panel = new Panel
					{
						BackColor = Color.FromArgb(120, this.cyan),
						Location = new Point(16, 34),
						Size = new Size(popup.Width - 32, 1)
					};
					popup.Controls.Add(panel);
					Label value = new Label
					{
						Text = text,
						ForeColor = this.fg,
						BackColor = Color.Transparent,
						Location = new Point(16, 46),
						Width = popup.Width - 32,
						Font = new Font("Segoe UI", 9f)
					};
					popup.Controls.Add(value);
					TextBox txt = new TextBox
					{
						Location = new Point(16, 72),
						Width = popup.Width - 32,
						BackColor = this.bgPanel,
						ForeColor = this.cyan,
						BorderStyle = BorderStyle.FixedSingle,
						Font = new Font("Consolas", 11f, FontStyle.Bold),
						TextAlign = HorizontalAlignment.Center
					};
					popup.Controls.Add(txt);
					int y = 112;
					int num = 138;
					int height = 32;
					Button ok = this.MakeNeonPopupButton("OK", DialogResult.OK, new Point(16, y), new Size(num, height), this.cyan);
					Button cancel = this.MakeNeonPopupButton("CANCEL", DialogResult.Cancel, new Point(popup.Width - 16 - num, y), new Size(num, height), this.muted);
					bool localDrag = false;
					Point localStart = Point.Empty;
					Point localForm = Point.Empty;
					EventHandler startDrag = delegate(object s, EventArgs ev)
					{
						localDrag = true;
						localStart = Cursor.Position;
						localForm = popup.Location;
					};
					MouseEventHandler value2 = delegate(object s, MouseEventArgs ev)
					{
						if (!localDrag)
						{
							return;
						}
						Point position = Cursor.Position;
						popup.Location = new Point(localForm.X + position.X - localStart.X, localForm.Y + position.Y - localStart.Y);
					};
					MouseEventHandler value3 = delegate(object s, MouseEventArgs ev)
					{
						localDrag = false;
					};
					label.MouseDown += delegate(object s, MouseEventArgs ev)
					{
						startDrag(s, ev);
					};
					label.MouseMove += value2;
					label.MouseUp += value3;
					panel.MouseDown += delegate(object s, MouseEventArgs ev)
					{
						startDrag(s, ev);
					};
					panel.MouseMove += value2;
					panel.MouseUp += value3;
					ok.Click += delegate(object s, EventArgs ev)
					{
						double batchInput2;
						if (double.TryParse(txt.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out batchInput2) || double.TryParse(txt.Text, NumberStyles.Float, CultureInfo.CurrentCulture, out batchInput2))
						{
							this._batchInput = batchInput2;
							this._batchOk = true;
							popup.DialogResult = DialogResult.OK;
							popup.Close();
							return;
						}
						txt.BackColor = Color.FromArgb(80, 20, 25);
						txt.ForeColor = Color.White;
					};
					cancel.Click += delegate(object s, EventArgs ev)
					{
						this._batchOk = false;
						popup.DialogResult = DialogResult.Cancel;
						popup.Close();
					};
					popup.Controls.Add(ok);
					popup.Controls.Add(cancel);
					popup.KeyPreview = true;
					popup.KeyDown += delegate(object s, KeyEventArgs ev)
					{
						if (ev.KeyCode == Keys.Return)
						{
							ok.PerformClick();
							return;
						}
						if (ev.KeyCode == Keys.Escape)
						{
							cancel.PerformClick();
						}
					};
					txt.Focus();
					if (popup.ShowDialog(this) != DialogResult.OK || !this._batchOk)
					{
						return;
					}
					batchInput = this._batchInput;
					try
					{
						this.undoStack.Push((byte[])this.binData.Clone());
						this.redoStack.Clear();
					}
					catch
					{
					}
				}
			}
			try
			{
				this.suppress3DSync = true;
				foreach (object obj in this.dgvMap.SelectedCells)
				{
					DataGridViewCell dataGridViewCell = (DataGridViewCell)obj;
					if (dataGridViewCell != null && dataGridViewCell.RowIndex >= 0 && dataGridViewCell.ColumnIndex >= 0 && !dataGridViewCell.ReadOnly && (!this.is1DView || dataGridViewCell.ColumnIndex != 0))
					{
						object value4 = dataGridViewCell.Value;
						double num2;
						if (double.TryParse((value4 != null) ? value4.ToString() : null, NumberStyles.Float, CultureInfo.InvariantCulture, out num2))
						{
							double v;
							if (operation == "add")
							{
								v = num2 + batchInput;
							}
							else if (operation == "sub")
							{
								v = num2 - batchInput;
							}
							else if (operation == "mul")
							{
								v = num2 * (1.0 + batchInput / 100.0);
							}
							else if (operation == "fill")
							{
								v = batchInput;
							}
							else
							{
								v = num2;
							}
							dataGridViewCell.Value = MapEditorForm.FmtSmart(v);
						}
					}
				}
			}
			finally
			{
				this.suppress3DSync = false;
			}
			try
			{
				this.CommitGridToBinData();
			}
			catch
			{
			}
			if (this.graph3DForm != null && !this.graph3DForm.IsDisposed && !this.is1DView)
			{
				try
				{
					this.Sync3DGraph();
				}
				catch
				{
				}
			}
			this.Sync3DPreviewFromGrid();
			this.UpdateHexView();
			this.hasUnsavedChanges = true;
		}

		// Token: 0x06001539 RID: 5433 RVA: 0x000A19F0 File Offset: 0x000A19F0
		private double ReadRaw(int offset, int size, bool swapped, bool isFloat, bool isSigned)
		{
			checked
			{
				if (offset < 0 || size <= 0 || offset + size > this.binData.Length)
				{
					return 0.0;
				}
				if (isFloat && size == 4)
				{
					byte[] array = new byte[4];
					Array.Copy(this.binData, offset, array, 0, 4);
					if (swapped)
					{
						Array.Reverse(array);
					}
					return (double)BitConverter.ToSingle(array, 0);
				}
				ulong num = 0UL;
				if (swapped)
				{
					for (int i = 0; i < size; i++)
					{
						num = (num << 8 | unchecked((ulong)this.binData[checked(offset + i)]));
					}
				}
				else
				{
					for (int j = size - 1; j >= 0; j--)
					{
						num = (num << 8 | unchecked((ulong)this.binData[checked(offset + j)]));
					}
				}
				ulong num2 = (size >= 8) ? ulong.MaxValue : ((1UL << size * 8) - 1UL);
				num &= num2;
				if (!isSigned)
				{
					return num;
				}
				int num3 = size * 8;
				ulong num4 = 1UL << num3 - 1;
				if ((num & num4) != 0UL)
				{
					return (double)((long)(num | ~num2));
				}
				return num;
			}
		}

		// Token: 0x0600153A RID: 5434 RVA: 0x000A1ADC File Offset: 0x000A1ADC
		private void WriteRaw(int offset, int size, bool swapped, bool isFloat, double value)
		{
			checked
			{
				if (offset < 0 || size <= 0 || offset + size > this.binData.Length)
				{
					return;
				}
				if (isFloat && size == 4)
				{
					byte[] bytes = BitConverter.GetBytes((float)value);
					if (swapped)
					{
						Array.Reverse(bytes);
					}
					Array.Copy(bytes, 0, this.binData, offset, 4);
					return;
				}
				ulong num = (size >= 8) ? ulong.MaxValue : ((1UL << size * 8) - 1UL);
				ulong num2 = (ulong)((value < 0.0) ? ((long)value & (long)num) : ((long)((ulong)value & num)));
				if (swapped)
				{
					for (int i = 0; i < size; i++)
					{
						this.binData[offset + i] = (byte)(num2 >> 8 * (size - 1 - i) & 255UL);
					}
					return;
				}
				for (int j = 0; j < size; j++)
				{
					this.binData[offset + j] = (byte)(num2 >> 8 * j & 255UL);
				}
			}
		}

		// Token: 0x0600153B RID: 5435 RVA: 0x000A1BB8 File Offset: 0x000A1BB8
		private double ReadValueAt(int address)
		{
			if (this.currentProfile == null)
			{
				return 0.0;
			}
			XdfTable table = this.currentProfile.Table;
			double raw = this.ReadRaw(address, table.ElementSize, table.IsSwapped, table.IsFloat, table.IsSigned);
			return MapEditorForm.EvalMathEquation(table.MathEquation, raw);
		}

		// Token: 0x0600153C RID: 5436 RVA: 0x000A1C10 File Offset: 0x000A1C10
		private void MapEditorForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (MapEditorForm.ForceCloseWithoutPrompt)
			{
				try
				{
					this.StopLiveChartTimer();
				}
				catch
				{
				}
				try
				{
					if (this._liveChart != null && !this._liveChart.IsDisposed)
					{
						this._liveChart.Close();
					}
				}
				catch
				{
				}
				try
				{
					if (this._speedDashboard != null && !this._speedDashboard.IsDisposed)
					{
						this._speedDashboard.Close();
					}
				}
				catch
				{
				}
				try
				{
					if (this.graph3DForm != null && !this.graph3DForm.IsDisposed)
					{
						this.graph3DForm.Close();
					}
				}
				catch
				{
				}
				try
				{
					if (this.graph2DForm != null && !this.graph2DForm.IsDisposed)
					{
						this.graph2DForm.Close();
					}
				}
				catch
				{
				}
				try
				{
					if (this.compareForm != null && !this.compareForm.IsDisposed)
					{
						this.compareForm.Close();
					}
				}
				catch
				{
				}
				return;
			}
			if (!this.hasUnsavedChanges)
			{
				try
				{
					this.StopLiveChartTimer();
				}
				catch
				{
				}
				try
				{
					if (this._liveChart != null && !this._liveChart.IsDisposed)
					{
						this._liveChart.Close();
					}
				}
				catch
				{
				}
				try
				{
					if (this._speedDashboard != null && !this._speedDashboard.IsDisposed)
					{
						this._speedDashboard.Close();
					}
				}
				catch
				{
				}
				try
				{
					if (this.graph3DForm != null && !this.graph3DForm.IsDisposed)
					{
						this.graph3DForm.Close();
					}
				}
				catch
				{
				}
				try
				{
					if (this.graph2DForm != null && !this.graph2DForm.IsDisposed)
					{
						this.graph2DForm.Close();
					}
				}
				catch
				{
				}
				try
				{
					if (this.compareForm != null && !this.compareForm.IsDisposed)
					{
						this.compareForm.Close();
					}
				}
				catch
				{
				}
				return;
			}
			if (this.hasUnsavedChanges && !e.Cancel && MapEditorForm.CustomMessageBox.Show(this, "Ada perubahan yang belum disimpan ke disk.\n\nYakin ingin menutup?", "Unsaved Changes", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
			{
				e.Cancel = true;
				return;
			}
			try
			{
				this.StopLiveChartTimer();
			}
			catch
			{
			}
			try
			{
				if (this._liveChart != null && !this._liveChart.IsDisposed)
				{
					this._liveChart.Close();
				}
			}
			catch
			{
			}
			try
			{
				if (this._speedDashboard != null && !this._speedDashboard.IsDisposed)
				{
					this._speedDashboard.Close();
				}
			}
			catch
			{
			}
			try
			{
				if (this.graph3DForm != null && !this.graph3DForm.IsDisposed)
				{
					this.graph3DForm.Close();
				}
			}
			catch
			{
			}
			try
			{
				if (this.graph2DForm != null && !this.graph2DForm.IsDisposed)
				{
					this.graph2DForm.Close();
				}
			}
			catch
			{
			}
			try
			{
				if (this.compareForm != null && !this.compareForm.IsDisposed)
				{
					this.compareForm.Close();
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600153D RID: 5437 RVA: 0x000A1F9C File Offset: 0x000A1F9C
		private void Open3DGraph()
		{
			if (this.binData == null || this.currentProfile == null || this.is1DView)
			{
				return;
			}
			if (this.dgvMap == null || this.dgvMap.Rows.Count == 0)
			{
				return;
			}
			if (this.currentProfile.Table == null)
			{
				return;
			}
			try
			{
				string text = "Graph 3D — " + this.currentProfile.Name;
				if (this.graph3DForm == null || this.graph3DForm.IsDisposed)
				{
					this.graph3DForm = new Plot3D.Graph3DMainForm
					{
						Text = text
					};
					this.graph3DForm.FormClosed += delegate(object s, FormClosedEventArgs ev)
					{
						try
						{
							if (this.graph3DForm != null)
							{
								this.graph3DForm.PointValueChanged -= this.Graph3DForm_PointValueChanged;
							}
						}
						catch
						{
						}
						this.graph3DForm = null;
					};
					this.graph3DForm.Show(this);
					this.graph3DForm.PointValueChanged += this.Graph3DForm_PointValueChanged;
					Plot3D.Graph3D graph3DControl = this.graph3DForm.Graph3DControl;
					if (graph3DControl != null)
					{
						graph3DControl.SelectionChangedInGraph -= this.Graph3D_SelectionChanged;
						graph3DControl.SelectionChangedInGraph += this.Graph3D_SelectionChanged;
					}
				}
				else
				{
					this.graph3DForm.Text = text;
					try
					{
						this.graph3DForm.PointValueChanged -= this.Graph3DForm_PointValueChanged;
					}
					catch
					{
					}
					this.graph3DForm.PointValueChanged += this.Graph3DForm_PointValueChanged;
					Plot3D.Graph3D graph3DControl2 = this.graph3DForm.Graph3DControl;
					if (graph3DControl2 != null)
					{
						graph3DControl2.SelectionChangedInGraph -= this.Graph3D_SelectionChanged;
						graph3DControl2.SelectionChangedInGraph += this.Graph3D_SelectionChanged;
					}
				}
				Plot3D.Graph3D graph3DControl3 = this.graph3DForm.Graph3DControl;
				if (graph3DControl3 != null && !graph3DControl3.IsDisposed)
				{
					graph3DControl3.ShowPoints = false;
					graph3DControl3.ShowWireframe = false;
					graph3DControl3.Raster = Plot3D.Graph3D.eRaster.Off;
					graph3DControl3.DragSensitivity = 0.05;
					graph3DControl3.EnableEditMode(true);
					graph3DControl3.AllowDrag = true;
					graph3DControl3.AllowRotate = true;
					graph3DControl3.AllowZoom = true;
					this.PushGridToGraph3D(graph3DControl3);
					graph3DControl3.Invalidate();
				}
				this.graph3DForm.Activate();
				this.graph3DForm.BringToFront();
				this.SyncSelectionTo3DGraph();
			}
			catch (Exception ex)
			{
				MapEditorForm.CustomMessageBox.Show(this, "Gagal buka 3D:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x0600153E RID: 5438 RVA: 0x000A21EC File Offset: 0x000A21EC
		private void Sync3DGraph()
		{
			if (this.graph3DForm == null || this.graph3DForm.IsDisposed)
			{
				return;
			}
			if (this.dgvMap == null || this.dgvMap.Rows.Count == 0)
			{
				return;
			}
			try
			{
				Plot3D.Graph3D graph3DControl = this.graph3DForm.Graph3DControl;
				if (graph3DControl != null && !graph3DControl.IsDisposed)
				{
					this.PushGridToGraph3D(graph3DControl);
					graph3DControl.Invalidate();
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600153F RID: 5439 RVA: 0x000026F4 File Offset: 0x000026F4
		private void ApplyAddressOverrides(XdfDefinition def)
		{
		}

		// Token: 0x06001540 RID: 5440 RVA: 0x000A2264 File Offset: 0x000A2264
		private void BtnSaveEdit_Click(object sender, EventArgs e)
		{
			if (this.binData == null || this.dgvMap.Rows.Count == 0)
			{
				return;
			}
			this.dgvMap.EndEdit();
			try
			{
				try
				{
					this.undoStack.Push((byte[])this.binData.Clone());
					this.redoStack.Clear();
				}
				catch
				{
				}
				this.CommitGridToBinData();
				this.hasUnsavedChanges = true;
				MapEditorForm.CustomMessageBox.Show(this, "Perubahan sementara disimpan di memori.\nGunakan SAVE BIN untuk save ke disk.", "SAVE EDIT", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			catch (Exception ex)
			{
				MapEditorForm.CustomMessageBox.Show(this, "Error:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x06001541 RID: 5441 RVA: 0x000A2324 File Offset: 0x000A2324
		private void CommitGridToBinData()
		{
			if (this.binData == null || this.currentProfile == null || this.currentProfile.Table == null)
			{
				return;
			}
			XdfTable table = this.currentProfile.Table;
			checked
			{
				if (this.is1DView)
				{
					for (int i = 0; i < this.dgvMap.Rows.Count; i++)
					{
						int num = table.Address + i * table.ElementSize;
						if (num >= 0 && num + table.ElementSize <= this.binData.Length)
						{
							object value = this.dgvMap[1, i].Value;
							double target;
							if (value != null && double.TryParse(value.ToString(), NumberStyles.Float, CultureInfo.InvariantCulture, out target))
							{
								double value2 = MapEditorForm.SolveRawForEquation(table.MathEquation, target);
								this.WriteRaw(num, table.ElementSize, table.IsSwapped, table.IsFloat, value2);
							}
						}
					}
					return;
				}
				for (int j = 0; j < this.dgvMap.Rows.Count; j++)
				{
					for (int k = 0; k < this.dgvMap.Columns.Count; k++)
					{
						int num2 = this.VisualToByteAddress(table, j, k);
						if (num2 >= 0 && num2 + table.ElementSize <= this.binData.Length)
						{
							object value3 = this.dgvMap[k, j].Value;
							double target2;
							if (value3 != null && double.TryParse(value3.ToString(), NumberStyles.Float, CultureInfo.InvariantCulture, out target2))
							{
								double value4 = MapEditorForm.SolveRawForEquation(table.MathEquation, target2);
								this.WriteRaw(num2, table.ElementSize, table.IsSwapped, table.IsFloat, value4);
							}
						}
					}
				}
			}
		}

		// Token: 0x06001542 RID: 5442 RVA: 0x000A24D8 File Offset: 0x000A24D8
		private Button MakeNeonButton(string text, int x, int y, int w, int h, Color accent, Color glow)
		{
			Button b = new Button
			{
				Text = text,
				Location = new Point(x, y),
				Size = new Size(w, h),
				FlatStyle = FlatStyle.Flat,
				BackColor = this.bgCard,
				ForeColor = accent,
				Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
				Cursor = Cursors.Hand,
				UseVisualStyleBackColor = false
			};
			b.FlatAppearance.BorderSize = 0;
			b.FlatAppearance.MouseOverBackColor = Color.Transparent;
			b.FlatAppearance.MouseDownBackColor = Color.Transparent;
			b.Paint += delegate(object s, PaintEventArgs ev)
			{
				Button button = (Button)s;
				ev.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				using (GraphicsPath graphicsPath = this.RoundedRect(checked(new Rectangle(0, 0, button.Width - 1, button.Height - 1)), 10))
				{
					using (SolidBrush solidBrush = new SolidBrush(button.BackColor))
					{
						ev.Graphics.FillPath(solidBrush, graphicsPath);
						using (Pen pen = new Pen(accent, 1.6f))
						{
							ev.Graphics.DrawPath(pen, graphicsPath);
						}
					}
				}
				TextRenderer.DrawText(ev.Graphics, button.Text, button.Font, button.ClientRectangle, button.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			};
			b.MouseEnter += delegate(object s, EventArgs ev)
			{
				b.ForeColor = Color.White;
				b.Invalidate();
			};
			b.MouseLeave += delegate(object s, EventArgs ev)
			{
				b.ForeColor = accent;
				b.Invalidate();
			};
			return b;
		}

		// Token: 0x06001543 RID: 5443 RVA: 0x0000D604 File Offset: 0x0000D604
		private GraphicsPath RoundedRect(Rectangle b, int r)
		{
			return MapEditorForm.CreateRoundedPath(b, r);
		}

		// Token: 0x06001544 RID: 5444 RVA: 0x0000D60D File Offset: 0x0000D60D
		private static GraphicsPath RoundedPath(Rectangle r, int rad)
		{
			return MapEditorForm.CreateRoundedPath(r, rad);
		}

		// Token: 0x06001545 RID: 5445 RVA: 0x000A25F8 File Offset: 0x000A25F8
		private Button MakeNeonPopupButton(string text, DialogResult result, Point location, Size size, Color accent)
		{
			Button b = new Button
			{
				Text = text,
				DialogResult = result,
				Location = location,
				Size = size,
				FlatStyle = FlatStyle.Flat,
				BackColor = this.bgCard,
				ForeColor = accent,
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				Cursor = Cursors.Hand,
				UseVisualStyleBackColor = false
			};
			b.FlatAppearance.BorderSize = 0;
			b.FlatAppearance.MouseOverBackColor = Color.Transparent;
			b.FlatAppearance.MouseDownBackColor = Color.Transparent;
			b.Paint += delegate(object s, PaintEventArgs ev)
			{
				Button button = (Button)s;
				ev.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				using (GraphicsPath graphicsPath = MapEditorForm.RoundedPath(checked(new Rectangle(0, 0, button.Width - 1, button.Height - 1)), 8))
				{
					using (SolidBrush solidBrush = new SolidBrush(button.BackColor))
					{
						ev.Graphics.FillPath(solidBrush, graphicsPath);
						using (Pen pen = new Pen(accent, 1.4f))
						{
							ev.Graphics.DrawPath(pen, graphicsPath);
						}
					}
				}
				TextRenderer.DrawText(ev.Graphics, button.Text, button.Font, button.ClientRectangle, button.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			};
			b.MouseEnter += delegate(object s, EventArgs ev)
			{
				b.ForeColor = Color.White;
				b.Invalidate();
			};
			b.MouseLeave += delegate(object s, EventArgs ev)
			{
				b.ForeColor = accent;
				b.Invalidate();
			};
			return b;
		}

		// Token: 0x06001546 RID: 5446 RVA: 0x000A2708 File Offset: 0x000A2708
		private void SetupGridCopyPaste()
		{
			this.dgvMap.MultiSelect = true;
			this.dgvMap.SelectionMode = DataGridViewSelectionMode.CellSelect;
			this.dgvMap.ReadOnly = false;
			this.dgvMap.EditMode = DataGridViewEditMode.EditOnEnter;
			this.dgvMap.ClipboardCopyMode = DataGridViewClipboardCopyMode.Disable;
			this.dgvMap.KeyDown -= this.DgvMap_KeyDown_CopyPaste;
			this.dgvMap.KeyDown += this.DgvMap_KeyDown_CopyPaste;
			this._gridContextMenu = new ContextMenuStrip();
			this._gridContextMenu.Items.Add("Copy", null, delegate(object s, EventArgs ev)
			{
				this.CopySelectedCellsToClipboard();
			});
			this._gridContextMenu.Items.Add("Paste", null, delegate(object s, EventArgs ev)
			{
				this.PasteFromClipboard();
			});
			this._gridContextMenu.Items.Add("Fill Selected", null, delegate(object s, EventArgs ev)
			{
				this.BatchEditValues("fill");
			});
			this._gridContextMenu.Items.Add("Interpolate", null, delegate(object s, EventArgs ev)
			{
				this.BatchInterpolate();
			});
			this._gridContextMenu.Items.Add("Smooth", null, delegate(object s, EventArgs ev)
			{
				this.BatchSmooth();
			});
			this.dgvMap.ContextMenuStrip = this._gridContextMenu;
			this.dgvMap.MouseDown -= this.DgvMap_MouseDown_TrackBlock;
			this.dgvMap.MouseDown += this.DgvMap_MouseDown_TrackBlock;
			this.dgvMap.MouseMove -= this.DgvMap_MouseMove_TrackBlock;
			this.dgvMap.MouseMove += this.DgvMap_MouseMove_TrackBlock;
			this.dgvMap.MouseUp -= this.DgvMap_MouseUp_TrackBlock;
			this.dgvMap.MouseUp += this.DgvMap_MouseUp_TrackBlock;
		}

		// Token: 0x06001547 RID: 5447 RVA: 0x000A28D4 File Offset: 0x000A28D4
		private TreeNode FindNodeByProfile(TreeNode parent, XdfProfile target)
		{
			if (parent == null || target == null)
			{
				return null;
			}
			if (parent.Tag is XdfProfile && parent.Tag == target)
			{
				return parent;
			}
			foreach (object obj in parent.Nodes)
			{
				TreeNode treeNode = this.FindNodeByProfile((TreeNode)obj, target);
				if (treeNode != null)
				{
					return treeNode;
				}
			}
			return null;
		}

		// Token: 0x06001548 RID: 5448 RVA: 0x000A295C File Offset: 0x000A295C
		private void UpdateHexView()
		{
			if (this.binData == null || this.dgvMap == null || this.dgvMap.SelectedCells.Count == 0)
			{
				return;
			}
			if (this.currentProfile == null || this.currentProfile.Table == null)
			{
				return;
			}
			if (this.hexBox == null || this.hexBox.IsDisposed)
			{
				return;
			}
			XdfTable table = this.currentProfile.Table;
			DataGridViewCell dataGridViewCell = this.dgvMap.SelectedCells[0];
			checked
			{
				int num;
				if (this.is1DView)
				{
					num = table.Address + dataGridViewCell.RowIndex * table.ElementSize;
				}
				else
				{
					num = this.VisualToByteAddress(table, dataGridViewCell.RowIndex, dataGridViewCell.ColumnIndex);
				}
				if (num < 0 || num >= this.binData.Length)
				{
					return;
				}
				int num2 = Math.Max(1, table.ElementSize);
				int num3 = Math.Min(num + num2, this.binData.Length);
				int num4 = num & -16;
				if (num4 < 0)
				{
					num4 = 0;
				}
				StringBuilder stringBuilder = new StringBuilder();
				for (int i = 0; i < 8; i++)
				{
					int num5 = num4 + i * 16;
					if (num5 >= this.binData.Length)
					{
						break;
					}
					stringBuilder.Append(num5.ToString("X8")).Append(": ");
					for (int j = 0; j < 16; j++)
					{
						int num6 = num5 + j;
						if (num6 >= this.binData.Length)
						{
							stringBuilder.Append("   ");
						}
						else
						{
							bool flag = num6 >= num && num6 < num3;
							byte b = this.binData[num6];
							if (flag)
							{
								stringBuilder.Append('[').Append(b.ToString("X2")).Append(']');
							}
							else
							{
								stringBuilder.Append(b.ToString("X2")).Append(' ');
							}
						}
					}
					stringBuilder.Append(" | ");
					for (int k = 0; k < 16; k++)
					{
						int num7 = num5 + k;
						if (num7 >= this.binData.Length)
						{
							stringBuilder.Append(' ');
						}
						else
						{
							byte b2 = this.binData[num7];
							stringBuilder.Append((char)((b2 >= 32 && b2 < 127) ? b2 : 46));
						}
					}
					stringBuilder.AppendLine();
				}
				this.hexBox.Text = stringBuilder.ToString();
				string text = this.BuildRawHexString(num, num2);
				string text2 = "—";
				string text3 = "—";
				try
				{
					double num8 = this.ReadRaw(num, num2, table.IsSwapped, table.IsFloat, table.IsSigned);
					double num9 = MapEditorForm.EvalMathEquation(table.MathEquation, num8);
					text2 = (table.IsFloat ? num8.ToString("0.######", CultureInfo.InvariantCulture) : ((long)Math.Round(num8)).ToString(CultureInfo.InvariantCulture));
					text3 = ((Math.Abs(num9) >= 100.0) ? ((long)Math.Round(num9)).ToString(CultureInfo.InvariantCulture) : num9.ToString("0.####", CultureInfo.InvariantCulture));
				}
				catch
				{
				}
				this.hexFooter.Text = string.Concat(new object[]
				{
					"Addr: 0x",
					num.ToString("X6"),
					"  •  Size: ",
					num2,
					" byte  •  Raw: 0x",
					text,
					"  •  Val: ",
					text2,
					"  •  Scaled: ",
					text3,
					table.IsSwapped ? "  •  [swapped]" : "",
					table.IsSigned ? "  •  [signed]" : "",
					table.IsFloat ? "  •  [float]" : ""
				});
			}
		}

		// Token: 0x06001549 RID: 5449 RVA: 0x000A2D24 File Offset: 0x000A2D24
		private void UpdatePropertiesPanel(XdfTable t)
		{
			if (t == null)
			{
				return;
			}
			this.lblPropName.Text = "Name:      " + (t.Title ?? "—");
			string str = "—";
			try
			{
				if (t.XAxisAddress > 0 || t.YAxisAddress > 0)
				{
					str = "0x" + Math.Max(t.XAxisAddress, t.YAxisAddress).ToString("X");
				}
			}
			catch
			{
			}
			this.lblPropAxis.Text = "Axis:      " + str;
			this.lblPropUnits.Text = "Units:     " + (string.IsNullOrEmpty(t.MathEquation) ? "—" : t.MathEquation);
			this.lblPropSize.Text = string.Concat(new object[]
			{
				"Table Size: ",
				t.Rows,
				" × ",
				t.Cols,
				"\r\nData Type:  ",
				checked(t.ElementSize * 8),
				"-bit"
			});
			if (this.lblMapTitle != null)
			{
				this.lblMapTitle.Text = "\ud83d\uddfa  " + (t.Title ?? "—") + " — " + (this.is1DView ? "1D TABLE" : "2D MAP TABLE");
			}
		}

		// Token: 0x0600154A RID: 5450 RVA: 0x000A2E9C File Offset: 0x000A2E9C
		private void BatchInterpolate()
		{
			if (this.dgvMap == null || this.dgvMap.SelectedCells.Count < 2)
			{
				return;
			}
			if (this.binData == null)
			{
				return;
			}
			int rowIndex = int.MaxValue;
			int rowIndex2 = int.MinValue;
			int columnIndex = int.MaxValue;
			int columnIndex2 = int.MinValue;
			foreach (object obj in this.dgvMap.SelectedCells)
			{
				DataGridViewCell dataGridViewCell = (DataGridViewCell)obj;
				if (dataGridViewCell.RowIndex < rowIndex)
				{
					rowIndex = dataGridViewCell.RowIndex;
				}
				if (dataGridViewCell.RowIndex > rowIndex2)
				{
					rowIndex2 = dataGridViewCell.RowIndex;
				}
				if (dataGridViewCell.ColumnIndex < columnIndex)
				{
					columnIndex = dataGridViewCell.ColumnIndex;
				}
				if (dataGridViewCell.ColumnIndex > columnIndex2)
				{
					columnIndex2 = dataGridViewCell.ColumnIndex;
				}
			}
			if (rowIndex2 == rowIndex && columnIndex2 == columnIndex)
			{
				return;
			}
			double num;
			double num2;
			double num3;
			double num4;
			if (!this.TryCell(columnIndex, rowIndex, out num) || !this.TryCell(columnIndex2, rowIndex, out num2) || !this.TryCell(columnIndex, rowIndex2, out num3) || !this.TryCell(columnIndex2, rowIndex2, out num4))
			{
				return;
			}
			try
			{
				this.undoStack.Push((byte[])this.binData.Clone());
				this.redoStack.Clear();
			}
			catch
			{
			}
			this.suppress3DSync = true;
			checked
			{
				for (int i = rowIndex; i <= rowIndex2; i++)
				{
					for (int j = columnIndex; j <= columnIndex2; j++)
					{
						if ((i != rowIndex || j != columnIndex) && (i != rowIndex2 || j != columnIndex2))
						{
							double num5 = (rowIndex2 == rowIndex) ? 0.0 : ((double)(i - rowIndex) / (double)(rowIndex2 - rowIndex));
							double num6 = (columnIndex2 == columnIndex) ? 0.0 : ((double)(j - columnIndex) / (double)(columnIndex2 - columnIndex));
							double num7 = unchecked((num * (1.0 - num5) + num3 * num5) * (1.0 - num6) + (num2 * (1.0 - num5) + num4 * num5) * num6);
							this.dgvMap[j, i].Value = num7.ToString("F3", CultureInfo.InvariantCulture);
						}
					}
				}
				this.suppress3DSync = false;
				try
				{
					this.CommitGridToBinData();
				}
				catch
				{
				}
				this.Sync3DPreviewFromGrid();
				this.hasUnsavedChanges = true;
			}
		}

		// Token: 0x0600154B RID: 5451 RVA: 0x000A3104 File Offset: 0x000A3104
		private void BatchSmooth()
		{
			if (this.dgvMap == null || this.binData == null)
			{
				return;
			}
			int count = this.dgvMap.Rows.Count;
			int count2 = this.dgvMap.Columns.Count;
			if (count < 3 || count2 < 3)
			{
				return;
			}
			double[,] array = new double[count, count2];
			bool[,] array2 = new bool[count, count2];
			checked
			{
				for (int i = 0; i < count; i++)
				{
					for (int j = 0; j < count2; j++)
					{
						array2[i, j] = this.TryCell(j, i, out array[i, j]);
					}
				}
				try
				{
					this.undoStack.Push((byte[])this.binData.Clone());
					this.redoStack.Clear();
				}
				catch
				{
				}
				this.suppress3DSync = true;
				for (int k = 1; k < count - 1; k++)
				{
					for (int l = 1; l < count2 - 1; l++)
					{
						if (array2[k, l])
						{
							double num = 0.0;
							int num2 = 0;
							for (int m = -1; m <= 1; m++)
							{
								for (int n = -1; n <= 1; n++)
								{
									if (array2[k + m, l + n])
									{
										unchecked
										{
											num += checked(array[k + m, l + n]);
										}
										num2++;
									}
								}
							}
							this.dgvMap[l, k].Value = (num / (double)num2).ToString("F3", CultureInfo.InvariantCulture);
						}
					}
				}
				this.suppress3DSync = false;
				try
				{
					this.CommitGridToBinData();
				}
				catch
				{
				}
				this.Sync3DPreviewFromGrid();
				this.hasUnsavedChanges = true;
			}
		}

		// Token: 0x0600154C RID: 5452 RVA: 0x000A32D0 File Offset: 0x000A32D0
		private void Sync3DPreviewFromGrid()
		{
			if (this.preview3DGraph == null || this.preview3DGraph.IsDisposed)
			{
				return;
			}
			if (this.dgvMap == null || this.dgvMap.Rows.Count == 0 || this.dgvMap.Columns.Count == 0)
			{
				return;
			}
			if (this.is1DView)
			{
				return;
			}
			if (!this.preview3DGraph.IsHandleCreated)
			{
				return;
			}
			if (this.preview3DGraph.ClientSize.Width <= 4 || this.preview3DGraph.ClientSize.Height <= 4)
			{
				return;
			}
			if (!this.preview3DGraph.Visible)
			{
				return;
			}
			try
			{
				this.PushGridToGraph3D(this.preview3DGraph);
				this.preview3DGraph.Invalidate();
			}
			catch
			{
			}
		}

		// Token: 0x0600154D RID: 5453 RVA: 0x000A33A0 File Offset: 0x000A33A0
		private void UpdateCursorLabel()
		{
			if (this.dgvMap == null || this.dgvMap.SelectedCells.Count == 0)
			{
				return;
			}
			DataGridViewCell dataGridViewCell = this.dgvMap.SelectedCells[0];
			string text = (dataGridViewCell.Value == null) ? "—" : dataGridViewCell.Value.ToString();
			double num = double.MaxValue;
			double num2 = double.MinValue;
			double num3 = 0.0;
			int num4 = 0;
			foreach (object obj in this.dgvMap.SelectedCells)
			{
				DataGridViewCell dataGridViewCell2 = (DataGridViewCell)obj;
				double num5;
				if (dataGridViewCell2.Value != null && double.TryParse(dataGridViewCell2.Value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out num5))
				{
					if (num5 < num)
					{
						num = num5;
					}
					if (num5 > num2)
					{
						num2 = num5;
					}
					num3 += num5;
					checked
					{
						num4++;
					}
				}
			}
			this.lblCursor.Text = string.Concat(new object[]
			{
				"Cursor: [R",
				dataGridViewCell.RowIndex,
				", C",
				dataGridViewCell.ColumnIndex,
				"] = ",
				text,
				" | Min: ",
				(num == double.MaxValue) ? "—" : num.ToString("F1", CultureInfo.InvariantCulture),
				" • Max: ",
				(num2 == double.MinValue) ? "—" : num2.ToString("F1", CultureInfo.InvariantCulture),
				" • Avg: ",
				(num4 > 0) ? (num3 / (double)num4).ToString("F1", CultureInfo.InvariantCulture) : "—",
				" • Sum: ",
				num3.ToString("F0", CultureInfo.InvariantCulture)
			});
		}

		// Token: 0x0600154E RID: 5454 RVA: 0x000A35AC File Offset: 0x000A35AC
		private void DoUndo()
		{
			if (this.undoStack == null || this.undoStack.Count == 0)
			{
				this.SetStatus("↶ Tidak ada perubahan untuk di-undo.");
				return;
			}
			if (this.binData != null)
			{
				this.redoStack.Push((byte[])this.binData.Clone());
			}
			this.binData = this.undoStack.Pop();
			this.hasUnsavedChanges = true;
			this.LoadMapView();
			this.SetStatus("↶ Undo. " + this.undoStack.Count + " langkah tersisa.");
		}

		// Token: 0x0600154F RID: 5455 RVA: 0x000A3640 File Offset: 0x000A3640
		private void DoRedo()
		{
			if (this.redoStack == null || this.redoStack.Count == 0)
			{
				this.SetStatus("↷ Tidak ada perubahan untuk di-redo.");
				return;
			}
			if (this.binData != null)
			{
				this.undoStack.Push((byte[])this.binData.Clone());
			}
			this.binData = this.redoStack.Pop();
			this.hasUnsavedChanges = true;
			this.LoadMapView();
			this.SetStatus("↷ Redo. " + this.redoStack.Count + " langkah tersisa.");
		}

		// Token: 0x06001550 RID: 5456 RVA: 0x000A36D4 File Offset: 0x000A36D4
		private void ApplyBatch(string operation, double value)
		{
			if (this.binData == null)
			{
				return;
			}
			try
			{
				this.undoStack.Push((byte[])this.binData.Clone());
				this.redoStack.Clear();
			}
			catch
			{
			}
			try
			{
				this.suppress3DSync = true;
				foreach (object obj in this.dgvMap.SelectedCells)
				{
					DataGridViewCell dataGridViewCell = (DataGridViewCell)obj;
					double num;
					if (dataGridViewCell != null && dataGridViewCell.RowIndex >= 0 && dataGridViewCell.ColumnIndex >= 0 && !dataGridViewCell.ReadOnly && (!this.is1DView || dataGridViewCell.ColumnIndex != 0) && double.TryParse((dataGridViewCell.Value != null) ? dataGridViewCell.Value.ToString() : null, NumberStyles.Float, CultureInfo.InvariantCulture, out num))
					{
						dataGridViewCell.Value = ((operation == "add") ? (num + value) : ((operation == "sub") ? (num - value) : ((operation == "mul") ? (num * (1.0 + value / 100.0)) : value))).ToString("F3", CultureInfo.InvariantCulture);
					}
				}
			}
			finally
			{
				this.suppress3DSync = false;
			}
			try
			{
				this.CommitGridToBinData();
			}
			catch
			{
			}
			if (this.graph3DForm != null && !this.graph3DForm.IsDisposed && !this.is1DView)
			{
				this.Sync3DGraph();
			}
			this.Sync3DPreviewFromGrid();
			this.UpdateHexView();
			this.hasUnsavedChanges = true;
		}

		// Token: 0x06001551 RID: 5457 RVA: 0x000A38D8 File Offset: 0x000A38D8
		private bool TryCell(int c, int r, out double v)
		{
			v = 0.0;
			if (this.dgvMap == null)
			{
				return false;
			}
			if (r < 0 || c < 0 || r >= this.dgvMap.Rows.Count || c >= this.dgvMap.Columns.Count)
			{
				return false;
			}
			object value = this.dgvMap[c, r].Value;
			return value != null && double.TryParse(value.ToString(), NumberStyles.Float, CultureInfo.InvariantCulture, out v);
		}

		// Token: 0x06001552 RID: 5458 RVA: 0x000A3958 File Offset: 0x000A3958
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			if (base.Width <= 0 || base.Height <= 0)
			{
				return;
			}
			using (GraphicsPath graphicsPath = MapEditorForm.CreateRoundedPath(new Rectangle(0, 0, base.Width, base.Height), 10))
			{
				Region region = base.Region;
				base.Region = new Region(graphicsPath);
				if (region != null)
				{
					region.Dispose();
				}
			}
			if (this.mainContent != null)
			{
				this.mainContent.PerformLayout();
			}
			if (this.dgvMap != null)
			{
				this.dgvMap.PerformLayout();
			}
			base.Invalidate();
		}

		// Token: 0x06001553 RID: 5459 RVA: 0x000A3A00 File Offset: 0x000A3A00
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			if (base.Width < 5 || base.Height < 5)
			{
				return;
			}
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			using (GraphicsPath graphicsPath = MapEditorForm.CreateRoundedPath(checked(new Rectangle(2, 2, base.Width - 5, base.Height - 5)), 10))
			{
				using (Pen pen = new Pen(Color.FromArgb(25, 0, 255, 230), 8f))
				{
					using (Pen pen2 = new Pen(Color.FromArgb(60, 0, 255, 230), 5f))
					{
						using (Pen pen3 = new Pen(Color.FromArgb(120, 0, 255, 230), 2f))
						{
							using (Pen pen4 = new Pen(this.cyan, 1.2f))
							{
								e.Graphics.DrawPath(pen, graphicsPath);
								e.Graphics.DrawPath(pen2, graphicsPath);
								e.Graphics.DrawPath(pen3, graphicsPath);
								e.Graphics.DrawPath(pen4, graphicsPath);
							}
						}
					}
				}
			}
		}

		// Token: 0x06001554 RID: 5460 RVA: 0x0000D616 File Offset: 0x0000D616
		private void BatchEditValues(string operation, double value)
		{
			if (this.dgvMap == null || this.dgvMap.SelectedCells.Count == 0)
			{
				return;
			}
			this.ApplyBatch(operation, value);
		}

		// Token: 0x06001555 RID: 5461 RVA: 0x0000D63B File Offset: 0x0000D63B
		private void ShowHelp()
		{
			new HondaMapEditorPro.Form2().Show(this);
		}

		// Token: 0x06001556 RID: 5462 RVA: 0x0000D648 File Offset: 0x0000D648
		private void SetStatus(string text)
		{
			if (this.lblStatus != null)
			{
				this.lblStatus.Text = text;
			}
		}

		// Token: 0x06001557 RID: 5463 RVA: 0x000A3B68 File Offset: 0x000A3B68
		private void Open2DBreakpoint()
		{
			if (this.binData == null || this.currentProfile == null)
			{
				return;
			}
			XdfTable table = this.currentProfile.Table;
			if (table == null)
			{
				return;
			}
			int num;
			int num2;
			int num3;
			bool isSwapped;
			if (this.swapAxes)
			{
				num = table.YAxisAddress;
				num2 = table.Rows;
				num3 = table.YAxisElementSize;
				double yaxisScale = table.YAxisScale;
				double yaxisOffset = table.YAxisOffset;
				isSwapped = table.IsSwapped;
			}
			else
			{
				num = table.XAxisAddress;
				num2 = table.Cols;
				num3 = table.XAxisElementSize;
				double xaxisScale = table.XAxisScale;
				double xaxisOffset = table.XAxisOffset;
				isSwapped = table.IsSwapped;
			}
			if (num <= 0)
			{
				num = table.Address;
				num2 = ((table.Cols > 1) ? table.Cols : table.Rows);
				num3 = table.ElementSize;
				double scale = table.Scale;
				double offset = table.Offset;
				isSwapped = table.IsSwapped;
			}
			if (num <= 0 || num2 < 2 || num3 <= 0)
			{
				return;
			}
			List<double> list = new List<double>();
			checked
			{
				for (int i = 0; i < num2; i++)
				{
					int num4 = num + i * num3;
					if (num4 < 0 || num4 + num3 > this.binData.Length)
					{
						break;
					}
					double raw = this.ReadRaw(num4, num3, isSwapped, false, false);
					list.Add(MapEditorForm.EvalMathEquation(table.MathEquation, raw));
				}
				if (list.Count < 2)
				{
					return;
				}
				if (this.graph2DForm != null && !this.graph2DForm.IsDisposed)
				{
					try
					{
						this.graph2DForm.DataPointValueChanged -= this.Graph2DForm_DataPointValueChanged;
					}
					catch
					{
					}
					this.graph2DForm.DataPointValueChanged += this.Graph2DForm_DataPointValueChanged;
					this.graph2DForm.Text = "Graph 2D — Breakpoint (" + this.currentProfile.Name + ")";
					this.graph2DForm.ShowChart(list);
					this.graph2DForm.Activate();
					this.graph2DForm.BringToFront();
					return;
				}
				this.graph2DForm = new _3D_Chart_Graph._2d();
				this.graph2DForm.DataPointValueChanged += this.Graph2DForm_DataPointValueChanged;
				this.graph2DForm.FormClosed += delegate(object s, FormClosedEventArgs ev)
				{
					this.graph2DForm = null;
				};
				this.graph2DForm.Show(this);
				this.graph2DForm.Text = "Graph 2D — Breakpoint (" + this.currentProfile.Name + ")";
				this.graph2DForm.ShowChart(list);
			}
		}

		// Token: 0x06001558 RID: 5464 RVA: 0x000A3DC0 File Offset: 0x000A3DC0
		private void BuildTopBar()
		{
			this.titleBar = new Panel
			{
				Dock = DockStyle.Top,
				Height = 56,
				BackColor = this.bgPanel,
				Padding = new Padding(12, 6, 12, 6)
			};
			Label value = new Label
			{
				Text = "⬢",
				Font = new Font("Segoe UI", 22f, FontStyle.Bold),
				ForeColor = this.cyan,
				Location = new Point(14, -5),
				AutoSize = true,
				BackColor = Color.Transparent
			};
			this.lblTitle = new Label
			{
				Text = "DEPPLOY MAP TUNING EDITOR",
				Font = new Font("Segoe UI", 13f, FontStyle.Bold),
				ForeColor = this.cyan,
				Location = new Point(52, 4),
				AutoSize = true,
				BackColor = Color.Transparent,
				Cursor = Cursors.SizeAll
			};
			this.lblSubtitle = new Label
			{
				Text = "XDF CALIBRATION / BIN EDITOR",
				Font = new Font("Segoe UI", 7.5f),
				ForeColor = this.muted,
				Location = new Point(54, 30),
				AutoSize = true,
				BackColor = Color.Transparent
			};
			string[,] array = new string[11, 2];
			array[0, 0] = "\ud83d\udcc2";
			array[0, 1] = "Open XDF";
			array[1, 0] = "\ud83d\udcc2";
			array[1, 1] = "Open BIN";
			array[2, 0] = "\ud83d\udcbe";
			array[2, 1] = "Save BIN";
			array[3, 0] = "♻️";
			array[3, 1] = "Undo";
			array[4, 0] = "♻️";
			array[4, 1] = "Redo";
			array[5, 0] = "\ud83d\udcc8";
			array[5, 1] = "2D Graph";
			array[6, 0] = "\ud83d\udcca";
			array[6, 1] = "3D Graph";
			array[7, 0] = "\ud83d\udc1e";
			array[7, 1] = "Debug";
			array[8, 0] = "\ud83d\udd0d";
			array[8, 1] = "Compare";
			array[9, 0] = "\ud83d\udcc2";
			array[9, 1] = "Compare Bins";
			array[10, 0] = "\ud83d\udcd6";
			array[10, 1] = "Help";
			int num = 600;
			checked
			{
				for (int i = 0; i < array.GetLength(0); i++)
				{
					string glyph = array[i, 0];
					string tip = array[i, 1];
					int idx = i;
					Button button = this.MakeIconButton(glyph, num, 14, tip);
					button.Click += delegate(object s, EventArgs ev)
					{
						switch (idx)
						{
						case 0:
							this.BtnOpenXdf_Click(null, EventArgs.Empty);
							return;
						case 1:
							this.BtnOpenBin_Click(null, EventArgs.Empty);
							return;
						case 2:
							this.BtnSaveBin_Click(null, EventArgs.Empty);
							return;
						case 3:
							this.DoUndo();
							return;
						case 4:
							this.DoRedo();
							return;
						case 5:
							this.Open2DBreakpoint();
							return;
						case 6:
							this.Open3DGraph();
							return;
						case 7:
							this.BtnDebug_Click(null, EventArgs.Empty);
							return;
						case 8:
							this.OpenCompareDialog();
							return;
						case 9:
							this.OpenSelectCompareBins();
							return;
						case 10:
							this.ShowHelp();
							return;
						default:
							return;
						}
					};
					this.titleBar.Controls.Add(button);
					num += 34;
				}
				this.lblConn = new Label
				{
					Text = "\ud83d\udfe2 CONNECTED • COM5",
					Font = new Font("Segoe UI", 7.5f, FontStyle.Bold),
					ForeColor = Color.Black,
					BackColor = this.green,
					TextAlign = ContentAlignment.MiddleCenter,
					Size = new Size(140, 24),
					Location = new Point(0, 16),
					Anchor = (AnchorStyles.Top | AnchorStyles.Right)
				};
				this.btnClose = this.CreateWindowButton("✕", 0, 0, this.danger, Color.FromArgb(140, 35, 50));
				this.btnMinimize = this.CreateWindowButton("—", 0, 0, this.fg, Color.FromArgb(30, 40, 50));
				this.btnClose.Click += delegate(object s, EventArgs ev)
				{
					base.Close();
				};
				this.btnMinimize.Click += delegate(object s, EventArgs ev)
				{
					base.WindowState = FormWindowState.Minimized;
				};
				this.titleBar.Controls.Add(value);
				this.titleBar.Controls.Add(this.lblTitle);
				this.titleBar.Controls.Add(this.lblSubtitle);
				this.titleBar.Controls.Add(this.lblConn);
				this.titleBar.Controls.Add(this.btnMinimize);
				this.titleBar.Controls.Add(this.btnClose);
				this.titleBar.Resize += delegate(object s, EventArgs ev)
				{
					this.lblConn.Left = this.titleBar.Width - 260;
					this.btnClose.Location = new Point(this.titleBar.Width - 44, 14);
					this.btnMinimize.Location = new Point(this.titleBar.Width - 84, 14);
				};
				this.titleBar.MouseDown += this.TitleBar_MouseDown;
				this.titleBar.MouseMove += this.TitleBar_MouseMove;
				this.titleBar.MouseUp += this.TitleBar_MouseUp;
				this.lblTitle.MouseDown += this.TitleBar_MouseDown;
				this.lblTitle.MouseMove += this.TitleBar_MouseMove;
				this.lblTitle.MouseUp += this.TitleBar_MouseUp;
			}
		}

		// Token: 0x06001559 RID: 5465 RVA: 0x000A42C8 File Offset: 0x000A42C8
		private Button MakeIconButton(string glyph, int x, int y, string tip)
		{
			Button b = new Button
			{
				Text = glyph,
				Location = new Point(x, y),
				Size = new Size(30, 30),
				FlatStyle = FlatStyle.Flat,
				BackColor = Color.Transparent,
				ForeColor = this.cyan,
				Font = new Font("Segoe UI", 11f),
				Cursor = Cursors.Hand,
				TabStop = false
			};
			b.FlatAppearance.BorderSize = 0;
			b.FlatAppearance.MouseOverBackColor = Color.Transparent;
			b.FlatAppearance.MouseDownBackColor = Color.Transparent;
			b.Paint += checked(delegate(object s, PaintEventArgs ev)
			{
				Button button = (Button)s;
				if (button.Width < 4 || button.Height < 4)
				{
					return;
				}
				ev.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				bool flag = button.ClientRectangle.Contains(button.PointToClient(Cursor.Position));
				using (GraphicsPath graphicsPath = MapEditorForm.CreateRoundedPath(new Rectangle(0, 0, button.Width - 1, button.Height - 1), 6))
				{
					using (SolidBrush solidBrush = new SolidBrush(flag ? Color.FromArgb(30, 0, 255, 230) : this.bgCard))
					{
						ev.Graphics.FillPath(solidBrush, graphicsPath);
					}
				}
				using (GraphicsPath graphicsPath2 = MapEditorForm.CreateRoundedPath(new Rectangle(0, 0, button.Width - 1, button.Height - 1), 6))
				{
					if (flag)
					{
						using (Pen pen = new Pen(Color.FromArgb(40, 0, 255, 230), 4f))
						{
							using (Pen pen2 = new Pen(Color.FromArgb(100, 0, 255, 230), 2f))
							{
								using (Pen pen3 = new Pen(this.cyan, 1.4f))
								{
									ev.Graphics.DrawPath(pen, graphicsPath2);
									ev.Graphics.DrawPath(pen2, graphicsPath2);
									ev.Graphics.DrawPath(pen3, graphicsPath2);
									goto IL_1BF;
								}
							}
						}
					}
					using (Pen pen4 = new Pen(Color.FromArgb(120, 0, 255, 230), 1f))
					{
						ev.Graphics.DrawPath(pen4, graphicsPath2);
					}
				}
				IL_1BF:
				TextRenderer.DrawText(ev.Graphics, button.Text, button.Font, button.ClientRectangle, flag ? Color.White : this.cyan, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			});
			new ToolTip().SetToolTip(b, tip);
			b.MouseEnter += delegate(object s, EventArgs ev)
			{
				b.Invalidate();
			};
			b.MouseLeave += delegate(object s, EventArgs ev)
			{
				b.Invalidate();
			};
			b.MouseDown += delegate(object s, MouseEventArgs ev)
			{
				b.Invalidate();
			};
			b.MouseUp += delegate(object s, MouseEventArgs ev)
			{
				b.Invalidate();
			};
			return b;
		}

		// Token: 0x0600155A RID: 5466 RVA: 0x000A441C File Offset: 0x000A441C
		private void BuildMenuStrip()
		{
			this.mainMenu = new MenuStrip
			{
				Dock = DockStyle.Top,
				Height = 24,
				BackColor = this.bgCard,
				ForeColor = this.cyan,
				Font = new Font("Segoe UI", 8.5f, FontStyle.Italic),
				Padding = new Padding(12, 0, 0, 0),
				RenderMode = ToolStripRenderMode.Professional
			};
			ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("FILE");
			toolStripMenuItem.DropDownItems.Add(new ToolStripMenuItem("Open XDF Definition...", null, new EventHandler(this.BtnOpenXdf_Click)));
			toolStripMenuItem.DropDownItems.Add(new ToolStripMenuItem("Open BIN/ROM", null, new EventHandler(this.BtnOpenBin_Click)));
			toolStripMenuItem.DropDownItems.Add(new ToolStripMenuItem("Save As BIN/ROM", null, new EventHandler(this.BtnSaveBin_Click)));
			toolStripMenuItem.DropDownItems.Add(new ToolStripMenuItem("Save Edit (overwrite BIN)", null, new EventHandler(this.BtnSaveEdit_Click)));
			toolStripMenuItem.DropDownItems.Add(new ToolStripMenuItem("Reload XDF", null, delegate(object s, EventArgs ev)
			{
				if (!string.IsNullOrEmpty(this.loadedXdfPath) && File.Exists(this.loadedXdfPath))
				{
					this.LoadXdf(this.loadedXdfPath, false);
				}
			}));
			toolStripMenuItem.DropDownItems.Add(new ToolStripMenuItem("Exit", null, delegate(object s, EventArgs ev)
			{
				base.Close();
			}));
			ToolStripMenuItem toolStripMenuItem2 = new ToolStripMenuItem("FUNCTION VALUE");
			toolStripMenuItem2.DropDownItems.Add(new ToolStripMenuItem("Add Value (+)", null, delegate(object s, EventArgs ev)
			{
				this.BatchEditValues("add");
			}));
			toolStripMenuItem2.DropDownItems.Add(new ToolStripMenuItem("Subtract Value (-)", null, delegate(object s, EventArgs ev)
			{
				this.BatchEditValues("sub");
			}));
			toolStripMenuItem2.DropDownItems.Add(new ToolStripMenuItem("Multiply Value (%)", null, delegate(object s, EventArgs ev)
			{
				this.BatchEditValues("mul");
			}));
			toolStripMenuItem2.DropDownItems.Add(new ToolStripMenuItem("Fill Selected with Value", null, delegate(object s, EventArgs ev)
			{
				this.BatchEditValues("fill");
			}));
			ToolStripMenuItem toolStripMenuItem3 = new ToolStripMenuItem("GRAPH 3D");
			toolStripMenuItem3.DropDownItems.Add(new ToolStripMenuItem("Show Current View in 3D", null, delegate(object s, EventArgs ev)
			{
				this.Open3DGraph();
			}));
			ToolStripMenuItem toolStripMenuItem4 = new ToolStripMenuItem("GRAPH 2D");
			toolStripMenuItem4.DropDownItems.Add(new ToolStripMenuItem("Show Current Axis (Editable)", null, delegate(object s, EventArgs ev)
			{
				this.Open2DBreakpoint();
			}));
			ToolStripMenuItem toolStripMenuItem5 = new ToolStripMenuItem("VIEW");
			toolStripMenuItem5.DropDownItems.Add(new ToolStripMenuItem("Swap X/Y Axis (Ctrl+T)", null, delegate(object s, EventArgs ev)
			{
				this.ToggleSwapAxes();
			}));
			toolStripMenuItem5.DropDownItems.Add(new ToolStripMenuItem("Toggle Right Panel (Ctrl+H)", null, delegate(object s, EventArgs ev)
			{
				this.ToggleRightPanel();
			}));
			ToolStripMenuItem toolStripMenuItem6 = new ToolStripMenuItem("COMPARE");
			toolStripMenuItem6.DropDownItems.Add(new ToolStripMenuItem("Compare Edited vs Original BIN (Ctrl+K)", null, delegate(object s, EventArgs ev)
			{
				this.OpenCompareDialog();
			}));
			toolStripMenuItem6.DropDownItems.Add(new ToolStripMenuItem("Compare Bins (Ctrl+B)", null, delegate(object s, EventArgs ev)
			{
				this.OpenSelectCompareBins();
			}));
			toolStripMenuItem6.DropDownItems.Add(new ToolStripMenuItem("Revert Selected Cell to Original", null, delegate(object s, EventArgs ev)
			{
				this.RevertSelectedCellsToOriginal();
			}));
			toolStripMenuItem6.DropDownItems.Add(new ToolStripMenuItem("Revert ALL to Original", null, delegate(object s, EventArgs ev)
			{
				this.RevertAllToOriginalAndRefresh();
			}));
			ToolStripMenuItem toolStripMenuItem7 = new ToolStripMenuItem("LIVE DATA");
			toolStripMenuItem7.DropDownItems.Add(new ToolStripMenuItem("Start / Stop Live Tracking", null, delegate(object s, EventArgs ev)
			{
				this.BtnLiveData_Click(null, EventArgs.Empty);
			}));
			toolStripMenuItem7.DropDownItems.Add(new ToolStripMenuItem("Set COM Port / Baud / Protocol...", null, delegate(object s, EventArgs ev)
			{
				this.ShowLiveSettings();
			}));
			this.mainMenu.Items.AddRange(new ToolStripItem[]
			{
				toolStripMenuItem,
				toolStripMenuItem2,
				toolStripMenuItem3,
				toolStripMenuItem4,
				toolStripMenuItem5,
				toolStripMenuItem6,
				toolStripMenuItem7
			});
			base.MainMenuStrip = this.mainMenu;
		}

		// Token: 0x0600155B RID: 5467 RVA: 0x000A47E0 File Offset: 0x000A47E0
		private void BuildToolbar()
		{
			this.toolbarPanel = new Panel
			{
				Dock = DockStyle.Top,
				Height = 52,
				BackColor = this.bgPanel,
				Padding = new Padding(12, 8, 12, 8)
			};
			this.btn2DView = this.MakeNeonButton("\ud83d\udcc8 2D BP", 0, 10, 100, 32, this.blue2D, Color.FromArgb(0, 100, 180));
			this.btn2DView.Click += delegate(object s, EventArgs ev)
			{
				this.Open2DBreakpoint();
			};
			this.btn3DView = this.MakeNeonButton("\ud83d\udcca 3D VIEW", 0, 10, 100, 32, this.orange3D, Color.FromArgb(180, 100, 0));
			this.btn3DView.Click += delegate(object s, EventArgs ev)
			{
				this.Open3DGraph();
			};
			this.btnOpenXdf = this.MakeNeonButton("\ud83d\udcc1 OPEN XDF", 0, 10, 100, 32, this.purpleXdf, Color.FromArgb(130, 60, 200));
			this.btnOpenXdf.Click += this.BtnOpenXdf_Click;
			this.btnOpenBin = this.MakeNeonButton("\ud83d\udcc2 OPEN BIN", 0, 10, 100, 32, this.cyan, this.cyanDark);
			this.btnOpenBin.Click += this.BtnOpenBin_Click;
			this.btnSaveBin = this.MakeNeonButton("\ud83d\udcbe SAVE BIN", 0, 10, 100, 32, this.green, Color.FromArgb(0, 200, 120));
			this.btnSaveBin.Click += this.BtnSaveBin_Click;
			this.btnSaveEdit = this.MakeNeonButton("\ud83d\udcbe SAVE EDIT", 0, 10, 100, 32, Color.FromArgb(0, 180, 220), Color.FromArgb(0, 120, 160));
			this.btnSaveEdit.Click += this.BtnSaveEdit_Click;
			this.btnSwapAxes = this.MakeNeonButton("\ud83d\udd04 SWAP X/Y", 0, 10, 110, 32, this.gold, Color.FromArgb(200, 150, 0));
			this.btnSwapAxes.Click += delegate(object s, EventArgs ev)
			{
				this.ToggleSwapAxes();
			};
			this.btnCompare = this.MakeNeonButton("\ud83d\udd0d COMPARE", 0, 10, 100, 32, this.orange3D, Color.FromArgb(180, 100, 0));
			this.btnCompare.Click += delegate(object s, EventArgs ev)
			{
				this.OpenCompareDialog();
			};
			this.btnCompareBins = this.MakeNeonButton("\ud83d\udcc1 COMPARE BINS", 0, 10, 130, 32, Color.FromArgb(0, 150, 255), Color.FromArgb(0, 100, 180));
			this.btnCompareBins.Click += delegate(object s, EventArgs ev)
			{
				this.OpenSelectCompareBins();
			};
			this.btnDebug = this.MakeNeonButton("\ud83c\udfaf HISTORY", 0, 10, 110, 32, this.cyan, this.cyanDark);
			this.btnDebug.Click += this.BtnLiveTrace_Click;
			this.cmbProfiles = new ComboBox
			{
				DropDownStyle = ComboBoxStyle.DropDownList,
				BackColor = this.bgCard,
				ForeColor = this.cyan,
				FlatStyle = FlatStyle.Flat,
				Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
				Location = new Point(0, 10),
				Size = new Size(200, 30),
				Visible = false
			};
			this.cmbProfiles.SelectedIndexChanged += this.CmbProfiles_SelectedIndexChanged;
			this.toolbarPanel.Controls.Add(this.btn2DView);
			this.toolbarPanel.Controls.Add(this.btn3DView);
			this.toolbarPanel.Controls.Add(this.btnOpenXdf);
			this.toolbarPanel.Controls.Add(this.btnOpenBin);
			this.toolbarPanel.Controls.Add(this.btnSaveBin);
			this.toolbarPanel.Controls.Add(this.btnSaveEdit);
			this.toolbarPanel.Controls.Add(this.btnSwapAxes);
			this.toolbarPanel.Controls.Add(this.btnCompare);
			this.toolbarPanel.Controls.Add(this.btnCompareBins);
			this.toolbarPanel.Controls.Add(this.btnDebug);
			this.toolbarPanel.Controls.Add(this.cmbProfiles);
			this.toolbarPanel.Resize += delegate(object s, EventArgs ev)
			{
				this.RepositionToolbar();
			};
		}

		// Token: 0x0600155C RID: 5468 RVA: 0x000A4C58 File Offset: 0x000A4C58
		private void BuildLeftPanel()
		{
			Panel panel = new Panel
			{
				Dock = DockStyle.Fill,
				BackColor = this.bgDark
			};
			Panel hdr = new Panel
			{
				Dock = DockStyle.Top,
				Height = 64,
				BackColor = this.bgPanel
			};
			Label value = new Label
			{
				Text = "Parameter Tree",
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				ForeColor = this.cyan,
				Location = new Point(10, 4),
				AutoSize = true,
				BackColor = Color.Transparent
			};
			Label value2 = new Label
			{
				Text = "View By:",
				Font = new Font("Segoe UI", 8.5f),
				ForeColor = this.fg,
				Location = new Point(10, 32),
				AutoSize = true,
				BackColor = Color.Transparent
			};
			this.cmbViewBy = new ComboBox
			{
				DropDownStyle = ComboBoxStyle.DropDownList,
				BackColor = this.bgCard,
				ForeColor = this.cyan,
				FlatStyle = FlatStyle.Flat,
				Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
				Location = new Point(64, 28),
				Width = 250,
				Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
			};
			this.cmbViewBy.Items.AddRange(new object[]
			{
				"Parameter Category",
				"Parameter Name",
				"Address (Hex)"
			});
			this.cmbViewBy.SelectedIndex = 0;
			this.cmbViewBy.SelectedIndexChanged += delegate(object s, EventArgs ev)
			{
				this.RebuildTree();
			};
			hdr.Controls.Add(value);
			hdr.Controls.Add(value2);
			hdr.Controls.Add(this.cmbViewBy);
			hdr.Resize += delegate(object s, EventArgs ev)
			{
				this.cmbViewBy.Width = Math.Max(120, checked(hdr.Width - 80));
			};
			this.treeViewMaps = new TreeView
			{
				Dock = DockStyle.Fill,
				BackColor = this.bgPanel,
				ForeColor = this.cyan,
				BorderStyle = BorderStyle.None,
				Font = new Font("Segoe UI", 8.5f),
				ItemHeight = 20,
				ShowLines = true,
				ShowPlusMinus = true,
				ShowRootLines = true,
				HideSelection = false,
				Indent = 16,
				LineColor = this.border,
				FullRowSelect = false
			};
			this.treeViewMaps.AfterSelect += delegate(object s, TreeViewEventArgs e)
			{
				XdfProfile prof;
				if (e.Node != null && (prof = (e.Node.Tag as XdfProfile)) != null)
				{
					this.SelectProfile(prof);
				}
			};
			this.treeViewMaps.MouseUp += delegate(object s, MouseEventArgs e)
			{
				if (e.Button != MouseButtons.Right)
				{
					return;
				}
				new ContextMenuStrip
				{
					BackColor = this.bgCard,
					ForeColor = this.cyan,
					RenderMode = ToolStripRenderMode.Professional,
					Items = 
					{
						{
							"Expand All",
							null,
							delegate(object s2, EventArgs ev2)
							{
								this.treeViewMaps.ExpandAll();
							}
						},
						{
							"Collapse All",
							null,
							delegate(object s2, EventArgs ev2)
							{
								this.treeViewMaps.CollapseAll();
							}
						}
					}
				}.Show(this.treeViewMaps, e.Location);
			};
			this.lblTreeFooter = new Label
			{
				Dock = DockStyle.Bottom,
				Height = 26,
				BackColor = this.bgPanel,
				ForeColor = this.cyan,
				Font = new Font("Segoe UI", 8f, FontStyle.Italic),
				Padding = new Padding(10, 4, 10, 4),
				Text = "▸  [Kompatible Ecu : —]"
			};
			this.propPanel = this.BuildPropertiesPanel();
			this.propPanel.Dock = DockStyle.Bottom;
			this.propPanel.Height = 168;
			panel.Controls.Add(this.treeViewMaps);
			panel.Controls.Add(this.lblTreeFooter);
			panel.Controls.Add(hdr);
			panel.Controls.Add(this.propPanel);
			this.splitContainerMain.Panel1.Controls.Add(panel);
		}

		// Token: 0x0600155D RID: 5469 RVA: 0x000A4FFC File Offset: 0x000A4FFC
		private Panel BuildPropertiesPanel()
		{
			Panel panel = new Panel();
			panel.BackColor = this.bgPanel;
			panel.Padding = new Padding(0);
			panel.Margin = new Padding(0);
			Label value = new Label
			{
				Text = "MAP PROPERTIES",
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				ForeColor = this.cyan,
				Dock = DockStyle.Top,
				Height = 22,
				BackColor = Color.Transparent,
				Padding = new Padding(10, 4, 10, 0),
				TextAlign = ContentAlignment.MiddleLeft
			};
			this.lblPropName = this.MakePropLabel();
			this.lblPropAxis = this.MakePropLabel();
			this.lblPropUnits = this.MakePropLabel();
			this.lblPropSize = this.MakePropSizeLabel();
			Panel panel2 = new Panel
			{
				Dock = DockStyle.Fill,
				BackColor = Color.Transparent,
				Padding = new Padding(0, 30, 0, 0),
				Margin = new Padding(0)
			};
			panel2.Controls.Add(this.lblPropSize);
			panel2.Controls.Add(this.lblPropUnits);
			panel2.Controls.Add(this.lblPropAxis);
			panel2.Controls.Add(this.lblPropName);
			panel.Controls.Add(panel2);
			panel.Controls.Add(value);
			return panel;
		}

		// Token: 0x0600155E RID: 5470 RVA: 0x000A5158 File Offset: 0x000A5158
		private Label MakePropLabel()
		{
			return new Label
			{
				Dock = DockStyle.Top,
				Height = 24,
				ForeColor = this.fg,
				Font = new Font("Consolas", 8.5f),
				BackColor = Color.Transparent,
				Padding = new Padding(10, 2, 4, 0),
				TextAlign = ContentAlignment.MiddleLeft,
				AutoEllipsis = true,
				Margin = new Padding(0)
			};
		}

		// Token: 0x0600155F RID: 5471 RVA: 0x000A51D0 File Offset: 0x000A51D0
		private Label MakePropSizeLabel()
		{
			return new Label
			{
				Dock = DockStyle.Top,
				Height = 44,
				ForeColor = this.fg,
				Font = new Font("Consolas", 8.5f),
				BackColor = Color.Transparent,
				Padding = new Padding(10, 2, 4, 0),
				TextAlign = ContentAlignment.TopLeft,
				AutoEllipsis = true,
				Margin = new Padding(0)
			};
		}

		// Token: 0x06001560 RID: 5472 RVA: 0x000A5248 File Offset: 0x000A5248
		private void BuildCenterPanel()
		{
			Panel panel = new Panel
			{
				Dock = DockStyle.Fill,
				BackColor = this.bgDark,
				Padding = new Padding(6)
			};
			Panel panel2 = new Panel
			{
				Dock = DockStyle.Top,
				Height = 40,
				BackColor = this.bgCard
			};
			this.lblMapTitle = new Label
			{
				Text = "\ud83d\uddfa  Select a map from the left list",
				Font = new Font("Segoe UI", 12f, FontStyle.Bold),
				ForeColor = this.cyan,
				Location = new Point(14, 6),
				AutoSize = true,
				BackColor = Color.Transparent
			};
			panel2.Controls.Add(this.lblMapTitle);
			this.xRuler = new Panel
			{
				Dock = DockStyle.Top,
				Height = 26,
				BackColor = this.bgPanel
			};
			this.xRuler.Paint += this.PaintXRuler;
			Panel panel3 = new Panel
			{
				Dock = DockStyle.Fill
			};
			this.yRuler = new Panel
			{
				Dock = DockStyle.Left,
				Width = 46,
				BackColor = this.bgPanel
			};
			this.yRuler.Paint += this.PaintYRuler;
			this.dgvMap = this.CreateStyledDgv();
			this.dgvMap.SelectionChanged += delegate(object s, EventArgs ev)
			{
				this.UpdateCursorLabel();
				this.UpdateHexView();
			};
			this.dgvMap.CellValueChanged += this.DgvMap_CellValueChanged;
			this.dgvMap.CellFormatting += this.DgvMap_CellFormatting;
			this.dgvMap.Scroll += delegate(object s, ScrollEventArgs ev)
			{
				this.xRuler.Invalidate();
				this.yRuler.Invalidate();
			};
			panel3.Controls.Add(this.dgvMap);
			panel3.Controls.Add(this.yRuler);
			this.lblCursor = new Label
			{
				Dock = DockStyle.Bottom,
				Height = 26,
				BackColor = this.bgPanel,
				ForeColor = this.cyan,
				Font = new Font("Consolas", 8.5f, FontStyle.Bold),
				Padding = new Padding(10, 4, 10, 4),
				Text = "Cursor: [R0, C0] = — | Min: — • Max: — • Avg: — • Sum: —"
			};
			Panel panel4 = new Panel
			{
				Dock = DockStyle.Bottom,
				Height = 46,
				BackColor = this.bgDark,
				Padding = new Padding(4, 6, 4, 6)
			};
			Button button = this.MakeNeonButton("Interpolate", 4, 6, 130, 32, this.cyan, this.cyanDark);
			Button button2 = this.MakeNeonButton("Smooth", 142, 6, 100, 32, this.fg, this.border);
			Button button3 = this.MakeNeonButton("Scale +5%", 250, 6, 110, 32, this.fg, this.border);
			Button button4 = this.MakeNeonButton("Scale -5%", 368, 6, 110, 32, this.fg, this.border);
			button.Click += delegate(object s, EventArgs ev)
			{
				this.BatchInterpolate();
			};
			button2.Click += delegate(object s, EventArgs ev)
			{
				this.BatchSmooth();
			};
			button3.Click += delegate(object s, EventArgs ev)
			{
				this.BatchEditValues("mul", 5.0);
			};
			button4.Click += delegate(object s, EventArgs ev)
			{
				this.BatchEditValues("mul", -5.0);
			};
			panel4.Controls.Add(button);
			panel4.Controls.Add(button2);
			panel4.Controls.Add(button3);
			panel4.Controls.Add(button4);
			PictureBox pictureBox = new PictureBox();
			pictureBox.Name = "picLogoCenter";
			pictureBox.BackColor = Color.Transparent;
			pictureBox.Location = new Point(checked(button4.Right + 10), 6);
			pictureBox.Size = new Size(132, 42);
			pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
			pictureBox.TabStop = false;
			pictureBox.Cursor = Cursors.Default;
			try
			{
				ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Honda_Flash_Tools.Net.FormMain));
				pictureBox.Image = (Image)componentResourceManager.GetObject("pictureBox1.Image");
			}
			catch
			{
				pictureBox.Image = null;
			}
			panel4.Controls.Add(pictureBox);
			panel.Controls.Add(panel3);
			panel.Controls.Add(this.lblCursor);
			panel.Controls.Add(panel4);
			panel.Controls.Add(this.xRuler);
			panel.Controls.Add(panel2);
			this.splitRight.Panel1.Controls.Add(panel);
		}

		// Token: 0x06001561 RID: 5473 RVA: 0x000A56C8 File Offset: 0x000A56C8
		private DataGridView CreateStyledDgv()
		{
			return new DataGridView
			{
				Dock = DockStyle.Fill,
				BackgroundColor = this.bgCard,
				BorderStyle = BorderStyle.None,
				GridColor = this.border,
				EnableHeadersVisualStyles = false,
				AllowUserToAddRows = false,
				AllowUserToDeleteRows = false,
				SelectionMode = DataGridViewSelectionMode.CellSelect,
				ReadOnly = false,
				EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2,
				ColumnHeadersVisible = true,
				RowHeadersVisible = true,
				ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize,
				RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders,
				CellBorderStyle = DataGridViewCellBorderStyle.Single,
				ScrollBars = ScrollBars.Both,
				Margin = new Padding(0),
				RowTemplate = 
				{
					Height = 24
				},
				DefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = this.bgCard,
					ForeColor = Color.Black,
					SelectionBackColor = Color.White,
					SelectionForeColor = Color.Black,
					Alignment = DataGridViewContentAlignment.MiddleCenter,
					Font = new Font("Consolas", 8f)
				},
				ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = Color.FromArgb(0, 55, 57),
					ForeColor = this.cyan,
					SelectionBackColor = Color.FromArgb(0, 75, 75),
					SelectionForeColor = this.cyan,
					Alignment = DataGridViewContentAlignment.MiddleCenter,
					Font = new Font("Segoe UI", 7.5f, FontStyle.Bold),
					WrapMode = DataGridViewTriState.True
				},
				RowHeadersDefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = Color.FromArgb(23, 34, 45),
					ForeColor = this.muted,
					SelectionBackColor = Color.FromArgb(0, 75, 75),
					SelectionForeColor = this.cyan,
					Alignment = DataGridViewContentAlignment.MiddleCenter,
					Font = new Font("Segoe UI", 7.5f, FontStyle.Bold)
				},
				AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = Color.FromArgb(23, 32, 43),
					ForeColor = this.fg
				}
			};
		}

		// Token: 0x06001562 RID: 5474 RVA: 0x000A58B4 File Offset: 0x000A58B4
		private void BuildRightPanel()
		{
			Panel panel = new Panel
			{
				Dock = DockStyle.Fill,
				BackColor = this.bgDark,
				Padding = new Padding(6)
			};
			Panel header = new Panel
			{
				Dock = DockStyle.Top,
				Height = 28,
				BackColor = this.bgCard
			};
			Label value = new Label
			{
				Text = "⬢ SIDE PANEL (3D + HEX)",
				Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
				ForeColor = this.cyan,
				Dock = DockStyle.Left,
				Width = 220,
				TextAlign = ContentAlignment.MiddleLeft,
				BackColor = Color.Transparent
			};
			this.btnToggleRightPanel = this.MakeNeonButton("▸", 0, 2, 26, 24, this.cyan, this.cyanDark);
			this.btnToggleRightPanel.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.btnToggleRightPanel.Click += delegate(object s, EventArgs ev)
			{
				this.ToggleRightPanel();
			};
			new ToolTip().SetToolTip(this.btnToggleRightPanel, "Collapse / Expand Right Panel (Ctrl+H)");
			header.Controls.Add(this.btnToggleRightPanel);
			header.Controls.Add(value);
			header.Resize += delegate(object s, EventArgs ev)
			{
				this.btnToggleRightPanel.Location = new Point(checked(header.Width - 30), 2);
			};
			Panel panel2 = new Panel
			{
				Dock = DockStyle.Fill,
				BackColor = this.bgDark
			};
			Panel panel3 = new Panel
			{
				Dock = DockStyle.Top,
				Height = 320,
				BackColor = this.bgCard,
				Padding = new Padding(6)
			};
			Label value2 = new Label
			{
				Text = "\ud83d\udcca  3D SURFACE (LIVE)",
				Font = new Font("Segoe UI", 10f, FontStyle.Bold),
				ForeColor = this.green,
				Dock = DockStyle.Top,
				Height = 24,
				TextAlign = ContentAlignment.MiddleLeft,
				BackColor = Color.Transparent
			};
			this.preview3DGraph = new MapEditorForm.PreviewGraph3D
			{
				Dock = DockStyle.Fill,
				BackColor = Color.FromArgb(5, 10, 15),
				BorderColor = Color.FromArgb(40, 80, 110),
				AxisX_Color = Color.FromArgb(0, 200, 255),
				AxisY_Color = Color.FromArgb(0, 255, 150),
				AxisZ_Color = Color.FromArgb(255, 165, 0),
				TopLegendColor = Color.White,
				PolygonLineColor = Color.FromArgb(60, 90, 110),
				Raster = Plot3D.Graph3D.eRaster.Off,
				AllowDrag = true,
				AllowRotate = true,
				AllowZoom = true,
				Cursor = Cursors.Hand,
				ShowPoints = false,
				ShowWireframe = false
			};
			this.preview3DGraph.SetCoefficients(5000.0, 69.0, 345.0);
			this.preview3DGraph.SetColorScheme(Plot3D.ColorSchema.GetSchema(Plot3D.ColorSchema.eSchema.Graph4D), 1f);
			this.preview3DGraph.HandleCreated += delegate(object s, EventArgs ev)
			{
				this.Request3DSync();
			};
			this.preview3DGraph.Resize += delegate(object s, EventArgs ev)
			{
				this.Request3DSync();
			};
			this.preview3DGraph.VisibleChanged += delegate(object s, EventArgs ev)
			{
				if (this.preview3DGraph.Visible)
				{
					this.Request3DSync();
				}
			};
			this.preview3DGraph.SelectionChangedInGraph -= this.Graph3D_SelectionChanged;
			this.preview3DGraph.SelectionChangedInGraph += this.Graph3D_SelectionChanged;
			panel3.Controls.Add(this.preview3DGraph);
			panel3.Controls.Add(value2);
			Splitter value3 = new Splitter
			{
				Dock = DockStyle.Top,
				Height = 6,
				BackColor = this.bgDark
			};
			Panel panel4 = new Panel
			{
				Dock = DockStyle.Fill,
				BackColor = this.bgCard,
				Padding = new Padding(6)
			};
			Label value4 = new Label
			{
				Text = "\ud83d\udd22  HEX VIEW",
				Font = new Font("Segoe UI", 10f, FontStyle.Bold),
				ForeColor = this.cyan,
				Dock = DockStyle.Top,
				Height = 24,
				TextAlign = ContentAlignment.MiddleLeft,
				BackColor = Color.Transparent
			};
			this.hexFooter = new Label
			{
				Dock = DockStyle.Bottom,
				Height = 22,
				ForeColor = this.muted,
				Font = new Font("Consolas", 7.5f),
				BackColor = Color.Transparent,
				Text = ""
			};
			this.hexBox = new RichTextBox
			{
				Dock = DockStyle.Fill,
				ReadOnly = true,
				BackColor = Color.FromArgb(8, 12, 16),
				ForeColor = this.cyan,
				Font = new Font("Consolas", 8.5f),
				BorderStyle = BorderStyle.None,
				WordWrap = false
			};
			panel4.Controls.Add(this.hexBox);
			panel4.Controls.Add(this.hexFooter);
			panel4.Controls.Add(value4);
			panel2.Controls.Add(panel4);
			panel2.Controls.Add(value3);
			panel2.Controls.Add(panel3);
			panel.Controls.Add(panel2);
			panel.Controls.Add(header);
			this.splitRight.Panel2.Controls.Add(panel);
		}

		// Token: 0x06001563 RID: 5475 RVA: 0x000A5E14 File Offset: 0x000A5E14
		private void BuildStatusBar()
		{
			this.statusBar = new Panel
			{
				Dock = DockStyle.Bottom,
				Height = 44,
				BackColor = this.bgPanel,
				Padding = new Padding(12, 6, 12, 6)
			};
			this.lblZoom = new Label
			{
				Text = "Zoom: 100%  •  v3.2.1 TUNERPRO/WINOLS EDITION  •  " + DateTime.Now.ToString("yyyy-MM-dd HH:mm"),
				Font = new Font("Consolas", 7.5f),
				ForeColor = this.muted,
				Dock = DockStyle.Top,
				Height = 16,
				BackColor = Color.Transparent
			};
			this.lblStatus = new Label
			{
				Text = "Ready  •  Edit Mode: Relative  •  Step: ±1  •  File: —  •  Size: —",
				Font = new Font("Consolas", 8.5f, FontStyle.Bold),
				ForeColor = this.green,
				Dock = DockStyle.Top,
				Height = 18,
				BackColor = Color.Transparent
			};
			this.statusBar.Controls.Add(this.lblZoom);
			this.statusBar.Controls.Add(this.lblStatus);
		}

		// Token: 0x06001564 RID: 5476 RVA: 0x000A5F40 File Offset: 0x000A5F40
		private void PaintXRuler(object sender, PaintEventArgs e)
		{
			e.Graphics.Clear(this.bgPanel);
			if (this.dgvMap == null || this.currentProfile == null || this.currentProfile.Table == null)
			{
				return;
			}
			if (this.dgvMap.Columns.Count == 0)
			{
				return;
			}
			checked
			{
				using (Font font = new Font("Consolas", 7f))
				{
					using (SolidBrush solidBrush = new SolidBrush(this.muted))
					{
						int num = this.dgvMap.RowHeadersWidth;
						int num2 = 0;
						if (this.dgvMap.Columns[0].Frozen)
						{
							num2 = this.dgvMap.Columns[0].Width;
						}
						if (this.dgvMap.FirstDisplayedScrollingColumnIndex > 0)
						{
							for (int i = 0; i < this.dgvMap.FirstDisplayedScrollingColumnIndex; i++)
							{
								if (!this.dgvMap.Columns[i].Frozen)
								{
									num -= this.dgvMap.Columns[i].Width;
								}
							}
						}
						if (num < num2 + this.dgvMap.RowHeadersWidth)
						{
							num = num2 + this.dgvMap.RowHeadersWidth;
						}
						int firstDisplayedScrollingColumnIndex = this.dgvMap.FirstDisplayedScrollingColumnIndex;
						int num3 = firstDisplayedScrollingColumnIndex + this.dgvMap.DisplayedColumnCount(true);
						int num4 = firstDisplayedScrollingColumnIndex;
						while (num4 < num3 && num4 < this.dgvMap.Columns.Count)
						{
							if (num >= 0 && (num4 == 0 || !this.dgvMap.Columns[num4].Frozen))
							{
								e.Graphics.DrawString(this.dgvMap.Columns[num4].HeaderText, font, solidBrush, (float)(num + 3), 6f);
							}
							num += this.dgvMap.Columns[num4].Width;
							num4++;
						}
						using (Font font2 = new Font("Consolas", 7f, FontStyle.Bold))
						{
							using (SolidBrush solidBrush2 = new SolidBrush(this.cyan))
							{
								e.Graphics.DrawString("Axis: " + (this.swapAxes ? "Y" : "X") + " →", font2, solidBrush2, 2f, 6f);
							}
						}
					}
				}
			}
		}

		// Token: 0x06001565 RID: 5477 RVA: 0x000A61F8 File Offset: 0x000A61F8
		private void PaintYRuler(object sender, PaintEventArgs e)
		{
			e.Graphics.Clear(this.bgPanel);
			if (this.dgvMap == null || this.dgvMap.Rows.Count == 0)
			{
				return;
			}
			checked
			{
				using (Font font = new Font("Consolas", 7f))
				{
					using (SolidBrush solidBrush = new SolidBrush(this.muted))
					{
						int num = this.dgvMap.ColumnHeadersHeight;
						if (this.dgvMap.FirstDisplayedScrollingRowIndex > 0)
						{
							for (int i = 0; i < this.dgvMap.FirstDisplayedScrollingRowIndex; i++)
							{
								num -= this.dgvMap.Rows[i].Height;
							}
						}
						int firstDisplayedScrollingRowIndex = this.dgvMap.FirstDisplayedScrollingRowIndex;
						int num2 = firstDisplayedScrollingRowIndex + this.dgvMap.DisplayedRowCount(true);
						int num3 = firstDisplayedScrollingRowIndex;
						while (num3 < num2 && num3 < this.dgvMap.Rows.Count)
						{
							if (num >= 0)
							{
								string s = (this.dgvMap.Rows[num3].HeaderCell.Value == null) ? "" : this.dgvMap.Rows[num3].HeaderCell.Value.ToString();
								e.Graphics.DrawString(s, font, solidBrush, 4f, (float)(num + 6));
							}
							num += this.dgvMap.Rows[num3].Height;
							num3++;
						}
					}
				}
			}
		}

		// Token: 0x06001566 RID: 5478 RVA: 0x000A63A8 File Offset: 0x000A63A8
		private string BuildRawHexString(int addr, int size)
		{
			if (this.binData == null || size <= 0)
			{
				return "";
			}
			checked
			{
				int num = Math.Min(addr + size, this.binData.Length);
				StringBuilder stringBuilder = new StringBuilder(size * 3);
				for (int i = addr; i < num; i++)
				{
					if (stringBuilder.Length > 0)
					{
						stringBuilder.Append(' ');
					}
					stringBuilder.Append(this.binData[i].ToString("X2"));
				}
				return stringBuilder.ToString();
			}
		}

		// Token: 0x06001567 RID: 5479 RVA: 0x000A6424 File Offset: 0x000A6424
		private void RebuildTree()
		{
			if (this.treeViewMaps == null)
			{
				return;
			}
			this.treeViewMaps.BeginUpdate();
			try
			{
				this.treeViewMaps.Nodes.Clear();
				if (this.allProfiles == null || this.allProfiles.Count == 0)
				{
					this.UpdateTreeFooter();
					return;
				}
				TreeNode treeNode = new TreeNode("\ud83d\ude97 BEAT_KOM ---- 30400-K81 (" + this.allProfiles.Count + ")")
				{
					Name = "__ROOT__",
					Tag = null
				};
				this.treeViewMaps.Nodes.Add(treeNode);
				string a2 = (this.cmbViewBy != null && this.cmbViewBy.SelectedItem != null) ? this.cmbViewBy.SelectedItem.ToString() : "Parameter Category";
				if (a2 == "Parameter Category")
				{
					Dictionary<string, TreeNode> dictionary = new Dictionary<string, TreeNode>(StringComparer.OrdinalIgnoreCase);
					List<XdfProfile> list = new List<XdfProfile>(this.allProfiles);
					list.Sort(delegate(XdfProfile a, XdfProfile b)
					{
						int num2 = string.Compare(MapEditorForm.SafeCategory(a), MapEditorForm.SafeCategory(b), StringComparison.OrdinalIgnoreCase);
						if (num2 == 0)
						{
							return string.Compare(a.Name ?? "", b.Name ?? "", StringComparison.OrdinalIgnoreCase);
						}
						return num2;
					});
					using (List<XdfProfile>.Enumerator enumerator = list.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							XdfProfile xdfProfile = enumerator.Current;
							string text = MapEditorForm.SafeCategory(xdfProfile);
							TreeNode treeNode2;
							if (!dictionary.TryGetValue(text, out treeNode2))
							{
								treeNode2 = new TreeNode(string.Concat(new object[]
								{
									"\ud83d\udcc1 ",
									text,
									" (",
									this.CountInCategory(text),
									")"
								}))
								{
									Name = "CAT_" + text,
									Tag = null
								};
								dictionary[text] = treeNode2;
								treeNode.Nodes.Add(treeNode2);
							}
							treeNode2.Nodes.Add(this.CreateLeafNode(xdfProfile));
						}
						goto IL_36C;
					}
				}
				if (a2 == "Parameter Name")
				{
					List<XdfProfile> list2 = new List<XdfProfile>(this.allProfiles);
					list2.Sort((XdfProfile a, XdfProfile b) => string.Compare(a.Name ?? "", b.Name ?? "", StringComparison.OrdinalIgnoreCase));
					using (List<XdfProfile>.Enumerator enumerator2 = list2.GetEnumerator())
					{
						while (enumerator2.MoveNext())
						{
							XdfProfile prof = enumerator2.Current;
							treeNode.Nodes.Add(this.CreateLeafNode(prof));
						}
						goto IL_36C;
					}
				}
				if (a2 == "Address (Hex)")
				{
					List<XdfProfile> list3 = new List<XdfProfile>(this.allProfiles);
					list3.Sort(delegate(XdfProfile a, XdfProfile b)
					{
						int num2 = (a.Table != null) ? a.Table.Address : 0;
						int value = (b.Table != null) ? b.Table.Address : 0;
						return num2.CompareTo(value);
					});
					Dictionary<int, TreeNode> dictionary2 = new Dictionary<int, TreeNode>();
					foreach (XdfProfile xdfProfile2 in list3)
					{
						int num = ((xdfProfile2.Table != null) ? xdfProfile2.Table.Address : 0) & -4096;
						TreeNode treeNode3;
						if (!dictionary2.TryGetValue(num, out treeNode3))
						{
							treeNode3 = new TreeNode(string.Format("\ud83d\udce6 0x{0:X4} – 0x{1:X4}", num, checked(num + 4095)))
							{
								Name = "BLK_" + num.ToString("X"),
								Tag = null
							};
							dictionary2[num] = treeNode3;
							treeNode.Nodes.Add(treeNode3);
						}
						treeNode3.Nodes.Add(this.CreateLeafNode(xdfProfile2));
					}
				}
				IL_36C:
				treeNode.Expand();
				foreach (object obj in treeNode.Nodes)
				{
					((TreeNode)obj).Expand();
				}
				if (this.currentProfile != null)
				{
					TreeNode treeNode4 = this.FindNodeByProfile(treeNode, this.currentProfile);
					if (treeNode4 != null)
					{
						this.treeViewMaps.SelectedNode = treeNode4;
					}
					else if (treeNode.Nodes.Count > 0 && treeNode.Nodes[0].Nodes.Count > 0)
					{
						this.treeViewMaps.SelectedNode = treeNode.Nodes[0].Nodes[0];
					}
				}
				else if (treeNode.Nodes.Count > 0 && treeNode.Nodes[0].Nodes.Count > 0)
				{
					this.treeViewMaps.SelectedNode = treeNode.Nodes[0].Nodes[0];
				}
			}
			finally
			{
				this.treeViewMaps.EndUpdate();
			}
			this.UpdateTreeFooter();
		}

		// Token: 0x06001568 RID: 5480 RVA: 0x000A6938 File Offset: 0x000A6938
		private static string SafeCategory(XdfProfile p)
		{
			if (p == null)
			{
				return "Umum";
			}
			string text = null;
			try
			{
				text = p.Category;
			}
			catch
			{
			}
			if (string.IsNullOrEmpty(text) && p.Table != null)
			{
				try
				{
					text = p.Table.Category;
				}
				catch
				{
				}
			}
			if (!string.IsNullOrEmpty(text))
			{
				return text;
			}
			return "Umum";
		}

		// Token: 0x06001569 RID: 5481 RVA: 0x000A69A8 File Offset: 0x000A69A8
		private int CountInCategory(string cat)
		{
			int num = 0;
			if (this.allProfiles == null)
			{
				return 0;
			}
			checked
			{
				using (List<XdfProfile>.Enumerator enumerator = this.allProfiles.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (string.Equals(MapEditorForm.SafeCategory(enumerator.Current), cat, StringComparison.OrdinalIgnoreCase))
						{
							num++;
						}
					}
				}
				return num;
			}
		}

		// Token: 0x0600156A RID: 5482 RVA: 0x000A6A14 File Offset: 0x000A6A14
		private TreeNode CreateLeafNode(XdfProfile prof)
		{
			string text = "\ud83d\udcc4 " + (prof.Name ?? "(unnamed)");
			if (prof.Table != null && prof.Table.Rows == 1 && prof.Table.Cols == 1)
			{
				text += "  (Const)";
			}
			return new TreeNode(text)
			{
				Tag = prof
			};
		}

		// Token: 0x0600156B RID: 5483 RVA: 0x000A6A78 File Offset: 0x000A6A78
		private void UpdateTreeFooter()
		{
			if (this.lblTreeFooter == null)
			{
				return;
			}
			string str = "—";
			try
			{
				if (this.loadedXdf != null)
				{
					str = ((!string.IsNullOrEmpty(this.loadedXdf.Title)) ? this.loadedXdf.Title : ((!string.IsNullOrEmpty(this.loadedXdf.FilePath)) ? Path.GetFileNameWithoutExtension(this.loadedXdf.FilePath) : "—"));
				}
				else if (!string.IsNullOrEmpty(this.loadedXdfPath))
				{
					str = Path.GetFileNameWithoutExtension(this.loadedXdfPath);
				}
			}
			catch
			{
			}
			this.lblTreeFooter.Text = "▸  [Kompatible Ecu : " + str + "]";
		}

		// Token: 0x0600156C RID: 5484 RVA: 0x000A6B30 File Offset: 0x000A6B30
		private static string FmtSmart(double v)
		{
			if (Math.Abs(v) >= 100.0)
			{
				return (checked((long)Math.Round(v))).ToString(CultureInfo.InvariantCulture);
			}
			if (Math.Abs(v - Math.Round(v)) < 0.0005)
			{
				return (checked((long)Math.Round(v))).ToString(CultureInfo.InvariantCulture);
			}
			return v.ToString("0.###", CultureInfo.InvariantCulture);
		}

		// Token: 0x0600156D RID: 5485 RVA: 0x000A6BA4 File Offset: 0x000A6BA4
		private void ToggleRightPanel()
		{
			if (this.splitRight == null || this.splitRight.IsDisposed)
			{
				return;
			}
			this.rightPanelCollapsed = !this.rightPanelCollapsed;
			checked
			{
				try
				{
					if (this.rightPanelCollapsed)
					{
						if (this.splitRight.Panel2.Width > 100)
						{
							this.rightPanelLastWidth = this.splitRight.Panel2.Width;
						}
						this.splitRight.Panel2Collapsed = true;
						if (this.btnToggleRightPanel != null)
						{
							this.btnToggleRightPanel.Text = "◂";
						}
					}
					else
					{
						this.splitRight.Panel2Collapsed = false;
						if (this.btnToggleRightPanel != null)
						{
							this.btnToggleRightPanel.Text = "▸";
						}
						try
						{
							int num = Math.Max(240, this.rightPanelLastWidth);
							int num2 = this.splitRight.Width - this.splitRight.Panel1MinSize - this.splitRight.SplitterWidth;
							if (num > num2)
							{
								num = num2;
							}
							if (num < this.splitRight.Panel2MinSize)
							{
								num = this.splitRight.Panel2MinSize;
							}
							this.splitRight.SplitterDistance = this.splitRight.Width - num - this.splitRight.SplitterWidth;
						}
						catch
						{
						}
					}
					try
					{
						this.splitRight.Panel2.PerformLayout();
					}
					catch
					{
					}
					try
					{
						this.splitRight.PerformLayout();
					}
					catch
					{
					}
					try
					{
						this.splitContainerMain.Panel2.PerformLayout();
					}
					catch
					{
					}
					try
					{
						this.splitContainerMain.PerformLayout();
					}
					catch
					{
					}
					try
					{
						this.mainContent.PerformLayout();
					}
					catch
					{
					}
					if (this.dgvMap != null)
					{
						this.dgvMap.PerformLayout();
						this.dgvMap.Refresh();
						this.dgvMap.Invalidate();
					}
					if (this.preview3DGraph != null && !this.preview3DGraph.IsDisposed)
					{
						this.preview3DGraph.Invalidate();
					}
					if (this.xRuler != null)
					{
						this.xRuler.Invalidate();
					}
					if (this.yRuler != null)
					{
						this.yRuler.Invalidate();
					}
					if (!this.rightPanelCollapsed)
					{
						this.Request3DSync();
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x0600156E RID: 5486 RVA: 0x000A6E64 File Offset: 0x000A6E64
		private void Request3DSync()
		{
			this.pending3DSync = true;
			this.pending3DAttempts = 0;
			if (this.pending3DTimer == null)
			{
				this.pending3DTimer = new System.Windows.Forms.Timer
				{
					Interval = 120
				};
				this.pending3DTimer.Tick += checked(delegate(object s, EventArgs ev)
				{
					this.pending3DAttempts++;
					if (this.TryFlush3DSync() || this.pending3DAttempts > 20)
					{
						try
						{
							if (this.preview3DGraph != null && !this.preview3DGraph.IsDisposed && this.preview3DGraph.IsHandleCreated && this.preview3DGraph.ClientSize.Width > 4 && this.preview3DGraph.ClientSize.Height > 4 && this.preview3DGraph.Visible && this.dgvMap != null && this.dgvMap.Rows.Count >= 2 && this.dgvMap.Columns.Count >= 2 && !this.is1DView)
							{
								this.Sync3DPreviewFromGrid();
								this.preview3DGraph.Invalidate();
								this.preview3DGraph.Refresh();
							}
						}
						catch
						{
						}
						try
						{
							this.pending3DTimer.Stop();
						}
						catch
						{
						}
						this.pending3DSync = false;
					}
				});
			}
			try
			{
				this.pending3DTimer.Stop();
			}
			catch
			{
			}
			try
			{
				this.pending3DTimer.Start();
			}
			catch
			{
			}
			try
			{
				base.BeginInvoke(new Action(delegate()
				{
					if (this.TryFlush3DSync())
					{
						try
						{
							this.pending3DTimer.Stop();
						}
						catch
						{
						}
						this.pending3DSync = false;
					}
				}));
			}
			catch
			{
			}
		}

		// Token: 0x0600156F RID: 5487 RVA: 0x000A6F14 File Offset: 0x000A6F14
		private bool TryFlush3DSync()
		{
			if (!this.pending3DSync)
			{
				return true;
			}
			if (this.preview3DGraph == null || this.preview3DGraph.IsDisposed)
			{
				return false;
			}
			if (this.dgvMap == null || this.dgvMap.Rows.Count < 2 || this.dgvMap.Columns.Count < 2)
			{
				return false;
			}
			if (this.is1DView)
			{
				return true;
			}
			bool result;
			try
			{
				if (!this.preview3DGraph.IsHandleCreated)
				{
					result = false;
				}
				else if (this.preview3DGraph.ClientSize.Width <= 4 || this.preview3DGraph.ClientSize.Height <= 4)
				{
					result = false;
				}
				else if (!this.preview3DGraph.Visible)
				{
					result = false;
				}
				else
				{
					this.Sync3DPreviewFromGrid();
					this.preview3DGraph.Invalidate();
					this.preview3DGraph.Refresh();
					result = true;
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06001570 RID: 5488 RVA: 0x000A7008 File Offset: 0x000A7008
		private double[] ReadAxis(int addr, int elemSize, double scale, double offset, int count)
		{
			double[] array = new double[count];
			checked
			{
				for (int i = 0; i < count; i++)
				{
					array[i] = (double)(i + 1);
				}
				if (addr <= 0 || elemSize <= 0)
				{
					return array;
				}
				for (int j = 0; j < count; j++)
				{
					int num = addr + j * elemSize;
					if (num + elemSize > this.binData.Length)
					{
						break;
					}
					double num2 = unchecked(this.ReadRaw(num, elemSize, false, false, false) * scale + offset);
					array[j] = num2;
				}
				return array;
			}
		}

		// Token: 0x06001571 RID: 5489 RVA: 0x000A7074 File Offset: 0x000A7074
		private bool IsMonotonic(double[] vals)
		{
			if (vals == null || vals.Length < 2)
			{
				return false;
			}
			int num = 0;
			checked
			{
				for (int i = 1; i < vals.Length; i++)
				{
					if (vals[i] > vals[i - 1])
					{
						num++;
					}
					else if (vals[i] == vals[i - 1])
					{
						return false;
					}
				}
			}
			return (double)num >= (double)(checked(vals.Length - 1)) * 0.8;
		}

		// Token: 0x06001572 RID: 5490 RVA: 0x000A70D0 File Offset: 0x000A70D0
		private double[] FindDonorAxis(int count, bool isX)
		{
			if (this.allProfiles == null)
			{
				return null;
			}
			foreach (XdfProfile xdfProfile in this.allProfiles)
			{
				if (xdfProfile != this.currentProfile && xdfProfile.Table != null && (isX ? xdfProfile.Table.Cols : xdfProfile.Table.Rows) == count)
				{
					double[] array = isX ? this.ReadAxis(xdfProfile.Table.XAxisAddress, xdfProfile.Table.XAxisElementSize, xdfProfile.Table.XAxisScale, xdfProfile.Table.XAxisOffset, count) : this.ReadAxis(xdfProfile.Table.YAxisAddress, xdfProfile.Table.YAxisElementSize, xdfProfile.Table.YAxisScale, xdfProfile.Table.YAxisOffset, count);
					if (this.IsMonotonic(array))
					{
						return array;
					}
				}
			}
			return null;
		}

		// Token: 0x06001573 RID: 5491 RVA: 0x000A71E0 File Offset: 0x000A71E0
		private int VisualToByteAddress(XdfTable t, int vRow, int vCol)
		{
			if (vRow < 0 || vCol < 0)
			{
				return -1;
			}
			int rows = t.Rows;
			int cols = t.Cols;
			if (rows <= 0 || cols <= 0)
			{
				return -1;
			}
			bool flag = t.PreferRpmOnTop ^ this.swapAxes;
			int num = flag ? cols : rows;
			int num2 = flag ? rows : cols;
			if (vRow >= num || vCol >= num2)
			{
				return -1;
			}
			int num3 = flag ? vCol : vRow;
			int num4 = flag ? vRow : vCol;
			return checked(t.Address + (num3 * cols + num4) * t.ElementSize);
		}

		// Token: 0x06001574 RID: 5492 RVA: 0x000A7260 File Offset: 0x000A7260
		private void ToggleSwapAxes()
		{
			this.swapAxes = !this.swapAxes;
			if (this.btnSwapAxes != null)
			{
				this.btnSwapAxes.Text = (this.swapAxes ? "\ud83d\udd04 NORMAL" : "\ud83d\udd04 SWAP X/Y");
				this.btnSwapAxes.Invalidate();
			}
			if (this.binData != null && this.currentProfile != null && this.currentProfile.Table != null)
			{
				this.LoadMapView();
				try
				{
					this.BuildLiveAxisCache();
				}
				catch
				{
				}
			}
			if (this.compareForm != null && !this.compareForm.IsDisposed)
			{
				try
				{
					this.compareForm.SetSwapAxes(this.swapAxes);
				}
				catch
				{
				}
			}
			this.SetStatus(this.swapAxes ? "\ud83d\udd04 TAMPILAN DITUKAR — baris ↔ kolom, data asli tidak berubah." : "\ud83d\udd04 TAMPILAN NORMAL.");
		}

		// Token: 0x06001575 RID: 5493 RVA: 0x000A7340 File Offset: 0x000A7340
		private void OpenCompareDialog()
		{
			if (this.binData == null)
			{
				MapEditorForm.CustomMessageBox.Show(this, "Belum ada BIN yang dimuat.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
			if (this.originalBinData == null)
			{
				MapEditorForm.CustomMessageBox.Show(this, "Original BIN tidak tersedia di memori.\nBuka ulang BIN untuk membuat snapshot original.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}
			List<MapEditorForm.CompareForm.DiffEntry> list = this.BuildDiffList();
			XdfTable xdfTable = (this.currentProfile != null) ? this.currentProfile.Table : null;
			checked
			{
				if (xdfTable == null && this.loadedXdf != null && this.loadedXdf.Tables.Count > 0 && list.Count > 0)
				{
					int address = list[0].Address;
					foreach (XdfTable xdfTable2 in this.loadedXdf.Tables)
					{
						int num = xdfTable2.Rows * xdfTable2.Cols * xdfTable2.ElementSize;
						if (address >= xdfTable2.Address && address < xdfTable2.Address + num)
						{
							xdfTable = xdfTable2;
							break;
						}
					}
				}
				if (this.compareForm != null && !this.compareForm.IsDisposed)
				{
					try
					{
						this.compareForm.UpdateData(list, this.binData.Length, this.originalBinData.Length, xdfTable, this.binData, this.originalBinData);
						this.compareForm.SetSwapAxes(this.swapAxes);
						this.compareForm.Activate();
						this.compareForm.BringToFront();
					}
					catch (Exception ex)
					{
						MapEditorForm.CustomMessageBox.Show(this, "Gagal update CompareForm:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					return;
				}
				this.compareForm = null;
				this.compareForm = new MapEditorForm.CompareForm(list, this.binData.Length, this.originalBinData.Length, this.binFilePath ?? "(in-memory)", delegate()
				{
					this.RevertAllToOriginalAndRefresh();
				}, delegate(List<int> addrs)
				{
					this.RevertAddressesToOriginal(addrs);
					this.RefreshAfterRevert();
				}, xdfTable, this.binData, this.originalBinData, this.swapAxes);
				this.compareForm.FormClosed += delegate(object s, FormClosedEventArgs ev)
				{
					try
					{
						this.compareForm.Dispose();
					}
					catch
					{
					}
					this.compareForm = null;
				};
				this.compareForm.Show(this);
				this.compareForm.Activate();
				this.compareForm.BringToFront();
			}
		}

		// Token: 0x06001576 RID: 5494 RVA: 0x000A7590 File Offset: 0x000A7590
		private void RefreshAfterRevert()
		{
			if (this.compareForm != null && !this.compareForm.IsDisposed)
			{
				this.compareForm.UpdateData(this.BuildDiffList(), this.binData.Length, this.originalBinData.Length, (this.currentProfile != null) ? this.currentProfile.Table : null, this.binData, this.originalBinData);
			}
			this.LoadMapView();
			this.Request3DSync();
		}

		// Token: 0x06001577 RID: 5495 RVA: 0x000A7604 File Offset: 0x000A7604
		private List<MapEditorForm.CompareForm.DiffEntry> BuildDiffList()
		{
			List<MapEditorForm.CompareForm.DiffEntry> list = new List<MapEditorForm.CompareForm.DiffEntry>();
			if (this.binData == null || this.originalBinData == null)
			{
				return list;
			}
			int num = Math.Max(this.binData.Length, this.originalBinData.Length);
			List<XdfProfile> list2 = this.allProfiles ?? new List<XdfProfile>();
			checked
			{
				for (int i = 0; i < num; i++)
				{
					byte b = 0;
					if (i >= 0 && i < this.originalBinData.Length)
					{
						b = this.originalBinData[i];
					}
					byte b2 = 0;
					if (i >= 0 && i < this.binData.Length)
					{
						b2 = this.binData[i];
					}
					if (b != b2)
					{
						string tableName = "—";
						string units = "—";
						int tps = 0;
						int rpm = 0;
						XdfProfile xdfProfile = null;
						XdfTable xdfTable = null;
						foreach (XdfProfile xdfProfile2 in list2)
						{
							if (xdfProfile2 != null && xdfProfile2.Table != null)
							{
								XdfTable table = xdfProfile2.Table;
								int num2 = table.Rows * table.Cols * table.ElementSize;
								if (i >= table.Address && i < table.Address + num2)
								{
									xdfProfile = xdfProfile2;
									xdfTable = table;
									break;
								}
							}
						}
						if (xdfTable != null)
						{
							string text;
							if ((text = xdfTable.Title) == null)
							{
								text = (((xdfProfile != null) ? xdfProfile.Name : "—") ?? "—");
							}
							tableName = text;
							units = (xdfTable.MathEquation ?? "—");
							int num3 = i - xdfTable.Address;
							int num4 = (xdfTable.ElementSize > 0) ? (num3 / xdfTable.ElementSize) : 0;
							int num5 = (xdfTable.Cols > 0) ? (num4 % xdfTable.Cols) : 0;
							int num6 = (xdfTable.Cols > 0) ? (num4 / xdfTable.Cols) : 0;
							if (xdfTable.XAxisAddress > 0 && xdfTable.XAxisElementSize > 0)
							{
								int num7 = xdfTable.XAxisAddress + num5 * xdfTable.XAxisElementSize;
								if (num7 + xdfTable.XAxisElementSize <= this.binData.Length)
								{
									tps = (int)Math.Round(unchecked(this.ReadRaw(num7, xdfTable.XAxisElementSize, false, false, false) * xdfTable.XAxisScale + xdfTable.XAxisOffset));
								}
							}
							else
							{
								tps = num5;
							}
							if (xdfTable.YAxisAddress > 0 && xdfTable.YAxisElementSize > 0)
							{
								int num8 = xdfTable.YAxisAddress + num6 * xdfTable.YAxisElementSize;
								if (num8 + xdfTable.YAxisElementSize <= this.binData.Length)
								{
									rpm = (int)Math.Round(unchecked(this.ReadRaw(num8, xdfTable.YAxisElementSize, false, false, false) * xdfTable.YAxisScale + xdfTable.YAxisOffset));
								}
							}
							else
							{
								rpm = num6;
							}
						}
						list.Add(new MapEditorForm.CompareForm.DiffEntry
						{
							Address = i,
							OldByte = b,
							NewByte = b2,
							TableName = tableName,
							Units = units,
							Tps = tps,
							Rpm = rpm
						});
					}
				}
				return list;
			}
		}

		// Token: 0x06001578 RID: 5496 RVA: 0x000A7900 File Offset: 0x000A7900
		private void RevertAllToOriginalAndRefresh()
		{
			if (this.binData == null || this.originalBinData == null)
			{
				return;
			}
			try
			{
				this.undoStack.Push((byte[])this.binData.Clone());
				this.redoStack.Clear();
			}
			catch
			{
			}
			this.binData = (byte[])this.originalBinData.Clone();
			this.hasUnsavedChanges = true;
			this.SetStatus("\ud83d\udd04 Revert ALL ke original selesai.");
			this.RefreshAfterRevert();
		}

		// Token: 0x06001579 RID: 5497 RVA: 0x000A7988 File Offset: 0x000A7988
		private void RevertAddressesToOriginal(List<int> addresses)
		{
			if (this.binData == null || this.originalBinData == null || addresses == null || addresses.Count == 0)
			{
				return;
			}
			try
			{
				this.undoStack.Push((byte[])this.binData.Clone());
				this.redoStack.Clear();
			}
			catch
			{
			}
			foreach (int num in addresses)
			{
				if (num >= 0 && num < this.binData.Length && num < this.originalBinData.Length)
				{
					this.binData[num] = this.originalBinData[num];
				}
			}
			this.hasUnsavedChanges = true;
			this.SetStatus("\ud83d\udd04 Revert " + addresses.Count + " byte ke original.");
		}

		// Token: 0x0600157A RID: 5498 RVA: 0x000A7A74 File Offset: 0x000A7A74
		private void RevertSelectedCellsToOriginal()
		{
			if (this.binData == null || this.originalBinData == null || this.currentProfile == null || this.currentProfile.Table == null)
			{
				MapEditorForm.CustomMessageBox.Show(this, "Tidak ada cell terpilih / tabel.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
			if (this.dgvMap == null || this.dgvMap.SelectedCells.Count == 0)
			{
				return;
			}
			XdfTable table = this.currentProfile.Table;
			List<int> list = new List<int>();
			checked
			{
				foreach (object obj in this.dgvMap.SelectedCells)
				{
					DataGridViewCell dataGridViewCell = (DataGridViewCell)obj;
					if (dataGridViewCell != null && dataGridViewCell.RowIndex >= 0 && dataGridViewCell.ColumnIndex >= 0)
					{
						int num;
						if (this.is1DView)
						{
							if (dataGridViewCell.ColumnIndex != 1)
							{
								continue;
							}
							num = table.Address + dataGridViewCell.RowIndex * table.ElementSize;
						}
						else
						{
							num = this.VisualToByteAddress(table, dataGridViewCell.RowIndex, dataGridViewCell.ColumnIndex);
						}
						if (num >= 0)
						{
							for (int i = 0; i < table.ElementSize; i++)
							{
								list.Add(num + i);
							}
						}
					}
				}
				if (list.Count == 0)
				{
					return;
				}
				this.RevertAddressesToOriginal(list);
				this.RefreshAfterRevert();
			}
		}

		// Token: 0x0600157B RID: 5499 RVA: 0x000A7BCC File Offset: 0x000A7BCC
		private void OpenSelectCompareBins()
		{
			checked
			{
				using (MapEditorForm.SelectCompareBinsForm selectCompareBinsForm = new MapEditorForm.SelectCompareBinsForm())
				{
					if (selectCompareBinsForm.ShowDialog(this) == DialogResult.OK)
					{
						int num = 0;
						for (int i = 0; i < selectCompareBinsForm.EnabledBins.Length; i++)
						{
							if (selectCompareBinsForm.EnabledBins[i])
							{
								num++;
							}
						}
						if (num < 2)
						{
							MapEditorForm.CustomMessageBox.Show(this, "Pilih minimal 2 file BIN untuk dibandingkan.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
						else
						{
							List<string> list = new List<string>();
							for (int j = 0; j < 4; j++)
							{
								if (selectCompareBinsForm.EnabledBins[j] && !string.IsNullOrWhiteSpace(selectCompareBinsForm.SelectedFiles[j]))
								{
									list.Add(selectCompareBinsForm.SelectedFiles[j]);
								}
							}
							List<byte[]> list2 = new List<byte[]>();
							try
							{
								foreach (string path in list)
								{
									list2.Add(File.ReadAllBytes(path));
								}
							}
							catch (Exception ex)
							{
								MapEditorForm.CustomMessageBox.Show(this, "Gagal membaca file BIN:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
								return;
							}
							int num2 = list2[0].Length;
							foreach (byte[] array in list2)
							{
								num2 = Math.Min(num2, array.Length);
							}
							List<MapEditorForm.CompareForm.DiffEntry> list3 = new List<MapEditorForm.CompareForm.DiffEntry>();
							for (int k = 0; k < num2; k++)
							{
								byte b = list2[0][k];
								bool flag = false;
								for (int l = 1; l < list2.Count; l++)
								{
									if (list2[l][k] != b)
									{
										flag = true;
										break;
									}
								}
								if (flag)
								{
									list3.Add(new MapEditorForm.CompareForm.DiffEntry
									{
										Address = k,
										OldByte = list2[0][k],
										NewByte = list2[1][k],
										TableName = Path.GetFileName(list[0]) + " vs " + Path.GetFileName(list[1]),
										Units = "—",
										Tps = 0,
										Rpm = 0
									});
								}
							}
							XdfTable xdfTable = (this.currentProfile != null) ? this.currentProfile.Table : null;
							if (xdfTable != null)
							{
								int num3 = xdfTable.Address + xdfTable.Rows * xdfTable.Cols * xdfTable.ElementSize;
								int num4 = Math.Min(list2[0].Length, list2[1].Length);
								if (num3 > num4)
								{
									xdfTable = null;
								}
							}
							new MapEditorForm.CompareForm(list3, list2[0].Length, list2[1].Length, list[0] + " vs " + list[1], null, null, xdfTable, list2[0], list2[1], false).Show(this);
						}
					}
				}
			}
		}

		// Token: 0x0600157C RID: 5500
		[DllImport("dwmapi.dll")]
		private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

		// Token: 0x0600157D RID: 5501 RVA: 0x000A7F0C File Offset: 0x000A7F0C
		protected override void OnHandleCreated(EventArgs e)
		{
			base.OnHandleCreated(e);
			int num = 1;
			MapEditorForm.DwmSetWindowAttribute(base.Handle, 2, ref num, 4);
			num = 1;
			MapEditorForm.DwmSetWindowAttribute(base.Handle, 3, ref num, 4);
			num = 1;
			MapEditorForm.DwmSetWindowAttribute(base.Handle, 33, ref num, 4);
		}

		// Token: 0x0600157E RID: 5502 RVA: 0x000A7F58 File Offset: 0x000A7F58
		private void ApplyRoundedRegion()
		{
			if (base.ClientSize.Width <= 0 || base.ClientSize.Height <= 0)
			{
				return;
			}
			using (GraphicsPath graphicsPath = this.RoundedRect(new Rectangle(0, 0, base.ClientSize.Width, base.ClientSize.Height), 18))
			{
				Region region = base.Region;
				base.Region = new Region(graphicsPath);
				if (region != null)
				{
					region.Dispose();
				}
			}
		}

		// Token: 0x0600157F RID: 5503 RVA: 0x0000D65E File Offset: 0x0000D65E
		protected override void OnSizeChanged(EventArgs e)
		{
			base.OnSizeChanged(e);
			this.ApplyRoundedRegion();
		}

		// Token: 0x06001580 RID: 5504 RVA: 0x000A7FEC File Offset: 0x000A7FEC
		private static bool IsRealXdfFile(string path)
		{
			bool result;
			try
			{
				if (HexDumpHelper.LooksLikeHexDump(path))
				{
					result = HexDumpHelper.IsXmlPayload(HexDumpHelper.DecodeHexDump(path));
				}
				else
				{
					byte[] array = File.ReadAllBytes(path);
					if (array.Length < 5)
					{
						result = false;
					}
					else
					{
						string @string = Encoding.ASCII.GetString(array, 0, Math.Min(8, array.Length));
						result = (@string.StartsWith("<!--") || @string.StartsWith("<XDF") || @string.StartsWith("<?xml") || @string.StartsWith("<xdf"));
					}
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06001581 RID: 5505 RVA: 0x000A8084 File Offset: 0x000A8084
		private static double EvalMathEquation(string eq, double raw)
		{
			if (string.IsNullOrWhiteSpace(eq))
			{
				return raw;
			}
			string text = eq.Trim();
			if (text.Equals("X", StringComparison.OrdinalIgnoreCase))
			{
				return raw;
			}
			Match match = Regex.Match(text, "^[xX](?:\\s*\\*\\s*([-+]?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?))?(?:\\s*/\\s*([-+]?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?))?(?:\\s*([+-])\\s*(\\d*\\.?\\d+(?:[eE][-+]?\\d+)?))?$");
			if (match.Success)
			{
				double num = 1.0;
				double num2 = 0.0;
				double num3 = 0.0;
				if (match.Groups[1].Success)
				{
					num = double.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture);
				}
				if (match.Groups[2].Success)
				{
					num3 = double.Parse(match.Groups[2].Value, CultureInfo.InvariantCulture);
				}
				if (match.Groups[4].Success)
				{
					num2 = double.Parse(match.Groups[4].Value, CultureInfo.InvariantCulture);
					if (match.Groups[3].Value == "-")
					{
						num2 = -num2;
					}
				}
				if (num3 != 0.0)
				{
					num /= num3;
				}
				return num * raw + num2;
			}
			string text2 = Regex.Replace(text, "x", raw.ToString("R", CultureInfo.InvariantCulture), RegexOptions.IgnoreCase);
			text2 = text2.Replace(",", ".");
			double result;
			try
			{
				List<string> tokens = MapEditorForm.MathTokenize(text2);
				int num4 = 0;
				double num5 = MapEditorForm.MathParseExpr(tokens, ref num4);
				if (double.IsNaN(num5) || double.IsInfinity(num5))
				{
					result = raw;
				}
				else
				{
					result = num5;
				}
			}
			catch
			{
				result = raw;
			}
			return result;
		}

		// Token: 0x06001582 RID: 5506 RVA: 0x0009E5FC File Offset: 0x0009E5FC
		private static List<string> MathTokenize(string s)
		{
			List<string> list = new List<string>();
			int i = 0;
			checked
			{
				while (i < s.Length)
				{
					char c = s[i];
					if (char.IsDigit(c) || c == '.')
					{
						int num = i;
						while (i < s.Length && (char.IsDigit(s[i]) || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || ((s[i] == '+' || s[i] == '-') && i > num && (s[i - 1] == 'e' || s[i - 1] == 'E'))))
						{
							i++;
						}
						list.Add(s.Substring(num, i - num));
					}
					else if (c == '+' || c == '-' || c == '*' || c == '/' || c == '(' || c == ')')
					{
						list.Add(c.ToString());
						i++;
					}
					else
					{
						i++;
					}
				}
				return list;
			}
		}

		// Token: 0x06001583 RID: 5507 RVA: 0x000A822C File Offset: 0x000A822C
		private static double MathParseExpr(List<string> tokens, ref int pos)
		{
			double num = MapEditorForm.MathParseTerm(tokens, ref pos);
			while (pos < tokens.Count && (tokens[pos] == "+" || tokens[pos] == "-"))
			{
				int num2 = pos;
				pos = checked(num2 + 1);
				string a = tokens[num2];
				double num3 = MapEditorForm.MathParseTerm(tokens, ref pos);
				if (a == "+")
				{
					num += num3;
				}
				else
				{
					num -= num3;
				}
			}
			return num;
		}

		// Token: 0x06001584 RID: 5508 RVA: 0x000A82A4 File Offset: 0x000A82A4
		private static double MathParseTerm(List<string> tokens, ref int pos)
		{
			double num = MapEditorForm.MathParseFactor(tokens, ref pos);
			while (pos < tokens.Count && (tokens[pos] == "*" || tokens[pos] == "/"))
			{
				int num2 = pos;
				pos = checked(num2 + 1);
				string a = tokens[num2];
				double num3 = MapEditorForm.MathParseFactor(tokens, ref pos);
				if (a == "*")
				{
					num *= num3;
				}
				else if (num3 != 0.0)
				{
					num /= num3;
				}
			}
			return num;
		}

		// Token: 0x06001585 RID: 5509 RVA: 0x000A8328 File Offset: 0x000A8328
		private static double MathParseFactor(List<string> tokens, ref int pos)
		{
			if (pos >= tokens.Count)
			{
				return 0.0;
			}
			string text = tokens[pos];
			checked
			{
				if (text == "-")
				{
					pos++;
					return unchecked(-MapEditorForm.MathParseFactor(tokens, ref pos));
				}
				if (text == "+")
				{
					pos++;
					return MapEditorForm.MathParseFactor(tokens, ref pos);
				}
				if (text == "(")
				{
					pos++;
					double result = MapEditorForm.MathParseExpr(tokens, ref pos);
					if (pos < tokens.Count && tokens[pos] == ")")
					{
						pos++;
					}
					return result;
				}
				pos++;
				double result2;
				if (!double.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out result2))
				{
					return 0.0;
				}
				return result2;
			}
		}

		// Token: 0x06001586 RID: 5510 RVA: 0x000A83F0 File Offset: 0x000A83F0
		private static double SolveRawForEquation(string eq, double target)
		{
			if (string.IsNullOrWhiteSpace(eq))
			{
				return target;
			}
			string text = eq.Trim();
			if (text.Equals("X", StringComparison.OrdinalIgnoreCase))
			{
				return target;
			}
			Match match = Regex.Match(text, "^[xX](?:\\s*\\*\\s*([-+]?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?))?(?:\\s*/\\s*([-+]?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?))?(?:\\s*([+-])\\s*(\\d*\\.?\\d+(?:[eE][-+]?\\d+)?))?$");
			if (match.Success)
			{
				double num = 1.0;
				double num2 = 0.0;
				double num3 = 0.0;
				if (match.Groups[1].Success)
				{
					num = double.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture);
				}
				if (match.Groups[2].Success)
				{
					num3 = double.Parse(match.Groups[2].Value, CultureInfo.InvariantCulture);
				}
				if (match.Groups[4].Success)
				{
					num2 = double.Parse(match.Groups[4].Value, CultureInfo.InvariantCulture);
					if (match.Groups[3].Value == "-")
					{
						num2 = -num2;
					}
				}
				if (num3 != 0.0)
				{
					num /= num3;
				}
				if (num != 0.0)
				{
					return (target - num2) / num;
				}
				return target;
			}
			else
			{
				double num4 = 0.0;
				double num5 = 65535.0;
				double num6 = MapEditorForm.EvalMathEquation(eq, num4) - target;
				double num7 = MapEditorForm.EvalMathEquation(eq, num5) - target;
				if (num6 == 0.0)
				{
					return num4;
				}
				if (num7 == 0.0)
				{
					return num5;
				}
				if (Math.Sign(num6) == Math.Sign(num7))
				{
					return target;
				}
				for (int i = 0; i < 80; i = checked(i + 1))
				{
					double num8 = (num4 + num5) / 2.0;
					double num9 = MapEditorForm.EvalMathEquation(eq, num8) - target;
					if (Math.Abs(num9) < 1E-07)
					{
						return num8;
					}
					if (Math.Sign(num9) == Math.Sign(num6))
					{
						num4 = num8;
						num6 = num9;
					}
					else
					{
						num5 = num8;
					}
				}
				return (num4 + num5) / 2.0;
			}
		}

		// Token: 0x06001587 RID: 5511 RVA: 0x000A85F8 File Offset: 0x000A85F8
		private void Graph3DForm_PointValueChanged(object sender, Plot3D.Graph3D.PointValueChangedEventArgs e)
		{
			if (e == null)
			{
				return;
			}
			if (this.binData == null || this.currentProfile == null)
			{
				return;
			}
			if (this.suppress3DSync)
			{
				return;
			}
			XdfTable table = this.currentProfile.Table;
			if (table == null || table.ElementSize <= 0)
			{
				return;
			}
			if (this.is1DView)
			{
				return;
			}
			int x = e.X;
			int y = e.Y;
			int num = this.VisualToByteAddress(table, x, y);
			if (num < 0 || checked(num + table.ElementSize) > this.binData.Length)
			{
				return;
			}
			double num2 = MapEditorForm.SolveRawForEquation(table.MathEquation, e.NewValue);
			if (double.IsNaN(num2) || double.IsInfinity(num2))
			{
				return;
			}
			this.WriteRaw(num, table.ElementSize, table.IsSwapped, table.IsFloat, num2);
			this.hasUnsavedChanges = true;
			if (this.dgvMap != null && x >= 0 && x < this.dgvMap.Rows.Count && y >= 0 && y < this.dgvMap.Columns.Count)
			{
				this.suppress3DSync = true;
				try
				{
					string text = MapEditorForm.FmtSmart(e.NewValue);
					object value = this.dgvMap[y, x].Value;
					if (value == null || value.ToString() != text)
					{
						this.dgvMap[y, x].Value = text;
					}
				}
				finally
				{
					this.suppress3DSync = false;
				}
			}
			try
			{
				if (this.preview3DGraph != null && !this.preview3DGraph.IsDisposed)
				{
					this.preview3DGraph.SetValueAt(x, y, e.NewValue);
					this.preview3DGraph.Invalidate();
				}
			}
			catch
			{
			}
			if ((DateTime.Now - this._lastGraph3DHexUpdate).TotalMilliseconds >= 125.0)
			{
				this._lastGraph3DHexUpdate = DateTime.Now;
				this.UpdateHexView();
				this.UpdateCursorLabel();
			}
		}

		// Token: 0x06001588 RID: 5512 RVA: 0x000A87E4 File Offset: 0x000A87E4
		protected override void WndProc(ref Message m)
		{
			base.WndProc(ref m);
			checked
			{
				if (m.Msg == 132 && base.WindowState == FormWindowState.Normal)
				{
					Point point = base.PointToClient(new Point(m.LParam.ToInt32()));
					int num = 8;
					bool flag = point.X <= num;
					bool flag2 = point.X >= base.ClientSize.Width - num;
					bool flag3 = point.Y <= num;
					bool flag4 = point.Y >= base.ClientSize.Height - num;
					if (flag2 && flag4)
					{
						m.Result = (IntPtr)17;
						return;
					}
					if (flag && flag4)
					{
						m.Result = (IntPtr)16;
						return;
					}
					if (flag2 && flag3)
					{
						m.Result = (IntPtr)14;
						return;
					}
					if (flag && flag3)
					{
						m.Result = (IntPtr)13;
						return;
					}
					if (flag4)
					{
						m.Result = (IntPtr)15;
						return;
					}
					if (flag2)
					{
						m.Result = (IntPtr)11;
						return;
					}
					if (flag)
					{
						m.Result = (IntPtr)10;
						return;
					}
					if (flag3)
					{
						m.Result = (IntPtr)12;
					}
				}
			}
		}

		// Token: 0x06001589 RID: 5513 RVA: 0x000A8920 File Offset: 0x000A8920
		private void ApplyResponsiveLayout(bool force)
		{
			checked
			{
				if (this.splitContainerMain != null && this.splitContainerMain.Width > 0)
				{
					try
					{
						int width = this.splitContainerMain.Width;
						int num = 150;
						int num2 = 500;
						this.splitContainerMain.Panel1MinSize = num;
						this.splitContainerMain.Panel2MinSize = num2;
						int num3 = width - num2 - this.splitContainerMain.SplitterWidth;
						int num4 = num;
						if (num3 < num4)
						{
							num3 = num4;
						}
						int num5 = (int)(unchecked((double)width * 0.2));
						if (num5 < num4)
						{
							num5 = num4;
						}
						if (num5 > num3)
						{
							num5 = num3;
						}
						this.splitContainerMain.SplitterDistance = num5;
						this._lastMainRatio = 0.2;
					}
					catch
					{
					}
				}
				if (this.splitRight != null && this.splitRight.Width > 0)
				{
					try
					{
						int width2 = this.splitRight.Width;
						int num6 = 380;
						int num7 = 240;
						this.splitRight.Panel1MinSize = num6;
						this.splitRight.Panel2MinSize = num7;
						int num8 = width2 - num7 - this.splitRight.SplitterWidth;
						int num9 = num6;
						if (num8 < num9)
						{
							num8 = num9;
						}
						int num10 = (int)(unchecked((double)width2 * 0.6875));
						if (num10 < num9)
						{
							num10 = num9;
						}
						if (num10 > num8)
						{
							num10 = num8;
						}
						this.splitRight.SplitterDistance = num10;
						this._lastRightRatio = 0.6875;
					}
					catch
					{
					}
				}
			}
		}

		// Token: 0x0600158A RID: 5514 RVA: 0x000A8AA0 File Offset: 0x000A8AA0
		private void MapEditorForm_Shown(object sender, EventArgs e)
		{
			Rectangle workingArea = Screen.FromControl(this).WorkingArea;
			if (workingArea.Width <= 1400 || workingArea.Height <= 760)
			{
				base.Bounds = workingArea;
			}
			else
			{
				base.WindowState = FormWindowState.Normal;
				base.Size = new Size(1340, 700);
				base.CenterToScreen();
			}
			this.AttachLiveButton();
			this.AttachLiveChartButton();
			this.AttachSpeedometerButton();
			this.RepositionToolbar();
			this.ApplyResponsiveLayout(true);
			this.RebuildTree();
			this.Request3DSync();
		}

		// Token: 0x0600158B RID: 5515 RVA: 0x0000D66D File Offset: 0x0000D66D
		private void MapEditorForm_Resize(object sender, EventArgs e)
		{
			if (base.WindowState == FormWindowState.Minimized)
			{
				return;
			}
			this.ApplyResponsiveLayout(false);
		}

		// Token: 0x0600158C RID: 5516 RVA: 0x0000D680 File Offset: 0x0000D680
		private void MapEditorForm_DpiChanged(object sender, EventArgs e)
		{
			this.ApplyResponsiveLayout(true);
		}

		// Token: 0x060015AD RID: 5549 RVA: 0x000A8F8C File Offset: 0x000A8F8C
		private void Graph2DForm_DataPointValueChanged(int index, double newValue)
		{
			if (this.binData == null || this.currentProfile == null)
			{
				return;
			}
			XdfTable table = this.currentProfile.Table;
			if (table == null || table.ElementSize <= 0)
			{
				return;
			}
			int num;
			int num2;
			int num3;
			if (this.swapAxes)
			{
				num = table.YAxisAddress;
				num2 = table.YAxisElementSize;
				num3 = table.Rows;
			}
			else
			{
				num = table.XAxisAddress;
				num2 = table.XAxisElementSize;
				num3 = table.Cols;
			}
			if (num <= 0)
			{
				num = table.Address;
				num3 = ((table.Cols > 1) ? table.Cols : table.Rows);
				num2 = table.ElementSize;
			}
			if (num <= 0 || num2 <= 0)
			{
				return;
			}
			if (index < 0 || index >= num3)
			{
				return;
			}
			checked
			{
				int num4 = num + index * num2;
				if (num4 < 0 || num4 + num2 > this.binData.Length)
				{
					return;
				}
				try
				{
					this.undoStack.Push((byte[])this.binData.Clone());
					this.redoStack.Clear();
				}
				catch
				{
				}
				double num5 = MapEditorForm.SolveRawForEquation(table.MathEquation, newValue);
				if (double.IsNaN(num5) || double.IsInfinity(num5))
				{
					return;
				}
				this.WriteRaw(num4, num2, table.IsSwapped, table.IsFloat, num5);
				this.hasUnsavedChanges = true;
				if (this.dgvMap != null && this.dgvMap.Rows.Count > 0 && this.dgvMap.Columns.Count > 0)
				{
					this.suppress3DSync = true;
					try
					{
						if (this.is1DView)
						{
							if (index < this.dgvMap.Rows.Count)
							{
								this.dgvMap[1, index].Value = MapEditorForm.FmtSmart(newValue);
							}
						}
						else
						{
							bool flag = table.PreferRpmOnTop ^ this.swapAxes;
							bool flag2 = this.swapAxes;
							if (flag)
							{
								if (this.swapAxes && index < this.dgvMap.Rows.Count)
								{
									this.dgvMap.Rows[index].HeaderCell.Value = newValue.ToString("0");
								}
								else if (!this.swapAxes && index < this.dgvMap.Columns.Count)
								{
									this.dgvMap.Columns[index].HeaderText = newValue.ToString("0");
								}
							}
							else if (this.swapAxes && index < this.dgvMap.Columns.Count)
							{
								this.dgvMap.Columns[index].HeaderText = newValue.ToString("0");
							}
							else if (!this.swapAxes && index < this.dgvMap.Rows.Count)
							{
								this.dgvMap.Rows[index].HeaderCell.Value = newValue.ToString("0");
							}
						}
					}
					catch
					{
					}
					finally
					{
						this.suppress3DSync = false;
					}
				}
				try
				{
					if (this.xRuler != null)
					{
						this.xRuler.Invalidate();
					}
				}
				catch
				{
				}
				try
				{
					if (this.yRuler != null)
					{
						this.yRuler.Invalidate();
					}
				}
				catch
				{
				}
				try
				{
					this.UpdateHexView();
				}
				catch
				{
				}
				try
				{
					this.UpdateCursorLabel();
				}
				catch
				{
				}
				try
				{
					this.Sync3DPreviewFromGrid();
				}
				catch
				{
				}
				try
				{
					if (this.graph3DForm != null && !this.graph3DForm.IsDisposed && !this.is1DView)
					{
						this.Sync3DGraph();
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x060015AE RID: 5550 RVA: 0x000A93C4 File Offset: 0x000A93C4
		private void AttachLiveButton()
		{
			if (this.toolbarPanel == null || this.btnLiveData != null)
			{
				return;
			}
			this.btnLiveData = this.MakeNeonButton("\ud83d\udfe2 LIVE DATA", 0, 10, 118, 32, this.green, Color.FromArgb(0, 180, 120));
			this.btnLiveData.Click += this.BtnLiveData_Click;
			this.toolbarPanel.Controls.Add(this.btnLiveData);
		}

		// Token: 0x060015AF RID: 5551 RVA: 0x000A943C File Offset: 0x000A943C
		private void AttachLiveOverlayAndGridHook()
		{
			if (this.dgvMap == null)
			{
				return;
			}
			this.dgvMap.CellPainting -= this.DgvMap_LivePointer_Paint;
			this.dgvMap.CellPainting += this.DgvMap_LivePointer_Paint;
			this.BuildLiveOverlay();
			this.livePointerVisible = true;
			this.livePointerRow = 0;
			this.livePointerCol = 0;
		}

		// Token: 0x060015B0 RID: 5552 RVA: 0x000A949C File Offset: 0x000A949C
		private void ShowLiveSettings()
		{
			checked
			{
				using (Form dlg = new Form())
				{
					dlg.Text = "Live Data — Settings";
					dlg.FormBorderStyle = FormBorderStyle.None;
					dlg.StartPosition = FormStartPosition.CenterParent;
					dlg.ClientSize = new Size(400, 240);
					dlg.BackColor = this.bgCard;
					dlg.ForeColor = this.fg;
					dlg.Font = new Font("Segoe UI", 9f);
					dlg.MaximizeBox = false;
					dlg.MinimizeBox = false;
					dlg.ShowInTaskbar = false;
					using (GraphicsPath graphicsPath = this.RoundedRect(new Rectangle(0, 0, dlg.Width, dlg.Height), 16))
					{
						dlg.Region = new Region(graphicsPath);
					}
					dlg.Paint += delegate(object s, PaintEventArgs e)
					{
						e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
						Rectangle b = new Rectangle(1, 1, dlg.Width - 3, dlg.Height - 3);
						for (int i = 3; i >= 1; i--)
						{
							using (Pen pen = new Pen(Color.FromArgb((i == 3) ? 40 : ((i == 2) ? 90 : 160), this.cyan), (i == 3) ? 5f : 2f))
							{
								using (GraphicsPath graphicsPath2 = this.RoundedRect(b, 16))
								{
									e.Graphics.DrawPath(pen, graphicsPath2);
								}
							}
						}
						using (Pen pen2 = new Pen(this.cyan, 1.6f))
						{
							using (GraphicsPath graphicsPath3 = this.RoundedRect(b, 16))
							{
								e.Graphics.DrawPath(pen2, graphicsPath3);
							}
						}
						using (Pen pen3 = new Pen(Color.FromArgb(60, Color.White), 1f))
						{
							using (GraphicsPath graphicsPath4 = this.RoundedRect(new Rectangle(3, 3, dlg.Width - 7, dlg.Height - 7), 14))
							{
								e.Graphics.DrawPath(pen3, graphicsPath4);
							}
						}
						using (SolidBrush solidBrush = new SolidBrush(this.cyan))
						{
							e.Graphics.DrawString(dlg.Text, new Font("Segoe UI", 10f, FontStyle.Bold), solidBrush, new PointF(18f, 10f));
						}
					};
					Point dragOffset = Point.Empty;
					dlg.MouseDown += delegate(object s, MouseEventArgs e)
					{
						if (e.Button == MouseButtons.Left)
						{
							dragOffset = e.Location;
						}
					};
					dlg.MouseMove += delegate(object s, MouseEventArgs e)
					{
						if (e.Button == MouseButtons.Left)
						{
							dlg.Location = new Point(dlg.Location.X + e.X - dragOffset.X, dlg.Location.Y + e.Y - dragOffset.Y);
						}
					};
					Label value = new Label
					{
						Text = "FTDI Index:",
						Location = new Point(20, 44),
						AutoSize = true,
						ForeColor = this.cyan,
						BackColor = Color.Transparent
					};
					dlg.Controls.Add(value);
					TextBox txtPort = new TextBox
					{
						Location = new Point(130, 42),
						Width = 240,
						Text = (string.IsNullOrEmpty(this.livePortName) ? "0" : this.livePortName),
						BackColor = this.bgPanel,
						ForeColor = this.cyan,
						BorderStyle = BorderStyle.FixedSingle
					};
					dlg.Controls.Add(txtPort);
					Label value2 = new Label
					{
						Text = "Baud Rate:",
						Location = new Point(20, 80),
						AutoSize = true,
						ForeColor = this.cyan,
						BackColor = Color.Transparent
					};
					dlg.Controls.Add(value2);
					ComboBox cmbBaud = new ComboBox
					{
						Location = new Point(130, 78),
						Width = 240,
						DropDownStyle = ComboBoxStyle.DropDown,
						BackColor = this.bgPanel,
						ForeColor = this.cyan,
						FlatStyle = FlatStyle.Flat
					};
					cmbBaud.Items.AddRange(new object[]
					{
						9600,
						10400,
						19200,
						38400,
						57600,
						115200,
						500000
					});
					cmbBaud.Text = this.liveBaudRate.ToString();
					dlg.Controls.Add(cmbBaud);
					Label value3 = new Label
					{
						Text = "Protocol:",
						Location = new Point(20, 116),
						AutoSize = true,
						ForeColor = this.cyan,
						BackColor = Color.Transparent
					};
					dlg.Controls.Add(value3);
					ComboBox cmbProto = new ComboBox
					{
						Location = new Point(130, 114),
						Width = 240,
						DropDownStyle = ComboBoxStyle.DropDownList,
						BackColor = this.bgPanel,
						ForeColor = this.cyan,
						FlatStyle = FlatStyle.Flat
					};
					cmbProto.Items.AddRange(new object[]
					{
						"Honda K-Line (PGM-FI dat10)",
						"Honda CAN / OBD-II (ELM327)",
						"Generic OBD-II (ISO9141/KWP)"
					});
					cmbProto.SelectedIndex = (int)this.liveProtocol;
					dlg.Controls.Add(cmbProto);
					Label value4 = new Label
					{
						Text = "0 = FTDI pertama, 1 = kedua",
						Location = new Point(130, 156),
						AutoSize = true,
						ForeColor = this.muted,
						BackColor = Color.Transparent
					};
					dlg.Controls.Add(value4);
					Button button = new Button
					{
						Text = "SIMPAN",
						Location = new Point(130, 192),
						Size = new Size(115, 32),
						FlatStyle = FlatStyle.Flat,
						BackColor = this.bgPanel,
						ForeColor = this.cyan
					};
					button.FlatAppearance.BorderColor = this.cyan;
					button.Click += delegate(object s, EventArgs e)
					{
						this.livePortName = txtPort.Text.Trim();
						int num;
						if (int.TryParse(cmbBaud.Text.Trim(), out num))
						{
							this.liveBaudRate = num;
						}
						this.liveProtocol = (MapEditorForm.LiveProtocol)cmbProto.SelectedIndex;
						this.SetStatus(string.Concat(new object[]
						{
							"⚙ Port diset: ",
							this.livePortName,
							" @ ",
							this.liveBaudRate,
							" (",
							this.liveProtocol,
							")"
						}));
						dlg.DialogResult = DialogResult.OK;
						dlg.Close();
					};
					dlg.Controls.Add(button);
					Button button2 = new Button
					{
						Text = "BATAL",
						Location = new Point(255, 192),
						Size = new Size(115, 32),
						FlatStyle = FlatStyle.Flat,
						BackColor = this.bgPanel,
						ForeColor = this.muted
					};
					button2.FlatAppearance.BorderColor = this.muted;
					button2.Click += delegate(object s, EventArgs e)
					{
						dlg.DialogResult = DialogResult.Cancel;
						dlg.Close();
					};
					dlg.Controls.Add(button2);
					dlg.AcceptButton = button;
					dlg.CancelButton = button2;
					dlg.ShowDialog(this);
				}
			}
		}

		// Token: 0x060015B1 RID: 5553 RVA: 0x0000D7A8 File Offset: 0x0000D7A8
		private void BtnLiveData_Click(object sender, EventArgs e)
		{
			if (this.isLiveDataRunning)
			{
				this.StopLiveData();
				return;
			}
			if (string.IsNullOrWhiteSpace(this.livePortName))
			{
				this.ShowLiveSettings();
				if (string.IsNullOrWhiteSpace(this.livePortName))
				{
					return;
				}
			}
			this.StartLiveData();
		}

		// Token: 0x060015B2 RID: 5554 RVA: 0x000A9B78 File Offset: 0x000A9B78
		private void StartLiveData()
		{
			if (this.binData == null || this.currentProfile == null || this.currentProfile.Table == null)
			{
				MapEditorForm.CustomMessageBox.Show(this, "Buka XDF + BIN terlebih dahulu sebelum memulai Live Data Tracking.", "Live Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}
			if (this.is1DView)
			{
				MapEditorForm.CustomMessageBox.Show(this, "Live Data Tracking hanya untuk tabel 2D (RPM x TPS/MAP).", "Live Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}
			if (string.IsNullOrEmpty(this.livePortName))
			{
				this.livePortName = "0";
			}
			if (this.liveBaudRate <= 0)
			{
				this.liveBaudRate = 10400;
			}
			try
			{
				this.AttachLiveOverlayAndGridHook();
				this.BuildLiveAxisCache();
				if (this.liveProtocol == MapEditorForm.LiveProtocol.HondaKLine)
				{
					this.liveReader = new MapEditorForm.LiveDataReader(this, this.livePortName, this.liveBaudRate, this.liveProtocol);
					this.liveReader.Open();
				}
				else
				{
					this._port.PortName = this.livePortName;
					this._port.BaudRate = this.liveBaudRate;
					this._port.ReadTimeout = 200;
					this._port.WriteTimeout = 200;
					this._port.Open();
				}
				if (this.preview3DGraph != null && !this.preview3DGraph.IsDisposed)
				{
					this.preview3DGraph.EnableLiveMode(true);
					this.preview3DGraph.LivePointerSize = 12;
					this.preview3DGraph.ShowLiveLabel = true;
				}
				this._liveCts = new CancellationTokenSource();
				Task.Run(() => this.LoopLiveData());
				this.isLiveDataRunning = true;
				this.livePointerVisible = true;
				this.livePointerRow = 0;
				this.livePointerCol = 0;
				this.SetLiveButtonState(true);
				this.ShowLiveOverlay(true);
				if (this.lblLiveConn != null)
				{
					this.lblLiveConn.Text = "● WAITING";
					this.lblLiveConn.ForeColor = this.gold;
				}
				this.SetStatus(string.Concat(new object[]
				{
					"● LIVE DATA @ ",
					this.livePortName,
					" (",
					this.liveBaudRate,
					" bps, ",
					this.liveProtocol,
					")"
				}));
			}
			catch (Exception ex)
			{
				this.StopLiveDataInternal(false);
				MapEditorForm.CustomMessageBox.Show(this, "Gagal memulai Live Data:\n\n" + ex.GetType().Name + ": " + ex.Message, "Live Data Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.SetStatus("\ud83d\udd34 Live Data gagal: " + ex.Message);
			}
		}

		// Token: 0x060015B3 RID: 5555 RVA: 0x0000D7E0 File Offset: 0x0000D7E0
		private void StopLiveData()
		{
			this.StopLiveDataInternal(true);
		}

		// Token: 0x060015B4 RID: 5556 RVA: 0x000A9DFC File Offset: 0x000A9DFC
		private void SetLiveButtonState(bool running)
		{
			if (this.btnLiveData == null)
			{
				return;
			}
			this.btnLiveData.Text = (running ? "⏹ STOP LIVE" : "\ud83d\udfe2 LIVE DATA");
			this.btnLiveData.ForeColor = (running ? this.danger : this.green);
			this.btnLiveData.Invalidate();
		}

		// Token: 0x060015B5 RID: 5557 RVA: 0x000026F4 File Offset: 0x000026F4
		private void LiveDataTimer_Tick(object sender, EventArgs e)
		{
		}

		// Token: 0x060015B6 RID: 5558 RVA: 0x000A9E54 File Offset: 0x000A9E54
		private void BuildLiveAxisCache()
		{
			if (this.liveRpmValues == null)
			{
				this.liveRpmValues = new List<double>();
			}
			if (this.liveColValues == null)
			{
				this.liveColValues = new List<double>();
			}
			if (this.liveInitialCellValues == null)
			{
				this.liveInitialCellValues = new Dictionary<ValueTuple<int, int>, double>();
			}
			this.liveRpmValues.Clear();
			this.liveColValues.Clear();
			this.liveInitialCellValues.Clear();
			if (this.currentProfile == null || this.currentProfile.Table == null)
			{
				return;
			}
			if (this.dgvMap == null || this.dgvMap.Rows.Count == 0 || this.dgvMap.Columns.Count == 0)
			{
				return;
			}
			XdfTable table = this.currentProfile.Table;
			double[] array = this.ReadAxis(table.YAxisAddress, table.YAxisElementSize, table.YAxisScale, table.YAxisOffset, table.Rows);
			if (!this.IsMonotonic(array))
			{
				double[] array2 = this.FindDonorAxis(table.Rows, false);
				if (array2 != null)
				{
					array = array2;
				}
			}
			checked
			{
				if (array == null || array.Length == 0 || !this.IsMonotonic(array) || (array.Length > 1 && array[0] == 1.0 && array[1] == 2.0))
				{
					array = new double[table.Rows];
					int num = (table.Rows > 1) ? (table.Rows - 1) : 1;
					for (int i = 0; i < table.Rows; i++)
					{
						array[i] = unchecked(800.0 + (double)i * (6400.0 / (double)num));
					}
				}
				this.liveRpmValues.AddRange(array);
				double[] array3 = this.ReadAxis(table.XAxisAddress, table.XAxisElementSize, table.XAxisScale, table.XAxisOffset, table.Cols);
				if (!this.IsMonotonic(array3))
				{
					double[] array4 = this.FindDonorAxis(table.Cols, true);
					if (array4 != null)
					{
						array3 = array4;
					}
				}
				if (array3 == null || array3.Length == 0 || !this.IsMonotonic(array3) || (array3.Length > 1 && array3[0] == 1.0 && array3[1] == 2.0))
				{
					array3 = new double[table.Cols];
					int num2 = (table.Cols > 1) ? (table.Cols - 1) : 1;
					for (int j = 0; j < table.Cols; j++)
					{
						array3[j] = unchecked((double)j * (100.0 / (double)num2));
					}
				}
				this.liveColValues.AddRange(array3);
				double num3 = 0.0;
				for (int k = 0; k < this.liveColValues.Count; k++)
				{
					if (this.liveColValues[k] > num3)
					{
						num3 = this.liveColValues[k];
					}
				}
				this.liveUseMapAxis = (this.liveColValues.Count > 0 && num3 > 120.0);
				for (int l = 0; l < this.dgvMap.Rows.Count; l++)
				{
					for (int m = 0; m < this.dgvMap.Columns.Count; m++)
					{
						object value = this.dgvMap[m, l].Value;
						double value2;
						if (value != null && double.TryParse(value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out value2))
						{
							this.liveInitialCellValues[new ValueTuple<int, int>(l, m)] = value2;
						}
					}
				}
				this.SetStatus(string.Format("CACHE RPM[{0}] {1:0}..{2:0}  |  {3}[{4}] {5:0.#}..{6:0.#}  |  useMapAxis={7}", new object[]
				{
					this.liveRpmValues.Count,
					(this.liveRpmValues.Count > 0) ? this.liveRpmValues[0] : 0.0,
					(this.liveRpmValues.Count > 0) ? this.liveRpmValues[this.liveRpmValues.Count - 1] : 0.0,
					this.liveUseMapAxis ? "MAP" : "TPS",
					this.liveColValues.Count,
					(this.liveColValues.Count > 0) ? this.liveColValues[0] : 0.0,
					(this.liveColValues.Count > 0) ? this.liveColValues[this.liveColValues.Count - 1] : 0.0,
					this.liveUseMapAxis
				}));
			}
		}

		// Token: 0x060015B7 RID: 5559 RVA: 0x000AA2D0 File Offset: 0x000AA2D0
		private int FindClosestIndex(List<double> vals, double target)
		{
			if (vals == null || vals.Count == 0)
			{
				return 0;
			}
			int result = 0;
			double num = double.MaxValue;
			checked
			{
				for (int i = 0; i < vals.Count; i++)
				{
					double num2 = Math.Abs(unchecked(vals[i] - target));
					if (num2 < num)
					{
						num = num2;
						result = i;
					}
				}
				return result;
			}
		}

		// Token: 0x060015B8 RID: 5560 RVA: 0x000AA320 File Offset: 0x000AA320
		private void UpdateLivePointerOnGrid(MapEditorForm.LiveFrame f)
		{
			if (this.dgvMap == null || this.dgvMap.Rows.Count == 0 || this.dgvMap.Columns.Count == 0)
			{
				return;
			}
			if (this.liveRpmValues == null || this.liveRpmValues.Count == 0)
			{
				return;
			}
			if (this.liveColValues == null || this.liveColValues.Count == 0)
			{
				return;
			}
			if (f.RPM < 0 || f.RPM > 12000)
			{
				return;
			}
			int num = this.FindClosestIndex(this.liveRpmValues, (double)f.RPM);
			double num2 = (double)(this.liveUseMapAxis ? f.MAP : f.TPS);
			int num3 = this.FindClosestIndex(this.liveColValues, num2);
			bool flag;
			try
			{
				flag = (this.currentProfile.Table.PreferRpmOnTop ^ this.swapAxes);
			}
			catch
			{
				return;
			}
			int num4 = flag ? num3 : num;
			int num5 = flag ? num : num3;
			if (num4 < 0 || num4 >= this.dgvMap.Rows.Count)
			{
				return;
			}
			if (num5 < 0 || num5 >= this.dgvMap.Columns.Count)
			{
				return;
			}
			int num6 = this.livePointerRow;
			int num7 = this.livePointerCol;
			bool flag2 = num4 != num6 || num5 != num7;
			this.livePointerRow = num4;
			this.livePointerCol = num5;
			this.livePointerVisible = true;
			checked
			{
				if (flag2)
				{
					try
					{
						int num8 = Math.Max(0, Math.Min(num4 - 2, this.dgvMap.Rows.Count - 1));
						if (num8 != this.dgvMap.FirstDisplayedScrollingRowIndex)
						{
							this.dgvMap.FirstDisplayedScrollingRowIndex = num8;
						}
					}
					catch
					{
					}
					try
					{
						int num9 = Math.Max(0, Math.Min(num5 - 1, this.dgvMap.Columns.Count - 1));
						if (num9 != this.dgvMap.FirstDisplayedScrollingColumnIndex)
						{
							this.dgvMap.FirstDisplayedScrollingColumnIndex = num9;
						}
					}
					catch
					{
					}
				}
				try
				{
					if (flag2)
					{
						this.dgvMap.Invalidate();
					}
					else
					{
						Rectangle cellDisplayRectangle = this.dgvMap.GetCellDisplayRectangle(num5, num4, false);
						if (cellDisplayRectangle.Width > 0 && cellDisplayRectangle.Height > 0)
						{
							this.dgvMap.Invalidate(cellDisplayRectangle);
						}
						else
						{
							this.dgvMap.Invalidate();
						}
					}
				}
				catch
				{
				}
				if (this.lblLiveConn != null)
				{
					this.lblLiveConn.Text = string.Format("● LIVE {0} rpm | {1:0}% | R{2}C{3}", new object[]
					{
						f.RPM,
						num2,
						num4,
						num5
					});
					this.lblLiveConn.ForeColor = this.green;
				}
			}
		}

		// Token: 0x060015B9 RID: 5561 RVA: 0x000AA5F4 File Offset: 0x000AA5F4
		private void UpdateLiveStatusLabel(MapEditorForm.LiveFrame f)
		{
			if (this.lblLiveRPM != null)
			{
				this.lblLiveRPM.Text = "RPM: " + f.RPM.ToString(CultureInfo.InvariantCulture);
			}
			if (this.lblLiveTPS != null)
			{
				this.lblLiveTPS.Text = "TPS: " + f.TPS.ToString("0.0", CultureInfo.InvariantCulture) + "%";
			}
			if (this.lblLiveMAP != null)
			{
				this.lblLiveMAP.Text = "MAP: " + f.MAP.ToString("0", CultureInfo.InvariantCulture);
			}
			if (this.lblLiveCL != null)
			{
				this.lblLiveCL.Text = "CL: " + f.CL.ToString("0", CultureInfo.InvariantCulture) + "C";
			}
			if (this.lblLiveConn != null)
			{
				this.lblLiveConn.Text = "● LIVE";
				this.lblLiveConn.ForeColor = this.green;
			}
		}

		// Token: 0x060015BA RID: 5562 RVA: 0x000AA6F8 File Offset: 0x000AA6F8
		private void BuildLiveOverlay()
		{
			if (this.dgvMap == null || this.dgvMap.Parent == null)
			{
				return;
			}
			if (this.liveOverlayPanel != null && !this.liveOverlayPanel.IsDisposed)
			{
				return;
			}
			this.liveOverlayPanel = new Panel
			{
				Size = new Size(240, 132),
				Visible = false,
				BackColor = this.bgCard
			};
			this.liveOverlayPanel.HandleCreated += delegate(object s, EventArgs e)
			{
				using (GraphicsPath graphicsPath = MapEditorForm.CreateRoundedPath(new Rectangle(0, 0, this.liveOverlayPanel.Width, this.liveOverlayPanel.Height), 12))
				{
					this.liveOverlayPanel.Region = new Region(graphicsPath);
				}
			};
			this.liveOverlayPanel.Paint += checked(delegate(object s, PaintEventArgs ev)
			{
				ev.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				ev.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
				Rectangle rect = new Rectangle(1, 1, this.liveOverlayPanel.Width - 3, this.liveOverlayPanel.Height - 3);
				int[] array2 = new int[]
				{
					40,
					90,
					160
				};
				float[] array3 = new float[]
				{
					5f,
					3f,
					1.6f
				};
				for (int j = 0; j < array2.Length; j++)
				{
					using (GraphicsPath graphicsPath = MapEditorForm.CreateRoundedPath(rect, 12))
					{
						using (Pen pen = new Pen(Color.FromArgb(array2[j], 0, 255, 150), array3[j]))
						{
							ev.Graphics.DrawPath(pen, graphicsPath);
						}
					}
				}
				using (GraphicsPath graphicsPath2 = MapEditorForm.CreateRoundedPath(rect, 12))
				{
					using (Pen pen2 = new Pen(Color.FromArgb(0, 255, 150), 1.4f))
					{
						ev.Graphics.DrawPath(pen2, graphicsPath2);
					}
				}
				using (GraphicsPath graphicsPath3 = MapEditorForm.CreateRoundedPath(new Rectangle(3, 3, this.liveOverlayPanel.Width - 7, this.liveOverlayPanel.Height - 7), 10))
				{
					using (Pen pen3 = new Pen(Color.FromArgb(60, Color.White), 1f))
					{
						ev.Graphics.DrawPath(pen3, graphicsPath3);
					}
				}
			});
			this.lblLiveConn = this.NewOverlayLabel("● OFFLINE", 12, 8, this.muted, true);
			this.lblLiveRPM = this.NewOverlayLabel("RPM: -", 12, 28, this.cyan, true);
			this.lblLiveTPS = this.NewOverlayLabel("TPS: -", 12, 48, this.fg, false);
			this.lblLiveMAP = this.NewOverlayLabel("MAP: -", 12, 66, this.fg, false);
			this.lblLiveCL = this.NewOverlayLabel("CL: -", 12, 84, this.fg, false);
			this.lblLiveAFR = this.NewOverlayLabel("AFR: -", 122, 48, this.green, false);
			this.lblLiveIDC = this.NewOverlayLabel("IDC: -", 122, 66, this.gold, false);
			foreach (Control control in new Control[]
			{
				this.lblLiveConn,
				this.lblLiveRPM,
				this.lblLiveTPS,
				this.lblLiveMAP,
				this.lblLiveCL,
				this.lblLiveAFR,
				this.lblLiveIDC
			})
			{
				control.BackColor = Color.Transparent;
				this.liveOverlayPanel.Controls.Add(control);
			}
			this.dgvMap.Parent.Controls.Add(this.liveOverlayPanel);
			this.liveOverlayPanel.BringToFront();
			this.RepositionLiveOverlay();
			this.dgvMap.Parent.Resize += delegate(object s, EventArgs ev)
			{
				this.RepositionLiveOverlay();
			};
		}

		// Token: 0x060015BB RID: 5563 RVA: 0x000AA914 File Offset: 0x000AA914
		private Label NewOverlayLabel(string text, int x, int y, Color fg, bool bold)
		{
			return new Label
			{
				Text = text,
				ForeColor = fg,
				Font = new Font("Consolas", 8.5f, bold ? FontStyle.Bold : FontStyle.Regular),
				Location = new Point(x, y),
				AutoSize = true,
				BackColor = Color.Transparent
			};
		}

		// Token: 0x060015BC RID: 5564 RVA: 0x000AA974 File Offset: 0x000AA974
		private void RepositionLiveOverlay()
		{
			if (this.liveOverlayPanel == null || this.dgvMap == null || this.dgvMap.Parent == null)
			{
				return;
			}
			Control parent = this.dgvMap.Parent;
			this.liveOverlayPanel.Location = checked(new Point(Math.Max(6, parent.ClientSize.Width - this.liveOverlayPanel.Width - 14), Math.Max(6, parent.ClientSize.Height - this.liveOverlayPanel.Height - 14)));
		}

		// Token: 0x060015BD RID: 5565 RVA: 0x0000D7E9 File Offset: 0x0000D7E9
		private void ShowLiveOverlay(bool show)
		{
			if (this.liveOverlayPanel != null)
			{
				this.liveOverlayPanel.Visible = show;
			}
		}

		// Token: 0x060015BE RID: 5566 RVA: 0x000AAA04 File Offset: 0x000AAA04
		private void DgvMap_LivePointer_Paint(object sender, DataGridViewCellPaintingEventArgs e)
		{
			e.Paint(e.CellBounds, DataGridViewPaintParts.All);
			if (!this.isLiveDataRunning || !this.livePointerVisible)
			{
				return;
			}
			if (e.RowIndex < 0 || e.ColumnIndex < 0)
			{
				return;
			}
			if (e.RowIndex != this.livePointerRow || e.ColumnIndex != this.livePointerCol)
			{
				return;
			}
			Rectangle cellBounds = e.CellBounds;
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			int num;
			int num2;
			int num3;
			checked
			{
				num = cellBounds.Left + cellBounds.Width / 2;
				num2 = cellBounds.Top + cellBounds.Height / 2;
				num3 = Math.Max(12, Math.Min(26, Math.Min(cellBounds.Width, cellBounds.Height) - 6));
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(70, 255, 80, 0)))
				{
					e.Graphics.FillEllipse(solidBrush, num - num3 / 2 - 3, num2 - num3 / 2 - 3, num3 + 6, num3 + 6);
				}
				using (SolidBrush solidBrush2 = new SolidBrush(Color.Red))
				{
					using (SolidBrush solidBrush3 = new SolidBrush(Color.White))
					{
						using (SolidBrush solidBrush4 = new SolidBrush(Color.Black))
						{
							e.Graphics.FillEllipse(solidBrush2, num - num3 / 2, num2 - num3 / 2, num3, num3);
							int num4 = (int)(unchecked((double)num3 * 0.65));
							e.Graphics.FillEllipse(solidBrush3, num - num4 / 2, num2 - num4 / 2, num4, num4);
							int num5 = (int)(unchecked((double)num3 * 0.35));
							e.Graphics.FillEllipse(solidBrush4, num - num5 / 2, num2 - num5 / 2, num5, num5);
						}
					}
				}
			}
			float num6 = (float)num3 * 1.35f;
			RectangleF rect = new RectangleF((float)num - num6 / 2f, (float)num2 - num6 / 2f, num6, num6);
			using (Pen pen = new Pen(Color.Black, Math.Max(2.5f, (float)num3 * 0.15f)))
			{
				pen.StartCap = LineCap.Round;
				pen.EndCap = LineCap.Round;
				Color backColor = this.dgvMap.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor;
				if (backColor == Color.Empty)
				{
					backColor = this.dgvMap.DefaultCellStyle.BackColor;
				}
				if (backColor.GetBrightness() < 0.5f)
				{
					pen.Color = Color.Blue;
				}
				else
				{
					pen.Color = Color.Black;
				}
				checked
				{
					for (int i = 0; i < 3; i++)
					{
						float startAngle = unchecked((float)i * 120f - 30f + (float)(this.livePointerPulse * 360.0));
						e.Graphics.DrawArc(pen, rect, startAngle, 80f);
					}
				}
			}
			e.Handled = true;
		}

		// Token: 0x060015BF RID: 5567 RVA: 0x0000D7FF File Offset: 0x0000D7FF
		public void Open()
		{
			this._port.Open();
			this._port.DiscardInBuffer();
			this._port.DiscardOutBuffer();
		}

		// Token: 0x060015C0 RID: 5568 RVA: 0x000AAD38 File Offset: 0x000AAD38
		public new void Dispose()
		{
			try
			{
				if (this._port.IsOpen)
				{
					this._port.Close();
				}
			}
			catch
			{
			}
			try
			{
				this._port.Dispose();
			}
			catch
			{
			}
		}

		// Token: 0x060015C1 RID: 5569 RVA: 0x000AAD90 File Offset: 0x000AAD90
		public MapEditorForm.LiveFrame ReadFrame()
		{
			MapEditorForm.LiveFrame result;
			try
			{
				if (this._protocol == MapEditorForm.LiveProtocol.HondaKLine)
				{
					result = this.ReadHondaKLine();
				}
				else
				{
					result = this.ReadElm327();
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060015C2 RID: 5570 RVA: 0x000AADD0 File Offset: 0x000AADD0
		private MapEditorForm.LiveFrame ReadHondaKLine()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				16,
				8
			};
			try
			{
				this._port.DiscardInBuffer();
				this._port.Write(array, 0, array.Length);
			}
			catch (Exception)
			{
				return null;
			}
			int num = 0;
			Stopwatch stopwatch = Stopwatch.StartNew();
			checked
			{
				while (num < 24 && stopwatch.ElapsedMilliseconds < 350L)
				{
					try
					{
						int bytesToRead = this._port.BytesToRead;
						if (bytesToRead > 0)
						{
							num += this._port.Read(this._rx, num, Math.Min(bytesToRead, this._rx.Length - num));
						}
						else
						{
							Thread.Sleep(2);
						}
					}
					catch
					{
						return null;
					}
				}
				if (num < 6)
				{
					return null;
				}
				if (this._rx[0] == 127)
				{
					return null;
				}
			}
			MapEditorForm.LiveFrame result;
			try
			{
				MapEditorForm.LiveFrame liveFrame = new MapEditorForm.LiveFrame
				{
					RPM = checked(((int)this._rx[4] << 8) + (int)this._rx[5]),
					Valid = true
				};
				if (num >= 8)
				{
					liveFrame.TPS = (float)this._rx[7] / 2f;
				}
				if (num >= 10)
				{
					liveFrame.CL = (float)this._rx[9] - 40f;
				}
				if (num >= 14)
				{
					liveFrame.MAP = (float)this._rx[13];
				}
				if (num >= 21)
				{
					float num2 = (float)(checked(((int)this._rx[18] << 8) + (int)this._rx[19])) / 200f;
					liveFrame.InjectorMs = num2;
					liveFrame.IDC = (float)liveFrame.RPM * num2 / 1200f;
					liveFrame.AD = (float)this._rx[20] / 2f - 64f;
				}
				result = liveFrame;
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060015C3 RID: 5571 RVA: 0x000AAFA0 File Offset: 0x000AAFA0
		private MapEditorForm.LiveFrame ReadElm327()
		{
			int num = this.ReadPid(12, 2);
			if (num < 0)
			{
				return null;
			}
			MapEditorForm.LiveFrame liveFrame = new MapEditorForm.LiveFrame();
			liveFrame.RPM = num / 4;
			liveFrame.Valid = true;
			int num2 = this.ReadPid(17, 1);
			if (num2 >= 0)
			{
				liveFrame.TPS = (float)num2 * 100f / 255f;
			}
			int num3 = this.ReadPid(11, 1);
			if (num3 >= 0)
			{
				liveFrame.MAP = (float)num3;
			}
			int num4 = this.ReadPid(5, 1);
			checked
			{
				if (num4 >= 0)
				{
					liveFrame.CL = (float)(num4 - 40);
				}
				int num5 = this.ReadPid(15, 1);
				if (num5 >= 0)
				{
					liveFrame.IAT = (float)(num5 - 40);
				}
				int num6 = this.ReadPid(20, 2);
				if (num6 >= 0)
				{
					liveFrame.O2V = (float)num6 / 200f;
				}
				int num7 = this.ReadPid(66, 2);
				if (num7 >= 0)
				{
					liveFrame.BatteryV = (float)num7 / 1000f;
				}
				return liveFrame;
			}
		}

		// Token: 0x060015C4 RID: 5572 RVA: 0x000AB084 File Offset: 0x000AB084
		private int ReadPid(byte pid, int bytes)
		{
			checked
			{
				int result;
				try
				{
					this._port.DiscardInBuffer();
					this._port.Write(string.Format("01{0:X2}\r", pid));
					Thread.Sleep(30);
					string text = this._port.ReadExisting();
					if (string.IsNullOrEmpty(text))
					{
						result = -1;
					}
					else
					{
						text = text.Replace("\r", " ").Replace("\n", " ").Replace(">", " ").Trim();
						string text2 = "41" + pid.ToString("X2");
						int num = text.IndexOf(text2, StringComparison.OrdinalIgnoreCase);
						if (num < 0)
						{
							result = -1;
						}
						else
						{
							int num2 = num + text2.Length;
							while (num2 < text.Length && text[num2] == ' ')
							{
								num2++;
							}
							string text3 = text.Substring(num2).Replace(" ", "");
							if (text3.Length < bytes * 2)
							{
								result = -1;
							}
							else
							{
								int num3 = 0;
								for (int i = 0; i < bytes; i++)
								{
									num3 = (num3 << 8 | Convert.ToInt32(text3.Substring(i * 2, 2), 16));
								}
								result = num3;
							}
						}
					}
				}
				catch
				{
					result = -1;
				}
				return result;
			}
		}

		// Token: 0x17000157 RID: 343
		// (get) Token: 0x060015C7 RID: 5575 RVA: 0x0000D838 File Offset: 0x0000D838
		public string PortName
		{
			get
			{
				return this._port.PortName;
			}
		}

		// Token: 0x17000158 RID: 344
		// (get) Token: 0x060015C8 RID: 5576 RVA: 0x0000D845 File Offset: 0x0000D845
		public bool IsOpen
		{
			get
			{
				return this._port.IsOpen;
			}
		}

		// Token: 0x060015C9 RID: 5577 RVA: 0x000AB1E0 File Offset: 0x000AB1E0
		private double GetAxisValue(bool fromRow, int index)
		{
			if (this.dgvMap == null || index < 0)
			{
				return 0.0;
			}
			string text = null;
			try
			{
				if (fromRow)
				{
					if (index < this.dgvMap.Rows.Count)
					{
						DataGridViewRowHeaderCell headerCell = this.dgvMap.Rows[index].HeaderCell;
						object obj = (headerCell != null) ? headerCell.Value : null;
						text = ((obj != null) ? obj.ToString() : null);
					}
				}
				else if (index < this.dgvMap.Columns.Count)
				{
					text = this.dgvMap.Columns[index].HeaderText;
				}
			}
			catch
			{
			}
			double result;
			if (!string.IsNullOrWhiteSpace(text) && MapEditorForm.TryParseLeadingNumber(text, out result))
			{
				return result;
			}
			return (double)index;
		}

		// Token: 0x060015CA RID: 5578 RVA: 0x00053E1C File Offset: 0x00053E1C
		private GraphicsPath CreateRoundedRectPath(Rectangle r, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			checked
			{
				int num = radius * 2;
				if (num > r.Width)
				{
					num = r.Width;
				}
				if (num > r.Height)
				{
					num = r.Height;
				}
				graphicsPath.AddArc(r.X, r.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(r.Right - num, r.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(r.Right - num, r.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(r.X, r.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x060015CB RID: 5579 RVA: 0x000AB2A4 File Offset: 0x000AB2A4
		private void DgvMap_CustomPopup_Paint(object sender, PaintEventArgs e)
		{
			if (!this.isLiveDataRunning)
			{
				return;
			}
			if (this.dgvMap == null || this.dgvMap.IsDisposed)
			{
				return;
			}
			int hoveredRow;
			int hoveredCol;
			if (this.livePointerVisible && this.livePointerRow >= 0 && this.livePointerCol >= 0 && this.livePointerRow < this.dgvMap.Rows.Count && this.livePointerCol < this.dgvMap.Columns.Count)
			{
				hoveredRow = this.livePointerRow;
				hoveredCol = this.livePointerCol;
			}
			else
			{
				if (this._hoveredRow < 0 || this._hoveredCol < 0 || this._hoveredRow >= this.dgvMap.Rows.Count || this._hoveredCol >= this.dgvMap.Columns.Count)
				{
					return;
				}
				hoveredRow = this._hoveredRow;
				hoveredCol = this._hoveredCol;
			}
			double v = 0.0;
			bool flag = false;
			if (this.liveInitialCellValues != null)
			{
				flag = this.liveInitialCellValues.TryGetValue(new ValueTuple<int, int>(hoveredRow, hoveredCol), out v);
			}
			if (!flag)
			{
				object value = this.dgvMap.Rows[hoveredRow].Cells[hoveredCol].Value;
				if (value == null)
				{
					return;
				}
				if (!double.TryParse(value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out v))
				{
					return;
				}
			}
			Rectangle cellDisplayRectangle = this.dgvMap.GetCellDisplayRectangle(hoveredCol, hoveredRow, true);
			if (cellDisplayRectangle.IsEmpty || cellDisplayRectangle.Width <= 0 || cellDisplayRectangle.Height <= 0)
			{
				return;
			}
			if (cellDisplayRectangle.Top < this.dgvMap.ColumnHeadersHeight)
			{
				return;
			}
			double axisValue = this.GetAxisValue(true, hoveredRow);
			double axisValue2 = this.GetAxisValue(false, hoveredCol);
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
			graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			Color color = Color.FromArgb(0, 220, 255);
			int num = 96;
			int num2 = 82;
			int num3 = 8;
			Rectangle rectangle;
			string str;
			string str2;
			string str3;
			checked
			{
				int num4 = cellDisplayRectangle.Left + cellDisplayRectangle.Width / 2;
				int num5 = cellDisplayRectangle.Top + cellDisplayRectangle.Height / 2;
				int num6 = num4 - num / 2;
				int num7 = num5 - MapEditorForm.PointerSize - num2 - 10;
				if (num6 < 5)
				{
					num6 = 5;
				}
				if (num6 + num > this.dgvMap.ClientSize.Width - 5)
				{
					num6 = this.dgvMap.ClientSize.Width - num - 5;
				}
				if (num7 < 5)
				{
					num7 = num5 + MapEditorForm.PointerSize + 12;
				}
				rectangle = new Rectangle(num6, num7, num, num2);
				Point[] array = new Point[]
				{
					new Point(num4 - 8, rectangle.Bottom - 1),
					new Point(num4 + 8, rectangle.Bottom - 1),
					new Point(num4, rectangle.Bottom + 8)
				};
				Rectangle r = new Rectangle(rectangle.X + 4, rectangle.Y + 4, rectangle.Width, rectangle.Height);
				using (GraphicsPath graphicsPath = this.CreateRoundedRectPath(r, num3))
				{
					using (PathGradientBrush pathGradientBrush = new PathGradientBrush(graphicsPath))
					{
						pathGradientBrush.CenterColor = Color.FromArgb(140, 0, 0, 0);
						pathGradientBrush.SurroundColors = new Color[]
						{
							Color.DimGray
						};
						graphics.FillPath(pathGradientBrush, graphicsPath);
					}
				}
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(25, 25, 32)))
				{
					graphics.FillPolygon(solidBrush, array);
				}
				using (GraphicsPath graphicsPath2 = this.CreateRoundedRectPath(rectangle, num3))
				{
					using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(rectangle, Color.FromArgb(8, 8, 10), Color.FromArgb(20, 22, 28), LinearGradientMode.Vertical))
					{
						graphics.FillPath(linearGradientBrush, graphicsPath2);
					}
					int[] array2 = new int[]
					{
						40,
						90,
						160
					};
					float[] array3 = new float[]
					{
						5f,
						3f,
						1.6f
					};
					for (int i = 0; i < array2.Length; i++)
					{
						using (Pen pen = new Pen(Color.FromArgb(array2[i], color), array3[i]))
						{
							graphics.DrawPath(pen, graphicsPath2);
						}
					}
					using (Pen pen2 = new Pen(color, 1.4f))
					{
						graphics.DrawPath(pen2, graphicsPath2);
					}
					Rectangle r2 = new Rectangle(rectangle.X + 2, rectangle.Y + 2, rectangle.Width - 5, rectangle.Height - 5);
					using (GraphicsPath graphicsPath3 = this.CreateRoundedRectPath(r2, Math.Max(2, num3 - 2)))
					{
						using (Pen pen3 = new Pen(Color.FromArgb(60, Color.White), 1f))
						{
							graphics.DrawPath(pen3, graphicsPath3);
						}
					}
				}
				using (Pen pen4 = new Pen(Color.FromArgb(120, color), 1.4f))
				{
					graphics.DrawLine(pen4, array[0], array[2]);
					graphics.DrawLine(pen4, array[1], array[2]);
				}
				str = MapEditorForm.FormatSmart(axisValue);
				str2 = MapEditorForm.FormatSmart(v);
				str3 = MapEditorForm.FormatSmart(axisValue2);
			}
			float x = (float)rectangle.X + 10f;
			float num8 = (float)rectangle.Y + 6f;
			using (Font font = new Font("Tahoma", 8.5f, FontStyle.Bold | FontStyle.Italic))
			{
				using (Font font2 = new Font("Consolas", 12f, FontStyle.Bold))
				{
					using (SolidBrush solidBrush2 = new SolidBrush(Color.OrangeRed))
					{
						using (SolidBrush solidBrush3 = new SolidBrush(Color.Cyan))
						{
							using (SolidBrush solidBrush4 = new SolidBrush(Color.Lime))
							{
								graphics.DrawString("X:" + str, font, solidBrush2, x, num8);
								float num9 = num8 + (float)font.Height + 2f;
								graphics.DrawString("Z:" + str2, font2, solidBrush3, x, num9);
								float y = num9 + (float)font2.Height + 3f;
								graphics.DrawString("Y:" + str3, font, solidBrush4, x, y);
							}
						}
					}
				}
			}
		}

		// Token: 0x060015CC RID: 5580 RVA: 0x000ABA7C File Offset: 0x000ABA7C
		private void DrawIntegratedPopup(Graphics g, int centerX, int centerY, double cellValue, double axisX, double axisY)
		{
			Color color = Color.FromArgb(0, 220, 255);
			int num = 90;
			int num2 = 78;
			int num3 = 8;
			int pointerSize = MapEditorForm.PointerSize;
			Rectangle rectangle;
			string s;
			string s2;
			string s3;
			float x;
			checked
			{
				int num4 = (int)g.VisibleClipBounds.Width;
				int num5 = (int)g.VisibleClipBounds.Height;
				int num6 = centerX - num / 2;
				int num7 = centerY - pointerSize - num2 - 10;
				if (num6 < 5)
				{
					num6 = 5;
				}
				if (num6 + num > num4 - 5)
				{
					num6 = num4 - num - 5;
				}
				if (num7 < 5)
				{
					num7 = centerY + pointerSize + 12;
				}
				if (num7 + num2 > num5 - 5)
				{
					num7 = num5 - num2 - 5;
				}
				rectangle = new Rectangle(num6, num7, num, num2);
				Point[] array = new Point[]
				{
					new Point(centerX - 8, rectangle.Bottom - 1),
					new Point(centerX + 8, rectangle.Bottom - 1),
					new Point(centerX, rectangle.Bottom + 8)
				};
				Rectangle r = new Rectangle(rectangle.X + 4, rectangle.Y + 4, rectangle.Width, rectangle.Height);
				g.SmoothingMode = SmoothingMode.AntiAlias;
				g.PixelOffsetMode = PixelOffsetMode.HighQuality;
				using (GraphicsPath graphicsPath = this.CreateRoundedRectPath(r, num3))
				{
					using (PathGradientBrush pathGradientBrush = new PathGradientBrush(graphicsPath))
					{
						pathGradientBrush.CenterColor = Color.FromArgb(140, 0, 0, 0);
						pathGradientBrush.SurroundColors = new Color[]
						{
							Color.DimGray
						};
						g.FillPath(pathGradientBrush, graphicsPath);
					}
				}
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(25, 25, 32)))
				{
					g.FillPolygon(solidBrush, array);
				}
				using (GraphicsPath graphicsPath2 = this.CreateRoundedRectPath(rectangle, num3))
				{
					using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(rectangle, Color.FromArgb(8, 8, 10), Color.FromArgb(20, 22, 28), LinearGradientMode.Vertical))
					{
						g.FillPath(linearGradientBrush, graphicsPath2);
					}
					int[] array2 = new int[]
					{
						40,
						90,
						160
					};
					float[] array3 = new float[]
					{
						5f,
						3f,
						1.6f
					};
					for (int i = 0; i < array2.Length; i++)
					{
						using (GraphicsPath graphicsPath3 = this.CreateRoundedRectPath(rectangle, num3))
						{
							using (Pen pen = new Pen(Color.FromArgb(array2[i], color), array3[i]))
							{
								g.DrawPath(pen, graphicsPath3);
							}
						}
					}
					using (Pen pen2 = new Pen(color, 1.4f))
					{
						g.DrawPath(pen2, graphicsPath2);
					}
					Rectangle r2 = new Rectangle(rectangle.X + 2, rectangle.Y + 2, rectangle.Width - 5, rectangle.Height - 5);
					using (GraphicsPath graphicsPath4 = this.CreateRoundedRectPath(r2, Math.Max(2, num3 - 2)))
					{
						using (Pen pen3 = new Pen(Color.FromArgb(60, Color.White), 1f))
						{
							g.DrawPath(pen3, graphicsPath4);
						}
					}
				}
				using (Pen pen4 = new Pen(Color.FromArgb(120, color), 1.4f))
				{
					g.DrawLine(pen4, array[0], array[2]);
					g.DrawLine(pen4, array[1], array[2]);
				}
				s = string.Format("X:{0:F0}", axisX);
				s2 = string.Format("Z:{0:F3}", cellValue);
				s3 = string.Format("Y:{0:F1}", axisY);
				x = (float)(rectangle.X + 14);
			}
			float num8 = (float)rectangle.Y + 6f;
			using (Font font = new Font("TAHOMA", 10f, FontStyle.Bold | FontStyle.Italic))
			{
				using (Font font2 = new Font("ds-digital", 15f, FontStyle.Bold))
				{
					using (Font font3 = new Font("TAHOMA", 10f, FontStyle.Bold | FontStyle.Italic))
					{
						using (SolidBrush solidBrush2 = new SolidBrush(Color.OrangeRed))
						{
							using (SolidBrush solidBrush3 = new SolidBrush(Color.FromArgb(0, 220, 255)))
							{
								using (SolidBrush solidBrush4 = new SolidBrush(Color.Lime))
								{
									g.DrawString(s, font, solidBrush2, x, num8);
									float num9 = num8 + (float)font.Height + 2f;
									g.DrawString(s2, font2, solidBrush3, x, num9);
									float y = num9 + (float)font2.Height + 3f;
									g.DrawString(s3, font3, solidBrush4, x, y);
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x17000159 RID: 345
		// (get) Token: 0x060015CE RID: 5582 RVA: 0x0000D85B File Offset: 0x0000D85B
		// (set) Token: 0x060015CF RID: 5583 RVA: 0x0000D862 File Offset: 0x0000D862
		public static int PointerSize { get; set; } = 10;

		// Token: 0x060015D3 RID: 5587 RVA: 0x0000D8AA File Offset: 0x0000D8AA
		private static string FormatSmart(double v)
		{
			if (Math.Abs(v - Math.Round(v)) < 0.0001)
			{
				return v.ToString("F0", CultureInfo.InvariantCulture);
			}
			return v.ToString("0.###", CultureInfo.InvariantCulture);
		}

		// Token: 0x060015D4 RID: 5588 RVA: 0x000AC0EC File Offset: 0x000AC0EC
		private static bool TryParseLeadingNumber(string s, out double value)
		{
			value = 0.0;
			if (string.IsNullOrWhiteSpace(s))
			{
				return false;
			}
			StringBuilder stringBuilder = new StringBuilder();
			bool flag = false;
			foreach (char c in s)
			{
				if (char.IsDigit(c) || c == '.' || c == ',' || c == '-')
				{
					stringBuilder.Append((c == ',') ? '.' : c);
					flag = true;
				}
				else if (flag)
				{
					break;
				}
			}
			return stringBuilder.Length != 0 && double.TryParse(stringBuilder.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out value);
		}

		// Token: 0x060015D8 RID: 5592 RVA: 0x000AC3B8 File Offset: 0x000AC3B8
		private void StopLiveDataInternal(bool showMessage)
		{
			if (this._liveCts != null)
			{
				try
				{
					this._liveCts.Cancel();
				}
				catch
				{
				}
			}
			if (this._liveLoopTask != null)
			{
				try
				{
					this._liveLoopTask.Wait(500);
				}
				catch
				{
				}
				this._liveLoopTask = null;
			}
			if (this._liveCts != null)
			{
				try
				{
					this._liveCts.Dispose();
				}
				catch
				{
				}
				this._liveCts = null;
			}
			if (this.liveReader != null)
			{
				try
				{
					this.liveReader.Dispose();
				}
				catch
				{
				}
				this.liveReader = null;
			}
			try
			{
				if (this._port != null && this._port.IsOpen)
				{
					this._port.Close();
				}
			}
			catch
			{
			}
			this.isLiveDataRunning = false;
			this.livePointerVisible = false;
			this.livePointerRow = -1;
			this.livePointerCol = -1;
			this.lastLiveFrame = null;
			if (this.preview3DGraph != null && !this.preview3DGraph.IsDisposed)
			{
				try
				{
					this.preview3DGraph.ClearLivePointer();
					this.preview3DGraph.EnableLiveMode(false);
				}
				catch
				{
				}
			}
			this.SetLiveButtonState(false);
			this.ShowLiveOverlay(false);
			this.StopLiveChartTimer();
			if (this._liveChart != null && !this._liveChart.IsDisposed)
			{
				this._liveChart.Close();
				this._liveChart = null;
			}
			if (this.btnLiveChart != null)
			{
				this.btnLiveChart.Text = "\ud83d\udcc8 LIVE CHART";
				this.btnLiveChart.ForeColor = this.cyan;
				this.btnLiveChart.Invalidate();
			}
			try
			{
				this.dgvMap.Invalidate();
			}
			catch
			{
			}
			this.StopLiveChartTimer();
			if (this._liveChart != null && !this._liveChart.IsDisposed)
			{
				this._liveChart.Close();
				this._liveChart = null;
			}
			if (this._speedDashboard != null && !this._speedDashboard.IsDisposed)
			{
				this._speedDashboard.Close();
				this._speedDashboard = null;
			}
			if (this.btnLiveChart != null)
			{
				this.btnLiveChart.Text = "\ud83d\udcc8 LIVE CHART";
				this.btnLiveChart.ForeColor = this.cyan;
				this.btnLiveChart.Invalidate();
			}
			if (this.btnSpeedometer != null)
			{
				this.btnSpeedometer.Text = "⚡ SPEEDO";
				this.btnSpeedometer.ForeColor = this.gold;
				this.btnSpeedometer.Invalidate();
			}
			if (showMessage)
			{
				this.SetStatus("\ud83d\udd34 Live Data Tracking dihentikan.");
			}
		}

		// Token: 0x060015D9 RID: 5593 RVA: 0x000AC65C File Offset: 0x000AC65C
		private void dat10()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				16,
				8
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			if (this.liveReader == null)
			{
				return;
			}
			if (!this.liveReader.SendCommand(array, array.Length, ref array2, ref num, 0))
			{
				return;
			}
			if (num < 6U)
			{
				this.tek10 = false;
				return;
			}
			if (array2[0] == 127)
			{
				this.tek10 = false;
				return;
			}
			try
			{
				this.RPMD = checked(((int)array2[4] << 8) + (int)array2[5]);
				if (num >= 8U)
				{
					this.TPSD = (float)array2[7] / 2f;
				}
				if (num >= 10U)
				{
					this.CL = (float)array2[9] - 40f;
				}
				if (num >= 14U)
				{
					this.MAP = (float)array2[13];
				}
				if (num >= 21U)
				{
					this.AD = (float)array2[20] / 2f - 64f;
					this.inj = (float)(checked(((int)array2[18] << 8) + (int)array2[19])) / 200f;
					this.IDC = (float)this.RPMD * this.inj / 1200f;
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding dat10: " + ex.Message);
			}
			this.dat20();
			this.UpdateLiveStatusLabelFromFields();
			this.ApplyLivePointerFromFields();
		}

		// Token: 0x060015DA RID: 5594 RVA: 0x000AC798 File Offset: 0x000AC798
		private void dat11()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				17,
				7
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			if (this.liveReader == null)
			{
				return;
			}
			if (!this.liveReader.SendCommand(array, array.Length, ref array2, ref num, 0))
			{
				return;
			}
			if (num < 6U)
			{
				this.tek11 = false;
				return;
			}
			if (array2[0] == 127)
			{
				this.tek11 = false;
				return;
			}
			try
			{
				this.RPMD = checked(((int)array2[4] << 8) + (int)array2[5]);
				if (num >= 8U)
				{
					this.TPSD = (float)array2[7] / 2f;
				}
				if (num >= 10U)
				{
					this.CL = (float)array2[9] - 40f;
				}
				if (num >= 14U)
				{
					this.MAP = (float)array2[13];
				}
				if (num >= 21U)
				{
					this.AD = (float)array2[20] / 2f - 64f;
					this.inj = (float)(checked(((int)array2[18] << 8) + (int)array2[19])) / 200f;
					this.IDC = (float)this.RPMD * this.inj / 1200f;
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding dat11: " + ex.Message);
			}
			this.dat20();
			this.UpdateLiveStatusLabelFromFields();
			this.ApplyLivePointerFromFields();
		}

		// Token: 0x060015DB RID: 5595 RVA: 0x000AC8D4 File Offset: 0x000AC8D4
		private void dat13()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				19,
				5
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			if (this.liveReader == null)
			{
				return;
			}
			if (!this.liveReader.SendCommand(array, array.Length, ref array2, ref num, 0))
			{
				return;
			}
			Console.WriteLine("Response 13: " + BitConverter.ToString(array2, 0, checked((int)num)));
			if (num < 6U)
			{
				this.tek13 = false;
				return;
			}
			if (array2[1] == 5)
			{
				this.tek13 = false;
				return;
			}
			try
			{
				this.RPMD = checked(((int)array2[4] << 8) + (int)array2[5]);
				this.TPSD = (float)array2[7] / 2f;
				float num2 = (float)array2[8] * 5f / 256f;
				this.CL = (float)array2[9] - 40f;
				this.MAP = (float)array2[13];
				if (num > 17U)
				{
					this.AD = (float)array2[17] / 2f - 64f;
				}
				if (num > 16U)
				{
					this.inj = (float)(checked(((int)array2[15] << 8) + (int)array2[16])) / 200f;
				}
				this.IDC = (float)this.RPMD * this.inj / 1200f;
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding dat13: " + ex.Message);
			}
			this.dat20();
			this.UpdateLiveStatusLabelFromFields();
			this.ApplyLivePointerFromFields();
		}

		// Token: 0x060015DC RID: 5596 RVA: 0x000ACA30 File Offset: 0x000ACA30
		private void dat16()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				22,
				2
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			if (this.liveReader == null)
			{
				return;
			}
			if (!this.liveReader.SendCommand(array, array.Length, ref array2, ref num, 0))
			{
				return;
			}
			Console.WriteLine("Response 16: " + BitConverter.ToString(array2, 0, checked((int)num)));
			if (num < 6U)
			{
				this.tek16 = false;
				return;
			}
			if (array2[1] == 5)
			{
				this.tek16 = false;
				return;
			}
		}

		// Token: 0x060015DD RID: 5597 RVA: 0x000ACAB0 File Offset: 0x000ACAB0
		private void dat17()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				23,
				1
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			if (this.liveReader == null)
			{
				return;
			}
			if (!this.liveReader.SendCommand(array, array.Length, ref array2, ref num, 0))
			{
				return;
			}
			if (num < 6U)
			{
				this.tek17 = false;
				return;
			}
			if (array2[1] == 5)
			{
				this.tek17 = false;
				return;
			}
			try
			{
				this.RPMD = checked(((int)array2[4] << 8) + (int)array2[5]);
				this.TPSD = (float)array2[7] / 2f;
				if (num > 12U && array2[12] != 255)
				{
					float num2 = (float)array2[12] * 5f / 256f;
				}
				else if (num > 8U)
				{
					float num3 = (float)array2[8] * 5f / 256f;
				}
				if (num > 13U)
				{
					this.CL = ((array2[13] != byte.MaxValue) ? ((float)array2[13] - 40f) : ((float)array2[9] - 40f));
				}
				if (num > 17U)
				{
					this.AD = (float)array2[17] / 2f - 64f;
				}
				if (num > 16U)
				{
					this.inj = (float)(checked(((int)array2[15] << 8) + (int)array2[16])) / 200f;
				}
				this.IDC = (float)this.RPMD * this.inj / 1200f;
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding dat17: " + ex.Message);
			}
			this.dat20();
			this.UpdateLiveStatusLabelFromFields();
			this.ApplyLivePointerFromFields();
		}

		// Token: 0x060015DE RID: 5598 RVA: 0x000ACC2C File Offset: 0x000ACC2C
		private void dat20()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				32,
				248
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			if (this.liveReader == null)
			{
				return;
			}
			if (!this.liveReader.SendCommand(array, array.Length, ref array2, ref num, 0))
			{
				return;
			}
			if (num < 5U)
			{
				return;
			}
			try
			{
				this.O2V = (float)(array2[4] & byte.MaxValue) / 195.19519f;
				this.O2V2 = (float)(array2[4] & byte.MaxValue) / 50.9937f;
				this.AFR = -5.351f * this.O2V2 + 17.7f;
				this.NILAI = (float)this.MapVoltageToValue((double)this.O2V2);
				float num2 = -100f;
				float num3 = 25f;
				this.nilaiPersen = (this.NILAI - num2) / (num3 - num2) * 100f;
				if (this.nilaiPersen < 0f)
				{
					this.nilaiPersen = 0f;
				}
				if (this.nilaiPersen > 100f)
				{
					this.nilaiPersen = 100f;
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060015DF RID: 5599 RVA: 0x000ACD44 File Offset: 0x000ACD44
		public double MapVoltageToValue(double voltage)
		{
			double[] array = new double[]
			{
				0.0,
				0.961,
				1.922,
				2.883,
				3.844
			};
			double[] array2 = new double[]
			{
				25.0,
				0.0,
				-25.0,
				-50.0,
				-75.0
			};
			if (voltage <= array[0])
			{
				return array2[0];
			}
			if (voltage >= array[4])
			{
				return array2[4];
			}
			checked
			{
				for (int i = 0; i < array.Length - 1; i++)
				{
					if (voltage >= array[i] && voltage <= array[i + 1])
					{
						unchecked
						{
							double num = (voltage - array[i]) / (array[checked(i + 1)] - array[i]);
							return array2[i] + num * (array2[checked(i + 1)] - array2[i]);
						}
					}
				}
				return 0.0;
			}
		}

		// Token: 0x060015E0 RID: 5600 RVA: 0x000ACDD0 File Offset: 0x000ACDD0
		public double MapVoltageToValueig(double voltage)
		{
			double[] array = new double[]
			{
				0.0,
				0.5,
				1.0,
				2.0,
				3.0
			};
			double[] array2 = new double[]
			{
				15.0,
				0.0,
				5.0,
				10.0,
				15.0
			};
			if (voltage <= array[0])
			{
				return array2[0];
			}
			if (voltage >= array[4])
			{
				return array2[4];
			}
			checked
			{
				for (int i = 0; i < array.Length - 1; i++)
				{
					if (voltage >= array[i] && voltage <= array[i + 1])
					{
						unchecked
						{
							double num = (voltage - array[i]) / (array[checked(i + 1)] - array[i]);
							return array2[i] + num * (array2[checked(i + 1)] - array2[i]);
						}
					}
				}
				return 0.0;
			}
		}

		// Token: 0x060015E1 RID: 5601 RVA: 0x000ACE5C File Offset: 0x000ACE5C
		private void UpdateLiveStatusLabelFromFields()
		{
			this.lastLiveFrame = new MapEditorForm.LiveFrame
			{
				RPM = this.RPMD,
				TPS = this.TPSD,
				CL = this.CL,
				MAP = this.MAP,
				AD = this.AD,
				InjectorMs = this.inj,
				IDC = this.IDC,
				O2V = this.O2V,
				AFR = this.AFR,
				Valid = (this.RPMD >= 0)
			};
			this.UpdateLiveStatusLabel(this.lastLiveFrame);
			this.livePointerPulse = (this.livePointerPulse + 0.15) % 1.0;
		}

		// Token: 0x060015E2 RID: 5602 RVA: 0x0000D8EF File Offset: 0x0000D8EF
		private void ApplyLivePointerFromFields()
		{
			if (this.lastLiveFrame != null && this.lastLiveFrame.Valid)
			{
				this.UpdateLivePointerOnGrid(this.lastLiveFrame);
			}
		}

		// Token: 0x060015E8 RID: 5608 RVA: 0x000ACF20 File Offset: 0x000ACF20
		public MapEditorForm.LiveFrame DecodeDat17(byte[] r, uint len)
		{
			if (len < 6U)
			{
				return null;
			}
			MapEditorForm.LiveFrame result;
			try
			{
				int num = (int)r[4] << 8 | (int)r[5];
				float tps = 0f;
				float cl = 0f;
				float ad = 0f;
				float num2 = 0f;
				if (len >= 8U)
				{
					tps = (float)r[7] / 2f;
				}
				if (len >= 14U)
				{
					cl = ((r[13] != byte.MaxValue) ? ((float)r[13] - 40f) : ((float)r[9] - 40f));
				}
				if (len >= 18U)
				{
					ad = (float)r[17] / 2f - 64f;
				}
				if (len >= 17U)
				{
					num2 = (float)((int)r[15] << 8 | (int)r[16]) / 200f;
				}
				result = new MapEditorForm.LiveFrame
				{
					RPM = num,
					TPS = tps,
					CL = cl,
					MAP = 0f,
					AD = ad,
					InjectorMs = num2,
					IDC = (float)num * num2 / 1200f,
					Valid = (len >= 6U)
				};
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060015E9 RID: 5609 RVA: 0x000AD030 File Offset: 0x000AD030
		public MapEditorForm.LiveFrame DecodeDat11(byte[] r, uint len)
		{
			if (len < 6U)
			{
				return null;
			}
			MapEditorForm.LiveFrame result;
			try
			{
				int rpm = (int)r[4] << 8 | (int)r[5];
				float tps = 0f;
				float cl = 0f;
				float iat = 0f;
				if (len >= 8U)
				{
					tps = (float)r[7] / 2f;
				}
				if (len >= 10U)
				{
					cl = (float)r[9] - 40f;
				}
				if (len >= 14U)
				{
					iat = (float)r[13] - 40f;
				}
				result = new MapEditorForm.LiveFrame
				{
					RPM = rpm,
					TPS = tps,
					CL = cl,
					IAT = iat,
					Valid = (len >= 6U)
				};
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060015EA RID: 5610 RVA: 0x000AD0DC File Offset: 0x000AD0DC
		private async Task LoopLiveData(CancellationToken token)
		{
			this.LoopLiveData();
		}

		// Token: 0x060015EB RID: 5611 RVA: 0x000AD124 File Offset: 0x000AD124
		private async Task LoopLiveData()
		{
			CancellationTokenSource cancellationTokenSource = this._liveCts;
			if (cancellationTokenSource != null)
			{
				CancellationToken token = cancellationTokenSource.Token;
				try
				{
					while (!token.IsCancellationRequested)
					{
						try
						{
							await Task.Delay(50, token).ConfigureAwait(false);
							if (token.IsCancellationRequested)
							{
								break;
							}
							if (this.liveReader == null)
							{
								break;
							}
							this.dat11();
							this.dat10();
							this.dat13();
							this.dat16();
							this.dat17();
							if (base.IsHandleCreated && !base.IsDisposed)
							{
								base.BeginInvoke(new Action(delegate()
								{
									if (token.IsCancellationRequested)
									{
										return;
									}
									if (this.IsDisposed)
									{
										return;
									}
									if (this.lastLiveFrame == null)
									{
										this.lastLiveFrame = new MapEditorForm.LiveFrame();
									}
									this.SyncPreview3DPointer();
								}));
							}
						}
						catch (TaskCanceledException)
						{
							break;
						}
						catch (ObjectDisposedException)
						{
							break;
						}
						catch (Exception)
						{
						}
					}
				}
				catch (OperationCanceledException)
				{
				}
				catch (ObjectDisposedException)
				{
				}
				catch (Exception ex)
				{
					Exception ex2;
					Exception ex = ex2;
					if (!token.IsCancellationRequested && base.IsHandleCreated && !base.IsDisposed)
					{
						base.BeginInvoke(new Action(delegate()
						{
							MessageBox.Show("Loop Error: " + ex.Message);
						}));
					}
				}
			}
		}

		// Token: 0x060015EF RID: 5615 RVA: 0x000AD2C4 File Offset: 0x000AD2C4
		private void Sync3DPointer()
		{
			Plot3D.Graph3D graph3D = this.preview3DGraph;
			if (graph3D == null || graph3D.IsDisposed || !graph3D.IsLiveModeActive())
			{
				return;
			}
			int num = this.livePointerRow;
			int num2 = this.livePointerCol;
			if (num < 0 || num2 < 0 || num >= graph3D.GridHeight || num2 >= graph3D.GridWidth)
			{
				return;
			}
			double valueAt = graph3D.GetValueAt(num2, num);
			graph3D.UpdateLiveData((double)this.RPMD, (double)this.TPSD, valueAt);
		}

		// Token: 0x060015F0 RID: 5616 RVA: 0x000AD334 File Offset: 0x000AD334
		private async void StopLiveDataInternalCore(bool showMessage)
		{
			CancellationTokenSource cts = this._liveCts;
			if (cts != null)
			{
				try
				{
					cts.Cancel();
				}
				catch
				{
				}
			}
			Task task = this._liveLoopTask;
			if (task != null)
			{
				try
				{
					await task;
				}
				catch
				{
				}
				this._liveLoopTask = null;
			}
			if (cts != null)
			{
				try
				{
					cts.Dispose();
				}
				catch
				{
				}
				this._liveCts = null;
			}
			if (this.liveReader != null)
			{
				try
				{
					this.liveReader.Dispose();
				}
				catch
				{
				}
				this.liveReader = null;
			}
			try
			{
				if (this._port != null && this._port.IsOpen)
				{
					this._port.Close();
				}
			}
			catch
			{
			}
			this.isLiveDataRunning = false;
			this.livePointerVisible = false;
			this.livePointerRow = -1;
			this.livePointerCol = -1;
			this.lastLiveFrame = null;
			if (this.preview3DGraph != null && !this.preview3DGraph.IsDisposed)
			{
				try
				{
					this.preview3DGraph.ClearLivePointer();
					this.preview3DGraph.EnableLiveMode(false);
				}
				catch
				{
				}
			}
			this.SetLiveButtonState(false);
			this.ShowLiveOverlay(false);
			this.StopLiveChartTimer();
			if (this._liveChart != null && !this._liveChart.IsDisposed)
			{
				this._liveChart.Close();
				this._liveChart = null;
			}
			if (this.btnLiveChart != null)
			{
				this.btnLiveChart.Text = "\ud83d\udcc8 LIVE CHART";
				this.btnLiveChart.ForeColor = this.cyan;
				this.btnLiveChart.Invalidate();
			}
			try
			{
				this.dgvMap.Invalidate();
			}
			catch
			{
			}
			if (showMessage)
			{
				this.SetStatus("\ud83d\udd34 Live Data Tracking dihentikan.");
			}
		}

		// Token: 0x060015F1 RID: 5617 RVA: 0x000AD378 File Offset: 0x000AD378
		private void SyncPreview3DPointer()
		{
			int num = this.livePointerCol;
			int num2 = this.livePointerRow;
			if (num < 0 || num2 < 0)
			{
				return;
			}
			if (this.dgvMap == null || this.dgvMap.IsDisposed)
			{
				return;
			}
			if (num2 >= this.dgvMap.Rows.Count)
			{
				return;
			}
			if (num >= this.dgvMap.Columns.Count)
			{
				return;
			}
			object value = this.dgvMap.Rows[num2].Cells[num].Value;
			if (value == null)
			{
				return;
			}
			double num3;
			if (!double.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), NumberStyles.Any, CultureInfo.InvariantCulture, out num3))
			{
				return;
			}
			int num4 = 0;
			checked
			{
				foreach (Plot3D.Graph3D graph3D in this.GetAllActiveGraphs())
				{
					if (graph3D != null && !graph3D.IsDisposed)
					{
						num4++;
						if (!graph3D.IsLiveModeActive())
						{
							try
							{
								graph3D.EnableLiveMode(true);
							}
							catch
							{
							}
						}
						try
						{
							graph3D.UpdateLiveDataDirect(num, num2, (double)this.RPMD, (double)this.TPSD, num3);
						}
						catch (Exception ex)
						{
							Console.WriteLine("[SYNC ERROR] " + ex.Message);
						}
					}
				}
				Console.WriteLine(string.Format("[SYNC] {0} Graph3D, col={1}, row={2}, z={3}, RPM={4}, TPS={5}", new object[]
				{
					num4,
					num,
					num2,
					num3,
					this.RPMD,
					this.TPSD
				}));
			}
		}

		// Token: 0x060015F2 RID: 5618 RVA: 0x000AD530 File Offset: 0x000AD530
		private void Sync3DArrayFromGrid()
		{
			if (this.preview3DGraph == null || this.preview3DGraph.IsDisposed)
			{
				return;
			}
			if (this.dgvMap == null || this.dgvMap.IsDisposed)
			{
				return;
			}
			int count = this.dgvMap.Rows.Count;
			int count2 = this.dgvMap.Columns.Count;
			if (count == 0 || count2 == 0)
			{
				return;
			}
			Plot3D.Graph3D.cPoint3D[,] array = new Plot3D.Graph3D.cPoint3D[count2, count];
			checked
			{
				for (int i = 0; i < count; i++)
				{
					for (int j = 0; j < count2; j++)
					{
						double z = 0.0;
						object value = this.dgvMap.Rows[i].Cells[j].Value;
						if (value != null)
						{
							double.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), NumberStyles.Any, CultureInfo.InvariantCulture, out z);
						}
						double x = (double)j;
						double y = (double)i;
						array[j, i] = new Plot3D.Graph3D.cPoint3D(x, y, z);
					}
				}
				this.preview3DGraph.SetSurfacePoints(array, Plot3D.Graph3D.eNormalize.Separate);
			}
		}

		// Token: 0x060015F3 RID: 5619 RVA: 0x0000D91A File Offset: 0x0000D91A
		private IEnumerable<Plot3D.Graph3D> GetAllActiveGraphs()
		{
			if (this.preview3DGraph != null && !this.preview3DGraph.IsDisposed)
			{
				yield return this.preview3DGraph;
			}
			FormCollection openForms;
			try
			{
				openForms = Application.OpenForms;
			}
			catch
			{
				yield break;
			}
			int i = openForms.Count;
			int num;
			for (int j = 0; j < i; j = checked(num + 1))
			{
				Form form = null;
				try
				{
					form = openForms[j];
				}
				catch
				{
				}
				if (form != null && !form.IsDisposed && form != this)
				{
					Plot3D.Graph3D graph3D = this.FindGraph3DControl(form);
					if (graph3D != null && !graph3D.IsDisposed && graph3D != this.preview3DGraph)
					{
						yield return graph3D;
					}
				}
				num = j;
			}
			yield break;
		}

		// Token: 0x060015F4 RID: 5620 RVA: 0x000AD638 File Offset: 0x000AD638
		private Plot3D.Graph3D FindGraph3DControl(Control parent)
		{
			if (parent == null)
			{
				return null;
			}
			Plot3D.Graph3D result;
			if ((result = (parent as Plot3D.Graph3D)) != null)
			{
				return result;
			}
			Control.ControlCollection controls;
			try
			{
				controls = parent.Controls;
			}
			catch
			{
				return null;
			}
			if (controls == null)
			{
				return null;
			}
			int count = controls.Count;
			checked
			{
				for (int i = 0; i < count; i++)
				{
					Control control = null;
					try
					{
						control = controls[i];
					}
					catch
					{
					}
					if (control != null)
					{
						Plot3D.Graph3D graph3D = this.FindGraph3DControl(control);
						if (graph3D != null)
						{
							return graph3D;
						}
					}
				}
				return null;
			}
		}

		// Token: 0x060015F5 RID: 5621 RVA: 0x000AD6C8 File Offset: 0x000AD6C8
		private void AttachLiveChartButton()
		{
			if (this.toolbarPanel == null || this.btnLiveChart != null)
			{
				return;
			}
			this.btnLiveChart = this.MakeNeonButton("\ud83d\udcc8 LIVE CHART", 0, 10, 120, 32, this.cyan, this.cyanDark);
			this.btnLiveChart.Click += delegate(object s, EventArgs e)
			{
				this.ToggleLiveChart();
			};
			this.toolbarPanel.Controls.Add(this.btnLiveChart);
			this.btnLiveChart.BringToFront();
		}

		// Token: 0x060015F6 RID: 5622 RVA: 0x000AD744 File Offset: 0x000AD744
		private void ToggleLiveChart()
		{
			if (this._liveChart != null && !this._liveChart.IsDisposed)
			{
				this._liveChart.Close();
				this._liveChart = null;
				if (this._speedDashboard == null || this._speedDashboard.IsDisposed)
				{
					this.StopLiveChartTimer();
				}
				if (this.btnLiveChart != null)
				{
					this.btnLiveChart.Text = "\ud83d\udcc8 LIVE CHART";
					this.btnLiveChart.ForeColor = this.cyan;
					this.btnLiveChart.Invalidate();
				}
				return;
			}
			this._liveChart = new LiveTrackingChart();
			this._liveChart.FormClosed += delegate(object s, FormClosedEventArgs e)
			{
				this._liveChart = null;
				this.StopLiveChartTimer();
				if (this.btnLiveChart != null)
				{
					this.btnLiveChart.Text = "\ud83d\udcc8 LIVE CHART";
					this.btnLiveChart.ForeColor = this.cyan;
					this.btnLiveChart.Invalidate();
				}
			};
			this._liveChart.Show(this);
			if (this.btnLiveChart != null)
			{
				this.btnLiveChart.Text = "⏹ CHART";
				this.btnLiveChart.ForeColor = this.danger;
				this.btnLiveChart.Invalidate();
			}
			this.StartLiveChartTimer();
		}

		// Token: 0x060015F7 RID: 5623 RVA: 0x0000D92A File Offset: 0x0000D92A
		private void StartLiveChartTimer()
		{
			if (this._liveChartTimer == null)
			{
				this._liveChartTimer = new System.Windows.Forms.Timer
				{
					Interval = 100
				};
				this._liveChartTimer.Tick += delegate(object s, EventArgs e)
				{
					this.PushFrameToAll();
				};
			}
			this._liveChartTimer.Start();
		}

		// Token: 0x060015F8 RID: 5624 RVA: 0x0000D969 File Offset: 0x0000D969
		private void StopLiveChartTimer()
		{
			if (this._liveChartTimer != null)
			{
				this._liveChartTimer.Stop();
				this._liveChartTimer.Dispose();
				this._liveChartTimer = null;
			}
		}

		// Token: 0x060015F9 RID: 5625 RVA: 0x000AD830 File Offset: 0x000AD830
		private void PushFrameToChart()
		{
			if (this._liveChart == null || this._liveChart.IsDisposed)
			{
				return;
			}
			if (!this.isLiveDataRunning || this.lastLiveFrame == null)
			{
				return;
			}
			try
			{
				MapEditorForm.LiveFrame liveFrame = this.lastLiveFrame;
				if (liveFrame.Valid)
				{
					this._liveChart.PushSample(liveFrame.RPM, liveFrame.TPS, liveFrame.AFR, liveFrame.AD);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06001604 RID: 5636 RVA: 0x000AD8FC File Offset: 0x000AD8FC
		private void RepositionToolbar()
		{
			if (this.toolbarPanel == null || this._toolbarRepositioning)
			{
				return;
			}
			this._toolbarRepositioning = true;
			checked
			{
				try
				{
					if (this.cmbProfiles != null && this.cmbProfiles.Visible)
					{
						this.cmbProfiles.Visible = false;
					}
					ValueTuple<Button, int>[] array = new ValueTuple<Button, int>[]
					{
						new ValueTuple<Button, int>(this.btn2DView, 90),
						new ValueTuple<Button, int>(this.btn3DView, 90),
						new ValueTuple<Button, int>(this.btnOpenXdf, 90),
						new ValueTuple<Button, int>(this.btnOpenBin, 90),
						new ValueTuple<Button, int>(this.btnSaveBin, 90),
						new ValueTuple<Button, int>(this.btnSaveEdit, 90),
						new ValueTuple<Button, int>(this.btnSwapAxes, 100),
						new ValueTuple<Button, int>(this.btnCompare, 100),
						new ValueTuple<Button, int>(this.btnCompareBins, 120),
						new ValueTuple<Button, int>(this.btnDebug, 90),
						new ValueTuple<Button, int>(this.btnLiveData, 110),
						new ValueTuple<Button, int>(this.btnLiveChart, 100),
						new ValueTuple<Button, int>(this.btnSpeedometer, 100)
					};
					int num = 12;
					foreach (ValueTuple<Button, int> valueTuple in array)
					{
						Button item = valueTuple.Item1;
						int item2 = valueTuple.Item2;
						if (item != null)
						{
							item.Location = new Point(num, 10);
							item.Size = new Size(item2, 32);
							num += item2 + 6;
						}
					}
				}
				finally
				{
					this._toolbarRepositioning = false;
				}
			}
		}

		// Token: 0x0600160C RID: 5644 RVA: 0x000ADAC8 File Offset: 0x000ADAC8
		private void AttachSpeedometerButton()
		{
			if (this.toolbarPanel == null || this.btnSpeedometer != null)
			{
				return;
			}
			this.btnSpeedometer = this.MakeNeonButton("⚡ SPEEDO", 0, 10, 120, 32, this.gold, Color.FromArgb(200, 150, 0));
			this.btnSpeedometer.Click += delegate(object s, EventArgs e)
			{
				this.ToggleSpeedometer();
			};
			this.toolbarPanel.Controls.Add(this.btnSpeedometer);
			this.btnSpeedometer.BringToFront();
		}

		// Token: 0x0600160D RID: 5645 RVA: 0x000ADB4C File Offset: 0x000ADB4C
		private void ToggleSpeedometer()
		{
			if (this._speedDashboard != null && !this._speedDashboard.IsDisposed)
			{
				this._speedDashboard.Close();
				this._speedDashboard = null;
				if (this._liveChart == null || this._liveChart.IsDisposed)
				{
					this.StopLiveChartTimer();
				}
				if (this.btnSpeedometer != null)
				{
					this.btnSpeedometer.Text = "⚡ SPEEDO";
					this.btnSpeedometer.ForeColor = this.gold;
					this.btnSpeedometer.Invalidate();
				}
				return;
			}
			this._speedDashboard = new SpeedometerDashboard();
			this._speedDashboard.FormClosed += delegate(object s, FormClosedEventArgs e)
			{
				this._speedDashboard = null;
				if (this._liveChart == null || this._liveChart.IsDisposed)
				{
					this.StopLiveChartTimer();
				}
				if (this.btnSpeedometer != null)
				{
					this.btnSpeedometer.Text = "⚡ SPEEDO";
					this.btnSpeedometer.ForeColor = this.gold;
					this.btnSpeedometer.Invalidate();
				}
			};
			this._speedDashboard.Show(this);
			if (this.btnSpeedometer != null)
			{
				this.btnSpeedometer.Text = "⏹ SPEEDO";
				this.btnSpeedometer.ForeColor = this.danger;
				this.btnSpeedometer.Invalidate();
			}
			this.StartLiveChartTimer();
		}

		// Token: 0x06001611 RID: 5649 RVA: 0x000ADC9C File Offset: 0x000ADC9C
		private void PushFrameToAll()
		{
			if (!this.isLiveDataRunning || this.lastLiveFrame == null)
			{
				return;
			}
			MapEditorForm.LiveFrame liveFrame = this.lastLiveFrame;
			if (!liveFrame.Valid)
			{
				return;
			}
			if (this._liveChart != null && !this._liveChart.IsDisposed)
			{
				try
				{
					this._liveChart.PushSample(liveFrame.RPM, liveFrame.TPS, liveFrame.AFR, liveFrame.AD);
				}
				catch
				{
				}
			}
			if (this._speedDashboard != null && !this._speedDashboard.IsDisposed)
			{
				try
				{
					this._speedDashboard.PushSample(liveFrame.RPM, liveFrame.TPS, liveFrame.AFR, liveFrame.AD);
				}
				catch
				{
				}
			}
		}

		// Token: 0x0600161C RID: 5660 RVA: 0x000ADD60 File Offset: 0x000ADD60
		private void SyncSelectionTo3DGraph()
		{
			if (this.dgvMap == null || this.dgvMap.IsDisposed)
			{
				return;
			}
			if (this.suppress3DSync)
			{
				return;
			}
			if (this.isLiveDataRunning)
			{
				return;
			}
			List<Point> list = new List<Point>();
			try
			{
				foreach (object obj in this.dgvMap.SelectedCells)
				{
					DataGridViewCell dataGridViewCell = (DataGridViewCell)obj;
					if (dataGridViewCell != null && dataGridViewCell.RowIndex >= 0 && dataGridViewCell.ColumnIndex >= 0 && (!this.is1DView || dataGridViewCell.ColumnIndex == 1))
					{
						list.Add(new Point(dataGridViewCell.ColumnIndex, dataGridViewCell.RowIndex));
					}
				}
			}
			catch
			{
			}
			try
			{
				Plot3D.Graph3D graph3D = this.preview3DGraph;
				if (graph3D != null && !graph3D.IsDisposed)
				{
					if (graph3D.GridWidth == 0 || graph3D.GridHeight == 0)
					{
						this.PushGridToGraph3D(graph3D);
					}
					graph3D.SetSelectedPoints(list);
					graph3D.Invalidate();
				}
			}
			catch
			{
			}
			try
			{
				Plot3D.Graph3DMainForm graph3DMainForm = this.graph3DForm;
				if (graph3DMainForm != null && !graph3DMainForm.IsDisposed)
				{
					Plot3D.Graph3D graph3DControl = graph3DMainForm.Graph3DControl;
					if (graph3DControl != null && !graph3DControl.IsDisposed)
					{
						if (graph3DControl.GridWidth == 0 || graph3DControl.GridHeight == 0)
						{
							this.PushGridToGraph3D(graph3DControl);
						}
						graph3DControl.SetSelectedPoints(list);
						graph3DControl.Invalidate();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600161F RID: 5663 RVA: 0x000ADEEC File Offset: 0x000ADEEC
		private void DgvMap_KeyDown_CopyPaste(object sender, KeyEventArgs e)
		{
			if (e.Control && e.KeyCode == Keys.C)
			{
				this.CopySelectedCellsToClipboard();
				e.Handled = true;
				e.SuppressKeyPress = true;
				return;
			}
			if (e.Control && e.KeyCode == Keys.V)
			{
				this.PasteFromClipboard();
				e.Handled = true;
				e.SuppressKeyPress = true;
			}
		}

		// Token: 0x06001620 RID: 5664 RVA: 0x000ADF48 File Offset: 0x000ADF48
		private void DgvMap_CellMouseDown_PreserveSelection(object sender, DataGridViewCellMouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right && e.RowIndex >= 0 && e.ColumnIndex >= 0 && !this.dgvMap.Rows[e.RowIndex].Cells[e.ColumnIndex].Selected && this.dgvMap.SelectedCells.Count > 0)
			{
				DataGridViewCell currentCell = this.dgvMap.CurrentCell;
				this.dgvMap.CurrentCell = this.dgvMap.SelectedCells[0];
				this.dgvMap.BeginInvoke(new Action(delegate()
				{
					if (this.dgvMap.IsDisposed)
					{
						return;
					}
					foreach (object obj in this.dgvMap.SelectedCells)
					{
						DataGridViewCell dataGridViewCell = (DataGridViewCell)obj;
					}
				}));
			}
		}

		// Token: 0x06001621 RID: 5665 RVA: 0x000AE000 File Offset: 0x000AE000
		private void CopySelectedCellsToClipboard()
		{
			if (this.dgvMap == null || this.dgvMap.SelectedCells.Count == 0)
			{
				return;
			}
			int rowIndex = int.MaxValue;
			int rowIndex2 = int.MinValue;
			int columnIndex = int.MaxValue;
			int columnIndex2 = int.MinValue;
			foreach (object obj in this.dgvMap.SelectedCells)
			{
				DataGridViewCell dataGridViewCell = (DataGridViewCell)obj;
				if (dataGridViewCell.RowIndex >= 0 && dataGridViewCell.ColumnIndex >= 0)
				{
					if (dataGridViewCell.RowIndex < rowIndex)
					{
						rowIndex = dataGridViewCell.RowIndex;
					}
					if (dataGridViewCell.RowIndex > rowIndex2)
					{
						rowIndex2 = dataGridViewCell.RowIndex;
					}
					if (dataGridViewCell.ColumnIndex < columnIndex)
					{
						columnIndex = dataGridViewCell.ColumnIndex;
					}
					if (dataGridViewCell.ColumnIndex > columnIndex2)
					{
						columnIndex2 = dataGridViewCell.ColumnIndex;
					}
				}
			}
			if (rowIndex == 2147483647)
			{
				return;
			}
			StringBuilder stringBuilder = new StringBuilder();
			checked
			{
				for (int i = rowIndex; i <= rowIndex2; i++)
				{
					for (int j = columnIndex; j <= columnIndex2; j++)
					{
						DataGridViewCell dataGridViewCell2 = this.dgvMap.Rows[i].Cells[j];
						if (dataGridViewCell2.Selected && dataGridViewCell2.Value != null)
						{
							stringBuilder.Append(dataGridViewCell2.Value.ToString());
						}
						if (j < columnIndex2)
						{
							stringBuilder.Append('\t');
						}
					}
					stringBuilder.AppendLine();
				}
				if (stringBuilder.Length > 0)
				{
					try
					{
						Clipboard.SetText(stringBuilder.ToString());
						this.SetStatus(string.Format("\ud83d\udccb Copy {0} sel (R{1}C{2} → R{3}C{4})", new object[]
						{
							this.dgvMap.SelectedCells.Count,
							rowIndex,
							columnIndex,
							rowIndex2,
							columnIndex2
						}));
					}
					catch (Exception ex)
					{
						this.SetStatus("❌ Copy gagal: " + ex.Message);
					}
				}
			}
		}

		// Token: 0x06001622 RID: 5666 RVA: 0x000AE20C File Offset: 0x000AE20C
		private void PasteFromClipboard()
		{
			if (this.dgvMap == null || this.dgvMap.SelectedCells.Count == 0)
			{
				return;
			}
			if (this.binData == null || this.currentProfile == null)
			{
				return;
			}
			string text = null;
			try
			{
				if (Clipboard.ContainsData(DataFormats.UnicodeText))
				{
					text = (Clipboard.GetData(DataFormats.UnicodeText) as string);
				}
				if (string.IsNullOrEmpty(text) && Clipboard.ContainsText())
				{
					text = Clipboard.GetText(TextDataFormat.Text);
				}
			}
			catch (Exception ex)
			{
				this.SetStatus("❌ Paste gagal: " + ex.Message);
				return;
			}
			if (string.IsNullOrWhiteSpace(text))
			{
				return;
			}
			Console.WriteLine("[PASTE] Panjang: " + text.Length + " char");
			Console.WriteLine("[PASTE] Baris: " + text.Split(new char[]
			{
				'\n'
			}).Length);
			Console.WriteLine("[PASTE] Isi (first 200): " + ((text.Length > 200) ? text.Substring(0, 200) : text));
			text = text.Replace("\r\n", "\n").Replace("\r", "\n").TrimEnd(new char[]
			{
				'\n'
			});
			string[] array = text.Split(new char[]
			{
				'\n'
			}, StringSplitOptions.None);
			List<string[]> list = new List<string[]>();
			foreach (string text2 in array)
			{
				list.Add(text2.Split(new char[]
				{
					'\t'
				}));
			}
			if (list.Count == 0)
			{
				return;
			}
			int rowIndex = int.MaxValue;
			int columnIndex = int.MaxValue;
			foreach (object obj in this.dgvMap.SelectedCells)
			{
				DataGridViewCell dataGridViewCell = (DataGridViewCell)obj;
				if (dataGridViewCell.RowIndex >= 0 && dataGridViewCell.ColumnIndex >= 0)
				{
					if (dataGridViewCell.RowIndex < rowIndex)
					{
						rowIndex = dataGridViewCell.RowIndex;
					}
					if (dataGridViewCell.ColumnIndex < columnIndex)
					{
						columnIndex = dataGridViewCell.ColumnIndex;
					}
				}
			}
			if (rowIndex == 2147483647)
			{
				return;
			}
			try
			{
				this.undoStack.Push((byte[])this.binData.Clone());
				this.redoStack.Clear();
			}
			catch
			{
			}
			this.suppress3DSync = true;
			int num = 0;
			int num2 = 0;
			checked
			{
				try
				{
					for (int j = 0; j < list.Count; j++)
					{
						int num3 = rowIndex + j;
						if (num3 < 0)
						{
							break;
						}
						if (num3 >= this.dgvMap.Rows.Count)
						{
							break;
						}
						string[] array3 = list[j];
						for (int k = 0; k < array3.Length; k++)
						{
							int num4 = columnIndex + k;
							if (num4 < 0 || num4 >= this.dgvMap.Columns.Count)
							{
								break;
							}
							DataGridViewCell dataGridViewCell2 = this.dgvMap.Rows[num3].Cells[num4];
							if (dataGridViewCell2 != null && !dataGridViewCell2.ReadOnly)
							{
								string text3 = array3[k].Trim().Trim(new char[]
								{
									'"'
								});
								if (!string.IsNullOrEmpty(text3))
								{
									if (text3.Contains(",") && !text3.Contains("."))
									{
										text3 = text3.Replace(",", "");
									}
									double v;
									if (double.TryParse(text3, NumberStyles.Any, CultureInfo.InvariantCulture, out v) || double.TryParse(text3, NumberStyles.Any, CultureInfo.CurrentCulture, out v))
									{
										dataGridViewCell2.Value = MapEditorForm.FmtSmart(v);
									}
									else
									{
										dataGridViewCell2.Value = text3;
									}
									num2++;
								}
							}
						}
						num++;
					}
				}
				finally
				{
					this.suppress3DSync = false;
				}
				try
				{
					this.CommitGridToBinData();
				}
				catch (Exception ex2)
				{
					Console.WriteLine("[PASTE] Commit Error: " + ex2.Message);
				}
				this.Sync3DPreviewFromGrid();
				this.hasUnsavedChanges = true;
				this.SetStatus(string.Format("\ud83d\udccb Paste {0} baris × {1} sel (mulai R{2}C{3})", new object[]
				{
					num,
					num2,
					rowIndex,
					columnIndex
				}));
			}
		}

		// Token: 0x06001629 RID: 5673 RVA: 0x000AE71C File Offset: 0x000AE71C
		private void DgvMap_MouseDown_TrackBlock(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				DataGridView.HitTestInfo hitTestInfo = this.dgvMap.HitTest(e.X, e.Y);
				if (hitTestInfo.Type == DataGridViewHitTestType.Cell)
				{
					this._isDraggingBlock = true;
					this._dragBlockStart = new Point(hitTestInfo.ColumnIndex, hitTestInfo.RowIndex);
					this._dragBlockEnd = this._dragBlockStart;
					this.SyncSelectionTo3DGraph();
					return;
				}
			}
			else if (e.Button == MouseButtons.Right)
			{
				if (this.preview3DGraph != null)
				{
					this.preview3DGraph.ClearSelection();
					this.preview3DGraph.Invalidate();
				}
				if (this.graph3DForm != null && this.graph3DForm.Graph3DControl != null)
				{
					this.graph3DForm.Graph3DControl.ClearSelection();
					this.graph3DForm.Graph3DControl.Invalidate();
				}
			}
		}

		// Token: 0x0600162A RID: 5674 RVA: 0x000AE7EC File Offset: 0x000AE7EC
		private void DgvMap_MouseMove_TrackBlock(object sender, MouseEventArgs e)
		{
			if (this._isDraggingBlock)
			{
				DataGridView.HitTestInfo hitTestInfo = this.dgvMap.HitTest(e.X, e.Y);
				if (hitTestInfo.Type == DataGridViewHitTestType.Cell && (this._dragBlockEnd.X != hitTestInfo.ColumnIndex || this._dragBlockEnd.Y != hitTestInfo.RowIndex))
				{
					this._dragBlockEnd = new Point(hitTestInfo.ColumnIndex, hitTestInfo.RowIndex);
					this.SyncSelectionTo3DGraph();
				}
			}
		}

		// Token: 0x0600162B RID: 5675 RVA: 0x0000D9C8 File Offset: 0x0000D9C8
		private void DgvMap_MouseUp_TrackBlock(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this._isDraggingBlock = false;
				this.SyncSelectionTo3DGraph();
			}
		}

		// Token: 0x06001636 RID: 5686 RVA: 0x000AE868 File Offset: 0x000AE868
		private void PushGridToGraph3D(Plot3D.Graph3D target)
		{
			if (target == null || target.IsDisposed)
			{
				return;
			}
			if (this.dgvMap == null || this.dgvMap.Rows.Count == 0 || this.dgvMap.Columns.Count == 0)
			{
				return;
			}
			if (this.is1DView)
			{
				return;
			}
			checked
			{
				try
				{
					int count = this.dgvMap.Rows.Count;
					int count2 = this.dgvMap.Columns.Count;
					if (count2 >= 2 && count >= 2)
					{
						Plot3D.Graph3D.cPoint3D[,] array = new Plot3D.Graph3D.cPoint3D[count2, count];
						for (int i = 0; i < count2; i++)
						{
							for (int j = 0; j < count; j++)
							{
								double z = 0.0;
								object value = this.dgvMap[i, j].Value;
								double num;
								if (value != null && value != DBNull.Value && double.TryParse(value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out num))
								{
									z = num;
								}
								array[i, j] = new Plot3D.Graph3D.cPoint3D((double)i, (double)j, z);
							}
						}
						target.SetSurfacePoints(array, Plot3D.Graph3D.eNormalize.Separate);
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x06001638 RID: 5688 RVA: 0x0000D9E4 File Offset: 0x0000D9E4
		private void BtnLiveTrace_Click(object sender, EventArgs e)
		{
			this.ShowHistoryPopup();
		}

		// Token: 0x06001639 RID: 5689 RVA: 0x000AE988 File Offset: 0x000AE988
		private void ShowHistoryPopup()
		{
			if (this.dgvMap == null || this.dgvMap.Rows.Count == 0 || this.dgvMap.Columns.Count == 0)
			{
				MapEditorForm.CustomMessageBox.Show(this, "Belum ada data grid untuk ditampilkan.", "History Kosong", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
			if (this.currentProfile == null || this.currentProfile.Table == null)
			{
				return;
			}
			if (this.liveRpmValues == null || this.liveRpmValues.Count == 0)
			{
				this.BuildLiveAxisCache();
			}
			LiveTracingOptions options = new LiveTracingOptions
			{
				BgDark = this.bgDark,
				BgPanel = this.bgPanel,
				BgCard = this.bgCard,
				Fg = this.fg,
				Muted = this.muted,
				Cyan = this.cyan,
				Gold = this.gold,
				Green = this.green,
				Danger = this.danger,
				Border = this.border,
				MinValue = this.minValue,
				MaxValue = this.maxValue,
				SwapAxes = this.swapAxes,
				MapTitle = this.currentProfile.Table.Title,
				IsLiveRunning = (() => this.isLiveDataRunning),
				ColorFromProportion = ((float p) => this.ColorFromProportion(p)),
				CreateWindowButton = ((string text, Color fore, Color back) => this.CreateWindowButton(text, 0, 0, fore, back)),
				CreateRoundedRect = ((Rectangle rect, int radius) => this.RoundedRect(rect, radius))
			};
			MapEditorForm.LocalLiveProvider frameProvider = new MapEditorForm.LocalLiveProvider(this);
			DataGridView dataGridView = null;
			XdfProfile xdfProfile = null;
			if (this.allProfiles != null)
			{
				foreach (XdfProfile xdfProfile2 in this.allProfiles)
				{
					if (xdfProfile2.Name.IndexOf("Ignition", StringComparison.OrdinalIgnoreCase) >= 0 || (xdfProfile2.Table != null && xdfProfile2.Table.Title.IndexOf("Ignition", StringComparison.OrdinalIgnoreCase) >= 0))
					{
						xdfProfile = xdfProfile2;
						break;
					}
				}
			}
			checked
			{
				if (xdfProfile != null && xdfProfile.Table != null && this.binData != null)
				{
					XdfTable table = xdfProfile.Table;
					dataGridView = new DataGridView();
					double[] array = this.ReadAxis(table.XAxisAddress, table.XAxisElementSize, table.XAxisScale, table.XAxisOffset, table.Cols);
					double[] array2 = this.ReadAxis(table.YAxisAddress, table.YAxisElementSize, table.YAxisScale, table.YAxisOffset, table.Rows);
					bool flag = table.PreferRpmOnTop ^ this.swapAxes;
					double[] array3 = flag ? array2 : array;
					double[] array4 = flag ? array : array2;
					for (int i = 0; i < table.Cols; i++)
					{
						string headerText = (i < array3.Length) ? array3[i].ToString("0.#", CultureInfo.InvariantCulture) : ("Col " + i);
						dataGridView.Columns.Add("C" + i, headerText);
					}
					for (int j = 0; j < table.Rows; j++)
					{
						int num = dataGridView.Rows.Add();
						if (j < array4.Length)
						{
							dataGridView.Rows[num].HeaderCell.Value = array4[j].ToString("0.#", CultureInfo.InvariantCulture);
						}
						else
						{
							dataGridView.Rows[num].HeaderCell.Value = "Row " + j;
						}
						for (int k = 0; k < table.Cols; k++)
						{
							int num2 = table.Address + (j * table.Cols + k) * table.ElementSize;
							if (num2 >= 0 && num2 + table.ElementSize <= this.binData.Length)
							{
								double raw = this.ReadRaw(num2, table.ElementSize, table.IsSwapped, table.IsFloat, table.IsSigned);
								double num3 = MapEditorForm.EvalMathEquation(table.MathEquation, raw);
								dataGridView[k, num].Value = ((Math.Abs(num3) >= 100.0) ? ((long)Math.Round(num3)).ToString() : num3.ToString("F2"));
							}
						}
					}
				}
				MapEditorForm.LastIgnitionGrid = dataGridView;
				MapEditorForm.LastBinData = this.binData;
				using (LiveTracingForm liveTracingForm = new LiveTracingForm(this.dgvMap, null, frameProvider, options))
				{
					liveTracingForm.ShowDialog(this);
				}
			}
		}

		// Token: 0x06001648 RID: 5704 RVA: 0x000AEE40 File Offset: 0x000AEE40
		private void SyncGridYellowFrom3DSelection()
		{
			if (this.dgvMap == null || this.dgvMap.IsDisposed)
			{
				return;
			}
			if (this.suppress3DSync)
			{
				return;
			}
			if (this.is1DView)
			{
				return;
			}
			if (this.dgvMap.InvokeRequired)
			{
				try
				{
					this.dgvMap.BeginInvoke(new Action(this.SyncGridYellowFrom3DSelection));
				}
				catch
				{
				}
				return;
			}
			try
			{
				HashSet<Point> hashSet = new HashSet<Point>();
				if (this.preview3DGraph != null && !this.preview3DGraph.IsDisposed)
				{
					List<Point> selectedPoints = this.preview3DGraph.GetSelectedPoints();
					if (selectedPoints != null)
					{
						foreach (Point item in selectedPoints)
						{
							hashSet.Add(item);
						}
					}
				}
				if (this.graph3DForm != null && !this.graph3DForm.IsDisposed)
				{
					Plot3D.Graph3D graph3DControl = this.graph3DForm.Graph3DControl;
					if (graph3DControl != null && !graph3DControl.IsDisposed)
					{
						List<Point> selectedPoints2 = graph3DControl.GetSelectedPoints();
						if (selectedPoints2 != null)
						{
							foreach (Point item2 in selectedPoints2)
							{
								hashSet.Add(item2);
							}
						}
					}
				}
				this.ClearAllYellowGridHighlights();
				if (hashSet.Count == 0)
				{
					try
					{
						this.dgvMap.Invalidate();
					}
					catch
					{
					}
				}
				else
				{
					Color yellow = Color.Yellow;
					Color black = Color.Black;
					this.dgvMap.SuspendLayout();
					try
					{
						foreach (Point point in hashSet)
						{
							int x = point.X;
							int y = point.Y;
							if (y >= 0 && y < this.dgvMap.Rows.Count && x >= 0 && x < this.dgvMap.Columns.Count)
							{
								DataGridViewCell dataGridViewCell = this.dgvMap.Rows[y].Cells[x];
								if (dataGridViewCell != null)
								{
									dataGridViewCell.Style.BackColor = yellow;
									dataGridViewCell.Style.ForeColor = black;
									dataGridViewCell.Style.SelectionBackColor = yellow;
									dataGridViewCell.Style.SelectionForeColor = black;
									dataGridViewCell.Tag = "3D_SELECTED_YELLOW";
								}
							}
						}
					}
					finally
					{
						this.dgvMap.ResumeLayout(false);
						try
						{
							this.dgvMap.Invalidate();
						}
						catch
						{
						}
					}
					this.SetStatus(string.Format("\ud83c\udfaf {0} cell di-highlight KUNING dari selection 3D", hashSet.Count));
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("SyncGridYellowFrom3DSelection error: " + ex.Message);
			}
		}

		// Token: 0x06001649 RID: 5705 RVA: 0x000AF1A4 File Offset: 0x000AF1A4
		private void ClearAllYellowGridHighlights()
		{
			if (this.dgvMap == null || this.dgvMap.IsDisposed)
			{
				return;
			}
			checked
			{
				for (int i = 0; i < this.dgvMap.Rows.Count; i++)
				{
					DataGridViewRow dataGridViewRow = this.dgvMap.Rows[i];
					if (dataGridViewRow != null && !dataGridViewRow.IsNewRow)
					{
						for (int j = 0; j < this.dgvMap.Columns.Count; j++)
						{
							DataGridViewCell dataGridViewCell = dataGridViewRow.Cells[j];
							string a;
							if (dataGridViewCell != null && (a = (dataGridViewCell.Tag as string)) != null && a == "3D_SELECTED_YELLOW")
							{
								dataGridViewCell.Style.BackColor = Color.Empty;
								dataGridViewCell.Style.ForeColor = Color.Empty;
								dataGridViewCell.Style.SelectionBackColor = Color.Empty;
								dataGridViewCell.Style.SelectionForeColor = Color.Empty;
								dataGridViewCell.Tag = null;
							}
						}
					}
				}
			}
		}

		// Token: 0x0600164A RID: 5706 RVA: 0x0000DA14 File Offset: 0x0000DA14
		private void Graph3D_SelectionChanged(object sender, EventArgs e)
		{
			if (this.suppress3DSync)
			{
				return;
			}
			this.SyncGridYellowFrom3DSelection();
		}

		// Token: 0x04001B8C RID: 7052
		private Label lblTitle;

		// Token: 0x04001B8D RID: 7053
		private Label lblSubtitle;

		// Token: 0x04001B8E RID: 7054
		private Button btnMinimize;

		// Token: 0x04001B8F RID: 7055
		private Button btnClose;

		// Token: 0x04001B90 RID: 7056
		private ComboBox cmbProfiles;

		// Token: 0x04001B91 RID: 7057
		private DataGridView dgvMap;

		// Token: 0x04001B92 RID: 7058
		private Button btnOpenBin;

		// Token: 0x04001B93 RID: 7059
		private Button btnOpenXdf;

		// Token: 0x04001B94 RID: 7060
		private Button btnSaveBin;

		// Token: 0x04001B95 RID: 7061
		private Button btnDebug;

		// Token: 0x04001B96 RID: 7062
		private Label lblStatus;

		// Token: 0x04001B99 RID: 7065
		private Button btn3DView;

		// Token: 0x04001B9A RID: 7066
		private Button btn2DView;

		// Token: 0x04001B9B RID: 7067
		private bool dragging;

		// Token: 0x04001B9C RID: 7068
		private Point dragStart;

		// Token: 0x04001B9D RID: 7069
		private Point formStart;

		// Token: 0x04001B9E RID: 7070
		private byte[] binData;

		// Token: 0x04001B9F RID: 7071
		private string binFilePath;

		// Token: 0x04001BA0 RID: 7072
		private XdfProfile currentProfile;

		// Token: 0x04001BA1 RID: 7073
		private List<XdfProfile> allProfiles;

		// Token: 0x04001BA2 RID: 7074
		private XdfDefinition loadedXdf;

		// Token: 0x04001BA3 RID: 7075
		private string loadedXdfPath;

		// Token: 0x04001BA4 RID: 7076
		private int currentBaseAddress;

		// Token: 0x04001BA5 RID: 7077
		private int currentRows;

		// Token: 0x04001BA6 RID: 7078
		private int currentCols;

		// Token: 0x04001BA7 RID: 7079
		private bool is1DView;

		// Token: 0x04001BA8 RID: 7080
		private double minValue;

		// Token: 0x04001BA9 RID: 7081
		private double maxValue;

		// Token: 0x04001BAA RID: 7082
		private Plot3D.Graph3DMainForm graph3DForm;

		// Token: 0x04001BAB RID: 7083
		private bool suppress3DSync;

		// Token: 0x04001BAC RID: 7084
		private _3D_Chart_Graph._2d graph2DForm;

		// Token: 0x04001BAE RID: 7086
		private readonly Color bgPanel;

		// Token: 0x04001BAF RID: 7087
		private readonly Color bgCard;

		// Token: 0x04001BB0 RID: 7088
		private readonly Color cyan;

		// Token: 0x04001BB1 RID: 7089
		private readonly Color cyanDark;

		// Token: 0x04001BB2 RID: 7090
		private readonly Color green;

		// Token: 0x04001BB3 RID: 7091
		private readonly Color purpleXdf;

		// Token: 0x04001BB5 RID: 7093
		private readonly Color muted;

		// Token: 0x04001BB6 RID: 7094
		private readonly Color danger;

		// Token: 0x04001BB7 RID: 7095
		private readonly Color border;

		// Token: 0x04001BB8 RID: 7096
		private readonly Color orange3D;

		// Token: 0x04001BB9 RID: 7097
		private readonly Color blue2D;

		// Token: 0x04001BBA RID: 7098
		private Button btnSaveEdit;

		// Token: 0x04001BBB RID: 7099
		private Dictionary<string, bool> editedTables;

		// Token: 0x04001BBC RID: 7100
		private bool hasUnsavedChanges;

		// Token: 0x04001BBD RID: 7101
		private Stack<byte[]> undoStack;

		// Token: 0x04001BBE RID: 7102
		private Stack<byte[]> redoStack;

		// Token: 0x04001BBF RID: 7103
		public Action<List<double>> OnDataSaved;

		// Token: 0x04001BC0 RID: 7104
		public Action OnSaveClicked;

		// Token: 0x04001BC1 RID: 7105
		private TreeView treeViewMaps;

		// Token: 0x04001BC2 RID: 7106
		private ComboBox cmbViewBy;

		// Token: 0x04001BC4 RID: 7108
		private Label lblMapTitle;

		// Token: 0x04001BC5 RID: 7109
		private Label lblPropName;

		// Token: 0x04001BC6 RID: 7110
		private Label lblPropAxis;

		// Token: 0x04001BC7 RID: 7111
		private Label lblPropUnits;

		// Token: 0x04001BC8 RID: 7112
		private Label lblPropSize;

		// Token: 0x04001BC9 RID: 7113
		private Plot3D.Graph3D preview3DGraph;

		// Token: 0x04001BCA RID: 7114
		private RichTextBox hexBox;

		// Token: 0x04001BCB RID: 7115
		private Label hexFooter;

		// Token: 0x04001BCD RID: 7117
		private byte[] originalBinData;

		// Token: 0x04001BCF RID: 7119
		private Label lblConn;

		// Token: 0x04001BD1 RID: 7121
		private Label lblZoom;

		// Token: 0x04001BD2 RID: 7122
		private Panel propPanel;

		// Token: 0x04001BD3 RID: 7123
		private Panel xRuler;

		// Token: 0x04001BD4 RID: 7124
		private Panel yRuler;

		// Token: 0x04001BD5 RID: 7125
		private Label lblCursor;

		// Token: 0x04001BD6 RID: 7126
		private Label lblTreeFooter;

		// Token: 0x04001BD7 RID: 7127
		private double _batchInput;

		// Token: 0x04001BD8 RID: 7128
		private bool _batchOk;

		// Token: 0x04001BD9 RID: 7129
		private bool rightPanelCollapsed;

		// Token: 0x04001BDA RID: 7130
		private int rightPanelLastWidth;

		// Token: 0x04001BDB RID: 7131
		private Button btnToggleRightPanel;

		// Token: 0x04001BDC RID: 7132
		private System.Windows.Forms.Timer pending3DTimer;

		// Token: 0x04001BDD RID: 7133
		private bool pending3DSync;

		// Token: 0x04001BDE RID: 7134
		private int pending3DAttempts;

		// Token: 0x04001BDF RID: 7135
		private Button btnSwapAxes;

		// Token: 0x04001BE0 RID: 7136
		private bool swapAxes;

		// Token: 0x04001BE1 RID: 7137
		private readonly Color gold;

		// Token: 0x04001BE2 RID: 7138
		private Button btnCompare;

		// Token: 0x04001BE3 RID: 7139
		private MapEditorForm.CompareForm compareForm;

		// Token: 0x04001BE4 RID: 7140
		private const int DWMWA_NCRENDERING_POLICY = 2;

		// Token: 0x04001BE5 RID: 7141
		private const int DWMNCRP_DISABLED = 1;

		// Token: 0x04001BE6 RID: 7142
		private const int DWMWA_TRANSITIONS_FORCEDISABLED = 3;

		// Token: 0x04001BE7 RID: 7143
		private const int DWMWA_WINDOW_CORNER_PREFERENCE = 33;

		// Token: 0x04001BE8 RID: 7144
		private const int DWMWCP_ROUND = 2;

		// Token: 0x04001BE9 RID: 7145
		private const int DWMWCP_DONOTROUND = 1;

		// Token: 0x04001BEA RID: 7146
		private DateTime _lastGraph3DHexUpdate;

		// Token: 0x04001BEB RID: 7147
		private const int WM_NCHITTEST = 132;

		// Token: 0x04001BEC RID: 7148
		private const int HTBOTTOMRIGHT = 17;

		// Token: 0x04001BED RID: 7149
		private const int HTBOTTOM = 15;

		// Token: 0x04001BEE RID: 7150
		private const int HTRIGHT = 11;

		// Token: 0x04001BEF RID: 7151
		private const int HTLEFT = 10;

		// Token: 0x04001BF0 RID: 7152
		private const int HTTOP = 12;

		// Token: 0x04001BF1 RID: 7153
		private const int HTTOPLEFT = 13;

		// Token: 0x04001BF2 RID: 7154
		private const int HTTOPRIGHT = 14;

		// Token: 0x04001BF3 RID: 7155
		private const int HTBOTTOMLEFT = 16;

		// Token: 0x04001BF4 RID: 7156
		private double _lastMainRatio;

		// Token: 0x04001BF5 RID: 7157
		private double _lastRightRatio;

		// Token: 0x04001BF6 RID: 7158
		private Button btnLiveData;

		// Token: 0x04001BF7 RID: 7159
		private bool isLiveDataRunning;

		// Token: 0x04001BF8 RID: 7160
		private System.Windows.Forms.Timer liveDataTimer;

		// Token: 0x04001BF9 RID: 7161
		private MapEditorForm.LiveDataReader liveReader;

		// Token: 0x04001BFA RID: 7162
		private MapEditorForm.LiveProtocol liveProtocol;

		// Token: 0x04001BFB RID: 7163
		private string livePortName;

		// Token: 0x04001BFC RID: 7164
		private int liveBaudRate;

		// Token: 0x04001BFD RID: 7165
		private MapEditorForm.LiveFrame lastLiveFrame;

		// Token: 0x04001BFE RID: 7166
		private int livePointerRow;

		// Token: 0x04001BFF RID: 7167
		private int livePointerCol;

		// Token: 0x04001C00 RID: 7168
		private bool livePointerVisible;

		// Token: 0x04001C01 RID: 7169
		private double livePointerPulse;

		// Token: 0x04001C02 RID: 7170
		private Dictionary<ValueTuple<int, int>, double> liveInitialCellValues;

		// Token: 0x04001C03 RID: 7171
		private List<double> liveRpmValues;

		// Token: 0x04001C04 RID: 7172
		private List<double> liveColValues;

		// Token: 0x04001C05 RID: 7173
		private bool liveUseMapAxis;

		// Token: 0x04001C06 RID: 7174
		private Panel liveOverlayPanel;

		// Token: 0x04001C07 RID: 7175
		private Label lblLiveRPM;

		// Token: 0x04001C08 RID: 7176
		private Label lblLiveTPS;

		// Token: 0x04001C09 RID: 7177
		private Label lblLiveMAP;

		// Token: 0x04001C0A RID: 7178
		private Label lblLiveCL;

		// Token: 0x04001C0B RID: 7179
		private Label lblLiveAFR;

		// Token: 0x04001C0C RID: 7180
		private Label lblLiveIDC;

		// Token: 0x04001C0D RID: 7181
		private Label lblLiveConn;

		// Token: 0x04001C0E RID: 7182
		private SerialPort _port;

		// Token: 0x04001C0F RID: 7183
		private MapEditorForm.LiveProtocol _protocol;

		// Token: 0x04001C10 RID: 7184
		private readonly byte[] _rx;

		// Token: 0x04001C11 RID: 7185
		private int _hoveredRow;

		// Token: 0x04001C12 RID: 7186
		private int _hoveredCol;

		// Token: 0x04001C13 RID: 7187
		private Dictionary<ValueTuple<int, int>, double> initialCellValues;

		// Token: 0x04001C15 RID: 7189
		private int RPMD;

		// Token: 0x04001C16 RID: 7190
		private float TPSD;

		// Token: 0x04001C17 RID: 7191
		private float CL;

		// Token: 0x04001C18 RID: 7192
		private float MAP;

		// Token: 0x04001C19 RID: 7193
		private float AD;

		// Token: 0x04001C1A RID: 7194
		private float inj;

		// Token: 0x04001C1B RID: 7195
		private float IDC;

		// Token: 0x04001C1C RID: 7196
		private float O2V;

		// Token: 0x04001C1D RID: 7197
		private float O2V2;

		// Token: 0x04001C1E RID: 7198
		private float AFR;

		// Token: 0x04001C1F RID: 7199
		private float HP;

		// Token: 0x04001C20 RID: 7200
		private float TQ;

		// Token: 0x04001C21 RID: 7201
		private float NILAI;

		// Token: 0x04001C22 RID: 7202
		private float nilaiPersen;

		// Token: 0x04001C23 RID: 7203
		private bool tek10;

		// Token: 0x04001C24 RID: 7204
		private bool tek11;

		// Token: 0x04001C25 RID: 7205
		private bool tek13;

		// Token: 0x04001C26 RID: 7206
		private bool tek16;

		// Token: 0x04001C27 RID: 7207
		private bool tek17;

		// Token: 0x04001C28 RID: 7208
		private bool tek20;

		// Token: 0x04001C29 RID: 7209
		private bool liv;

		// Token: 0x04001C2A RID: 7210
		private CancellationTokenSource liveCts;

		// Token: 0x04001C2B RID: 7211
		private Task liveLoopTask;

		// Token: 0x04001C2C RID: 7212
		private int _liveStep;

		// Token: 0x04001C2D RID: 7213
		private CancellationTokenSource _liveCts;

		// Token: 0x04001C2E RID: 7214
		private Task _liveLoopTask;

		// Token: 0x04001C2F RID: 7215
		private LiveTrackingChart _liveChart;

		// Token: 0x04001C30 RID: 7216
		private System.Windows.Forms.Timer _liveChartTimer;

		// Token: 0x04001C31 RID: 7217
		private Button btnLiveChart;

		// Token: 0x04001C32 RID: 7218
		private bool _toolbarRepositioning;

		// Token: 0x04001C33 RID: 7219
		private Button btnCompareBins;

		// Token: 0x04001C34 RID: 7220
		private SpeedometerDashboard _speedDashboard;

		// Token: 0x04001C35 RID: 7221
		private Button btnSpeedometer;

		// Token: 0x04001C36 RID: 7222
		private ContextMenuStrip _gridContextMenu;

		// Token: 0x04001C37 RID: 7223
		private bool _isDraggingBlock;

		// Token: 0x04001C38 RID: 7224
		private Point _dragBlockStart;

		// Token: 0x04001C39 RID: 7225
		private Point _dragBlockEnd;

		// Token: 0x04001C3A RID: 7226
		private bool _isLiveTracingActive;

		// Token: 0x04001C3B RID: 7227
		private DataGridView dgvIgnitionMap;

		// Token: 0x04001C3C RID: 7228
		public static DataGridView LastIgnitionGrid;

		// Token: 0x04001C3D RID: 7229
		public static byte[] LastBinData;

		// Token: 0x04001C3E RID: 7230
		public static bool ForceCloseWithoutPrompt;

		// Token: 0x020007FF RID: 2047
		private sealed class BufferedForm : Form
		{
			// Token: 0x0600164B RID: 5707 RVA: 0x0000DA25 File Offset: 0x0000DA25
			public BufferedForm()
			{
				this.DoubleBuffered = true;
			}
		}

		// Token: 0x02000800 RID: 2048
		public class CustomMessageBox : Form
		{
			// Token: 0x0600164C RID: 5708 RVA: 0x000AF2A0 File Offset: 0x000AF2A0
			public static DialogResult Show(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
			{
				DialogResult dialogResult;
				using (MapEditorForm.CustomMessageBox customMessageBox = new MapEditorForm.CustomMessageBox())
				{
					customMessageBox.SetupDialog(message, title, buttons, icon);
					customMessageBox.ShowDialog();
					dialogResult = MapEditorForm.CustomMessageBox._dialogResult;
				}
				return dialogResult;
			}

			// Token: 0x0600164D RID: 5709 RVA: 0x000AF2E8 File Offset: 0x000AF2E8
			public CustomMessageBox()
			{
				base.FormBorderStyle = FormBorderStyle.None;
				base.StartPosition = FormStartPosition.CenterScreen;
				this.BackColor = MapEditorForm.CustomMessageBox.BgDark;
				base.MaximizeBox = false;
				base.MinimizeBox = false;
				base.ShowInTaskbar = false;
				base.Width = 440;
				base.Height = 300;
				base.TopMost = true;
				base.Padding = new Padding(2);
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			}

			// Token: 0x0600164E RID: 5710 RVA: 0x000AF368 File Offset: 0x000AF368
			public static DialogResult Show(IWin32Window owner, string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
			{
				DialogResult dialogResult;
				using (MapEditorForm.CustomMessageBox customMessageBox = new MapEditorForm.CustomMessageBox())
				{
					customMessageBox.SetupDialog(message, title, buttons, icon);
					customMessageBox.ShowDialog(owner);
					dialogResult = MapEditorForm.CustomMessageBox._dialogResult;
				}
				return dialogResult;
			}

			// Token: 0x0600164F RID: 5711 RVA: 0x000AF3B4 File Offset: 0x000AF3B4
			private void SetupDialog(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
			{
				base.Controls.Clear();
				this.contentPanel = new HondaMapEditorPro.RoundedPanel();
				this.contentPanel.Dock = DockStyle.Fill;
				this.contentPanel.CornerRadius = this._cornerRadius;
				this.contentPanel.BorderColor = MapEditorForm.CustomMessageBox.Cyan;
				this.contentPanel.BorderWidth = 1f;
				this.contentPanel.InnerBackColor = MapEditorForm.CustomMessageBox.BgPanel;
				this.contentPanel.Padding = new Padding(20);
				base.Controls.Add(this.contentPanel);
				PictureBox pictureBox = new PictureBox
				{
					Location = new Point(18, 22),
					Size = new Size(28, 28),
					SizeMode = PictureBoxSizeMode.StretchImage,
					BackColor = Color.Transparent
				};
				if (icon == MessageBoxIcon.Asterisk)
				{
					pictureBox.Image = SystemIcons.Information.ToBitmap();
				}
				else if (icon == MessageBoxIcon.Exclamation)
				{
					pictureBox.Image = SystemIcons.Warning.ToBitmap();
				}
				else if (icon == MessageBoxIcon.Hand)
				{
					pictureBox.Image = SystemIcons.Error.ToBitmap();
				}
				else if (icon == MessageBoxIcon.Question)
				{
					pictureBox.Image = SystemIcons.Question.ToBitmap();
				}
				this.contentPanel.Controls.Add(pictureBox);
				this.titleLabel = new Label
				{
					Text = title,
					Font = new Font("Segoe UI", 12f, FontStyle.Bold),
					ForeColor = MapEditorForm.CustomMessageBox.TextTitle,
					BackColor = Color.Transparent,
					Location = new Point(56, 18),
					AutoSize = true
				};
				this.contentPanel.Controls.Add(this.titleLabel);
				checked
				{
					Panel value = new Panel
					{
						BackColor = MapEditorForm.CustomMessageBox.CyanDark,
						Location = new Point(18, 50),
						Size = new Size(base.Width - 36, 1),
						Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
					};
					this.contentPanel.Controls.Add(value);
					Label value2 = new Label
					{
						Text = message,
						Font = new Font("Segoe UI", 9.5f),
						ForeColor = MapEditorForm.CustomMessageBox.TextFore,
						BackColor = Color.Transparent,
						Location = new Point(20, 64),
						Width = base.Width - 80,
						Height = 120,
						AutoSize = false,
						Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
					};
					this.contentPanel.Controls.Add(value2);
					int num = 90;
					int num2 = 34;
					int num3 = 10;
					int num4 = (buttons == MessageBoxButtons.OK) ? 1 : ((buttons == MessageBoxButtons.OKCancel || buttons == MessageBoxButtons.YesNo) ? 2 : ((buttons == MessageBoxButtons.YesNoCancel) ? 3 : 0));
					int num5 = num4 * num + (num4 - 1) * num3;
					int width = this.contentPanel.ClientSize.Width;
					int height = this.contentPanel.ClientSize.Height;
					int num6 = this.contentPanel.Padding.Left + (width - this.contentPanel.Padding.Left - this.contentPanel.Padding.Right - num5) / 2;
					int top = height - num2 - this.contentPanel.Padding.Bottom;
					if (buttons == MessageBoxButtons.OK)
					{
						this.CreateButton("OK", num6, top, num, num2, DialogResult.OK);
						return;
					}
					if (buttons == MessageBoxButtons.OKCancel)
					{
						this.CreateButton("OK", num6, top, num, num2, DialogResult.OK);
						this.CreateButton("Cancel", num6 + num + num3, top, num, num2, DialogResult.Cancel);
						return;
					}
					if (buttons == MessageBoxButtons.YesNo)
					{
						this.CreateButton("Yes", num6, top, num, num2, DialogResult.Yes);
						this.CreateButton("No", num6 + num + num3, top, num, num2, DialogResult.No);
						return;
					}
					if (buttons == MessageBoxButtons.YesNoCancel)
					{
						this.CreateButton("Yes", num6, top, num, num2, DialogResult.Yes);
						this.CreateButton("No", num6 + num + num3, top, num, num2, DialogResult.No);
						this.CreateButton("Cancel", num6 + (num + num3) * 2, top, num, num2, DialogResult.Cancel);
					}
				}
			}

			// Token: 0x06001650 RID: 5712 RVA: 0x000AF7A4 File Offset: 0x000AF7A4
			private void CreateButton(string text, int left, int top, int width, int height, DialogResult result)
			{
				HondaMapEditorPro.RoundedButton roundedButton = new HondaMapEditorPro.RoundedButton
				{
					Text = text,
					Location = new Point(left, top),
					Size = new Size(width, height),
					Font = new Font("Segoe UI", 9f, FontStyle.Bold),
					ForeColor = MapEditorForm.CustomMessageBox.Cyan,
					BackColor = MapEditorForm.CustomMessageBox.BgButton,
					CornerRadius = 8,
					BorderColor = MapEditorForm.CustomMessageBox.Cyan,
					BorderWidth = 1f,
					HoverBackColor = MapEditorForm.CustomMessageBox.BgButtonHover,
					Cursor = Cursors.Hand
				};
				roundedButton.Click += delegate(object s, EventArgs ev)
				{
					MapEditorForm.CustomMessageBox._dialogResult = result;
					this.Close();
				};
				this.contentPanel.Controls.Add(roundedButton);
			}

			// Token: 0x06001651 RID: 5713 RVA: 0x000AF874 File Offset: 0x000AF874
			protected override void OnPaint(PaintEventArgs e)
			{
				base.OnPaint(e);
				Graphics graphics = e.Graphics;
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				graphics.PixelOffsetMode = PixelOffsetMode.Half;
				graphics.Clear(this.BackColor);
				using (GraphicsPath graphicsPath = MapEditorForm.RoundedHelper.RoundedRectF(new RectangleF(1.5f, 1.5f, (float)base.Width - 3f, (float)base.Height - 3f), (float)this._cornerRadius))
				{
					using (Pen pen = new Pen(MapEditorForm.CustomMessageBox.Cyan, 2f))
					{
						pen.Alignment = PenAlignment.Center;
						pen.LineJoin = LineJoin.Round;
						graphics.DrawPath(pen, graphicsPath);
					}
				}
			}

			// Token: 0x06001652 RID: 5714 RVA: 0x0000DA34 File Offset: 0x0000DA34
			protected override void OnLoad(EventArgs e)
			{
				base.OnLoad(e);
				this.UpdateFormRegion();
			}

			// Token: 0x06001653 RID: 5715 RVA: 0x0000DA43 File Offset: 0x0000DA43
			protected override void OnMouseDown(MouseEventArgs e)
			{
				base.OnMouseDown(e);
				if (e.Button == MouseButtons.Left)
				{
					MapEditorForm.CustomMessageBox.ReleaseCapture();
					MapEditorForm.CustomMessageBox.SendMessage(base.Handle, 161, 2, 0);
				}
			}

			// Token: 0x06001654 RID: 5716
			[DllImport("user32.dll")]
			public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

			// Token: 0x06001655 RID: 5717
			[DllImport("user32.dll")]
			public static extern bool ReleaseCapture();

			// Token: 0x06001656 RID: 5718 RVA: 0x0000DA72 File Offset: 0x0000DA72
			protected override void OnResize(EventArgs e)
			{
				base.OnResize(e);
				this.UpdateFormRegion();
				base.Invalidate();
			}

			// Token: 0x06001657 RID: 5719 RVA: 0x0000DA87 File Offset: 0x0000DA87
			private void UpdateFormRegion()
			{
				if (base.Width <= 0 || base.Height <= 0)
				{
					return;
				}
				MapEditorForm.RoundedHelper.SetRegion(this, this._cornerRadius);
			}

			// Token: 0x04001C3F RID: 7231
			private Label titleLabel;

			// Token: 0x04001C40 RID: 7232
			private static readonly Color Cyan = Color.FromArgb(0, 255, 230);

			// Token: 0x04001C41 RID: 7233
			private static readonly Color CyanDark = Color.FromArgb(0, 145, 135);

			// Token: 0x04001C42 RID: 7234
			private static readonly Color BgDark = Color.FromArgb(18, 23, 29);

			// Token: 0x04001C43 RID: 7235
			private static readonly Color BgPanel = Color.FromArgb(22, 28, 35);

			// Token: 0x04001C44 RID: 7236
			private static readonly Color BgButton = Color.FromArgb(32, 40, 47);

			// Token: 0x04001C45 RID: 7237
			private static readonly Color BgButtonHover = Color.FromArgb(45, 60, 70);

			// Token: 0x04001C46 RID: 7238
			private static readonly Color TextFore = Color.FromArgb(235, 240, 245);

			// Token: 0x04001C47 RID: 7239
			private static readonly Color TextTitle = Color.FromArgb(255, 215, 0);

			// Token: 0x04001C48 RID: 7240
			private int _cornerRadius = 14;

			// Token: 0x04001C49 RID: 7241
			private static DialogResult _dialogResult;

			// Token: 0x04001C4A RID: 7242
			private HondaMapEditorPro.RoundedPanel contentPanel;
		}

		// Token: 0x02000803 RID: 2051
		private sealed class PreviewGraph3D : Plot3D.Graph3D
		{
			// Token: 0x06001661 RID: 5729 RVA: 0x0000DAF2 File Offset: 0x0000DAF2
			public PreviewGraph3D()
			{
				base.ShowPoints = false;
				base.ShowCompareBins = false;
				base.ShowLiveLabel = false;
				base.EnableLiveMode(false);
				base.EnableAreaDrag(false);
				base.EnableEditMode(false);
			}

			// Token: 0x06001662 RID: 5730 RVA: 0x0000DB24 File Offset: 0x0000DB24
			protected override void OnMouseMove(MouseEventArgs e)
			{
				base.OnMouseMove(e);
				base.ClearSelection();
			}

			// Token: 0x06001663 RID: 5731 RVA: 0x0000DB33 File Offset: 0x0000DB33
			protected override void OnMouseUp(MouseEventArgs e)
			{
				base.OnMouseUp(e);
				base.ClearSelection();
				base.ClearClickedPoints();
				base.ClearLivePointer();
			}
		}

		// Token: 0x02000804 RID: 2052
		internal static class RoundedHelper
		{
			// Token: 0x06001664 RID: 5732 RVA: 0x000AFB24 File Offset: 0x000AFB24
			public static GraphicsPath RoundedRectF(RectangleF rect, float radius)
			{
				GraphicsPath graphicsPath = new GraphicsPath();
				if (rect.Width <= 0f || rect.Height <= 0f)
				{
					return graphicsPath;
				}
				float num = radius * 2f;
				if (num > rect.Width)
				{
					num = rect.Width;
				}
				if (num > rect.Height)
				{
					num = rect.Height;
				}
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}

			// Token: 0x06001665 RID: 5733 RVA: 0x000AFC10 File Offset: 0x000AFC10
			public static void SetRegion(Form f, int radius)
			{
				using (GraphicsPath graphicsPath = MapEditorForm.RoundedHelper.RoundedRectF(new RectangleF(0f, 0f, (float)f.Width, (float)f.Height), (float)radius))
				{
					f.Region = new Region(graphicsPath);
				}
			}
		}

		// Token: 0x02000805 RID: 2053
		public sealed class CompareForm : Form
		{
			// Token: 0x06001666 RID: 5734 RVA: 0x000AFC6C File Offset: 0x000AFC6C
			private void RefreshGrid()
			{
				if (this._grid == null)
				{
					return;
				}
				this._grid.SuspendLayout();
				try
				{
					this._grid.Rows.Clear();
					this._grid.Columns.Clear();
					this._minVal = double.MaxValue;
					this._maxVal = double.MinValue;
					checked
					{
						if (this._useMatrixMode && this._table != null)
						{
							int rows = this._table.Rows;
							int cols = this._table.Cols;
							int visualCols = this._visualCols;
							List<int> list = this._rpmOnTop ? this._cachedRpm : this._cachedTps;
							string headerText = this._rpmOnTop ? "TPS \\ RPM" : "RPM \\ TPS";
							this._grid.Columns.Add(new DataGridViewTextBoxColumn
							{
								Name = "RowAxis",
								HeaderText = headerText,
								Width = 90,
								Frozen = true,
								SortMode = DataGridViewColumnSortMode.NotSortable,
								DefaultCellStyle = new DataGridViewCellStyle
								{
									BackColor = Color.FromArgb(40, 40, 40),
									ForeColor = Color.Cyan,
									Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
									Alignment = DataGridViewContentAlignment.MiddleCenter
								}
							});
							for (int i = 0; i < visualCols; i++)
							{
								int num = (i < list.Count) ? list[i] : i;
								this._grid.Columns.Add(new DataGridViewTextBoxColumn
								{
									Name = "Col_" + i,
									HeaderText = num.ToString(),
									Width = 62,
									SortMode = DataGridViewColumnSortMode.NotSortable,
									DefaultCellStyle = new DataGridViewCellStyle
									{
										Alignment = DataGridViewContentAlignment.MiddleCenter
									}
								});
							}
							List<int> list2 = this._rpmOnTop ? this._cachedTps : this._cachedRpm;
							for (int j = 0; j < this._visualRows; j++)
							{
								int index = this._grid.Rows.Add();
								DataGridViewRow dataGridViewRow = this._grid.Rows[index];
								dataGridViewRow.Cells[0].Value = ((j < list2.Count) ? list2[j].ToString() : j.ToString());
								for (int k = 0; k < this._visualCols; k++)
								{
									int num2;
									int num3;
									if (this._rpmOnTop)
									{
										num2 = k;
										num3 = j;
									}
									else
									{
										num2 = j;
										num3 = k;
									}
									if (num2 < rows && num3 < cols)
									{
										int num4 = this._table.Address + (num2 * cols + num3) * this._table.ElementSize;
										if (num4 >= 0 && num4 + this._table.ElementSize <= this._snapshotBin.Length)
										{
											double num5;
											double num6;
											bool flag;
											unchecked
											{
												num5 = MapEditorForm.CompareForm.ReadRaw(this._originalBin, num4, this._table.ElementSize, this._table.IsSwapped, this._table.IsFloat, this._table.IsSigned) * this._table.Scale + this._table.Offset;
												num6 = MapEditorForm.CompareForm.ReadRaw(this._snapshotBin, num4, this._table.ElementSize, this._table.IsSwapped, this._table.IsFloat, this._table.IsSigned) * this._table.Scale + this._table.Offset;
												flag = (Math.Abs(num5 - num6) > 1E-09);
											}
											DataGridViewCell dataGridViewCell = dataGridViewRow.Cells[k + 1];
											if (this._filterChangedOnly.Checked && !flag)
											{
												dataGridViewCell.Value = null;
												dataGridViewCell.Style.BackColor = Color.FromArgb(20, 28, 36);
												dataGridViewCell.Style.ForeColor = Color.Transparent;
											}
											else
											{
												double num7 = this._rbAbsolute.Checked ? num6 : unchecked(this._rbDifference.Checked ? (num6 - num5) : ((num5 != 0.0) ? ((num6 - num5) / num5 * 100.0) : 0.0));
												if (num7 < this._minVal)
												{
													this._minVal = num7;
												}
												if (num7 > this._maxVal)
												{
													this._maxVal = num7;
												}
												dataGridViewCell.Value = ((Math.Abs(num7) >= 100.0) ? ((long)Math.Round(num7)).ToString() : num7.ToString("F2"));
											}
											dataGridViewCell.Tag = new MapEditorForm.CompareForm.CellTag
											{
												Address = num4,
												OldValue = num5,
												NewValue = num6,
												Changed = flag
											};
										}
									}
								}
							}
							this._summary.Text = string.Format("Map {0} × {1}   |   {2}   |   Changed: {3}", new object[]
							{
								this._visualRows,
								this._visualCols,
								this._rpmOnTop ? "RPM di atas" : "TPS di atas",
								this._all.Count
							});
						}
						else
						{
							string text = this._rbAbsolute.Checked ? "Absolute" : (this._rbDifference.Checked ? "Difference (Δ)" : "Percentage (%)");
							string[] array = new string[]
							{
								"Address",
								"Old (Hex)",
								"New (Hex)",
								"Old (Dec)",
								text,
								"Delta (Δ)",
								"Table Name",
								"Units"
							};
							int[] array2 = new int[]
							{
								90,
								80,
								80,
								80,
								110,
								80,
								200,
								100
							};
							for (int l = 0; l < array.Length; l++)
							{
								this._grid.Columns.Add(new DataGridViewTextBoxColumn
								{
									Name = array[l],
									HeaderText = array[l],
									Width = array2[l],
									SortMode = DataGridViewColumnSortMode.NotSortable
								});
							}
							this._grid.Columns["Table Name"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
							this._grid.Columns["Units"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
							foreach (MapEditorForm.CompareForm.DiffEntry diffEntry in from x in this._all
							orderby x.Address
							select x)
							{
								if (diffEntry != null)
								{
									bool flag2 = diffEntry.OldValue != diffEntry.NewValue;
									if (!this._filterChangedOnly.Checked || flag2)
									{
										double num8 = this._rbAbsolute.Checked ? ((double)diffEntry.NewValue) : (this._rbDifference.Checked ? ((double)diffEntry.Delta) : ((diffEntry.OldValue != 0) ? unchecked((double)diffEntry.Delta / (double)diffEntry.OldValue * 100.0) : 0.0));
										if (num8 < this._minVal)
										{
											this._minVal = num8;
										}
										if (num8 > this._maxVal)
										{
											this._maxVal = num8;
										}
										int index2 = this._grid.Rows.Add();
										this._grid.Rows[index2].Cells[0].Value = "0x" + diffEntry.Address.ToString("X6");
										this._grid.Rows[index2].Cells[1].Value = diffEntry.OldByte.ToString("X2");
										this._grid.Rows[index2].Cells[2].Value = diffEntry.NewByte.ToString("X2");
										this._grid.Rows[index2].Cells[3].Value = diffEntry.OldValue.ToString();
										if (this._rbAbsolute.Checked)
										{
											this._grid.Rows[index2].Cells[4].Value = num8.ToString("F2");
										}
										else if (this._rbDifference.Checked)
										{
											this._grid.Rows[index2].Cells[4].Value = num8.ToString("+0;-0;0");
										}
										else
										{
											this._grid.Rows[index2].Cells[4].Value = num8.ToString("+0;-0;0") + "%";
										}
										this._grid.Rows[index2].Cells[5].Value = diffEntry.Delta.ToString("+0;-0;0");
										this._grid.Rows[index2].Cells[6].Value = (diffEntry.TableName ?? "—");
										this._grid.Rows[index2].Cells[7].Value = (diffEntry.Units ?? "—");
										this._grid.Rows[index2].Cells[4].Tag = new MapEditorForm.CompareForm.CellTag
										{
											Address = diffEntry.Address,
											OldValue = (double)diffEntry.OldValue,
											NewValue = (double)diffEntry.NewValue,
											Changed = flag2
										};
									}
								}
							}
							Control summary = this._summary;
							string format = "List mode ({0})   |   Entries: {1}   |   Changed: {2}   |   BIN: {3}";
							object[] array3 = new object[4];
							array3[0] = text;
							array3[1] = this._all.Count;
							array3[2] = this._all.Count((MapEditorForm.CompareForm.DiffEntry x) => x.OldValue != x.NewValue);
							array3[3] = this._binName;
							summary.Text = string.Format(format, array3);
						}
						if (this._minVal == 1.7976931348623157E+308)
						{
							this._minVal = 0.0;
						}
						if (this._maxVal == -1.7976931348623157E+308)
						{
							this._maxVal = 1.0;
						}
					}
					if (this._minVal == this._maxVal)
					{
						this._maxVal = this._minVal + 1.0;
					}
				}
				finally
				{
					this._grid.ResumeLayout();
				}
			}

			// Token: 0x06001667 RID: 5735 RVA: 0x000B0778 File Offset: 0x000B0778
			private void Grid_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
			{
				if (e.RowIndex < 0 || e.ColumnIndex < 0 || e.Value == null)
				{
					return;
				}
				DataGridViewCell dataGridViewCell = this._grid.Rows[e.RowIndex].Cells[e.ColumnIndex];
				if (!this._useMatrixMode)
				{
					string name = this._grid.Columns[e.ColumnIndex].Name;
					MapEditorForm.CompareForm.CellTag cellTag = dataGridViewCell.Tag as MapEditorForm.CompareForm.CellTag;
					if (this._filterChangedOnly.Checked && cellTag != null && !cellTag.Changed)
					{
						e.Value = "";
						e.FormattingApplied = true;
						e.CellStyle.BackColor = Color.FromArgb(20, 28, 36);
						return;
					}
					if (name == "Delta (Δ)" || name == "New (Dec)" || name == "New (Hex)")
					{
						string text = e.Value.ToString();
						if (text.StartsWith("+"))
						{
							e.CellStyle.ForeColor = Color.LimeGreen;
							return;
						}
						if (text.StartsWith("-"))
						{
							e.CellStyle.ForeColor = Color.Orange;
							return;
						}
						e.CellStyle.ForeColor = Color.LawnGreen;
					}
					return;
				}
				else
				{
					MapEditorForm.CompareForm.CellTag cellTag2 = dataGridViewCell.Tag as MapEditorForm.CompareForm.CellTag;
					if (e.ColumnIndex <= 0 || cellTag2 == null)
					{
						return;
					}
					if (this._filterChangedOnly.Checked && !cellTag2.Changed)
					{
						e.Value = "";
						e.FormattingApplied = true;
						e.CellStyle.BackColor = Color.FromArgb(20, 28, 36);
						e.CellStyle.ForeColor = Color.Transparent;
						return;
					}
					double num;
					if (!double.TryParse(e.Value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out num))
					{
						return;
					}
					double num2 = this._maxVal - this._minVal;
					if (num2 <= 0.0)
					{
						num2 = 1.0;
					}
					float p = (float)((num - this._minVal) / num2);
					e.CellStyle.BackColor = this.ColorFromProportion(p);
					e.CellStyle.ForeColor = Color.Black;
					e.CellStyle.SelectionBackColor = this._cyan;
					e.CellStyle.SelectionForeColor = Color.Black;
					return;
				}
			}

			// Token: 0x06001668 RID: 5736 RVA: 0x000B09C0 File Offset: 0x000B09C0
			private List<int> GetSelectedAddresses()
			{
				List<int> list = new List<int>();
				HashSet<int> hashSet = new HashSet<int>();
				foreach (object obj in this._grid.SelectedCells)
				{
					DataGridViewCell dataGridViewCell = (DataGridViewCell)obj;
					MapEditorForm.CompareForm.CellTag cellTag = dataGridViewCell.Tag as MapEditorForm.CompareForm.CellTag;
					if ((!this._useMatrixMode || dataGridViewCell.ColumnIndex > 0) && cellTag != null && cellTag.Address >= 0 && hashSet.Add(cellTag.Address))
					{
						list.Add(cellTag.Address);
					}
				}
				return list;
			}

			// Token: 0x06001669 RID: 5737 RVA: 0x000B0A70 File Offset: 0x000B0A70
			private void ExportCsv()
			{
				checked
				{
					using (SaveFileDialog saveFileDialog = new SaveFileDialog())
					{
						saveFileDialog.Filter = "CSV File (*.csv)|*.csv";
						saveFileDialog.FileName = string.Concat(new string[]
						{
							"compare_",
							this._binName,
							"_",
							DateTime.Now.ToString("yyyyMMdd_HHmmss"),
							".csv"
						});
						if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
						{
							try
							{
								StringBuilder stringBuilder = new StringBuilder();
								for (int i = 0; i < this._grid.Columns.Count; i++)
								{
									if (i > 0)
									{
										stringBuilder.Append(',');
									}
									stringBuilder.Append(this._grid.Columns[i].HeaderText);
								}
								stringBuilder.AppendLine();
								foreach (object obj in ((IEnumerable)this._grid.Rows))
								{
									DataGridViewRow dataGridViewRow = (DataGridViewRow)obj;
									if (!dataGridViewRow.IsNewRow)
									{
										stringBuilder.Append((dataGridViewRow.Cells[0].Value != null) ? dataGridViewRow.Cells[0].Value.ToString() : "");
										for (int j = 1; j < this._grid.Columns.Count; j++)
										{
											stringBuilder.Append(',');
											stringBuilder.Append((dataGridViewRow.Cells[j].Value != null) ? dataGridViewRow.Cells[j].Value.ToString() : "");
										}
										stringBuilder.AppendLine();
									}
								}
								File.WriteAllText(saveFileDialog.FileName, stringBuilder.ToString(), Encoding.UTF8);
								MapEditorForm.CustomMessageBox.Show(this, "Export CSV berhasil:\n" + saveFileDialog.FileName, "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
							catch (Exception ex)
							{
								MapEditorForm.CustomMessageBox.Show(this, "Gagal export CSV:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							}
						}
					}
				}
			}

			// Token: 0x0600166A RID: 5738 RVA: 0x000B0CE0 File Offset: 0x000B0CE0
			protected override void OnPaint(PaintEventArgs e)
			{
				base.OnPaint(e);
				int width = base.ClientSize.Width;
				int height = base.ClientSize.Height;
				if (width < 30 || height < 30)
				{
					return;
				}
				Graphics graphics = e.Graphics;
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
				graphics.CompositingQuality = CompositingQuality.HighQuality;
				RectangleF rectangleF = new RectangleF(4.5f, 4.5f, (float)width - 9f, (float)height - 9f);
				float num = 14f;
				float num2 = Math.Min(rectangleF.Width, rectangleF.Height) / 2f;
				if (num > num2)
				{
					num = num2;
				}
				using (GraphicsPath graphicsPath = new GraphicsPath())
				{
					float num3 = num * 2f;
					graphicsPath.StartFigure();
					graphicsPath.AddArc(rectangleF.X, rectangleF.Y, num3, num3, 180f, 90f);
					graphicsPath.AddArc(rectangleF.Right - num3, rectangleF.Y, num3, num3, 270f, 90f);
					graphicsPath.AddArc(rectangleF.Right - num3, rectangleF.Bottom - num3, num3, num3, 0f, 90f);
					graphicsPath.AddArc(rectangleF.X, rectangleF.Bottom - num3, num3, num3, 90f, 90f);
					graphicsPath.CloseFigure();
					using (Pen pen = new Pen(Color.FromArgb(35, 0, 255, 230), 8f))
					{
						pen.LineJoin = LineJoin.Round;
						graphics.DrawPath(pen, graphicsPath);
					}
					using (Pen pen2 = new Pen(Color.FromArgb(90, 0, 255, 230), 5f))
					{
						pen2.LineJoin = LineJoin.Round;
						graphics.DrawPath(pen2, graphicsPath);
					}
					using (Pen pen3 = new Pen(Color.FromArgb(0, 255, 230), 2.5f))
					{
						pen3.LineJoin = LineJoin.Round;
						graphics.DrawPath(pen3, graphicsPath);
					}
					using (Pen pen4 = new Pen(Color.FromArgb(220, 255, 255, 245), 0.8f))
					{
						pen4.LineJoin = LineJoin.Round;
						graphics.DrawPath(pen4, graphicsPath);
					}
				}
			}

			// Token: 0x0600166B RID: 5739 RVA: 0x000B0FC4 File Offset: 0x000B0FC4
			protected override void OnResize(EventArgs e)
			{
				base.OnResize(e);
				if (base.ClientSize.Width <= 20 || base.ClientSize.Height <= 20)
				{
					return;
				}
				using (GraphicsPath graphicsPath = MapEditorForm.CreateRoundedPath(new Rectangle(0, 0, base.Width, base.Height), 14))
				{
					base.Region = new Region(graphicsPath);
				}
			}

			// Token: 0x0600166C RID: 5740 RVA: 0x000B1040 File Offset: 0x000B1040
			private void BuildPivotCache()
			{
				checked
				{
					if (this._table != null && this._table.Rows > 0 && this._table.Cols > 0 && this._snapshotBin != null && this._originalBin != null)
					{
						this._useMatrixMode = true;
						int rows = this._table.Rows;
						int cols = this._table.Cols;
						bool flag = this._table.PreferRpmOnTop ^ this._swapAxes;
						this._rpmOnTop = flag;
						this._visualRows = (flag ? cols : rows);
						this._visualCols = (flag ? rows : cols);
						this._cachedRpm = new List<int>(rows);
						this._cachedTps = new List<int>(cols);
						double[] array = this.ReadAxis(this._snapshotBin, this._table.YAxisAddress, this._table.YAxisElementSize, this._table.YAxisScale, this._table.YAxisOffset, rows);
						for (int i = 0; i < rows; i++)
						{
							this._cachedRpm.Add((int)Math.Round(array[i]));
						}
						double[] array2 = this.ReadAxis(this._snapshotBin, this._table.XAxisAddress, this._table.XAxisElementSize, this._table.XAxisScale, this._table.XAxisOffset, cols);
						for (int j = 0; j < cols; j++)
						{
							this._cachedTps.Add((int)Math.Round(array2[j]));
						}
						return;
					}
					this._useMatrixMode = false;
				}
			}

			// Token: 0x0600166D RID: 5741 RVA: 0x000B11C4 File Offset: 0x000B11C4
			public void UpdateData(List<MapEditorForm.CompareForm.DiffEntry> diffs, int editedSize, int originalSize, XdfTable table = null, byte[] snapshotBin = null, byte[] originalBin = null)
			{
				this._all = (diffs ?? new List<MapEditorForm.CompareForm.DiffEntry>());
				this._editedSize = editedSize;
				this._originalSize = originalSize;
				this._table = table;
				this._snapshotBin = snapshotBin;
				this._originalBin = originalBin;
				this._cachedTps = null;
				this._cachedRpm = null;
				this.BuildPivotCache();
				this.RefreshGrid();
			}

			// Token: 0x0600166E RID: 5742 RVA: 0x000B1224 File Offset: 0x000B1224
			private static double ReadRaw(byte[] bin, int offset, int size, bool swapped, bool isFloat, bool isSigned)
			{
				checked
				{
					if (bin == null || offset < 0 || size <= 0 || offset + size > bin.Length)
					{
						return 0.0;
					}
					if (isFloat && size == 4)
					{
						byte[] array = new byte[4];
						Array.Copy(bin, offset, array, 0, 4);
						if (swapped)
						{
							Array.Reverse(array);
						}
						return (double)BitConverter.ToSingle(array, 0);
					}
					ulong num = 0UL;
					if (swapped)
					{
						for (int i = 0; i < size; i++)
						{
							num = (num << 8 | unchecked((ulong)bin[checked(offset + i)]));
						}
					}
					else
					{
						for (int j = size - 1; j >= 0; j--)
						{
							num = (num << 8 | unchecked((ulong)bin[checked(offset + j)]));
						}
					}
					ulong num2 = (size >= 8) ? ulong.MaxValue : ((1UL << size * 8) - 1UL);
					num &= num2;
					if (!isSigned)
					{
						return num;
					}
					ulong num3 = 1UL << size * 8 - 1;
					if ((num & num3) != 0UL)
					{
						return (double)((long)(num | ~num2));
					}
					return (double)((long)num);
				}
			}

			// Token: 0x0600166F RID: 5743 RVA: 0x000B12F8 File Offset: 0x000B12F8
			private double[] ReadAxis(byte[] bin, int addr, int elemSize, double scale, double offset, int count)
			{
				double[] array = new double[count];
				checked
				{
					for (int i = 0; i < count; i++)
					{
						array[i] = (double)(i + 1);
					}
					if (addr <= 0 || elemSize <= 0)
					{
						return array;
					}
					for (int j = 0; j < count; j++)
					{
						int num = addr + j * elemSize;
						if (num + elemSize > bin.Length)
						{
							break;
						}
						array[j] = unchecked(MapEditorForm.CompareForm.ReadRaw(bin, num, elemSize, false, false, false) * scale + offset);
					}
					return array;
				}
			}

			// Token: 0x06001670 RID: 5744 RVA: 0x000B135C File Offset: 0x000B135C
			private Color ColorFromProportion(float p)
			{
				p = Math.Max(0f, Math.Min(1f, p));
				Color[] array = new Color[]
				{
					Color.Blue,
					Color.Aqua,
					Color.FromArgb(0, 255, 0),
					Color.Yellow,
					Color.Orange,
					Color.Red
				};
				checked
				{
					float num = 1f / (float)(array.Length - 1);
					int num2 = (int)(p / num);
					if (num2 >= array.Length - 1)
					{
						num2 = array.Length - 2;
					}
					int num3 = Math.Min(num2 + 1, array.Length - 1);
					float num4 = unchecked(p - (float)num2 * num) / num;
					return Color.FromArgb((int)(unchecked((float)array[num2].R * (1f - num4) + (float)array[num3].R * num4)), (int)(unchecked((float)array[num2].G * (1f - num4) + (float)array[num3].G * num4)), (int)(unchecked((float)array[num2].B * (1f - num4) + (float)array[num3].B * num4)));
				}
			}

			// Token: 0x06001671 RID: 5745 RVA: 0x000026F4 File Offset: 0x000026F4
			protected override void OnPaintBackground(PaintEventArgs e)
			{
			}

			// Token: 0x06001672 RID: 5746 RVA: 0x000B148C File Offset: 0x000B148C
			protected override void WndProc(ref Message m)
			{
				if (m.Msg == 133)
				{
					m.Result = IntPtr.Zero;
					return;
				}
				if (m.Msg == 134)
				{
					base.WndProc(ref m);
					m.Result = new IntPtr(1);
					return;
				}
				base.WndProc(ref m);
			}

			// Token: 0x06001673 RID: 5747 RVA: 0x000B14DC File Offset: 0x000B14DC
			private Control BuildHeader()
			{
				MapEditorForm.CompareForm.RoundedPanel roundedPanel = new MapEditorForm.CompareForm.RoundedPanel();
				roundedPanel.Dock = DockStyle.Fill;
				roundedPanel.Fill = this._bgPanel;
				roundedPanel.Radius = 8;
				roundedPanel.Padding = new Padding(14, 10, 14, 10);
				roundedPanel.Margin = new Padding(0, 0, 0, 6);
				Label label = new Label
				{
					Text = "\ud83d\udd0d  BIN COMPARISON",
					Font = new Font("Segoe UI", 11f, FontStyle.Bold),
					ForeColor = this._cyan,
					AutoSize = true,
					Location = new Point(14, 8),
					BackColor = this._bgPanel
				};
				this._summary = new Label
				{
					Text = "",
					Font = new Font("Consolas", 9f),
					ForeColor = this._cyan,
					AutoSize = true,
					Location = new Point(14, 34),
					BackColor = this._bgPanel
				};
				roundedPanel.Controls.Add(label);
				roundedPanel.Controls.Add(this._summary);
				MouseEventHandler value = delegate(object s, MouseEventArgs ev)
				{
					if (ev.Button == MouseButtons.Left)
					{
						this._dragging = true;
						this._dragStart = Cursor.Position;
						this._formStart = base.Location;
					}
				};
				MouseEventHandler value2 = delegate(object s, MouseEventArgs ev)
				{
					if (this._dragging)
					{
						Point position = Cursor.Position;
						base.Location = checked(new Point(this._formStart.X + position.X - this._dragStart.X, this._formStart.Y + position.Y - this._dragStart.Y));
					}
				};
				MouseEventHandler value3 = delegate(object s, MouseEventArgs ev)
				{
					this._dragging = false;
				};
				roundedPanel.MouseDown += value;
				roundedPanel.MouseMove += value2;
				roundedPanel.MouseUp += value3;
				label.MouseDown += value;
				label.MouseMove += value2;
				label.MouseUp += value3;
				return roundedPanel;
			}

			// Token: 0x06001674 RID: 5748 RVA: 0x000B1648 File Offset: 0x000B1648
			private Control BuildToolbar()
			{
				MapEditorForm.CompareForm.RoundedPanel roundedPanel = new MapEditorForm.CompareForm.RoundedPanel
				{
					Dock = DockStyle.Fill,
					Fill = this._bgPanel,
					Radius = 8,
					Padding = new Padding(14, 8, 14, 8),
					Margin = new Padding(0, 0, 0, 6)
				};
				FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
				{
					Dock = DockStyle.Bottom,
					Height = 32,
					FlowDirection = FlowDirection.RightToLeft,
					WrapContents = false,
					BackColor = this._bgPanel,
					Padding = new Padding(0),
					Margin = new Padding(0)
				};
				Button button = this.MakeBtn("CLOSE", this._danger);
				Button button2 = this.MakeBtn("EXPORT CSV", this._green);
				Button button3 = this.MakeBtn("REVERT SELECTED", this._orange);
				Button button4 = this.MakeBtn("REVERT ALL", this._danger);
				button.Click += delegate(object s, EventArgs ev)
				{
					base.Close();
				};
				button2.Click += delegate(object s, EventArgs ev)
				{
					this.ExportCsv();
				};
				button3.Click += delegate(object s, EventArgs ev)
				{
					this.OnRevertSelected();
				};
				button4.Click += delegate(object s, EventArgs ev)
				{
					this.OnRevertAll();
				};
				flowLayoutPanel.Controls.Add(button);
				flowLayoutPanel.Controls.Add(button2);
				flowLayoutPanel.Controls.Add(button3);
				flowLayoutPanel.Controls.Add(button4);
				FlowLayoutPanel flowLayoutPanel2 = new FlowLayoutPanel
				{
					Dock = DockStyle.Fill,
					FlowDirection = FlowDirection.LeftToRight,
					WrapContents = false,
					BackColor = this._bgPanel,
					Margin = new Padding(0),
					Padding = new Padding(0, 4, 0, 0)
				};
				this._filterChangedOnly = new CheckBox
				{
					Text = "Show changed only",
					AutoSize = true,
					ForeColor = this._fg,
					BackColor = this._bgPanel,
					Checked = false,
					Margin = new Padding(0, 3, 16, 0)
				};
				this._filterChangedOnly.CheckedChanged += delegate(object s, EventArgs ev)
				{
					this.RefreshGrid();
				};
				Label label = new Label
				{
					Text = "Compare Mode:",
					AutoSize = true,
					ForeColor = this._cyan,
					BackColor = this._bgPanel,
					Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
					Margin = new Padding(0, 4, 8, 0)
				};
				this._rbAbsolute = this.MakeRadio("1. Absolute", true);
				this._rbDifference = this.MakeRadio("2. Difference (Δ)", false);
				this._rbPercentage = this.MakeRadio("3. Percentage (%)", false);
				flowLayoutPanel2.Controls.AddRange(new Control[]
				{
					this._filterChangedOnly,
					label,
					this._rbAbsolute,
					this._rbDifference,
					this._rbPercentage
				});
				roundedPanel.Controls.Add(flowLayoutPanel2);
				roundedPanel.Controls.Add(flowLayoutPanel);
				return roundedPanel;
			}

			// Token: 0x06001675 RID: 5749 RVA: 0x000B192C File Offset: 0x000B192C
			private RadioButton MakeRadio(string text, bool isChecked)
			{
				RadioButton rb = new RadioButton
				{
					Text = text,
					AutoSize = true,
					ForeColor = this._fg,
					BackColor = this._bgPanel,
					Checked = isChecked,
					Margin = new Padding(0, 3, 14, 0)
				};
				rb.CheckedChanged += delegate(object s, EventArgs ev)
				{
					if (rb.Checked)
					{
						this.RefreshGrid();
					}
				};
				return rb;
			}

			// Token: 0x06001676 RID: 5750 RVA: 0x000B19AC File Offset: 0x000B19AC
			private Button MakeBtn(string text, Color accent)
			{
				return new MapEditorForm.CompareForm.RoundedButton
				{
					Text = text,
					Size = new Size(150, 30),
					Accent = accent,
					Radius = 8,
					BackNormal = Color.FromArgb(45, 55, 65),
					BackHover = Color.FromArgb(60, 75, 90),
					Margin = new Padding(8, 0, 0, 0)
				};
			}

			// Token: 0x06001677 RID: 5751 RVA: 0x000B1A18 File Offset: 0x000B1A18
			private Control BuildGridHost()
			{
				Panel panel = new Panel();
				panel.Dock = DockStyle.Fill;
				panel.BackColor = this._bgPanel;
				panel.Padding = new Padding(1);
				panel.Margin = new Padding(0);
				this._grid = new DataGridView
				{
					Dock = DockStyle.Fill,
					BackgroundColor = this._bgGrid,
					BorderStyle = BorderStyle.None,
					GridColor = Color.FromArgb(50, 60, 72),
					EnableHeadersVisualStyles = false,
					AllowUserToAddRows = false,
					AllowUserToDeleteRows = false,
					AllowUserToResizeRows = false,
					ReadOnly = true,
					SelectionMode = DataGridViewSelectionMode.CellSelect,
					MultiSelect = true,
					RowHeadersVisible = false,
					AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
					AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None,
					ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
					ColumnHeadersHeight = 32,
					ScrollBars = ScrollBars.Both,
					RowTemplate = 
					{
						Height = 26
					}
				};
				this._grid.DefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = this._bgGrid,
					ForeColor = Color.White,
					SelectionBackColor = this._cyan,
					SelectionForeColor = Color.Black,
					Font = new Font("Consolas", 9f),
					Alignment = DataGridViewContentAlignment.MiddleCenter,
					Padding = new Padding(2)
				};
				this._grid.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = Color.FromArgb(28, 35, 44),
					ForeColor = this._cyan,
					SelectionBackColor = Color.FromArgb(28, 35, 44),
					SelectionForeColor = this._cyan,
					Font = new Font("Segoe UI", 9f, FontStyle.Bold),
					Alignment = DataGridViewContentAlignment.MiddleCenter
				};
				this._grid.CellFormatting += this.Grid_CellFormatting;
				this._grid.SelectionChanged += delegate(object s, EventArgs ev)
				{
					this.UpdateStatus();
				};
				panel.Controls.Add(this._grid);
				return panel;
			}

			// Token: 0x06001678 RID: 5752 RVA: 0x000B1C04 File Offset: 0x000B1C04
			private Control BuildStatusBar()
			{
				MapEditorForm.CompareForm.RoundedPanel roundedPanel = new MapEditorForm.CompareForm.RoundedPanel();
				roundedPanel.Dock = DockStyle.Fill;
				roundedPanel.Fill = this._bgPanel;
				roundedPanel.Radius = 6;
				roundedPanel.Margin = new Padding(0, 6, 0, 0);
				this._statusBar = new Label
				{
					Dock = DockStyle.Fill,
					ForeColor = this._muted,
					Font = new Font("Consolas", 8.5f),
					Text = "",
					Padding = new Padding(12, 6, 12, 6),
					BackColor = this._bgPanel,
					TextAlign = ContentAlignment.MiddleLeft
				};
				roundedPanel.Controls.Add(this._statusBar);
				return roundedPanel;
			}

			// Token: 0x06001679 RID: 5753 RVA: 0x000B1CB4 File Offset: 0x000B1CB4
			private void UpdateStatus()
			{
				if (this._statusBar == null)
				{
					return;
				}
				this._statusBar.Text = string.Format("Selected cells: {0}   |   Cols: {1}   |   Rows: {2}   |   BIN: {3} ({4} → {5} bytes)", new object[]
				{
					this._grid.SelectedCells.Count,
					Math.Max(0, checked(this._grid.Columns.Count - 1)),
					this._grid.Rows.Count,
					this._binName,
					this._originalSize,
					this._editedSize
				});
			}

			// Token: 0x0600167A RID: 5754 RVA: 0x000B1D5C File Offset: 0x000B1D5C
			private void OnRevertAll()
			{
				if (MapEditorForm.CustomMessageBox.Show(this, "Revert SEMUA perubahan ke original?\nTindakan ini bisa di-undo via Ctrl+Z.", "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
				{
					Action onRevertAll = this._onRevertAll;
					if (onRevertAll == null)
					{
						return;
					}
					onRevertAll();
				}
			}

			// Token: 0x0600167B RID: 5755 RVA: 0x000B1D90 File Offset: 0x000B1D90
			private void OnRevertSelected()
			{
				List<int> selectedAddresses = this.GetSelectedAddresses();
				if (selectedAddresses.Count == 0)
				{
					MapEditorForm.CustomMessageBox.Show(this, "Pilih dulu satu atau lebih sel di tabel.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					return;
				}
				Action<List<int>> onRevertSelected = this._onRevertSelected;
				if (onRevertSelected == null)
				{
					return;
				}
				onRevertSelected(selectedAddresses);
			}

			// Token: 0x1700015A RID: 346
			// (get) Token: 0x0600167C RID: 5756 RVA: 0x0000DB4E File Offset: 0x0000DB4E
			protected override CreateParams CreateParams
			{
				get
				{
					CreateParams createParams = base.CreateParams;
					createParams.Style &= -8388609;
					createParams.ExStyle &= -513;
					createParams.ExStyle &= -257;
					return createParams;
				}
			}

			// Token: 0x0600167D RID: 5757 RVA: 0x000B1DD4 File Offset: 0x000B1DD4
			public CompareForm(List<MapEditorForm.CompareForm.DiffEntry> diffs, int editedSize, int originalSize, string binName, Action onRevertAll, Action<List<int>> onRevertSelected, XdfTable table = null, byte[] snapshotBin = null, byte[] originalBin = null, bool swapAxes = false)
			{
				this._all = (diffs ?? new List<MapEditorForm.CompareForm.DiffEntry>());
				this._editedSize = editedSize;
				this._originalSize = originalSize;
				this._binName = (binName ?? "(unknown)");
				this._onRevertAll = onRevertAll;
				this._onRevertSelected = onRevertSelected;
				this._table = table;
				this._snapshotBin = snapshotBin;
				this._originalBin = originalBin;
				this._swapAxes = swapAxes;
				this.Text = "COMPARE — Edited vs Original BIN";
				base.ClientSize = new Size(1280, 720);
				base.StartPosition = FormStartPosition.CenterScreen;
				this.BackColor = Color.FromArgb(45, 55, 65);
				this.ForeColor = Color.Cyan;
				this.Font = new Font("Segoe UI", 9f);
				base.FormBorderStyle = FormBorderStyle.None;
				base.MinimizeBox = false;
				base.MaximizeBox = false;
				base.Padding = new Padding(10);
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
				base.UpdateStyles();
				this.DoubleBuffered = true;
				TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
				{
					Dock = DockStyle.Fill,
					ColumnCount = 1,
					RowCount = 4,
					Padding = new Padding(10),
					Margin = new Padding(0),
					BackColor = this._bgDark
				};
				tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 64f));
				tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 80f));
				tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
				tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 32f));
				tableLayoutPanel.Controls.Add(this.BuildHeader(), 0, 0);
				tableLayoutPanel.Controls.Add(this.BuildToolbar(), 0, 1);
				tableLayoutPanel.Controls.Add(this.BuildGridHost(), 0, 2);
				tableLayoutPanel.Controls.Add(this.BuildStatusBar(), 0, 3);
				base.Controls.Add(tableLayoutPanel);
				this.BuildPivotCache();
				this.RefreshGrid();
			}

			// Token: 0x0600167E RID: 5758 RVA: 0x0000DB8C File Offset: 0x0000DB8C
			public void SetSwapAxes(bool swapAxes)
			{
				if (this._swapAxes == swapAxes)
				{
					return;
				}
				this._swapAxes = swapAxes;
				this._cachedTps = null;
				this._cachedRpm = null;
				this.BuildPivotCache();
				this.RefreshGrid();
			}

			// Token: 0x04001C52 RID: 7250
			private DataGridView _grid;

			// Token: 0x04001C53 RID: 7251
			private Label _summary;

			// Token: 0x04001C54 RID: 7252
			private Label _statusBar;

			// Token: 0x04001C55 RID: 7253
			private CheckBox _filterChangedOnly;

			// Token: 0x04001C56 RID: 7254
			private List<MapEditorForm.CompareForm.DiffEntry> _all;

			// Token: 0x04001C57 RID: 7255
			private int _editedSize;

			// Token: 0x04001C58 RID: 7256
			private int _originalSize;

			// Token: 0x04001C59 RID: 7257
			private string _binName;

			// Token: 0x04001C5A RID: 7258
			private Action _onRevertAll;

			// Token: 0x04001C5B RID: 7259
			private Action<List<int>> _onRevertSelected;

			// Token: 0x04001C5C RID: 7260
			private readonly Color _bgDark = Color.FromArgb(18, 23, 29);

			// Token: 0x04001C5D RID: 7261
			private readonly Color _bgPanel = Color.FromArgb(22, 28, 35);

			// Token: 0x04001C5E RID: 7262
			private readonly Color _cyan = Color.FromArgb(0, 255, 230);

			// Token: 0x04001C5F RID: 7263
			private readonly Color _fg = Color.FromArgb(225, 238, 245);

			// Token: 0x04001C60 RID: 7264
			private readonly Color _muted = Color.FromArgb(135, 158, 174);

			// Token: 0x04001C61 RID: 7265
			private readonly Color _danger = Color.FromArgb(255, 90, 105);

			// Token: 0x04001C62 RID: 7266
			private readonly Color _green = Color.FromArgb(0, 255, 150);

			// Token: 0x04001C63 RID: 7267
			private readonly Color _orange = Color.FromArgb(255, 165, 0);

			// Token: 0x04001C64 RID: 7268
			private RadioButton _rbAbsolute;

			// Token: 0x04001C65 RID: 7269
			private RadioButton _rbDifference;

			// Token: 0x04001C66 RID: 7270
			private RadioButton _rbPercentage;

			// Token: 0x04001C67 RID: 7271
			private bool _dragging;

			// Token: 0x04001C68 RID: 7272
			private Point _dragStart;

			// Token: 0x04001C69 RID: 7273
			private Point _formStart;

			// Token: 0x04001C6A RID: 7274
			private List<int> _cachedTps;

			// Token: 0x04001C6B RID: 7275
			private List<int> _cachedRpm;

			// Token: 0x04001C6C RID: 7276
			private bool _useMatrixMode;

			// Token: 0x04001C6D RID: 7277
			private XdfTable _table;

			// Token: 0x04001C6E RID: 7278
			private byte[] _snapshotBin;

			// Token: 0x04001C6F RID: 7279
			private byte[] _originalBin;

			// Token: 0x04001C70 RID: 7280
			private double _minVal;

			// Token: 0x04001C71 RID: 7281
			private double _maxVal;

			// Token: 0x04001C72 RID: 7282
			private readonly Color _bgGrid = Color.FromArgb(32, 38, 46);

			// Token: 0x04001C73 RID: 7283
			private bool _rpmOnTop;

			// Token: 0x04001C74 RID: 7284
			private int _visualRows;

			// Token: 0x04001C75 RID: 7285
			private int _visualCols;

			// Token: 0x04001C76 RID: 7286
			private bool _swapAxes;

			// Token: 0x02000806 RID: 2054
			public sealed class DiffEntry
			{
				// Token: 0x1700015B RID: 347
				// (get) Token: 0x06001688 RID: 5768 RVA: 0x0000DC17 File Offset: 0x0000DC17
				public int Delta
				{
					get
					{
						return (int)(checked(this.NewByte - this.OldByte));
					}
				}

				// Token: 0x1700015C RID: 348
				// (get) Token: 0x0600168A RID: 5770 RVA: 0x0000DC26 File Offset: 0x0000DC26
				public int OldValue
				{
					get
					{
						return (int)this.OldByte;
					}
				}

				// Token: 0x1700015D RID: 349
				// (get) Token: 0x0600168B RID: 5771 RVA: 0x0000DC2E File Offset: 0x0000DC2E
				public int NewValue
				{
					get
					{
						return (int)this.NewByte;
					}
				}

				// Token: 0x04001C77 RID: 7287
				public int Address;

				// Token: 0x04001C78 RID: 7288
				public byte OldByte;

				// Token: 0x04001C79 RID: 7289
				public byte NewByte;

				// Token: 0x04001C7A RID: 7290
				public string TableName;

				// Token: 0x04001C7B RID: 7291
				public string Units;

				// Token: 0x04001C7C RID: 7292
				public int Tps;

				// Token: 0x04001C7D RID: 7293
				public int Rpm;
			}

			// Token: 0x02000808 RID: 2056
			private sealed class CellTag
			{
				// Token: 0x04001C81 RID: 7297
				public int Address;

				// Token: 0x04001C82 RID: 7298
				public double OldValue;

				// Token: 0x04001C83 RID: 7299
				public double NewValue;

				// Token: 0x04001C84 RID: 7300
				public bool Changed;
			}

			// Token: 0x02000809 RID: 2057
			private sealed class RoundedPanel : Panel
			{
				// Token: 0x1700015E RID: 350
				// (get) Token: 0x06001691 RID: 5777 RVA: 0x0000DC5D File Offset: 0x0000DC5D
				// (set) Token: 0x06001692 RID: 5778 RVA: 0x0000DC65 File Offset: 0x0000DC65
				public int Radius
				{
					get
					{
						return this._radius;
					}
					set
					{
						this._radius = Math.Max(0, value);
						base.Invalidate();
					}
				}

				// Token: 0x1700015F RID: 351
				// (get) Token: 0x06001693 RID: 5779 RVA: 0x0000DC7A File Offset: 0x0000DC7A
				// (set) Token: 0x06001694 RID: 5780 RVA: 0x0000DC82 File Offset: 0x0000DC82
				public Color Fill
				{
					get
					{
						return this._fill;
					}
					set
					{
						this._fill = (value.IsEmpty ? Color.FromArgb(40, 48, 58) : value);
						base.Invalidate();
					}
				}

				// Token: 0x06001695 RID: 5781 RVA: 0x0000DCA7 File Offset: 0x0000DCA7
				public RoundedPanel()
				{
					base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
					this.BackColor = this._fill;
				}

				// Token: 0x06001696 RID: 5782 RVA: 0x000B20FC File Offset: 0x000B20FC
				protected override void OnPaint(PaintEventArgs e)
				{
					Graphics graphics = e.Graphics;
					graphics.SmoothingMode = SmoothingMode.AntiAlias;
					using (GraphicsPath graphicsPath = MapEditorForm.CompareForm.RoundedPanel.Rounded(checked(new Rectangle(0, 0, base.Width - 1, base.Height - 1)), this._radius))
					{
						using (SolidBrush solidBrush = new SolidBrush(this._fill))
						{
							graphics.FillPath(solidBrush, graphicsPath);
						}
					}
					base.OnPaint(e);
				}

				// Token: 0x06001697 RID: 5783 RVA: 0x000B2188 File Offset: 0x000B2188
				private static GraphicsPath Rounded(Rectangle r, int rad)
				{
					GraphicsPath graphicsPath = new GraphicsPath();
					if (rad <= 0)
					{
						graphicsPath.AddRectangle(r);
						return graphicsPath;
					}
					checked
					{
						int num = rad * 2;
						graphicsPath.AddArc(r.X, r.Y, num, num, 180f, 90f);
						graphicsPath.AddArc(r.Right - num, r.Y, num, num, 270f, 90f);
						graphicsPath.AddArc(r.Right - num, r.Bottom - num, num, num, 0f, 90f);
						graphicsPath.AddArc(r.X, r.Bottom - num, num, num, 90f, 90f);
						graphicsPath.CloseFigure();
						return graphicsPath;
					}
				}

				// Token: 0x04001C85 RID: 7301
				private int _radius = 8;

				// Token: 0x04001C86 RID: 7302
				private Color _fill = Color.FromArgb(40, 48, 58);
			}

			// Token: 0x0200080A RID: 2058
			private sealed class RoundedButton : Button
			{
				// Token: 0x17000160 RID: 352
				// (get) Token: 0x06001698 RID: 5784 RVA: 0x0000DCDF File Offset: 0x0000DCDF
				// (set) Token: 0x06001699 RID: 5785 RVA: 0x0000DCE7 File Offset: 0x0000DCE7
				public int Radius
				{
					get
					{
						return this._radius;
					}
					set
					{
						this._radius = Math.Max(0, value);
						base.Invalidate();
					}
				}

				// Token: 0x17000161 RID: 353
				// (get) Token: 0x0600169A RID: 5786 RVA: 0x0000DCFC File Offset: 0x0000DCFC
				// (set) Token: 0x0600169B RID: 5787 RVA: 0x0000DD04 File Offset: 0x0000DD04
				public Color Accent
				{
					get
					{
						return this._accent;
					}
					set
					{
						this._accent = (value.IsEmpty ? Color.FromArgb(0, 255, 230) : value);
						this.ForeColor = this._accent;
						base.Invalidate();
					}
				}

				// Token: 0x17000162 RID: 354
				// (get) Token: 0x0600169C RID: 5788 RVA: 0x0000DD3A File Offset: 0x0000DD3A
				// (set) Token: 0x0600169D RID: 5789 RVA: 0x0000DD42 File Offset: 0x0000DD42
				public Color BackNormal
				{
					get
					{
						return this._back;
					}
					set
					{
						this._back = (value.IsEmpty ? Color.FromArgb(45, 55, 65) : value);
						base.Invalidate();
					}
				}

				// Token: 0x17000163 RID: 355
				// (get) Token: 0x0600169E RID: 5790 RVA: 0x0000DD67 File Offset: 0x0000DD67
				// (set) Token: 0x0600169F RID: 5791 RVA: 0x0000DD6F File Offset: 0x0000DD6F
				public Color BackHover
				{
					get
					{
						return this._hoverBack;
					}
					set
					{
						this._hoverBack = (value.IsEmpty ? Color.FromArgb(60, 75, 90) : value);
						base.Invalidate();
					}
				}

				// Token: 0x060016A0 RID: 5792 RVA: 0x000B223C File Offset: 0x000B223C
				public RoundedButton()
				{
					base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
					base.FlatStyle = FlatStyle.Flat;
					base.FlatAppearance.BorderSize = 0;
					this.BackColor = this._back;
					this.ForeColor = this._accent;
					this.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
					this.Cursor = Cursors.Hand;
				}

				// Token: 0x060016A1 RID: 5793 RVA: 0x0000DD94 File Offset: 0x0000DD94
				protected override void OnMouseEnter(EventArgs e)
				{
					this._hover = true;
					base.Invalidate();
					base.OnMouseEnter(e);
				}

				// Token: 0x060016A2 RID: 5794 RVA: 0x0000DDAA File Offset: 0x0000DDAA
				protected override void OnMouseLeave(EventArgs e)
				{
					this._hover = false;
					base.Invalidate();
					base.OnMouseLeave(e);
				}

				// Token: 0x060016A3 RID: 5795 RVA: 0x000B2188 File Offset: 0x000B2188
				private static GraphicsPath RoundedPath(Rectangle r, int rad)
				{
					GraphicsPath graphicsPath = new GraphicsPath();
					if (rad <= 0)
					{
						graphicsPath.AddRectangle(r);
						return graphicsPath;
					}
					checked
					{
						int num = rad * 2;
						graphicsPath.AddArc(r.X, r.Y, num, num, 180f, 90f);
						graphicsPath.AddArc(r.Right - num, r.Y, num, num, 270f, 90f);
						graphicsPath.AddArc(r.Right - num, r.Bottom - num, num, num, 0f, 90f);
						graphicsPath.AddArc(r.X, r.Bottom - num, num, num, 90f, 90f);
						graphicsPath.CloseFigure();
						return graphicsPath;
					}
				}

				// Token: 0x060016A4 RID: 5796 RVA: 0x000B22E8 File Offset: 0x000B22E8
				protected override void OnPaint(PaintEventArgs e)
				{
					Graphics graphics = e.Graphics;
					using (SolidBrush solidBrush = new SolidBrush((base.Parent != null) ? base.Parent.BackColor : this.BackColor))
					{
						graphics.FillRectangle(solidBrush, base.ClientRectangle);
					}
					graphics.SmoothingMode = SmoothingMode.AntiAlias;
					graphics.PixelOffsetMode = PixelOffsetMode.Half;
					checked
					{
						Rectangle rectangle = new Rectangle(0, 0, base.Width - 1, base.Height - 1);
						using (GraphicsPath graphicsPath = MapEditorForm.CompareForm.RoundedButton.RoundedPath(rectangle, this._radius))
						{
							using (SolidBrush solidBrush2 = new SolidBrush(this._hover ? this._hoverBack : this._back))
							{
								graphics.FillPath(solidBrush2, graphicsPath);
							}
							using (Pen pen = new Pen(this._accent, 2f)
							{
								Alignment = PenAlignment.Inset
							})
							{
								graphics.DrawPath(pen, graphicsPath);
							}
							if (this._hover)
							{
								using (GraphicsPath graphicsPath2 = MapEditorForm.CompareForm.RoundedButton.RoundedPath(Rectangle.Inflate(rectangle, -2, -2), Math.Max(0, this._radius - 2)))
								{
									using (Pen pen2 = new Pen(Color.FromArgb(120, this._accent), 1f))
									{
										graphics.DrawPath(pen2, graphicsPath2);
									}
								}
							}
							TextRenderer.DrawText(graphics, this.Text, this.Font, rectangle, this._accent, TextFormatFlags.EndEllipsis | TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
						}
					}
				}

				// Token: 0x04001C87 RID: 7303
				private int _radius = 8;

				// Token: 0x04001C88 RID: 7304
				private Color _accent = Color.FromArgb(0, 255, 230);

				// Token: 0x04001C89 RID: 7305
				private Color _back = Color.FromArgb(45, 55, 65);

				// Token: 0x04001C8A RID: 7306
				private Color _hoverBack = Color.FromArgb(60, 75, 90);

				// Token: 0x04001C8B RID: 7307
				private bool _hover;
			}
		}

		// Token: 0x0200080C RID: 2060
		public sealed class SelectCompareBinsForm : Form
		{
			// Token: 0x17000164 RID: 356
			// (get) Token: 0x060016A7 RID: 5799 RVA: 0x0000DDDA File Offset: 0x0000DDDA
			// (set) Token: 0x060016A8 RID: 5800 RVA: 0x0000DDE2 File Offset: 0x0000DDE2
			public string[] SelectedFiles { get; private set; } = new string[4];

			// Token: 0x17000165 RID: 357
			// (get) Token: 0x060016A9 RID: 5801 RVA: 0x0000DDEB File Offset: 0x0000DDEB
			// (set) Token: 0x060016AA RID: 5802 RVA: 0x0000DDF3 File Offset: 0x0000DDF3
			public bool[] EnabledBins { get; private set; } = new bool[4];

			// Token: 0x060016AB RID: 5803 RVA: 0x000B24A8 File Offset: 0x000B24A8
			public SelectCompareBinsForm()
			{
				this.Text = "Select Compare Bins";
				base.ClientSize = new Size(520, 210);
				base.FormBorderStyle = FormBorderStyle.None;
				base.MaximizeBox = false;
				base.MinimizeBox = false;
				base.StartPosition = FormStartPosition.CenterParent;
				this.BackColor = Color.FromArgb(16, 23, 30);
				this.ForeColor = Color.FromArgb(225, 238, 245);
				this.Font = new Font("Segoe UI", 9f);
				base.Padding = new Padding(2);
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
				Label value = new Label
				{
					Text = "Enable",
					Location = new Point(20, 10),
					AutoSize = true,
					ForeColor = Color.FromArgb(0, 255, 230),
					Font = new Font("Segoe UI", 9f, FontStyle.Bold)
				};
				base.Controls.Add(value);
				checked
				{
					for (int i = 0; i < 4; i++)
					{
						int num = 35 + i * 32;
						CheckBox chk = new CheckBox
						{
							Text = string.Format("Bin {0}", i + 1),
							Location = new Point(20, num + 3),
							AutoSize = true,
							ForeColor = Color.White
						};
						TextBox txt = new TextBox
						{
							Location = new Point(80, num),
							Width = 380,
							BackColor = Color.FromArgb(20, 28, 36),
							ForeColor = Color.White,
							BorderStyle = BorderStyle.FixedSingle
						};
						Button button = new Button
						{
							Text = "Browse...",
							Location = new Point(465, num - 1),
							Size = new Size(40, 23),
							FlatStyle = FlatStyle.Flat,
							ForeColor = Color.FromArgb(0, 255, 230),
							BackColor = Color.Transparent
						};
						button.FlatAppearance.BorderSize = 0;
						button.Click += delegate(object s, EventArgs ev)
						{
							using (OpenFileDialog openFileDialog = new OpenFileDialog
							{
								Filter = "BIN Files (*.bin)|*.bin|All Files (*.*)|*.*"
							})
							{
								if (openFileDialog.ShowDialog() == DialogResult.OK)
								{
									txt.Text = openFileDialog.FileName;
									chk.Checked = true;
								}
							}
						};
						base.Controls.Add(chk);
						base.Controls.Add(txt);
						base.Controls.Add(button);
					}
					Button button2 = new Button
					{
						Text = "OK",
						Location = new Point(180, 170),
						Size = new Size(75, 28),
						FlatStyle = FlatStyle.Flat,
						ForeColor = Color.FromArgb(0, 255, 230),
						BackColor = Color.Transparent
					};
					button2.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 230);
					button2.Click += delegate(object s, EventArgs ev)
					{
						for (int j = 0; j < 4; j++)
						{
							CheckBox[] array = base.Controls.OfType<CheckBox>().ToArray<CheckBox>();
							TextBox[] array2 = base.Controls.OfType<TextBox>().ToArray<TextBox>();
							if (j < array.Length && j < array2.Length)
							{
								this.EnabledBins[j] = (array[j].Checked && !string.IsNullOrWhiteSpace(array2[j].Text));
								this.SelectedFiles[j] = array2[j].Text;
							}
						}
						base.DialogResult = DialogResult.OK;
					};
					Button button3 = new Button
					{
						Text = "Cancel",
						Location = new Point(270, 170),
						Size = new Size(75, 28),
						FlatStyle = FlatStyle.Flat,
						ForeColor = Color.FromArgb(135, 158, 174),
						BackColor = Color.Transparent
					};
					button3.FlatAppearance.BorderColor = Color.FromArgb(135, 158, 174);
					button3.Click += delegate(object s, EventArgs ev)
					{
						base.DialogResult = DialogResult.Cancel;
					};
					base.Controls.Add(button2);
					base.Controls.Add(button3);
					base.AcceptButton = button2;
					base.CancelButton = button3;
					bool drag = false;
					Point ds = Point.Empty;
					Point fs = Point.Empty;
					base.MouseDown += delegate(object s, MouseEventArgs ev)
					{
						if (ev.Button == MouseButtons.Left)
						{
							drag = true;
							ds = Cursor.Position;
							fs = this.Location;
						}
					};
					base.MouseMove += delegate(object s, MouseEventArgs ev)
					{
						if (drag)
						{
							Point position = Cursor.Position;
							this.Location = new Point(fs.X + position.X - ds.X, fs.Y + position.Y - ds.Y);
						}
					};
					base.MouseUp += delegate(object s, MouseEventArgs ev)
					{
						drag = false;
					};
				}
			}

			// Token: 0x060016AC RID: 5804 RVA: 0x000B28D0 File Offset: 0x000B28D0
			protected override void OnPaint(PaintEventArgs e)
			{
				base.OnPaint(e);
				e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				using (GraphicsPath graphicsPath = MapEditorForm.CreateRoundedPath(new Rectangle(0, 0, base.Width, base.Height), 14))
				{
					e.Graphics.FillPath(new SolidBrush(this.BackColor), graphicsPath);
					using (Pen pen = new Pen(Color.FromArgb(0, 255, 230), 2f))
					{
						e.Graphics.DrawPath(pen, graphicsPath);
					}
				}
			}
		}

		// Token: 0x02000819 RID: 2073
		public enum LiveProtocol
		{
			// Token: 0x04001CB3 RID: 7347
			HondaKLine,
			// Token: 0x04001CB4 RID: 7348
			HondaCAN,
			// Token: 0x04001CB5 RID: 7349
			GenericOBD2
		}

		// Token: 0x0200081A RID: 2074
		public sealed class LiveFrame
		{
			// Token: 0x04001CB6 RID: 7350
			public int RPM;

			// Token: 0x04001CB7 RID: 7351
			public float TPS;

			// Token: 0x04001CB8 RID: 7352
			public float MAP;

			// Token: 0x04001CB9 RID: 7353
			public float CL;

			// Token: 0x04001CBA RID: 7354
			public float IAT;

			// Token: 0x04001CBB RID: 7355
			public float AD;

			// Token: 0x04001CBC RID: 7356
			public float InjectorMs;

			// Token: 0x04001CBD RID: 7357
			public float IDC;

			// Token: 0x04001CBE RID: 7358
			public float O2V;

			// Token: 0x04001CBF RID: 7359
			public float AFR;

			// Token: 0x04001CC0 RID: 7360
			public float BatteryV;

			// Token: 0x04001CC1 RID: 7361
			public DateTime Timestamp = DateTime.Now;

			// Token: 0x04001CC2 RID: 7362
			public bool Valid;
		}

		// Token: 0x0200081B RID: 2075
		private sealed class LiveDataReader : IDisposable
		{
			// Token: 0x17000166 RID: 358
			// (get) Token: 0x060016E6 RID: 5862 RVA: 0x0000E05D File Offset: 0x0000E05D
			// (set) Token: 0x060016EB RID: 5867 RVA: 0x0000E06D File Offset: 0x0000E06D
			public string PortName { get; private set; }

			// Token: 0x17000167 RID: 359
			// (get) Token: 0x060016E7 RID: 5863 RVA: 0x0000E065 File Offset: 0x0000E065
			public bool IsOpen
			{
				get
				{
					return this._isOpen;
				}
			}

			// Token: 0x060016E8 RID: 5864 RVA: 0x000B3440 File Offset: 0x000B3440
			public void Open()
			{
				uint num = 0U;
				uint.TryParse(this.PortName, out num);
				if (FTD2XX_NET.FTDI.FT_Open(num, ref this._ftHandle) != null)
				{
					throw new IOException("Gagal buka FTDI index " + num);
				}
				if (FTD2XX_NET.FTDI.FT_Purge(this._ftHandle, 3U) != null)
				{
					this.Fail("purge");
					return;
				}
				if (FTD2XX_NET.FTDI.FT_SetBitMode(this._ftHandle, 0, 0) != null)
				{
					this.Fail("bitmode0");
					return;
				}
				if (FTD2XX_NET.FTDI.FT_SetDataCharacteristics(this._ftHandle, 8, 0, 0) != null)
				{
					this.Fail("datachar");
					return;
				}
				checked
				{
					if (FTD2XX_NET.FTDI.FT_SetBaudRate(this._ftHandle, (uint)this._baud) != null)
					{
						this.Fail("baud");
						return;
					}
					if (FTD2XX_NET.FTDI.FT_SetTimeouts(this._ftHandle, 300U, 0U) != null)
					{
						this.Fail("timeout");
						return;
					}
					if (FTD2XX_NET.FTDI.FT_SetLatencyTimer(this._ftHandle, 8) != null)
					{
						this.Fail("latency");
						return;
					}
					if (FTD2XX_NET.FTDI.FT_SetBitMode(this._ftHandle, 1, 1) != null)
					{
						this.Fail("bitmode_tx");
						return;
					}
					uint num2 = 0U;
					FTD2XX_NET.FTDI.FT_Write(this._ftHandle, new byte[1], 1U, ref num2);
					Thread.Sleep(200);
					FTD2XX_NET.FTDI.FT_Write(this._ftHandle, new byte[]
					{
						1
					}, 1U, ref num2);
					Thread.Sleep(80);
					FTD2XX_NET.FTDI.FT_SetBitMode(this._ftHandle, 0, 0);
					FTD2XX_NET.FTDI.FT_SetBaudRate(this._ftHandle, (uint)this._baud);
					FTD2XX_NET.FTDI.FT_Purge(this._ftHandle, 3U);
					Thread.Sleep(300);
					this._isOpen = true;
					this._handshakeDone = false;
					this.LastDebugHex = "open ok";
				}
			}

			// Token: 0x060016E9 RID: 5865 RVA: 0x000B35D8 File Offset: 0x000B35D8
			public void Dispose()
			{
				try
				{
					if (this._ftHandle != IntPtr.Zero)
					{
						FTD2XX_NET.FTDI.FT_Close(this._ftHandle);
					}
				}
				catch
				{
				}
				this._ftHandle = IntPtr.Zero;
				this._isOpen = false;
				this._handshakeDone = false;
			}

			// Token: 0x060016EA RID: 5866 RVA: 0x000B3634 File Offset: 0x000B3634
			public MapEditorForm.LiveFrame ReadFrame()
			{
				if (!this._isOpen || this._ftHandle == IntPtr.Zero)
				{
					return null;
				}
				if (this._protocol != MapEditorForm.LiveProtocol.HondaKLine)
				{
					return null;
				}
				MapEditorForm.LiveFrame result;
				try
				{
					if (!this.DoHandshake())
					{
						result = null;
					}
					else
					{
						if ((DateTime.Now - this._lastKeepAliveMs).TotalMilliseconds >= 1000.0)
						{
							byte[] array = new byte[256];
							uint num = 0U;
							byte[] array2 = new byte[]
							{
								114,
								5,
								0,
								240,
								153
							};
							this.SendCommand(array2, array2.Length, ref array, ref num, 0);
							FTD2XX_NET.FTDI.FT_Purge(this._ftHandle, 3U);
							Thread.Sleep(20);
							this._lastKeepAliveMs = DateTime.Now;
						}
						byte[] array3 = this.BuildDat10Request1();
						byte[] array4 = new byte[256];
						uint num2 = 0U;
						this.SendCommand(array3, array3.Length, ref array4, ref num2, 0);
						this.LastResponseLen = checked((int)num2);
						if (num2 < 6U)
						{
							this.LastDebugHex = string.Format("DAT10 [{0}B] too short: {1}", num2, this.HexOf(array4, num2, 24));
							result = null;
						}
						else
						{
							int startIdx = 0;
							if (array4[0] == 113 && array4[1] == 16)
							{
								startIdx = 2;
							}
							MapEditorForm.LiveFrame liveFrame = this.DecodeDat10(array4, num2, startIdx);
							if (liveFrame != null)
							{
								this.LastDebugHex = string.Format("OK RPM={0} TPS={1:F1} | RAW={2}", liveFrame.RPM, liveFrame.TPS, this.HexOf(array4, num2, 24));
							}
							else
							{
								this.LastDebugHex = "decode null";
							}
							result = liveFrame;
						}
					}
				}
				catch (Exception ex)
				{
					this.LastDebugHex = "ex: " + ex.Message;
					result = null;
				}
				return result;
			}

			// Token: 0x060016EC RID: 5868 RVA: 0x000B37EC File Offset: 0x000B37EC
			private bool DoHandshake()
			{
				if (this._handshakeDone)
				{
					return true;
				}
				if (!this.SendRaw(new byte[]
				{
					254,
					4,
					114,
					140
				}))
				{
					this.LastDebugHex = "HS1 no reply";
					return false;
				}
				Thread.Sleep(50);
				if (!this.SendRaw(new byte[]
				{
					114,
					5,
					0,
					240,
					153
				}))
				{
					this.LastDebugHex = "HS2 KA no reply";
					return false;
				}
				Thread.Sleep(50);
				if (!this.SendRaw(new byte[]
				{
					114,
					5,
					0,
					240,
					153
				}))
				{
					this.LastDebugHex = "HS3 KA no reply";
					return false;
				}
				Thread.Sleep(50);
				this._handshakeDone = true;
				this._lastMaintainMs = DateTime.Now;
				this._lastKeepAliveMs = DateTime.Now;
				this.LastDebugHex = "HS OK";
				FTD2XX_NET.FTDI.FT_Purge(this._ftHandle, 3U);
				Thread.Sleep(150);
				return true;
			}

			// Token: 0x060016ED RID: 5869 RVA: 0x000B38CC File Offset: 0x000B38CC
			private bool SendRaw(byte[] data)
			{
				uint num = 0U;
				if (FTD2XX_NET.FTDI.FT_Write(this._ftHandle, data, checked((uint)data.Length), ref num) != null)
				{
					return false;
				}
				Thread.Sleep(50);
				uint num2 = 0U;
				FTD2XX_NET.FTDI.FT_GetQueueStatus(this._ftHandle, ref num2);
				if (num2 == 0U)
				{
					return false;
				}
				byte[] array = new byte[num2];
				uint num3 = 0U;
				FTD2XX_NET.FTDI.FT_Read(this._ftHandle, array, num2, ref num3);
				return num3 > 0U;
			}

			// Token: 0x17000168 RID: 360
			// (get) Token: 0x060016EE RID: 5870 RVA: 0x0000E076 File Offset: 0x0000E076
			// (set) Token: 0x060016F4 RID: 5876 RVA: 0x0000E0A0 File Offset: 0x0000E0A0
			public string LastError { get; private set; }

			// Token: 0x17000169 RID: 361
			// (get) Token: 0x060016EF RID: 5871 RVA: 0x0000E07E File Offset: 0x0000E07E
			// (set) Token: 0x060016F0 RID: 5872 RVA: 0x0000E086 File Offset: 0x0000E086
			public string LastDebugHex { get; set; }

			// Token: 0x1700016A RID: 362
			// (get) Token: 0x060016F1 RID: 5873 RVA: 0x0000E08F File Offset: 0x0000E08F
			// (set) Token: 0x060016F2 RID: 5874 RVA: 0x0000E097 File Offset: 0x0000E097
			public int LastResponseLen { get; set; }

			// Token: 0x060016F3 RID: 5875 RVA: 0x000B392C File Offset: 0x000B392C
			public MapEditorForm.LiveFrame DecodeDat10(byte[] r, uint len)
			{
				if (len < 6U)
				{
					return null;
				}
				MapEditorForm.LiveFrame result;
				try
				{
					int num = (int)r[4] << 8 | (int)r[5];
					float tps = 0f;
					float cl = 0f;
					float map = 0f;
					float ad = 0f;
					float num2 = 0f;
					if (len >= 8U)
					{
						tps = (float)r[7] / 2f;
					}
					if (len >= 10U)
					{
						cl = (float)r[9] - 40f;
					}
					if (len >= 14U)
					{
						map = (float)r[13];
					}
					if (len >= 20U)
					{
						num2 = (float)((int)r[18] << 8 | (int)r[19]) / 200f;
					}
					if (len >= 21U)
					{
						ad = (float)r[20] / 2f - 64f;
					}
					result = new MapEditorForm.LiveFrame
					{
						RPM = num,
						TPS = tps,
						CL = cl,
						MAP = map,
						AD = ad,
						InjectorMs = num2,
						IDC = (float)num * num2 / 1200f,
						Valid = true
					};
				}
				catch
				{
					result = null;
				}
				return result;
			}

			// Token: 0x060016F5 RID: 5877 RVA: 0x000B3A2C File Offset: 0x000B3A2C
			private void Fail(string stage)
			{
				try
				{
					FTD2XX_NET.FTDI.FT_Close(this._ftHandle);
				}
				catch
				{
				}
				this._ftHandle = IntPtr.Zero;
				this._isOpen = false;
				this.LastError = "FTDI init fail @ " + stage;
				throw new IOException("Gagal inisialisasi FTDI (" + stage + ")");
			}

			// Token: 0x060016F6 RID: 5878 RVA: 0x000B3A94 File Offset: 0x000B3A94
			private string HexOf(byte[] buf, uint len, int maxBytes)
			{
				checked
				{
					int num = (int)Math.Min(len, (uint)maxBytes);
					StringBuilder stringBuilder = new StringBuilder();
					for (int i = 0; i < num; i++)
					{
						stringBuilder.Append(buf[i].ToString("X2")).Append(' ');
					}
					return stringBuilder.ToString();
				}
			}

			// Token: 0x060016F7 RID: 5879 RVA: 0x000B3AE4 File Offset: 0x000B3AE4
			public LiveDataReader(MapEditorForm owner, string portName, int baud, MapEditorForm.LiveProtocol protocol)
			{
				this._lastMaintainMs = DateTime.MinValue;
				this.LastDebugHex = "";
				base..ctor();
				this._owner = owner;
				this.PortName = portName;
				this._baud = baud;
				this._protocol = protocol;
			}

			// Token: 0x060016F8 RID: 5880 RVA: 0x000B3B40 File Offset: 0x000B3B40
			public bool SendCommand(byte[] command, int commandSize, ref byte[] reply, ref uint replySize, int sleepMs = 0)
			{
				if (!this._isOpen || this._ftHandle == IntPtr.Zero)
				{
					return false;
				}
				byte[] array = new byte[256];
				byte[] array2 = new byte[256];
				uint num = 0U;
				uint num2 = 0U;
				uint num3 = 0U;
				uint num4 = 0U;
				uint num5 = 0U;
				long num6 = (long)(checked(50 + 2 * commandSize));
				checked
				{
					if (FTD2XX_NET.FTDI.FT_Write(this._ftHandle, command, (uint)commandSize, ref num) > 0)
					{
						return false;
					}
					if (FTD2XX_NET.FTDI.FT_SetLatencyTimer(this._ftHandle, 8) > 0)
					{
						return false;
					}
					if (sleepMs > 0)
					{
						Thread.Sleep(sleepMs);
					}
					Stopwatch stopwatch = Stopwatch.StartNew();
					for (;;)
					{
						if (FTD2XX_NET.FTDI.FT_GetQueueStatus(this._ftHandle, ref num2) == null && num2 > 0U && num2 < (uint)array.Length && FTD2XX_NET.FTDI.FT_Read(this._ftHandle, array, num2, ref num3) == null && num3 > 0U)
						{
							unchecked
							{
								Array.Copy(array, 0L, array2, (long)((ulong)num4), (long)((ulong)num3));
							}
							num4 += num3;
							if (num4 >= (uint)(commandSize + 2))
							{
								if (num5 == 0U)
								{
									num5 = (uint)array2[commandSize + 1];
								}
								if (unchecked((ulong)num4) - (ulong)(unchecked((long)commandSize)) == unchecked((ulong)num5))
								{
									replySize = num5;
									unchecked
									{
										Array.Copy(array2, (long)((ulong)(checked(num4 - num5))), reply, 0L, (long)((ulong)num5));
									}
									if (this.ValidateChecksum(reply, (int)num5))
									{
										break;
									}
								}
							}
						}
						if (stopwatch.ElapsedMilliseconds >= num6)
						{
							goto Block_14;
						}
					}
					stopwatch.Stop();
					FTD2XX_NET.FTDI.FT_Purge(this._ftHandle, 3U);
					return true;
					Block_14:
					stopwatch.Stop();
					FTD2XX_NET.FTDI.FT_Purge(this._ftHandle, 3U);
					return false;
				}
			}

			// Token: 0x060016F9 RID: 5881 RVA: 0x000B3C9C File Offset: 0x000B3C9C
			public bool ValidateChecksum(byte[] data, int length)
			{
				if (length < 2)
				{
					return false;
				}
				byte b = 0;
				for (int i = 0; i < length - 1; i++)
				{
					b ^= data[i];
				}
				if (b == data[length - 1])
				{
					return true;
				}
				int num = 0;
				for (int j = 0; j < length - 1; j++)
				{
					num += (int)data[j];
				}
				return (byte)(~num + 1) == data[length - 1] || (byte)(num & 255) == data[length - 1];
			}

			// Token: 0x060016FA RID: 5882 RVA: 0x000B3D04 File Offset: 0x000B3D04
			private byte[] BuildDat10Request1()
			{
				byte[] array = new byte[]
				{
					114,
					5,
					113,
					16,
					8
				};
				int num = 0;
				checked
				{
					foreach (byte b in array)
					{
						num += (int)b;
					}
				}
				byte b2 = (byte)(~num + 1);
				byte[] array3 = new byte[6];
				Array.Copy(array, 0, array3, 0, 5);
				array3[5] = b2;
				return array3;
			}

			// Token: 0x060016FB RID: 5883 RVA: 0x000B3D64 File Offset: 0x000B3D64
			public MapEditorForm.LiveFrame DecodeDat10(byte[] r, uint len, int startIdx = 0)
			{
				if (len < 6U)
				{
					return null;
				}
				checked
				{
					MapEditorForm.LiveFrame result;
					try
					{
						int rpm = 0;
						float tps = 0f;
						for (int i = 0; i < Math.Min((int)len - 1, 10); i++)
						{
							int num = (int)r[i] << 8 | (int)r[i + 1];
							if (num >= 500 && num <= 12000)
							{
								rpm = num;
								break;
							}
						}
						for (int j = 4; j < Math.Min((int)len - 1, 10); j++)
						{
							float num2 = (float)r[j] / 2f;
							if (num2 >= 0f && num2 <= 100f)
							{
								tps = num2;
								break;
							}
						}
						result = new MapEditorForm.LiveFrame
						{
							RPM = rpm,
							TPS = tps,
							Valid = true
						};
					}
					catch
					{
						result = null;
					}
					return result;
				}
			}

			// Token: 0x04001CC3 RID: 7363
			private readonly MapEditorForm.LiveProtocol _protocol;

			// Token: 0x04001CC4 RID: 7364
			private readonly int _baud;

			// Token: 0x04001CC5 RID: 7365
			private IntPtr _ftHandle = IntPtr.Zero;

			// Token: 0x04001CC6 RID: 7366
			private bool _isOpen;

			// Token: 0x04001CC8 RID: 7368
			private bool _handshakeDone;

			// Token: 0x04001CCB RID: 7371
			private DateTime _lastMaintainMs;

			// Token: 0x04001CCC RID: 7372
			private DateTime _lastKeepAliveMs = DateTime.MinValue;

			// Token: 0x04001CCE RID: 7374
			private readonly MapEditorForm _owner;
		}

		// Token: 0x02000854 RID: 2132
		private sealed class LocalLiveProvider : ILiveFrameProvider
		{
			// Token: 0x06001878 RID: 6264 RVA: 0x0000EDC6 File Offset: 0x0000EDC6
			public LocalLiveProvider(MapEditorForm owner)
			{
				this._owner = owner;
			}

			// Token: 0x1700016D RID: 365
			// (get) Token: 0x06001879 RID: 6265 RVA: 0x000C3478 File Offset: 0x000C3478
			public LiveFrameInfo LastFrame
			{
				get
				{
					MapEditorForm.LiveFrame lastLiveFrame = this._owner.lastLiveFrame;
					if (lastLiveFrame == null)
					{
						return null;
					}
					return new LiveFrameInfo
					{
						RPM = lastLiveFrame.RPM,
						TPS = (double)lastLiveFrame.TPS,
						MAP = (double)lastLiveFrame.MAP,
						AFR = (double)lastLiveFrame.AFR
					};
				}
			}

			// Token: 0x1700016E RID: 366
			// (get) Token: 0x0600187A RID: 6266 RVA: 0x0000EDD5 File Offset: 0x0000EDD5
			public int LivePointerRow
			{
				get
				{
					return this._owner.livePointerRow;
				}
			}

			// Token: 0x1700016F RID: 367
			// (get) Token: 0x0600187B RID: 6267 RVA: 0x0000EDE2 File Offset: 0x0000EDE2
			public int LivePointerCol
			{
				get
				{
					return this._owner.livePointerCol;
				}
			}

			// Token: 0x04001E63 RID: 7779
			private readonly MapEditorForm _owner;
		}
	}
}
