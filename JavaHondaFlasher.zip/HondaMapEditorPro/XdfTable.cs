﻿using System;
using System.Collections.Generic;

namespace HondaMapEditorPro
{
	// Token: 0x020007F7 RID: 2039
	public class XdfTable
	{
		// Token: 0x1700011D RID: 285
		// (get) Token: 0x0600147D RID: 5245 RVA: 0x0000D083 File Offset: 0x0000D083
		// (set) Token: 0x0600147E RID: 5246 RVA: 0x0000D08B File Offset: 0x0000D08B
		public string UniqueId { get; set; } = "";

		// Token: 0x1700011E RID: 286
		// (get) Token: 0x0600147F RID: 5247 RVA: 0x0000D094 File Offset: 0x0000D094
		// (set) Token: 0x06001480 RID: 5248 RVA: 0x0000D09C File Offset: 0x0000D09C
		public string Title { get; set; } = "Unnamed Table";

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x06001481 RID: 5249 RVA: 0x0000D0A5 File Offset: 0x0000D0A5
		// (set) Token: 0x06001482 RID: 5250 RVA: 0x0000D0AD File Offset: 0x0000D0AD
		public string Description { get; set; } = "";

		// Token: 0x17000120 RID: 288
		// (get) Token: 0x06001483 RID: 5251 RVA: 0x0000D0B6 File Offset: 0x0000D0B6
		// (set) Token: 0x06001484 RID: 5252 RVA: 0x0000D0BE File Offset: 0x0000D0BE
		public string CategoryName { get; set; } = "";

		// Token: 0x17000121 RID: 289
		// (get) Token: 0x06001485 RID: 5253 RVA: 0x0000D0C7 File Offset: 0x0000D0C7
		// (set) Token: 0x06001486 RID: 5254 RVA: 0x0000D0E2 File Offset: 0x0000D0E2
		public string Category
		{
			get
			{
				if (!string.IsNullOrEmpty(this.CategoryName))
				{
					return this.CategoryName;
				}
				return "";
			}
			set
			{
				this.CategoryName = value;
			}
		}

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x06001487 RID: 5255 RVA: 0x0000D0EB File Offset: 0x0000D0EB
		// (set) Token: 0x06001488 RID: 5256 RVA: 0x0000D0F3 File Offset: 0x0000D0F3
		public int Address { get; set; }

		// Token: 0x17000123 RID: 291
		// (get) Token: 0x06001489 RID: 5257 RVA: 0x0000D0FC File Offset: 0x0000D0FC
		// (set) Token: 0x0600148A RID: 5258 RVA: 0x0000D104 File Offset: 0x0000D104
		public int ElementSize { get; set; } = 2;

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x0600148B RID: 5259 RVA: 0x0000D10D File Offset: 0x0000D10D
		// (set) Token: 0x0600148C RID: 5260 RVA: 0x0000D115 File Offset: 0x0000D115
		public int Rows { get; set; } = 1;

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x0600148D RID: 5261 RVA: 0x0000D11E File Offset: 0x0000D11E
		// (set) Token: 0x0600148E RID: 5262 RVA: 0x0000D126 File Offset: 0x0000D126
		public int Cols { get; set; } = 1;

		// Token: 0x17000126 RID: 294
		// (get) Token: 0x0600148F RID: 5263 RVA: 0x0000D12F File Offset: 0x0000D12F
		// (set) Token: 0x06001490 RID: 5264 RVA: 0x0000D137 File Offset: 0x0000D137
		public bool IsSigned { get; set; }

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x06001491 RID: 5265 RVA: 0x0000D140 File Offset: 0x0000D140
		// (set) Token: 0x06001492 RID: 5266 RVA: 0x0000D148 File Offset: 0x0000D148
		public bool IsSwapped { get; set; }

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x06001493 RID: 5267 RVA: 0x0000D151 File Offset: 0x0000D151
		// (set) Token: 0x06001494 RID: 5268 RVA: 0x0000D159 File Offset: 0x0000D159
		public bool IsFloat { get; set; }

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x06001495 RID: 5269 RVA: 0x0000D162 File Offset: 0x0000D162
		// (set) Token: 0x06001496 RID: 5270 RVA: 0x0000D16A File Offset: 0x0000D16A
		public string MathEquation { get; set; } = "X";

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x06001497 RID: 5271 RVA: 0x0000D173 File Offset: 0x0000D173
		// (set) Token: 0x06001498 RID: 5272 RVA: 0x0000D17B File Offset: 0x0000D17B
		public double Scale { get; set; } = 1.0;

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x06001499 RID: 5273 RVA: 0x0000D184 File Offset: 0x0000D184
		// (set) Token: 0x0600149A RID: 5274 RVA: 0x0000D18C File Offset: 0x0000D18C
		public double Offset { get; set; }

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x0600149B RID: 5275 RVA: 0x0000D195 File Offset: 0x0000D195
		// (set) Token: 0x0600149C RID: 5276 RVA: 0x0000D19D File Offset: 0x0000D19D
		public int XAxisAddress { get; set; }

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x0600149D RID: 5277 RVA: 0x0000D1A6 File Offset: 0x0000D1A6
		// (set) Token: 0x0600149E RID: 5278 RVA: 0x0000D1AE File Offset: 0x0000D1AE
		public int XAxisElementSize { get; set; } = 2;

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x0600149F RID: 5279 RVA: 0x0000D1B7 File Offset: 0x0000D1B7
		// (set) Token: 0x060014A0 RID: 5280 RVA: 0x0000D1BF File Offset: 0x0000D1BF
		public double XAxisScale { get; set; } = 1.0;

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x060014A1 RID: 5281 RVA: 0x0000D1C8 File Offset: 0x0000D1C8
		// (set) Token: 0x060014A2 RID: 5282 RVA: 0x0000D1D0 File Offset: 0x0000D1D0
		public double XAxisOffset { get; set; }

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x060014A3 RID: 5283 RVA: 0x0000D1D9 File Offset: 0x0000D1D9
		// (set) Token: 0x060014A4 RID: 5284 RVA: 0x0000D1E1 File Offset: 0x0000D1E1
		public int XAxisCount { get; set; }

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x060014A5 RID: 5285 RVA: 0x0000D1EA File Offset: 0x0000D1EA
		// (set) Token: 0x060014A6 RID: 5286 RVA: 0x0000D1F2 File Offset: 0x0000D1F2
		public string XAxisLinkId { get; set; } = "";

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x060014A7 RID: 5287 RVA: 0x0000D1FB File Offset: 0x0000D1FB
		// (set) Token: 0x060014A8 RID: 5288 RVA: 0x0000D203 File Offset: 0x0000D203
		public string XAxisLabel { get; set; } = "";

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x060014A9 RID: 5289 RVA: 0x0000D20C File Offset: 0x0000D20C
		// (set) Token: 0x060014AA RID: 5290 RVA: 0x0000D214 File Offset: 0x0000D214
		public List<double> XAxisValues { get; set; } = new List<double>();

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x060014AB RID: 5291 RVA: 0x0000D21D File Offset: 0x0000D21D
		// (set) Token: 0x060014AC RID: 5292 RVA: 0x0000D225 File Offset: 0x0000D225
		public int YAxisAddress { get; set; }

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x060014AD RID: 5293 RVA: 0x0000D22E File Offset: 0x0000D22E
		// (set) Token: 0x060014AE RID: 5294 RVA: 0x0000D236 File Offset: 0x0000D236
		public int YAxisElementSize { get; set; } = 2;

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x060014AF RID: 5295 RVA: 0x0000D23F File Offset: 0x0000D23F
		// (set) Token: 0x060014B0 RID: 5296 RVA: 0x0000D247 File Offset: 0x0000D247
		public double YAxisScale { get; set; } = 1.0;

		// Token: 0x17000137 RID: 311
		// (get) Token: 0x060014B1 RID: 5297 RVA: 0x0000D250 File Offset: 0x0000D250
		// (set) Token: 0x060014B2 RID: 5298 RVA: 0x0000D258 File Offset: 0x0000D258
		public double YAxisOffset { get; set; }

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x060014B3 RID: 5299 RVA: 0x0000D261 File Offset: 0x0000D261
		// (set) Token: 0x060014B4 RID: 5300 RVA: 0x0000D269 File Offset: 0x0000D269
		public int YAxisCount { get; set; }

		// Token: 0x17000139 RID: 313
		// (get) Token: 0x060014B5 RID: 5301 RVA: 0x0000D272 File Offset: 0x0000D272
		// (set) Token: 0x060014B6 RID: 5302 RVA: 0x0000D27A File Offset: 0x0000D27A
		public string YAxisLinkId { get; set; } = "";

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x060014B7 RID: 5303 RVA: 0x0000D283 File Offset: 0x0000D283
		// (set) Token: 0x060014B8 RID: 5304 RVA: 0x0000D28B File Offset: 0x0000D28B
		public string YAxisLabel { get; set; } = "";

		// Token: 0x1700013B RID: 315
		// (get) Token: 0x060014B9 RID: 5305 RVA: 0x0000D294 File Offset: 0x0000D294
		// (set) Token: 0x060014BA RID: 5306 RVA: 0x0000D29C File Offset: 0x0000D29C
		public List<double> YAxisValues { get; set; } = new List<double>();

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x060014BB RID: 5307 RVA: 0x0000D2A5 File Offset: 0x0000D2A5
		public bool IsValid
		{
			get
			{
				return this.Address > 0 && (this.Rows > 0 || this.Cols > 0);
			}
		}

		// Token: 0x060014BC RID: 5308 RVA: 0x0009BA34 File Offset: 0x0009BA34
		public override string ToString()
		{
			return string.Format("{0} @ 0x{1:X} ({2}x{3})", new object[]
			{
				this.Title,
				this.Address,
				this.Rows,
				this.Cols
			});
		}

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x060014BE RID: 5310 RVA: 0x0000D2C6 File Offset: 0x0000D2C6
		// (set) Token: 0x060014BF RID: 5311 RVA: 0x0000D2CE File Offset: 0x0000D2CE
		public bool PreferRpmOnTop { get; set; }
	}
}
