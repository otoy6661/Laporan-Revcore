﻿using System;

namespace HondaMapEditorPro
{
	// Token: 0x020007F8 RID: 2040
	public class XdfProfile
	{
		// Token: 0x1700013E RID: 318
		// (get) Token: 0x060014C0 RID: 5312 RVA: 0x0000D2D7 File Offset: 0x0000D2D7
		// (set) Token: 0x060014C1 RID: 5313 RVA: 0x0000D2DF File Offset: 0x0000D2DF
		public XdfTable Table { get; set; }

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x060014C2 RID: 5314 RVA: 0x0000D2E8 File Offset: 0x0000D2E8
		// (set) Token: 0x060014C3 RID: 5315 RVA: 0x0000D2F0 File Offset: 0x0000D2F0
		public string XdfFilePath { get; set; } = "";

		// Token: 0x17000140 RID: 320
		// (get) Token: 0x060014C4 RID: 5316 RVA: 0x0000D2F9 File Offset: 0x0000D2F9
		// (set) Token: 0x060014C5 RID: 5317 RVA: 0x0000D316 File Offset: 0x0000D316
		public string Name
		{
			get
			{
				XdfTable table = this.Table;
				return ((table != null) ? table.Title : null) ?? "";
			}
			set
			{
				if (this.Table != null)
				{
					this.Table.Title = value;
				}
			}
		}

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x060014C6 RID: 5318 RVA: 0x0000D32C File Offset: 0x0000D32C
		// (set) Token: 0x060014C7 RID: 5319 RVA: 0x0000D349 File Offset: 0x0000D349
		public string Category
		{
			get
			{
				XdfTable table = this.Table;
				return ((table != null) ? table.Category : null) ?? "";
			}
			set
			{
				if (this.Table != null)
				{
					this.Table.Category = value;
				}
			}
		}

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x060014C8 RID: 5320 RVA: 0x0000D35F File Offset: 0x0000D35F
		// (set) Token: 0x060014C9 RID: 5321 RVA: 0x0000D372 File Offset: 0x0000D372
		public int Address
		{
			get
			{
				XdfTable table = this.Table;
				if (table == null)
				{
					return 0;
				}
				return table.Address;
			}
			set
			{
				if (this.Table != null)
				{
					this.Table.Address = value;
				}
			}
		}

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x060014CA RID: 5322 RVA: 0x0000D388 File Offset: 0x0000D388
		// (set) Token: 0x060014CB RID: 5323 RVA: 0x0000D39B File Offset: 0x0000D39B
		public int Rows
		{
			get
			{
				XdfTable table = this.Table;
				if (table == null)
				{
					return 0;
				}
				return table.Rows;
			}
			set
			{
				if (this.Table != null)
				{
					this.Table.Rows = value;
				}
			}
		}

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x060014CC RID: 5324 RVA: 0x0000D3B1 File Offset: 0x0000D3B1
		// (set) Token: 0x060014CD RID: 5325 RVA: 0x0000D3C4 File Offset: 0x0000D3C4
		public int Cols
		{
			get
			{
				XdfTable table = this.Table;
				if (table == null)
				{
					return 0;
				}
				return table.Cols;
			}
			set
			{
				if (this.Table != null)
				{
					this.Table.Cols = value;
				}
			}
		}

		// Token: 0x17000145 RID: 325
		// (get) Token: 0x060014CE RID: 5326 RVA: 0x0000D3DA File Offset: 0x0000D3DA
		// (set) Token: 0x060014CF RID: 5327 RVA: 0x0000D3ED File Offset: 0x0000D3ED
		public int ElementSize
		{
			get
			{
				XdfTable table = this.Table;
				if (table == null)
				{
					return 2;
				}
				return table.ElementSize;
			}
			set
			{
				if (this.Table != null)
				{
					this.Table.ElementSize = value;
				}
			}
		}

		// Token: 0x060014D0 RID: 5328 RVA: 0x0000D403 File Offset: 0x0000D403
		public override string ToString()
		{
			if (this.Table == null)
			{
				return "(empty)";
			}
			return this.Table.Title;
		}
	}
}
