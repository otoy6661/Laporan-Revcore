﻿using System;
using System.Collections.Generic;

namespace HondaMapEditorPro
{
	// Token: 0x020007F6 RID: 2038
	public class XdfDefinition
	{
		// Token: 0x17000111 RID: 273
		// (get) Token: 0x06001463 RID: 5219 RVA: 0x0000CF95 File Offset: 0x0000CF95
		// (set) Token: 0x06001464 RID: 5220 RVA: 0x0000CF9D File Offset: 0x0000CF9D
		public string FilePath { get; set; } = "";

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x06001465 RID: 5221 RVA: 0x0000CFA6 File Offset: 0x0000CFA6
		// (set) Token: 0x06001466 RID: 5222 RVA: 0x0000CFAE File Offset: 0x0000CFAE
		public string Version { get; set; } = "1.0";

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x06001467 RID: 5223 RVA: 0x0000CFB7 File Offset: 0x0000CFB7
		// (set) Token: 0x06001468 RID: 5224 RVA: 0x0000CFBF File Offset: 0x0000CFBF
		public string Title { get; set; } = "Untitled XDF";

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x06001469 RID: 5225 RVA: 0x0000CFC8 File Offset: 0x0000CFC8
		// (set) Token: 0x0600146A RID: 5226 RVA: 0x0000CFD0 File Offset: 0x0000CFD0
		public string Author { get; set; } = "Unknown";

		// Token: 0x17000115 RID: 277
		// (get) Token: 0x0600146B RID: 5227 RVA: 0x0000CFD9 File Offset: 0x0000CFD9
		// (set) Token: 0x0600146C RID: 5228 RVA: 0x0000CFE1 File Offset: 0x0000CFE1
		public string Description { get; set; } = "";

		// Token: 0x17000116 RID: 278
		// (get) Token: 0x0600146D RID: 5229 RVA: 0x0000CFEA File Offset: 0x0000CFEA
		// (set) Token: 0x0600146E RID: 5230 RVA: 0x0000CFF2 File Offset: 0x0000CFF2
		public int BinSize { get; set; }

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x0600146F RID: 5231 RVA: 0x0000CFFB File Offset: 0x0000CFFB
		// (set) Token: 0x06001470 RID: 5232 RVA: 0x0000D003 File Offset: 0x0000D003
		public int DefaultDataSizeBits { get; set; } = 16;

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x06001471 RID: 5233 RVA: 0x0000D00C File Offset: 0x0000D00C
		// (set) Token: 0x06001472 RID: 5234 RVA: 0x0000D014 File Offset: 0x0000D014
		public bool DefaultSigned { get; set; }

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x06001473 RID: 5235 RVA: 0x0000D01D File Offset: 0x0000D01D
		// (set) Token: 0x06001474 RID: 5236 RVA: 0x0000D025 File Offset: 0x0000D025
		public bool DefaultLsbFirst { get; set; } = true;

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x06001475 RID: 5237 RVA: 0x0000D02E File Offset: 0x0000D02E
		// (set) Token: 0x06001476 RID: 5238 RVA: 0x0000D036 File Offset: 0x0000D036
		public Dictionary<string, string> Categories { get; set; } = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x1700011B RID: 283
		// (get) Token: 0x06001477 RID: 5239 RVA: 0x0000D03F File Offset: 0x0000D03F
		// (set) Token: 0x06001478 RID: 5240 RVA: 0x0000D047 File Offset: 0x0000D047
		public List<XdfTable> Tables { get; set; } = new List<XdfTable>();

		// Token: 0x1700011C RID: 284
		// (get) Token: 0x06001479 RID: 5241 RVA: 0x0000D050 File Offset: 0x0000D050
		// (set) Token: 0x0600147A RID: 5242 RVA: 0x0000D058 File Offset: 0x0000D058
		public List<XdfConstant> Constants { get; set; } = new List<XdfConstant>();

		// Token: 0x0600147B RID: 5243 RVA: 0x0000D061 File Offset: 0x0000D061
		public override string ToString()
		{
			return string.Format("{0} ({1} tables)", this.Title, this.Tables.Count);
		}
	}
}
