﻿namespace HondaMapEditorPro
{
	// Token: 0x020007FE RID: 2046
	public partial class MapEditorForm : global::System.Windows.Forms.Form
	{
		// Token: 0x06001522 RID: 5410 RVA: 0x0009EF04 File Offset: 0x0009EF04
		private void InitializeComponent()
		{
			base.SuspendLayout();
			this.Text = "DEPPLOY MAP TUNING - MAP EDITOR PRO (XDF)";
			base.ClientSize = new global::System.Drawing.Size(1340, 700);
			this.MinimumSize = new global::System.Drawing.Size(1024, 600);
			this.MaximumSize = new global::System.Drawing.Size(0, 0);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.BackColor = this.bgDark;
			this.ForeColor = this.fg;
			this.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			base.Padding = new global::System.Windows.Forms.Padding(6);
			this.DoubleBuffered = true;
			base.KeyPreview = true;
			base.MaximizeBox = false;
			base.MinimizeBox = true;
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Dpi;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(96f, 96f);
			base.SetStyle(global::System.Windows.Forms.ControlStyles.UserPaint | global::System.Windows.Forms.ControlStyles.ResizeRedraw | global::System.Windows.Forms.ControlStyles.AllPaintingInWmPaint | global::System.Windows.Forms.ControlStyles.OptimizedDoubleBuffer, true);
			this.BuildTopBar();
			this.BuildMenuStrip();
			this.BuildToolbar();
			this.splitContainerMain = new global::System.Windows.Forms.SplitContainer
			{
				Dock = global::System.Windows.Forms.DockStyle.Fill,
				SplitterWidth = 6,
				BackColor = this.bgDark,
				BorderStyle = global::System.Windows.Forms.BorderStyle.None
			};
			this.splitContainerMain.Panel1.BackColor = this.bgDark;
			this.splitContainerMain.Panel2.BackColor = this.bgDark;
			this.splitRight = new global::System.Windows.Forms.SplitContainer
			{
				Dock = global::System.Windows.Forms.DockStyle.Fill,
				Orientation = global::System.Windows.Forms.Orientation.Vertical,
				SplitterWidth = 6,
				BackColor = this.bgDark,
				BorderStyle = global::System.Windows.Forms.BorderStyle.None
			};
			this.splitRight.Panel1.BackColor = this.bgDark;
			this.splitRight.Panel2.BackColor = this.bgDark;
			this.splitContainerMain.Panel2.Controls.Add(this.splitRight);
			this.BuildLeftPanel();
			this.BuildCenterPanel();
			this.BuildRightPanel();
			this.BuildStatusBar();
			this.mainContent = new global::System.Windows.Forms.Panel
			{
				Dock = global::System.Windows.Forms.DockStyle.Fill,
				BackColor = this.bgDark,
				Padding = new global::System.Windows.Forms.Padding(8, 6, 8, 6)
			};
			this.mainContent.Controls.Add(this.splitContainerMain);
			base.Controls.Add(this.mainContent);
			base.Controls.Add(this.statusBar);
			base.Controls.Add(this.toolbarPanel);
			base.Controls.Add(this.mainMenu);
			base.Controls.Add(this.titleBar);
			base.Shown += new global::System.EventHandler(this.MapEditorForm_Shown);
			base.Resize += new global::System.EventHandler(this.MapEditorForm_Resize);
			base.DpiChangedAfterParent += new global::System.EventHandler(this.MapEditorForm_DpiChanged);
			base.ResumeLayout(true);
		}

		// Token: 0x04001B8B RID: 7051
		private global::System.Windows.Forms.Panel titleBar;

		// Token: 0x04001B97 RID: 7063
		private global::System.Windows.Forms.MenuStrip mainMenu;

		// Token: 0x04001B98 RID: 7064
		private global::System.Windows.Forms.Panel toolbarPanel;

		// Token: 0x04001BAD RID: 7085
		private readonly global::System.Drawing.Color bgDark;

		// Token: 0x04001BB4 RID: 7092
		private readonly global::System.Drawing.Color fg;

		// Token: 0x04001BC3 RID: 7107
		private global::System.Windows.Forms.SplitContainer splitRight;

		// Token: 0x04001BCC RID: 7116
		private global::System.Windows.Forms.Panel mainContent;

		// Token: 0x04001BCE RID: 7118
		private global::System.Windows.Forms.SplitContainer splitContainerMain;

		// Token: 0x04001BD0 RID: 7120
		private global::System.Windows.Forms.Panel statusBar;
	}
}
