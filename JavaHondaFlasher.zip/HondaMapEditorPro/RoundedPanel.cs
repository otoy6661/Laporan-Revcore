﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace HondaMapEditorPro
{
	// Token: 0x0200087C RID: 2172
	public class RoundedPanel : Panel
	{
		// Token: 0x17000170 RID: 368
		// (get) Token: 0x0600189A RID: 6298 RVA: 0x0000EFA7 File Offset: 0x0000EFA7
		// (set) Token: 0x0600189B RID: 6299 RVA: 0x0000EFAF File Offset: 0x0000EFAF
		public int CornerRadius { get; set; }

		// Token: 0x17000171 RID: 369
		// (get) Token: 0x0600189C RID: 6300 RVA: 0x0000EFB8 File Offset: 0x0000EFB8
		// (set) Token: 0x0600189D RID: 6301 RVA: 0x0000EFC0 File Offset: 0x0000EFC0
		public Color BorderColor { get; set; }

		// Token: 0x17000172 RID: 370
		// (get) Token: 0x0600189E RID: 6302 RVA: 0x0000EFC9 File Offset: 0x0000EFC9
		// (set) Token: 0x0600189F RID: 6303 RVA: 0x0000EFD1 File Offset: 0x0000EFD1
		public float BorderWidth { get; set; }

		// Token: 0x17000173 RID: 371
		// (get) Token: 0x060018A0 RID: 6304 RVA: 0x0000EFDA File Offset: 0x0000EFDA
		// (set) Token: 0x060018A1 RID: 6305 RVA: 0x0000EFE2 File Offset: 0x0000EFE2
		public Color InnerBackColor { get; set; }

		// Token: 0x060018A2 RID: 6306 RVA: 0x0000EFEB File Offset: 0x0000EFEB
		public RoundedPanel()
		{
			this.DoubleBuffered = true;
			this.BackColor = Color.Transparent;
		}

		// Token: 0x060018A3 RID: 6307 RVA: 0x000C355C File Offset: 0x000C355C
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(checked(new Rectangle(0, 0, base.Width - 1, base.Height - 1)), (float)this.CornerRadius))
			{
				using (SolidBrush solidBrush = new SolidBrush(this.InnerBackColor))
				{
					e.Graphics.FillPath(solidBrush, graphicsPath);
				}
				using (Pen pen = new Pen(this.BorderColor, this.BorderWidth))
				{
					e.Graphics.DrawPath(pen, graphicsPath);
				}
			}
		}
	}
}
