﻿using System;

namespace HondaMapEditorPro
{
	// Token: 0x020009CD RID: 2509
	public interface ILiveFrameProvider
	{
		// Token: 0x170001D4 RID: 468
		// (get) Token: 0x06001B01 RID: 6913
		LiveFrameInfo LastFrame { get; }

		// Token: 0x170001D5 RID: 469
		// (get) Token: 0x06001B02 RID: 6914
		int LivePointerRow { get; }

		// Token: 0x170001D6 RID: 470
		// (get) Token: 0x06001B03 RID: 6915
		int LivePointerCol { get; }
	}
}
