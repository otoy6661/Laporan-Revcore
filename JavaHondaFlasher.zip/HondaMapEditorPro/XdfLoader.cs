﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace HondaMapEditorPro
{
	// Token: 0x020007FD RID: 2045
	public static class XdfLoader
	{
		// Token: 0x06001503 RID: 5379 RVA: 0x0009C0A0 File Offset: 0x0009C0A0
		public static XdfDefinition Parse(string xdfPath)
		{
			if (string.IsNullOrWhiteSpace(xdfPath))
			{
				throw new ArgumentException("Path XDF kosong", "xdfPath");
			}
			if (!File.Exists(xdfPath))
			{
				throw new FileNotFoundException("XDF tidak ditemukan", xdfPath);
			}
			byte[] array = File.ReadAllBytes(xdfPath);
			if (array.Length == 0)
			{
				throw new Exception("File XDF kosong");
			}
			string text;
			if (XdfDecryptor.IsEncrypted(array))
			{
				XdfDecryptor.DecryptResult decryptResult = XdfDecryptor.Decrypt(xdfPath);
				if (!decryptResult.Success)
				{
					throw new Exception(string.Concat(new string[]
					{
						"File XDF terpassword dan gagal di-decrypt!\n\nError: ",
						decryptResult.ErrorMessage,
						"\n\nFile: ",
						Path.GetFileName(xdfPath),
						"\nUkuran: ",
						array.Length.ToString("N0", CultureInfo.InvariantCulture),
						" bytes"
					}));
				}
				text = decryptResult.UnlockedXml;
			}
			else
			{
				text = XdfLoader.ExtractXmlFromBinary(array);
			}
			if (string.IsNullOrWhiteSpace(text))
			{
				string hexPreview = XdfLoader.GetHexPreview(array, 64);
				string asciiPreview = XdfLoader.GetAsciiPreview(array, 64);
				throw new Exception(string.Concat(new string[]
				{
					"Tidak dapat menemukan struktur XML valid.\n\nUkuran file: ",
					array.Length.ToString("N0", CultureInfo.InvariantCulture),
					" bytes\nHeader (hex):\n",
					hexPreview,
					"\n\nHeader (ASCII):\n",
					asciiPreview
				}));
			}
			string text2 = XdfLoader.CleanupXml(text);
			XmlDocument xmlDocument = new XmlDocument
			{
				PreserveWhitespace = false,
				XmlResolver = null
			};
			try
			{
				xmlDocument.LoadXml(text2);
			}
			catch (XmlException ex)
			{
				string xml = XdfLoader.AggressiveRepair(text2);
				try
				{
					xmlDocument.LoadXml(xml);
				}
				catch (XmlException ex2)
				{
					string text3 = XdfLoader.FixHeaderMismatchOnly(xml);
					try
					{
						File.WriteAllText(Path.Combine(Path.GetDirectoryName(xdfPath) ?? ".", Path.GetFileNameWithoutExtension(xdfPath) + "_repaired.xml"), text3, Encoding.UTF8);
					}
					catch
					{
					}
					try
					{
						xmlDocument.LoadXml(text3);
					}
					catch (XmlException ex3)
					{
						throw new Exception(string.Concat(new string[]
						{
							"Format XML rusak dan tidak dapat diperbaiki.\n\nError asli : ",
							ex.Message,
							"\nSetelah repair-1 : ",
							ex2.Message,
							"\nSetelah repair-2 : ",
							ex3.Message,
							"\n\nFile repair disimpan di:\n",
							Path.GetFileNameWithoutExtension(xdfPath),
							"_repaired.xml"
						}));
					}
				}
			}
			return XdfLoader.ParseDocument(xmlDocument, xdfPath);
		}

		// Token: 0x06001504 RID: 5380 RVA: 0x0009C30C File Offset: 0x0009C30C
		public static List<XdfProfile> ToProfiles(XdfDefinition xdf, string xdfPath)
		{
			List<XdfProfile> list = new List<XdfProfile>();
			if (xdf == null)
			{
				return list;
			}
			foreach (XdfTable table in xdf.Tables)
			{
				list.Add(new XdfProfile
				{
					Table = table,
					XdfFilePath = xdfPath
				});
			}
			return list;
		}

		// Token: 0x06001505 RID: 5381 RVA: 0x0009C380 File Offset: 0x0009C380
		private static XdfDefinition ParseDocument(XmlDocument doc, string xdfPath)
		{
			XdfDefinition xdfDefinition = new XdfDefinition
			{
				FilePath = xdfPath,
				Title = Path.GetFileNameWithoutExtension(xdfPath)
			};
			XmlElement documentElement = doc.DocumentElement;
			if (documentElement == null)
			{
				throw new Exception("Root XML kosong");
			}
			xdfDefinition.Version = (XdfLoader.Attr(documentElement, "version") ?? "1.0");
			XmlNode xmlNode = doc.SelectSingleNode("//XDFHEADER") ?? doc.SelectSingleNode("//Header");
			if (xmlNode != null)
			{
				XdfDefinition xdfDefinition2 = xdfDefinition;
				string title;
				if ((title = XdfLoader.GetChildText(xmlNode, "deftitle")) == null && (title = XdfLoader.GetChildText(xmlNode, "title")) == null)
				{
					title = (XdfLoader.GetChildText(xmlNode, "name") ?? xdfDefinition.Title);
				}
				xdfDefinition2.Title = title;
				XdfDefinition xdfDefinition3 = xdfDefinition;
				string author;
				if ((author = XdfLoader.GetChildText(xmlNode, "author")) == null)
				{
					author = (XdfLoader.GetChildText(xmlNode, "creator") ?? "Unknown");
				}
				xdfDefinition3.Author = author;
				XdfDefinition xdfDefinition4 = xdfDefinition;
				string description;
				if ((description = XdfLoader.GetChildText(xmlNode, "description")) == null)
				{
					description = (XdfLoader.GetChildText(xmlNode, "desc") ?? "");
				}
				xdfDefinition4.Description = description;
				XmlNode xmlNode2 = xmlNode.SelectSingleNode("REGION") ?? xmlNode.SelectSingleNode("region");
				if (xmlNode2 != null)
				{
					xdfDefinition.BinSize = (XdfLoader.ParseAddress(XdfLoader.Attr(xmlNode2, "size")) | XdfLoader.ParseAddress(XdfLoader.Attr(xmlNode2, "Size")));
					if (xdfDefinition.BinSize == 0)
					{
						xdfDefinition.BinSize = XdfLoader.ParseAddress(XdfLoader.Attr(xmlNode, "size"));
					}
				}
				XmlNode xmlNode3 = xmlNode.SelectSingleNode("DEFAULTS") ?? xmlNode.SelectSingleNode("defaults");
				if (xmlNode3 != null)
				{
					int defaultDataSizeBits;
					if (int.TryParse(XdfLoader.Attr(xmlNode3, "datasizeinbits"), out defaultDataSizeBits) || int.TryParse(XdfLoader.Attr(xmlNode3, "datasizebits"), out defaultDataSizeBits))
					{
						xdfDefinition.DefaultDataSizeBits = defaultDataSizeBits;
					}
					xdfDefinition.DefaultSigned = XdfLoader.ParseBool(XdfLoader.Attr(xmlNode3, "signed"));
					string text = XdfLoader.Attr(xmlNode3, "lsbfirst");
					if (!string.IsNullOrEmpty(text))
					{
						xdfDefinition.DefaultLsbFirst = XdfLoader.ParseBool(text);
					}
					else
					{
						string text2 = XdfLoader.Attr(xmlNode3, "msbfirst");
						xdfDefinition.DefaultLsbFirst = (!string.IsNullOrEmpty(text2) && !XdfLoader.ParseBool(text2));
					}
				}
				foreach (object obj in xmlNode.SelectNodes(".//CATEGORY"))
				{
					XmlNode n = (XmlNode)obj;
					string text3 = XdfLoader.Attr(n, "index") ?? "0";
					string value = XdfLoader.Attr(n, "name") ?? "Uncategorized";
					if (text3.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
					{
						text3 = XdfLoader.ParseHexSafe(text3).ToString(CultureInfo.InvariantCulture);
					}
					if (!xdfDefinition.Categories.ContainsKey(text3))
					{
						xdfDefinition.Categories[text3] = value;
					}
				}
			}
			XmlNodeList xmlNodeList = doc.SelectNodes("//XDFTABLE") ?? doc.SelectNodes("//TABLE");
			if (xmlNodeList != null)
			{
				foreach (object obj2 in xmlNodeList)
				{
					XmlNode tn = (XmlNode)obj2;
					try
					{
						XdfTable xdfTable = XdfLoader.ParseTable(tn, xdfDefinition);
						if (xdfTable != null && xdfTable.IsValid)
						{
							if (string.IsNullOrEmpty(xdfTable.CategoryName))
							{
								xdfTable.CategoryName = XdfLoader.ClassifyTable(xdfTable.Title);
							}
							xdfDefinition.Tables.Add(xdfTable);
						}
					}
					catch
					{
					}
				}
			}
			XmlNodeList xmlNodeList2 = doc.SelectNodes("//XDFCONSTANT") ?? doc.SelectNodes("//CONSTANT");
			if (xmlNodeList2 != null)
			{
				foreach (object obj3 in xmlNodeList2)
				{
					XmlNode cn = (XmlNode)obj3;
					try
					{
						XdfConstant xdfConstant = XdfLoader.ParseConstant(cn, xdfDefinition);
						if (xdfConstant != null && xdfConstant.Address > 0)
						{
							xdfDefinition.Constants.Add(xdfConstant);
						}
					}
					catch
					{
					}
				}
			}
			XdfLoader.ResolveAxisLinks(xdfDefinition);
			return xdfDefinition;
		}

		// Token: 0x06001506 RID: 5382 RVA: 0x0009C7D4 File Offset: 0x0009C7D4
		private static XdfConstant ParseConstant(XmlNode cn, XdfDefinition def)
		{
			XdfConstant xdfConstant = new XdfConstant();
			string uniqueId;
			if ((uniqueId = XdfLoader.Attr(cn, "uniqueid")) == null)
			{
				uniqueId = (XdfLoader.Attr(cn, "id") ?? "");
			}
			xdfConstant.UniqueId = uniqueId;
			string title;
			if ((title = XdfLoader.GetChildText(cn, "title")) == null)
			{
				title = (XdfLoader.GetChildText(cn, "name") ?? "Unnamed Constant");
			}
			xdfConstant.Title = title;
			XdfConstant xdfConstant2 = xdfConstant;
			XmlNode xmlNode = cn.SelectSingleNode("EMBEDDEDDATA") ?? cn.SelectSingleNode("DATA");
			if (xmlNode == null)
			{
				return null;
			}
			XdfConstant xdfConstant3 = xdfConstant2;
			string s;
			if ((s = XdfLoader.Attr(xmlNode, "mmedaddress")) == null)
			{
				s = (XdfLoader.Attr(xmlNode, "address") ?? XdfLoader.Attr(xmlNode, "offset"));
			}
			xdfConstant3.Address = XdfLoader.ParseAddress(s);
			XdfConstant xdfConstant4 = xdfConstant2;
			string s2;
			if ((s2 = XdfLoader.Attr(xmlNode, "mmedelementsizebits")) == null)
			{
				s2 = (XdfLoader.Attr(xmlNode, "datasizebits") ?? XdfLoader.Attr(xmlNode, "elementsizebits"));
			}
			xdfConstant4.ElementSize = XdfLoader.ParseElementSizeBits(s2);
			xdfConstant2.IsSigned = def.DefaultSigned;
			xdfConstant2.IsSwapped = def.DefaultLsbFirst;
			xdfConstant2.IsFloat = false;
			if (xmlNode != null)
			{
				string text = XdfLoader.Attr(xmlNode, "signed");
				if (!string.IsNullOrEmpty(text))
				{
					xdfConstant2.IsSigned = XdfLoader.ParseBool(text);
				}
				string text2 = XdfLoader.Attr(xmlNode, "lsbfirst");
				if (!string.IsNullOrEmpty(text2))
				{
					xdfConstant2.IsSwapped = XdfLoader.ParseBool(text2);
				}
				string text3 = XdfLoader.Attr(xmlNode, "float");
				if (!string.IsNullOrEmpty(text3))
				{
					xdfConstant2.IsFloat = XdfLoader.ParseBool(text3);
				}
			}
			string text4 = XdfLoader.Attr(xmlNode, "mmedtypeflags") ?? XdfLoader.Attr(xmlNode, "typeflags");
			if (!string.IsNullOrEmpty(text4))
			{
				int num = XdfLoader.ParseAddress(text4);
				if ((num & 1) != 0)
				{
					xdfConstant2.IsSigned = true;
				}
				if ((num & 4) != 0)
				{
					xdfConstant2.IsFloat = true;
				}
			}
			if (xdfConstant2.IsFloat && xdfConstant2.ElementSize != 4)
			{
				xdfConstant2.IsFloat = false;
			}
			XmlNode xmlNode2 = cn.SelectSingleNode("MATH");
			if (xmlNode2 != null)
			{
				xdfConstant2.MathEquation = (XdfLoader.Attr(xmlNode2, "equation") ?? "X");
				double scale;
				double offset;
				XdfLoader.ParseMathEquation(xdfConstant2.MathEquation, out scale, out offset);
				xdfConstant2.Scale = scale;
				xdfConstant2.Offset = offset;
			}
			return xdfConstant2;
		}

		// Token: 0x06001507 RID: 5383 RVA: 0x0009CA04 File Offset: 0x0009CA04
		private static XdfTable ParseTable(XmlNode tn, XdfDefinition def)
		{
			XdfTable xdfTable = new XdfTable();
			XdfTable xdfTable2 = xdfTable;
			string uniqueId;
			if ((uniqueId = XdfLoader.Attr(tn, "uniqueid")) == null)
			{
				uniqueId = (XdfLoader.Attr(tn, "id") ?? "");
			}
			xdfTable2.UniqueId = uniqueId;
			XdfTable xdfTable3 = xdfTable;
			string title;
			if ((title = XdfLoader.GetChildText(tn, "title")) == null && (title = XdfLoader.GetChildText(tn, "TITLE")) == null && (title = XdfLoader.GetChildText(tn, "name")) == null)
			{
				title = (XdfLoader.Attr(tn, "name") ?? "Unnamed Table");
			}
			xdfTable3.Title = title;
			xdfTable.Description = (XdfLoader.GetChildText(tn, "description") ?? "");
			XmlNode xmlNode;
			if ((xmlNode = tn.SelectSingleNode("XDFAXIS[@id='z']")) == null)
			{
				xmlNode = (tn.SelectSingleNode("XDFAXIS[@id='Z']") ?? tn.SelectSingleNode("AXIS[@id='z']"));
			}
			XmlNode xmlNode2 = xmlNode;
			XmlNode xmlNode3 = null;
			if (xmlNode2 != null)
			{
				XmlNode xmlNode4;
				if ((xmlNode4 = xmlNode2.SelectSingleNode("EMBEDDEDDATA")) == null)
				{
					xmlNode4 = (xmlNode2.SelectSingleNode("EMBEDINFO") ?? xmlNode2.SelectSingleNode("DATA"));
				}
				xmlNode3 = xmlNode4;
			}
			if (xmlNode3 == null)
			{
				xmlNode3 = tn.SelectSingleNode("EMBEDDEDDATA");
			}
			string text = null;
			if (xmlNode3 != null)
			{
				string text2;
				if ((text2 = XdfLoader.Attr(xmlNode3, "mmedaddress")) == null && (text2 = XdfLoader.Attr(xmlNode3, "address")) == null)
				{
					text2 = (XdfLoader.Attr(xmlNode3, "offset") ?? XdfLoader.Attr(xmlNode3, "Address"));
				}
				text = text2;
			}
			if (string.IsNullOrEmpty(text))
			{
				text = XdfLoader.Attr(tn, "address");
			}
			xdfTable.Address = XdfLoader.ParseAddress(text);
			string text3 = null;
			if (xmlNode3 != null)
			{
				string text4;
				if ((text4 = XdfLoader.Attr(xmlNode3, "mmedelementsizebits")) == null && (text4 = XdfLoader.Attr(xmlNode3, "datasizebits")) == null)
				{
					text4 = (XdfLoader.Attr(xmlNode3, "elementsizebits") ?? XdfLoader.Attr(xmlNode3, "bitcount"));
				}
				text3 = text4;
			}
			if (string.IsNullOrEmpty(text3))
			{
				text3 = XdfLoader.Attr(tn, "datasizeinbits");
			}
			xdfTable.ElementSize = XdfLoader.ParseElementSizeBits(text3);
			xdfTable.IsSigned = def.DefaultSigned;
			xdfTable.IsSwapped = def.DefaultLsbFirst;
			xdfTable.IsFloat = false;
			if (xmlNode3 != null)
			{
				string text5 = XdfLoader.Attr(xmlNode3, "signed");
				if (!string.IsNullOrEmpty(text5))
				{
					xdfTable.IsSigned = XdfLoader.ParseBool(text5);
				}
				string text6 = XdfLoader.Attr(xmlNode3, "lsbfirst");
				if (!string.IsNullOrEmpty(text6))
				{
					xdfTable.IsSwapped = XdfLoader.ParseBool(text6);
				}
				string text7 = XdfLoader.Attr(xmlNode3, "float");
				if (!string.IsNullOrEmpty(text7))
				{
					xdfTable.IsFloat = XdfLoader.ParseBool(text7);
				}
			}
			string text8 = null;
			if (xmlNode3 != null)
			{
				string text9;
				if ((text9 = XdfLoader.Attr(xmlNode3, "mmedtypeflags")) == null)
				{
					text9 = (XdfLoader.Attr(xmlNode3, "typeflags") ?? XdfLoader.Attr(xmlNode3, "flags"));
				}
				text8 = text9;
			}
			if (!string.IsNullOrEmpty(text8))
			{
				int num = XdfLoader.ParseAddress(text8);
				if ((num & 1) != 0)
				{
					xdfTable.IsSigned = true;
				}
				if ((num & 4) != 0)
				{
					xdfTable.IsFloat = true;
				}
			}
			if (xdfTable.IsFloat && xdfTable.ElementSize != 4)
			{
				xdfTable.IsFloat = false;
			}
			string text10 = (xmlNode3 != null) ? XdfLoader.Attr(xmlNode3, "mmedrowcount") : null;
			if (text10 == null)
			{
				text10 = (((xmlNode3 != null) ? XdfLoader.Attr(xmlNode3, "rowcount") : null) ?? XdfLoader.Attr(tn, "rows"));
			}
			xdfTable.Rows = XdfLoader.ParseIntSafe(text10, 0);
			string text11 = (xmlNode3 != null) ? XdfLoader.Attr(xmlNode3, "mmedcolcount") : null;
			if (text11 == null)
			{
				text11 = (((xmlNode3 != null) ? XdfLoader.Attr(xmlNode3, "colcount") : null) ?? XdfLoader.Attr(tn, "cols"));
			}
			xdfTable.Cols = XdfLoader.ParseIntSafe(text11, 0);
			if (xdfTable.Rows == 0)
			{
				xdfTable.Rows = 1;
			}
			if (xdfTable.Cols == 0)
			{
				xdfTable.Cols = 1;
			}
			XmlNode xmlNode5;
			if ((xmlNode5 = ((xmlNode2 != null) ? xmlNode2.SelectSingleNode("MATH") : null)) == null)
			{
				xmlNode5 = (tn.SelectSingleNode("MATH") ?? tn.SelectSingleNode("math"));
			}
			XmlNode xmlNode6 = xmlNode5;
			if (xmlNode6 != null)
			{
				XdfTable xdfTable4 = xdfTable;
				string mathEquation;
				if ((mathEquation = XdfLoader.Attr(xmlNode6, "equation")) == null)
				{
					mathEquation = (XdfLoader.Attr(xmlNode6, "expr") ?? "X");
				}
				xdfTable4.MathEquation = mathEquation;
				double scale;
				double offset;
				XdfLoader.ParseMathEquation(xdfTable.MathEquation, out scale, out offset);
				xdfTable.Scale = scale;
				xdfTable.Offset = offset;
			}
			else
			{
				xdfTable.Scale = 1.0;
				xdfTable.Offset = 0.0;
			}
			XdfLoader.ParseAxis(xdfTable, tn, "x", true, def);
			XdfLoader.ParseAxis(xdfTable, tn, "y", false, def);
			xdfTable.PreferRpmOnTop = (xdfTable.XAxisCount > xdfTable.YAxisCount);
			bool flag = false;
			if (xdfTable.XAxisAddress > 0 && xdfTable.YAxisAddress > 0 && xdfTable.XAxisCount > 0 && xdfTable.YAxisCount > 0)
			{
				if (xdfTable.XAxisCount > xdfTable.YAxisCount)
				{
					flag = true;
				}
			}
			else if (xdfTable.Rows != xdfTable.Cols && xdfTable.Rows > 0 && xdfTable.Cols > 0 && xdfTable.Rows < xdfTable.Cols && xdfTable.Cols >= 25 && xdfTable.Rows >= 20)
			{
				flag = true;
			}
			if (flag)
			{
				int rows = xdfTable.Rows;
				xdfTable.Rows = xdfTable.Cols;
				xdfTable.Cols = rows;
				int xaxisAddress = xdfTable.XAxisAddress;
				xdfTable.XAxisAddress = xdfTable.YAxisAddress;
				xdfTable.YAxisAddress = xaxisAddress;
				int xaxisElementSize = xdfTable.XAxisElementSize;
				xdfTable.XAxisElementSize = xdfTable.YAxisElementSize;
				xdfTable.YAxisElementSize = xaxisElementSize;
				double xaxisScale = xdfTable.XAxisScale;
				xdfTable.XAxisScale = xdfTable.YAxisScale;
				xdfTable.YAxisScale = xaxisScale;
				double xaxisOffset = xdfTable.XAxisOffset;
				xdfTable.XAxisOffset = xdfTable.YAxisOffset;
				xdfTable.YAxisOffset = xaxisOffset;
				int xaxisCount = xdfTable.XAxisCount;
				xdfTable.XAxisCount = xdfTable.YAxisCount;
				xdfTable.YAxisCount = xaxisCount;
				List<double> xaxisValues = xdfTable.XAxisValues;
				xdfTable.XAxisValues = xdfTable.YAxisValues;
				xdfTable.YAxisValues = xaxisValues;
			}
			xdfTable.XAxisLabel = (XdfLoader.GetAxisLabel(tn, "x") ?? "X");
			xdfTable.YAxisLabel = (XdfLoader.GetAxisLabel(tn, "y") ?? "Y");
			XmlNode xmlNode7 = tn.SelectSingleNode("CATEGORYMEM");
			if (xmlNode7 != null)
			{
				string text12 = XdfLoader.Attr(xmlNode7, "category") ?? XdfLoader.Attr(xmlNode7, "name");
				if (!string.IsNullOrEmpty(text12))
				{
					string text13;
					xdfTable.CategoryName = (def.Categories.TryGetValue(text12, out text13) ? text13 : text12);
				}
			}
			return xdfTable;
		}

		// Token: 0x06001508 RID: 5384 RVA: 0x0009D064 File Offset: 0x0009D064
		private static string GetAxisLabel(XmlNode tableNode, string axisId)
		{
			XmlNode xmlNode = tableNode.SelectSingleNode("XDFAXIS[@id='" + axisId + "']") ?? tableNode.SelectSingleNode("XDFAXIS[@id='" + axisId.ToUpper() + "']");
			if (xmlNode == null)
			{
				return null;
			}
			string result;
			if ((result = XdfLoader.GetChildText(xmlNode, "units")) == null && (result = XdfLoader.GetChildText(xmlNode, "label")) == null && (result = XdfLoader.GetChildText(xmlNode, "name")) == null)
			{
				result = (XdfLoader.Attr(xmlNode, "label") ?? XdfLoader.Attr(xmlNode, "name"));
			}
			return result;
		}

		// Token: 0x06001509 RID: 5385 RVA: 0x0009D0F8 File Offset: 0x0009D0F8
		private static void ParseAxis(XdfTable t, XmlNode tableNode, string axisId, bool isX, XdfDefinition def)
		{
			XmlNode xmlNode;
			if ((xmlNode = tableNode.SelectSingleNode("XDFAXIS[@id='" + axisId + "']")) == null)
			{
				xmlNode = (tableNode.SelectSingleNode("XDFAXIS[@id='" + axisId.ToUpper() + "']") ?? tableNode.SelectSingleNode("AXIS[@id='" + axisId + "']"));
			}
			XmlNode xmlNode2 = xmlNode;
			if (xmlNode2 == null)
			{
				return;
			}
			XmlNode xmlNode3;
			if ((xmlNode3 = xmlNode2.SelectSingleNode("DALINK")) == null && (xmlNode3 = xmlNode2.SelectSingleNode("dalink")) == null && (xmlNode3 = xmlNode2.SelectSingleNode("embedinfo")) == null)
			{
				xmlNode3 = (xmlNode2.SelectSingleNode("EMBEDINFO") ?? xmlNode2.SelectSingleNode("link"));
			}
			XmlNode xmlNode4 = xmlNode3;
			string text = null;
			if (xmlNode4 != null)
			{
				string text2;
				if ((text2 = XdfLoader.Attr(xmlNode4, "obidhash")) == null && (text2 = XdfLoader.Attr(xmlNode4, "linkobjid")) == null)
				{
					text2 = (XdfLoader.Attr(xmlNode4, "objid") ?? XdfLoader.Attr(xmlNode4, "id"));
				}
				text = text2;
			}
			if (!string.IsNullOrEmpty(text))
			{
				if (isX)
				{
					t.XAxisLinkId = text;
				}
				else
				{
					t.YAxisLinkId = text;
				}
			}
			XmlNode xmlNode5 = xmlNode2.SelectSingleNode("EMBEDDEDDATA") ?? xmlNode2.SelectSingleNode("DATA");
			if (xmlNode5 != null)
			{
				string s;
				if ((s = XdfLoader.Attr(xmlNode5, "mmedaddress")) == null)
				{
					s = (XdfLoader.Attr(xmlNode5, "address") ?? XdfLoader.Attr(xmlNode5, "offset"));
				}
				int num = XdfLoader.ParseAddress(s);
				string s2;
				if ((s2 = XdfLoader.Attr(xmlNode5, "mmedelementsizebits")) == null)
				{
					s2 = (XdfLoader.Attr(xmlNode5, "datasizebits") ?? XdfLoader.Attr(xmlNode5, "elementsizebits"));
				}
				int num2 = XdfLoader.ParseElementSizeBits(s2);
				double num3 = 1.0;
				double num4 = 0.0;
				XmlNode xmlNode6 = xmlNode2.SelectSingleNode("MATH") ?? xmlNode2.SelectSingleNode("math");
				if (xmlNode6 != null)
				{
					string eq;
					if ((eq = XdfLoader.Attr(xmlNode6, "equation")) == null)
					{
						eq = (XdfLoader.Attr(xmlNode6, "expr") ?? "X");
					}
					XdfLoader.ParseMathEquation(eq, out num3, out num4);
				}
				string s3;
				if ((s3 = XdfLoader.GetChildText(xmlNode2, "indexcount")) == null)
				{
					s3 = (XdfLoader.Attr(xmlNode2, "count") ?? XdfLoader.Attr(xmlNode2, "indexcount"));
				}
				int num5 = XdfLoader.ParseIntSafe(s3, 0);
				if (isX)
				{
					t.XAxisAddress = num;
					t.XAxisElementSize = num2;
					t.XAxisScale = num3;
					t.XAxisOffset = num4;
					t.XAxisCount = num5;
				}
				else
				{
					t.YAxisAddress = num;
					t.YAxisElementSize = num2;
					t.YAxisScale = num3;
					t.YAxisOffset = num4;
					t.YAxisCount = num5;
				}
			}
			XmlNodeList xmlNodeList = xmlNode2.SelectNodes(".//LABEL");
			if (xmlNodeList != null && xmlNodeList.Count > 0)
			{
				List<double> list = new List<double>(xmlNodeList.Count);
				foreach (object obj in xmlNodeList)
				{
					XmlNode xmlNode7 = (XmlNode)obj;
					string text3 = XdfLoader.Attr(xmlNode7, "value") ?? xmlNode7.InnerText;
					double item;
					if (!string.IsNullOrEmpty(text3) && double.TryParse(text3.Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out item))
					{
						list.Add(item);
					}
					else
					{
						list.Add(0.0);
					}
				}
				if (list.Count > 0)
				{
					if (isX)
					{
						t.XAxisValues = list;
						return;
					}
					t.YAxisValues = list;
				}
			}
		}

		// Token: 0x0600150A RID: 5386 RVA: 0x0009D484 File Offset: 0x0009D484
		public static void ResolveAxisLinks(XdfDefinition def)
		{
			if (def == null)
			{
				return;
			}
			Dictionary<string, XdfTable> dictionary = new Dictionary<string, XdfTable>(StringComparer.OrdinalIgnoreCase);
			foreach (XdfTable xdfTable in def.Tables)
			{
				if (!string.IsNullOrEmpty(xdfTable.UniqueId))
				{
					dictionary[xdfTable.UniqueId] = xdfTable;
				}
			}
			Dictionary<int, XdfTable> dictionary2 = new Dictionary<int, XdfTable>();
			foreach (XdfTable xdfTable2 in def.Tables)
			{
				if (xdfTable2.Rows > 0 && xdfTable2.Cols > 0 && ((xdfTable2.Rows == 1 && xdfTable2.Cols > 1) || (xdfTable2.Cols == 1 && xdfTable2.Rows > 1)))
				{
					int key = Math.Max(xdfTable2.Rows, xdfTable2.Cols);
					if (!dictionary2.ContainsKey(key))
					{
						dictionary2[key] = xdfTable2;
					}
				}
			}
			checked
			{
				for (int i = 0; i < 5; i++)
				{
					bool flag = false;
					foreach (XdfTable xdfTable3 in def.Tables)
					{
						if (xdfTable3.Rows > 0 && xdfTable3.Cols > 0)
						{
							if ((xdfTable3.Rows == 1 && xdfTable3.Cols > 1) || (xdfTable3.Cols == 1 && xdfTable3.Rows > 1))
							{
								if (xdfTable3.Rows == 1 && xdfTable3.Cols > 1)
								{
									if (xdfTable3.YAxisAddress != 0)
									{
										xdfTable3.YAxisAddress = 0;
										xdfTable3.YAxisElementSize = 0;
										xdfTable3.YAxisCount = 1;
										xdfTable3.YAxisValues.Clear();
										flag = true;
									}
									if (xdfTable3.XAxisCount != xdfTable3.Cols)
									{
										xdfTable3.XAxisCount = xdfTable3.Cols;
									}
								}
								else
								{
									if (xdfTable3.XAxisAddress != 0)
									{
										xdfTable3.XAxisAddress = 0;
										xdfTable3.XAxisElementSize = 0;
										xdfTable3.XAxisCount = 1;
										xdfTable3.XAxisValues.Clear();
										flag = true;
									}
									if (xdfTable3.YAxisCount != xdfTable3.Rows)
									{
										xdfTable3.YAxisCount = xdfTable3.Rows;
									}
								}
							}
							else
							{
								if (xdfTable3.XAxisAddress == 0 && xdfTable3.Cols > 1)
								{
									XdfTable xdfTable4 = null;
									if (!string.IsNullOrEmpty(xdfTable3.XAxisLinkId))
									{
										dictionary.TryGetValue(xdfTable3.XAxisLinkId, out xdfTable4);
									}
									if (xdfTable4 == null)
									{
										dictionary2.TryGetValue(xdfTable3.Cols, out xdfTable4);
									}
									if (xdfTable4 != null && xdfTable4.Address > 0 && xdfTable4 != xdfTable3)
									{
										xdfTable3.XAxisAddress = xdfTable4.Address;
										xdfTable3.XAxisElementSize = xdfTable4.ElementSize;
										xdfTable3.XAxisScale = xdfTable4.Scale;
										xdfTable3.XAxisOffset = xdfTable4.Offset;
										xdfTable3.XAxisCount = Math.Max(xdfTable4.Rows, xdfTable4.Cols);
										if (xdfTable3.XAxisValues.Count == 0 && xdfTable4.XAxisValues.Count > 0)
										{
											xdfTable3.XAxisValues = new List<double>(xdfTable4.XAxisValues);
										}
										flag = true;
									}
								}
								if (xdfTable3.YAxisAddress == 0 && xdfTable3.Rows > 1)
								{
									XdfTable xdfTable5 = null;
									if (!string.IsNullOrEmpty(xdfTable3.YAxisLinkId))
									{
										dictionary.TryGetValue(xdfTable3.YAxisLinkId, out xdfTable5);
									}
									if (xdfTable5 == null)
									{
										dictionary2.TryGetValue(xdfTable3.Rows, out xdfTable5);
									}
									if (xdfTable5 != null && xdfTable5.Address > 0 && xdfTable5 != xdfTable3)
									{
										xdfTable3.YAxisAddress = xdfTable5.Address;
										xdfTable3.YAxisElementSize = xdfTable5.ElementSize;
										xdfTable3.YAxisScale = xdfTable5.Scale;
										xdfTable3.YAxisOffset = xdfTable5.Offset;
										xdfTable3.YAxisCount = Math.Max(xdfTable5.Rows, xdfTable5.Cols);
										if (xdfTable3.YAxisValues.Count == 0 && xdfTable5.YAxisValues.Count > 0)
										{
											xdfTable3.YAxisValues = new List<double>(xdfTable5.YAxisValues);
										}
										flag = true;
									}
								}
							}
						}
					}
					if (!flag)
					{
						break;
					}
				}
			}
		}

		// Token: 0x0600150B RID: 5387 RVA: 0x0009D90C File Offset: 0x0009D90C
		private static string ExtractXmlFromBinary(byte[] raw)
		{
			if (raw == null || raw.Length < 5)
			{
				return null;
			}
			int num = 0;
			if (raw.Length >= 3 && raw[0] == 239 && raw[1] == 187 && raw[2] == 191)
			{
				num = 3;
			}
			else if (raw.Length >= 2 && ((raw[0] == 255 && raw[1] == 254) || (raw[0] == 254 && raw[1] == 255)))
			{
				num = 2;
			}
			int num2 = -1;
			checked
			{
				for (int i = num; i < raw.Length - 1; i++)
				{
					if (raw[i] == 60)
					{
						char c = (char)raw[i + 1];
						if (c == '?' || c == '!' || char.IsLetter(c))
						{
							num2 = i;
							break;
						}
					}
				}
				if (num2 < 0)
				{
					return null;
				}
				byte[] array = new byte[raw.Length - num2];
				Array.Copy(raw, num2, array, 0, array.Length);
				string result;
				if ((result = XdfLoader.TryDecode(array, Encoding.UTF8)) == null && (result = XdfLoader.TryDecode(array, Encoding.Unicode)) == null && (result = XdfLoader.TryDecode(array, Encoding.BigEndianUnicode)) == null && (result = XdfLoader.TryDecode(array, Encoding.UTF32)) == null)
				{
					result = (XdfLoader.TryDecode(array, Encoding.ASCII) ?? XdfLoader.TryDecode(array, Encoding.GetEncoding(1252)));
				}
				return result;
			}
		}

		// Token: 0x0600150C RID: 5388 RVA: 0x0009DA38 File Offset: 0x0009DA38
		private static string TryDecode(byte[] data, Encoding enc)
		{
			string result;
			try
			{
				string @string = enc.GetString(data);
				result = ((@string.IndexOf('<') < 0 || @string.IndexOf('>') < 0) ? null : @string);
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x0600150D RID: 5389 RVA: 0x0009DA80 File Offset: 0x0009DA80
		private static string CleanupXml(string s)
		{
			if (string.IsNullOrEmpty(s))
			{
				return s;
			}
			if (s[0] == '﻿')
			{
				s = s.Substring(1);
			}
			StringBuilder stringBuilder = new StringBuilder(s.Length);
			foreach (char c in s)
			{
				if (c == '\t' || c == '\n' || c == '\r' || (c >= ' ' && c <= '퟿') || (c >= '' && c <= '�') || ((int)c >= 65536 && (int)c <= 1114111))
				{
					stringBuilder.Append(c);
				}
			}
			s = stringBuilder.ToString();
			s = Regex.Replace(s, "&(?!(amp|lt|gt|quot|apos|#\\d+|#x[0-9A-Fa-f]+);)", "&amp;");
			s = Regex.Replace(s, "<!DOCTYPE[^>]*>", "", RegexOptions.IgnoreCase);
			return s;
		}

		// Token: 0x0600150E RID: 5390 RVA: 0x0009DB48 File Offset: 0x0009DB48
		private static string AggressiveRepair(string s)
		{
			if (string.IsNullOrEmpty(s))
			{
				return s;
			}
			s = Regex.Replace(s, "<!--.*?-->", "", RegexOptions.Singleline);
			s = Regex.Replace(s, "<!\\[CDATA\\[.*?\\]\\]>", "", RegexOptions.Singleline);
			s = Regex.Replace(s, "<(\\w+)([^>]*?)/>", "<$1$2 />");
			return XdfLoader.RepairTagMismatch(s);
		}

		// Token: 0x0600150F RID: 5391 RVA: 0x0009DBA0 File Offset: 0x0009DBA0
		private static string RepairTagMismatch(string xml)
		{
			if (string.IsNullOrEmpty(xml))
			{
				return xml;
			}
			string[] array = xml.Replace("\r\n", "\n").Split(new char[]
			{
				'\n'
			});
			Stack<string> stack = new Stack<string>();
			HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
			{
				"br",
				"hr",
				"img",
				"input",
				"meta",
				"link",
				"area",
				"base",
				"col",
				"embed",
				"param",
				"source",
				"track",
				"wbr"
			};
			checked
			{
				StringBuilder stringBuilder = new StringBuilder(xml.Length + 256);
				Regex regex = new Regex("<\\s*(/?)\\s*([A-Za-z_][\\w\\-\\.]*)([^>]*?)(/?)\\s*>", RegexOptions.Compiled);
				for (int i = 0; i < array.Length; i++)
				{
					string text = array[i];
					int num = 0;
					StringBuilder stringBuilder2 = new StringBuilder();
					foreach (object obj in regex.Matches(text))
					{
						Match match = (Match)obj;
						stringBuilder2.Append(text, num, match.Index - num);
						string value = match.Groups[1].Value;
						string value2 = match.Groups[2].Value;
						string value3 = match.Groups[4].Value;
						bool flag = value == "/";
						if (value3 == "/" || hashSet.Contains(value2))
						{
							stringBuilder2.Append(match.Value);
						}
						else if (!flag)
						{
							stringBuilder2.Append(match.Value);
							stack.Push(value2);
						}
						else if (stack.Count > 0 && string.Equals(stack.Peek(), value2, StringComparison.OrdinalIgnoreCase))
						{
							stack.Pop();
							stringBuilder2.Append(match.Value);
						}
						else
						{
							bool flag2 = false;
							using (Stack<string>.Enumerator enumerator2 = stack.GetEnumerator())
							{
								while (enumerator2.MoveNext())
								{
									if (string.Equals(enumerator2.Current, value2, StringComparison.OrdinalIgnoreCase))
									{
										flag2 = true;
										break;
									}
								}
							}
							if (flag2)
							{
								while (stack.Count > 0 && !string.Equals(stack.Peek(), value2, StringComparison.OrdinalIgnoreCase))
								{
									stringBuilder2.Append("</").Append(stack.Pop()).Append(">");
								}
								if (stack.Count > 0)
								{
									stack.Pop();
								}
								stringBuilder2.Append(match.Value);
							}
							else
							{
								stringBuilder2.Append(match.Value);
							}
						}
						num = match.Index + match.Length;
					}
					if (num < text.Length)
					{
						stringBuilder2.Append(text, num, text.Length - num);
					}
					stringBuilder.Append(stringBuilder2);
					if (i < array.Length - 1)
					{
						stringBuilder.Append('\n');
					}
				}
				string text2 = stringBuilder.ToString();
				while (stack.Count > 0)
				{
					string text3 = stack.Pop();
					if (text2.LastIndexOf("</" + text3 + ">", StringComparison.OrdinalIgnoreCase) < 0)
					{
						text2 = text2 + "\n</" + text3 + ">";
					}
				}
				return text2;
			}
		}

		// Token: 0x06001510 RID: 5392 RVA: 0x0009DF78 File Offset: 0x0009DF78
		private static string FixHeaderMismatchOnly(string xml)
		{
			if (string.IsNullOrEmpty(xml))
			{
				return xml;
			}
			Match match = Regex.Match(xml, "<XDFFORMAT\\b", RegexOptions.IgnoreCase);
			if (!match.Success)
			{
				return xml;
			}
			string input = xml.Substring(0, match.Index);
			if (Regex.IsMatch(input, "<XDFHEADER\\b", RegexOptions.IgnoreCase) && !Regex.IsMatch(input, "</XDFHEADER\\s*>", RegexOptions.IgnoreCase))
			{
				xml = xml.Insert(match.Index, "</XDFHEADER>\n  ");
			}
			return xml;
		}

		// Token: 0x06001511 RID: 5393 RVA: 0x0009DFE4 File Offset: 0x0009DFE4
		private static string Attr(XmlNode n, string name)
		{
			if (n == null || n.Attributes == null)
			{
				return null;
			}
			XmlAttribute xmlAttribute = n.Attributes[name];
			if (xmlAttribute != null && !string.IsNullOrWhiteSpace(xmlAttribute.Value))
			{
				return xmlAttribute.Value.Trim();
			}
			return null;
		}

		// Token: 0x06001512 RID: 5394 RVA: 0x0009E028 File Offset: 0x0009E028
		private static string GetChildText(XmlNode parent, string name)
		{
			if (parent == null)
			{
				return null;
			}
			XmlNode xmlNode = parent.SelectSingleNode(name);
			if (xmlNode != null && !string.IsNullOrWhiteSpace(xmlNode.InnerText))
			{
				return xmlNode.InnerText.Trim();
			}
			return null;
		}

		// Token: 0x06001513 RID: 5395 RVA: 0x0009E060 File Offset: 0x0009E060
		private static bool ParseBool(string s)
		{
			if (string.IsNullOrWhiteSpace(s))
			{
				return false;
			}
			s = s.Trim().ToLowerInvariant();
			return s == "1" || s == "true" || s == "yes" || s == "y" || s == "on";
		}

		// Token: 0x06001514 RID: 5396 RVA: 0x0009E0C8 File Offset: 0x0009E0C8
		private static int ParseIntSafe(string s, int fallback)
		{
			int result;
			if (!int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out result))
			{
				return fallback;
			}
			return result;
		}

		// Token: 0x06001515 RID: 5397 RVA: 0x0009E0E8 File Offset: 0x0009E0E8
		private static int ParseHexSafe(string s)
		{
			int result;
			try
			{
				if (s.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
				{
					s = s.Substring(2);
				}
				result = Convert.ToInt32(s, 16);
			}
			catch
			{
				result = 0;
			}
			return result;
		}

		// Token: 0x06001516 RID: 5398 RVA: 0x0009E130 File Offset: 0x0009E130
		private static int ParseAddress(string s)
		{
			if (string.IsNullOrWhiteSpace(s))
			{
				return 0;
			}
			s = s.Trim().ToUpperInvariant().Replace(",", "").Replace("_", "").Replace(" ", "");
			bool flag = false;
			if (s.StartsWith("0X"))
			{
				s = s.Substring(2);
				flag = true;
			}
			else if (s.StartsWith("$"))
			{
				s = s.Substring(1);
				flag = true;
			}
			else if (s.StartsWith("H'"))
			{
				s = s.Substring(2).TrimEnd(new char[]
				{
					'\''
				});
				flag = true;
			}
			else if (s.EndsWith("H"))
			{
				s = s.Substring(0, checked(s.Length - 1));
				flag = true;
			}
			if (flag)
			{
				int result;
				if (int.TryParse(s, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out result))
				{
					return result;
				}
				try
				{
					return Convert.ToInt32(s, 16);
				}
				catch
				{
					return 0;
				}
			}
			int result2;
			if (int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out result2))
			{
				return result2;
			}
			int result3;
			if (int.TryParse(s, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out result3))
			{
				return result3;
			}
			int result4;
			try
			{
				result4 = Convert.ToInt32(s, 16);
			}
			catch
			{
				result4 = 0;
			}
			return result4;
		}

		// Token: 0x06001517 RID: 5399 RVA: 0x0009E288 File Offset: 0x0009E288
		private static int ParseElementSizeBits(string s)
		{
			if (string.IsNullOrWhiteSpace(s))
			{
				return 2;
			}
			int num;
			if (int.TryParse(s, out num))
			{
				if (num <= 8)
				{
					return 1;
				}
				if (num <= 16)
				{
					return 2;
				}
				if (num <= 32)
				{
					return 4;
				}
			}
			if (s == "1")
			{
				return 1;
			}
			if (s == "2")
			{
				return 2;
			}
			if (s == "4")
			{
				return 4;
			}
			return 2;
		}

		// Token: 0x06001518 RID: 5400 RVA: 0x0009E2EC File Offset: 0x0009E2EC
		private static void ParseMathEquation(string eq, out double scale, out double offset)
		{
			scale = 1.0;
			offset = 0.0;
			if (string.IsNullOrWhiteSpace(eq))
			{
				return;
			}
			eq = eq.Trim().Replace(",", ".").Replace(" ", "");
			string text = Regex.Replace(eq, "^[xX]", "", RegexOptions.IgnoreCase).Trim();
			if (string.IsNullOrEmpty(text))
			{
				return;
			}
			Match match = Regex.Match(text, "^\\*?\\s*([-+]?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?)\\s*(?:\\+\\s*([-+]?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?))?$");
			if (match.Success)
			{
				if (match.Groups[1].Success)
				{
					double.TryParse(match.Groups[1].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out scale);
				}
				if (match.Groups[2].Success)
				{
					double.TryParse(match.Groups[2].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out offset);
				}
				return;
			}
			match = Regex.Match(text, "^/\\s*([-+]?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?)\\s*(?:\\+\\s*([-+]?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?))?$");
			if (match.Success)
			{
				double num;
				if (match.Groups[1].Success && double.TryParse(match.Groups[1].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out num) && num != 0.0)
				{
					scale = 1.0 / num;
				}
				if (match.Groups[2].Success)
				{
					double.TryParse(match.Groups[2].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out offset);
				}
				return;
			}
			match = Regex.Match(text, "^\\+\\s*([-+]?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?)$");
			if (match.Success)
			{
				double.TryParse(match.Groups[1].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out offset);
				return;
			}
			try
			{
				string expr = Regex.Replace(eq, "x", "X");
				double num2 = XdfLoader.EvalSimpleExpr(expr, 0.0);
				double num3 = XdfLoader.EvalSimpleExpr(expr, 1.0);
				if (double.IsInfinity(num2) || double.IsNaN(num2) || double.IsInfinity(num3) || double.IsNaN(num3))
				{
					scale = 1.0;
					offset = 0.0;
				}
				else
				{
					scale = num3 - num2;
					offset = num2;
					if (Math.Abs(scale) < 1E-12)
					{
						scale = 1.0;
						offset = num2;
					}
				}
			}
			catch
			{
				scale = 1.0;
				offset = 0.0;
			}
		}

		// Token: 0x06001519 RID: 5401 RVA: 0x0009E570 File Offset: 0x0009E570
		private static double EvalSimpleExpr(string expr, double x)
		{
			if (string.IsNullOrWhiteSpace(expr))
			{
				return 0.0;
			}
			string text = Regex.Replace(expr, "X", x.ToString(CultureInfo.InvariantCulture), RegexOptions.IgnoreCase);
			text = text.Replace(",", ".").Replace(" ", "");
			text = Regex.Replace(text, "[^0-9\\.\\+\\-\\*/\\(\\)eE]", "");
			if (string.IsNullOrEmpty(text))
			{
				return 0.0;
			}
			List<string> tokens = XdfLoader.Tokenize(text);
			int num = 0;
			return XdfLoader.ParseExpression(tokens, ref num);
		}

		// Token: 0x0600151A RID: 5402 RVA: 0x0009E5FC File Offset: 0x0009E5FC
		private static List<string> Tokenize(string s)
		{
			List<string> list = new List<string>();
			int i = 0;
			checked
			{
				while (i < s.Length)
				{
					char c = s[i];
					if (char.IsDigit(c) || c == '.')
					{
						int num = i;
						while (i < s.Length && (char.IsDigit(s[i]) || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || ((s[i] == '+' || s[i] == '-') && i > num && (s[i - 1] == 'e' || s[i - 1] == 'E'))))
						{
							i++;
						}
						list.Add(s.Substring(num, i - num));
					}
					else if (c == '+' || c == '-' || c == '*' || c == '/' || c == '(' || c == ')')
					{
						list.Add(c.ToString());
						i++;
					}
					else
					{
						i++;
					}
				}
				return list;
			}
		}

		// Token: 0x0600151B RID: 5403 RVA: 0x0009E6F8 File Offset: 0x0009E6F8
		private static double ParseExpression(List<string> tokens, ref int pos)
		{
			double num = XdfLoader.ParseTerm(tokens, ref pos);
			while (pos < tokens.Count && (tokens[pos] == "+" || tokens[pos] == "-"))
			{
				int num2 = pos;
				pos = checked(num2 + 1);
				string a = tokens[num2];
				double num3 = XdfLoader.ParseTerm(tokens, ref pos);
				if (a == "+")
				{
					num += num3;
				}
				else
				{
					num -= num3;
				}
			}
			return num;
		}

		// Token: 0x0600151C RID: 5404 RVA: 0x0009E770 File Offset: 0x0009E770
		private static double ParseTerm(List<string> tokens, ref int pos)
		{
			double num = XdfLoader.ParseFactor(tokens, ref pos);
			while (pos < tokens.Count && (tokens[pos] == "*" || tokens[pos] == "/"))
			{
				int num2 = pos;
				pos = checked(num2 + 1);
				string a = tokens[num2];
				double num3 = XdfLoader.ParseFactor(tokens, ref pos);
				if (a == "*")
				{
					num *= num3;
				}
				else if (num3 != 0.0)
				{
					num /= num3;
				}
			}
			return num;
		}

		// Token: 0x0600151D RID: 5405 RVA: 0x0009E7F4 File Offset: 0x0009E7F4
		private static double ParseFactor(List<string> tokens, ref int pos)
		{
			if (pos >= tokens.Count)
			{
				return 0.0;
			}
			string text = tokens[pos];
			checked
			{
				if (text == "-")
				{
					pos++;
					return unchecked(-XdfLoader.ParseFactor(tokens, ref pos));
				}
				if (text == "+")
				{
					pos++;
					return XdfLoader.ParseFactor(tokens, ref pos);
				}
				if (text == "(")
				{
					pos++;
					double result = XdfLoader.ParseExpression(tokens, ref pos);
					if (pos < tokens.Count && tokens[pos] == ")")
					{
						pos++;
					}
					return result;
				}
				pos++;
				double result2;
				if (!double.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out result2))
				{
					return 0.0;
				}
				return result2;
			}
		}

		// Token: 0x0600151E RID: 5406 RVA: 0x0009E8BC File Offset: 0x0009E8BC
		private static string ClassifyTable(string title)
		{
			if (string.IsNullOrEmpty(title))
			{
				return "General";
			}
			string text = title.ToLowerInvariant();
			if (text.StartsWith("table ") || text.Contains("breakpoint"))
			{
				return "Axes";
			}
			if (text == "rpm" || text == "tps" || text == "map" || text == "maf" || text == "ect" || text == "iat")
			{
				return "Axes";
			}
			if (text.Contains("fuel") || text.Contains("afr") || text.Contains("injector") || text.Contains("inj") || text.Contains("lambda") || text.Contains("o2"))
			{
				return "Fuel";
			}
			if (text.Contains("ign") || text.Contains("timing") || text.Contains("spark") || text.Contains("advance") || text.Contains("dwell") || text.Contains("decel") || text.Contains("accel"))
			{
				return "Ignition";
			}
			if (text.Contains("limit") || text.Contains("cut") || text.Contains("rev") || text.Contains("governor"))
			{
				return "Limiters";
			}
			if (text.Contains("idle") || text.Contains("iac") || text.Contains("isc"))
			{
				return "Idle";
			}
			if (text.Contains("boost") || text.Contains("turbo") || text.Contains("wastegate"))
			{
				return "Boost";
			}
			if (text.Contains("vvt") || text.Contains("cam") || text.Contains("vanos"))
			{
				return "VVT";
			}
			if (text.Contains("knock") || text.Contains("det"))
			{
				return "Knock";
			}
			if (text.Contains("fan") || text.Contains("coolant"))
			{
				return "Cooling";
			}
			if (text.Contains("version") || text.Contains("sw ver") || text.Contains("hw ver") || text.Contains("region"))
			{
				return "Info";
			}
			return "General";
		}

		// Token: 0x0600151F RID: 5407 RVA: 0x0009EB48 File Offset: 0x0009EB48
		private static string GetHexPreview(byte[] data, int count)
		{
			if (data == null)
			{
				return "(null)";
			}
			count = Math.Min(count, data.Length);
			checked
			{
				StringBuilder stringBuilder = new StringBuilder(count * 3);
				for (int i = 0; i < count; i++)
				{
					stringBuilder.Append(data[i].ToString("X2", CultureInfo.InvariantCulture)).Append(' ');
					if ((i + 1) % 16 == 0)
					{
						stringBuilder.AppendLine();
					}
				}
				return stringBuilder.ToString();
			}
		}

		// Token: 0x06001520 RID: 5408 RVA: 0x0009EBB8 File Offset: 0x0009EBB8
		private static string GetAsciiPreview(byte[] data, int count)
		{
			if (data == null)
			{
				return "(null)";
			}
			count = Math.Min(count, data.Length);
			StringBuilder stringBuilder = new StringBuilder(count);
			checked
			{
				for (int i = 0; i < count; i++)
				{
					byte b = data[i];
					if (b >= 32 && b < 127)
					{
						stringBuilder.Append((char)b);
					}
					else if (b == 10 || b == 13)
					{
						stringBuilder.Append('\n');
					}
					else
					{
						stringBuilder.Append('.');
					}
				}
				return stringBuilder.ToString();
			}
		}
	}
}
