﻿namespace HondaMapEditorPro
{
	// Token: 0x020008FC RID: 2300
	public partial class Form2 : global::System.Windows.Forms.Form
	{
		// Token: 0x060019B8 RID: 6584 RVA: 0x0000F754 File Offset: 0x0000F754
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060019B9 RID: 6585 RVA: 0x000CB174 File Offset: 0x000CB174
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Honda_Flash_Tools.Net.MainForm));
			try
			{
				base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			}
			catch
			{
			}
			this.lblRemappingMode = new global::System.Windows.Forms.Label();
			this.lblVersion = new global::System.Windows.Forms.Label();
			this.lblCopyright = new global::System.Windows.Forms.Label();
			this.lblRenew = new global::System.Windows.Forms.Label();
			this.lblEcuMode = new global::System.Windows.Forms.Label();
			this.pictureBoxLogo = new global::System.Windows.Forms.PictureBox();
			this.btnOk = new global::HondaMapEditorPro.Form2.RoundedButton();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBoxLogo).BeginInit();
			base.SuspendLayout();
			try
			{
				this.pictureBoxLogo.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			}
			catch
			{
			}
			this.pictureBoxLogo.Location = new global::System.Drawing.Point(12, 15);
			this.pictureBoxLogo.Size = new global::System.Drawing.Size(150, 90);
			this.pictureBoxLogo.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBoxLogo.BackColor = global::System.Drawing.Color.Transparent;
			this.pictureBoxLogo.TabStop = false;
			this.lblRemappingMode.Text = "\ud83d\udcc2 ~ XDF Map Editor Pro\r\n\ud83d\udd34 ~ Real-time Live Tracking\r\n\ud83d\udcca ~ 2D/3D Graph Viewer\r\n\ud83d\udd0d ~ BIN Compare & Diff\r\n\ud83d\udcbe ~ Hex Editor + Undo";
			this.lblRemappingMode.AutoSize = true;
			this.lblRemappingMode.ForeColor = global::HondaMapEditorPro.Form2.NeonCyan;
			this.lblRemappingMode.Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Italic);
			this.lblRemappingMode.BackColor = global::System.Drawing.Color.Transparent;
			this.lblRemappingMode.Location = new global::System.Drawing.Point(170, 15);
			this.lblVersion.Text = "Version 2.0.2.6";
			this.lblVersion.AutoSize = true;
			this.lblVersion.ForeColor = global::HondaMapEditorPro.Form2.NeonCyan;
			this.lblVersion.Font = new global::System.Drawing.Font("Segoe UI", 7.5f, global::System.Drawing.FontStyle.Italic);
			this.lblVersion.BackColor = global::System.Drawing.Color.Transparent;
			this.lblVersion.Location = new global::System.Drawing.Point(170, 70);
			this.lblCopyright.Text = "Winols-Tunerpro Editions\r\nCopyright (c) 2026";
			this.lblCopyright.AutoSize = true;
			this.lblCopyright.ForeColor = global::System.Drawing.Color.FromArgb(150, 150, 160);
			this.lblCopyright.Font = new global::System.Drawing.Font("Segoe UI", 7f, global::System.Drawing.FontStyle.Italic);
			this.lblCopyright.BackColor = global::System.Drawing.Color.Transparent;
			this.lblCopyright.Location = new global::System.Drawing.Point(170, 80);
			this.lblRenew.Text = "";
			this.lblRenew.Visible = false;
			this.lblEcuMode.Text = "";
			this.lblEcuMode.Visible = false;
			this.btnOk.Text = "OK";
			this.btnOk.ForeColor = global::HondaMapEditorPro.Form2.NeonGreen;
			this.btnOk.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Bold);
			this.btnOk.Location = new global::System.Drawing.Point(12, 125);
			this.btnOk.Size = new global::System.Drawing.Size(150, 32);
			this.btnOk.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.btnOk.Cursor = global::System.Windows.Forms.Cursors.Hand;
			global::HondaMapEditorPro.Form2.RoundedButton roundedButton;
			if ((roundedButton = (this.btnOk as global::HondaMapEditorPro.Form2.RoundedButton)) != null)
			{
				roundedButton.CornerRadius = 8;
				roundedButton.BorderColor = global::HondaMapEditorPro.Form2.NeonGreen;
				roundedButton.HoverBorderColor = global::HondaMapEditorPro.Form2.NeonCyan;
				roundedButton.NormalBackColor = global::System.Drawing.Color.FromArgb(28, 28, 32);
				roundedButton.HoverBackColor = global::System.Drawing.Color.FromArgb(40, 50, 60);
				roundedButton.BorderWidth = 2f;
				roundedButton.GlowWidth = 5f;
			}
			this.btnOk.Click += new global::System.EventHandler(this.button1_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(5f, 11f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(300, 175);
			this.BackColor = global::HondaMapEditorPro.Form2.BackPanel;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.ShowInTaskbar = false;
			this.Text = "Honda Remap Mode";
			base.Padding = new global::System.Windows.Forms.Padding(16);
			base.Controls.Add(this.btnOk);
			base.Controls.Add(this.pictureBoxLogo);
			base.Controls.Add(this.lblCopyright);
			base.Controls.Add(this.lblVersion);
			base.Controls.Add(this.lblRemappingMode);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBoxLogo).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
			checked
			{
				base.Paint += delegate(object s, global::System.Windows.Forms.PaintEventArgs e)
				{
					e.Graphics.SmoothingMode = global::System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
					e.Graphics.PixelOffsetMode = global::System.Drawing.Drawing2D.PixelOffsetMode.Half;
					int width = base.ClientSize.Width;
					int height = base.ClientSize.Height;
					using (global::System.Drawing.Pen pen = new global::System.Drawing.Pen(global::System.Drawing.Color.FromArgb(0, 255, 230), 2f))
					{
						using (global::System.Drawing.Drawing2D.GraphicsPath roundedRect = global::HondaMapEditorPro.Form2.GetRoundedRect(new global::System.Drawing.Rectangle(1, 1, width - 2, height - 2), 14))
						{
							e.Graphics.DrawPath(pen, roundedRect);
						}
					}
					using (global::System.Drawing.Pen pen2 = new global::System.Drawing.Pen(global::System.Drawing.Color.DarkCyan, 1.5f))
					{
						using (global::System.Drawing.Drawing2D.GraphicsPath roundedRect2 = global::HondaMapEditorPro.Form2.GetRoundedRect(new global::System.Drawing.Rectangle(8, 8, width - 16, height - 16), 12))
						{
							e.Graphics.DrawPath(pen2, roundedRect2);
						}
					}
				};
				base.Resize += delegate(object s, global::System.EventArgs e)
				{
					this.ApplyRoundedRegion();
					base.Invalidate();
				};
				bool dragging = false;
				global::System.Drawing.Point dragStart = global::System.Drawing.Point.Empty;
				base.MouseDown += delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
				{
					if (e.Button == global::System.Windows.Forms.MouseButtons.Left)
					{
						dragging = true;
						dragStart = e.Location;
					}
				};
				base.MouseMove += delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
				{
					if (dragging)
					{
						this.Location = new global::System.Drawing.Point(this.Location.X + e.X - dragStart.X, this.Location.Y + e.Y - dragStart.Y);
					}
				};
				base.MouseUp += delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
				{
					dragging = false;
				};
				base.KeyPreview = true;
				base.KeyDown += delegate(object s, global::System.Windows.Forms.KeyEventArgs e)
				{
					if (e.KeyCode == global::System.Windows.Forms.Keys.Escape)
					{
						base.Close();
					}
				};
				this.ApplyRoundedRegion();
			}
		}

		// Token: 0x04001FF2 RID: 8178
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04001FFC RID: 8188
		private global::System.Windows.Forms.Label lblRemappingMode;

		// Token: 0x04001FFD RID: 8189
		private global::System.Windows.Forms.Label lblVersion;

		// Token: 0x04001FFE RID: 8190
		private global::System.Windows.Forms.Label lblCopyright;

		// Token: 0x04001FFF RID: 8191
		private global::System.Windows.Forms.Label lblRenew;

		// Token: 0x04002000 RID: 8192
		private global::System.Windows.Forms.Label lblEcuMode;

		// Token: 0x04002001 RID: 8193
		private global::System.Windows.Forms.PictureBox pictureBoxLogo;

		// Token: 0x04002002 RID: 8194
		private global::System.Windows.Forms.Button btnOk;

		// Token: 0x04002003 RID: 8195
		private static readonly global::System.Drawing.Color BackPanel = global::System.Drawing.Color.FromArgb(28, 28, 32);

		// Token: 0x04002004 RID: 8196
		private static readonly global::System.Drawing.Color NeonCyan = global::System.Drawing.Color.FromArgb(0, 229, 255);

		// Token: 0x04002006 RID: 8198
		private static readonly global::System.Drawing.Color NeonGreen = global::System.Drawing.Color.FromArgb(57, 255, 20);
	}
}
