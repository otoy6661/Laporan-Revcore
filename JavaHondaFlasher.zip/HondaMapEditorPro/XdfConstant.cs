﻿using System;

namespace HondaMapEditorPro
{
	// Token: 0x020007F9 RID: 2041
	public class XdfConstant
	{
		// Token: 0x17000146 RID: 326
		// (get) Token: 0x060014D2 RID: 5330 RVA: 0x0000D431 File Offset: 0x0000D431
		// (set) Token: 0x060014D3 RID: 5331 RVA: 0x0000D439 File Offset: 0x0000D439
		public string UniqueId { get; set; } = "";

		// Token: 0x17000147 RID: 327
		// (get) Token: 0x060014D4 RID: 5332 RVA: 0x0000D442 File Offset: 0x0000D442
		// (set) Token: 0x060014D5 RID: 5333 RVA: 0x0000D44A File Offset: 0x0000D44A
		public string Title { get; set; } = "Unnamed Constant";

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x060014D6 RID: 5334 RVA: 0x0000D453 File Offset: 0x0000D453
		// (set) Token: 0x060014D7 RID: 5335 RVA: 0x0000D45B File Offset: 0x0000D45B
		public int Address { get; set; }

		// Token: 0x17000149 RID: 329
		// (get) Token: 0x060014D8 RID: 5336 RVA: 0x0000D464 File Offset: 0x0000D464
		// (set) Token: 0x060014D9 RID: 5337 RVA: 0x0000D46C File Offset: 0x0000D46C
		public int ElementSize { get; set; } = 2;

		// Token: 0x1700014A RID: 330
		// (get) Token: 0x060014DA RID: 5338 RVA: 0x0000D475 File Offset: 0x0000D475
		// (set) Token: 0x060014DB RID: 5339 RVA: 0x0000D47D File Offset: 0x0000D47D
		public bool IsSigned { get; set; }

		// Token: 0x1700014B RID: 331
		// (get) Token: 0x060014DC RID: 5340 RVA: 0x0000D486 File Offset: 0x0000D486
		// (set) Token: 0x060014DD RID: 5341 RVA: 0x0000D48E File Offset: 0x0000D48E
		public bool IsSwapped { get; set; }

		// Token: 0x1700014C RID: 332
		// (get) Token: 0x060014DE RID: 5342 RVA: 0x0000D497 File Offset: 0x0000D497
		// (set) Token: 0x060014DF RID: 5343 RVA: 0x0000D49F File Offset: 0x0000D49F
		public bool IsFloat { get; set; }

		// Token: 0x1700014D RID: 333
		// (get) Token: 0x060014E0 RID: 5344 RVA: 0x0000D4A8 File Offset: 0x0000D4A8
		// (set) Token: 0x060014E1 RID: 5345 RVA: 0x0000D4B0 File Offset: 0x0000D4B0
		public double Scale { get; set; } = 1.0;

		// Token: 0x1700014E RID: 334
		// (get) Token: 0x060014E2 RID: 5346 RVA: 0x0000D4B9 File Offset: 0x0000D4B9
		// (set) Token: 0x060014E3 RID: 5347 RVA: 0x0000D4C1 File Offset: 0x0000D4C1
		public double Offset { get; set; }

		// Token: 0x1700014F RID: 335
		// (get) Token: 0x060014E4 RID: 5348 RVA: 0x0000D4CA File Offset: 0x0000D4CA
		// (set) Token: 0x060014E5 RID: 5349 RVA: 0x0000D4D2 File Offset: 0x0000D4D2
		public string MathEquation { get; set; } = "X";

		// Token: 0x17000150 RID: 336
		// (get) Token: 0x060014E6 RID: 5350 RVA: 0x0000D4DB File Offset: 0x0000D4DB
		// (set) Token: 0x060014E7 RID: 5351 RVA: 0x0000D4E3 File Offset: 0x0000D4E3
		public string Category { get; set; } = "";

		// Token: 0x17000151 RID: 337
		// (get) Token: 0x060014E8 RID: 5352 RVA: 0x0000D4EC File Offset: 0x0000D4EC
		// (set) Token: 0x060014E9 RID: 5353 RVA: 0x0000D4F4 File Offset: 0x0000D4F4
		public string CategoryName { get; set; } = "";

		// Token: 0x060014EA RID: 5354 RVA: 0x0000D4FD File Offset: 0x0000D4FD
		public override string ToString()
		{
			return string.Format("{0} @ 0x{1:X}", this.Title, this.Address);
		}
	}
}
