﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace HondaMapEditorPro
{
	// Token: 0x020007FA RID: 2042
	public static class XdfDecryptor
	{
		// Token: 0x060014EC RID: 5356 RVA: 0x0000D51A File Offset: 0x0000D51A
		public static bool IsEncrypted(byte[] raw)
		{
			return raw != null && raw.Length >= 264 && (raw[0] == 5 && raw[1] == 34) && raw[2] == 151;
		}

		// Token: 0x060014ED RID: 5357 RVA: 0x0009BBC0 File Offset: 0x0009BBC0
		public static bool IsEncrypted(string path)
		{
			bool result;
			try
			{
				using (FileStream fileStream = File.OpenRead(path))
				{
					if (fileStream.Length < 264L)
					{
						result = false;
					}
					else
					{
						int num = fileStream.ReadByte();
						int num2 = fileStream.ReadByte();
						int num3 = fileStream.ReadByte();
						result = (num == 5 && num2 == 34 && num3 == 151);
					}
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060014EE RID: 5358 RVA: 0x0009BC3C File Offset: 0x0009BC3C
		public static XdfDecryptor.DecryptResult Decrypt(string xdfPath)
		{
			XdfDecryptor.DecryptResult decryptResult = new XdfDecryptor.DecryptResult();
			checked
			{
				XdfDecryptor.DecryptResult result;
				try
				{
					byte[] array = File.ReadAllBytes(xdfPath);
					if (!XdfDecryptor.IsEncrypted(array))
					{
						decryptResult.ErrorMessage = "File tidak terenkripsi.";
						result = decryptResult;
					}
					else if (array.Length <= 264)
					{
						decryptResult.ErrorMessage = "File terenkripsi tapi tanpa payload.";
						result = decryptResult;
					}
					else
					{
						string s = "$9Ad0$!#*)1QqPow^";
						byte[] bytes = Encoding.ASCII.GetBytes(s);
						byte[] array2 = new byte[array.Length - 264];
						Array.Copy(array, 264, array2, 0, array2.Length);
						uint num = (uint)array2.Length;
						UIntPtr zero = UIntPtr.Zero;
						UIntPtr zero2 = UIntPtr.Zero;
						UIntPtr zero3 = UIntPtr.Zero;
						bool flag = XdfDecryptor.Crypto.CryptAcquireContext(ref zero, "TunerPro", "Microsoft Enhanced Cryptographic Provider v1.0", 1U, 0U);
						if (!flag)
						{
							flag = XdfDecryptor.Crypto.CryptAcquireContext(ref zero, null, "Microsoft Enhanced RSA and AES Cryptographic Provider", 1U, 4026531840U);
						}
						if (!flag)
						{
							flag = XdfDecryptor.Crypto.CryptAcquireContext(ref zero, null, null, 1U, 4026531840U);
						}
						if (!flag)
						{
							decryptResult.ErrorMessage = "CryptAcquireContext gagal (err " + Marshal.GetLastWin32Error() + ")";
							result = decryptResult;
						}
						else
						{
							try
							{
								if (!XdfDecryptor.Crypto.CryptCreateHash(zero, 32771U, UIntPtr.Zero, 0U, ref zero2))
								{
									decryptResult.ErrorMessage = "CryptCreateHash gagal";
									return decryptResult;
								}
								try
								{
									if (!XdfDecryptor.Crypto.CryptHashData(zero2, bytes, (uint)bytes.Length, 0U))
									{
										decryptResult.ErrorMessage = "CryptHashData gagal";
										return decryptResult;
									}
									if (!XdfDecryptor.Crypto.CryptDeriveKey(zero, 26625U, zero2, 1U, ref zero3))
									{
										decryptResult.ErrorMessage = "CryptDeriveKey gagal";
										return decryptResult;
									}
									if (!XdfDecryptor.Crypto.CryptDecrypt(zero3, UIntPtr.Zero, true, 0U, array2, ref num))
									{
										decryptResult.ErrorMessage = "CryptDecrypt gagal (password/key salah)";
										return decryptResult;
									}
								}
								finally
								{
									if (zero2 != UIntPtr.Zero)
									{
										XdfDecryptor.Crypto.CryptDestroyHash(zero2);
									}
								}
							}
							finally
							{
								if (zero3 != UIntPtr.Zero)
								{
									XdfDecryptor.Crypto.CryptDestroyKey(zero3);
								}
								if (zero != UIntPtr.Zero)
								{
									XdfDecryptor.Crypto.CryptReleaseContext(zero, 0U);
								}
							}
							string text = Encoding.GetEncoding(1252).GetString(array2, 0, (int)num);
							int num2 = text.IndexOf('\0');
							if (num2 >= 0)
							{
								text = text.Substring(0, num2);
							}
							if (text.Length > 0 && text[0] == '﻿')
							{
								text = text.Substring(1);
							}
							StringBuilder stringBuilder = new StringBuilder(text.Length);
							foreach (string text2 in text.Replace("\r", "").Split(new char[]
							{
								'\n'
							}))
							{
								if (text2.Contains("<openpassword>"))
								{
									int num3 = text2.IndexOf("<openpassword>") + 14;
									int num4 = text2.IndexOf("</openpassword>");
									if (num3 >= 0 && num4 > num3)
									{
										decryptResult.OpenPassword = text2.Substring(num3, num4 - num3);
									}
								}
								else if (text2.Contains("<modifypassword>"))
								{
									int num5 = text2.IndexOf("<modifypassword>") + 16;
									int num6 = text2.IndexOf("</modifypassword>");
									if (num5 >= 0 && num6 > num5)
									{
										decryptResult.ModifyPassword = text2.Substring(num5, num6 - num5);
									}
								}
								else if (text2.Contains("<flags>0x"))
								{
									stringBuilder.Append("    <flags>0x0</flags>\r\n");
								}
								else if (!string.IsNullOrEmpty(text2))
								{
									stringBuilder.Append(text2).Append("\r\n");
								}
							}
							decryptResult.UnlockedXml = stringBuilder.ToString();
							decryptResult.Success = true;
							result = decryptResult;
						}
					}
				}
				catch (Exception ex)
				{
					decryptResult.ErrorMessage = ex.Message;
					result = decryptResult;
				}
				return result;
			}
		}

		// Token: 0x060014EF RID: 5359 RVA: 0x0009C030 File Offset: 0x0009C030
		public static string DecryptToFile(string xdfPath, string outputPath = null)
		{
			XdfDecryptor.DecryptResult decryptResult = XdfDecryptor.Decrypt(xdfPath);
			if (!decryptResult.Success)
			{
				throw new Exception("Gagal decrypt: " + decryptResult.ErrorMessage);
			}
			if (string.IsNullOrEmpty(outputPath))
			{
				string directoryName = Path.GetDirectoryName(xdfPath);
				string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(xdfPath);
				outputPath = Path.Combine(directoryName, fileNameWithoutExtension + "_unlocked.xdf");
			}
			File.WriteAllText(outputPath, decryptResult.UnlockedXml, Encoding.GetEncoding(1252));
			return outputPath;
		}

		// Token: 0x020007FB RID: 2043
		public class DecryptResult
		{
			// Token: 0x17000152 RID: 338
			// (get) Token: 0x060014F0 RID: 5360 RVA: 0x0000D544 File Offset: 0x0000D544
			// (set) Token: 0x060014F1 RID: 5361 RVA: 0x0000D54C File Offset: 0x0000D54C
			public bool Success { get; set; }

			// Token: 0x17000153 RID: 339
			// (get) Token: 0x060014F2 RID: 5362 RVA: 0x0000D555 File Offset: 0x0000D555
			// (set) Token: 0x060014F3 RID: 5363 RVA: 0x0000D55D File Offset: 0x0000D55D
			public string OpenPassword { get; set; } = "";

			// Token: 0x17000154 RID: 340
			// (get) Token: 0x060014F4 RID: 5364 RVA: 0x0000D566 File Offset: 0x0000D566
			// (set) Token: 0x060014F5 RID: 5365 RVA: 0x0000D56E File Offset: 0x0000D56E
			public string ModifyPassword { get; set; } = "";

			// Token: 0x17000155 RID: 341
			// (get) Token: 0x060014F6 RID: 5366 RVA: 0x0000D577 File Offset: 0x0000D577
			// (set) Token: 0x060014F7 RID: 5367 RVA: 0x0000D57F File Offset: 0x0000D57F
			public string UnlockedXml { get; set; } = "";

			// Token: 0x17000156 RID: 342
			// (get) Token: 0x060014F8 RID: 5368 RVA: 0x0000D588 File Offset: 0x0000D588
			// (set) Token: 0x060014F9 RID: 5369 RVA: 0x0000D590 File Offset: 0x0000D590
			public string ErrorMessage { get; set; } = "";
		}

		// Token: 0x020007FC RID: 2044
		internal static class Crypto
		{
			// Token: 0x060014FB RID: 5371
			[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
			public static extern bool CryptAcquireContext(ref UIntPtr hProv, string pszContainer, string pszProvider, uint dwProvType, uint dwFlags);

			// Token: 0x060014FC RID: 5372
			[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
			public static extern bool CryptCreateHash(UIntPtr hProv, uint Algid, UIntPtr hKey, uint dwFlags, ref UIntPtr phHash);

			// Token: 0x060014FD RID: 5373
			[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
			public static extern bool CryptHashData(UIntPtr hHash, byte[] pbData, uint dwDataLen, uint dwFlags);

			// Token: 0x060014FE RID: 5374
			[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
			public static extern bool CryptDeriveKey(UIntPtr hProv, uint Algid, UIntPtr hBaseData, uint dwFlags, ref UIntPtr phKey);

			// Token: 0x060014FF RID: 5375
			[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
			public static extern bool CryptDecrypt(UIntPtr hKey, UIntPtr hHash, bool Final, uint dwFlags, byte[] pbData, ref uint pdwDataLen);

			// Token: 0x06001500 RID: 5376
			[DllImport("advapi32.dll", SetLastError = true)]
			public static extern bool CryptDestroyHash(UIntPtr hHash);

			// Token: 0x06001501 RID: 5377
			[DllImport("advapi32.dll", SetLastError = true)]
			public static extern bool CryptDestroyKey(UIntPtr hKey);

			// Token: 0x06001502 RID: 5378
			[DllImport("advapi32.dll", SetLastError = true)]
			public static extern bool CryptReleaseContext(UIntPtr hProv, uint dwFlags);
		}
	}
}
