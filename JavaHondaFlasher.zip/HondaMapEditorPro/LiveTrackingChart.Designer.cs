﻿namespace HondaMapEditorPro
{
	// Token: 0x0200095E RID: 2398
	public partial class LiveTrackingChart : global::System.Windows.Forms.Form
	{
		// Token: 0x06001A42 RID: 6722 RVA: 0x000CDEA4 File Offset: 0x000CDEA4
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				global::System.Drawing.Font fontAxis = this._fontAxis;
				if (fontAxis != null)
				{
					fontAxis.Dispose();
				}
				global::System.Drawing.Font fontLegend = this._fontLegend;
				if (fontLegend != null)
				{
					fontLegend.Dispose();
				}
				global::System.Drawing.Font fontHover = this._fontHover;
				if (fontHover != null)
				{
					fontHover.Dispose();
				}
				global::System.Drawing.Font fontHoverBig = this._fontHoverBig;
				if (fontHoverBig != null)
				{
					fontHoverBig.Dispose();
				}
				global::System.Drawing.Font fontEmpty = this._fontEmpty;
				if (fontEmpty != null)
				{
					fontEmpty.Dispose();
				}
				global::System.Drawing.Font fontTitle = this._fontTitle;
				if (fontTitle != null)
				{
					fontTitle.Dispose();
				}
				global::System.Drawing.Pen gridPen = this._gridPen;
				if (gridPen != null)
				{
					gridPen.Dispose();
				}
				global::System.Drawing.Pen gridPenMajor = this._gridPenMajor;
				if (gridPenMajor != null)
				{
					gridPenMajor.Dispose();
				}
				global::System.Drawing.Pen borderPen = this._borderPen;
				if (borderPen != null)
				{
					borderPen.Dispose();
				}
				global::System.Drawing.Pen cursorPen = this._cursorPen;
				if (cursorPen != null)
				{
					cursorPen.Dispose();
				}
				global::System.Drawing.SolidBrush rpmBrush = this._rpmBrush;
				if (rpmBrush != null)
				{
					rpmBrush.Dispose();
				}
				global::System.Drawing.SolidBrush tpsBrush = this._tpsBrush;
				if (tpsBrush != null)
				{
					tpsBrush.Dispose();
				}
				global::System.Drawing.SolidBrush afrBrush = this._afrBrush;
				if (afrBrush != null)
				{
					afrBrush.Dispose();
				}
				global::System.Drawing.SolidBrush adBrush = this._adBrush;
				if (adBrush != null)
				{
					adBrush.Dispose();
				}
				global::System.Drawing.SolidBrush mutedBrush = this._mutedBrush;
				if (mutedBrush != null)
				{
					mutedBrush.Dispose();
				}
				global::System.Drawing.SolidBrush fgBrush = this._fgBrush;
				if (fgBrush != null)
				{
					fgBrush.Dispose();
				}
				global::System.Drawing.SolidBrush panelBrush = this._panelBrush;
				if (panelBrush != null)
				{
					panelBrush.Dispose();
				}
				global::System.Drawing.SolidBrush hoverBgBrush = this._hoverBgBrush;
				if (hoverBgBrush != null)
				{
					hoverBgBrush.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		// Token: 0x040020F6 RID: 8438
		private global::System.Drawing.Font _fontAxis;

		// Token: 0x040020F7 RID: 8439
		private global::System.Drawing.Font _fontLegend;

		// Token: 0x040020F8 RID: 8440
		private global::System.Drawing.Font _fontHover;

		// Token: 0x040020F9 RID: 8441
		private global::System.Drawing.Font _fontHoverBig;

		// Token: 0x040020FA RID: 8442
		private global::System.Drawing.Font _fontEmpty;

		// Token: 0x040020FB RID: 8443
		private global::System.Drawing.Pen _gridPen;

		// Token: 0x040020FC RID: 8444
		private global::System.Drawing.Pen _gridPenMajor;

		// Token: 0x040020FD RID: 8445
		private global::System.Drawing.Pen _borderPen;

		// Token: 0x040020FE RID: 8446
		private global::System.Drawing.Pen _cursorPen;

		// Token: 0x040020FF RID: 8447
		private global::System.Drawing.SolidBrush _rpmBrush;

		// Token: 0x04002100 RID: 8448
		private global::System.Drawing.SolidBrush _tpsBrush;

		// Token: 0x04002101 RID: 8449
		private global::System.Drawing.SolidBrush _afrBrush;

		// Token: 0x04002102 RID: 8450
		private global::System.Drawing.SolidBrush _adBrush;

		// Token: 0x04002103 RID: 8451
		private global::System.Drawing.SolidBrush _mutedBrush;

		// Token: 0x04002104 RID: 8452
		private global::System.Drawing.SolidBrush _fgBrush;

		// Token: 0x04002105 RID: 8453
		private global::System.Drawing.SolidBrush _panelBrush;

		// Token: 0x04002106 RID: 8454
		private global::System.Drawing.SolidBrush _hoverBgBrush;

		// Token: 0x04002111 RID: 8465
		private global::System.Drawing.Font _fontTitle;
	}
}
