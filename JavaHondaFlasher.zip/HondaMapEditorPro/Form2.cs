﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;
using Honda_Flash_Tools.Net;

namespace HondaMapEditorPro
{
	// Token: 0x020008FC RID: 2300
	public partial class Form2 : Form
	{
		// Token: 0x060019B6 RID: 6582 RVA: 0x0000F739 File Offset: 0x0000F739
		public Form2()
		{
			this.InitializeComponent();
			this.Create3DLabels();
		}

		// Token: 0x060019B7 RID: 6583 RVA: 0x0000282D File Offset: 0x0000282D
		private void button1_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		// Token: 0x060019BB RID: 6587 RVA: 0x000CB730 File Offset: 0x000CB730
		private void ColorTimer_Tick(object sender, EventArgs e)
		{
			this.hue = checked(this.hue + 1) % 360;
			Color backColor = this.HsvToRgb((double)this.hue, 0.9, 0.3);
			this.BackColor = backColor;
			this.ForeColor = Color.White;
			base.Invalidate();
		}

		// Token: 0x060019BC RID: 6588 RVA: 0x0000F773 File Offset: 0x0000F773
		protected override void OnFormClosing(FormClosingEventArgs e)
		{
			if (this.colorTimer != null)
			{
				this.colorTimer.Stop();
				this.colorTimer.Dispose();
			}
			base.OnFormClosing(e);
		}

		// Token: 0x060019BD RID: 6589 RVA: 0x0006800C File Offset: 0x0006800C
		private Color HsvToRgb(double h, double s, double v)
		{
			double num = v * s;
			double num2 = num * (1.0 - Math.Abs(h / 60.0 % 2.0 - 1.0));
			double num3 = v - num;
			double num4 = 0.0;
			double num5 = 0.0;
			double num6 = 0.0;
			if (h >= 0.0 && h < 60.0)
			{
				num4 = num;
				num5 = num2;
				num6 = 0.0;
			}
			else if (h >= 60.0 && h < 120.0)
			{
				num4 = num2;
				num5 = num;
				num6 = 0.0;
			}
			else if (h >= 120.0 && h < 180.0)
			{
				num4 = 0.0;
				num5 = num;
				num6 = num2;
			}
			else if (h >= 180.0 && h < 240.0)
			{
				num4 = 0.0;
				num5 = num2;
				num6 = num;
			}
			else if (h >= 240.0 && h < 300.0)
			{
				num4 = num2;
				num5 = 0.0;
				num6 = num;
			}
			else if (h >= 300.0 && h < 360.0)
			{
				num4 = num;
				num5 = 0.0;
				num6 = num2;
			}
			return checked(Color.FromArgb((int)(unchecked((num4 + num3) * 255.0)), (int)(unchecked((num5 + num3) * 255.0)), (int)(unchecked((num6 + num3) * 255.0))));
		}

		// Token: 0x060019BE RID: 6590 RVA: 0x000681A4 File Offset: 0x000681A4
		private Icon CreateDefaultIcon()
		{
			Bitmap bitmap = new Bitmap(32, 32);
			using (Graphics graphics = Graphics.FromImage(bitmap))
			{
				graphics.Clear(Color.Transparent);
				using (Brush brush = new SolidBrush(Color.Gold))
				{
					graphics.FillRectangle(brush, 4, 4, 24, 24);
				}
				using (Font font = new Font("Arial", 16f, FontStyle.Bold))
				{
					using (Brush brush2 = new SolidBrush(Color.Blue))
					{
						graphics.DrawString("H", font, brush2, 8f, 4f);
					}
				}
			}
			return Icon.FromHandle(bitmap.GetHicon());
		}

		// Token: 0x060019BF RID: 6591 RVA: 0x000CB78C File Offset: 0x000CB78C
		private void Create3DLabels()
		{
			Font font = new Font("Impact", 13f, FontStyle.Italic);
			this.lblRenew = new HondaMapEditorPro.Form2.Label3D
			{
				Text = "DEPPLOY MAP TUNING",
				Font = font,
				ForeColor = SystemColors.ButtonShadow,
				ShadowColor = Color.Cyan,
				ShadowOffsetX = 2,
				ShadowOffsetY = 2,
				Depth = 4,
				BackColor = Color.Transparent,
				AutoSize = true,
				Location = new Point(199, 141),
				Anchor = (AnchorStyles.Bottom | AnchorStyles.Right)
			};
			checked
			{
				this.lblRenew.Paint += delegate(object sender, PaintEventArgs e)
				{
					Control control = sender as Control;
					if (control != null)
					{
						e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
						using (Pen pen = new Pen(Color.FromArgb(100, Color.Gold), 3f))
						{
							e.Graphics.DrawRectangle(pen, new Rectangle(0, 0, control.Width - 1, control.Height - 1));
						}
						using (Pen pen2 = new Pen(Color.Gold, 2f))
						{
							e.Graphics.DrawRectangle(pen2, new Rectangle(2, 2, control.Width - 5, control.Height - 5));
						}
					}
				};
				this.lblEcuMode = new HondaMapEditorPro.Form2.Label3D
				{
					Text = "MAP EDITOR PRO",
					Font = font,
					ForeColor = HondaMapEditorPro.Form2.NeonGreen,
					ShadowColor = Color.Cyan,
					ShadowOffsetX = 2,
					ShadowOffsetY = 2,
					Depth = 4,
					BackColor = Color.Transparent,
					AutoSize = true,
					Location = new Point(199, 161),
					Anchor = (AnchorStyles.Bottom | AnchorStyles.Right)
				};
				this.lblEcuMode.Paint += delegate(object sender, PaintEventArgs e)
				{
					Control control = sender as Control;
					if (control != null)
					{
						e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
						using (Pen pen = new Pen(Color.FromArgb(100, HondaMapEditorPro.Form2.NeonMagenta), 3f))
						{
							e.Graphics.DrawRectangle(pen, new Rectangle(0, 0, control.Width - 1, control.Height - 1));
						}
						using (Pen pen2 = new Pen(HondaMapEditorPro.Form2.NeonMagenta, 2f))
						{
							e.Graphics.DrawRectangle(pen2, new Rectangle(2, 2, control.Width - 5, control.Height - 5));
						}
					}
				};
				base.Controls.Add(this.lblRenew);
				base.Controls.Add(this.lblEcuMode);
			}
		}

		// Token: 0x060019C0 RID: 6592 RVA: 0x000CB910 File Offset: 0x000CB910
		private void ApplyRoundedRegion()
		{
			using (GraphicsPath roundedRect = HondaMapEditorPro.Form2.GetRoundedRect(checked(new Rectangle(0, 0, base.Width - 1, base.Height - 1)), 14))
			{
				base.Region = new Region(roundedRect);
			}
		}

		// Token: 0x060019C1 RID: 6593 RVA: 0x000CB964 File Offset: 0x000CB964
		private static GraphicsPath GetRoundedRect(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			checked
			{
				int num = radius * 2;
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x04001FF3 RID: 8179
		private PictureBox pictureBox1;

		// Token: 0x04001FF4 RID: 8180
		private Label label1;

		// Token: 0x04001FF5 RID: 8181
		private Label label2;

		// Token: 0x04001FF6 RID: 8182
		private Label label3;

		// Token: 0x04001FF7 RID: 8183
		private Button button1;

		// Token: 0x04001FF8 RID: 8184
		private Timer colorTimer;

		// Token: 0x04001FF9 RID: 8185
		private int colorStep;

		// Token: 0x04001FFA RID: 8186
		private int direction = 1;

		// Token: 0x04001FFB RID: 8187
		private int hue;

		// Token: 0x04002005 RID: 8197
		private static readonly Color NeonMagenta = Color.FromArgb(255, 0, 200);

		// Token: 0x04002007 RID: 8199
		private static readonly Color ForeColorDefault = Color.FromArgb(235, 235, 240);

		// Token: 0x04002008 RID: 8200
		private static readonly Color ForeMuted = Color.FromArgb(150, 150, 160);

		// Token: 0x04002009 RID: 8201
		private TableLayoutPanel rootLayout;

		// Token: 0x0400200A RID: 8202
		private TableLayoutPanel infoLayout;

		// Token: 0x0400200B RID: 8203
		private TableLayoutPanel mainLayout;

		// Token: 0x020008FD RID: 2301
		public class Label3D : Label
		{
			// Token: 0x1700018A RID: 394
			// (get) Token: 0x060019C8 RID: 6600 RVA: 0x0000F7A8 File Offset: 0x0000F7A8
			// (set) Token: 0x060019C9 RID: 6601 RVA: 0x0000F7B0 File Offset: 0x0000F7B0
			public Color ShadowColor { get; set; } = Color.Black;

			// Token: 0x1700018B RID: 395
			// (get) Token: 0x060019CA RID: 6602 RVA: 0x0000F7B9 File Offset: 0x0000F7B9
			// (set) Token: 0x060019CB RID: 6603 RVA: 0x0000F7C1 File Offset: 0x0000F7C1
			public int ShadowOffsetX { get; set; } = 2;

			// Token: 0x1700018C RID: 396
			// (get) Token: 0x060019CC RID: 6604 RVA: 0x0000F7CA File Offset: 0x0000F7CA
			// (set) Token: 0x060019CD RID: 6605 RVA: 0x0000F7D2 File Offset: 0x0000F7D2
			public int ShadowOffsetY { get; set; } = 2;

			// Token: 0x1700018D RID: 397
			// (get) Token: 0x060019CE RID: 6606 RVA: 0x0000F7DB File Offset: 0x0000F7DB
			// (set) Token: 0x060019CF RID: 6607 RVA: 0x0000F7E3 File Offset: 0x0000F7E3
			public int Depth { get; set; } = 3;

			// Token: 0x060019D0 RID: 6608 RVA: 0x000CBB28 File Offset: 0x000CBB28
			protected override void OnPaint(PaintEventArgs e)
			{
				checked
				{
					for (int i = 1; i <= this.Depth; i++)
					{
						using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(100 / i, this.ShadowColor)))
						{
							e.Graphics.DrawString(this.Text, this.Font, solidBrush, (float)(this.ShadowOffsetX * i), (float)(this.ShadowOffsetY * i));
						}
					}
					using (SolidBrush solidBrush2 = new SolidBrush(this.ForeColor))
					{
						e.Graphics.DrawString(this.Text, this.Font, solidBrush2, 0f, 0f);
					}
				}
			}
		}

		// Token: 0x02000900 RID: 2304
		public class RoundedButton : Button
		{
			// Token: 0x1700018E RID: 398
			// (get) Token: 0x060019DA RID: 6618 RVA: 0x0000F84B File Offset: 0x0000F84B
			// (set) Token: 0x060019DB RID: 6619 RVA: 0x0000F853 File Offset: 0x0000F853
			[Category("Appearance")]
			public int CornerRadius
			{
				get
				{
					return this._cornerRadius;
				}
				set
				{
					this._cornerRadius = Math.Max(0, value);
					base.Invalidate();
				}
			}

			// Token: 0x1700018F RID: 399
			// (get) Token: 0x060019DC RID: 6620 RVA: 0x0000F868 File Offset: 0x0000F868
			// (set) Token: 0x060019DD RID: 6621 RVA: 0x0000F870 File Offset: 0x0000F870
			[Category("Appearance")]
			public Color BorderColor
			{
				get
				{
					return this._borderColor;
				}
				set
				{
					this._borderColor = value;
					base.Invalidate();
				}
			}

			// Token: 0x17000190 RID: 400
			// (get) Token: 0x060019DE RID: 6622 RVA: 0x0000F87F File Offset: 0x0000F87F
			// (set) Token: 0x060019DF RID: 6623 RVA: 0x0000F887 File Offset: 0x0000F887
			[Category("Appearance")]
			public Color HoverBorderColor
			{
				get
				{
					return this._hoverBorderColor;
				}
				set
				{
					this._hoverBorderColor = value;
					base.Invalidate();
				}
			}

			// Token: 0x17000191 RID: 401
			// (get) Token: 0x060019E0 RID: 6624 RVA: 0x0000F896 File Offset: 0x0000F896
			// (set) Token: 0x060019E1 RID: 6625 RVA: 0x0000F89E File Offset: 0x0000F89E
			[Category("Appearance")]
			public Color NormalBackColor
			{
				get
				{
					return this._normalBackColor;
				}
				set
				{
					this._normalBackColor = value;
					base.Invalidate();
				}
			}

			// Token: 0x17000192 RID: 402
			// (get) Token: 0x060019E2 RID: 6626 RVA: 0x0000F8AD File Offset: 0x0000F8AD
			// (set) Token: 0x060019E3 RID: 6627 RVA: 0x0000F8B5 File Offset: 0x0000F8B5
			[Category("Appearance")]
			public Color HoverBackColor
			{
				get
				{
					return this._hoverBackColor;
				}
				set
				{
					this._hoverBackColor = value;
					base.Invalidate();
				}
			}

			// Token: 0x17000193 RID: 403
			// (get) Token: 0x060019E4 RID: 6628 RVA: 0x0000F8C4 File Offset: 0x0000F8C4
			// (set) Token: 0x060019E5 RID: 6629 RVA: 0x0000F8CC File Offset: 0x0000F8CC
			[Category("Appearance")]
			public float BorderWidth
			{
				get
				{
					return this._borderWidth;
				}
				set
				{
					this._borderWidth = Math.Max(0.5f, value);
					base.Invalidate();
				}
			}

			// Token: 0x17000194 RID: 404
			// (get) Token: 0x060019E6 RID: 6630 RVA: 0x0000F8E5 File Offset: 0x0000F8E5
			// (set) Token: 0x060019E7 RID: 6631 RVA: 0x0000F8ED File Offset: 0x0000F8ED
			[Category("Appearance")]
			public float GlowWidth
			{
				get
				{
					return this._glowWidth;
				}
				set
				{
					this._glowWidth = Math.Max(1f, value);
					base.Invalidate();
				}
			}

			// Token: 0x060019E8 RID: 6632 RVA: 0x000CBD24 File Offset: 0x000CBD24
			public RoundedButton()
			{
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
				this.BackColor = this._normalBackColor;
				this.ForeColor = this._borderColor;
				base.FlatStyle = FlatStyle.Flat;
				base.FlatAppearance.BorderSize = 0;
				this.Cursor = Cursors.Hand;
				base.UseVisualStyleBackColor = false;
			}

			// Token: 0x060019E9 RID: 6633 RVA: 0x0000F906 File Offset: 0x0000F906
			protected override void OnMouseEnter(EventArgs e)
			{
				this._isHover = true;
				base.Invalidate();
				base.OnMouseEnter(e);
			}

			// Token: 0x060019EA RID: 6634 RVA: 0x0000F91C File Offset: 0x0000F91C
			protected override void OnMouseLeave(EventArgs e)
			{
				this._isHover = false;
				base.Invalidate();
				base.OnMouseLeave(e);
			}

			// Token: 0x060019EB RID: 6635 RVA: 0x000CBDEC File Offset: 0x000CBDEC
			protected override void OnPaint(PaintEventArgs e)
			{
				Graphics graphics = e.Graphics;
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
				graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
				Rectangle rect = checked(new Rectangle(0, 0, base.Width - 1, base.Height - 1));
				using (GraphicsPath roundedRect = HondaMapEditorPro.Form2.RoundedButton.GetRoundedRect(rect, this._cornerRadius))
				{
					using (SolidBrush solidBrush = new SolidBrush(this._isHover ? this._hoverBackColor : this._normalBackColor))
					{
						graphics.FillPath(solidBrush, roundedRect);
					}
				}
				if (this._isHover)
				{
					using (GraphicsPath roundedRect2 = HondaMapEditorPro.Form2.RoundedButton.GetRoundedRect(rect, this._cornerRadius))
					{
						using (Pen pen = new Pen(Color.FromArgb(80, this._hoverBorderColor), this._glowWidth))
						{
							pen.LineJoin = LineJoin.Round;
							graphics.DrawPath(pen, roundedRect2);
						}
						using (Pen pen2 = new Pen(Color.FromArgb(150, this._hoverBorderColor), this._glowWidth * 0.6f))
						{
							pen2.LineJoin = LineJoin.Round;
							graphics.DrawPath(pen2, roundedRect2);
						}
					}
				}
				using (GraphicsPath roundedRect3 = HondaMapEditorPro.Form2.RoundedButton.GetRoundedRect(rect, this._cornerRadius))
				{
					using (Pen pen3 = new Pen(this._isHover ? this._hoverBorderColor : this._borderColor, this._borderWidth))
					{
						pen3.LineJoin = LineJoin.Round;
						pen3.Alignment = PenAlignment.Inset;
						graphics.DrawPath(pen3, roundedRect3);
					}
				}
				TextRenderer.DrawText(graphics, this.Text, this.Font, base.ClientRectangle, this.ForeColor, TextFormatFlags.EndEllipsis | TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			}

			// Token: 0x060019EC RID: 6636 RVA: 0x000CBFF8 File Offset: 0x000CBFF8
			private static GraphicsPath GetRoundedRect(Rectangle rect, int radius)
			{
				GraphicsPath graphicsPath = new GraphicsPath();
				if (radius <= 0)
				{
					graphicsPath.AddRectangle(rect);
					return graphicsPath;
				}
				checked
				{
					int num = radius * 2;
					if (num > rect.Width)
					{
						num = rect.Width;
					}
					if (num > rect.Height)
					{
						num = rect.Height;
					}
					graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
					graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
					graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
					graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
					graphicsPath.CloseFigure();
					return graphicsPath;
				}
			}

			// Token: 0x04002016 RID: 8214
			private int _cornerRadius = 10;

			// Token: 0x04002017 RID: 8215
			private Color _borderColor = Color.FromArgb(0, 255, 230);

			// Token: 0x04002018 RID: 8216
			private Color _hoverBorderColor = Color.FromArgb(255, 0, 200);

			// Token: 0x04002019 RID: 8217
			private Color _normalBackColor = Color.FromArgb(28, 28, 32);

			// Token: 0x0400201A RID: 8218
			private Color _hoverBackColor = Color.FromArgb(40, 40, 48);

			// Token: 0x0400201B RID: 8219
			private float _borderWidth = 2f;

			// Token: 0x0400201C RID: 8220
			private float _glowWidth = 5f;

			// Token: 0x0400201D RID: 8221
			private bool _isHover;
		}
	}
}
