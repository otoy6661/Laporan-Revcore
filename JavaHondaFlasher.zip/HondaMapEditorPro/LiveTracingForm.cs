﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using Honda_Flash_Tools.Net;
using Plot3D;

namespace HondaMapEditorPro
{
	// Token: 0x020009D1 RID: 2513
	public sealed partial class LiveTracingForm : Form
	{
		// Token: 0x06001B39 RID: 6969 RVA: 0x00010426 File Offset: 0x00010426
		public LiveTracingForm(DataGridView sourceGrid, ILiveFrameProvider frameProvider, LiveTracingOptions options) : this(sourceGrid, null, frameProvider, options)
		{
		}

		// Token: 0x06001B3A RID: 6970 RVA: 0x000D1E64 File Offset: 0x000D1E64
		private void InitializeUi()
		{
			this.Text = "\ud83d\udccb LIVE GRID TRACING";
			base.Size = new Size(1330, 710);
			base.StartPosition = FormStartPosition.CenterScreen;
			this.BackColor = this._options.BgDark;
			this.ForeColor = this._options.Fg;
			base.FormBorderStyle = FormBorderStyle.None;
			base.Padding = new Padding(4);
			this.DoubleBuffered = true;
			base.Paint += this.OnFormPaint;
			TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
			{
				Dock = DockStyle.Fill,
				ColumnCount = 1,
				RowCount = 4,
				Margin = new Padding(0),
				Padding = new Padding(0),
				BackColor = this._options.BgDark
			};
			tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 45f));
			tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 45f));
			tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
			tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 28f));
			Panel panel = this.BuildHeaderPanel();
			Panel control = this.BuildHistoryTableMenu();
			Panel control2 = this.BuildContentPanel();
			Panel control3 = this.BuildFooterPanel();
			tableLayoutPanel.Controls.Add(panel, 0, 0);
			tableLayoutPanel.Controls.Add(control, 0, 1);
			tableLayoutPanel.Controls.Add(control2, 0, 2);
			tableLayoutPanel.Controls.Add(control3, 0, 3);
			base.Controls.Add(tableLayoutPanel);
			panel.MouseDown += this.OnHeaderMouseDown;
			panel.MouseMove += this.OnHeaderMouseMove;
			panel.MouseUp += this.OnHeaderMouseUp;
			this._traceTimer = new Timer
			{
				Interval = 50
			};
			this._traceTimer.Tick += this.OnTraceTick;
			this._traceTimer.Start();
			base.FormClosed += this.OnFormClosed;
		}

		// Token: 0x06001B3B RID: 6971 RVA: 0x000D2068 File Offset: 0x000D2068
		private Panel BuildHeaderPanel()
		{
			Panel panel = new Panel
			{
				Dock = DockStyle.Fill,
				BackColor = this._options.BgPanel
			};
			Panel panel2 = new Panel
			{
				Dock = DockStyle.Left,
				Width = 160,
				BackColor = this._options.BgPanel,
				Padding = new Padding(0)
			};
			PictureBox pictureBox = new PictureBox
			{
				Name = "picLogo",
				BackColor = Color.Transparent,
				SizeMode = PictureBoxSizeMode.Zoom,
				Location = new Point(4, 0),
				Size = new Size(160, 35),
				TabStop = false,
				Cursor = Cursors.Default
			};
			Image image = null;
			try
			{
				image = (new ComponentResourceManager(typeof(Honda_Flash_Tools.Net.FormMain)).GetObject("pictureBox1.Image") as Image);
			}
			catch
			{
			}
			if (image == null)
			{
				try
				{
					string text = Path.Combine(Application.StartupPath, "logo.png");
					if (File.Exists(text))
					{
						image = Image.FromFile(text);
					}
				}
				catch
				{
				}
			}
			if (image == null)
			{
				image = SystemIcons.Application.ToBitmap();
			}
			pictureBox.Image = image;
			panel2.Controls.Add(pictureBox);
			Label value = new Label
			{
				Text = "\ud83d\udccb LIVE TRACING HISTORY",
				Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
				ForeColor = this._options.Cyan,
				Dock = DockStyle.Fill,
				TextAlign = ContentAlignment.MiddleLeft,
				Padding = new Padding(8, 0, 0, 0),
				BackColor = Color.Transparent
			};
			Label label = new Label
			{
				Text = "● OFFLINE",
				Font = new Font("Consolas", 9f, FontStyle.Bold),
				ForeColor = this._options.Gold,
				Dock = DockStyle.Right,
				Width = 420,
				TextAlign = ContentAlignment.MiddleRight,
				Padding = new Padding(0, 0, 10, 0),
				BackColor = Color.Transparent
			};
			this._lblLiveInfo = label;
			Button button = this._options.CreateWindowButton("✕", this._options.Danger, Color.FromArgb(140, 35, 50));
			button.Dock = DockStyle.Right;
			button.Width = 44;
			button.Click += delegate(object s, EventArgs e)
			{
				base.Close();
			};
			panel.Controls.Add(value);
			panel.Controls.Add(label);
			panel.Controls.Add(button);
			panel.Controls.Add(panel2);
			return panel;
		}

		// Token: 0x06001B3C RID: 6972 RVA: 0x000D230C File Offset: 0x000D230C
		private Panel BuildContentPanel()
		{
			Panel panel = new Panel();
			panel.Dock = DockStyle.Fill;
			panel.BackColor = this._options.BgDark;
			panel.Padding = new Padding(6);
			Panel panel2 = new Panel
			{
				Dock = DockStyle.Top,
				Height = 40,
				BackColor = this._options.BgCard
			};
			this._lblMapTitle = new Label
			{
				Text = "\ud83d\uddfa  " + this._currentTableName + " — 2D MAP TABLE (LIVE TRACE)",
				Font = new Font("Segoe UI", 12f, FontStyle.Bold),
				ForeColor = this._options.Cyan,
				Location = new Point(14, 6),
				AutoSize = true,
				BackColor = Color.Transparent
			};
			panel2.Controls.Add(this._lblMapTitle);
			this._xRuler = new Panel
			{
				Dock = DockStyle.Top,
				Height = 26,
				BackColor = this._options.BgPanel
			};
			this._yRuler = new Panel
			{
				Dock = DockStyle.Left,
				Width = 46,
				BackColor = this._options.BgPanel
			};
			Panel panel3 = new Panel
			{
				Dock = DockStyle.Fill
			};
			this._replicaGrid = this.BuildReplicaGrid();
			this.PopulateReplicaGrid();
			this._replicaGrid.CellPainting += this.OnCellPainting;
			this._replicaGrid.Scroll += delegate(object s, ScrollEventArgs e)
			{
				this._xRuler.Invalidate();
				this._yRuler.Invalidate();
			};
			this._xRuler.Paint += this.OnXRulerPaint;
			this._yRuler.Paint += this.OnYRulerPaint;
			panel3.Controls.Add(this._replicaGrid);
			panel3.Controls.Add(this._yRuler);
			panel.Controls.Add(panel3);
			panel.Controls.Add(this._xRuler);
			panel.Controls.Add(panel2);
			return panel;
		}

		// Token: 0x06001B3D RID: 6973 RVA: 0x000D2504 File Offset: 0x000D2504
		private Panel BuildFooterPanel()
		{
			Panel panel = new Panel();
			panel.Dock = DockStyle.Fill;
			panel.BackColor = this._options.BgPanel;
			Label value = new Label
			{
				Text = "LIVE TRACE — Cell kosong. Jejak berwarna sesuai nilai. Cell aktif border merah. Centang Graph untuk tampilkan 3D.",
				Font = new Font("Consolas", 8f),
				ForeColor = this._options.Muted,
				Dock = DockStyle.Fill,
				TextAlign = ContentAlignment.MiddleLeft,
				Padding = new Padding(12, 0, 0, 0)
			};
			panel.Controls.Add(value);
			return panel;
		}

		// Token: 0x06001B3E RID: 6974 RVA: 0x000D2590 File Offset: 0x000D2590
		private DataGridView BuildReplicaGrid()
		{
			DataGridView dataGridView = new DataGridView
			{
				Dock = DockStyle.Fill,
				BackgroundColor = this._options.BgCard,
				BorderStyle = BorderStyle.None,
				GridColor = this._options.Border,
				EnableHeadersVisualStyles = false,
				AllowUserToAddRows = false,
				AllowUserToDeleteRows = false,
				SelectionMode = DataGridViewSelectionMode.CellSelect,
				ReadOnly = true,
				EditMode = DataGridViewEditMode.EditProgrammatically,
				ColumnHeadersVisible = true,
				RowHeadersVisible = true,
				ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize,
				RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders,
				CellBorderStyle = DataGridViewCellBorderStyle.Single,
				ScrollBars = ScrollBars.Both,
				Margin = new Padding(0),
				RowTemplate = 
				{
					Height = 24
				},
				DefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = this._options.BgCard,
					ForeColor = Color.Black,
					SelectionBackColor = Color.White,
					SelectionForeColor = Color.Black,
					Alignment = DataGridViewContentAlignment.MiddleCenter,
					Font = new Font("Consolas", 8f)
				},
				ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = Color.FromArgb(0, 55, 57),
					ForeColor = this._options.Cyan,
					SelectionBackColor = Color.FromArgb(0, 75, 75),
					SelectionForeColor = this._options.Cyan,
					Alignment = DataGridViewContentAlignment.MiddleCenter,
					Font = new Font("Segoe UI", 7.5f, FontStyle.Bold),
					WrapMode = DataGridViewTriState.True
				},
				RowHeadersDefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = Color.FromArgb(23, 34, 45),
					ForeColor = this._options.Muted,
					SelectionBackColor = Color.FromArgb(0, 75, 75),
					SelectionForeColor = this._options.Cyan,
					Alignment = DataGridViewContentAlignment.MiddleCenter,
					Font = new Font("Segoe UI", 7.5f, FontStyle.Bold)
				},
				AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = Color.FromArgb(23, 32, 43),
					ForeColor = this._options.Fg
				}
			};
			try
			{
				typeof(DataGridView).InvokeMember("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.SetProperty, null, dataGridView, new object[]
				{
					true
				});
			}
			catch
			{
			}
			return dataGridView;
		}

		// Token: 0x06001B3F RID: 6975 RVA: 0x000D27E8 File Offset: 0x000D27E8
		private void PopulateReplicaGrid()
		{
			DataGridView dataGridView = this._activeSourceGrid ?? this._sourceGrid;
			int count = dataGridView.Columns.Count;
			int count2 = dataGridView.Rows.Count;
			checked
			{
				for (int i = 0; i < count; i++)
				{
					this._replicaGrid.Columns.Add(new DataGridViewTextBoxColumn
					{
						HeaderText = dataGridView.Columns[i].HeaderText,
						Name = dataGridView.Columns[i].Name,
						Width = dataGridView.Columns[i].Width
					});
				}
				double num = unchecked(this._options.MaxValue - this._options.MinValue);
				if (num <= 0.0)
				{
					num = 1.0;
				}
				for (int j = 0; j < count2; j++)
				{
					int index = this._replicaGrid.Rows.Add();
					this._replicaGrid.Rows[index].Height = dataGridView.Rows[j].Height;
					object value = dataGridView.Rows[j].HeaderCell.Value;
					this._replicaGrid.Rows[index].HeaderCell.Value = (value ?? "");
					for (int k = 0; k < count; k++)
					{
						DataGridViewCell dataGridViewCell = dataGridView[k, j];
						DataGridViewCell dataGridViewCell2 = this._replicaGrid.Rows[index].Cells[k];
						dataGridViewCell2.Value = null;
						Color fill = this._options.BgCard;
						object value2 = dataGridViewCell.Value;
						double num2;
						if (value2 != null && double.TryParse(value2.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out num2))
						{
							float arg = (float)(unchecked(num2 - this._options.MinValue) / num);
							try
							{
								fill = this._options.ColorFromProportion(arg);
							}
							catch
							{
							}
						}
						dataGridViewCell2.Tag = new LiveTracingForm.ReplicaCellTag
						{
							Fill = fill,
							RawValue = value2
						};
						dataGridViewCell2.Style.ForeColor = Color.Black;
						dataGridViewCell2.Style.Font = (dataGridViewCell.Style.Font ?? this._replicaGrid.DefaultCellStyle.Font);
					}
				}
			}
		}

		// Token: 0x06001B40 RID: 6976 RVA: 0x000D2A60 File Offset: 0x000D2A60
		private void OnFormPaint(object sender, PaintEventArgs e)
		{
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			try
			{
				using (GraphicsPath graphicsPath = this._options.CreateRoundedRect(checked(new Rectangle(1, 1, base.Width - 3, base.Height - 3)), 12))
				{
					using (Pen pen = new Pen(this._options.Cyan, 2f))
					{
						e.Graphics.DrawPath(pen, graphicsPath);
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06001B41 RID: 6977 RVA: 0x000D2B0C File Offset: 0x000D2B0C
		private void OnCellPainting(object sender, DataGridViewCellPaintingEventArgs e)
		{
			if (e.RowIndex < 0 || e.ColumnIndex < 0)
			{
				return;
			}
			DataGridViewCell dataGridViewCell = this._replicaGrid.Rows[e.RowIndex].Cells[e.ColumnIndex];
			LiveTracingForm.ReplicaCellTag replicaCellTag = dataGridViewCell.Tag as LiveTracingForm.ReplicaCellTag;
			Color color;
			object obj;
			if (replicaCellTag != null)
			{
				color = replicaCellTag.Fill;
				obj = replicaCellTag.RawValue;
			}
			else if (dataGridViewCell.Tag is Color)
			{
				color = (Color)dataGridViewCell.Tag;
				obj = dataGridViewCell.Value;
			}
			else
			{
				color = this._options.BgCard;
				obj = dataGridViewCell.Value;
			}
			bool flag = e.RowIndex == this._liveCellRow && e.ColumnIndex == this._liveCellCol;
			bool flag2 = this._tracedCells.Contains(Tuple.Create<int, int>(e.RowIndex, e.ColumnIndex));
			Color color2;
			if (flag)
			{
				color2 = Color.FromArgb(255, 220, 50, 50);
			}
			else if (this._currentTableName == "AFR")
			{
				Tuple<int, int> key = Tuple.Create<int, int>(e.RowIndex, e.ColumnIndex);
				double num;
				if (this._afrCellValues.TryGetValue(key, out num))
				{
					double num2 = (num - 10.0) / 10.0;
					num2 = Math.Max(0.0, Math.Min(1.0, num2));
					color2 = this._options.ColorFromProportion((float)num2);
				}
				else
				{
					color2 = color;
				}
			}
			else if (flag2)
			{
				color2 = this.GetTracedColorFromValue(obj, color);
			}
			else
			{
				color2 = color;
			}
			if (color2.A != 255)
			{
				color2 = Color.FromArgb(255, (int)color2.R, (int)color2.G, (int)color2.B);
			}
			using (SolidBrush solidBrush = new SolidBrush(color2))
			{
				e.Graphics.FillRectangle(solidBrush, e.CellBounds);
			}
			if ((flag || flag2) && obj != null)
			{
				Color foreColor = flag ? Color.Yellow : Color.Black;
				Font font = dataGridViewCell.Style.Font ?? this._replicaGrid.DefaultCellStyle.Font;
				TextRenderer.DrawText(e.Graphics, obj.ToString(), font, e.CellBounds, foreColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			}
			bool flag3 = false;
			try
			{
				flag3 = this._options.IsLiveRunning();
			}
			catch
			{
			}
			checked
			{
				if (flag3 && flag && !string.IsNullOrEmpty(this._liveCellText))
				{
					using (Font font2 = new Font("Consolas", 10f, FontStyle.Bold))
					{
						e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
						e.Graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
						foreach (Rectangle bounds in new Rectangle[]
						{
							new Rectangle(e.CellBounds.X - 1, e.CellBounds.Y, e.CellBounds.Width, e.CellBounds.Height),
							new Rectangle(e.CellBounds.X + 1, e.CellBounds.Y, e.CellBounds.Width, e.CellBounds.Height),
							new Rectangle(e.CellBounds.X, e.CellBounds.Y - 1, e.CellBounds.Width, e.CellBounds.Height),
							new Rectangle(e.CellBounds.X, e.CellBounds.Y + 1, e.CellBounds.Width, e.CellBounds.Height)
						})
						{
							TextRenderer.DrawText(e.Graphics, this._liveCellText, font2, bounds, Color.Black, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
						}
						TextRenderer.DrawText(e.Graphics, this._liveCellText, font2, e.CellBounds, Color.Yellow, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
					}
					using (Pen pen = new Pen(Color.Red, 2f))
					{
						e.Graphics.DrawRectangle(pen, new Rectangle(e.CellBounds.X, e.CellBounds.Y, e.CellBounds.Width - 1, e.CellBounds.Height - 1));
					}
				}
				using (Pen pen2 = new Pen(this._options.Border, 1f))
				{
					e.Graphics.DrawRectangle(pen2, new Rectangle(e.CellBounds.X, e.CellBounds.Y, e.CellBounds.Width - 1, e.CellBounds.Height - 1));
				}
				if (flag2 && !flag)
				{
					using (Pen pen3 = new Pen(Color.FromArgb(255, 20, 20, 20), 2f))
					{
						e.Graphics.DrawRectangle(pen3, new Rectangle(e.CellBounds.X + 1, e.CellBounds.Y + 1, e.CellBounds.Width - 3, e.CellBounds.Height - 3));
					}
				}
				e.Handled = true;
			}
		}

		// Token: 0x06001B42 RID: 6978 RVA: 0x000D3158 File Offset: 0x000D3158
		private void OnXRulerPaint(object sender, PaintEventArgs e)
		{
			e.Graphics.Clear(this._options.BgPanel);
			int num = this._replicaGrid.RowHeadersWidth;
			checked
			{
				using (Font font = new Font("Consolas", 7f))
				{
					using (SolidBrush solidBrush = new SolidBrush(this._options.Muted))
					{
						foreach (object obj in this._replicaGrid.Columns)
						{
							DataGridViewColumn dataGridViewColumn = (DataGridViewColumn)obj;
							if (dataGridViewColumn.Visible)
							{
								e.Graphics.DrawString(dataGridViewColumn.HeaderText, font, solidBrush, (float)(num + 3), 6f);
								num += dataGridViewColumn.Width;
							}
						}
					}
				}
				using (Font font2 = new Font("Consolas", 7f, FontStyle.Bold))
				{
					using (SolidBrush solidBrush2 = new SolidBrush(this._options.Cyan))
					{
						e.Graphics.DrawString("Axis: " + (this._options.SwapAxes ? "Y" : "X") + " →", font2, solidBrush2, 2f, 6f);
					}
				}
			}
		}

		// Token: 0x06001B43 RID: 6979 RVA: 0x000D32EC File Offset: 0x000D32EC
		private void OnYRulerPaint(object sender, PaintEventArgs e)
		{
			e.Graphics.Clear(this._options.BgPanel);
			checked
			{
				using (Font font = new Font("Consolas", 7f))
				{
					using (SolidBrush solidBrush = new SolidBrush(this._options.Muted))
					{
						int num = this._replicaGrid.ColumnHeadersHeight;
						int num2 = this._replicaGrid.FirstDisplayedScrollingRowIndex;
						if (num2 < 0)
						{
							num2 = 0;
						}
						int num3 = this._replicaGrid.DisplayedRowCount(true);
						int num4 = num2;
						while (num4 < num2 + num3 && num4 < this._replicaGrid.Rows.Count)
						{
							object value = this._replicaGrid.Rows[num4].HeaderCell.Value;
							if (value != null)
							{
								e.Graphics.DrawString(value.ToString(), font, solidBrush, 4f, (float)(num + 6));
							}
							num += this._replicaGrid.Rows[num4].Height;
							num4++;
						}
					}
				}
			}
		}

		// Token: 0x06001B44 RID: 6980 RVA: 0x000D3410 File Offset: 0x000D3410
		private void OnTraceTick(object sender, EventArgs e)
		{
			bool flag = false;
			try
			{
				flag = this._options.IsLiveRunning();
			}
			catch
			{
			}
			if (!flag || this._frameProvider.LastFrame == null)
			{
				this._lblLiveInfo.Text = "● OFFLINE";
				this._lblLiveInfo.ForeColor = this._options.Muted;
				return;
			}
			int livePointerRow = this._frameProvider.LivePointerRow;
			int livePointerCol = this._frameProvider.LivePointerCol;
			LiveFrameInfo lastFrame = this._frameProvider.LastFrame;
			try
			{
				this._lblLiveInfo.Text = string.Format("● LIVE  {0} rpm | TPS {1:0.0}% | MAP {2:0} | AFR {3:0.0} | R{4}C{5}", new object[]
				{
					lastFrame.RPM,
					lastFrame.TPS,
					lastFrame.MAP,
					lastFrame.AFR,
					livePointerRow,
					livePointerCol
				});
				this._lblLiveInfo.ForeColor = this._options.Green;
			}
			catch
			{
			}
			if (this._currentTableName == "AFR")
			{
				if (this._replicaGrid.Rows.Count > 0 && this._replicaGrid.Columns.Count > 0)
				{
					double num = lastFrame.AFR;
					if (num <= 0.0)
					{
						num = 14.7;
					}
					if (livePointerRow >= 0 && livePointerRow < this._replicaGrid.Rows.Count && livePointerCol >= 0 && livePointerCol < this._replicaGrid.Columns.Count)
					{
						int num2 = livePointerRow;
						int num3 = livePointerCol;
						Tuple<int, int> tuple = Tuple.Create<int, int>(num2, num3);
						this._afrCellValues[tuple] = num;
						if (!this._cellHistoryValues.ContainsKey(tuple))
						{
							this._cellHistoryValues[tuple] = new List<double>();
						}
						this._cellHistoryValues[tuple].Add(num);
						this._tracedCells.Add(tuple);
						this._liveCellRow = num2;
						this._liveCellCol = num3;
						this._liveCellText = num.ToString("F2", CultureInfo.InvariantCulture);
						DataGridViewCell dataGridViewCell = this._replicaGrid.Rows[num2].Cells[num3];
						dataGridViewCell.Value = num.ToString("F2", CultureInfo.InvariantCulture);
						double num4 = (num - 10.0) / 10.0;
						num4 = Math.Max(0.0, Math.Min(1.0, num4));
						Color fill = this._options.ColorFromProportion((float)num4);
						dataGridViewCell.Tag = new LiveTracingForm.ReplicaCellTag
						{
							Fill = fill,
							RawValue = num.ToString("F2", CultureInfo.InvariantCulture)
						};
						dataGridViewCell.Style.ForeColor = Color.Black;
					}
					try
					{
						this._replicaGrid.Invalidate();
					}
					catch
					{
					}
				}
				return;
			}
			if (livePointerRow < 0 || livePointerCol < 0 || livePointerRow >= this._replicaGrid.Rows.Count || livePointerCol >= this._replicaGrid.Columns.Count || livePointerRow >= this._activeSourceGrid.Rows.Count || livePointerCol >= this._activeSourceGrid.Columns.Count)
			{
				return;
			}
			object obj = null;
			try
			{
				obj = this._activeSourceGrid[livePointerCol, livePointerRow].Value;
			}
			catch
			{
			}
			double num5 = 0.0;
			if (obj != null)
			{
				double.TryParse(obj.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out num5);
			}
			Tuple<int, int> key = Tuple.Create<int, int>(livePointerRow, livePointerCol);
			if (!this._cellHistoryValues.ContainsKey(key))
			{
				this._cellHistoryValues[key] = new List<double>();
			}
			this._cellHistoryValues[key].Add(num5);
			checked
			{
				string liveCellText = (Math.Abs(num5) >= 100.0) ? ((long)Math.Round(num5)).ToString(CultureInfo.InvariantCulture) : num5.ToString("F2", CultureInfo.InvariantCulture);
				int liveCellRow = this._liveCellRow;
				int liveCellCol = this._liveCellCol;
				this._liveCellText = liveCellText;
				this._liveCellRow = livePointerRow;
				this._liveCellCol = livePointerCol;
				this._tracedCells.Add(Tuple.Create<int, int>(livePointerRow, livePointerCol));
				if (this._cmbView.SelectedIndex == 0)
				{
					this._tracedCells.Clear();
					this._tracedCells.Add(Tuple.Create<int, int>(livePointerRow, livePointerCol));
				}
				try
				{
					int num6 = Math.Max(0, Math.Min(livePointerRow - 2, this._replicaGrid.Rows.Count - 1));
					if (this._replicaGrid.FirstDisplayedScrollingRowIndex != num6)
					{
						this._replicaGrid.FirstDisplayedScrollingRowIndex = num6;
					}
					int num7 = Math.Max(0, Math.Min(livePointerCol - 1, this._replicaGrid.Columns.Count - 1));
					if (this._replicaGrid.FirstDisplayedScrollingColumnIndex != num7)
					{
						this._replicaGrid.FirstDisplayedScrollingColumnIndex = num7;
					}
				}
				catch
				{
				}
				try
				{
					Rectangle cellDisplayRectangle = this._replicaGrid.GetCellDisplayRectangle(livePointerCol, livePointerRow, false);
					if (!cellDisplayRectangle.IsEmpty && cellDisplayRectangle.Width > 0)
					{
						this._replicaGrid.Invalidate(cellDisplayRectangle);
					}
					if (liveCellRow >= 0 && liveCellCol >= 0 && (liveCellRow != livePointerRow || liveCellCol != livePointerCol))
					{
						Rectangle cellDisplayRectangle2 = this._replicaGrid.GetCellDisplayRectangle(liveCellCol, liveCellRow, false);
						if (!cellDisplayRectangle2.IsEmpty && cellDisplayRectangle2.Width > 0)
						{
							this._replicaGrid.Invalidate(cellDisplayRectangle2);
						}
					}
				}
				catch
				{
				}
				this.SyncGraph3DLivePointer(livePointerCol, livePointerRow, num5);
			}
		}

		// Token: 0x06001B45 RID: 6981 RVA: 0x00010432 File Offset: 0x00010432
		private void OnHeaderMouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this._isDrag = true;
				this._dragStart = e.Location;
			}
		}

		// Token: 0x06001B46 RID: 6982 RVA: 0x000D39D0 File Offset: 0x000D39D0
		private void OnHeaderMouseMove(object sender, MouseEventArgs e)
		{
			if (this._isDrag)
			{
				base.Location = checked(new Point(base.Location.X + e.X - this._dragStart.X, base.Location.Y + e.Y - this._dragStart.Y));
			}
		}

		// Token: 0x06001B47 RID: 6983 RVA: 0x00010454 File Offset: 0x00010454
		private void OnHeaderMouseUp(object sender, MouseEventArgs e)
		{
			this._isDrag = false;
		}

		// Token: 0x06001B48 RID: 6984 RVA: 0x0001045D File Offset: 0x0001045D
		private void OnFormClosed(object sender, FormClosedEventArgs e)
		{
			this.CloseGraph3D();
			if (this._traceTimer != null)
			{
				this._traceTimer.Stop();
				this._traceTimer.Dispose();
				this._traceTimer = null;
			}
		}

		// Token: 0x06001B49 RID: 6985 RVA: 0x000D3A34 File Offset: 0x000D3A34
		private Color GetTracedColorFromValue(object rawValue, Color fallbackBaseColor)
		{
			double num;
			if (rawValue == null || !double.TryParse(rawValue.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out num))
			{
				return LiveTracingForm.Darken(fallbackBaseColor, 0.55f);
			}
			double num2 = this._options.MaxValue - this._options.MinValue;
			if (num2 <= 0.0)
			{
				num2 = 1.0;
			}
			float num3 = (float)((num - this._options.MinValue) / num2);
			if (num3 < 0f)
			{
				num3 = 0f;
			}
			if (num3 > 1f)
			{
				num3 = 1f;
			}
			return LiveTracingForm.ComputeValueGradient(num3);
		}

		// Token: 0x06001B4A RID: 6986 RVA: 0x000D3ACC File Offset: 0x000D3ACC
		private static Color ComputeValueGradient(float t)
		{
			if (t < 0f)
			{
				t = 0f;
			}
			if (t > 1f)
			{
				t = 1f;
			}
			Color[] array = new Color[]
			{
				Color.FromArgb(255, 255, 0, 255),
				Color.FromArgb(255, 0, 150, 255),
				Color.FromArgb(255, 0, 255, 150),
				Color.FromArgb(255, 255, 200, 0),
				Color.FromArgb(255, 255, 0, 0)
			};
			float num = t * (float)(checked(array.Length - 1));
			checked
			{
				int num2 = (int)Math.Floor((double)num);
				if (num2 >= array.Length - 1)
				{
					return array[array.Length - 1];
				}
				float num3 = unchecked(num - (float)num2);
				Color color = array[num2];
				Color color2 = array[num2 + 1];
				return Color.FromArgb(255, (int)(unchecked((float)color.R + (float)(checked(color2.R - color.R)) * num3)), (int)(unchecked((float)color.G + (float)(checked(color2.G - color.G)) * num3)), (int)(unchecked((float)color.B + (float)(checked(color2.B - color.B)) * num3)));
			}
		}

		// Token: 0x06001B4B RID: 6987 RVA: 0x000D3C24 File Offset: 0x000D3C24
		private static Color Darken(Color c, float factor)
		{
			if (factor < 0f)
			{
				factor = 0f;
			}
			if (factor > 1f)
			{
				factor = 1f;
			}
			return checked(Color.FromArgb(255, (int)(unchecked((float)c.R * factor)), (int)(unchecked((float)c.G * factor)), (int)(unchecked((float)c.B * factor))));
		}

		// Token: 0x06001B4C RID: 6988 RVA: 0x000D3C7C File Offset: 0x000D3C7C
		public LiveTracingForm(DataGridView sourceGrid, DataGridView sourceGridIgnition, ILiveFrameProvider frameProvider, LiveTracingOptions options)
		{
			this._liveCellRow = -1;
			this._liveCellCol = -1;
			this._tracedCells = new HashSet<Tuple<int, int>>();
			this._afrCellValues = new Dictionary<Tuple<int, int>, double>();
			if (sourceGrid == null)
			{
				throw new ArgumentNullException("sourceGrid");
			}
			if (frameProvider == null)
			{
				throw new ArgumentNullException("frameProvider");
			}
			if (options == null)
			{
				throw new ArgumentNullException("options");
			}
			this._sourceGrid = sourceGrid;
			this._sourceGridIgnition = sourceGridIgnition;
			this._activeSourceGrid = sourceGrid;
			this._frameProvider = frameProvider;
			this._options = options;
			this._currentTableName = (options.MapTitle ?? "—");
			this._mapSources["Fuel TPS - RPM"] = sourceGrid;
			if (this._sourceGridIgnition != null)
			{
				this._mapSources["Ignition TPS - RPM"] = this._sourceGridIgnition;
			}
			this.InitializeUi();
		}

		// Token: 0x06001B4D RID: 6989 RVA: 0x000D3D70 File Offset: 0x000D3D70
		private Panel BuildHistoryTableMenu()
		{
			Panel panel = new Panel();
			panel.Dock = DockStyle.Fill;
			panel.BackColor = this._options.BgPanel;
			panel.Padding = new Padding(10, 12, 10, 8);
			Label value = new Label
			{
				Text = "History Table:",
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				ForeColor = Color.White,
				BackColor = Color.Transparent,
				AutoSize = true,
				Location = new Point(10, 14)
			};
			panel.Controls.Add(value);
			this._cmbHistoryTable = new ComboBox
			{
				DropDownStyle = ComboBoxStyle.DropDownList,
				Font = new Font("Segoe UI", 8.5f),
				Location = new Point(110, 10),
				Width = 150
			};
			this._cmbHistoryTable.Items.Add("Fuel TPS - RPM");
			this._cmbHistoryTable.Items.Add("Ignition TPS - RPM");
			this._cmbHistoryTable.Items.Add("AFR");
			this._cmbHistoryTable.SelectedIndex = 0;
			this._cmbHistoryTable.SelectedIndexChanged += this.OnHistoryTableChanged;
			panel.Controls.Add(this._cmbHistoryTable);
			Label value2 = new Label
			{
				Text = "View:",
				Font = new Font("Segoe UI", 9f),
				ForeColor = this._options.Fg,
				Location = new Point(280, 14),
				AutoSize = true
			};
			panel.Controls.Add(value2);
			this._cmbView = new ComboBox
			{
				DropDownStyle = ComboBoxStyle.DropDownList,
				Font = new Font("Segoe UI", 8.5f),
				Location = new Point(330, 10),
				Width = 150
			};
			this._cmbView.Items.Add("Most Recent Sample");
			this._cmbView.Items.Add("History Average");
			this._cmbView.Items.Add("History Std Deviation");
			this._cmbView.Items.Add("History Sample Count");
			this._cmbView.Items.Add("Running Average");
			this._cmbView.Items.Add("Running Sample Count");
			this._cmbView.Items.Add("Running Minimum");
			this._cmbView.Items.Add("Running Maximum");
			this._cmbView.Items.Add("Running Range");
			this._cmbView.SelectedIndex = 0;
			this._cmbView.SelectedIndexChanged += this.OnViewModeChanged;
			panel.Controls.Add(this._cmbView);
			Button button = new Button
			{
				Text = "Clear",
				Font = new Font("Segoe UI", 8.5f),
				Location = new Point(500, 9),
				Size = new Size(60, 24),
				FlatStyle = FlatStyle.System
			};
			button.Click += this.OnClearHistoryClicked;
			panel.Controls.Add(button);
			this._chkGraph = new CheckBox
			{
				Text = "Graph",
				Font = new Font("Segoe UI", 9f),
				ForeColor = this._options.Fg,
				Location = new Point(580, 12),
				AutoSize = true
			};
			this._chkGraph.CheckedChanged += this.OnGraphCheckChanged;
			panel.Controls.Add(this._chkGraph);
			return panel;
		}

		// Token: 0x06001B4E RID: 6990 RVA: 0x000D4148 File Offset: 0x000D4148
		private void OnHistoryTableChanged(object sender, EventArgs e)
		{
			string text = this._cmbHistoryTable.SelectedItem as string;
			if (text == null)
			{
				return;
			}
			DataGridView dataGridView = null;
			double? num = null;
			double? num2 = null;
			string currentTableName = text;
			checked
			{
				if (text.StartsWith("Fuel", StringComparison.OrdinalIgnoreCase))
				{
					dataGridView = this._sourceGrid;
					num = new double?(this._options.MinValue);
					num2 = new double?(this._options.MaxValue);
				}
				else if (text.StartsWith("Ignition", StringComparison.OrdinalIgnoreCase))
				{
					dataGridView = this.ReadIgnitionFromMemory();
					if (dataGridView != null && dataGridView.Rows.Count > 0)
					{
						double num3 = double.MaxValue;
						double num4 = double.MinValue;
						for (int i = 0; i < dataGridView.Rows.Count; i++)
						{
							for (int j = 0; j < dataGridView.Columns.Count; j++)
							{
								object value = dataGridView[j, i].Value;
								double num5;
								if (value != null && double.TryParse(value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out num5))
								{
									if (num5 < num3)
									{
										num3 = num5;
									}
									if (num5 > num4)
									{
										num4 = num5;
									}
								}
							}
						}
						num = new double?(num3);
						num2 = new double?(num4);
					}
				}
				else if (text == "AFR")
				{
					dataGridView = this._sourceGrid;
					num = new double?(10.0);
					num2 = new double?(20.0);
				}
				if (dataGridView == null)
				{
					return;
				}
				bool flag = this._traceTimer != null && this._traceTimer.Enabled;
				if (flag)
				{
					this._traceTimer.Stop();
				}
				try
				{
					this._activeSourceGrid = dataGridView;
					this._currentTableName = currentTableName;
					if (this._lblMapTitle != null)
					{
						this._lblMapTitle.Text = "\ud83d\uddfa  " + this._currentTableName + " — 2D MAP TABLE (LIVE TRACE)";
					}
					if (num != null)
					{
						this._options.MinValue = num.Value;
					}
					if (num2 != null)
					{
						this._options.MaxValue = num2.Value;
					}
					this._tracedCells.Clear();
					this._afrCellValues.Clear();
					this._cellHistoryValues.Clear();
					this._liveCellRow = -1;
					this._liveCellCol = -1;
					this._liveCellText = null;
					this._replicaGrid.CellPainting -= this.OnCellPainting;
					this._replicaGrid.Rows.Clear();
					this._replicaGrid.Columns.Clear();
					if (text == "AFR")
					{
						DataGridView sourceGrid = this._sourceGrid;
						for (int k = 0; k < sourceGrid.Columns.Count; k++)
						{
							this._replicaGrid.Columns.Add(new DataGridViewTextBoxColumn
							{
								HeaderText = sourceGrid.Columns[k].HeaderText,
								Name = sourceGrid.Columns[k].Name,
								Width = sourceGrid.Columns[k].Width
							});
						}
						for (int l = 0; l < sourceGrid.Rows.Count; l++)
						{
							int index = this._replicaGrid.Rows.Add();
							this._replicaGrid.Rows[index].Height = sourceGrid.Rows[l].Height;
							this._replicaGrid.Rows[index].HeaderCell.Value = (sourceGrid.Rows[l].HeaderCell.Value ?? "");
							for (int m = 0; m < sourceGrid.Columns.Count; m++)
							{
								this._replicaGrid.Rows[index].Cells[m].Value = null;
							}
						}
					}
					else
					{
						this.PopulateReplicaGrid();
					}
					this._replicaGrid.CellPainting += this.OnCellPainting;
					this._replicaGrid.Invalidate();
					this._xRuler.Invalidate();
					this._yRuler.Invalidate();
				}
				finally
				{
					if (flag)
					{
						this._traceTimer.Start();
					}
				}
				if (this._chkGraph != null && this._chkGraph.Checked)
				{
					this.OpenGraph3D();
				}
			}
		}

		// Token: 0x06001B4F RID: 6991 RVA: 0x000D45C0 File Offset: 0x000D45C0
		private void OnViewModeChanged(object sender, EventArgs e)
		{
			this._viewRunningMode = (this._cmbView.SelectedIndex == 0);
			if (this._viewRunningMode)
			{
				this._tracedCells.Clear();
				if (this._liveCellRow >= 0 && this._liveCellCol >= 0)
				{
					this._tracedCells.Add(Tuple.Create<int, int>(this._liveCellRow, this._liveCellCol));
				}
			}
			else
			{
				this._tracedCells.Clear();
				foreach (KeyValuePair<Tuple<int, int>, List<double>> keyValuePair in this._cellHistoryValues)
				{
					if (keyValuePair.Value.Count > 0)
					{
						Tuple<int, int> key = keyValuePair.Key;
						List<double> value = keyValuePair.Value;
						double num = 0.0;
						switch (this._cmbView.SelectedIndex)
						{
						case 1:
							num = value.Average();
							break;
						case 2:
						{
							double avg = value.Average();
							num = Math.Sqrt(value.Sum((double v) => Math.Pow(v - avg, 2.0)) / (double)value.Count);
							break;
						}
						case 3:
							num = (double)value.Count;
							break;
						case 4:
							num = value.Average();
							break;
						case 5:
							num = (double)value.Count;
							break;
						case 6:
							num = value.Min();
							break;
						case 7:
							num = value.Max();
							break;
						case 8:
							num = value.Max() - value.Min();
							break;
						}
						if (key.Item1 < this._replicaGrid.Rows.Count && key.Item2 < this._replicaGrid.Columns.Count)
						{
							DataGridViewCell dataGridViewCell = this._replicaGrid.Rows[key.Item1].Cells[key.Item2];
							string text = (Math.Abs(num) >= 100.0) ? (checked((long)Math.Round(num))).ToString(CultureInfo.InvariantCulture) : num.ToString("F2", CultureInfo.InvariantCulture);
							dataGridViewCell.Value = text;
							double num2 = this._options.MaxValue - this._options.MinValue;
							if (num2 <= 0.0)
							{
								num2 = 1.0;
							}
							float num3 = (float)((num - this._options.MinValue) / num2);
							num3 = Math.Max(0f, Math.Min(1f, num3));
							Color fill = this._options.ColorFromProportion(num3);
							dataGridViewCell.Tag = new LiveTracingForm.ReplicaCellTag
							{
								Fill = fill,
								RawValue = text
							};
							dataGridViewCell.Style.ForeColor = Color.Black;
						}
						this._tracedCells.Add(key);
					}
				}
			}
			if (this._replicaGrid != null)
			{
				this._replicaGrid.Invalidate();
			}
		}

		// Token: 0x06001B50 RID: 6992 RVA: 0x000D48D4 File Offset: 0x000D48D4
		private void OnClearHistoryClicked(object sender, EventArgs e)
		{
			this._tracedCells.Clear();
			this._afrCellValues.Clear();
			this._cellHistoryValues.Clear();
			if (this._replicaGrid != null)
			{
				this._replicaGrid.Invalidate();
			}
			this._xRuler.Invalidate();
			this._yRuler.Invalidate();
		}

		// Token: 0x06001B51 RID: 6993 RVA: 0x0001048A File Offset: 0x0001048A
		private void OnGraphCheckChanged(object sender, EventArgs e)
		{
			if (this._chkGraph != null && this._chkGraph.Checked)
			{
				this.OpenGraph3D();
				return;
			}
			this.CloseGraph3D();
		}

		// Token: 0x06001B52 RID: 6994 RVA: 0x000D492C File Offset: 0x000D492C
		private void OpenGraph3D()
		{
			try
			{
				this.CloseGraph3D();
				DataGridView dataGridView = this._activeSourceGrid ?? this._sourceGrid;
				if (dataGridView != null && dataGridView.Rows.Count != 0 && dataGridView.Columns.Count != 0)
				{
					string text = "Graph 3D — " + (this._options.MapTitle ?? "LIVE TRACE");
					this._graph3DForm = new Plot3D.Graph3DMainForm
					{
						Text = text
					};
					this._graph3DForm.FormClosed += delegate(object s, FormClosedEventArgs e)
					{
						this._graph3DForm = null;
						if (this._chkGraph != null && this._chkGraph.Checked)
						{
							this._chkGraph.Checked = false;
						}
					};
					this._graph3DForm.Show(this);
					Plot3D.Graph3D graph3DControl = this._graph3DForm.Graph3DControl;
					if (graph3DControl != null && !graph3DControl.IsDisposed)
					{
						graph3DControl.ShowPoints = false;
						graph3DControl.ShowWireframe = false;
						graph3DControl.Raster = Plot3D.Graph3D.eRaster.Off;
						graph3DControl.DragSensitivity = 0.05;
						graph3DControl.AllowDrag = true;
						graph3DControl.AllowRotate = true;
						graph3DControl.AllowZoom = true;
						try
						{
							graph3DControl.EnableEditMode(true);
						}
						catch
						{
						}
						try
						{
							graph3DControl.EnableLiveMode(true);
						}
						catch
						{
						}
						this.PushGridToGraph3D(graph3DControl);
						graph3DControl.Invalidate();
					}
					this._graph3DForm.Activate();
					this._graph3DForm.BringToFront();
				}
			}
			catch (Exception ex)
			{
				this._graph3DForm = null;
				MessageBox.Show(this, "Gagal buka Graph3D:\n\n" + ex.GetType().Name + ": " + ex.Message, "Graph3D Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x06001B53 RID: 6995 RVA: 0x000D4AE0 File Offset: 0x000D4AE0
		private void CloseGraph3D()
		{
			try
			{
				if (this._graph3DForm != null && !this._graph3DForm.IsDisposed)
				{
					Plot3D.Graph3DMainForm graph3DForm = this._graph3DForm;
					this._graph3DForm = null;
					graph3DForm.Close();
					graph3DForm.Dispose();
				}
			}
			catch
			{
				this._graph3DForm = null;
			}
		}

		// Token: 0x06001B54 RID: 6996 RVA: 0x000D4B38 File Offset: 0x000D4B38
		private void PushGridToGraph3D(Plot3D.Graph3D target)
		{
			if (target == null || target.IsDisposed)
			{
				return;
			}
			DataGridView dataGridView = this._activeSourceGrid ?? this._sourceGrid;
			if (dataGridView == null || dataGridView.Rows.Count < 2 || dataGridView.Columns.Count < 2)
			{
				return;
			}
			checked
			{
				try
				{
					int count = dataGridView.Rows.Count;
					int count2 = dataGridView.Columns.Count;
					Plot3D.Graph3D.cPoint3D[,] array = new Plot3D.Graph3D.cPoint3D[count2, count];
					for (int i = 0; i < count; i++)
					{
						for (int j = 0; j < count2; j++)
						{
							double z = 0.0;
							object value = dataGridView[j, i].Value;
							if (value != null)
							{
								double.TryParse(value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out z);
							}
							array[j, i] = new Plot3D.Graph3D.cPoint3D((double)j, (double)i, z);
						}
					}
					target.SetSurfacePoints(array, Plot3D.Graph3D.eNormalize.Separate);
				}
				catch
				{
				}
			}
		}

		// Token: 0x06001B55 RID: 6997 RVA: 0x000D4C30 File Offset: 0x000D4C30
		private void SyncGraph3DLivePointer(int col, int row, double zValue)
		{
			try
			{
				if (this._graph3DForm != null && !this._graph3DForm.IsDisposed)
				{
					Plot3D.Graph3D graph3DControl = this._graph3DForm.Graph3DControl;
					if (graph3DControl != null && !graph3DControl.IsDisposed)
					{
						double rpm = 0.0;
						double tps = 0.0;
						try
						{
							LiveFrameInfo lastFrame = this._frameProvider.LastFrame;
							if (lastFrame != null)
							{
								rpm = (double)lastFrame.RPM;
								tps = lastFrame.TPS;
							}
						}
						catch
						{
						}
						try
						{
							graph3DControl.UpdateLiveDataDirect(col, row, rpm, tps, zValue);
						}
						catch
						{
							try
							{
								graph3DControl.Invalidate();
							}
							catch
							{
							}
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06001B56 RID: 6998 RVA: 0x000D4CF8 File Offset: 0x000D4CF8
		private DataGridView ReadIgnitionFromMemory()
		{
			checked
			{
				try
				{
					DataGridView lastIgnitionGrid = MapEditorForm.LastIgnitionGrid;
					if (lastIgnitionGrid != null && lastIgnitionGrid.Rows.Count > 0)
					{
						DataGridView dataGridView = new DataGridView();
						foreach (object obj in lastIgnitionGrid.Columns)
						{
							DataGridViewColumn dataGridViewColumn = (DataGridViewColumn)obj;
							dataGridView.Columns.Add(new DataGridViewTextBoxColumn
							{
								HeaderText = dataGridViewColumn.HeaderText,
								Width = dataGridViewColumn.Width
							});
						}
						foreach (object obj2 in ((IEnumerable)lastIgnitionGrid.Rows))
						{
							DataGridViewRow dataGridViewRow = (DataGridViewRow)obj2;
							if (!dataGridViewRow.IsNewRow)
							{
								int index = dataGridView.Rows.Add();
								dataGridView.Rows[index].HeaderCell.Value = dataGridViewRow.HeaderCell.Value;
								for (int i = 0; i < lastIgnitionGrid.Columns.Count; i++)
								{
									dataGridView.Rows[index].Cells[i].Value = dataGridViewRow.Cells[i].Value;
								}
							}
						}
						return dataGridView;
					}
				}
				catch
				{
				}
				return null;
			}
		}

		// Token: 0x04002352 RID: 9042
		private readonly DataGridView _sourceGrid;

		// Token: 0x04002353 RID: 9043
		private readonly ILiveFrameProvider _frameProvider;

		// Token: 0x04002354 RID: 9044
		private readonly LiveTracingOptions _options;

		// Token: 0x04002355 RID: 9045
		private string _liveCellText;

		// Token: 0x04002356 RID: 9046
		private int _liveCellRow;

		// Token: 0x04002357 RID: 9047
		private int _liveCellCol;

		// Token: 0x04002358 RID: 9048
		private HashSet<Tuple<int, int>> _tracedCells;

		// Token: 0x04002359 RID: 9049
		private DataGridView _replicaGrid;

		// Token: 0x0400235A RID: 9050
		private Panel _xRuler;

		// Token: 0x0400235B RID: 9051
		private Panel _yRuler;

		// Token: 0x0400235C RID: 9052
		private Label _lblLiveInfo;

		// Token: 0x0400235D RID: 9053
		private Timer _traceTimer;

		// Token: 0x0400235E RID: 9054
		private bool _isDrag;

		// Token: 0x0400235F RID: 9055
		private Point _dragStart;

		// Token: 0x04002360 RID: 9056
		private DataGridView _sourceGridIgnition;

		// Token: 0x04002361 RID: 9057
		private DataGridView _activeSourceGrid;

		// Token: 0x04002362 RID: 9058
		private ComboBox _cmbHistoryTable;

		// Token: 0x04002363 RID: 9059
		private ComboBox _cmbView;

		// Token: 0x04002364 RID: 9060
		private bool _viewRunningMode = true;

		// Token: 0x04002365 RID: 9061
		private readonly Dictionary<string, DataGridView> _mapSources = new Dictionary<string, DataGridView>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04002366 RID: 9062
		private CheckBox _chkGraph;

		// Token: 0x04002367 RID: 9063
		private Plot3D.Graph3DMainForm _graph3DForm;

		// Token: 0x04002368 RID: 9064
		private Label _lblMapTitle;

		// Token: 0x04002369 RID: 9065
		private string _currentTableName;

		// Token: 0x0400236A RID: 9066
		private readonly Dictionary<Tuple<int, int>, double> _afrCellValues;

		// Token: 0x0400236B RID: 9067
		private Dictionary<Tuple<int, int>, List<double>> _cellHistoryValues = new Dictionary<Tuple<int, int>, List<double>>();

		// Token: 0x020009D2 RID: 2514
		private sealed class ReplicaCellTag
		{
			// Token: 0x0400236C RID: 9068
			public Color Fill;

			// Token: 0x0400236D RID: 9069
			public object RawValue;
		}
	}
}
