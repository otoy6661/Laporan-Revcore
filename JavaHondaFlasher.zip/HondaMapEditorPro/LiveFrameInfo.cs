﻿using System;

namespace HondaMapEditorPro
{
	// Token: 0x020009CE RID: 2510
	public sealed class LiveFrameInfo
	{
		// Token: 0x170001D7 RID: 471
		// (get) Token: 0x06001B04 RID: 6916 RVA: 0x00010258 File Offset: 0x00010258
		// (set) Token: 0x06001B05 RID: 6917 RVA: 0x00010260 File Offset: 0x00010260
		public int RPM { get; set; }

		// Token: 0x170001D8 RID: 472
		// (get) Token: 0x06001B06 RID: 6918 RVA: 0x00010269 File Offset: 0x00010269
		// (set) Token: 0x06001B07 RID: 6919 RVA: 0x00010271 File Offset: 0x00010271
		public double TPS { get; set; }

		// Token: 0x170001D9 RID: 473
		// (get) Token: 0x06001B08 RID: 6920 RVA: 0x0001027A File Offset: 0x0001027A
		// (set) Token: 0x06001B09 RID: 6921 RVA: 0x00010282 File Offset: 0x00010282
		public double MAP { get; set; }

		// Token: 0x170001DA RID: 474
		// (get) Token: 0x06001B0A RID: 6922 RVA: 0x0001028B File Offset: 0x0001028B
		// (set) Token: 0x06001B0B RID: 6923 RVA: 0x00010293 File Offset: 0x00010293
		public double AFR { get; set; }
	}
}
