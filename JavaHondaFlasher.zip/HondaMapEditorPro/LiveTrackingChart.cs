﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Honda_Flash_Tools.Net;

namespace HondaMapEditorPro
{
	// Token: 0x0200095E RID: 2398
	public partial class LiveTrackingChart : Form
	{
		// Token: 0x06001A35 RID: 6709 RVA: 0x000CC728 File Offset: 0x000CC728
		public LiveTrackingChart()
		{
			this._rpmColor = Color.FromArgb(0, 160, 255);
			this._tpsColor = Color.FromArgb(255, 220, 0);
			this._afrColor = Color.FromArgb(80, 255, 120);
			this._adColor = Color.FromArgb(255, 120, 60);
			this._autoScroll = true;
			this._autoPopupEnabled = true;
			this._rpmMax = 8000;
			this._lastStatusUpdate = DateTime.MinValue;
			this._lastInvalidate = DateTime.MinValue;
			this._hoverSampleIdx = -1;
			this.Text = "Live Chart Tracking — MAP EDITOR";
			this.BackColor = this._bgDark;
			this.ForeColor = this._fg;
			this.Font = new Font("Segoe UI", 9f);
			base.ClientSize = new Size(1100, 720);
			this.MinimumSize = new Size(800, 600);
			base.StartPosition = FormStartPosition.CenterScreen;
			base.FormBorderStyle = FormBorderStyle.None;
			base.Padding = new Padding(6);
			this.DoubleBuffered = true;
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.UpdateStyles();
			this.AllocGdi();
			this.BuildUI();
			base.HandleCreated += delegate(object s, EventArgs e)
			{
				this.ApplyRoundedRegion();
			};
			base.Resize += delegate(object s, EventArgs e)
			{
				this.ApplyRoundedRegion();
			};
		}

		// Token: 0x06001A36 RID: 6710 RVA: 0x000CC950 File Offset: 0x000CC950
		private void BuildUI()
		{
			this.BuildTitleBar();
			Panel panel = new Panel
			{
				Dock = DockStyle.Top,
				Height = 48,
				BackColor = this._bgPanel,
				Padding = new Padding(10, 6, 10, 6)
			};
			this._chkRpm = this.MakeCheck("RPM", this._rpmColor, true, 10);
			this._chkTps = this.MakeCheck("TPS", this._tpsColor, true, 90);
			this._chkAfr = this.MakeCheck("AFR", this._afrColor, true, 170);
			this._chkAd = this.MakeCheck("AD", this._adColor, false, 250);
			this._chkAutoScroll = new CheckBox
			{
				Text = "Auto-Scroll",
				Checked = true,
				AutoSize = true,
				Location = new Point(320, 14),
				ForeColor = this._cyan,
				BackColor = Color.Transparent
			};
			this._chkAutoScroll.CheckedChanged += delegate(object s, EventArgs e)
			{
				this._autoScroll = this._chkAutoScroll.Checked;
				this._plotPanel.Invalidate();
			};
			this._btnPause = this.MakeRoundedButton("⏸ PAUSE", 430, 10, 100, 28, this._cyan);
			this._btnPause.Click += delegate(object s, EventArgs e)
			{
				this._paused = !this._paused;
				this._btnPause.Text = (this._paused ? "▶ RESUME" : "⏸ PAUSE");
				this._btnPause.ForeColor = (this._paused ? this._danger : this._cyan);
				this._btnPause.Invalidate();
			};
			this._btnAutoPopup = this.MakeRoundedButton("\ud83d\udd34 POPUP: ON", 540, 10, 130, 28, this._green);
			this._btnAutoPopup.Click += delegate(object s, EventArgs e)
			{
				this._autoPopupEnabled = !this._autoPopupEnabled;
				this._btnAutoPopup.Text = (this._autoPopupEnabled ? "\ud83d\udd34 POPUP: ON" : "⚪ POPUP: OFF");
				this._btnAutoPopup.ForeColor = (this._autoPopupEnabled ? this._green : this._muted);
				this._btnAutoPopup.Invalidate();
				this._plotPanel.Invalidate();
			};
			panel.Controls.AddRange(new Control[]
			{
				this._chkRpm,
				this._chkTps,
				this._chkAfr,
				this._chkAd,
				this._chkAutoScroll,
				this._btnPause,
				this._btnAutoPopup
			});
			this._statusBar = new Label
			{
				Dock = DockStyle.Bottom,
				Height = 26,
				BackColor = this._bgPanel,
				ForeColor = this._muted,
				Font = new Font("Consolas", 8.5f, FontStyle.Bold),
				Padding = new Padding(10, 4, 10, 4),
				Text = "RPM: —   TPS: —   AFR: —   AD: —"
			};
			this._scroll = new HScrollBar
			{
				Dock = DockStyle.Bottom,
				Height = 18,
				Minimum = 0,
				Maximum = 0
			};
			this._scroll.Scroll += delegate(object s, ScrollEventArgs e)
			{
				this._autoScroll = false;
				this._chkAutoScroll.Checked = false;
				this._plotPanel.Invalidate();
			};
			this._plotPanel = new LiveTrackingChart.DoubleBufferedPanel
			{
				Dock = DockStyle.Fill,
				BackColor = this._bgDark
			};
			this._plotPanel.Paint += this.PlotPanel_Paint;
			this._plotPanel.Resize += delegate(object s, EventArgs e)
			{
				this._plotPanel.Invalidate();
			};
			this._plotPanel.MouseMove += this.PlotPanel_MouseMove;
			this._plotPanel.MouseLeave += delegate(object s, EventArgs e)
			{
				this._mouseOverPlot = false;
				this._hoverActive = false;
				this._hoverSampleIdx = -1;
				this._plotPanel.Invalidate();
			};
			base.Controls.Add(this._plotPanel);
			base.Controls.Add(panel);
			base.Controls.Add(this._scroll);
			base.Controls.Add(this._statusBar);
			base.Controls.Add(this._titleBar);
		}

		// Token: 0x06001A37 RID: 6711 RVA: 0x000CCC9C File Offset: 0x000CCC9C
		private CheckBox MakeCheck(string text, Color color, bool on, int x)
		{
			CheckBox checkBox = new CheckBox();
			checkBox.Text = text;
			checkBox.Checked = on;
			checkBox.AutoSize = true;
			checkBox.Location = new Point(x, 14);
			checkBox.ForeColor = color;
			checkBox.BackColor = Color.Transparent;
			checkBox.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
			checkBox.CheckedChanged += delegate(object s, EventArgs e)
			{
				this._plotPanel.Invalidate();
			};
			return checkBox;
		}

		// Token: 0x06001A38 RID: 6712 RVA: 0x000CCD0C File Offset: 0x000CCD0C
		public void PushSample(int rpm, float tps, float afr, float ad)
		{
			if (this._paused)
			{
				return;
			}
			checked
			{
				if (rpm > this._rpmMax)
				{
					this._rpmMax = Math.Min(12000, (rpm / 1000 + 1) * 1000);
				}
				this._samples.Add(new LiveTrackingChart.Sample
				{
					RPM = rpm,
					TPS = tps,
					AFR = afr,
					AD = ad,
					Time = DateTime.Now
				});
				if (this._samples.Count > 400)
				{
					this._samples.RemoveRange(0, this._samples.Count - 400);
				}
				int num = Math.Max(0, this._samples.Count * 4 - this._plotPanel.Width + 100);
				if (this._scroll.Maximum != num)
				{
					this._scroll.Maximum = num;
				}
				if (this._autoScroll && this._scroll.Value != num)
				{
					this._scroll.Value = num;
				}
				if ((DateTime.Now - this._lastStatusUpdate).TotalMilliseconds >= 333.0)
				{
					this._lastStatusUpdate = DateTime.Now;
					this._statusBar.Text = string.Format("RPM: {0,5}   TPS: {1,5:F1}%   AFR: {2,4:F1}   AD: {3,5:F1}   |   Samples: {4}", new object[]
					{
						rpm,
						tps,
						afr,
						ad,
						this._samples.Count
					});
				}
				if ((DateTime.Now - this._lastInvalidate).TotalMilliseconds >= 100.0)
				{
					this._lastInvalidate = DateTime.Now;
					this._plotPanel.Invalidate();
				}
			}
		}

		// Token: 0x06001A39 RID: 6713 RVA: 0x000CCECC File Offset: 0x000CCECC
		public void ClearData()
		{
			this._samples.Clear();
			this._scroll.Value = 0;
			this._scroll.Maximum = 0;
			this._rpmMax = 8000;
			this._hoverSampleIdx = -1;
			this._hoverActive = false;
			this._mouseOverPlot = false;
			this._plotPanel.Invalidate();
		}

		// Token: 0x06001A3A RID: 6714 RVA: 0x000CCF28 File Offset: 0x000CCF28
		private void PlotPanel_Paint(object sender, PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
			int width = this._plotPanel.Width;
			int height = this._plotPanel.Height;
			if (width < 40 || height < 40)
			{
				return;
			}
			int num = 56;
			int num2 = 26;
			int num3;
			int num4;
			checked
			{
				num3 = width - 56 - 56;
				num4 = height - 26 - 24;
				if (num3 < 20 || num4 < 20)
				{
					return;
				}
				graphics.FillRectangle(this._panelBrush, num, num2, num3, num4);
				for (int i = 0; i <= 4; i++)
				{
					float num5 = (float)i / 4f;
					int num6 = num2 + num4 - (int)(unchecked(num5 * (float)num4));
					graphics.DrawLine((i == 0 || i == 4) ? this._gridPenMajor : this._gridPen, num, num6, num + num3, num6);
					int num7 = (int)(unchecked((float)this._rpmMin + num5 * (float)(checked(this._rpmMax - this._rpmMin))));
					string text = (num7 >= 1000) ? (((float)num7 / 1000f).ToString("0.#") + "k") : num7.ToString();
					SizeF sizeF = graphics.MeasureString(text, this._fontAxis);
					unchecked
					{
						graphics.DrawString(text, this._fontAxis, this._rpmBrush, (float)num - sizeF.Width - 4f, (float)num6 - sizeF.Height / 2f);
						string s4 = checked((int)(unchecked(num5 * 100f))) + "%";
						graphics.DrawString(s4, this._fontAxis, this._tpsBrush, (float)(checked(num + num3 + 4)), (float)num6 - sizeF.Height / 2f);
						string s2 = (10f + num5 * 10f).ToString("0");
						graphics.DrawString(s2, this._fontAxis, this._afrBrush, (float)(checked(num + num3 + 30)), (float)num6 - sizeF.Height / 2f);
					}
				}
				int value = this._scroll.Value;
				int num8 = value / 4;
				int num9 = Math.Min(this._samples.Count, num8 + num3 / 4 + 2);
				for (int j = num8; j < num9; j++)
				{
					if (j >= 0 && j < this._samples.Count)
					{
						int num10 = num + (j * 4 - value);
						if (num10 >= num && num10 <= num + num3 && j % 10 == 0)
						{
							graphics.DrawLine(this._gridPen, num10, num2, num10, num2 + num4);
							string s3 = this._samples[j].Time.ToString("HH:mm:ss");
							graphics.DrawString(s3, this._fontAxis, this._mutedBrush, (float)(num10 - 20), (float)(num2 + num4 + 4));
						}
					}
				}
				if (this._samples.Count >= 2)
				{
					if (this._chkRpm.Checked)
					{
						this.DrawSeries(graphics, (LiveTrackingChart.Sample s) => (float)(s.RPM - this._rpmMin) / (float)(this._rpmMax - this._rpmMin), this._rpmColor, num, num2, num3, num4, num8, num9, value);
					}
					if (this._chkTps.Checked)
					{
						this.DrawSeries(graphics, (LiveTrackingChart.Sample s) => s.TPS / 100f, this._tpsColor, num, num2, num3, num4, num8, num9, value);
					}
					unchecked
					{
						if (this._chkAfr.Checked)
						{
							this.DrawSeries(graphics, (LiveTrackingChart.Sample s) => (s.AFR - 10f) / 10f, this._afrColor, num, num2, num3, num4, num8, num9, value);
						}
						if (this._chkAd.Checked)
						{
							this.DrawSeries(graphics, (LiveTrackingChart.Sample s) => (s.AD + 100f) / 125f, this._adColor, num, num2, num3, num4, num8, num9, value);
						}
					}
				}
				graphics.DrawRectangle(this._borderPen, num, num2, num3, num4);
				this.DrawLegend(graphics, num + 8, num2 + 6);
				int num11 = -1;
				if (this._autoPopupEnabled && this._samples.Count > 0 && !this._mouseOverPlot)
				{
					if (this._autoScroll)
					{
						num11 = this._samples.Count - 1;
					}
					else
					{
						int num12 = (value + num3) / 4;
						if (num12 >= this._samples.Count)
						{
							num12 = this._samples.Count - 1;
						}
						if (num12 >= 0)
						{
							num11 = num12;
						}
					}
				}
				if (this._hoverActive && this._hoverSampleIdx >= 0 && this._hoverSampleIdx < this._samples.Count)
				{
					int num13 = num + (this._hoverSampleIdx * 4 - value);
					if (num13 >= num && num13 <= num + num3)
					{
						graphics.DrawLine(this._cursorPen, num13, num2, num13, num2 + num4);
						LiveTrackingChart.Sample sample = this._samples[this._hoverSampleIdx];
						if (this._chkRpm.Checked)
						{
							this.DrawHoverDot(graphics, num13, num2, num4, (float)(sample.RPM - this._rpmMin) / (float)(this._rpmMax - this._rpmMin), this._rpmColor);
						}
						if (this._chkTps.Checked)
						{
							this.DrawHoverDot(graphics, num13, num2, num4, sample.TPS / 100f, this._tpsColor);
						}
						unchecked
						{
							if (this._chkAfr.Checked)
							{
								this.DrawHoverDot(graphics, num13, num2, num4, (sample.AFR - 10f) / 10f, this._afrColor);
							}
							if (this._chkAd.Checked)
							{
								this.DrawHoverDot(graphics, num13, num2, num4, (sample.AD + 100f) / 125f, this._adColor);
							}
							this.DrawHoverTooltip(graphics, num13, num2, num3, num4, sample);
						}
					}
				}
				else if (num11 >= 0 && num11 < this._samples.Count)
				{
					int num14 = num + (num11 * 4 - value);
					if (num14 > num + num3)
					{
						num14 = num + num3;
					}
					if (num14 < num)
					{
						num14 = num;
					}
					LiveTrackingChart.Sample sample2 = this._samples[num11];
					using (Pen pen = new Pen(Color.FromArgb(140, this._cyan), 1f)
					{
						DashStyle = DashStyle.Dot
					})
					{
						graphics.DrawLine(pen, num14, num2, num14, num2 + num4);
					}
					if (this._chkRpm.Checked)
					{
						this.DrawHoverDot(graphics, num14, num2, num4, (float)(sample2.RPM - this._rpmMin) / (float)(this._rpmMax - this._rpmMin), this._rpmColor);
					}
					if (this._chkTps.Checked)
					{
						this.DrawHoverDot(graphics, num14, num2, num4, sample2.TPS / 100f, this._tpsColor);
					}
					unchecked
					{
						if (this._chkAfr.Checked)
						{
							this.DrawHoverDot(graphics, num14, num2, num4, (sample2.AFR - 10f) / 10f, this._afrColor);
						}
						if (this._chkAd.Checked)
						{
							this.DrawHoverDot(graphics, num14, num2, num4, (sample2.AD + 100f) / 125f, this._adColor);
						}
						this.DrawHoverTooltip(graphics, num14, num2, num3, num4, sample2);
					}
				}
			}
			if (this._samples.Count == 0)
			{
				string text2 = "Menunggu data live... (start LIVE DATA + buka chart ini)";
				SizeF sizeF2 = graphics.MeasureString(text2, this._fontEmpty);
				graphics.DrawString(text2, this._fontEmpty, this._mutedBrush, (float)num + ((float)num3 - sizeF2.Width) / 2f, (float)num2 + ((float)num4 - sizeF2.Height) / 2f);
			}
		}

		// Token: 0x06001A3B RID: 6715 RVA: 0x000CD6D8 File Offset: 0x000CD6D8
		private void DrawLegend(Graphics g, int x, int y)
		{
			string[] array = new string[]
			{
				"RPM",
				"TPS",
				"AFR",
				"AD"
			};
			SolidBrush[] array2 = new SolidBrush[]
			{
				this._rpmBrush,
				this._tpsBrush,
				this._afrBrush,
				this._adBrush
			};
			bool[] array3 = new bool[]
			{
				this._chkRpm.Checked,
				this._chkTps.Checked,
				this._chkAfr.Checked,
				this._chkAd.Checked
			};
			int num = x;
			checked
			{
				for (int i = 0; i < array.Length; i++)
				{
					if (array3[i])
					{
						g.FillRectangle(array2[i], num, y + 4, 10, 3);
						g.DrawString(array[i], this._fontLegend, array2[i], (float)(num + 14), (float)y);
						num += 56;
					}
				}
			}
		}

		// Token: 0x06001A3C RID: 6716 RVA: 0x0000FBBC File Offset: 0x0000FBBC
		protected override void OnFormClosing(FormClosingEventArgs e)
		{
			this._samples.Clear();
			base.OnFormClosing(e);
		}

		// Token: 0x06001A3D RID: 6717 RVA: 0x000CD7C4 File Offset: 0x000CD7C4
		private void AllocGdi()
		{
			this._fontAxis = new Font("Consolas", 7.5f);
			this._fontLegend = new Font("Consolas", 8f, FontStyle.Bold);
			this._fontHover = new Font("Consolas", 8f, FontStyle.Bold);
			this._fontHoverBig = new Font("Consolas", 10f, FontStyle.Bold);
			this._fontEmpty = new Font("Segoe UI", 11f, FontStyle.Italic);
			this._fontTitle = new Font("Segoe UI", 9.5f, FontStyle.Bold);
			this._gridPen = new Pen(Color.FromArgb(35, this._border), 1f);
			this._gridPenMajor = new Pen(Color.FromArgb(70, this._border), 1f);
			this._borderPen = new Pen(this._border, 1f);
			this._cursorPen = new Pen(Color.FromArgb(180, this._cyan), 1f)
			{
				DashStyle = DashStyle.Dash
			};
			this._rpmBrush = new SolidBrush(this._rpmColor);
			this._tpsBrush = new SolidBrush(this._tpsColor);
			this._afrBrush = new SolidBrush(this._afrColor);
			this._adBrush = new SolidBrush(this._adColor);
			this._mutedBrush = new SolidBrush(this._muted);
			this._fgBrush = new SolidBrush(this._fg);
			this._panelBrush = new SolidBrush(this._bgPanel);
			this._hoverBgBrush = new SolidBrush(Color.FromArgb(230, 12, 18, 24));
		}

		// Token: 0x06001A3E RID: 6718 RVA: 0x000CD960 File Offset: 0x000CD960
		private void PlotPanel_MouseMove(object sender, MouseEventArgs e)
		{
			int width = this._plotPanel.Width;
			int height = this._plotPanel.Height;
			int num = 56;
			int num2 = 26;
			checked
			{
				int num3 = width - 56 - 56;
				int num4 = height - 26 - 24;
				if (e.X < num || e.X > num + num3 || e.Y < num2 || e.Y > num2 + num4 || this._samples.Count == 0)
				{
					if (this._mouseOverPlot)
					{
						this._mouseOverPlot = false;
						this._hoverActive = false;
						this._hoverSampleIdx = -1;
						this._plotPanel.Invalidate();
					}
					return;
				}
				this._mouseOverPlot = true;
				int value = this._scroll.Value;
				int num5 = (e.X - num + value) / 4;
				if (num5 < 0)
				{
					num5 = 0;
				}
				if (num5 >= this._samples.Count)
				{
					num5 = this._samples.Count - 1;
				}
				if (!this._hoverActive || this._hoverSampleIdx != num5)
				{
					this._hoverActive = true;
					this._hoverSampleIdx = num5;
					this._plotPanel.Invalidate();
				}
			}
		}

		// Token: 0x06001A3F RID: 6719 RVA: 0x000CDA70 File Offset: 0x000CDA70
		private void DrawSeries(Graphics g, Func<LiveTrackingChart.Sample, float> normalize, Color color, int plotX, int plotY, int plotW, int plotH, int firstIdx, int lastIdx, int scrollOffset)
		{
			checked
			{
				using (Pen pen = new Pen(color, 1.8f)
				{
					LineJoin = LineJoin.Round
				})
				{
					PointF? pointF = null;
					for (int i = firstIdx; i < lastIdx; i++)
					{
						if (i >= 0 && i < this._samples.Count)
						{
							float num = Math.Max(0f, Math.Min(1f, normalize(this._samples[i])));
							float x = (float)(plotX + (i * 4 - scrollOffset));
							float y = unchecked((float)(checked(plotY + plotH)) - num * (float)plotH);
							PointF value = new PointF(x, y);
							if (pointF != null)
							{
								float num2 = Math.Max((float)plotX, pointF.Value.X);
								float num3 = Math.Min((float)(plotX + plotW), value.X);
								if (num3 >= num2)
								{
									g.DrawLine(pen, new PointF(num2, pointF.Value.Y), new PointF(num3, value.Y));
								}
							}
							pointF = new PointF?(value);
						}
					}
				}
			}
		}

		// Token: 0x06001A40 RID: 6720 RVA: 0x000CDBA0 File Offset: 0x000CDBA0
		private void DrawHoverDot(Graphics g, int x, int plotY, int plotH, float normalized, Color color)
		{
			float num = (float)(checked(plotY + plotH)) - Math.Max(0f, Math.Min(1f, normalized)) * (float)plotH;
			using (SolidBrush solidBrush = new SolidBrush(color))
			{
				g.FillEllipse(solidBrush, (float)(checked(x - 4)), num - 4f, 8f, 8f);
			}
			using (Pen pen = new Pen(Color.White, 1.2f))
			{
				g.DrawEllipse(pen, (float)(checked(x - 4)), num - 4f, 8f, 8f);
			}
		}

		// Token: 0x06001A41 RID: 6721 RVA: 0x000CDC54 File Offset: 0x000CDC54
		private void DrawHoverTooltip(Graphics g, int hx, int plotY, int plotW, int plotH, LiveTrackingChart.Sample s)
		{
			string[] array = new string[]
			{
				s.Time.ToString("HH:mm:ss.fff"),
				string.Format("RPM: {0,5}", s.RPM),
				string.Format("TPS: {0,5:F1}%", s.TPS),
				string.Format("AFR: {0,5:F1}", s.AFR),
				string.Format("AD:  {0,5:F1}", s.AD)
			};
			Color[] array2 = new Color[]
			{
				this._cyan,
				this._rpmColor,
				this._tpsColor,
				this._afrColor,
				this._adColor
			};
			float num = 0f;
			float num2 = 0f;
			checked
			{
				for (int i = 0; i < array.Length; i++)
				{
					Font font = (i == 0) ? this._fontHover : this._fontHoverBig;
					SizeF sizeF = g.MeasureString(array[i], font);
					if (sizeF.Width > num)
					{
						num = sizeF.Width;
					}
					if (sizeF.Height > num2)
					{
						num2 = sizeF.Height;
					}
				}
			}
			num += 16f;
			float num3 = num2 * (float)array.Length + 12f;
			float num4 = (float)(checked(hx + 12));
			if (num4 + num > (float)(checked(56 + plotW - 4)))
			{
				num4 = (float)hx - num - 12f;
			}
			float num5 = (float)(checked(plotY + 8));
			if (num5 + num3 > (float)(checked(plotY + plotH - 4)))
			{
				num5 = (float)(checked(plotY + plotH)) - num3 - 4f;
			}
			RectangleF rect = new RectangleF(num4, num5, num, num3);
			g.FillRectangle(this._hoverBgBrush, rect);
			g.DrawRectangle(this._cursorPen, rect.X, rect.Y, rect.Width, rect.Height);
			for (int j = 0; j < array.Length; j = checked(j + 1))
			{
				Font font2 = (j == 0) ? this._fontHover : this._fontHoverBig;
				using (SolidBrush solidBrush = new SolidBrush(array2[j]))
				{
					g.DrawString(array[j], font2, solidBrush, num4 + 8f, num5 + 6f + (float)j * num2);
				}
			}
		}

		// Token: 0x06001A43 RID: 6723
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x06001A44 RID: 6724
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		// Token: 0x06001A45 RID: 6725 RVA: 0x0008EF50 File Offset: 0x0008EF50
		private static GraphicsPath CreateRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			if (rect.Width <= 0 || rect.Height <= 0)
			{
				return graphicsPath;
			}
			checked
			{
				int num = radius * 2;
				if (num > rect.Width)
				{
					num = rect.Width;
				}
				if (num > rect.Height)
				{
					num = rect.Height;
				}
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x06001A46 RID: 6726 RVA: 0x000CE008 File Offset: 0x000CE008
		private void ApplyRoundedRegion()
		{
			if (base.Width <= 0 || base.Height <= 0)
			{
				return;
			}
			try
			{
				using (GraphicsPath graphicsPath = LiveTrackingChart.CreateRoundedPath(new Rectangle(0, 0, base.Width, base.Height), 14))
				{
					Region region = base.Region;
					base.Region = new Region(graphicsPath);
					if (region != null)
					{
						region.Dispose();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06001A47 RID: 6727 RVA: 0x000CE090 File Offset: 0x000CE090
		private void BuildTitleBar()
		{
			this._titleBar = new Panel
			{
				Dock = DockStyle.Top,
				Height = 36,
				BackColor = this._bgPanel,
				Padding = new Padding(10, 0, 10, 0)
			};
			PictureBox pictureBox = new PictureBox();
			pictureBox.Name = "picLogo";
			pictureBox.BackColor = Color.Transparent;
			pictureBox.Location = new Point(10, 0);
			pictureBox.Size = new Size(130, 38);
			pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
			pictureBox.TabStop = false;
			pictureBox.Cursor = Cursors.Default;
			try
			{
				ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Honda_Flash_Tools.Net.FormMain));
				pictureBox.Image = (Image)componentResourceManager.GetObject("pictureBox1.Image");
			}
			catch
			{
				pictureBox.Image = null;
			}
			this._titleBar.Controls.Add(pictureBox);
			this._lblIcon = new Label
			{
				Text = "\ud83d\udcc8",
				Font = new Font("Segoe UI", 12f),
				ForeColor = this._cyan,
				Location = new Point(45, 8),
				AutoSize = true,
				BackColor = Color.Transparent
			};
			this._lblTitle = new Label
			{
				Text = "LIVE CHART TRACKING",
				Font = this._fontTitle,
				ForeColor = this._cyan,
				Location = new Point(139, 10),
				AutoSize = true,
				BackColor = Color.Transparent,
				Cursor = Cursors.SizeAll
			};
			this._btnClose = this.MakeRoundedButton("✕", 0, 6, 32, 28, this._danger);
			this._btnClose.Click += delegate(object s, EventArgs e)
			{
				base.Close();
			};
			this._btnMaximize = this.MakeRoundedButton("⛶", 0, 6, 32, 28, this._cyan);
			this._btnMaximize.Click += delegate(object s, EventArgs e)
			{
				this.ToggleMaximize();
			};
			this._btnMinimize = this.MakeRoundedButton("—", 0, 6, 32, 28, this._fg);
			this._btnMinimize.Click += delegate(object s, EventArgs e)
			{
				base.WindowState = FormWindowState.Minimized;
			};
			this._titleBar.Controls.Add(this._lblIcon);
			this._titleBar.Controls.Add(this._lblTitle);
			this._titleBar.Controls.Add(this._btnClose);
			this._titleBar.Controls.Add(this._btnMaximize);
			this._titleBar.Controls.Add(this._btnMinimize);
			this._titleBar.Resize += checked(delegate(object s, EventArgs e)
			{
				this._btnClose.Location = new Point(this._titleBar.Width - 40, 6);
				this._btnMaximize.Location = new Point(this._titleBar.Width - 78, 6);
				this._btnMinimize.Location = new Point(this._titleBar.Width - 116, 6);
			});
			MouseEventHandler value = delegate(object s, MouseEventArgs e)
			{
				if (e.Button == MouseButtons.Left)
				{
					if (this._isMaximized)
					{
						this.ToggleMaximize();
					}
					LiveTrackingChart.ReleaseCapture();
					LiveTrackingChart.SendMessage(base.Handle, 161, 2, 0);
				}
			};
			this._titleBar.MouseDown += value;
			this._lblTitle.MouseDown += value;
			this._lblIcon.MouseDown += value;
			pictureBox.MouseDown += value;
			EventHandler value2 = delegate(object s, EventArgs e)
			{
				this.ToggleMaximize();
			};
			this._titleBar.DoubleClick += value2;
			this._lblTitle.DoubleClick += value2;
			this._lblIcon.DoubleClick += value2;
		}

		// Token: 0x06001A48 RID: 6728 RVA: 0x000CE3BC File Offset: 0x000CE3BC
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			if (base.Width < 5 || base.Height < 5)
			{
				return;
			}
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			using (GraphicsPath graphicsPath = LiveTrackingChart.CreateRoundedPath(checked(new Rectangle(2, 2, base.Width - 5, base.Height - 5)), 14))
			{
				using (Pen pen = new Pen(Color.FromArgb(25, 0, 255, 230), 8f))
				{
					using (Pen pen2 = new Pen(Color.FromArgb(60, 0, 255, 230), 5f))
					{
						using (Pen pen3 = new Pen(Color.FromArgb(120, 0, 255, 230), 2f))
						{
							using (Pen pen4 = new Pen(this._cyan, 1.2f))
							{
								graphics.DrawPath(pen, graphicsPath);
								graphics.DrawPath(pen2, graphicsPath);
								graphics.DrawPath(pen3, graphicsPath);
								graphics.DrawPath(pen4, graphicsPath);
							}
						}
					}
				}
			}
		}

		// Token: 0x06001A49 RID: 6729 RVA: 0x000CE51C File Offset: 0x000CE51C
		private Button MakeRoundedButton(string text, int x, int y, int w, int h, Color accent)
		{
			Button b = new Button
			{
				Text = text,
				Location = new Point(x, y),
				Size = new Size(w, h),
				FlatStyle = FlatStyle.Flat,
				BackColor = this._bgCard,
				ForeColor = accent,
				Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
				Cursor = Cursors.Hand,
				UseVisualStyleBackColor = false
			};
			b.FlatAppearance.BorderSize = 0;
			b.FlatAppearance.MouseOverBackColor = Color.Transparent;
			b.FlatAppearance.MouseDownBackColor = Color.Transparent;
			b.Paint += delegate(object s, PaintEventArgs ev)
			{
				Button button = (Button)s;
				ev.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				using (GraphicsPath graphicsPath = LiveTrackingChart.CreateRoundedPath(checked(new Rectangle(0, 0, button.Width - 1, button.Height - 1)), 8))
				{
					using (SolidBrush solidBrush = new SolidBrush(button.BackColor))
					{
						ev.Graphics.FillPath(solidBrush, graphicsPath);
						using (Pen pen = new Pen(button.ForeColor, 1.4f))
						{
							ev.Graphics.DrawPath(pen, graphicsPath);
						}
					}
				}
				TextRenderer.DrawText(ev.Graphics, button.Text, button.Font, button.ClientRectangle, button.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			};
			b.MouseEnter += delegate(object s, EventArgs e)
			{
				b.BackColor = Color.FromArgb(30, 42, 52);
				b.Invalidate();
			};
			b.MouseLeave += delegate(object s, EventArgs e)
			{
				b.BackColor = this._bgCard;
				b.Invalidate();
			};
			return b;
		}

		// Token: 0x06001A4A RID: 6730 RVA: 0x000CE640 File Offset: 0x000CE640
		private void ToggleMaximize()
		{
			if (!this._isMaximized)
			{
				this._restoreBounds = base.Bounds;
				this._isMaximized = true;
				Screen screen = Screen.FromControl(this);
				base.Bounds = screen.WorkingArea;
				this._btnMaximize.Text = "❐";
			}
			else
			{
				this._isMaximized = false;
				base.Bounds = this._restoreBounds;
				this._btnMaximize.Text = "⛶";
			}
			this._btnMaximize.Invalidate();
			this.ApplyRoundedRegion();
		}

		// Token: 0x040020D5 RID: 8405
		private readonly List<LiveTrackingChart.Sample> _samples = new List<LiveTrackingChart.Sample>();

		// Token: 0x040020D6 RID: 8406
		private const int MAX_SAMPLES = 400;

		// Token: 0x040020D7 RID: 8407
		private const int PIXELS_PER_SAMPLE = 4;

		// Token: 0x040020D8 RID: 8408
		private readonly Color _bgDark = Color.FromArgb(10, 15, 20);

		// Token: 0x040020D9 RID: 8409
		private readonly Color _bgPanel = Color.FromArgb(16, 23, 30);

		// Token: 0x040020DA RID: 8410
		private readonly Color _bgCard = Color.FromArgb(20, 28, 36);

		// Token: 0x040020DB RID: 8411
		private readonly Color _cyan = Color.FromArgb(0, 255, 230);

		// Token: 0x040020DC RID: 8412
		private readonly Color _green = Color.FromArgb(0, 255, 150);

		// Token: 0x040020DD RID: 8413
		private readonly Color _fg = Color.FromArgb(225, 238, 245);

		// Token: 0x040020DE RID: 8414
		private readonly Color _muted = Color.FromArgb(135, 158, 174);

		// Token: 0x040020DF RID: 8415
		private readonly Color _border = Color.FromArgb(30, 45, 60);

		// Token: 0x040020E0 RID: 8416
		private readonly Color _rpmColor;

		// Token: 0x040020E1 RID: 8417
		private readonly Color _tpsColor;

		// Token: 0x040020E2 RID: 8418
		private readonly Color _afrColor;

		// Token: 0x040020E3 RID: 8419
		private readonly Color _adColor;

		// Token: 0x040020E4 RID: 8420
		private HScrollBar _scroll;

		// Token: 0x040020E5 RID: 8421
		private Label _statusBar;

		// Token: 0x040020E6 RID: 8422
		private CheckBox _chkRpm;

		// Token: 0x040020E7 RID: 8423
		private CheckBox _chkTps;

		// Token: 0x040020E8 RID: 8424
		private CheckBox _chkAfr;

		// Token: 0x040020E9 RID: 8425
		private CheckBox _chkAd;

		// Token: 0x040020EA RID: 8426
		private CheckBox _chkAutoScroll;

		// Token: 0x040020EB RID: 8427
		private Button _btnPause;

		// Token: 0x040020EC RID: 8428
		private bool _autoScroll;

		// Token: 0x040020ED RID: 8429
		private bool _paused;

		// Token: 0x040020EE RID: 8430
		private int _rpmMin;

		// Token: 0x040020EF RID: 8431
		private int _rpmMax;

		// Token: 0x040020F0 RID: 8432
		private const int PLOT_LEFT = 56;

		// Token: 0x040020F1 RID: 8433
		private const int PLOT_RIGHT = 56;

		// Token: 0x040020F2 RID: 8434
		private const int PLOT_TOP = 26;

		// Token: 0x040020F3 RID: 8435
		private const int PLOT_BOTTOM = 24;

		// Token: 0x040020F4 RID: 8436
		private const int STATUS_INTERVAL_MS = 333;

		// Token: 0x040020F5 RID: 8437
		private const int REPAINT_INTERVAL_MS = 100;

		// Token: 0x04002107 RID: 8455
		private LiveTrackingChart.DoubleBufferedPanel _plotPanel;

		// Token: 0x04002108 RID: 8456
		private DateTime _lastStatusUpdate;

		// Token: 0x04002109 RID: 8457
		private DateTime _lastInvalidate;

		// Token: 0x0400210A RID: 8458
		private int _hoverSampleIdx;

		// Token: 0x0400210B RID: 8459
		private bool _hoverActive;

		// Token: 0x0400210C RID: 8460
		private const int CORNER_RADIUS = 14;

		// Token: 0x0400210D RID: 8461
		private const int TITLE_BAR_HEIGHT = 36;

		// Token: 0x0400210E RID: 8462
		private const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x0400210F RID: 8463
		private const int HT_CAPTION = 2;

		// Token: 0x04002110 RID: 8464
		private readonly Color _danger = Color.FromArgb(255, 90, 105);

		// Token: 0x04002112 RID: 8466
		private Panel _titleBar;

		// Token: 0x04002113 RID: 8467
		private Label _lblTitle;

		// Token: 0x04002114 RID: 8468
		private Button _btnClose;

		// Token: 0x04002115 RID: 8469
		private Button _btnMinimize;

		// Token: 0x04002116 RID: 8470
		private Label _lblIcon;

		// Token: 0x04002117 RID: 8471
		private Button _btnAutoPopup;

		// Token: 0x04002118 RID: 8472
		private bool _autoPopupEnabled;

		// Token: 0x04002119 RID: 8473
		private bool _mouseOverPlot;

		// Token: 0x0400211A RID: 8474
		private Button _btnMaximize;

		// Token: 0x0400211B RID: 8475
		private Rectangle _restoreBounds;

		// Token: 0x0400211C RID: 8476
		private bool _isMaximized;

		// Token: 0x0200095F RID: 2399
		private class Sample
		{
			// Token: 0x0400211D RID: 8477
			public int RPM;

			// Token: 0x0400211E RID: 8478
			public float TPS;

			// Token: 0x0400211F RID: 8479
			public float AFR;

			// Token: 0x04002120 RID: 8480
			public float AD;

			// Token: 0x04002121 RID: 8481
			public DateTime Time;
		}

		// Token: 0x02000961 RID: 2401
		internal class DoubleBufferedPanel : Panel
		{
			// Token: 0x06001A68 RID: 6760 RVA: 0x00008955 File Offset: 0x00008955
			public DoubleBufferedPanel()
			{
				this.DoubleBuffered = true;
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
				base.UpdateStyles();
			}

			// Token: 0x06001A69 RID: 6761 RVA: 0x000026F4 File Offset: 0x000026F4
			protected override void OnPaintBackground(PaintEventArgs e)
			{
			}
		}
	}
}
