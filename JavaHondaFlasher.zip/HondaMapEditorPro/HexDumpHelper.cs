﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace HondaMapEditorPro
{
	// Token: 0x020008C8 RID: 2248
	public static class HexDumpHelper
	{
		// Token: 0x060019B2 RID: 6578 RVA: 0x000CAE8C File Offset: 0x000CAE8C
		public static bool LooksLikeHexDump(string path)
		{
			checked
			{
				bool result;
				try
				{
					if (!File.Exists(path))
					{
						result = false;
					}
					else
					{
						FileInfo fileInfo = new FileInfo(path);
						if (fileInfo.Length == 0L)
						{
							result = false;
						}
						else
						{
							byte[] array = new byte[Math.Min(4096, (int)Math.Min(fileInfo.Length, 2147483647L))];
							using (FileStream fileStream = File.OpenRead(path))
							{
								int i;
								int num;
								for (i = 0; i < array.Length; i += num)
								{
									num = fileStream.Read(array, i, array.Length - i);
									if (num <= 0)
									{
										break;
									}
								}
								if (i < array.Length)
								{
									Array.Resize<byte>(ref array, i);
								}
							}
							if (array.Length >= 5)
							{
								string @string = Encoding.ASCII.GetString(array, 0, Math.Min(5, array.Length));
								if (@string.StartsWith("<!--") || @string.StartsWith("<XDF") || @string.StartsWith("<?xml") || @string.StartsWith("<xdf"))
								{
									return false;
								}
							}
							for (int j = 0; j < Math.Min(512, array.Length); j++)
							{
								if (array[j] == 0)
								{
									return false;
								}
							}
							string string2 = Encoding.ASCII.GetString(array);
							int num2 = 0;
							foreach (object obj in HexDumpHelper.HexTokenRegex.Matches(string2))
							{
								Match match = (Match)obj;
								num2++;
								if (num2 >= 16)
								{
									return true;
								}
							}
							result = false;
						}
					}
				}
				catch
				{
					result = false;
				}
				return result;
			}
		}

		// Token: 0x060019B3 RID: 6579 RVA: 0x000CB06C File Offset: 0x000CB06C
		public static byte[] DecodeHexDump(string path)
		{
			string text = File.ReadAllText(path, Encoding.ASCII);
			List<byte> list = new List<byte>(text.Length / 2);
			using (IEnumerator enumerator = HexDumpHelper.HexTokenRegex.Matches(text).GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					byte item;
					if (byte.TryParse(((Match)enumerator.Current).Groups[1].Value, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out item))
					{
						list.Add(item);
					}
				}
			}
			return list.ToArray();
		}

		// Token: 0x060019B4 RID: 6580 RVA: 0x000CB110 File Offset: 0x000CB110
		public static bool IsXmlPayload(byte[] data)
		{
			if (data == null || data.Length < 5)
			{
				return false;
			}
			string @string = Encoding.ASCII.GetString(data, 0, Math.Min(8, data.Length));
			return @string.StartsWith("<!--") || @string.StartsWith("<XDF") || @string.StartsWith("<?xml") || @string.StartsWith("<xdf");
		}

		// Token: 0x04001FC1 RID: 8129
		private static readonly Regex HexTokenRegex = new Regex("(?:0x)?([0-9A-Fa-f]{2})(?![0-9A-Fa-f])", RegexOptions.Compiled);
	}
}
