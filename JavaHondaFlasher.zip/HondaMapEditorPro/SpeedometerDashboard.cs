﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Honda_Flash_Tools.Net;

namespace HondaMapEditorPro
{
	// Token: 0x02000963 RID: 2403
	public partial class SpeedometerDashboard : Form
	{
		// Token: 0x06001A6D RID: 6765
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x06001A6E RID: 6766
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		// Token: 0x06001A6F RID: 6767 RVA: 0x000CE8F0 File Offset: 0x000CE8F0
		public SpeedometerDashboard()
		{
			this._samples = new List<SpeedometerDashboard.Sample>();
			this._bgDark = Color.FromArgb(10, 15, 20);
			this._bgPanel = Color.FromArgb(16, 23, 30);
			this._bgCard = Color.FromArgb(20, 28, 36);
			this._cyan = Color.FromArgb(0, 255, 230);
			this._green = Color.FromArgb(0, 255, 150);
			this._fg = Color.FromArgb(225, 238, 245);
			this._muted = Color.FromArgb(135, 158, 174);
			this._border = Color.FromArgb(30, 45, 60);
			this._danger = Color.FromArgb(255, 90, 105);
			this._rpmColor = Color.FromArgb(0, 160, 255);
			this._tpsColor = Color.FromArgb(255, 220, 0);
			this._afrColor = Color.FromArgb(80, 255, 120);
			this._adColor = Color.FromArgb(255, 120, 60);
			this.Text = "Speedometer Dashboard — MAP EDITOR";
			this.BackColor = this._bgDark;
			this.ForeColor = this._fg;
			this.Font = new Font("Segoe UI", 9f);
			base.ClientSize = new Size(1100, 720);
			this.MinimumSize = new Size(720, 600);
			base.StartPosition = FormStartPosition.CenterScreen;
			base.FormBorderStyle = FormBorderStyle.None;
			base.Padding = new Padding(6);
			this.DoubleBuffered = true;
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.UpdateStyles();
			this.BuildUI();
			this._repaintTimer = new Timer
			{
				Interval = 33
			};
			this._repaintTimer.Tick += delegate(object s, EventArgs e)
			{
				this.RepaintAll();
			};
			this._repaintTimer.Start();
			base.HandleCreated += delegate(object s, EventArgs e)
			{
				this.ApplyRoundedRegion();
			};
			base.Resize += delegate(object s, EventArgs e)
			{
				this.ApplyRoundedRegion();
			};
		}

		// Token: 0x06001A70 RID: 6768 RVA: 0x0008EF50 File Offset: 0x0008EF50
		private static GraphicsPath CreateRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			if (rect.Width <= 0 || rect.Height <= 0)
			{
				return graphicsPath;
			}
			checked
			{
				int num = radius * 2;
				if (num > rect.Width)
				{
					num = rect.Width;
				}
				if (num > rect.Height)
				{
					num = rect.Height;
				}
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x06001A71 RID: 6769 RVA: 0x000CEB10 File Offset: 0x000CEB10
		private void ApplyRoundedRegion()
		{
			if (base.Width <= 0 || base.Height <= 0)
			{
				return;
			}
			try
			{
				using (GraphicsPath graphicsPath = SpeedometerDashboard.CreateRoundedPath(new Rectangle(0, 0, base.Width, base.Height), 14))
				{
					Region region = base.Region;
					base.Region = new Region(graphicsPath);
					if (region != null)
					{
						region.Dispose();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06001A72 RID: 6770 RVA: 0x000CEB98 File Offset: 0x000CEB98
		private void BuildTitleBar()
		{
			this._titleBar = new Panel
			{
				Dock = DockStyle.Top,
				Height = 36,
				BackColor = this._bgPanel,
				Padding = new Padding(10, 0, 10, 0)
			};
			PictureBox pictureBox = new PictureBox();
			pictureBox.Name = "picLogo";
			pictureBox.BackColor = Color.Transparent;
			pictureBox.Location = new Point(10, 0);
			pictureBox.Size = new Size(130, 38);
			pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
			pictureBox.TabStop = false;
			pictureBox.Cursor = Cursors.Default;
			try
			{
				ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Honda_Flash_Tools.Net.FormMain));
				pictureBox.Image = (Image)componentResourceManager.GetObject("pictureBox1.Image");
			}
			catch
			{
				pictureBox.Image = null;
			}
			this._titleBar.Controls.Add(pictureBox);
			this._lblIcon = new Label
			{
				Text = "▶️",
				Font = new Font("Segoe UI", 12f),
				ForeColor = this._cyan,
				Location = new Point(45, 8),
				AutoSize = true,
				BackColor = Color.Transparent
			};
			this._lblTitle = new Label
			{
				Text = "SPEED DASHBOARD",
				Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
				ForeColor = this._cyan,
				Location = new Point(139, 10),
				AutoSize = true,
				BackColor = Color.Transparent,
				Cursor = Cursors.SizeAll
			};
			this._btnClose = this.MakeWindowButton("✕", this._danger);
			this._btnClose.Click += delegate(object s, EventArgs e)
			{
				base.Close();
			};
			this._btnMaximize = this.MakeWindowButton("⛶", this._cyan);
			this._btnMaximize.Click += delegate(object s, EventArgs e)
			{
				this.ToggleMaximize();
			};
			this._btnMinimize = this.MakeWindowButton("—", this._fg);
			this._btnMinimize.Click += delegate(object s, EventArgs e)
			{
				base.WindowState = FormWindowState.Minimized;
			};
			this._titleBar.Controls.Add(this._lblIcon);
			this._titleBar.Controls.Add(this._lblTitle);
			this._titleBar.Controls.Add(this._btnClose);
			this._titleBar.Controls.Add(this._btnMaximize);
			this._titleBar.Controls.Add(this._btnMinimize);
			this._titleBar.Resize += checked(delegate(object s, EventArgs e)
			{
				this._btnClose.Location = new Point(this._titleBar.Width - 40, 6);
				this._btnMaximize.Location = new Point(this._titleBar.Width - 78, 6);
				this._btnMinimize.Location = new Point(this._titleBar.Width - 116, 6);
			});
			MouseEventHandler value = delegate(object s, MouseEventArgs e)
			{
				if (e.Button == MouseButtons.Left)
				{
					if (this._isMaximized)
					{
						this.ToggleMaximize();
					}
					SpeedometerDashboard.ReleaseCapture();
					SpeedometerDashboard.SendMessage(base.Handle, 161, 2, 0);
				}
			};
			this._titleBar.MouseDown += value;
			this._lblTitle.MouseDown += value;
			this._lblIcon.MouseDown += value;
			pictureBox.MouseDown += value;
			EventHandler value2 = delegate(object s, EventArgs e)
			{
				this.ToggleMaximize();
			};
			this._titleBar.DoubleClick += value2;
			this._lblTitle.DoubleClick += value2;
			this._lblIcon.DoubleClick += value2;
		}

		// Token: 0x06001A73 RID: 6771 RVA: 0x000CEEBC File Offset: 0x000CEEBC
		private Button MakeWindowButton(string text, Color accent)
		{
			Button b = new Button
			{
				Text = text,
				Size = new Size(32, 28),
				Location = new Point(0, 6),
				FlatStyle = FlatStyle.Flat,
				BackColor = this._bgCard,
				ForeColor = accent,
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				Cursor = Cursors.Hand,
				TabStop = false,
				UseVisualStyleBackColor = false
			};
			b.FlatAppearance.BorderSize = 0;
			b.FlatAppearance.MouseOverBackColor = Color.Transparent;
			b.FlatAppearance.MouseDownBackColor = Color.Transparent;
			b.Paint += delegate(object s, PaintEventArgs ev)
			{
				Button button = (Button)s;
				ev.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				using (GraphicsPath graphicsPath = SpeedometerDashboard.CreateRoundedPath(checked(new Rectangle(0, 0, button.Width - 1, button.Height - 1)), 8))
				{
					using (SolidBrush solidBrush = new SolidBrush(button.BackColor))
					{
						ev.Graphics.FillPath(solidBrush, graphicsPath);
						using (Pen pen = new Pen(button.ForeColor, 1.4f))
						{
							ev.Graphics.DrawPath(pen, graphicsPath);
						}
					}
				}
				TextRenderer.DrawText(ev.Graphics, button.Text, button.Font, button.ClientRectangle, button.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			};
			b.MouseEnter += delegate(object s, EventArgs e)
			{
				b.BackColor = Color.FromArgb(30, 42, 52);
				b.Invalidate();
			};
			b.MouseLeave += delegate(object s, EventArgs e)
			{
				b.BackColor = this._bgCard;
				b.Invalidate();
			};
			return b;
		}

		// Token: 0x06001A74 RID: 6772 RVA: 0x000CEFE8 File Offset: 0x000CEFE8
		private void ToggleMaximize()
		{
			if (!this._isMaximized)
			{
				this._restoreBounds = base.Bounds;
				this._isMaximized = true;
				Screen screen = Screen.FromControl(this);
				base.Bounds = screen.WorkingArea;
				this._btnMaximize.Text = "❐";
			}
			else
			{
				this._isMaximized = false;
				base.Bounds = this._restoreBounds;
				this._btnMaximize.Text = "⛶";
			}
			this._btnMaximize.Invalidate();
			this.ApplyRoundedRegion();
		}

		// Token: 0x06001A75 RID: 6773 RVA: 0x000CF06C File Offset: 0x000CF06C
		private void BuildUI()
		{
			this.BuildTitleBar();
			this._grid = new TableLayoutPanel
			{
				Dock = DockStyle.Fill,
				ColumnCount = 2,
				RowCount = 2,
				BackColor = this._bgDark,
				Padding = new Padding(6)
			};
			this._grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
			this._grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
			this._grid.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
			this._grid.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
			this._gaugeRpm = this.MakeGaugePanel("RPM", this._rpmColor, 0.0, 12000.0, "0", "", true);
			this._gaugeTps = this.MakeGaugePanel("TPS", this._tpsColor, 0.0, 100.0, "0.0", "%", true);
			this._gaugeAfr = this.MakeGaugePanel("AFR", this._afrColor, 10.0, 20.0, "0.0", "", true);
			this._gaugeAd = this.MakeGaugePanel("AD", this._adColor, -100.0, 25.0, "0.0", "", true);
			this._grid.Controls.Add(this._gaugeRpm, 0, 0);
			this._grid.Controls.Add(this._gaugeTps, 1, 0);
			this._grid.Controls.Add(this._gaugeAfr, 0, 1);
			this._grid.Controls.Add(this._gaugeAd, 1, 1);
			this._statusBar = new Label
			{
				Dock = DockStyle.Bottom,
				Height = 26,
				BackColor = this._bgPanel,
				ForeColor = this._muted,
				Font = new Font("Consolas", 8.5f, FontStyle.Bold),
				Padding = new Padding(10, 4, 10, 4),
				Text = "RPM: —   TPS: —   AFR: —   AD: —"
			};
			base.Controls.Add(this._grid);
			base.Controls.Add(this._statusBar);
			base.Controls.Add(this._titleBar);
		}

		// Token: 0x06001A76 RID: 6774 RVA: 0x000CF2F0 File Offset: 0x000CF2F0
		private SpeedometerDashboard.GaugePanel MakeGaugePanel(string title, Color accent, double minVal, double maxVal, string format, string unit, bool arcZones)
		{
			return new SpeedometerDashboard.GaugePanel
			{
				Dock = DockStyle.Fill,
				BackColor = this._bgPanel,
				Margin = new Padding(4),
				Title = title,
				Accent = accent,
				MinValue = minVal,
				MaxValue = maxVal,
				Format = format,
				Unit = unit,
				ArcZones = arcZones
			};
		}

		// Token: 0x06001A77 RID: 6775 RVA: 0x000CF358 File Offset: 0x000CF358
		public void PushSample(int rpm, float tps, float afr, float ad)
		{
			this._samples.Add(new SpeedometerDashboard.Sample
			{
				RPM = rpm,
				TPS = tps,
				AFR = afr,
				AD = ad,
				Time = DateTime.Now
			});
			this._statusBar.Text = string.Format("RPM: {0,5}   TPS: {1,5:F1}%   AFR: {2,4:F1}   AD: {3,5:F1}", new object[]
			{
				rpm,
				tps,
				afr,
				ad
			});
		}

		// Token: 0x06001A78 RID: 6776 RVA: 0x000CF3E0 File Offset: 0x000CF3E0
		public void ClearData()
		{
			this._samples.Clear();
			this._smoothRpm = 0f;
			this._smoothTps = 0f;
			this._smoothAfr = 0f;
			this._smoothAd = 0f;
			this._statusBar.Text = "RPM: —   TPS: —   AFR: —   AD: —";
		}

		// Token: 0x06001A79 RID: 6777 RVA: 0x000CF434 File Offset: 0x000CF434
		private void RepaintAll()
		{
			int num = 0;
			float num2 = 0f;
			float num3 = 0f;
			float num4 = 0f;
			if (this._samples.Count > 0)
			{
				SpeedometerDashboard.Sample sample = this._samples[checked(this._samples.Count - 1)];
				num = sample.RPM;
				num2 = sample.TPS;
				num3 = sample.AFR;
				num4 = sample.AD;
			}
			this._smoothRpm += ((float)num - this._smoothRpm) * 0.18f;
			this._smoothTps += (num2 - this._smoothTps) * 0.18f;
			this._smoothAfr += (num3 - this._smoothAfr) * 0.18f;
			this._smoothAd += (num4 - this._smoothAd) * 0.18f;
			if (Math.Abs((float)num - this._smoothRpm) < 1f)
			{
				this._smoothRpm = (float)num;
			}
			if (Math.Abs(num2 - this._smoothTps) < 0.1f)
			{
				this._smoothTps = num2;
			}
			if (Math.Abs(num3 - this._smoothAfr) < 0.05f)
			{
				this._smoothAfr = num3;
			}
			if (Math.Abs(num4 - this._smoothAd) < 0.1f)
			{
				this._smoothAd = num4;
			}
			this._gaugeRpm.Value = (double)this._smoothRpm;
			this._gaugeTps.Value = (double)this._smoothTps;
			this._gaugeAfr.Value = (double)this._smoothAfr;
			this._gaugeAd.Value = (double)this._smoothAd;
			this._gaugeRpm.Invalidate();
			this._gaugeTps.Invalidate();
			this._gaugeAfr.Invalidate();
			this._gaugeAd.Invalidate();
			if (this._samples.Count > 200)
			{
				this._samples.RemoveRange(0, checked(this._samples.Count - 200));
			}
		}

		// Token: 0x06001A7A RID: 6778 RVA: 0x000CF614 File Offset: 0x000CF614
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			if (base.Width < 5 || base.Height < 5)
			{
				return;
			}
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			using (GraphicsPath graphicsPath = SpeedometerDashboard.CreateRoundedPath(checked(new Rectangle(2, 2, base.Width - 5, base.Height - 5)), 14))
			{
				using (Pen pen = new Pen(Color.FromArgb(25, 0, 255, 230), 8f))
				{
					using (Pen pen2 = new Pen(Color.FromArgb(60, 0, 255, 230), 5f))
					{
						using (Pen pen3 = new Pen(Color.FromArgb(120, 0, 255, 230), 2f))
						{
							using (Pen pen4 = new Pen(this._cyan, 1.2f))
							{
								graphics.DrawPath(pen, graphicsPath);
								graphics.DrawPath(pen2, graphicsPath);
								graphics.DrawPath(pen3, graphicsPath);
								graphics.DrawPath(pen4, graphicsPath);
							}
						}
					}
				}
			}
		}

		// Token: 0x06001A7B RID: 6779 RVA: 0x0000FD2A File Offset: 0x0000FD2A
		protected override void OnFormClosing(FormClosingEventArgs e)
		{
			if (this._repaintTimer != null)
			{
				this._repaintTimer.Stop();
				this._repaintTimer.Dispose();
			}
			base.OnFormClosing(e);
		}

		// Token: 0x04002129 RID: 8489
		private const int CORNER_RADIUS = 14;

		// Token: 0x0400212A RID: 8490
		private const int TITLE_BAR_HEIGHT = 36;

		// Token: 0x0400212B RID: 8491
		private const int REPAINT_MS = 33;

		// Token: 0x0400212C RID: 8492
		private const float SMOOTH_FACTOR = 0.18f;

		// Token: 0x0400212D RID: 8493
		private const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x0400212E RID: 8494
		private const int HT_CAPTION = 2;

		// Token: 0x0400212F RID: 8495
		private readonly List<SpeedometerDashboard.Sample> _samples;

		// Token: 0x04002130 RID: 8496
		private readonly Color _bgDark;

		// Token: 0x04002131 RID: 8497
		private readonly Color _bgPanel;

		// Token: 0x04002132 RID: 8498
		private readonly Color _bgCard;

		// Token: 0x04002133 RID: 8499
		private readonly Color _cyan;

		// Token: 0x04002134 RID: 8500
		private readonly Color _green;

		// Token: 0x04002135 RID: 8501
		private readonly Color _fg;

		// Token: 0x04002136 RID: 8502
		private readonly Color _muted;

		// Token: 0x04002137 RID: 8503
		private readonly Color _border;

		// Token: 0x04002138 RID: 8504
		private readonly Color _danger;

		// Token: 0x04002139 RID: 8505
		private readonly Color _rpmColor;

		// Token: 0x0400213A RID: 8506
		private readonly Color _tpsColor;

		// Token: 0x0400213B RID: 8507
		private readonly Color _afrColor;

		// Token: 0x0400213C RID: 8508
		private readonly Color _adColor;

		// Token: 0x0400213D RID: 8509
		private TableLayoutPanel _grid;

		// Token: 0x0400213E RID: 8510
		private SpeedometerDashboard.GaugePanel _gaugeRpm;

		// Token: 0x0400213F RID: 8511
		private SpeedometerDashboard.GaugePanel _gaugeTps;

		// Token: 0x04002140 RID: 8512
		private SpeedometerDashboard.GaugePanel _gaugeAfr;

		// Token: 0x04002141 RID: 8513
		private SpeedometerDashboard.GaugePanel _gaugeAd;

		// Token: 0x04002142 RID: 8514
		private Label _statusBar;

		// Token: 0x04002143 RID: 8515
		private Panel _titleBar;

		// Token: 0x04002144 RID: 8516
		private Label _lblTitle;

		// Token: 0x04002145 RID: 8517
		private Button _btnClose;

		// Token: 0x04002146 RID: 8518
		private Button _btnMinimize;

		// Token: 0x04002147 RID: 8519
		private Button _btnMaximize;

		// Token: 0x04002148 RID: 8520
		private Label _lblIcon;

		// Token: 0x04002149 RID: 8521
		private Rectangle _restoreBounds;

		// Token: 0x0400214A RID: 8522
		private bool _isMaximized;

		// Token: 0x0400214B RID: 8523
		private float _smoothRpm;

		// Token: 0x0400214C RID: 8524
		private float _smoothTps;

		// Token: 0x0400214D RID: 8525
		private float _smoothAfr;

		// Token: 0x0400214E RID: 8526
		private float _smoothAd;

		// Token: 0x0400214F RID: 8527
		private readonly Timer _repaintTimer;

		// Token: 0x04002150 RID: 8528
		private const float SMOOTH_SNAP_MIN = 0.05f;

		// Token: 0x02000964 RID: 2404
		private class Sample
		{
			// Token: 0x04002151 RID: 8529
			public int RPM;

			// Token: 0x04002152 RID: 8530
			public float TPS;

			// Token: 0x04002153 RID: 8531
			public float AFR;

			// Token: 0x04002154 RID: 8532
			public float AD;

			// Token: 0x04002155 RID: 8533
			public DateTime Time;
		}

		// Token: 0x02000965 RID: 2405
		private sealed class GaugePanel : Panel
		{
			// Token: 0x17000195 RID: 405
			// (get) Token: 0x06001A86 RID: 6790 RVA: 0x0000FD9F File Offset: 0x0000FD9F
			// (set) Token: 0x06001A87 RID: 6791 RVA: 0x0000FDA7 File Offset: 0x0000FDA7
			public string Title { get; set; } = "RPM";

			// Token: 0x17000196 RID: 406
			// (get) Token: 0x06001A88 RID: 6792 RVA: 0x0000FDB0 File Offset: 0x0000FDB0
			// (set) Token: 0x06001A89 RID: 6793 RVA: 0x0000FDB8 File Offset: 0x0000FDB8
			public Color Accent { get; set; } = Color.Cyan;

			// Token: 0x17000197 RID: 407
			// (get) Token: 0x06001A8A RID: 6794 RVA: 0x0000FDC1 File Offset: 0x0000FDC1
			// (set) Token: 0x06001A8B RID: 6795 RVA: 0x0000FDC9 File Offset: 0x0000FDC9
			public double MinValue { get; set; }

			// Token: 0x17000198 RID: 408
			// (get) Token: 0x06001A8C RID: 6796 RVA: 0x0000FDD2 File Offset: 0x0000FDD2
			// (set) Token: 0x06001A8D RID: 6797 RVA: 0x0000FDDA File Offset: 0x0000FDDA
			public double MaxValue { get; set; } = 12000.0;

			// Token: 0x17000199 RID: 409
			// (get) Token: 0x06001A8E RID: 6798 RVA: 0x0000FDE3 File Offset: 0x0000FDE3
			// (set) Token: 0x06001A8F RID: 6799 RVA: 0x0000FDEB File Offset: 0x0000FDEB
			public string Format { get; set; } = "0";

			// Token: 0x1700019A RID: 410
			// (get) Token: 0x06001A90 RID: 6800 RVA: 0x0000FDF4 File Offset: 0x0000FDF4
			// (set) Token: 0x06001A91 RID: 6801 RVA: 0x0000FDFC File Offset: 0x0000FDFC
			public string Unit { get; set; } = "";

			// Token: 0x1700019B RID: 411
			// (get) Token: 0x06001A92 RID: 6802 RVA: 0x0000FE05 File Offset: 0x0000FE05
			// (set) Token: 0x06001A93 RID: 6803 RVA: 0x0000FE0D File Offset: 0x0000FE0D
			public bool ArcZones { get; set; } = true;

			// Token: 0x1700019C RID: 412
			// (get) Token: 0x06001A94 RID: 6804 RVA: 0x0000FE16 File Offset: 0x0000FE16
			// (set) Token: 0x06001A95 RID: 6805 RVA: 0x0000FE1E File Offset: 0x0000FE1E
			public double Value { get; set; }

			// Token: 0x06001A96 RID: 6806 RVA: 0x000CF7E0 File Offset: 0x000CF7E0
			public GaugePanel()
			{
				this.DoubleBuffered = true;
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
				base.UpdateStyles();
				this._fontTitle = new Font("Segoe UI", 11f, FontStyle.Bold);
				this._fontVal = new Font("Consolas", 22f, FontStyle.Bold);
				this._fontTick = new Font("Consolas", 7f, FontStyle.Bold);
			}

			// Token: 0x06001A97 RID: 6807 RVA: 0x0000FE27 File Offset: 0x0000FE27
			protected override void Dispose(bool disposing)
			{
				if (disposing)
				{
					Font fontTitle = this._fontTitle;
					if (fontTitle != null)
					{
						fontTitle.Dispose();
					}
					Font fontVal = this._fontVal;
					if (fontVal != null)
					{
						fontVal.Dispose();
					}
					Font fontTick = this._fontTick;
					if (fontTick != null)
					{
						fontTick.Dispose();
					}
				}
				base.Dispose(disposing);
			}

			// Token: 0x06001A98 RID: 6808 RVA: 0x000026F4 File Offset: 0x000026F4
			protected override void OnPaintBackground(PaintEventArgs e)
			{
			}

			// Token: 0x06001A99 RID: 6809 RVA: 0x000CF94C File Offset: 0x000CF94C
			protected override void OnPaint(PaintEventArgs e)
			{
				Graphics graphics = e.Graphics;
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
				graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
				int width = base.Width;
				int height = base.Height;
				if (width < 100 || height < 100)
				{
					return;
				}
				int num;
				int num2;
				int num3;
				float num4;
				float num5;
				RectangleF rect3;
				checked
				{
					using (GraphicsPath graphicsPath = SpeedometerDashboard.GaugePanel.CreateRoundedPath(new Rectangle(2, 2, width - 4, height - 4), 10))
					{
						using (SolidBrush solidBrush = new SolidBrush(this._bgCard))
						{
							graphics.FillPath(solidBrush, graphicsPath);
						}
						using (Pen pen = new Pen(Color.FromArgb(80, this.Accent), 1.2f))
						{
							graphics.DrawPath(pen, graphicsPath);
						}
					}
					num = width / 2;
					num2 = height / 2 + 5;
					num3 = Math.Min(width, height) / 2 - 15;
					if (num3 < 30)
					{
						num3 = 30;
					}
					Rectangle rect = new Rectangle(num - num3, num2 - num3, num3 * 2, num3 * 2);
					using (Pen pen2 = new Pen(Color.FromArgb(100, 0, 255, 220), 4f))
					{
						graphics.DrawEllipse(pen2, rect);
					}
					using (Pen pen3 = new Pen(Color.FromArgb(0, 255, 220), 1.5f))
					{
						graphics.DrawEllipse(pen3, rect);
					}
					Rectangle rect2 = new Rectangle(num - num3 + 5, num2 - num3 + 5, (num3 - 5) * 2, (num3 - 5) * 2);
					using (Pen pen4 = new Pen(Color.FromArgb(60, 0, 255, 220), 1f))
					{
						graphics.DrawEllipse(pen4, rect2);
					}
					num4 = 135f;
					num5 = 270f;
					rect3 = new RectangleF((float)(num - num3 + 15), (float)(num2 - num3 + 15), (float)((num3 - 15) * 2), (float)((num3 - 15) * 2));
					using (Pen pen5 = new Pen(Color.FromArgb(22, 27, 34), 8f))
					{
						pen5.StartCap = LineCap.Round;
						pen5.EndCap = LineCap.Round;
						graphics.DrawArc(pen5, rect3, num4, num5);
					}
				}
				double num6 = Math.Max(0.0, Math.Min(1.0, (this.Value - this.MinValue) / (this.MaxValue - this.MinValue)));
				float num7 = (float)((double)num5 * num6);
				if (num7 > 0f)
				{
					using (Pen pen6 = new Pen(this.Accent, 8f))
					{
						pen6.StartCap = LineCap.Round;
						pen6.EndCap = LineCap.Round;
						graphics.DrawArc(pen6, rect3, num4, num7);
					}
				}
				int num8 = 14;
				if (this.Title == "TPS")
				{
					num8 = 10;
				}
				else if (this.Title == "AFR")
				{
					num8 = 10;
				}
				else if (this.Title == "AD")
				{
					num8 = 10;
				}
				for (int i = 0; i <= num8; i = checked(i + 1))
				{
					float num9 = (float)i / (float)num8;
					double num10 = (double)(num4 + num5 * num9) * 3.141592653589793 / 180.0;
					float num11 = (float)num3 - 18f;
					float num12 = (float)num3 - 28f;
					float x = (float)num + (float)(Math.Cos(num10) * (double)num11);
					float y = (float)num2 + (float)(Math.Sin(num10) * (double)num11);
					float x2 = (float)num + (float)(Math.Cos(num10) * (double)num12);
					float y2 = (float)num2 + (float)(Math.Sin(num10) * (double)num12);
					bool flag = this.Title == "RPM" && i >= 10;
					Color color = flag ? Color.FromArgb(255, 50, 50) : Color.FromArgb(200, 210, 220);
					using (Pen pen7 = new Pen(color, flag ? 2f : 1.5f))
					{
						graphics.DrawLine(pen7, x, y, x2, y2);
					}
					if (num3 > 60 && (i % 2 == 0 || num8 <= 10))
					{
						string text = (this.Title == "RPM") ? i.ToString() : Math.Round(this.MaxValue / (double)num8 * (double)i).ToString();
						using (Font font = new Font("Segoe UI", 7f, FontStyle.Bold))
						{
							SizeF sizeF = graphics.MeasureString(text, font);
							float x3 = (float)num + (float)(Math.Cos(num10) * (double)(num12 - 12f)) - sizeF.Width / 2f;
							float y3 = (float)num2 + (float)(Math.Sin(num10) * (double)(num12 - 12f)) - sizeF.Height / 2f;
							using (SolidBrush solidBrush2 = new SolidBrush(color))
							{
								graphics.DrawString(text, font, solidBrush2, x3, y3);
							}
						}
					}
				}
				double num13 = (double)(num4 + num7) * 3.141592653589793 / 180.0;
				float num14 = (float)num3 - 35f;
				float x4 = (float)num + (float)(Math.Cos(num13) * (double)num14);
				float y4 = (float)num2 + (float)(Math.Sin(num13) * (double)num14);
				using (Pen pen8 = new Pen(this.Accent, 3f))
				{
					pen8.StartCap = LineCap.Round;
					pen8.EndCap = LineCap.Round;
					graphics.DrawLine(pen8, (float)num, (float)num2, x4, y4);
				}
				using (SolidBrush solidBrush3 = new SolidBrush(Color.FromArgb(30, 35, 40)))
				{
					graphics.FillEllipse(solidBrush3, (float)num - 8f, (float)num2 - 8f, 16f, 16f);
				}
				using (Pen pen9 = new Pen(this.Accent, 2f))
				{
					graphics.DrawEllipse(pen9, (float)num - 8f, (float)num2 - 8f, 16f, 16f);
				}
				using (SolidBrush solidBrush4 = new SolidBrush(this.Accent))
				{
					graphics.FillEllipse(solidBrush4, (float)num - 3f, (float)num2 - 3f, 6f, 6f);
				}
				if (num3 > 50)
				{
					string text2 = this.Value.ToString(this.Format);
					using (Font font2 = new Font("Segoe UI", 14f, FontStyle.Bold))
					{
						SizeF sizeF2 = graphics.MeasureString(text2, font2);
						using (SolidBrush solidBrush5 = new SolidBrush(Color.White))
						{
							graphics.DrawString(text2, font2, solidBrush5, (float)num - sizeF2.Width / 2f, (float)num2 + 15f);
						}
					}
					using (Font font3 = new Font("Segoe UI", 7f, FontStyle.Bold))
					{
						string text3 = string.IsNullOrEmpty(this.Unit) ? this.Title : (this.Title + " (" + this.Unit + ")");
						SizeF sizeF3 = graphics.MeasureString(text3, font3);
						using (SolidBrush solidBrush6 = new SolidBrush(this.Accent))
						{
							graphics.DrawString(text3, font3, solidBrush6, (float)num - sizeF3.Width / 2f, (float)num2 + 35f);
						}
					}
				}
				if (num3 > 80)
				{
					float num15 = (float)num3 * 0.9f;
					float height2 = 20f;
					RectangleF value = new RectangleF((float)num - num15 / 2f, (float)(checked(num2 + num3)) - 35f, num15, height2);
					using (GraphicsPath graphicsPath2 = SpeedometerDashboard.GaugePanel.CreateRoundedPath(Rectangle.Round(value), 6))
					{
						using (SolidBrush solidBrush7 = new SolidBrush(Color.FromArgb(30, 35, 40)))
						{
							graphics.FillPath(solidBrush7, graphicsPath2);
						}
						using (Pen pen10 = new Pen(Color.FromArgb(60, 70, 80), 1f))
						{
							graphics.DrawPath(pen10, graphicsPath2);
						}
					}
					using (Font font4 = new Font("Segoe UI", 8f, FontStyle.Bold))
					{
						string text4 = string.IsNullOrEmpty(this.Unit) ? this.Title : this.Unit;
						SizeF sizeF4 = graphics.MeasureString(text4, font4);
						using (SolidBrush solidBrush8 = new SolidBrush(this.Accent))
						{
							graphics.DrawString(text4, font4, solidBrush8, value.X + (value.Width - sizeF4.Width) / 2f, value.Y + (value.Height - sizeF4.Height) / 2f);
						}
					}
				}
			}

			// Token: 0x06001A9A RID: 6810 RVA: 0x0008EF50 File Offset: 0x0008EF50
			private static GraphicsPath CreateRoundedPath(Rectangle rect, int radius)
			{
				GraphicsPath graphicsPath = new GraphicsPath();
				if (rect.Width <= 0 || rect.Height <= 0)
				{
					return graphicsPath;
				}
				checked
				{
					int num = radius * 2;
					if (num > rect.Width)
					{
						num = rect.Width;
					}
					if (num > rect.Height)
					{
						num = rect.Height;
					}
					graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
					graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
					graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
					graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
					graphicsPath.CloseFigure();
					return graphicsPath;
				}
			}

			// Token: 0x0400215E RID: 8542
			private Font _fontTitle;

			// Token: 0x0400215F RID: 8543
			private Font _fontVal;

			// Token: 0x04002160 RID: 8544
			private Font _fontTick;

			// Token: 0x04002161 RID: 8545
			private readonly Color _bgDark = Color.FromArgb(10, 15, 20);

			// Token: 0x04002162 RID: 8546
			private readonly Color _bgCard = Color.FromArgb(20, 28, 36);

			// Token: 0x04002163 RID: 8547
			private readonly Color _cyan = Color.FromArgb(0, 255, 230);

			// Token: 0x04002164 RID: 8548
			private readonly Color _muted = Color.FromArgb(135, 158, 174);

			// Token: 0x04002165 RID: 8549
			private readonly Color _fg = Color.FromArgb(225, 238, 245);

			// Token: 0x04002166 RID: 8550
			private readonly Color _border = Color.FromArgb(30, 45, 60);

			// Token: 0x04002167 RID: 8551
			private readonly Color _green = Color.FromArgb(80, 255, 120);

			// Token: 0x04002168 RID: 8552
			private readonly Color _yellow = Color.FromArgb(255, 220, 0);

			// Token: 0x04002169 RID: 8553
			private readonly Color _red = Color.FromArgb(255, 90, 105);
		}
	}
}
