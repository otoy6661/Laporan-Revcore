﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace HondaMapEditorPro
{
	// Token: 0x0200087E RID: 2174
	public static class RoundedHelper
	{
		// Token: 0x060018B0 RID: 6320 RVA: 0x000C3728 File Offset: 0x000C3728
		public static GraphicsPath RoundedRectF(RectangleF rect, float radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			if (radius <= 0f)
			{
				radius = 1f;
			}
			float num = radius * 2f;
			graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x060018B1 RID: 6321 RVA: 0x000C37E0 File Offset: 0x000C37E0
		public static void SetRegion(Form form, int radius)
		{
			using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(new RectangleF(0f, 0f, (float)form.Width, (float)form.Height), (float)radius))
			{
				form.Region = new Region(graphicsPath);
			}
		}
	}
}
