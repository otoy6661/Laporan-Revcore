﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyVersion("1.0.2.1")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright ©  2026")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyFileVersion("1.0.2.1")]
[assembly: AssemblyProduct("Honda Flash Tools .Net")]
[assembly: AssemblyTitle("Honda Flash Tools .Net")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("9794b4df-8871-40f3-9fb3-b88e16663ba4")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
