﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32;

namespace LicenseShared
{
	// Token: 0x02000719 RID: 1817
	public static class HardwareIdProvider
	{
		// Token: 0x06001091 RID: 4241 RVA: 0x00078CDC File Offset: 0x00078CDC
		public static string GetHardwareId()
		{
			string result;
			try
			{
				string s = HardwareIdProvider.BuildSeed();
				using (SHA256 sha = SHA256.Create())
				{
					byte[] bytes = Encoding.UTF8.GetBytes(s);
					string text = Convert.ToBase64String(sha.ComputeHash(bytes)).Replace("/", "").Replace("+", "").Replace("=", "");
					if (text.Length >= 32)
					{
						result = text.Substring(0, 32);
					}
					else
					{
						result = text.PadRight(32, '0');
					}
				}
			}
			catch
			{
				result = "ERROR-GETTING-HARDWARE-ID";
			}
			return result;
		}

		// Token: 0x06001092 RID: 4242 RVA: 0x00078D94 File Offset: 0x00078D94
		public static string BuildSeed()
		{
			StringBuilder stringBuilder = new StringBuilder();
			try
			{
				using (RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
				{
					using (RegistryKey registryKey2 = registryKey.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion"))
					{
						if (registryKey2 != null)
						{
							object value = registryKey2.GetValue("ProductId");
							if (value != null)
							{
								stringBuilder.Append(value.ToString());
							}
						}
					}
				}
			}
			catch
			{
				try
				{
					using (RegistryKey registryKey3 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion"))
					{
						if (registryKey3 != null)
						{
							object value2 = registryKey3.GetValue("ProductId");
							if (value2 != null)
							{
								stringBuilder.Append(value2.ToString());
							}
						}
					}
				}
				catch
				{
				}
			}
			stringBuilder.Append("|");
			try
			{
				DriveInfo driveInfo = new DriveInfo("C:\\");
				if (driveInfo.IsReady)
				{
					stringBuilder.Append(driveInfo.DriveFormat);
					stringBuilder.Append(driveInfo.TotalSize.ToString());
				}
			}
			catch
			{
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06001093 RID: 4243 RVA: 0x00078EE4 File Offset: 0x00078EE4
		public static string GetDebugInfo()
		{
			StringBuilder stringBuilder = new StringBuilder();
			string text = HardwareIdProvider.BuildSeed();
			stringBuilder.AppendLine("===== HARDWARE ID DEBUG =====");
			stringBuilder.AppendLine("Process Architecture : " + (Environment.Is64BitProcess ? "64-BIT" : "32-BIT"));
			stringBuilder.AppendLine("OS Architecture      : " + (Environment.Is64BitOperatingSystem ? "64-BIT" : "32-BIT"));
			stringBuilder.AppendLine("Machine Name         : " + Environment.MachineName);
			stringBuilder.AppendLine("Seed                 : " + text);
			stringBuilder.AppendLine("Seed Length          : " + text.Length.ToString());
			stringBuilder.AppendLine("HWID                 : " + HardwareIdProvider.GetHardwareId());
			return stringBuilder.ToString();
		}
	}
}
