﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace _3D_Chart_Graph
{
	// Token: 0x020007D2 RID: 2002
	public partial class _2d : Form
	{
		// Token: 0x14000007 RID: 7
		// (add) Token: 0x0600129F RID: 4767 RVA: 0x0008BEF4 File Offset: 0x0008BEF4
		// (remove) Token: 0x060012A0 RID: 4768 RVA: 0x0008BF2C File Offset: 0x0008BF2C
		public event Action<int, double> DataPointValueChanged;

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x060012A1 RID: 4769 RVA: 0x0008BF64 File Offset: 0x0008BF64
		// (remove) Token: 0x060012A2 RID: 4770 RVA: 0x0008BF9C File Offset: 0x0008BF9C
		public event Action OnSaveClicked;

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x060012A3 RID: 4771 RVA: 0x0008BFD4 File Offset: 0x0008BFD4
		// (remove) Token: 0x060012A4 RID: 4772 RVA: 0x0008C00C File Offset: 0x0008C00C
		public event Action<List<double>> OnDataSaved;

		// Token: 0x060012A5 RID: 4773 RVA: 0x0008C044 File Offset: 0x0008C044
		public _2d()
		{
			this.margin = 16;
			this.bottomMargin = 32;
			this.pointSize = 8;
			this.showLabels = true;
			this.fixedMaxY = 100.0;
			this.showGuideLines = true;
			try
			{
				this.InitializeColors();
				this.InitializeComponent();
				this.InitializeMenu();
				this.InitializeStatusStrip();
				this.InitializePanel();
				this.Text = "RPM Breakpoint Chart";
				base.StartPosition = FormStartPosition.CenterScreen;
				base.Size = new Size(900, 500);
				this.MinimumSize = new Size(600, 400);
				base.FormBorderStyle = FormBorderStyle.None;
				base.Padding = new Padding(6);
				this.BackColor = _2d.BgDark;
				this.DoubleBuffered = true;
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
				base.UpdateStyles();
				this.InitRoundedNeonBorder();
				base.HandleCreated += delegate(object s, EventArgs e)
				{
					this.ApplyRoundedRegion();
				};
				base.Resize += delegate(object s, EventArgs e)
				{
					this.ApplyRoundedRegion();
					this.RepositionContentControls();
				};
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error initializing chart: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x060012A6 RID: 4774 RVA: 0x0008C17C File Offset: 0x0008C17C
		public void ShowChart(List<double> values)
		{
			checked
			{
				try
				{
					if (values == null || values.Count < 2)
					{
						MessageBox.Show("Data must contain at least 2 points.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
					else if (this.panel1 == null)
					{
						MessageBox.Show("Panel not initialized.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						this.originalValues = new List<double>(values);
						this.dataPoints.Clear();
						this.selectedPoints.Clear();
						this.undoStack.Clear();
						this.redoStack.Clear();
						this.isDataChanged = false;
						double num = values.Max();
						if (num <= 0.0)
						{
							num = 100.0;
						}
						this.fixedMaxY = num;
						int num2 = this.panel1.Width - 2 * this.margin;
						int num3 = this.panel1.Height - this.margin - this.bottomMargin;
						if (num2 <= 0 || num3 <= 0)
						{
							num2 = 100;
							num3 = 100;
						}
						double currentScaleMax = this.GetCurrentScaleMax();
						for (int i = 0; i < values.Count; i++)
						{
							int num4 = this.margin + (int)(unchecked((double)i * (double)num2) / (double)(values.Count - 1));
							int num5 = this.margin + (int)(unchecked((double)num3 - values[i] / currentScaleMax * (double)num3));
							num5 = Math.Max(this.margin, Math.Min(this.panel1.Height - this.bottomMargin - this.pointSize, num5));
							this.dataPoints.Add(new _2d.DataPoint
							{
								X = (double)i,
								Y = values[i],
								Bounds = new Rectangle(num4 - this.pointSize / 2, num5 - this.pointSize / 2, this.pointSize, this.pointSize)
							});
						}
						this.UpdateStatus();
						this.panel1.Invalidate();
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error showing chart: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		// Token: 0x060012A8 RID: 4776 RVA: 0x0008C4C4 File Offset: 0x0008C4C4
		private void EnableDoubleBuffering(Panel panel)
		{
			if (panel == null)
			{
				return;
			}
			try
			{
				typeof(Panel).InvokeMember("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.SetProperty, null, panel, new object[]
				{
					true
				});
			}
			catch
			{
			}
		}

		// Token: 0x060012A9 RID: 4777 RVA: 0x0008C518 File Offset: 0x0008C518
		private void InitializeColors()
		{
			this.availableColors = new Color[]
			{
				Color.FromArgb(8, 8, 8),
				Color.FromArgb(20, 20, 40),
				Color.FromArgb(40, 20, 20),
				Color.FromArgb(20, 40, 20),
				Color.FromArgb(40, 40, 20),
				Color.FromArgb(30, 20, 40),
				Color.FromArgb(40, 30, 20),
				Color.FromArgb(20, 30, 40),
				Color.FromArgb(40, 20, 30),
				Color.FromArgb(10, 10, 10)
			};
			this.pointerColors = new Color[]
			{
				Color.Yellow,
				Color.Red,
				Color.Lime,
				Color.Cyan,
				Color.Magenta,
				Color.Orange,
				Color.White,
				Color.Pink,
				Color.LightBlue,
				Color.Gold
			};
			this.currentPointerColor = Color.Yellow;
			this.currentColorIndex = 0;
			this.currentPointerColorIndex = 0;
		}

		// Token: 0x060012AA RID: 4778 RVA: 0x0008C684 File Offset: 0x0008C684
		private void InitializeMenu()
		{
			this.menuStrip = new MenuStrip
			{
				BackColor = _2d.BgPanel,
				ForeColor = _2d.FgText,
				Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
				RenderMode = ToolStripRenderMode.Professional,
				GripStyle = ToolStripGripStyle.Hidden,
				Padding = new Padding(0)
			};
			this.menuFile = new ToolStripMenuItem("File")
			{
				ForeColor = _2d.FgText
			};
			this.menuSave = new ToolStripMenuItem("Save")
			{
				ShortcutKeys = (Keys)131155,
				ForeColor = _2d.FgText
			};
			this.menuSaveAs = new ToolStripMenuItem("Save As…")
			{
				ShortcutKeys = (Keys)196691,
				ForeColor = _2d.FgText
			};
			this.menuExit = new ToolStripMenuItem("Exit")
			{
				ShortcutKeys = (Keys)131141,
				ForeColor = _2d.FgText
			};
			this.menuSave.Click += this.BtnSave_Click;
			this.menuSaveAs.Click += this.MenuSaveAs_Click;
			this.menuExit.Click += delegate(object s, EventArgs e)
			{
				base.Close();
			};
			this.menuFile.DropDownItems.AddRange(new ToolStripItem[]
			{
				this.menuSave,
				this.menuSaveAs,
				this.menuExit
			});
			this.menuEdit = new ToolStripMenuItem("Edit")
			{
				ForeColor = _2d.FgText
			};
			this.menuUndo = new ToolStripMenuItem("Undo")
			{
				ShortcutKeys = (Keys)131162,
				ForeColor = _2d.FgText
			};
			this.menuRedo = new ToolStripMenuItem("Redo")
			{
				ShortcutKeys = (Keys)131161,
				ForeColor = _2d.FgText
			};
			this.menuUndo.Click += this.BtnUndo_Click;
			this.menuRedo.Click += this.BtnRedo_Click;
			this.menuEdit.DropDownItems.AddRange(new ToolStripItem[]
			{
				this.menuUndo,
				this.menuRedo
			});
			this.menuView = new ToolStripMenuItem("View")
			{
				ForeColor = _2d.FgText
			};
			this.menuViewLabels = new ToolStripMenuItem("Show Values")
			{
				Checked = true,
				CheckOnClick = true,
				ForeColor = _2d.FgText
			};
			this.menuViewAutoRange = new ToolStripMenuItem("Auto Range")
			{
				Checked = false,
				CheckOnClick = true,
				ForeColor = _2d.FgText
			};
			this.menuViewGuideLines = new ToolStripMenuItem("Guide Lines")
			{
				Checked = true,
				CheckOnClick = true,
				ForeColor = _2d.FgText
			};
			this.menuViewBgColor = new ToolStripMenuItem("Change Background Color")
			{
				ForeColor = _2d.FgText
			};
			this.menuViewPointerColor = new ToolStripMenuItem("Change Pointer Color")
			{
				ForeColor = _2d.FgText
			};
			this.menuViewLabels.Click += this.MenuViewLabels_Click;
			this.menuViewAutoRange.Click += this.MenuViewAutoRange_Click;
			this.menuViewGuideLines.Click += this.MenuViewGuideLines_Click;
			this.menuViewBgColor.Click += this.BtnBgColor_Click;
			this.menuViewPointerColor.Click += this.BtnPointerColor_Click;
			this.menuView.DropDownItems.AddRange(new ToolStripItem[]
			{
				this.menuViewLabels,
				this.menuViewAutoRange,
				this.menuViewGuideLines,
				this.menuViewBgColor,
				this.menuViewPointerColor
			});
			this.menuHelp = new ToolStripMenuItem("Help")
			{
				ForeColor = _2d.FgText
			};
			this.menuAbout = new ToolStripMenuItem("About")
			{
				ForeColor = _2d.FgText
			};
			this.menuAbout.Click += this.MenuAbout_Click;
			this.menuHelp.DropDownItems.Add(this.menuAbout);
			this.menuStrip.Items.AddRange(new ToolStripItem[]
			{
				this.menuFile,
				this.menuEdit,
				this.menuView,
				this.menuHelp
			});
			this.menuStrip.Renderer = new _2d.NeonMenuRenderer();
			base.Controls.Add(this.menuStrip);
			base.MainMenuStrip = this.menuStrip;
		}

		// Token: 0x060012AB RID: 4779 RVA: 0x0008CAF0 File Offset: 0x0008CAF0
		private void InitializeStatusStrip()
		{
			this.statusStrip = new StatusStrip
			{
				BackColor = _2d.BgPanel,
				ForeColor = _2d.FgText,
				Font = new Font("Segoe UI", 8f),
				SizingGrip = false
			};
			this.statusLabel = new ToolStripStatusLabel("Ready")
			{
				Spring = true,
				TextAlign = ContentAlignment.MiddleLeft
			};
			this.statusPointCount = new ToolStripStatusLabel("Points: 0")
			{
				TextAlign = ContentAlignment.MiddleRight
			};
			this.statusValue = new ToolStripStatusLabel("Value: -")
			{
				TextAlign = ContentAlignment.MiddleRight
			};
			this.statusStrip.Items.AddRange(new ToolStripItem[]
			{
				this.statusLabel,
				this.statusPointCount,
				this.statusValue
			});
			base.Controls.Add(this.statusStrip);
		}

		// Token: 0x060012AC RID: 4780 RVA: 0x0008CBCC File Offset: 0x0008CBCC
		private void InitializePanel()
		{
			this.dataPoints = new List<_2d.DataPoint>();
			this.selectedPoints = new List<_2d.DataPoint>();
			this.toolTip = new ToolTip();
			this.undoStack = new Stack<Dictionary<int, double>>();
			this.redoStack = new Stack<Dictionary<int, double>>();
			this.originalValues = new List<double>();
			this.buttonDataChanged = new Dictionary<Button, bool>();
		}

		// Token: 0x060012AD RID: 4781 RVA: 0x0008CC28 File Offset: 0x0008CC28
		private void Panel1_Paint(object sender, PaintEventArgs e)
		{
			checked
			{
				try
				{
					if (e != null && e.Graphics != null)
					{
						if (this.dataPoints != null && this.dataPoints.Count >= 2)
						{
							Graphics graphics = e.Graphics;
							graphics.SmoothingMode = SmoothingMode.AntiAlias;
							double currentScaleMax = this.GetCurrentScaleMax();
							int num = this.panel1.Height - this.margin - this.bottomMargin;
							int num2 = this.panel1.Width - 2 * this.margin;
							if (num > 0 && num2 > 0)
							{
								if (this.showGuideLines && this.selectedPoints != null && this.selectedPoints.Count > 0)
								{
									using (Pen pen = new Pen(Color.Red, 1f)
									{
										DashStyle = DashStyle.Dash
									})
									{
										foreach (_2d.DataPoint dataPoint in this.selectedPoints)
										{
											if (dataPoint != null && !(dataPoint.Bounds == Rectangle.Empty))
											{
												int num3 = dataPoint.Bounds.X + this.pointSize / 2;
												int num4 = dataPoint.Bounds.Y + this.pointSize / 2;
												graphics.DrawLine(pen, num3, this.margin, num3, this.panel1.Height - this.bottomMargin);
												graphics.DrawLine(pen, this.margin, num4, this.panel1.Width - this.margin, num4);
											}
										}
									}
								}
								using (Pen pen2 = new Pen(Color.FromArgb(80, 80, 80), 1f)
								{
									DashStyle = DashStyle.Dash
								})
								{
									for (int i = 0; i <= 10; i++)
									{
										int num5 = this.margin + i * num / 10;
										graphics.DrawLine(pen2, this.margin, num5, this.panel1.Width - this.margin, num5);
										graphics.DrawString((unchecked(currentScaleMax - (double)i / 10.0 * currentScaleMax)).ToString("F0"), this.Font, Brushes.Gray, 2f, (float)(num5 - 6));
									}
								}
								if (this.dataPoints.Count > 1)
								{
									using (Pen pen3 = new Pen(Color.FromArgb(80, 80, 80), 1f)
									{
										DashStyle = DashStyle.Dash
									})
									{
										for (int j = 0; j < this.dataPoints.Count; j++)
										{
											int num6 = this.margin + j * num2 / (this.dataPoints.Count - 1);
											graphics.DrawLine(pen3, num6, this.margin, num6, this.panel1.Height - this.bottomMargin);
											string text = j.ToString();
											SizeF sizeF = graphics.MeasureString(text, this.Font);
											float x = Math.Max(2f, unchecked(Math.Min((float)this.panel1.Width - sizeF.Width - 2f, (float)num6 - sizeF.Width / 2f)));
											graphics.DrawString(text, this.Font, Brushes.Gray, x, (float)(this.panel1.Height - this.bottomMargin + 4));
										}
									}
								}
								if (this.dataPoints.Count > 1)
								{
									using (Pen pen4 = new Pen(Color.Yellow, 1.5f))
									{
										for (int k = 1; k < this.dataPoints.Count; k++)
										{
											_2d.DataPoint dataPoint2 = this.dataPoints[k - 1];
											_2d.DataPoint dataPoint3 = this.dataPoints[k];
											if (dataPoint2 != null && dataPoint3 != null && !(dataPoint2.Bounds == Rectangle.Empty) && !(dataPoint3.Bounds == Rectangle.Empty))
											{
												Point pt = new Point(dataPoint2.Bounds.X + this.pointSize / 2, dataPoint2.Bounds.Y + this.pointSize / 2);
												Point pt2 = new Point(dataPoint3.Bounds.X + this.pointSize / 2, dataPoint3.Bounds.Y + this.pointSize / 2);
												graphics.DrawLine(pen4, pt, pt2);
											}
										}
									}
								}
								foreach (_2d.DataPoint dataPoint4 in this.dataPoints)
								{
									if (dataPoint4 != null && !(dataPoint4.Bounds == Rectangle.Empty))
									{
										bool flag = this.selectedPoints != null && this.selectedPoints.Contains(dataPoint4);
										if (flag)
										{
											Rectangle rect = new Rectangle(dataPoint4.Bounds.X - 3, dataPoint4.Bounds.Y - 3, dataPoint4.Bounds.Width + 6, dataPoint4.Bounds.Height + 6);
											using (SolidBrush solidBrush = new SolidBrush(this.currentPointerColor))
											{
												graphics.FillEllipse(solidBrush, rect);
											}
										}
										graphics.FillEllipse(Brushes.Red, dataPoint4.Bounds);
										Rectangle rect2 = new Rectangle(dataPoint4.Bounds.X + 2, dataPoint4.Bounds.Y + 2, dataPoint4.Bounds.Width - 4, dataPoint4.Bounds.Height - 4);
										graphics.FillEllipse(Brushes.White, rect2);
										unchecked
										{
											if (this.showLabels)
											{
												string text2 = (dataPoint4.Y < 200.0) ? dataPoint4.Y.ToString("F1") : dataPoint4.Y.ToString("F0");
												SizeF sizeF2 = graphics.MeasureString(text2, this.Font);
												float num7 = (float)dataPoint4.Bounds.X + ((float)dataPoint4.Bounds.Width - sizeF2.Width) / 2f;
												float num8 = (float)dataPoint4.Bounds.Y - sizeF2.Height - 5f;
												if (num8 < (float)this.margin / 2f)
												{
													num8 = (float)(checked(dataPoint4.Bounds.Y + dataPoint4.Bounds.Height)) + 5f;
												}
												num7 = Math.Max((float)this.margin / 2f, Math.Min((float)this.panel1.Width - (float)this.margin / 2f - sizeF2.Width, num7));
												RectangleF rect3 = new RectangleF(num7 - 2f, num8 - 2f, sizeF2.Width + 4f, sizeF2.Height + 4f);
												using (SolidBrush solidBrush2 = new SolidBrush(flag ? Color.FromArgb(200, 50, 50, 0) : Color.FromArgb(180, Color.Black)))
												{
													graphics.FillRectangle(solidBrush2, rect3);
												}
												graphics.DrawString(text2, this.Font, Brushes.Lime, num7, num8);
											}
										}
									}
								}
							}
						}
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine("Paint error: " + ex.Message);
				}
			}
		}

		// Token: 0x060012AE RID: 4782 RVA: 0x0008D4B8 File Offset: 0x0008D4B8
		private void Panel1_MouseDown(object sender, MouseEventArgs e)
		{
			checked
			{
				try
				{
					if (this.dataPoints != null && this.dataPoints.Count != 0)
					{
						_2d.DataPoint pointAtLocation = this.GetPointAtLocation(e.Location);
						if (e.Button == MouseButtons.Right)
						{
							if (pointAtLocation != null)
							{
								this.SaveStateToUndo();
								if (this.selectedPoints.Contains(pointAtLocation))
								{
									this.selectedPoints.Remove(pointAtLocation);
								}
								else
								{
									this.selectedPoints.Add(pointAtLocation);
								}
								this.panel1.Invalidate();
							}
							else if (this.selectedPoints.Count > 0)
							{
								this.selectedPoints.Clear();
								this.panel1.Invalidate();
							}
						}
						else if (pointAtLocation != null)
						{
							this.SaveStateToUndo();
							if ((Control.ModifierKeys & Keys.Control) == Keys.Control)
							{
								if (this.selectedPoints.Contains(pointAtLocation))
								{
									this.selectedPoints.Remove(pointAtLocation);
								}
								else
								{
									this.selectedPoints.Add(pointAtLocation);
								}
							}
							else if ((Control.ModifierKeys & Keys.Shift) == Keys.Shift && this.selectedPoints.Count > 0)
							{
								_2d.DataPoint dataPoint = this.selectedPoints[this.selectedPoints.Count - 1];
								int j = (int)Math.Min(dataPoint.X, pointAtLocation.X);
								int num = (int)Math.Max(dataPoint.X, pointAtLocation.X);
								this.selectedPoints.Clear();
								int i2;
								int i;
								for (i = j; i <= num; i = i2 + 1)
								{
									_2d.DataPoint dataPoint2 = this.dataPoints.FirstOrDefault((_2d.DataPoint d) => (int)d.X == i);
									if (dataPoint2 != null && !this.selectedPoints.Contains(dataPoint2))
									{
										this.selectedPoints.Add(dataPoint2);
									}
									i2 = i;
								}
							}
							else if (!this.selectedPoints.Contains(pointAtLocation))
							{
								this.selectedPoints.Clear();
								this.selectedPoints.Add(pointAtLocation);
							}
							this.isDragging = true;
							this.draggedPoint = pointAtLocation;
							this.offset = new Point(e.X - pointAtLocation.Bounds.X, e.Y - pointAtLocation.Bounds.Y);
							this.initialDragY = e.Y;
							this.initialYValues = new Dictionary<_2d.DataPoint, double>();
							foreach (_2d.DataPoint dataPoint3 in this.selectedPoints)
							{
								this.initialYValues[dataPoint3] = dataPoint3.Y;
							}
							this.initialMaxY = this.GetCurrentScaleMax();
							this.panel1.Cursor = Cursors.SizeNS;
							ToolTip toolTip = this.toolTip;
							if (toolTip != null)
							{
								toolTip.Show(string.Format("Value: {0:F2}", pointAtLocation.Y), this, e.X + 15, e.Y + 15);
							}
							this.panel1.Invalidate();
						}
						else if (this.selectedPoints.Count > 0)
						{
							this.selectedPoints.Clear();
							this.panel1.Invalidate();
						}
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine("MouseDown error: " + ex.Message);
				}
			}
		}

		// Token: 0x060012AF RID: 4783 RVA: 0x0008D820 File Offset: 0x0008D820
		private void Panel1_MouseMove(object sender, MouseEventArgs e)
		{
			checked
			{
				try
				{
					if (this.dataPoints != null && this.dataPoints.Count != 0)
					{
						if (this.isDragging && this.draggedPoint != null)
						{
							int num = this.panel1.Height - this.margin - this.bottomMargin;
							int num2 = e.Y - this.initialDragY;
							double num3 = (this.initialMaxY > 0.0001) ? this.initialMaxY : 100.0;
							Dictionary<_2d.DataPoint, double> dictionary = new Dictionary<_2d.DataPoint, double>();
							foreach (_2d.DataPoint key in this.selectedPoints)
							{
								double num4 = unchecked(this.initialYValues[key] - (double)num2 / (double)num * num3);
								num4 = Math.Max(0.0, num4);
								dictionary[key] = num4;
							}
							foreach (KeyValuePair<_2d.DataPoint, double> keyValuePair in dictionary)
							{
								keyValuePair.Key.Y = keyValuePair.Value;
							}
							double currentScaleMax = this.GetCurrentScaleMax();
							foreach (_2d.DataPoint dataPoint in this.dataPoints)
							{
								int num5 = this.margin + (int)(unchecked((double)num - dataPoint.Y / currentScaleMax * (double)num));
								num5 = Math.Max(this.margin, Math.Min(this.panel1.Height - this.bottomMargin - this.pointSize, num5));
								dataPoint.Bounds = new Rectangle(dataPoint.Bounds.X, num5, this.pointSize, this.pointSize);
							}
							this.isDataChanged = true;
							this.UpdateStatus();
							foreach (_2d.DataPoint dataPoint2 in this.selectedPoints)
							{
								int arg = this.dataPoints.IndexOf(dataPoint2);
								Action<int, double> dataPointValueChanged = this.DataPointValueChanged;
								if (dataPointValueChanged != null)
								{
									dataPointValueChanged(arg, dataPoint2.Y);
								}
							}
							ToolTip toolTip = this.toolTip;
							if (toolTip != null)
							{
								toolTip.Show(string.Format("Value: {0:F2}", this.draggedPoint.Y), this, e.X + 15, e.Y + 15);
							}
							this.panel1.Invalidate();
						}
						else
						{
							_2d.DataPoint pointAtLocation = this.GetPointAtLocation(e.Location);
							if (pointAtLocation != null)
							{
								this.panel1.Cursor = Cursors.Hand;
								if (this.statusValue != null)
								{
									this.statusValue.Text = string.Format("Value: {0:F2}", pointAtLocation.Y);
								}
							}
							else
							{
								this.panel1.Cursor = Cursors.Default;
								if (this.statusValue != null)
								{
									this.statusValue.Text = "Value: -";
								}
							}
						}
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine("MouseMove error: " + ex.Message);
				}
			}
		}

		// Token: 0x060012B0 RID: 4784 RVA: 0x0008DBC0 File Offset: 0x0008DBC0
		private void Panel1_MouseUp(object sender, MouseEventArgs e)
		{
			try
			{
				this.isDragging = false;
				this.draggedPoint = null;
				this.initialYValues = null;
				ToolTip toolTip = this.toolTip;
				if (toolTip != null)
				{
					toolTip.Hide(this);
				}
				this.panel1.Cursor = Cursors.Default;
			}
			catch (Exception ex)
			{
				Console.WriteLine("MouseUp error: " + ex.Message);
			}
		}

		// Token: 0x060012B1 RID: 4785 RVA: 0x0008DC30 File Offset: 0x0008DC30
		private void Panel1_MouseLeave(object sender, EventArgs e)
		{
			try
			{
				ToolTip toolTip = this.toolTip;
				if (toolTip != null)
				{
					toolTip.Hide(this);
				}
				this.panel1.Cursor = Cursors.Default;
				if (this.statusValue != null)
				{
					this.statusValue.Text = "Value: -";
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("MouseLeave error: " + ex.Message);
			}
		}

		// Token: 0x060012B2 RID: 4786 RVA: 0x0008DCA4 File Offset: 0x0008DCA4
		private void Panel1_Resize(object sender, EventArgs e)
		{
			try
			{
				this.RefreshAllPointPositions();
				Panel panel = this.panel1;
				if (panel != null)
				{
					panel.Invalidate();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Resize error: " + ex.Message);
			}
		}

		// Token: 0x060012B3 RID: 4787 RVA: 0x0008DCF4 File Offset: 0x0008DCF4
		private _2d.DataPoint GetPointAtLocation(Point location)
		{
			checked
			{
				_2d.DataPoint result;
				try
				{
					if (this.dataPoints == null || this.dataPoints.Count == 0)
					{
						result = null;
					}
					else
					{
						foreach (_2d.DataPoint dataPoint in this.dataPoints)
						{
							if (dataPoint != null && !(dataPoint.Bounds == Rectangle.Empty))
							{
								Rectangle rectangle = new Rectangle(dataPoint.Bounds.X - 10, dataPoint.Bounds.Y - 10, dataPoint.Bounds.Width + 20, dataPoint.Bounds.Height + 20);
								if (rectangle.Contains(location))
								{
									return dataPoint;
								}
							}
						}
						foreach (_2d.DataPoint dataPoint2 in this.dataPoints)
						{
							if (dataPoint2 != null && !(dataPoint2.Bounds == Rectangle.Empty))
							{
								Rectangle rectangle2 = new Rectangle(dataPoint2.Bounds.X - 15, dataPoint2.Bounds.Y - 15, dataPoint2.Bounds.Width + 30, dataPoint2.Bounds.Height + 30);
								if (rectangle2.Contains(location))
								{
									return dataPoint2;
								}
							}
						}
						result = null;
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine("GetPointAtLocation error: " + ex.Message);
					result = null;
				}
				return result;
			}
		}

		// Token: 0x060012B4 RID: 4788 RVA: 0x0008DEE0 File Offset: 0x0008DEE0
		private double GetCurrentScaleMax()
		{
			double result;
			try
			{
				if (this.useAutoRange)
				{
					double num;
					if (this.dataPoints == null || this.dataPoints.Count <= 0)
					{
						num = 0.0;
					}
					else
					{
						num = this.dataPoints.Max((_2d.DataPoint p) => p.Y);
					}
					double num2 = num;
					result = ((num2 > 0.0001) ? (num2 * 1.1) : 100.0);
				}
				else
				{
					result = ((this.fixedMaxY > 0.0001) ? this.fixedMaxY : 100.0);
				}
			}
			catch
			{
				result = 100.0;
			}
			return result;
		}

		// Token: 0x060012B5 RID: 4789 RVA: 0x0008DFAC File Offset: 0x0008DFAC
		private void RefreshAllPointPositions()
		{
			checked
			{
				try
				{
					if (this.dataPoints != null && this.dataPoints.Count >= 2 && this.panel1 != null)
					{
						double currentScaleMax = this.GetCurrentScaleMax();
						int num = this.panel1.Width - 2 * this.margin;
						int num2 = this.panel1.Height - this.margin - this.bottomMargin;
						if (num > 0 && num2 > 0)
						{
							for (int i = 0; i < this.dataPoints.Count; i++)
							{
								_2d.DataPoint dataPoint = this.dataPoints[i];
								if (dataPoint != null)
								{
									int num3 = this.margin + (int)(unchecked((double)i * (double)num) / (double)(this.dataPoints.Count - 1));
									int num4 = this.margin + (int)(unchecked((double)num2 - dataPoint.Y / currentScaleMax * (double)num2));
									num4 = Math.Max(this.margin, Math.Min(this.panel1.Height - this.bottomMargin - this.pointSize, num4));
									dataPoint.Bounds = new Rectangle(num3 - this.pointSize / 2, num4 - this.pointSize / 2, this.pointSize, this.pointSize);
								}
							}
						}
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine("RefreshAllPointPositions error: " + ex.Message);
				}
			}
		}

		// Token: 0x060012B6 RID: 4790 RVA: 0x0008E11C File Offset: 0x0008E11C
		private void UpdateStatus()
		{
			try
			{
				if (this.statusLabel != null)
				{
					this.statusLabel.Text = (this.isDataChanged ? "Modified *" : "Ready");
					this.statusLabel.ForeColor = (this.isDataChanged ? Color.Yellow : _2d.FgText);
				}
				if (this.statusPointCount != null && this.dataPoints != null)
				{
					this.statusPointCount.Text = string.Format("Points: {0}", this.dataPoints.Count);
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("UpdateStatus error: " + ex.Message);
			}
		}

		// Token: 0x060012B7 RID: 4791 RVA: 0x0008E1D0 File Offset: 0x0008E1D0
		private void SaveStateToUndo()
		{
			try
			{
				if (this.dataPoints != null && this.undoStack != null)
				{
					Dictionary<int, double> dictionary = new Dictionary<int, double>();
					foreach (_2d.DataPoint dataPoint in this.dataPoints)
					{
						if (dataPoint != null)
						{
							dictionary[checked((int)dataPoint.X)] = dataPoint.Y;
						}
					}
					this.undoStack.Push(dictionary);
					Stack<Dictionary<int, double>> stack = this.redoStack;
					if (stack != null)
					{
						stack.Clear();
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("SaveStateToUndo error: " + ex.Message);
			}
		}

		// Token: 0x060012B8 RID: 4792 RVA: 0x0008E290 File Offset: 0x0008E290
		private void ApplyState(Dictionary<int, double> state)
		{
			if (state == null || this.dataPoints == null)
			{
				return;
			}
			double num = this.GetCurrentScaleMax();
			if (num < 0.0001)
			{
				num = 100.0;
			}
			checked
			{
				int num2 = this.panel1.Height - this.margin - this.bottomMargin;
				foreach (KeyValuePair<int, double> keyValuePair in state)
				{
					int key = keyValuePair.Key;
					double value = keyValuePair.Value;
					if (key >= 0 && key < this.dataPoints.Count)
					{
						this.dataPoints[key].Y = value;
						int num3 = this.margin + (int)(unchecked((double)num2 - value / num * (double)num2));
						num3 = Math.Max(this.margin, Math.Min(this.panel1.Height - this.bottomMargin - this.pointSize, num3));
						this.dataPoints[key].Bounds = new Rectangle(this.dataPoints[key].Bounds.X, num3, this.pointSize, this.pointSize);
						Action<int, double> dataPointValueChanged = this.DataPointValueChanged;
						if (dataPointValueChanged != null)
						{
							dataPointValueChanged(key, value);
						}
					}
				}
				this.isDataChanged = true;
			}
		}

		// Token: 0x060012B9 RID: 4793 RVA: 0x0008E400 File Offset: 0x0008E400
		private void BtnUndo_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.undoStack == null || this.undoStack.Count == 0)
				{
					MessageBox.Show("Tidak ada history untuk Undo.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					Dictionary<int, double> dictionary = new Dictionary<int, double>();
					foreach (_2d.DataPoint dataPoint in this.dataPoints)
					{
						dictionary[checked((int)dataPoint.X)] = dataPoint.Y;
					}
					this.redoStack.Push(dictionary);
					this.ApplyState(this.undoStack.Pop());
					this.UpdateStatus();
					this.panel1.Invalidate();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error undo: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x060012BA RID: 4794 RVA: 0x0008E4F0 File Offset: 0x0008E4F0
		private void BtnRedo_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.redoStack == null || this.redoStack.Count == 0)
				{
					MessageBox.Show("Tidak ada history untuk Redo.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					Dictionary<int, double> dictionary = new Dictionary<int, double>();
					foreach (_2d.DataPoint dataPoint in this.dataPoints)
					{
						dictionary[checked((int)dataPoint.X)] = dataPoint.Y;
					}
					this.undoStack.Push(dictionary);
					this.ApplyState(this.redoStack.Pop());
					this.UpdateStatus();
					this.panel1.Invalidate();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error redo: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x060012BB RID: 4795 RVA: 0x0008E5E0 File Offset: 0x0008E5E0
		private void BtnSave_Click(object sender, EventArgs e)
		{
			try
			{
				List<double> currentData = this.GetCurrentData();
				Action<List<double>> onDataSaved = this.OnDataSaved;
				if (onDataSaved != null)
				{
					onDataSaved(currentData);
				}
				Action onSaveClicked = this.OnSaveClicked;
				if (onSaveClicked != null)
				{
					onSaveClicked();
				}
				this.isDataChanged = false;
				this.UpdateStatus();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Save error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x060012BC RID: 4796 RVA: 0x0000C106 File Offset: 0x0000C106
		public void TriggerSave()
		{
			this.BtnSave_Click(this, EventArgs.Empty);
		}

		// Token: 0x060012BD RID: 4797 RVA: 0x0008E658 File Offset: 0x0008E658
		private void MenuSaveAs_Click(object sender, EventArgs e)
		{
			try
			{
				using (SaveFileDialog saveFileDialog = new SaveFileDialog())
				{
					saveFileDialog.Filter = "Text Files (*.txt)|*.txt|CSV Files (*.csv)|*.csv|All Files (*.*)|*.*";
					saveFileDialog.DefaultExt = "txt";
					saveFileDialog.FileName = string.Format("chart_data_{0:yyyyMMdd_HHmmss}.txt", DateTime.Now);
					if (saveFileDialog.ShowDialog() == DialogResult.OK)
					{
						List<double> currentData = this.GetCurrentData();
						using (StreamWriter streamWriter = new StreamWriter(saveFileDialog.FileName))
						{
							streamWriter.WriteLine("# Chart Data");
							streamWriter.WriteLine(string.Format("# Saved: {0}", DateTime.Now));
							streamWriter.WriteLine(string.Format("# Total Points: {0}", currentData.Count));
							streamWriter.WriteLine("# --- DATA ---");
							foreach (double num in currentData)
							{
								streamWriter.WriteLine(num.ToString("F6"));
							}
						}
						MessageBox.Show("Data saved to: " + saveFileDialog.FileName, "Success", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error saving data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x060012BE RID: 4798 RVA: 0x0008E804 File Offset: 0x0008E804
		public List<double> GetCurrentData()
		{
			List<double> list = new List<double>();
			if (this.dataPoints != null)
			{
				foreach (_2d.DataPoint dataPoint in this.dataPoints)
				{
					if (dataPoint != null)
					{
						list.Add(dataPoint.Y);
					}
				}
			}
			return list;
		}

		// Token: 0x060012BF RID: 4799 RVA: 0x0000C114 File Offset: 0x0000C114
		public bool IsDataChanged()
		{
			return this.isDataChanged;
		}

		// Token: 0x060012C0 RID: 4800 RVA: 0x0000C11C File Offset: 0x0000C11C
		private void MenuViewLabels_Click(object sender, EventArgs e)
		{
			this.showLabels = !this.showLabels;
			if (this.menuViewLabels != null)
			{
				this.menuViewLabels.Checked = this.showLabels;
			}
			Panel panel = this.panel1;
			if (panel == null)
			{
				return;
			}
			panel.Invalidate();
		}

		// Token: 0x060012C1 RID: 4801 RVA: 0x0008E870 File Offset: 0x0008E870
		private void MenuViewAutoRange_Click(object sender, EventArgs e)
		{
			this.useAutoRange = !this.useAutoRange;
			if (this.menuViewAutoRange != null)
			{
				this.menuViewAutoRange.Checked = this.useAutoRange;
				this.menuViewAutoRange.ForeColor = (this.useAutoRange ? Color.Lime : _2d.FgText);
			}
			this.RefreshAllPointPositions();
			Panel panel = this.panel1;
			if (panel == null)
			{
				return;
			}
			panel.Invalidate();
		}

		// Token: 0x060012C2 RID: 4802 RVA: 0x0008E8DC File Offset: 0x0008E8DC
		private void MenuViewGuideLines_Click(object sender, EventArgs e)
		{
			this.showGuideLines = !this.showGuideLines;
			if (this.menuViewGuideLines != null)
			{
				this.menuViewGuideLines.Checked = this.showGuideLines;
				this.menuViewGuideLines.ForeColor = (this.showGuideLines ? Color.Lime : _2d.FgText);
			}
			Panel panel = this.panel1;
			if (panel == null)
			{
				return;
			}
			panel.Invalidate();
		}

		// Token: 0x060012C3 RID: 4803 RVA: 0x0008E940 File Offset: 0x0008E940
		private void BtnBgColor_Click(object sender, EventArgs e)
		{
			try
			{
				this.currentColorIndex = checked(this.currentColorIndex + 1) % this.availableColors.Length;
				if (this.panel1 != null)
				{
					this.panel1.BackColor = this.availableColors[this.currentColorIndex];
					this.panel1.Invalidate();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("BgColor error: " + ex.Message);
			}
		}

		// Token: 0x060012C4 RID: 4804 RVA: 0x0008E9C0 File Offset: 0x0008E9C0
		private void BtnPointerColor_Click(object sender, EventArgs e)
		{
			try
			{
				this.currentPointerColorIndex = checked(this.currentPointerColorIndex + 1) % this.pointerColors.Length;
				this.currentPointerColor = this.pointerColors[this.currentPointerColorIndex];
				Panel panel = this.panel1;
				if (panel != null)
				{
					panel.Invalidate();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("PointerColor error: " + ex.Message);
			}
		}

		// Token: 0x060012C5 RID: 4805 RVA: 0x0000C156 File Offset: 0x0000C156
		private void MenuAbout_Click(object sender, EventArgs e)
		{
			MessageBox.Show("RPM / TPS Breakpoint Chart\nEditor drag-point untuk breakpoint ECU.\n\n© TAWON BALAP 2025", "About", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		// Token: 0x060012C6 RID: 4806 RVA: 0x0008EA38 File Offset: 0x0008EA38
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			try
			{
				Panel panel = this.panel1;
				if (panel != null)
				{
					panel.Invalidate();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("OnLoad error: " + ex.Message);
			}
		}

		// Token: 0x060012C7 RID: 4807
		[DllImport("user32.dll")]
		private static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x060012C8 RID: 4808
		[DllImport("user32.dll")]
		private static extern bool ReleaseCapture();

		// Token: 0x060012C9 RID: 4809 RVA: 0x0000C16B File Offset: 0x0000C16B
		private void InitRoundedNeonBorder()
		{
			if (this._neonBorderInitialized)
			{
				return;
			}
			this._neonBorderInitialized = true;
			this.BuildCustomTitleBar();
			this.RepositionContentControls();
		}

		// Token: 0x060012CA RID: 4810 RVA: 0x0008EA88 File Offset: 0x0008EA88
		private void BuildCustomTitleBar()
		{
			this._customTitleBar = new Panel
			{
				Dock = DockStyle.Top,
				Height = 36,
				BackColor = _2d.BgPanel,
				Padding = new Padding(10, 0, 10, 0)
			};
			this._customTitleIcon = new Label
			{
				Text = "\ud83d\udcc8",
				Font = new Font("Segoe UI", 12f),
				ForeColor = _2d.NeonCyan,
				Location = new Point(10, 8),
				AutoSize = true,
				BackColor = Color.Transparent
			};
			this._customTitleLabel = new Label
			{
				Text = "RPM BREAKPOINT CHART",
				Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
				ForeColor = _2d.NeonCyan,
				Location = new Point(34, 10),
				AutoSize = true,
				BackColor = Color.Transparent,
				Cursor = Cursors.SizeAll
			};
			if (this.menuStrip != null)
			{
				if (base.Controls.Contains(this.menuStrip))
				{
					base.Controls.Remove(this.menuStrip);
				}
				this.menuStrip.Dock = DockStyle.None;
				this.menuStrip.BackColor = _2d.BgPanel;
				this.menuStrip.ForeColor = _2d.FgText;
				this.menuStrip.Location = new Point(240, 6);
				this.menuStrip.Visible = true;
				this._customTitleBar.Controls.Add(this.menuStrip);
			}
			this._customBtnClose = this.MakeNeonButton("✕", _2d.NeonRed);
			this._customBtnMaximize = this.MakeNeonButton("⛶", _2d.NeonCyan);
			this._customBtnMinimize = this.MakeNeonButton("—", _2d.FgText);
			this._customBtnClose.Click += delegate(object s, EventArgs e)
			{
				base.Close();
			};
			this._customBtnMaximize.Click += delegate(object s, EventArgs e)
			{
				this.ToggleMaximize();
			};
			this._customBtnMinimize.Click += delegate(object s, EventArgs e)
			{
				base.WindowState = FormWindowState.Minimized;
			};
			this._customTitleBar.Controls.Add(this._customTitleIcon);
			this._customTitleBar.Controls.Add(this._customTitleLabel);
			this._customTitleBar.Controls.Add(this._customBtnClose);
			this._customTitleBar.Controls.Add(this._customBtnMaximize);
			this._customTitleBar.Controls.Add(this._customBtnMinimize);
			this._customTitleBar.Resize += checked(delegate(object s, EventArgs e)
			{
				this._customBtnClose.Location = new Point(this._customTitleBar.Width - 40, 6);
				this._customBtnMaximize.Location = new Point(this._customTitleBar.Width - 78, 6);
				this._customBtnMinimize.Location = new Point(this._customTitleBar.Width - 116, 6);
			});
			MouseEventHandler value = delegate(object s, MouseEventArgs e)
			{
				if (e.Button == MouseButtons.Left)
				{
					if (this._isCustomMaximized)
					{
						this.ToggleMaximize();
					}
					_2d.ReleaseCapture();
					_2d.SendMessage(base.Handle, 161, 2, 0);
				}
			};
			this._customTitleBar.MouseDown += value;
			this._customTitleLabel.MouseDown += value;
			this._customTitleIcon.MouseDown += value;
			EventHandler value2 = delegate(object s, EventArgs e)
			{
				this.ToggleMaximize();
			};
			this._customTitleBar.DoubleClick += value2;
			this._customTitleLabel.DoubleClick += value2;
			this._customTitleIcon.DoubleClick += value2;
			base.Controls.Add(this._customTitleBar);
			this._customTitleBar.BringToFront();
		}

		// Token: 0x060012CB RID: 4811 RVA: 0x0008EDA4 File Offset: 0x0008EDA4
		private Button MakeNeonButton(string text, Color accent)
		{
			Button b = new Button
			{
				Text = text,
				Size = new Size(32, 28),
				Location = new Point(0, 6),
				FlatStyle = FlatStyle.Flat,
				BackColor = _2d.BgCard,
				ForeColor = accent,
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				Cursor = Cursors.Hand,
				TabStop = false,
				UseVisualStyleBackColor = false
			};
			b.FlatAppearance.BorderSize = 0;
			b.FlatAppearance.MouseOverBackColor = Color.Transparent;
			b.FlatAppearance.MouseDownBackColor = Color.Transparent;
			b.Paint += delegate(object s, PaintEventArgs ev)
			{
				Button button = (Button)s;
				ev.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				using (GraphicsPath graphicsPath = _2d.CreateRoundedPath(checked(new Rectangle(0, 0, button.Width - 1, button.Height - 1)), 8))
				{
					using (SolidBrush solidBrush = new SolidBrush(button.BackColor))
					{
						ev.Graphics.FillPath(solidBrush, graphicsPath);
					}
					using (Pen pen = new Pen(button.ForeColor, 1.4f))
					{
						ev.Graphics.DrawPath(pen, graphicsPath);
					}
				}
				TextRenderer.DrawText(ev.Graphics, button.Text, button.Font, button.ClientRectangle, button.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			};
			b.MouseEnter += delegate(object s, EventArgs e)
			{
				b.BackColor = Color.FromArgb(30, 42, 52);
				b.Invalidate();
			};
			b.MouseLeave += delegate(object s, EventArgs e)
			{
				b.BackColor = _2d.BgCard;
				b.Invalidate();
			};
			return b;
		}

		// Token: 0x060012CC RID: 4812 RVA: 0x0008EEC8 File Offset: 0x0008EEC8
		private void ToggleMaximize()
		{
			if (!this._isCustomMaximized)
			{
				this._restoreBounds = base.Bounds;
				this._isCustomMaximized = true;
				Screen screen = Screen.FromControl(this);
				base.Bounds = screen.WorkingArea;
				this._customBtnMaximize.Text = "❐";
			}
			else
			{
				this._isCustomMaximized = false;
				base.Bounds = this._restoreBounds;
				this._customBtnMaximize.Text = "⛶";
			}
			this._customBtnMaximize.Invalidate();
			this.ApplyRoundedRegion();
			this.RepositionContentControls();
		}

		// Token: 0x060012CD RID: 4813 RVA: 0x0008EF50 File Offset: 0x0008EF50
		private static GraphicsPath CreateRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			if (rect.Width <= 0 || rect.Height <= 0)
			{
				return graphicsPath;
			}
			checked
			{
				int num = radius * 2;
				if (num > rect.Width)
				{
					num = rect.Width;
				}
				if (num > rect.Height)
				{
					num = rect.Height;
				}
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x060012CE RID: 4814 RVA: 0x0008F030 File Offset: 0x0008F030
		private void ApplyRoundedRegion()
		{
			if (base.Width <= 0 || base.Height <= 0)
			{
				return;
			}
			try
			{
				using (GraphicsPath graphicsPath = _2d.CreateRoundedPath(new Rectangle(0, 0, base.Width, base.Height), 14))
				{
					Region region = base.Region;
					base.Region = new Region(graphicsPath);
					if (region != null)
					{
						region.Dispose();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060012CF RID: 4815 RVA: 0x0008F0B8 File Offset: 0x0008F0B8
		private void RepositionContentControls()
		{
			if (!this._neonBorderInitialized)
			{
				return;
			}
			int num = 42;
			checked
			{
				int num2 = 6 + ((this.statusStrip != null) ? this.statusStrip.Height : 22);
				if (this.panel1 != null && !this.panel1.IsDisposed)
				{
					this.panel1.Dock = DockStyle.None;
					this.panel1.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
					this.panel1.Location = new Point(6, num);
					this.panel1.Size = new Size(base.ClientSize.Width - 12, base.ClientSize.Height - num - num2);
				}
				if (this.statusStrip != null && !this.statusStrip.IsDisposed)
				{
					this.statusStrip.Dock = DockStyle.Bottom;
					this.statusStrip.BringToFront();
				}
				if (this.menuStrip != null && this._customTitleBar != null)
				{
					int x = Math.Min(240, Math.Max(100, this._customTitleBar.Width - 380));
					this.menuStrip.Location = new Point(x, 6);
				}
			}
		}

		// Token: 0x060012D0 RID: 4816 RVA: 0x0008F1D0 File Offset: 0x0008F1D0
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			if (base.Width < 5 || base.Height < 5)
			{
				return;
			}
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			using (GraphicsPath graphicsPath = _2d.CreateRoundedPath(checked(new Rectangle(2, 2, base.Width - 5, base.Height - 5)), 14))
			{
				using (Pen pen = new Pen(Color.FromArgb(25, 0, 255, 230), 8f))
				{
					using (Pen pen2 = new Pen(Color.FromArgb(60, 0, 255, 230), 5f))
					{
						using (Pen pen3 = new Pen(Color.FromArgb(120, 0, 255, 230), 2f))
						{
							using (Pen pen4 = new Pen(_2d.NeonCyan, 1.2f))
							{
								graphics.DrawPath(pen, graphicsPath);
								graphics.DrawPath(pen2, graphicsPath);
								graphics.DrawPath(pen3, graphicsPath);
								graphics.DrawPath(pen4, graphicsPath);
							}
						}
					}
				}
			}
		}

		// Token: 0x040019F1 RID: 6641
		private bool isDragging;

		// Token: 0x040019F2 RID: 6642
		private Point offset;

		// Token: 0x040019F3 RID: 6643
		private int margin;

		// Token: 0x040019F4 RID: 6644
		private int pointSize;

		// Token: 0x040019F6 RID: 6646
		private List<_2d.DataPoint> dataPoints;

		// Token: 0x040019F7 RID: 6647
		private _2d.DataPoint draggedPoint;

		// Token: 0x040019F8 RID: 6648
		private List<_2d.DataPoint> selectedPoints;

		// Token: 0x040019F9 RID: 6649
		private int initialDragY;

		// Token: 0x040019FA RID: 6650
		private Dictionary<_2d.DataPoint, double> initialYValues;

		// Token: 0x040019FB RID: 6651
		private Stack<Dictionary<int, double>> undoStack;

		// Token: 0x040019FC RID: 6652
		private Stack<Dictionary<int, double>> redoStack;

		// Token: 0x040019FD RID: 6653
		private double initialMaxY;

		// Token: 0x040019FE RID: 6654
		private List<double> originalValues;

		// Token: 0x040019FF RID: 6655
		private bool isDataChanged;

		// Token: 0x04001A00 RID: 6656
		private Dictionary<Button, bool> buttonDataChanged;

		// Token: 0x04001A01 RID: 6657
		private Color[] availableColors;

		// Token: 0x04001A02 RID: 6658
		private Color[] pointerColors;

		// Token: 0x04001A03 RID: 6659
		private Color currentPointerColor;

		// Token: 0x04001A04 RID: 6660
		private int bottomMargin;

		// Token: 0x04001A05 RID: 6661
		private bool showLabels;

		// Token: 0x04001A06 RID: 6662
		private bool useAutoRange;

		// Token: 0x04001A07 RID: 6663
		private double fixedMaxY;

		// Token: 0x04001A08 RID: 6664
		private int currentColorIndex;

		// Token: 0x04001A09 RID: 6665
		private int currentPointerColorIndex;

		// Token: 0x04001A0A RID: 6666
		private bool showGuideLines;

		// Token: 0x04001A0B RID: 6667
		private ToolTip toolTip;

		// Token: 0x04001A0C RID: 6668
		private MenuStrip menuStrip;

		// Token: 0x04001A0D RID: 6669
		private ToolStripMenuItem menuFile;

		// Token: 0x04001A0E RID: 6670
		private ToolStripMenuItem menuSave;

		// Token: 0x04001A0F RID: 6671
		private ToolStripMenuItem menuSaveAs;

		// Token: 0x04001A10 RID: 6672
		private ToolStripMenuItem menuExit;

		// Token: 0x04001A11 RID: 6673
		private ToolStripMenuItem menuEdit;

		// Token: 0x04001A12 RID: 6674
		private ToolStripMenuItem menuUndo;

		// Token: 0x04001A13 RID: 6675
		private ToolStripMenuItem menuRedo;

		// Token: 0x04001A14 RID: 6676
		private ToolStripMenuItem menuView;

		// Token: 0x04001A15 RID: 6677
		private ToolStripMenuItem menuViewLabels;

		// Token: 0x04001A16 RID: 6678
		private ToolStripMenuItem menuViewAutoRange;

		// Token: 0x04001A17 RID: 6679
		private ToolStripMenuItem menuViewGuideLines;

		// Token: 0x04001A18 RID: 6680
		private ToolStripMenuItem menuViewBgColor;

		// Token: 0x04001A19 RID: 6681
		private ToolStripMenuItem menuViewPointerColor;

		// Token: 0x04001A1A RID: 6682
		private ToolStripMenuItem menuHelp;

		// Token: 0x04001A1B RID: 6683
		private ToolStripMenuItem menuAbout;

		// Token: 0x04001A1C RID: 6684
		private StatusStrip statusStrip;

		// Token: 0x04001A1D RID: 6685
		private ToolStripStatusLabel statusLabel;

		// Token: 0x04001A1E RID: 6686
		private ToolStripStatusLabel statusPointCount;

		// Token: 0x04001A1F RID: 6687
		private ToolStripStatusLabel statusValue;

		// Token: 0x04001A20 RID: 6688
		private const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x04001A21 RID: 6689
		private const int HT_CAPTION = 2;

		// Token: 0x04001A22 RID: 6690
		private const int CORNER_RADIUS = 14;

		// Token: 0x04001A23 RID: 6691
		private const int CUSTOM_TITLE_HEIGHT = 36;

		// Token: 0x04001A24 RID: 6692
		private static readonly Color NeonCyan = Color.FromArgb(0, 255, 230);

		// Token: 0x04001A25 RID: 6693
		private static readonly Color NeonRed = Color.FromArgb(255, 90, 105);

		// Token: 0x04001A26 RID: 6694
		private static readonly Color BgPanel = Color.FromArgb(16, 23, 30);

		// Token: 0x04001A27 RID: 6695
		private static readonly Color BgCard = Color.FromArgb(20, 28, 36);

		// Token: 0x04001A28 RID: 6696
		private static readonly Color FgText = Color.FromArgb(225, 238, 245);

		// Token: 0x04001A29 RID: 6697
		private static readonly Color BgDark = Color.FromArgb(10, 15, 20);

		// Token: 0x04001A2A RID: 6698
		private Panel _customTitleBar;

		// Token: 0x04001A2B RID: 6699
		private Label _customTitleLabel;

		// Token: 0x04001A2C RID: 6700
		private Label _customTitleIcon;

		// Token: 0x04001A2D RID: 6701
		private Button _customBtnClose;

		// Token: 0x04001A2E RID: 6702
		private Button _customBtnMaximize;

		// Token: 0x04001A2F RID: 6703
		private Button _customBtnMinimize;

		// Token: 0x04001A30 RID: 6704
		private Rectangle _restoreBounds;

		// Token: 0x04001A31 RID: 6705
		private bool _isCustomMaximized;

		// Token: 0x04001A32 RID: 6706
		private bool _neonBorderInitialized;

		// Token: 0x020007D3 RID: 2003
		private class DataPoint
		{
			// Token: 0x170000CF RID: 207
			// (get) Token: 0x060012DD RID: 4829 RVA: 0x0000C1DD File Offset: 0x0000C1DD
			// (set) Token: 0x060012DE RID: 4830 RVA: 0x0000C1E5 File Offset: 0x0000C1E5
			public double X { get; set; }

			// Token: 0x170000D0 RID: 208
			// (get) Token: 0x060012DF RID: 4831 RVA: 0x0000C1EE File Offset: 0x0000C1EE
			// (set) Token: 0x060012E0 RID: 4832 RVA: 0x0000C1F6 File Offset: 0x0000C1F6
			public double Y { get; set; }

			// Token: 0x170000D1 RID: 209
			// (get) Token: 0x060012E1 RID: 4833 RVA: 0x0000C1FF File Offset: 0x0000C1FF
			// (set) Token: 0x060012E2 RID: 4834 RVA: 0x0000C207 File Offset: 0x0000C207
			public Rectangle Bounds { get; set; }
		}

		// Token: 0x020007D5 RID: 2005
		private sealed class NeonMenuRenderer : ToolStripProfessionalRenderer
		{
			// Token: 0x060012E8 RID: 4840 RVA: 0x0000C224 File Offset: 0x0000C224
			public NeonMenuRenderer() : base(new _2d.NeonMenuRenderer.NeonColorTable())
			{
			}

			// Token: 0x060012E9 RID: 4841 RVA: 0x0008F500 File Offset: 0x0008F500
			protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
			{
				checked
				{
					if (e.Item.Selected && e.Item.Enabled)
					{
						using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(40, _2d.NeonCyan)))
						{
							e.Graphics.FillRectangle(solidBrush, new Rectangle(Point.Empty, e.Item.Size));
						}
						using (Pen pen = new Pen(Color.FromArgb(180, _2d.NeonCyan), 1f))
						{
							e.Graphics.DrawRectangle(pen, 0, 0, e.Item.Width - 1, e.Item.Height - 1);
							return;
						}
					}
					base.OnRenderMenuItemBackground(e);
				}
			}

			// Token: 0x060012EA RID: 4842 RVA: 0x0008F5E0 File Offset: 0x0008F5E0
			protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
			{
				if (e.Item.Selected)
				{
					e.TextColor = _2d.NeonCyan;
				}
				else if (e.Item.Enabled)
				{
					e.TextColor = _2d.FgText;
				}
				else
				{
					e.TextColor = Color.FromArgb(100, 100, 100);
				}
				base.OnRenderItemText(e);
			}

			// Token: 0x020007D6 RID: 2006
			private sealed class NeonColorTable : ProfessionalColorTable
			{
				// Token: 0x170000D2 RID: 210
				// (get) Token: 0x060012EB RID: 4843 RVA: 0x0000C231 File Offset: 0x0000C231
				public override Color MenuItemSelected
				{
					get
					{
						return Color.FromArgb(40, _2d.NeonCyan);
					}
				}

				// Token: 0x170000D3 RID: 211
				// (get) Token: 0x060012EC RID: 4844 RVA: 0x0000C231 File Offset: 0x0000C231
				public override Color MenuItemSelectedGradientBegin
				{
					get
					{
						return Color.FromArgb(40, _2d.NeonCyan);
					}
				}

				// Token: 0x170000D4 RID: 212
				// (get) Token: 0x060012ED RID: 4845 RVA: 0x0000C231 File Offset: 0x0000C231
				public override Color MenuItemSelectedGradientEnd
				{
					get
					{
						return Color.FromArgb(40, _2d.NeonCyan);
					}
				}

				// Token: 0x170000D5 RID: 213
				// (get) Token: 0x060012EE RID: 4846 RVA: 0x0000C23F File Offset: 0x0000C23F
				public override Color MenuItemBorder
				{
					get
					{
						return Color.FromArgb(180, _2d.NeonCyan);
					}
				}

				// Token: 0x170000D6 RID: 214
				// (get) Token: 0x060012EF RID: 4847 RVA: 0x0000C250 File Offset: 0x0000C250
				public override Color MenuBorder
				{
					get
					{
						return Color.FromArgb(60, _2d.NeonCyan);
					}
				}

				// Token: 0x170000D7 RID: 215
				// (get) Token: 0x060012F0 RID: 4848 RVA: 0x0000C25E File Offset: 0x0000C25E
				public override Color MenuItemPressedGradientBegin
				{
					get
					{
						return _2d.BgCard;
					}
				}

				// Token: 0x170000D8 RID: 216
				// (get) Token: 0x060012F1 RID: 4849 RVA: 0x0000C265 File Offset: 0x0000C265
				public override Color MenuItemPressedGradientEnd
				{
					get
					{
						return _2d.BgPanel;
					}
				}

				// Token: 0x170000D9 RID: 217
				// (get) Token: 0x060012F2 RID: 4850 RVA: 0x0000C265 File Offset: 0x0000C265
				public override Color ToolStripDropDownBackground
				{
					get
					{
						return _2d.BgPanel;
					}
				}

				// Token: 0x170000DA RID: 218
				// (get) Token: 0x060012F3 RID: 4851 RVA: 0x0000C265 File Offset: 0x0000C265
				public override Color ImageMarginGradientBegin
				{
					get
					{
						return _2d.BgPanel;
					}
				}

				// Token: 0x170000DB RID: 219
				// (get) Token: 0x060012F4 RID: 4852 RVA: 0x0000C265 File Offset: 0x0000C265
				public override Color ImageMarginGradientMiddle
				{
					get
					{
						return _2d.BgPanel;
					}
				}

				// Token: 0x170000DC RID: 220
				// (get) Token: 0x060012F5 RID: 4853 RVA: 0x0000C265 File Offset: 0x0000C265
				public override Color ImageMarginGradientEnd
				{
					get
					{
						return _2d.BgPanel;
					}
				}

				// Token: 0x170000DD RID: 221
				// (get) Token: 0x060012F6 RID: 4854 RVA: 0x0000C265 File Offset: 0x0000C265
				public override Color ToolStripGradientBegin
				{
					get
					{
						return _2d.BgPanel;
					}
				}

				// Token: 0x170000DE RID: 222
				// (get) Token: 0x060012F7 RID: 4855 RVA: 0x0000C265 File Offset: 0x0000C265
				public override Color ToolStripGradientMiddle
				{
					get
					{
						return _2d.BgPanel;
					}
				}

				// Token: 0x170000DF RID: 223
				// (get) Token: 0x060012F8 RID: 4856 RVA: 0x0000C265 File Offset: 0x0000C265
				public override Color ToolStripGradientEnd
				{
					get
					{
						return _2d.BgPanel;
					}
				}
			}
		}
	}
}
