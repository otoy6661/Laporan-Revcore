﻿namespace _3D_Chart_Graph
{
	// Token: 0x020007D2 RID: 2002
	public partial class _2d : global::System.Windows.Forms.Form
	{
		// Token: 0x060012A7 RID: 4775 RVA: 0x0008C398 File Offset: 0x0008C398
		private void InitializeComponent()
		{
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.panel1.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.panel1.BackColor = global::System.Drawing.Color.FromArgb(8, 8, 8);
			this.panel1.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.panel1.Paint += new global::System.Windows.Forms.PaintEventHandler(this.Panel1_Paint);
			this.panel1.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.Panel1_MouseDown);
			this.panel1.MouseMove += new global::System.Windows.Forms.MouseEventHandler(this.Panel1_MouseMove);
			this.panel1.MouseUp += new global::System.Windows.Forms.MouseEventHandler(this.Panel1_MouseUp);
			this.panel1.MouseLeave += new global::System.EventHandler(this.Panel1_MouseLeave);
			this.panel1.Resize += new global::System.EventHandler(this.Panel1_Resize);
			this.panel1.Cursor = global::System.Windows.Forms.Cursors.Default;
			base.Controls.Add(this.panel1);
			this.BackColor = global::System.Drawing.Color.FromArgb(8, 8, 8);
			this.Font = new global::System.Drawing.Font("Segoe UI", 8.25f);
			this.EnableDoubleBuffering(this.panel1);
			base.SetStyle(global::System.Windows.Forms.ControlStyles.UserPaint | global::System.Windows.Forms.ControlStyles.ResizeRedraw | global::System.Windows.Forms.ControlStyles.AllPaintingInWmPaint | global::System.Windows.Forms.ControlStyles.DoubleBuffer, true);
		}

		// Token: 0x040019F5 RID: 6645
		private global::System.Windows.Forms.Panel panel1;
	}
}
