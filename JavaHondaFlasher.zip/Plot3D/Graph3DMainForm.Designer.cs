﻿namespace Plot3D
{
	// Token: 0x020007D9 RID: 2009
	public partial class Graph3DMainForm : global::System.Windows.Forms.Form
	{
		// Token: 0x06001304 RID: 4868 RVA: 0x0008F8C0 File Offset: 0x0008F8C0
		private void InitializeComponent()
		{
			this.menuStrip = new global::System.Windows.Forms.MenuStrip();
			this.viewMenu = new global::System.Windows.Forms.ToolStripMenuItem();
			this.wireFrameMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.autoRangeMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.heightColorMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.showAllPointsMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.showCompareBinsMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.resetPositionMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.editMenu = new global::System.Windows.Forms.ToolStripMenuItem();
			this.dragGraphMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.rotateGraphMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.zoomGraphMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.dataSourceMenu = new global::System.Windows.Forms.ToolStripMenuItem();
			this.colorSchemeMenu = new global::System.Windows.Forms.ToolStripMenuItem();
			this.perspectiveMenu = new global::System.Windows.Forms.ToolStripMenuItem();
			this.toolsMenu = new global::System.Windows.Forms.ToolStripMenuItem();
			this.autoRotateMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.autoRotateSpeedMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.screenshotMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.exitMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.trackRho = new global::System.Windows.Forms.TrackBar();
			this.trackTheta = new global::System.Windows.Forms.TrackBar();
			this.trackPhi = new global::System.Windows.Forms.TrackBar();
			this.lblInfo = new global::System.Windows.Forms.Label();
			this.lblPerspective = new global::System.Windows.Forms.Label();
			this.label1 = new global::System.Windows.Forms.Label();
			this.graph3D = new global::Plot3D.Graph3D();
			base.SuspendLayout();
			this.menuStrip.BackColor = global::System.Drawing.Color.FromArgb(45, 45, 48);
			this.menuStrip.ForeColor = global::System.Drawing.Color.White;
			this.menuStrip.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.viewMenu,
				this.editMenu,
				this.dataSourceMenu,
				this.colorSchemeMenu,
				this.perspectiveMenu,
				this.toolsMenu
			});
			this.menuStrip.Location = new global::System.Drawing.Point(0, 0);
			this.menuStrip.Name = "menuStrip";
			this.menuStrip.Size = new global::System.Drawing.Size(753, 24);
			this.menuStrip.TabIndex = 0;
			this.viewMenu.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.wireFrameMenuItem,
				this.autoRangeMenuItem,
				this.heightColorMenuItem,
				this.showAllPointsMenuItem,
				this.showCompareBinsMenuItem,
				this.resetPositionMenuItem
			});
			this.viewMenu.Name = "viewMenu";
			this.viewMenu.Text = "View Graph";
			this.wireFrameMenuItem.CheckOnClick = true;
			this.wireFrameMenuItem.Name = "wireFrameMenuItem";
			this.wireFrameMenuItem.Text = "Wire Frame";
			this.wireFrameMenuItem.Checked = false;
			this.wireFrameMenuItem.Click += new global::System.EventHandler(this.WireFrameMenuItem_Click);
			this.autoRangeMenuItem.CheckOnClick = true;
			this.autoRangeMenuItem.Name = "autoRangeMenuItem";
			this.autoRangeMenuItem.Text = "Auto-range";
			this.autoRangeMenuItem.Checked = true;
			this.autoRangeMenuItem.Click += new global::System.EventHandler(this.AutoRangeMenuItem_Click);
			this.heightColorMenuItem.CheckOnClick = true;
			this.heightColorMenuItem.Name = "heightColorMenuItem";
			this.heightColorMenuItem.Text = "Height Color";
			this.heightColorMenuItem.Checked = true;
			this.heightColorMenuItem.Click += new global::System.EventHandler(this.HeightColorMenuItem_Click);
			this.showAllPointsMenuItem.CheckOnClick = true;
			this.showAllPointsMenuItem.Name = "showAllPointsMenuItem";
			this.showAllPointsMenuItem.Text = "Show All Points";
			this.showAllPointsMenuItem.Checked = false;
			this.showAllPointsMenuItem.Click += new global::System.EventHandler(this.ShowAllPointsMenuItem_Click);
			this.showCompareBinsMenuItem.CheckOnClick = true;
			this.showCompareBinsMenuItem.Name = "showCompareBinsMenuItem";
			this.showCompareBinsMenuItem.Text = "Show Compare Bins";
			this.showCompareBinsMenuItem.Checked = false;
			this.showCompareBinsMenuItem.Click += new global::System.EventHandler(this.ShowCompareBinsMenuItem_Click);
			this.resetPositionMenuItem.Name = "resetPositionMenuItem";
			this.resetPositionMenuItem.Text = "Reset Position";
			this.resetPositionMenuItem.ShortcutKeys = (global::System.Windows.Forms.Keys)131154;
			this.resetPositionMenuItem.Click += new global::System.EventHandler(this.ResetPerspective_Click);
			this.editMenu.Name = "editMenu";
			this.editMenu.Text = "Edit";
			this.editMenu.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.dragGraphMenuItem,
				this.rotateGraphMenuItem,
				this.zoomGraphMenuItem
			});
			this.dragGraphMenuItem.CheckOnClick = true;
			this.dragGraphMenuItem.Name = "dragGraphMenuItem";
			this.dragGraphMenuItem.Text = "Drag Graph (Move)";
			this.dragGraphMenuItem.Checked = true;
			this.dragGraphMenuItem.Click += new global::System.EventHandler(this.DragGraphMenuItem_Click);
			this.rotateGraphMenuItem.CheckOnClick = true;
			this.rotateGraphMenuItem.Name = "rotateGraphMenuItem";
			this.rotateGraphMenuItem.Text = "Rotate Graph";
			this.rotateGraphMenuItem.Checked = true;
			this.rotateGraphMenuItem.Click += new global::System.EventHandler(this.RotateGraphMenuItem_Click);
			this.zoomGraphMenuItem.CheckOnClick = true;
			this.zoomGraphMenuItem.Name = "zoomGraphMenuItem";
			this.zoomGraphMenuItem.Text = "Zoom Graph";
			this.zoomGraphMenuItem.Checked = true;
			this.zoomGraphMenuItem.Click += new global::System.EventHandler(this.ZoomGraphMenuItem_Click);
			this.dataSourceMenu.Name = "dataSourceMenu";
			this.dataSourceMenu.Text = "Data Source";
			this.colorSchemeMenu.Name = "colorSchemeMenu";
			this.colorSchemeMenu.Text = "Color Scheme";
			this.perspectiveMenu.Name = "perspectiveMenu";
			this.perspectiveMenu.Text = "Perspective";
			this.toolsMenu.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.autoRotateMenuItem,
				this.autoRotateSpeedMenuItem,
				this.screenshotMenuItem,
				this.exitMenuItem
			});
			this.toolsMenu.Name = "toolsMenu";
			this.toolsMenu.Text = "Tools";
			this.autoRotateMenuItem.CheckOnClick = true;
			this.autoRotateMenuItem.Name = "autoRotateMenuItem";
			this.autoRotateMenuItem.Text = "Auto Rotation";
			this.autoRotateMenuItem.Checked = false;
			this.autoRotateMenuItem.Click += new global::System.EventHandler(this.AutoRotateMenuItem_Click);
			this.autoRotateSpeedMenuItem.Name = "autoRotateSpeedMenuItem";
			this.autoRotateSpeedMenuItem.Text = "Rotation Speed";
			this.screenshotMenuItem.Name = "screenshotMenuItem";
			this.screenshotMenuItem.Text = "Save Screenshot";
			this.screenshotMenuItem.ShortcutKeys = (global::System.Windows.Forms.Keys)131155;
			this.screenshotMenuItem.Click += new global::System.EventHandler(this.SaveScreenshot_Click);
			this.exitMenuItem.Name = "exitMenuItem";
			this.exitMenuItem.Text = "Exit";
			this.exitMenuItem.ShortcutKeys = (global::System.Windows.Forms.Keys)131141;
			this.exitMenuItem.Click += delegate(object s, global::System.EventArgs e)
			{
				base.Close();
			};
			this.trackRho.Location = new global::System.Drawing.Point(0, 0);
			this.trackRho.Name = "trackRho";
			this.trackRho.Size = new global::System.Drawing.Size(104, 45);
			this.trackRho.TabIndex = 1;
			this.trackTheta.Location = new global::System.Drawing.Point(0, 0);
			this.trackTheta.Name = "trackTheta";
			this.trackTheta.Size = new global::System.Drawing.Size(104, 45);
			this.trackTheta.TabIndex = 2;
			this.trackPhi.Location = new global::System.Drawing.Point(0, 0);
			this.trackPhi.Name = "trackPhi";
			this.trackPhi.Size = new global::System.Drawing.Size(104, 45);
			this.trackPhi.TabIndex = 3;
			this.lblInfo.AutoSize = true;
			this.lblInfo.Font = new global::System.Drawing.Font("Segoe UI", 8.25f);
			this.lblInfo.ForeColor = global::System.Drawing.Color.White;
			this.lblInfo.Location = new global::System.Drawing.Point(12, 445);
			this.lblInfo.Name = "lblInfo";
			this.lblInfo.Text = "Info";
			this.lblPerspective.AutoSize = true;
			this.lblPerspective.Font = new global::System.Drawing.Font("Segoe UI", 8.25f);
			this.lblPerspective.ForeColor = global::System.Drawing.Color.FromArgb(0, 122, 204);
			this.lblPerspective.Location = new global::System.Drawing.Point(12, 425);
			this.lblPerspective.Name = "lblPerspective";
			this.lblPerspective.Text = "Zoom: 0  UP: 0  L-R: 0";
			this.label1.Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Segoe UI", 8.25f);
			this.label1.ForeColor = global::System.Drawing.Color.FromArgb(0, 122, 204);
			this.label1.Location = new global::System.Drawing.Point(12, 445);
			this.label1.Name = "label1";
			this.label1.Text = "Left: Elevate | Right: Rotate | Middle: Move | Wheel: Zoom";
			this.graph3D.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.graph3D.AxisX_Color = global::System.Drawing.Color.FromArgb(0, 122, 204);
			this.graph3D.AxisX_Legend = null;
			this.graph3D.AxisY_Color = global::System.Drawing.Color.FromArgb(0, 122, 204);
			this.graph3D.AxisY_Legend = null;
			this.graph3D.AxisZ_Color = global::System.Drawing.Color.FromArgb(0, 122, 204);
			this.graph3D.AxisZ_Legend = null;
			this.graph3D.BackColor = global::System.Drawing.Color.FromArgb(37, 37, 38);
			this.graph3D.BorderColor = global::System.Drawing.Color.FromArgb(0, 122, 204);
			this.graph3D.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.graph3D.Cursor = global::System.Windows.Forms.Cursors.Default;
			this.graph3D.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.graph3D.Location = new global::System.Drawing.Point(12, 25);
			this.graph3D.Name = "graph3D";
			this.graph3D.PolygonLineColor = global::System.Drawing.Color.FromArgb(45, 45, 48);
			this.graph3D.Raster = global::Plot3D.Graph3D.eRaster.Off;
			this.graph3D.Size = new global::System.Drawing.Size(855, 410);
			this.graph3D.TabIndex = 6;
			this.graph3D.TopLegendColor = global::System.Drawing.Color.White;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(37, 37, 38);
			base.ClientSize = new global::System.Drawing.Size(900, 500);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.graph3D);
			base.Controls.Add(this.menuStrip);
			base.MainMenuStrip = this.menuStrip;
			this.Font = new global::System.Drawing.Font("Segoe UI", 8.25f);
			this.MinimumSize = new global::System.Drawing.Size(600, 400);
			base.Name = "Graph3DMainForm";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Graph 3D - Live Data Viewer";
			base.WindowState = global::System.Windows.Forms.FormWindowState.Normal;
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x06001306 RID: 4870 RVA: 0x00090630 File Offset: 0x00090630
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (this._autoRotateTimer != null)
				{
					this._autoRotateTimer.Stop();
					this._autoRotateTimer.Dispose();
					this._autoRotateTimer = null;
				}
				if (this.components != null)
				{
					this.components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		// Token: 0x04001A48 RID: 6728
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04001A49 RID: 6729
		private global::Plot3D.Graph3D graph3D;

		// Token: 0x04001A4A RID: 6730
		private global::System.Windows.Forms.Label lblInfo;

		// Token: 0x04001A4B RID: 6731
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04001A4D RID: 6733
		private global::System.Windows.Forms.MenuStrip menuStrip;

		// Token: 0x04001A4E RID: 6734
		private global::System.Windows.Forms.ToolStripMenuItem viewMenu;

		// Token: 0x04001A4F RID: 6735
		private global::System.Windows.Forms.ToolStripMenuItem wireFrameMenuItem;

		// Token: 0x04001A50 RID: 6736
		private global::System.Windows.Forms.ToolStripMenuItem autoRangeMenuItem;

		// Token: 0x04001A51 RID: 6737
		private global::System.Windows.Forms.ToolStripMenuItem heightColorMenuItem;

		// Token: 0x04001A52 RID: 6738
		private global::System.Windows.Forms.ToolStripMenuItem showAllPointsMenuItem;

		// Token: 0x04001A53 RID: 6739
		private global::System.Windows.Forms.ToolStripMenuItem showCompareBinsMenuItem;

		// Token: 0x04001A55 RID: 6741
		private global::System.Windows.Forms.ToolStripMenuItem resetPositionMenuItem;

		// Token: 0x04001A56 RID: 6742
		private global::System.Windows.Forms.ToolStripMenuItem dataSourceMenu;

		// Token: 0x04001A57 RID: 6743
		private global::System.Windows.Forms.TrackBar trackRho;

		// Token: 0x04001A58 RID: 6744
		private global::System.Windows.Forms.TrackBar trackTheta;

		// Token: 0x04001A59 RID: 6745
		private global::System.Windows.Forms.TrackBar trackPhi;

		// Token: 0x04001A5A RID: 6746
		private global::System.Windows.Forms.Label lblPerspective;

		// Token: 0x04001A5B RID: 6747
		private global::System.Windows.Forms.ToolStripMenuItem colorSchemeMenu;

		// Token: 0x04001A5C RID: 6748
		private global::System.Windows.Forms.ToolStripMenuItem perspectiveMenu;

		// Token: 0x04001A5D RID: 6749
		private global::System.Windows.Forms.ToolStripMenuItem toolsMenu;

		// Token: 0x04001A5E RID: 6750
		private global::System.Windows.Forms.ToolStripMenuItem screenshotMenuItem;

		// Token: 0x04001A60 RID: 6752
		private global::System.Windows.Forms.ToolStripMenuItem exitMenuItem;

		// Token: 0x04001A61 RID: 6753
		private global::System.Windows.Forms.ToolStripMenuItem editMenu;

		// Token: 0x04001A62 RID: 6754
		private global::System.Windows.Forms.ToolStripMenuItem dragGraphMenuItem;

		// Token: 0x04001A63 RID: 6755
		private global::System.Windows.Forms.ToolStripMenuItem rotateGraphMenuItem;

		// Token: 0x04001A64 RID: 6756
		private global::System.Windows.Forms.ToolStripMenuItem zoomGraphMenuItem;

		// Token: 0x04001A67 RID: 6759
		private global::System.Windows.Forms.ToolStripMenuItem autoRotateMenuItem;

		// Token: 0x04001A68 RID: 6760
		private global::System.Windows.Forms.ToolStripMenuItem autoRotateSpeedMenuItem;

		// Token: 0x04001A69 RID: 6761
		private global::System.Windows.Forms.Timer _autoRotateTimer;
	}
}
