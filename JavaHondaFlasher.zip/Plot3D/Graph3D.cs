﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using System.Windows.Forms;

namespace Plot3D
{
	// Token: 0x020007E1 RID: 2017
	public class Graph3D : UserControl
	{
		// Token: 0x1400000B RID: 11
		// (add) Token: 0x06001370 RID: 4976 RVA: 0x0009433C File Offset: 0x0009433C
		// (remove) Token: 0x06001371 RID: 4977 RVA: 0x00094374 File Offset: 0x00094374
		public event EventHandler<Graph3D.PointValueChangedEventArgs> PointValueChanged;

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x06001372 RID: 4978 RVA: 0x000943AC File Offset: 0x000943AC
		// (remove) Token: 0x06001373 RID: 4979 RVA: 0x000943E4 File Offset: 0x000943E4
		public event EventHandler SurfaceDataChanged;

		// Token: 0x1400000D RID: 13
		// (add) Token: 0x06001374 RID: 4980 RVA: 0x0009441C File Offset: 0x0009441C
		// (remove) Token: 0x06001375 RID: 4981 RVA: 0x00094454 File Offset: 0x00094454
		public event EventHandler<Graph3D.PointValueChangedEventArgs> LivePointChanged;

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x06001376 RID: 4982 RVA: 0x0000C53C File Offset: 0x0000C53C
		// (set) Token: 0x06001377 RID: 4983 RVA: 0x0000C544 File Offset: 0x0000C544
		public Graph3D.eRaster Raster
		{
			get
			{
				return this.me_Raster;
			}
			set
			{
				if (this.me_Raster != value)
				{
					this.me_Raster = value;
					this.mi_DrawObjects.Clear();
					this.SafeInvalidate();
				}
			}
		}

		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x06001378 RID: 4984 RVA: 0x0000C567 File Offset: 0x0000C567
		// (set) Token: 0x06001379 RID: 4985 RVA: 0x0000C582 File Offset: 0x0000C582
		public Color PolygonLineColor
		{
			get
			{
				if (this.mi_PolyLinePen != null)
				{
					return this.mi_PolyLinePen.Color;
				}
				return Color.Empty;
			}
			set
			{
				this.mi_PolyLinePen = ((value.A == 0) ? null : new Pen(value));
				this.SafeInvalidate();
			}
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x0600137A RID: 4986 RVA: 0x0000C5A2 File Offset: 0x0000C5A2
		// (set) Token: 0x0600137B RID: 4987 RVA: 0x0000C5BD File Offset: 0x0000C5BD
		public Color BorderColor
		{
			get
			{
				if (this.mi_BorderPen != null)
				{
					return this.mi_BorderPen.Color;
				}
				return Color.Empty;
			}
			set
			{
				this.mi_BorderPen = ((value.A == 0) ? null : new Pen(value));
				this.SafeInvalidate();
			}
		}

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x0600137C RID: 4988 RVA: 0x0000C5DD File Offset: 0x0000C5DD
		// (set) Token: 0x0600137D RID: 4989 RVA: 0x0000C5F8 File Offset: 0x0000C5F8
		public Color TopLegendColor
		{
			get
			{
				if (this.mi_TopLegendBrush != null)
				{
					return this.mi_TopLegendBrush.Color;
				}
				return Color.Empty;
			}
			set
			{
				this.mi_TopLegendBrush = new SolidBrush(value);
				this.SafeInvalidate();
			}
		}

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x0600137E RID: 4990 RVA: 0x0000C60C File Offset: 0x0000C60C
		// (set) Token: 0x0600137F RID: 4991 RVA: 0x0000C616 File Offset: 0x0000C616
		public string AxisX_Legend
		{
			get
			{
				return this.ms_AxisLegends[0];
			}
			set
			{
				this.ms_AxisLegends[0] = value;
				this.SafeInvalidate();
			}
		}

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x06001380 RID: 4992 RVA: 0x0000C627 File Offset: 0x0000C627
		// (set) Token: 0x06001381 RID: 4993 RVA: 0x0000C631 File Offset: 0x0000C631
		public string AxisY_Legend
		{
			get
			{
				return this.ms_AxisLegends[1];
			}
			set
			{
				this.ms_AxisLegends[1] = value;
				this.SafeInvalidate();
			}
		}

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x06001382 RID: 4994 RVA: 0x0000C642 File Offset: 0x0000C642
		// (set) Token: 0x06001383 RID: 4995 RVA: 0x0000C64C File Offset: 0x0000C64C
		public string AxisZ_Legend
		{
			get
			{
				return this.ms_AxisLegends[2];
			}
			set
			{
				this.ms_AxisLegends[2] = value;
				this.SafeInvalidate();
			}
		}

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x06001384 RID: 4996 RVA: 0x0000C65D File Offset: 0x0000C65D
		// (set) Token: 0x06001385 RID: 4997 RVA: 0x0000C67C File Offset: 0x0000C67C
		public Color AxisX_Color
		{
			get
			{
				if (this.mi_AxisPens[0] == null)
				{
					return Color.Empty;
				}
				return this.mi_AxisPens[0].Color;
			}
			set
			{
				this.SetAxisColor(Graph3D.eCoord.X, value);
				this.SafeInvalidate();
			}
		}

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x06001386 RID: 4998 RVA: 0x0000C68C File Offset: 0x0000C68C
		// (set) Token: 0x06001387 RID: 4999 RVA: 0x0000C6AB File Offset: 0x0000C6AB
		public Color AxisY_Color
		{
			get
			{
				if (this.mi_AxisPens[1] == null)
				{
					return Color.Empty;
				}
				return this.mi_AxisPens[1].Color;
			}
			set
			{
				this.SetAxisColor(Graph3D.eCoord.Y, value);
				this.SafeInvalidate();
			}
		}

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x06001388 RID: 5000 RVA: 0x0000C6BB File Offset: 0x0000C6BB
		// (set) Token: 0x06001389 RID: 5001 RVA: 0x0000C6DA File Offset: 0x0000C6DA
		public Color AxisZ_Color
		{
			get
			{
				if (this.mi_AxisPens[2] == null)
				{
					return Color.Empty;
				}
				return this.mi_AxisPens[2].Color;
			}
			set
			{
				this.SetAxisColor(Graph3D.eCoord.Z, value);
				this.SafeInvalidate();
			}
		}

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x0600138A RID: 5002 RVA: 0x0000C6EA File Offset: 0x0000C6EA
		[Browsable(false)]
		public int TotalPoints
		{
			get
			{
				return this.ms32_Points;
			}
		}

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x0600138B RID: 5003 RVA: 0x0000C6F2 File Offset: 0x0000C6F2
		[Browsable(false)]
		public int GridWidth
		{
			get
			{
				if (this.mi_PolyArr == null)
				{
					return 0;
				}
				return this.mi_PolyArr.GetLength(0);
			}
		}

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x0600138C RID: 5004 RVA: 0x0000C70A File Offset: 0x0000C70A
		[Browsable(false)]
		public int GridHeight
		{
			get
			{
				if (this.mi_PolyArr == null)
				{
					return 0;
				}
				return this.mi_PolyArr.GetLength(1);
			}
		}

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x0600138D RID: 5005 RVA: 0x0000C722 File Offset: 0x0000C722
		[Browsable(false)]
		public Graph3D.cPoint3D[,] SurfaceData
		{
			get
			{
				return this.mi_PolyArr;
			}
		}

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x0600138E RID: 5006 RVA: 0x0000C72A File Offset: 0x0000C72A
		// (set) Token: 0x0600138F RID: 5007 RVA: 0x0000C732 File Offset: 0x0000C732
		[Browsable(true)]
		[Category("View")]
		[Description("Tampilkan mode wireframe")]
		public bool ShowWireframe
		{
			get
			{
				return this._showWireframe;
			}
			set
			{
				if (this._showWireframe != value)
				{
					this._showWireframe = value;
					this.PolygonLineColor = (value ? Color.Yellow : Color.FromArgb(45, 45, 48));
					this.SafeInvalidate();
				}
			}
		}

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x06001390 RID: 5008 RVA: 0x0000C765 File Offset: 0x0000C765
		// (set) Token: 0x06001391 RID: 5009 RVA: 0x0000C76D File Offset: 0x0000C76D
		[Browsable(true)]
		[Category("View")]
		[Description("Aktifkan auto-scaling sumbu Z")]
		public bool AutoRange
		{
			get
			{
				return this._autoRange;
			}
			set
			{
				if (this._autoRange != value)
				{
					this._autoRange = value;
					if (this.mi_PolyArr != null && !this.mb_LockNormalization)
					{
						this.NormalizeRanges(this._currentNormalizeMode);
						this.RebuildDrawObjects();
					}
				}
			}
		}

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x06001392 RID: 5010 RVA: 0x0000C7A1 File Offset: 0x0000C7A1
		// (set) Token: 0x06001393 RID: 5011 RVA: 0x0000C7A9 File Offset: 0x0000C7A9
		[Browsable(true)]
		[Category("View")]
		[Description("Tampilkan semua titik data sebagai marker")]
		public bool ShowPoints
		{
			get
			{
				return this._showPoints;
			}
			set
			{
				this._showPoints = value;
				if (value)
				{
					this.GenerateAllPoints();
				}
				else
				{
					this._allPoints.Clear();
				}
				this.SafeInvalidate();
			}
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x06001394 RID: 5012 RVA: 0x0000C7CE File Offset: 0x0000C7CE
		// (set) Token: 0x06001395 RID: 5013 RVA: 0x0000C7D6 File Offset: 0x0000C7D6
		[Browsable(true)]
		[Category("View")]
		[Description("Tampilkan overlay perbandingan bin")]
		public bool ShowCompareBins
		{
			get
			{
				return this._showCompareBins;
			}
			set
			{
				this._showCompareBins = value;
				this.SafeInvalidate();
			}
		}

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x06001396 RID: 5014 RVA: 0x0000C7E5 File Offset: 0x0000C7E5
		// (set) Token: 0x06001397 RID: 5015 RVA: 0x0000C7ED File Offset: 0x0000C7ED
		[Browsable(true)]
		[Category("Behavior")]
		[Description("Sensitivitas drag titik (0.01 - 1.0, relatif terhadap range Z).")]
		public double DragSensitivity
		{
			get
			{
				return this.md_DragSensitivity;
			}
			set
			{
				this.md_DragSensitivity = Math.Max(0.01, Math.Min(1.0, value));
			}
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x06001398 RID: 5016 RVA: 0x0000C812 File Offset: 0x0000C812
		// (set) Token: 0x06001399 RID: 5017 RVA: 0x0000C81A File Offset: 0x0000C81A
		[Browsable(true)]
		[Category("Behavior")]
		[Description("Mengaktifkan/menonaktifkan drag/move graph")]
		public bool AllowDrag
		{
			get
			{
				return this._allowDrag;
			}
			set
			{
				this._allowDrag = value;
				this.SafeInvalidate();
			}
		}

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x0600139A RID: 5018 RVA: 0x0000C829 File Offset: 0x0000C829
		// (set) Token: 0x0600139B RID: 5019 RVA: 0x0000C831 File Offset: 0x0000C831
		[Browsable(true)]
		[Category("Behavior")]
		[Description("Mengaktifkan/menonaktifkan rotasi graph")]
		public bool AllowRotate
		{
			get
			{
				return this._allowRotate;
			}
			set
			{
				this._allowRotate = value;
				this.SafeInvalidate();
			}
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x0600139C RID: 5020 RVA: 0x0000C840 File Offset: 0x0000C840
		// (set) Token: 0x0600139D RID: 5021 RVA: 0x0000C848 File Offset: 0x0000C848
		[Browsable(true)]
		[Category("Behavior")]
		[Description("Mengaktifkan/menonaktifkan zoom graph")]
		public bool AllowZoom
		{
			get
			{
				return this._allowZoom;
			}
			set
			{
				this._allowZoom = value;
				this.SafeInvalidate();
			}
		}

		// Token: 0x17000105 RID: 261
		// (get) Token: 0x0600139E RID: 5022 RVA: 0x0000C857 File Offset: 0x0000C857
		// (set) Token: 0x0600139F RID: 5023 RVA: 0x0000C85F File Offset: 0x0000C85F
		public int LivePointerSize
		{
			get
			{
				return this._livePointerSize;
			}
			set
			{
				this._livePointerSize = Math.Max(4, Math.Min(20, value));
				base.Invalidate();
			}
		}

		// Token: 0x17000106 RID: 262
		// (get) Token: 0x060013A0 RID: 5024 RVA: 0x0000C87B File Offset: 0x0000C87B
		// (set) Token: 0x060013A1 RID: 5025 RVA: 0x0000C883 File Offset: 0x0000C883
		public bool ShowLiveLabel
		{
			get
			{
				return this._showLiveLabel;
			}
			set
			{
				this._showLiveLabel = value;
				base.Invalidate();
			}
		}

		// Token: 0x060013A2 RID: 5026 RVA: 0x0009448C File Offset: 0x0009448C
		public Graph3D()
		{
			this.md_Dist = 0.7;
			this._showWireframe = true;
			this._autoRange = true;
			this._showPoints = true;
			this._showClickedPoints = true;
			this._allowDrag = true;
			this._allowRotate = true;
			this._allowZoom = true;
			this.me_Raster = Graph3D.eRaster.Off;
			this.mi_AxisPens = new Pen[3];
			this.mi_RasterPens = new Pen[3];
			this.mi_AxisBrushes = new SolidBrush[3];
			this.mi_Transform = new Graph3D.cTransform();
			this.mi_Mouse = new Graph3D.cMouse();
			this.mk_Offset2D = new Point(0, -30);
			this.mi_DrawObjects = new List<Graph3D.cDrawObj>();
			this.mi_SelectedPoints = new List<Point>();
			this._allPoints = new List<Point>();
			this._clickedPoints = new List<Point>();
			this.ms32_SelectedX = -1;
			this.ms32_SelectedY = -1;
			this.ms32_HoverX = -1;
			this.ms32_HoverY = -1;
			this.mk_LastMouseScreen = Point.Empty;
			this.md_DragSensitivity = 0.08;
			this.mi_SelectedPen = new Pen(Color.Yellow, 2f);
			this.mi_HoverPen = new Pen(Color.Cyan, 2f);
			this.mi_SelectionPen = new Pen(Color.Lime, 2f)
			{
				DashStyle = DashStyle.Dash
			};
			this.mi_SelectionFill = new SolidBrush(Color.FromArgb(50, 0, 255, 0));
			this._livePointerLock = new object();
			this._liveRpmRangeLock = new object();
			this._livePointerX = -1;
			this._livePointerY = -1;
			this._livePointerSize = 10;
			this._showLiveLabel = true;
			this._liveRpmMin = double.NaN;
			this._liveRpmMax = double.NaN;
			this.ms_AxisLegends = new string[3];
			this.InitializeControl();
			this.InitializeDefaultColors();
			this.InitializeTransform();
			this.InitializeInteraction();
		}

		// Token: 0x060013A3 RID: 5027 RVA: 0x00094664 File Offset: 0x00094664
		public void SetColorScheme(Color[] c_Colors, float f_LineWidth)
		{
			this.mi_SchemeBrushes = new SolidBrush[c_Colors.Length];
			this.mi_SchemePens = new Pen[c_Colors.Length];
			checked
			{
				for (int i = 0; i < c_Colors.Length; i++)
				{
					this.mi_SchemeBrushes[i] = new SolidBrush(c_Colors[i]);
					this.mi_SchemePens[i] = new Pen(this.mi_SchemeBrushes[i], f_LineWidth);
				}
				this.SafeInvalidate();
			}
		}

		// Token: 0x060013A4 RID: 5028 RVA: 0x000946CC File Offset: 0x000946CC
		public void AssignTrackBars(TrackBar i_Rho, TrackBar i_Theta, TrackBar i_Phi)
		{
			this.mi_Mouse.AssignTrackbar(Graph3D.eMouseAction.Rho, i_Rho, new EventHandler(this.OnTrackbarScroll));
			this.mi_Mouse.AssignTrackbar(Graph3D.eMouseAction.Theta, i_Theta, new EventHandler(this.OnTrackbarScroll));
			this.mi_Mouse.AssignTrackbar(Graph3D.eMouseAction.Phi, i_Phi, new EventHandler(this.OnTrackbarScroll));
		}

		// Token: 0x060013A5 RID: 5029 RVA: 0x00094724 File Offset: 0x00094724
		public void SetFunction(Graph3D.delRendererFunction f_Function, PointF k_Start, PointF k_End, double d_Density, Graph3D.eNormalize e_Normalize)
		{
			this._currentNormalizeMode = e_Normalize;
			checked
			{
				int num = (int)(unchecked((double)(k_End.X - k_Start.X) / d_Density + 1.0));
				int num2 = (int)(unchecked((double)(k_End.Y - k_Start.Y) / d_Density + 1.0));
				Graph3D.cPoint3D[,] array = new Graph3D.cPoint3D[num, num2];
				for (int i = 0; i < num; i++)
				{
					double x = unchecked((double)k_Start.X + d_Density * (double)i);
					for (int j = 0; j < num2; j++)
					{
						double y = unchecked((double)k_Start.Y + d_Density * (double)j);
						array[i, j] = new Graph3D.cPoint3D(x, y, f_Function(x, y));
					}
				}
				this.SetSurfacePoints(array, e_Normalize);
			}
		}

		// Token: 0x060013A6 RID: 5030 RVA: 0x000947E4 File Offset: 0x000947E4
		public void SetSurfacePoints(Graph3D.cPoint3D[,] i_Points3D, Graph3D.eNormalize e_Normalize)
		{
			if (i_Points3D == null)
			{
				throw new ArgumentNullException("i_Points3D");
			}
			int length = i_Points3D.Length;
			if (length < 4)
			{
				throw new Exception("Insufficient 3D points specified");
			}
			if (this.mi_SelectedPoints != null)
			{
				this.mi_SelectedPoints.Clear();
			}
			if (this._selectedPointsSet != null)
			{
				this._selectedPointsSet.Clear();
			}
			if (this._clickedPoints != null)
			{
				this._clickedPoints.Clear();
			}
			this.ms32_SelectedX = -1;
			this.ms32_SelectedY = -1;
			this.mb_BlockEditActive = false;
			this.mb_DragAreaEdit = false;
			this.mb_DragPoint = false;
			this.mb_EditMode = false;
			this.mb_SelectingArea = false;
			this.md_OriginalZValues = null;
			this.md_AccumulatedDrag = 0.0;
			this._currentNormalizeMode = e_Normalize;
			this.mi_ScatterArr = null;
			this.mi_PolyArr = i_Points3D;
			this.ms32_Points = length;
			this.mi_MinMax = new Graph3D.cMinMax3D(i_Points3D);
			this.NormalizeRanges(e_Normalize);
			if (this.mi_LiveMode)
			{
				this.LockNormalization();
			}
			this.ResetViewState();
			this.InitLiveOverlay();
			this.BuildGeometry();
			if (this._showPoints)
			{
				this.GenerateAllPoints();
			}
			this.OnSurfaceDataChanged();
			this.SafeInvalidate();
			this.SyncGridSelectionColorsFromGraph();
		}

		// Token: 0x060013A7 RID: 5031 RVA: 0x00094904 File Offset: 0x00094904
		public void SetScatterPoints(Graph3D.cScatter[] i_Scatter, Graph3D.eNormalize e_Normalize)
		{
			this._currentNormalizeMode = e_Normalize;
			this.mi_PolyArr = null;
			this.mi_ScatterArr = i_Scatter;
			this.ms32_Points = i_Scatter.Length;
			this.mi_MinMax = new Graph3D.cMinMax3D(i_Scatter);
			this.NormalizeRanges(e_Normalize);
			this.ResetViewState();
			this.BuildGeometry();
			if (this._showPoints)
			{
				this.GenerateAllPoints();
			}
			this.SafeInvalidate();
		}

		// Token: 0x060013A8 RID: 5032 RVA: 0x00094964 File Offset: 0x00094964
		public void SetScatterLines(Graph3D.cScatter[] i_ScatterArr, Graph3D.eNormalize e_Normalize, float f_LineWidth)
		{
			Graph3D.cScatter mi_Previous = null;
			foreach (Graph3D.cScatter cScatter in i_ScatterArr)
			{
				cScatter.mb_Combine = true;
				cScatter.mi_Previous = mi_Previous;
				if (cScatter.mi_Brush != null)
				{
					cScatter.mi_Pen = new Pen(cScatter.mi_Brush, f_LineWidth);
				}
				mi_Previous = cScatter;
			}
			this.SetScatterPoints(i_ScatterArr, e_Normalize);
		}

		// Token: 0x060013A9 RID: 5033 RVA: 0x000949BC File Offset: 0x000949BC
		public void SetCoefficients(double d_Rho, double d_Theta, double d_Phi)
		{
			this.mi_Mouse.SetRho(d_Rho);
			this.mi_Mouse.SetTheta(d_Theta);
			this.mi_Mouse.SetPhi(d_Phi);
			this.mi_Transform.SetCoeficients(this.mi_Mouse);
			this.mi_DrawObjects.Clear();
			this.BuildGeometry();
			this.SafeInvalidate();
		}

		// Token: 0x060013AA RID: 5034 RVA: 0x00094A18 File Offset: 0x00094A18
		public double GetValueAt(int x, int y)
		{
			if (this.mi_PolyArr == null || x < 0 || x >= this.mi_PolyArr.GetLength(0) || y < 0 || y >= this.mi_PolyArr.GetLength(1))
			{
				return 0.0;
			}
			return this.mi_PolyArr[x, y].md_Z;
		}

		// Token: 0x060013AB RID: 5035 RVA: 0x0000C892 File Offset: 0x0000C892
		public void SetValueAt(int x, int y, double value)
		{
			this.UpdateSurfaceValue(x, y, value);
		}

		// Token: 0x060013AC RID: 5036 RVA: 0x00094A70 File Offset: 0x00094A70
		public void SetAllValues(double[,] values)
		{
			if (this.mi_PolyArr == null || values == null)
			{
				return;
			}
			bool suppressSurfaceEvent = this._suppressSurfaceEvent;
			this._suppressSurfaceEvent = true;
			bool flag = false;
			checked
			{
				try
				{
					int num = Math.Min(values.GetLength(0), this.mi_PolyArr.GetLength(0));
					int num2 = Math.Min(values.GetLength(1), this.mi_PolyArr.GetLength(1));
					for (int i = 0; i < num; i++)
					{
						for (int j = 0; j < num2; j++)
						{
							if (!this.IsBoundaryPoint(i, j))
							{
								double num3 = values[i, j];
								if (double.IsNaN(num3) || double.IsInfinity(num3))
								{
									num3 = 0.0;
								}
								if (Math.Abs(unchecked(this.mi_PolyArr[i, j].md_Z - num3)) >= 0.0001)
								{
									this.mi_PolyArr[i, j].md_Z = num3;
									this.SetLiveZ(i, j, num3);
									flag = true;
								}
							}
						}
					}
					if (flag)
					{
						this.SyncOverlayFromArray();
					}
				}
				finally
				{
					this._suppressSurfaceEvent = suppressSurfaceEvent;
				}
				if (!flag)
				{
					return;
				}
				if (!this.mb_FreezeGeometry)
				{
					this.mi_DrawObjects.Clear();
					this.BuildGeometry();
				}
				this.OnSurfaceDataChanged();
				base.Invalidate();
			}
		}

		// Token: 0x060013AD RID: 5037 RVA: 0x00094BC4 File Offset: 0x00094BC4
		public double[,] GetAllValues()
		{
			if (this.mi_PolyArr == null)
			{
				return new double[0, 0];
			}
			double[,] array = new double[this.mi_PolyArr.GetLength(0), this.mi_PolyArr.GetLength(1)];
			checked
			{
				for (int i = 0; i < this.mi_PolyArr.GetLength(0); i++)
				{
					for (int j = 0; j < this.mi_PolyArr.GetLength(1); j++)
					{
						array[i, j] = this.mi_PolyArr[i, j].md_Z;
					}
				}
				return array;
			}
		}

		// Token: 0x060013AE RID: 5038 RVA: 0x00094C48 File Offset: 0x00094C48
		public void BindToDataGridView(DataGridView grid)
		{
			if (this.mi_PolyArr == null || grid == null || grid.IsDisposed)
			{
				return;
			}
			this._boundGrid = grid;
			this._gridHasHeaderRow = false;
			this._suppressGridEvent = true;
			bool flag = false;
			checked
			{
				try
				{
					grid.SuspendLayout();
					flag = true;
					grid.CellValueChanged -= this.OnGridCellValueChanged;
					int length = this.mi_PolyArr.GetLength(0);
					int length2 = this.mi_PolyArr.GetLength(1);
					if (grid.ColumnCount != length || grid.RowCount != length2)
					{
						grid.Rows.Clear();
						grid.Columns.Clear();
						grid.ColumnCount = length;
						for (int i = 0; i < length; i++)
						{
							DataGridViewColumn dataGridViewColumn = grid.Columns[i];
							dataGridViewColumn.Name = "X" + i;
							dataGridViewColumn.HeaderText = "X" + i;
							dataGridViewColumn.Width = 60;
							dataGridViewColumn.SortMode = DataGridViewColumnSortMode.NotSortable;
							dataGridViewColumn.DefaultCellStyle.Format = "0.000";
							dataGridViewColumn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
						}
						grid.RowCount = length2;
						for (int j = 0; j < length2; j++)
						{
							grid.Rows[j].HeaderCell.Value = "Y" + j;
							grid.Rows[j].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
						}
					}
					for (int k = 0; k < length2; k++)
					{
						for (int l = 0; l < length; l++)
						{
							grid.Rows[k].Cells[l].Value = this.mi_PolyArr[l, k].md_Z;
						}
					}
					grid.CellValueChanged += this.OnGridCellValueChanged;
				}
				catch (Exception ex)
				{
					Console.WriteLine("BindToDataGridView Error: " + ex.Message);
				}
				finally
				{
					this._suppressGridEvent = false;
					if (flag)
					{
						grid.ResumeLayout(false);
					}
				}
				grid.Invalidate();
				this.SyncGridSelectionColorsFromGraph();
			}
		}

		// Token: 0x060013AF RID: 5039 RVA: 0x00094E84 File Offset: 0x00094E84
		public void UpdateDataGridView(DataGridView grid)
		{
			if (this.mi_PolyArr == null || grid == null || grid.IsDisposed)
			{
				return;
			}
			if (grid.Rows.Count == 0 || grid.Columns.Count == 0)
			{
				this.BindToDataGridViewPreserve(grid);
				return;
			}
			bool suppressGridEvent = this._suppressGridEvent;
			this._suppressGridEvent = true;
			checked
			{
				try
				{
					grid.SuspendLayout();
					int length = this.mi_PolyArr.GetLength(0);
					int length2 = this.mi_PolyArr.GetLength(1);
					int num = this._gridHasHeaderRow ? 1 : 0;
					int num2 = this._gridHasHeaderRow ? 1 : 0;
					if (grid.Rows.Count != length2 + num || grid.Columns.Count != length + num2)
					{
						grid.ResumeLayout();
						this._suppressGridEvent = suppressGridEvent;
						this.BindToDataGridViewPreserve(grid);
					}
					else
					{
						for (int i = 0; i < length2; i++)
						{
							for (int j = 0; j < length; j++)
							{
								grid.Rows[i + num].Cells[j + num2].Value = this.mi_PolyArr[j, i].md_Z;
							}
						}
						grid.ResumeLayout();
						grid.Refresh();
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine("UpdateDataGridView Error: " + ex.Message);
				}
				finally
				{
					this._suppressGridEvent = suppressGridEvent;
				}
			}
		}

		// Token: 0x060013B0 RID: 5040 RVA: 0x00094FF0 File Offset: 0x00094FF0
		public void BindToDataGridViewPreserve(DataGridView grid)
		{
			if (this.mi_PolyArr == null || grid == null || grid.IsDisposed)
			{
				return;
			}
			this._boundGrid = grid;
			this._gridHasHeaderRow = true;
			this._suppressGridEvent = true;
			checked
			{
				try
				{
					grid.SuspendLayout();
					grid.CellValueChanged -= this.OnGridCellValueChanged;
					int length = this.mi_PolyArr.GetLength(0);
					int length2 = this.mi_PolyArr.GetLength(1);
					if (grid.Rows.Count != length2 + 1 || grid.Columns.Count != length + 1)
					{
						grid.Rows.Clear();
						grid.Columns.Clear();
						grid.Columns.Add("X_Label", "X");
						for (int i = 0; i < length; i++)
						{
							grid.Columns.Add("X" + (i + 1), "X" + (i + 1));
							grid.Columns[i + 1].Width = 60;
							grid.Columns[i + 1].DefaultCellStyle.Format = "0.000";
						}
						grid.Rows.Add();
						grid.Rows[0].HeaderCell.Value = "Y";
						for (int j = 0; j < length2; j++)
						{
							int index = grid.Rows.Add();
							grid.Rows[index].HeaderCell.Value = "Y" + (j + 1);
						}
					}
					for (int k = 0; k < length2; k++)
					{
						for (int l = 0; l < length; l++)
						{
							if (k + 1 < grid.Rows.Count && l + 1 < grid.Columns.Count)
							{
								grid.Rows[k + 1].Cells[l + 1].Value = this.mi_PolyArr[l, k].md_Z;
							}
						}
					}
					grid.CellValueChanged += this.OnGridCellValueChanged;
					grid.ResumeLayout();
					grid.Refresh();
				}
				catch (Exception ex)
				{
					Console.WriteLine("BindToDataGridViewPreserve Error: " + ex.Message);
				}
				finally
				{
					this._suppressGridEvent = false;
				}
			}
		}

		// Token: 0x060013B1 RID: 5041 RVA: 0x00095274 File Offset: 0x00095274
		private void OnGridCellValueChanged(object sender, DataGridViewCellEventArgs e)
		{
			if (this._suppressGridEvent)
			{
				return;
			}
			if (e.RowIndex < 0 || e.ColumnIndex < 0)
			{
				return;
			}
			DataGridView dataGridView = sender as DataGridView;
			if (dataGridView == null)
			{
				return;
			}
			int num = this._gridHasHeaderRow ? 1 : 0;
			int num2 = this._gridHasHeaderRow ? 1 : 0;
			checked
			{
				int num3 = e.ColumnIndex - num2;
				int num4 = e.RowIndex - num;
				if (num3 < 0 || num4 < 0)
				{
					return;
				}
				try
				{
					object value = dataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
					double value2;
					if (value != null && double.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), NumberStyles.Any, CultureInfo.InvariantCulture, out value2))
					{
						this.UpdateSurfaceValue(num3, num4, value2);
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine("OnGridCellValueChanged Error: " + ex.Message);
				}
			}
		}

		// Token: 0x060013B2 RID: 5042 RVA: 0x00095364 File Offset: 0x00095364
		public void HighlightPoint(int x, int y, double value)
		{
			if (this.mi_PolyArr == null || x < 0 || x >= this.mi_PolyArr.GetLength(0) || y < 0 || y >= this.mi_PolyArr.GetLength(1))
			{
				return;
			}
			this.UpdateSurfaceValue(x, y, value);
			this.SelectPoint(x, y);
		}

		// Token: 0x060013B3 RID: 5043 RVA: 0x000953B4 File Offset: 0x000953B4
		public void SelectPoint(int x, int y)
		{
			if (this.mi_PolyArr == null || x < 0 || x >= this.mi_PolyArr.GetLength(0) || y < 0 || y >= this.mi_PolyArr.GetLength(1))
			{
				return;
			}
			this.ms32_SelectedX = x;
			this.ms32_SelectedY = y;
			this.mi_SelectedPoints.Add(new Point(x, y));
			base.Invalidate();
		}

		// Token: 0x060013B4 RID: 5044 RVA: 0x00095418 File Offset: 0x00095418
		public void ClearSelection()
		{
			this.mi_SelectedPoints.Clear();
			if (this._selectedPointsSet != null)
			{
				this._selectedPointsSet.Clear();
			}
			this.ms32_SelectedX = -1;
			this.ms32_SelectedY = -1;
			this.mb_DragAreaEdit = false;
			this.mb_BlockEditActive = false;
			this.Cursor = Cursors.Arrow;
			base.Invalidate();
			this.NotifySelectionChangedToGrid();
		}

		// Token: 0x060013B5 RID: 5045 RVA: 0x0000C89D File Offset: 0x0000C89D
		public List<Point> GetSelectedPoints()
		{
			return new List<Point>(this.mi_SelectedPoints);
		}

		// Token: 0x060013B6 RID: 5046 RVA: 0x0000C8AA File Offset: 0x0000C8AA
		public int GetSelectedPointCount()
		{
			return this.mi_SelectedPoints.Count;
		}

		// Token: 0x060013B7 RID: 5047 RVA: 0x00095478 File Offset: 0x00095478
		public void EnableEditMode(bool enable)
		{
			this.mb_EditMode = enable;
			if (!enable)
			{
				this.ms32_SelectedX = -1;
				this.ms32_SelectedY = -1;
				this.mi_SelectedPoints.Clear();
				this.mb_DragPoint = false;
				this.mb_DragAreaEdit = false;
				this.mb_BlockEditActive = false;
				this.Cursor = Cursors.Arrow;
			}
			base.Invalidate();
		}

		// Token: 0x060013B8 RID: 5048 RVA: 0x0000C8B7 File Offset: 0x0000C8B7
		public bool IsEditModeEnabled()
		{
			return this.mb_EditMode;
		}

		// Token: 0x060013B9 RID: 5049 RVA: 0x000954D0 File Offset: 0x000954D0
		public void EnableLiveMode(bool enable)
		{
			if (base.IsDisposed || base.Disposing)
			{
				return;
			}
			if (base.InvokeRequired)
			{
				try
				{
					base.BeginInvoke(new Action(delegate()
					{
						this.EnableLiveMode(enable);
					}));
				}
				catch
				{
				}
				return;
			}
			this.mi_LiveMode = enable;
			this.mb_LiveMode = enable;
			if (enable)
			{
				this._livePointerX = 0;
				this._livePointerY = 0;
				if (this.mi_PolyArr != null && this.mi_PolyArr.GetLength(0) > 0 && this.mi_PolyArr.GetLength(1) > 0)
				{
					this._livePointerZ = this.GetLiveZ(0, 0);
				}
				this._livePointerVisible = true;
			}
			base.Invalidate();
		}

		// Token: 0x060013BA RID: 5050 RVA: 0x0000C8BF File Offset: 0x0000C8BF
		public bool IsLiveModeActive()
		{
			return !base.IsDisposed && !base.Disposing && this.mi_LiveMode;
		}

		// Token: 0x060013BB RID: 5051 RVA: 0x0000C8D9 File Offset: 0x0000C8D9
		public void UpdateLiveData(int x, int y, double z)
		{
			this.UpdateLiveDataDirect(x, y, z);
		}

		// Token: 0x060013BC RID: 5052 RVA: 0x0000C892 File Offset: 0x0000C892
		public void UpdateValueOnly(int x, int y, double value)
		{
			this.UpdateSurfaceValue(x, y, value);
		}

		// Token: 0x060013BD RID: 5053 RVA: 0x000955A4 File Offset: 0x000955A4
		public void SetLivePointer(int x, int y)
		{
			if (base.IsDisposed || base.Disposing || this.mi_PolyArr == null)
			{
				return;
			}
			checked
			{
				try
				{
					int val = this.mi_PolyArr.GetLength(0) - 1;
					int val2 = this.mi_PolyArr.GetLength(1) - 1;
					x = Math.Max(0, Math.Min(val, x));
					y = Math.Max(0, Math.Min(val2, y));
					this.SyncLivePointer(x, y, this.GetLiveZ(x, y), 0.0, 0.0, false);
					this.SafeInvalidate();
				}
				catch (Exception ex)
				{
					Console.WriteLine("SetLivePointer error: " + ex.Message);
				}
			}
		}

		// Token: 0x060013BE RID: 5054 RVA: 0x0000C8E4 File Offset: 0x0000C8E4
		public void ClearLivePointer()
		{
			if (!base.IsDisposed && !base.Disposing)
			{
				this._livePointerVisible = false;
				this.SafeInvalidate();
			}
		}

		// Token: 0x060013BF RID: 5055 RVA: 0x0009565C File Offset: 0x0009565C
		public void UpdateLiveDataDirect(int x, int y, double z)
		{
			try
			{
				if (double.IsNaN(z) || double.IsInfinity(z))
				{
					z = 0.0;
				}
				this.ApplyLiveUpdateFast(x, y, 0.0, 0.0, z, false);
			}
			catch (Exception ex)
			{
				Console.WriteLine("[LIVE FIX ERROR] " + ex.Message);
			}
		}

		// Token: 0x060013C0 RID: 5056 RVA: 0x000956CC File Offset: 0x000956CC
		public void UpdateLiveGridData(int x, int y, double value)
		{
			try
			{
				if (double.IsNaN(value) || double.IsInfinity(value))
				{
					value = 0.0;
				}
				this.ApplyLiveUpdateFast(x, y, 0.0, 0.0, value, false);
			}
			catch (Exception ex)
			{
				Console.WriteLine("[LIVE GRID] ERROR: " + ex.Message);
			}
		}

		// Token: 0x060013C1 RID: 5057 RVA: 0x0009573C File Offset: 0x0009573C
		public void UpdateLiveDataDirect(int x, int y, double rpm, double tps, double z)
		{
			try
			{
				if (double.IsNaN(rpm) || double.IsInfinity(rpm))
				{
					rpm = 0.0;
				}
				if (double.IsNaN(tps) || double.IsInfinity(tps))
				{
					tps = 0.0;
				}
				if (double.IsNaN(z) || double.IsInfinity(z))
				{
					z = 0.0;
				}
				this.ApplyLiveUpdateFast(x, y, rpm, tps, z, true);
			}
			catch (Exception ex)
			{
				Console.WriteLine("[LIVE DIRECT ERROR] " + ex.Message);
			}
		}

		// Token: 0x060013C2 RID: 5058 RVA: 0x000957D8 File Offset: 0x000957D8
		public void UpdateLiveData(double rpm, double tps, double z)
		{
			try
			{
				if (this.mi_ProjectedPoints != null)
				{
					if (double.IsNaN(rpm) || double.IsInfinity(rpm))
					{
						rpm = 0.0;
					}
					if (double.IsNaN(tps) || double.IsInfinity(tps))
					{
						tps = 0.0;
					}
					if (double.IsNaN(z) || double.IsInfinity(z))
					{
						z = 0.0;
					}
					int num = this.MapTpsToLivePointerX(tps);
					int num2 = this.MapRpmToLivePointerY(rpm);
					this.SetLiveZ(num, num2, z);
					object livePointerLock = this._livePointerLock;
					lock (livePointerLock)
					{
						this._livePointerX = num;
						this._livePointerY = num2;
						this._livePointerZ = z;
						this._livePointerRPM = rpm;
						this._livePointerTPS = tps;
						this._livePointerVisible = true;
					}
					EventHandler<Graph3D.PointValueChangedEventArgs> livePointChanged = this.LivePointChanged;
					if (livePointChanged != null)
					{
						livePointChanged(this, new Graph3D.PointValueChangedEventArgs(num, num2, z, z));
					}
					this.SafeInvalidate();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("[UpdateLiveData ERROR] " + ex.Message);
			}
		}

		// Token: 0x060013C3 RID: 5059 RVA: 0x0000C903 File Offset: 0x0000C903
		public void RebuildDrawObjects()
		{
			this.mi_DrawObjects.Clear();
			this.BuildGeometry();
			if (this._showPoints)
			{
				this.GenerateAllPoints();
			}
			this.SafeInvalidate();
		}

		// Token: 0x060013C4 RID: 5060 RVA: 0x0000C92A File Offset: 0x0000C92A
		public void ForceRebuildGeometry()
		{
			this.mi_DrawObjects.Clear();
			this.mi_ProjectedPoints = null;
			this.BuildGeometry();
			this.SafeInvalidate();
		}

		// Token: 0x060013C5 RID: 5061 RVA: 0x000958FC File Offset: 0x000958FC
		public void ForceShowPointer()
		{
			if (this.mi_PolyArr == null)
			{
				return;
			}
			int length = this.mi_PolyArr.GetLength(0);
			int length2 = this.mi_PolyArr.GetLength(1);
			if (length > 0 && length2 > 0)
			{
				int x = length / 2;
				int y = length2 / 2;
				this.SyncLivePointer(x, y, this.GetLiveZ(x, y), 0.0, 0.0, false);
				this.SafeInvalidate();
			}
		}

		// Token: 0x060013C6 RID: 5062 RVA: 0x0000C94A File Offset: 0x0000C94A
		public void UpdateLivePointer(int x, int y)
		{
			this.SetLivePointer(x, y);
		}

		// Token: 0x060013C7 RID: 5063 RVA: 0x00095968 File Offset: 0x00095968
		public void AddClickedPoint(int x, int y)
		{
			if (this.mi_PolyArr == null || x < 0 || x >= this.mi_PolyArr.GetLength(0) || y < 0 || y >= this.mi_PolyArr.GetLength(1))
			{
				return;
			}
			Point item = new Point(x, y);
			if (!this._clickedPoints.Contains(item))
			{
				this._clickedPoints.Add(item);
				this.SafeInvalidate();
			}
		}

		// Token: 0x060013C8 RID: 5064 RVA: 0x000959D0 File Offset: 0x000959D0
		public void RemoveClickedPoint(int x, int y)
		{
			Point item = new Point(x, y);
			if (this._clickedPoints.Contains(item))
			{
				this._clickedPoints.Remove(item);
				this.SafeInvalidate();
			}
		}

		// Token: 0x060013C9 RID: 5065 RVA: 0x0000C954 File Offset: 0x0000C954
		public void ClearClickedPoints()
		{
			this._clickedPoints.Clear();
			this.SafeInvalidate();
		}

		// Token: 0x060013CA RID: 5066 RVA: 0x0000C967 File Offset: 0x0000C967
		public List<Point> GetClickedPoints()
		{
			return new List<Point>(this._clickedPoints);
		}

		// Token: 0x060013CB RID: 5067 RVA: 0x0000C974 File Offset: 0x0000C974
		public int GetClickedPointCount()
		{
			return this._clickedPoints.Count;
		}

		// Token: 0x060013CC RID: 5068 RVA: 0x0000C981 File Offset: 0x0000C981
		public void ToggleClickedPoints(bool show)
		{
			this._showClickedPoints = show;
			this.SafeInvalidate();
		}

		// Token: 0x060013CD RID: 5069 RVA: 0x0000C990 File Offset: 0x0000C990
		public void EnableAreaDrag(bool enable)
		{
			this.mb_DragAreaEdit = enable;
			if (enable)
			{
				this.mb_EditMode = true;
				this.Cursor = Cursors.SizeWE;
			}
			else
			{
				this.mb_DragAreaEdit = false;
				this.mb_DragPoint = false;
				this.Cursor = Cursors.Arrow;
			}
			base.Invalidate();
		}

		// Token: 0x060013CE RID: 5070 RVA: 0x0000C9CF File Offset: 0x0000C9CF
		public bool IsAreaDragEnabled()
		{
			return this.mb_DragAreaEdit;
		}

		// Token: 0x060013CF RID: 5071 RVA: 0x00095A08 File Offset: 0x00095A08
		private void NormalizeRanges(Graph3D.eNormalize e_Normalize)
		{
			if (this.mb_LockNormalization)
			{
				this.mi_Transform.md_NormalizeX = this.md_LockNormX;
				this.mi_Transform.md_NormalizeY = this.md_LockNormY;
				this.mi_Transform.md_NormalizeZ = this.md_LockNormZ;
				this.mi_MinMax.mi_Center3D.md_X = this.md_LockCenterX;
				this.mi_MinMax.mi_Center3D.md_Y = this.md_LockCenterY;
				this.mi_MinMax.mi_Center3D.md_Z = this.md_LockCenterZ;
				return;
			}
			if (this.mi_MinMax.md_MaxX == this.mi_MinMax.md_MinX)
			{
				this.mi_MinMax.md_MinX -= 1.0;
				this.mi_MinMax.md_MaxX += 1.0;
			}
			if (this.mi_MinMax.md_MaxY == this.mi_MinMax.md_MinY)
			{
				this.mi_MinMax.md_MinY -= 1.0;
				this.mi_MinMax.md_MaxY += 1.0;
			}
			if (this.mi_MinMax.md_MaxZ == this.mi_MinMax.md_MinZ)
			{
				this.mi_MinMax.md_MinZ -= 1.0;
				this.mi_MinMax.md_MaxZ += 1.0;
			}
			double num = this.mi_MinMax.md_MaxX - this.mi_MinMax.md_MinX;
			double num2 = this.mi_MinMax.md_MaxY - this.mi_MinMax.md_MinY;
			double num3 = (this.me_Raster == Graph3D.eRaster.Off) ? (this.mi_MinMax.md_MaxZ - this.mi_MinMax.md_MinZ) : (Math.Max(0.0, this.mi_MinMax.md_MaxZ) - Math.Min(0.0, this.mi_MinMax.md_MinZ));
			if (e_Normalize == Graph3D.eNormalize.MaintainXY)
			{
				num = (num2 = (num + num2) / 2.0);
			}
			else if (e_Normalize == Graph3D.eNormalize.MaintainXYZ)
			{
				num = (num2 = (num3 = (num + num2 + num3) / 3.0));
			}
			if (this._autoRange && num3 > 0.0)
			{
				double num4 = num3 * 0.15;
				this.mi_Transform.md_NormalizeZ = 250.0 / (num3 + num4 * 2.0);
				this.mi_MinMax.mi_Center3D.md_Z = (this.mi_MinMax.md_MaxZ + this.mi_MinMax.md_MinZ) / 2.0;
			}
			else
			{
				this.mi_Transform.md_NormalizeZ = 250.0 / num3;
				this.mi_MinMax.mi_Center3D.md_Z = ((this.me_Raster == Graph3D.eRaster.Off) ? ((this.mi_MinMax.md_MaxZ + this.mi_MinMax.md_MinZ) / 2.0) : ((Math.Max(0.0, this.mi_MinMax.md_MaxZ) + Math.Min(0.0, this.mi_MinMax.md_MinZ)) / 2.0));
			}
			this.mi_Transform.md_NormalizeX = 250.0 / num;
			this.mi_Transform.md_NormalizeY = 250.0 / num2;
			this.mi_MinMax.mi_Center3D.md_X = (this.mi_MinMax.md_MaxX + this.mi_MinMax.md_MinX) / 2.0;
			this.mi_MinMax.mi_Center3D.md_Y = (this.mi_MinMax.md_MaxY + this.mi_MinMax.md_MinY) / 2.0;
		}

		// Token: 0x060013D0 RID: 5072 RVA: 0x0000C9D7 File Offset: 0x0000C9D7
		private void BuildGeometry()
		{
			this.mi_DrawObjects.Clear();
			this.CreateCoordinateSystem();
			if (this.mi_PolyArr != null)
			{
				this.CreatePolygons();
			}
			if (this.mi_ScatterArr != null)
			{
				this.CreateScatterDots();
			}
		}

		// Token: 0x060013D1 RID: 5073 RVA: 0x00095DC8 File Offset: 0x00095DC8
		private void CreatePolygons()
		{
			if (this.mi_PolyArr == null)
			{
				return;
			}
			int length = this.mi_PolyArr.GetLength(0);
			int length2 = this.mi_PolyArr.GetLength(1);
			this.mi_ProjectedPoints = new Graph3D.cPoint2D[length, length2];
			Graph3D.cPoint2D[,] array = new Graph3D.cPoint2D[length, length2];
			checked
			{
				for (int i = 0; i < length; i++)
				{
					for (int j = 0; j < length2; j++)
					{
						array[i, j] = this.mi_Transform.ProjectSurface(this.mi_PolyArr[i, j], this.mi_MinMax.mi_Center3D);
						this.mi_ProjectedPoints[i, j] = array[i, j];
					}
				}
				for (int k = 0; k < length - 1; k++)
				{
					for (int l = 0; l < length2 - 1; l++)
					{
						Graph3D.cPolygon cPolygon = new Graph3D.cPolygon(new Graph3D.cPoint2D[]
						{
							array[k, l],
							array[k, l + 1],
							array[k + 1, l + 1],
							array[k + 1, l]
						});
						unchecked
						{
							double num = (this.mi_PolyArr[k, l].md_Z + this.mi_PolyArr[k, checked(l + 1)].md_Z + checked(this.mi_PolyArr[k + 1, l + 1]).md_Z + this.mi_PolyArr[checked(k + 1), l].md_Z) / 4.0;
							double num2 = this.mi_MinMax.md_MaxZ - this.mi_MinMax.md_MinZ;
							cPolygon.md_FactorZ = ((num2 > 0.0) ? ((num - this.mi_MinMax.md_MinZ) / num2) : 0.0);
							this.AddDrawObject(new Graph3D.cDrawObj(cPolygon, this.mi_Transform.ProjectXYSurface((double)k + 1.0, (double)l + 1.0)));
						}
					}
				}
			}
		}

		// Token: 0x060013D2 RID: 5074 RVA: 0x00095FC8 File Offset: 0x00095FC8
		private void CreateScatterDots()
		{
			foreach (Graph3D.cScatter cScatter in this.mi_ScatterArr)
			{
				cScatter.SetPoint2D(this.mi_Transform.ProjectSurface(cScatter.mi_Point3D, this.mi_MinMax.mi_Center3D));
				if (cScatter.mi_Brush == null)
				{
					double num = this.mi_MinMax.md_MaxZ - this.mi_MinMax.md_MinZ;
					cScatter.md_FactorZ = ((num > 0.0) ? ((cScatter.mi_Point3D.md_Z - this.mi_MinMax.md_MinZ) / num) : 0.0);
				}
				this.AddDrawObject(new Graph3D.cDrawObj(cScatter, this.mi_Transform.ProjectXYSurface(cScatter.mi_Point3D.md_X + 1.0, cScatter.mi_Point3D.md_Y + 1.0)));
			}
		}

		// Token: 0x060013D3 RID: 5075 RVA: 0x000960B0 File Offset: 0x000960B0
		private void AddDrawObject(Graph3D.cDrawObj obj)
		{
			int num = 0;
			checked
			{
				while (num < this.mi_DrawObjects.Count && this.mi_DrawObjects[num].md_Sort <= obj.md_Sort)
				{
					num++;
				}
				this.mi_DrawObjects.Insert(num, obj);
			}
		}

		// Token: 0x060013D4 RID: 5076 RVA: 0x000960FC File Offset: 0x000960FC
		private void CreateCoordinateSystem()
		{
			this.mk_Offset2D = new Point(0, -30);
			if (this.me_Raster == Graph3D.eRaster.Off || this.mi_MinMax == null)
			{
				return;
			}
			if (this.mi_Quadrant != null && this.mi_DrawObjects.Count > 0)
			{
				return;
			}
			List<Graph3D.cLine> list = new List<Graph3D.cLine>();
			checked
			{
				for (int i = 0; i < 3; i++)
				{
					Graph3D.cLine cLine = new Graph3D.cLine();
					cLine.mi_Pen = this.mi_AxisPens[i];
					unchecked
					{
						switch (i)
						{
						case 0:
							cLine.mi_Points3D[0].md_X = Math.Min(0.0, this.mi_MinMax.md_MinX * 1.1);
							cLine.mi_Points3D[1].md_X = Math.Max(0.0, this.mi_MinMax.md_MaxX * 1.1);
							cLine.mi_Points3D[0].md_Y = Math.Min(0.0, this.mi_MinMax.md_MinY * 1.1);
							cLine.mi_Points3D[1].md_Y = Math.Min(0.0, this.mi_MinMax.md_MinY * 1.1);
							cLine.me_Line = Graph3D.eCoord.X;
							cLine.me_Offset = Graph3D.eCoord.X;
							break;
						case 1:
							cLine.mi_Points3D[0].md_Y = Math.Min(0.0, this.mi_MinMax.md_MinY * 1.1);
							cLine.mi_Points3D[1].md_Y = Math.Max(0.0, this.mi_MinMax.md_MaxY * 1.1);
							cLine.mi_Points3D[0].md_X = Math.Min(0.0, this.mi_MinMax.md_MinX * 1.1);
							cLine.mi_Points3D[1].md_X = Math.Min(0.0, this.mi_MinMax.md_MinX * 1.1);
							cLine.me_Line = Graph3D.eCoord.Y;
							cLine.me_Offset = Graph3D.eCoord.Z;
							break;
						case 2:
							cLine.mi_Points3D[0].md_Z = Math.Min(0.0, this.mi_MinMax.md_MinZ * 1.1);
							cLine.mi_Points3D[1].md_Z = Math.Max(0.0, this.mi_MinMax.md_MaxZ * 1.1);
							cLine.mi_Points3D[0].md_X = Math.Min(0.0, this.mi_MinMax.md_MinX * 1.1);
							cLine.mi_Points3D[1].md_X = Math.Min(0.0, this.mi_MinMax.md_MinX * 1.1);
							cLine.mi_Points3D[0].md_Y = Math.Min(0.0, this.mi_MinMax.md_MinY * 1.1);
							cLine.mi_Points3D[1].md_Y = Math.Min(0.0, this.mi_MinMax.md_MinY * 1.1);
							cLine.me_Line = Graph3D.eCoord.Z;
							cLine.me_Offset = Graph3D.eCoord.Z;
							break;
						}
						cLine.mi_Points2D[0] = this.mi_Transform.Project(cLine.mi_Points3D[0], this.mi_MinMax.mi_Center3D);
						cLine.mi_Points2D[1] = this.mi_Transform.Project(cLine.mi_Points3D[1], this.mi_MinMax.mi_Center3D);
						cLine.CalcAngle2D();
						list.Add(cLine);
					}
				}
				this.mi_Quadrant = new Graph3D.cQuadrant(this.mi_Mouse.md_Phi, list[0], list[1], list[2]);
				if (this.me_Raster >= Graph3D.eRaster.Raster)
				{
					for (int j = 0; j < 3; j++)
					{
						Graph3D.eCoord eCoord = (Graph3D.eCoord)j;
						Graph3D.eCoord eCoord2 = (eCoord + 1) % (Graph3D.eCoord)3;
						for (int k = 0; k < 2; k++)
						{
							Graph3D.cLine cLine2 = list[(int)eCoord];
							Graph3D.cLine cLine3 = list[(int)eCoord2];
							double value = cLine3.mi_Points3D[0].GetValue(eCoord2);
							double value2 = cLine3.mi_Points3D[1].GetValue(eCoord2);
							double num = this.CalculateInterval(unchecked(value2 - value));
							for (int l = -11; l < 11; l++)
							{
								double num2 = unchecked(num * (double)l);
								if (num2 >= value && num2 <= value2)
								{
									Graph3D.cLine cLine4 = new Graph3D.cLine();
									cLine4.mi_Pen = this.mi_RasterPens[(int)eCoord2];
									cLine4.me_Line = eCoord;
									cLine4.me_Offset = eCoord2;
									cLine4.md_Label = num2;
									cLine4.mi_Points3D[0] = cLine2.mi_Points3D[0].Clone();
									cLine4.mi_Points3D[1] = cLine2.mi_Points3D[1].Clone();
									cLine4.mi_Points3D[0].SetValue(eCoord2, num2);
									cLine4.mi_Points3D[1].SetValue(eCoord2, num2);
									if (!cLine4.CoordEquals(list[0]) && !cLine4.CoordEquals(list[1]) && !cLine4.CoordEquals(list[2]))
									{
										if ((eCoord == Graph3D.eCoord.X && eCoord2 == Graph3D.eCoord.Z) || (eCoord == Graph3D.eCoord.Z && eCoord2 == Graph3D.eCoord.X))
										{
											cLine4.md_Sort = this.mi_Quadrant.md_SortXZ;
										}
										else if ((eCoord == Graph3D.eCoord.Z && eCoord2 == Graph3D.eCoord.Y) || (eCoord == Graph3D.eCoord.Y && eCoord2 == Graph3D.eCoord.Z))
										{
											cLine4.md_Sort = this.mi_Quadrant.md_SortYZ;
										}
										else
										{
											cLine4.md_Sort = this.mi_Quadrant.md_SortXY;
											cLine4.mi_Points3D[0].md_Z = list[2].mi_Points3D[0].md_Z;
											cLine4.mi_Points3D[1].md_Z = list[2].mi_Points3D[0].md_Z;
										}
										list.Add(cLine4);
									}
								}
							}
							eCoord = eCoord2;
							eCoord2 = (eCoord + 1) % (Graph3D.eCoord)3;
						}
					}
				}
				foreach (Graph3D.cLine cLine5 in list)
				{
					cLine5.mi_Points2D[0] = this.mi_Transform.Project(cLine5.mi_Points3D[0], this.mi_MinMax.mi_Center3D);
					cLine5.mi_Points2D[1] = this.mi_Transform.Project(cLine5.mi_Points3D[1], this.mi_MinMax.mi_Center3D);
					this.AddDrawObject(new Graph3D.cDrawObj(cLine5, cLine5.md_Sort));
				}
			}
		}

		// Token: 0x060013D5 RID: 5077 RVA: 0x000026F4 File Offset: 0x000026F4
		protected override void OnPaintBackground(PaintEventArgs e)
		{
		}

		// Token: 0x060013D6 RID: 5078 RVA: 0x000967A0 File Offset: 0x000967A0
		protected override void OnPaint(PaintEventArgs e)
		{
			if (base.ClientSize.Width <= 0 || base.ClientSize.Height <= 0)
			{
				return;
			}
			try
			{
				Graphics graphics = e.Graphics;
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				graphics.CompositingQuality = CompositingQuality.HighSpeed;
				graphics.InterpolationMode = InterpolationMode.NearestNeighbor;
				this.Draw(graphics);
			}
			catch
			{
			}
		}

		// Token: 0x060013D7 RID: 5079 RVA: 0x0009680C File Offset: 0x0009680C
		public Bitmap GetScreenshot()
		{
			Bitmap bitmap = new Bitmap(base.ClientSize.Width, base.ClientSize.Height);
			using (Graphics graphics = Graphics.FromImage(bitmap))
			{
				this.Draw(graphics);
			}
			return bitmap;
		}

		// Token: 0x060013D8 RID: 5080 RVA: 0x00096868 File Offset: 0x00096868
		private void Draw(Graphics g)
		{
			if (this.mi_DrawObjects == null || this.mi_DrawObjects.Count == 0 || this.mi_ProjectedPoints == null)
			{
				try
				{
					this.BuildGeometry();
					if (this.mi_DrawObjects.Count == 0)
					{
						return;
					}
				}
				catch
				{
					return;
				}
			}
			if (this.mi_PolyArr != null && this.mi_ProjectedPoints != null && (this.mi_ProjectedPoints.GetLength(0) != this.mi_PolyArr.GetLength(0) || this.mi_ProjectedPoints.GetLength(1) != this.mi_PolyArr.GetLength(1)))
			{
				try
				{
					this.BuildGeometry();
				}
				catch
				{
					return;
				}
			}
			g.Clear(this.BackColor);
			this.DrawLegends(g);
			this.DrawTopLegend(g);
			GraphicsState gstate = g.Save();
			g.ScaleTransform(-1f, 1f);
			g.TranslateTransform(-(float)base.ClientSize.Width, 0f);
			checked
			{
				g.TranslateTransform((float)(this.mi_Mouse.mk_Offset.X + this.mk_Offset2D.X), (float)(this.mi_Mouse.mk_Offset.Y + this.mk_Offset2D.Y));
				this.DrawObjects(g);
				this.DrawCompareBins(g);
				g.Restore(gstate);
				this.DrawSelectionMarkers(g);
				this.DrawSelectionRect(g);
				this.DrawAllPoints(g);
				this.DrawSelectedPointers(g);
				this.DrawLiveECUPointer(g);
			}
		}

		// Token: 0x060013D9 RID: 5081 RVA: 0x000969E8 File Offset: 0x000969E8
		private void DrawObjects(Graphics g)
		{
			foreach (Graph3D.cDrawObj cDrawObj in this.mi_DrawObjects)
			{
				if (cDrawObj.IsValid)
				{
					bool isHovered = cDrawObj == this.hoveredObj;
					if (cDrawObj.mi_Polygon != null)
					{
						this.DrawPolygon(g, cDrawObj, isHovered);
					}
					else if (cDrawObj.mi_Scatter != null)
					{
						this.DrawScatter(g, cDrawObj, isHovered);
					}
					else if (cDrawObj.mi_Line != null)
					{
						g.DrawLine(cDrawObj.mi_Line.mi_Pen, cDrawObj.mi_Line.mi_Points2D[0].Coord, cDrawObj.mi_Line.mi_Points2D[1].Coord);
					}
				}
			}
		}

		// Token: 0x060013DA RID: 5082 RVA: 0x00096AAC File Offset: 0x00096AAC
		private void DrawPolygon(Graphics g, Graph3D.cDrawObj obj, bool isHovered)
		{
			Brush brush = isHovered ? Brushes.LightGray : this.GetSchemeBrush(obj.mi_Polygon.md_FactorZ);
			if (this._showWireframe)
			{
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(30, ((SolidBrush)brush).Color)))
				{
					g.FillPolygon(solidBrush, obj.mi_Polygon.mk_Points);
				}
				if (this.mi_PolyLinePen != null)
				{
					g.DrawPolygon(isHovered ? Pens.Red : this.mi_PolyLinePen, obj.mi_Polygon.mk_Points);
					return;
				}
			}
			else
			{
				g.FillPolygon(brush, obj.mi_Polygon.mk_Points);
				if (this.mi_PolyLinePen != null)
				{
					g.DrawPolygon(isHovered ? Pens.Red : this.mi_PolyLinePen, obj.mi_Polygon.mk_Points);
				}
			}
		}

		// Token: 0x060013DB RID: 5083 RVA: 0x00096B88 File Offset: 0x00096B88
		private void DrawScatter(Graphics g, Graph3D.cDrawObj obj, bool isHovered)
		{
			Graph3D.cScatter mi_Scatter = obj.mi_Scatter;
			if (mi_Scatter.mb_Combine && mi_Scatter.mi_Previous != null)
			{
				Pen pen = mi_Scatter.mi_Pen ?? this.GetSchemePen(mi_Scatter.md_FactorZ);
				g.DrawLine(isHovered ? Pens.Red : pen, mi_Scatter.mi_Previous.mk_Point, mi_Scatter.mk_Point);
				return;
			}
			Brush brush = mi_Scatter.mi_Brush ?? this.GetSchemeBrush(mi_Scatter.md_FactorZ);
			g.FillEllipse(isHovered ? Brushes.White : brush, mi_Scatter.mk_Point.X, mi_Scatter.mk_Point.Y, 3f, 3f);
		}

		// Token: 0x060013DC RID: 5084 RVA: 0x00096C30 File Offset: 0x00096C30
		private void DrawCompareBins(Graphics g)
		{
			if (!this._showCompareBins || this._compareBinData == null || this.mi_PolyArr == null)
			{
				return;
			}
			int num = Math.Min(this.mi_PolyArr.GetLength(0), this._compareBinData.GetLength(0));
			int num2 = Math.Min(this.mi_PolyArr.GetLength(1), this._compareBinData.GetLength(1));
			checked
			{
				using (Pen pen = new Pen(Color.Magenta, 1.5f)
				{
					DashStyle = DashStyle.Dot
				})
				{
					for (int i = 0; i < num - 1; i++)
					{
						for (int j = 0; j < num2 - 1; j++)
						{
							Graph3D.cPoint2D cPoint2D = this.mi_ProjectedPoints[i, j];
							Graph3D.cPoint2D cPoint2D2 = this.mi_ProjectedPoints[i, j + 1];
							Graph3D.cPoint2D cPoint2D3 = this.mi_ProjectedPoints[i + 1, j + 1];
							Graph3D.cPoint2D cPoint2D4 = this.mi_ProjectedPoints[i + 1, j];
							if (cPoint2D.IsValid && cPoint2D2.IsValid && cPoint2D3.IsValid && cPoint2D4.IsValid)
							{
								g.DrawPolygon(pen, new PointF[]
								{
									cPoint2D.Coord,
									cPoint2D2.Coord,
									cPoint2D3.Coord,
									cPoint2D4.Coord
								});
							}
						}
					}
				}
			}
		}

		// Token: 0x060013DD RID: 5085 RVA: 0x00096DA4 File Offset: 0x00096DA4
		private void DrawLegends(Graphics g)
		{
			checked
			{
				int num = base.ClientSize.Height - this.Font.Height - 4;
				int num2 = 4;
				for (int i = 2; i >= 0; i--)
				{
					if (!string.IsNullOrEmpty(this.ms_AxisLegends[i]))
					{
						g.DrawString(string.Format("{0}: {1}", (Graph3D.eCoord)i, this.ms_AxisLegends[i]), this.Font, this.mi_AxisBrushes[i], (float)num2, (float)num);
						num -= this.Font.Height;
					}
				}
			}
		}

		// Token: 0x060013DE RID: 5086 RVA: 0x00096E2C File Offset: 0x00096E2C
		private void DrawTopLegend(Graphics g)
		{
			if (this.mi_TopLegendBrush == null)
			{
				return;
			}
			string[] array = new string[]
			{
				"Rotation:",
				"Elevation:",
				"Distance:"
			};
			string[] array2 = new string[]
			{
				string.Format("{0:+0;-#;0}°", this.mi_Mouse.md_Phi),
				string.Format("{0:+0;-#;0}°", this.mi_Mouse.md_Theta),
				string.Format("{0:0}", this.mi_Mouse.md_Rho)
			};
			SizeF sizeF = g.MeasureString(array[1], this.Font);
			int num = 4;
			int num2 = 3;
			checked
			{
				for (int i = 0; i < 3; i++)
				{
					g.DrawString(array[i], this.Font, this.mi_TopLegendBrush, (float)num, (float)num2);
					g.DrawString(array2[i], this.Font, this.mi_TopLegendBrush, unchecked((float)num + sizeF.Width), (float)num2);
					num2 += this.Font.Height;
				}
			}
		}

		// Token: 0x060013DF RID: 5087 RVA: 0x00096F34 File Offset: 0x00096F34
		private void DrawSelectionMarkers(Graphics g)
		{
			if (this.mb_LiveMode || this.mi_ProjectedPoints == null)
			{
				return;
			}
			HashSet<Point> selectedPointsSet = this._selectedPointsSet;
			if (selectedPointsSet == null || selectedPointsSet.Count == 0)
			{
				return;
			}
			int length = this.mi_ProjectedPoints.GetLength(0);
			int length2 = this.mi_ProjectedPoints.GetLength(1);
			using (SolidBrush solidBrush = new SolidBrush(Color.Lime))
			{
				using (Pen pen = new Pen(Color.Green, 1f))
				{
					foreach (Point point in selectedPointsSet)
					{
						int x = point.X;
						int y = point.Y;
						if (x >= 0 && x < length && y >= 0 && y < length2)
						{
							Graph3D.cPoint2D cPoint2D = this.mi_ProjectedPoints[x, y];
							if (cPoint2D != null && cPoint2D.IsValid)
							{
								float num = (float)cPoint2D.md_X + (float)this.mi_Mouse.mk_Offset.X + (float)this.mk_Offset2D.X;
								float num2 = (float)cPoint2D.md_Y + (float)this.mi_Mouse.mk_Offset.Y + (float)this.mk_Offset2D.Y;
								float num3 = (float)base.ClientSize.Width - num;
								float num4 = num2;
								RectangleF rect = new RectangleF(num3 - 3f, num4 - 3f, 6f, 6f);
								g.FillEllipse(solidBrush, rect);
								g.DrawEllipse(pen, rect);
							}
						}
					}
				}
			}
		}

		// Token: 0x060013E0 RID: 5088 RVA: 0x00097120 File Offset: 0x00097120
		private void DrawSelectionRect(Graphics g)
		{
			if (!this.mb_SelectingArea || this.mk_SelectionRect.Width <= 0 || this.mk_SelectionRect.Height <= 0)
			{
				return;
			}
			g.FillRectangle(this.mi_SelectionFill, this.mk_SelectionRect);
			g.DrawRectangle(this.mi_SelectionPen, this.mk_SelectionRect);
		}

		// Token: 0x060013E1 RID: 5089 RVA: 0x00097178 File Offset: 0x00097178
		private void GenerateAllPoints()
		{
			this._allPoints.Clear();
			if (this.mi_PolyArr == null)
			{
				return;
			}
			int length = this.mi_PolyArr.GetLength(0);
			int length2 = this.mi_PolyArr.GetLength(1);
			checked
			{
				for (int i = 0; i < length; i++)
				{
					for (int j = 0; j < length2; j++)
					{
						this._allPoints.Add(new Point(i, j));
					}
				}
			}
		}

		// Token: 0x060013E2 RID: 5090 RVA: 0x000971E0 File Offset: 0x000971E0
		private void DrawAllPoints(Graphics g)
		{
			if (!this._showPoints || this._allPoints.Count == 0 || this.mi_ProjectedPoints == null)
			{
				return;
			}
			int length = this.mi_ProjectedPoints.GetLength(0);
			int length2 = this.mi_ProjectedPoints.GetLength(1);
			HashSet<Point> selectedPointsSet = this._selectedPointsSet;
			using (SolidBrush solidBrush = new SolidBrush(Color.White))
			{
				using (Pen pen = new Pen(Color.Cyan, 1.5f))
				{
					foreach (Point item in this._allPoints)
					{
						int x = item.X;
						int y = item.Y;
						if (x >= 0 && x < length && y >= 0 && y < length2 && (selectedPointsSet == null || !selectedPointsSet.Contains(item)))
						{
							Graph3D.cPoint2D cPoint2D = this.mi_ProjectedPoints[x, y];
							if (cPoint2D != null && cPoint2D.IsValid)
							{
								float num = (float)cPoint2D.md_X + (float)this.mi_Mouse.mk_Offset.X + (float)this.mk_Offset2D.X;
								float num2 = (float)cPoint2D.md_Y + (float)this.mi_Mouse.mk_Offset.Y + (float)this.mk_Offset2D.Y;
								float num3 = (float)base.ClientSize.Width - num;
								float num4 = num2;
								g.FillEllipse(solidBrush, num3 - 2f, num4 - 2f, 4f, 4f);
								g.DrawEllipse(pen, num3 - 2f, num4 - 2f, 4f, 4f);
							}
						}
					}
				}
			}
		}

		// Token: 0x060013E3 RID: 5091 RVA: 0x000973F4 File Offset: 0x000973F4
		private void DrawSelectedPointers(Graphics g)
		{
			if (!this._showClickedPoints || this.mi_ProjectedPoints == null || this._clickedPoints.Count == 0)
			{
				return;
			}
			float num;
			float num2;
			checked
			{
				num = (float)(this.mi_Mouse.mk_Offset.X + this.mk_Offset2D.X);
				num2 = (float)(this.mi_Mouse.mk_Offset.Y + this.mk_Offset2D.Y);
			}
			using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(80, 0, 255, 0)))
			{
				using (SolidBrush solidBrush2 = new SolidBrush(Color.FromArgb(200, 0, 255, 0)))
				{
					using (Pen pen = new Pen(Color.Lime, 2.5f))
					{
						using (Pen pen2 = new Pen(Color.White, 2f))
						{
							using (Font font = new Font("Segoe UI", 8f, FontStyle.Bold))
							{
								using (SolidBrush solidBrush3 = new SolidBrush(Color.Lime))
								{
									using (SolidBrush solidBrush4 = new SolidBrush(Color.FromArgb(180, Color.Black)))
									{
										foreach (Point point in this._clickedPoints)
										{
											int x = point.X;
											int y = point.Y;
											int num3 = y;
											int num4 = x;
											if (num3 >= 0 && num3 < this.mi_ProjectedPoints.GetLength(0) && num4 >= 0 && num4 < this.mi_ProjectedPoints.GetLength(1))
											{
												Graph3D.cPoint2D cPoint2D = this.mi_ProjectedPoints[num3, num4];
												if (cPoint2D != null && cPoint2D.IsValid)
												{
													float num5 = (float)cPoint2D.md_X + num;
													float num6 = (float)cPoint2D.md_Y + num2;
													g.FillEllipse(solidBrush, num5 - 15f, num6 - 15f, 30f, 30f);
													RectangleF rect = new RectangleF(num5 - 5f, num6 - 5f, 10f, 10f);
													g.FillEllipse(solidBrush2, rect);
													g.DrawEllipse(pen, rect);
													g.DrawLine(pen2, num5 - 3.33f, num6, num5 + 3.33f, num6);
													g.DrawLine(pen2, num5, num6 - 3.33f, num5, num6 + 3.33f);
													if (this.mi_PolyArr != null && x < this.mi_PolyArr.GetLength(0) && y < this.mi_PolyArr.GetLength(1))
													{
														double md_Z = this.mi_PolyArr[x, y].md_Z;
														string text = string.Format("({0},{1}) {2:F2}", x, y, md_Z);
														SizeF sizeF = g.MeasureString(text, font);
														float num7 = num5 - sizeF.Width / 2f;
														float num8 = num6 - 10f - sizeF.Height - 6f;
														g.FillRectangle(solidBrush4, new RectangleF(num7 - 4f, num8 - 2f, sizeF.Width + 8f, sizeF.Height + 4f));
														g.DrawString(text, font, solidBrush3, num7, num8);
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x060013E4 RID: 5092 RVA: 0x00097828 File Offset: 0x00097828
		private Brush GetSchemeBrush(double factorZ)
		{
			if (this.mi_SchemeBrushes == null || double.IsNaN(factorZ))
			{
				return Brushes.Goldenrod;
			}
			factorZ = Math.Max(0.0, Math.Min(1.0, factorZ));
			int num = checked((int)(unchecked(factorZ * (double)(checked(this.mi_SchemeBrushes.Length - 1)))));
			return this.mi_SchemeBrushes[num];
		}

		// Token: 0x060013E5 RID: 5093 RVA: 0x00097884 File Offset: 0x00097884
		private Pen GetSchemePen(double factorZ)
		{
			if (this.mi_SchemePens == null || double.IsNaN(factorZ))
			{
				return Pens.Goldenrod;
			}
			factorZ = Math.Max(0.0, Math.Min(1.0, factorZ));
			int num = checked((int)(unchecked(factorZ * (double)(checked(this.mi_SchemePens.Length - 1)))));
			return this.mi_SchemePens[num];
		}

		// Token: 0x060013E6 RID: 5094 RVA: 0x0000CA06 File Offset: 0x0000CA06
		private void SetAxisColor(Graph3D.eCoord coord, Color color)
		{
			this.mi_AxisBrushes[(int)coord] = new SolidBrush(color);
			this.mi_AxisPens[(int)coord] = new Pen(color, 3f);
			this.mi_RasterPens[(int)coord] = new Pen(this.BrightenColor(color), 1f);
		}

		// Token: 0x060013E7 RID: 5095 RVA: 0x000978E0 File Offset: 0x000978E0
		private Color BrightenColor(Color c)
		{
			return checked(Color.FromArgb(255, (int)(c.R + (byte.MaxValue - c.R) / 2), (int)(c.G + (byte.MaxValue - c.G) / 2), (int)(c.B + (byte.MaxValue - c.B) / 2)));
		}

		// Token: 0x060013E8 RID: 5096 RVA: 0x0009793C File Offset: 0x0009793C
		private void SafeInvalidate()
		{
			if (!base.IsHandleCreated || base.IsDisposed || base.Disposing)
			{
				return;
			}
			if (base.InvokeRequired)
			{
				try
				{
					base.BeginInvoke(new MethodInvoker(delegate()
					{
						if (!base.IsDisposed && !base.Disposing && base.IsHandleCreated)
						{
							base.Invalidate();
						}
					}));
				}
				catch
				{
				}
				return;
			}
			base.Invalidate();
		}

		// Token: 0x060013E9 RID: 5097 RVA: 0x0009799C File Offset: 0x0009799C
		private void InitLiveOverlay()
		{
			if (this.mi_PolyArr == null)
			{
				this._liveOverlayZ = null;
				return;
			}
			int length = this.mi_PolyArr.GetLength(0);
			int length2 = this.mi_PolyArr.GetLength(1);
			this._liveOverlayZ = new double[length, length2];
			checked
			{
				for (int i = 0; i < length; i++)
				{
					for (int j = 0; j < length2; j++)
					{
						this._liveOverlayZ[i, j] = this.mi_PolyArr[i, j].md_Z;
					}
				}
			}
		}

		// Token: 0x060013EA RID: 5098 RVA: 0x00097A18 File Offset: 0x00097A18
		private void SyncOverlayFromArray()
		{
			if (this.mi_PolyArr == null || this._liveOverlayZ == null)
			{
				return;
			}
			int num = Math.Min(this.mi_PolyArr.GetLength(0), this._liveOverlayZ.GetLength(0));
			int num2 = Math.Min(this.mi_PolyArr.GetLength(1), this._liveOverlayZ.GetLength(1));
			checked
			{
				for (int i = 0; i < num; i++)
				{
					for (int j = 0; j < num2; j++)
					{
						this._liveOverlayZ[i, j] = this.mi_PolyArr[i, j].md_Z;
					}
				}
			}
		}

		// Token: 0x060013EB RID: 5099 RVA: 0x00097AAC File Offset: 0x00097AAC
		private double GetLiveZ(int x, int y)
		{
			if (this._liveOverlayZ != null && x >= 0 && x < this._liveOverlayZ.GetLength(0) && y >= 0 && y < this._liveOverlayZ.GetLength(1))
			{
				return this._liveOverlayZ[x, y];
			}
			if (this.mi_PolyArr != null && x >= 0 && x < this.mi_PolyArr.GetLength(0) && y >= 0 && y < this.mi_PolyArr.GetLength(1))
			{
				return this.mi_PolyArr[x, y].md_Z;
			}
			return 0.0;
		}

		// Token: 0x060013EC RID: 5100 RVA: 0x0000CA42 File Offset: 0x0000CA42
		private void SetLiveZ(int x, int y, double value)
		{
			if (this._liveOverlayZ != null && x >= 0 && x < this._liveOverlayZ.GetLength(0) && y >= 0 && y < this._liveOverlayZ.GetLength(1))
			{
				this._liveOverlayZ[x, y] = value;
			}
		}

		// Token: 0x060013ED RID: 5101 RVA: 0x00097B40 File Offset: 0x00097B40
		private void UpdateSurfaceValue(int x, int y, double value)
		{
			if (this.mi_PolyArr == null || x < 0 || x >= this.mi_PolyArr.GetLength(0) || y < 0 || y >= this.mi_PolyArr.GetLength(1))
			{
				return;
			}
			if (double.IsNaN(value) || double.IsInfinity(value))
			{
				value = 0.0;
			}
			double md_Z = this.mi_PolyArr[x, y].md_Z;
			if (Math.Abs(md_Z - value) < 0.0001)
			{
				this.SyncLivePointer(x, y, value, 0.0, 0.0, false);
				this.SafeInvalidate();
				return;
			}
			this.mi_PolyArr[x, y].md_Z = value;
			this.SetLiveZ(x, y, value);
			this.OnPointValueChanged(x, y, md_Z, value);
			this.SyncLivePointer(x, y, value, 0.0, 0.0, false);
			this.SafeInvalidate();
		}

		// Token: 0x060013EE RID: 5102 RVA: 0x00097C28 File Offset: 0x00097C28
		private void SyncLivePointer(int x, int y, double z, double rpm, double tps, bool hasRpmTps)
		{
			object livePointerLock = this._livePointerLock;
			lock (livePointerLock)
			{
				this._livePointerX = x;
				this._livePointerY = y;
				this._livePointerZ = z;
				if (hasRpmTps)
				{
					this._livePointerRPM = rpm;
					this._livePointerTPS = tps;
				}
				this._livePointerVisible = true;
			}
			EventHandler<Graph3D.PointValueChangedEventArgs> livePointChanged = this.LivePointChanged;
			if (livePointChanged != null)
			{
				livePointChanged(this, new Graph3D.PointValueChangedEventArgs(x, y, z, z));
			}
		}

		// Token: 0x060013EF RID: 5103 RVA: 0x00097CAC File Offset: 0x00097CAC
		private void LockNormalization()
		{
			if (this.mi_MinMax == null)
			{
				return;
			}
			this.mb_LockNormalization = true;
			this.md_LockNormX = this.mi_Transform.md_NormalizeX;
			this.md_LockNormY = this.mi_Transform.md_NormalizeY;
			this.md_LockNormZ = this.mi_Transform.md_NormalizeZ;
			this.md_LockCenterX = this.mi_MinMax.mi_Center3D.md_X;
			this.md_LockCenterY = this.mi_MinMax.mi_Center3D.md_Y;
			this.md_LockCenterZ = this.mi_MinMax.mi_Center3D.md_Z;
		}

		// Token: 0x060013F0 RID: 5104 RVA: 0x00097D40 File Offset: 0x00097D40
		private void ApplyLiveUpdateFast(int x, int y, double rpm, double tps, double z, bool hasRpmTps)
		{
			if (base.IsDisposed || base.Disposing || this.mi_PolyArr == null)
			{
				return;
			}
			checked
			{
				int num = this.mi_PolyArr.GetLength(0) - 1;
				int num2 = this.mi_PolyArr.GetLength(1) - 1;
				if (num < 0 || num2 < 0)
				{
					return;
				}
				x = Math.Max(0, Math.Min(num, x));
				y = Math.Max(0, Math.Min(num2, y));
			}
			if (Math.Abs(this.GetLiveZ(x, y) - z) > 0.0001)
			{
				this.SetLiveZ(x, y, z);
			}
			this.SyncLivePointer(x, y, z, rpm, tps, hasRpmTps);
			this.SafeInvalidate();
		}

		// Token: 0x060013F1 RID: 5105 RVA: 0x00097DE8 File Offset: 0x00097DE8
		private void UpdateLiveRpmRange(double rpm)
		{
			try
			{
				if (!double.IsNaN(rpm) && !double.IsInfinity(rpm))
				{
					object liveRpmRangeLock = this._liveRpmRangeLock;
					lock (liveRpmRangeLock)
					{
						if (double.IsNaN(this._liveRpmMin) || double.IsNaN(this._liveRpmMax))
						{
							this._liveRpmMin = rpm;
							this._liveRpmMax = rpm;
						}
						else
						{
							if (rpm < this._liveRpmMin)
							{
								this._liveRpmMin = rpm;
							}
							if (rpm > this._liveRpmMax)
							{
								this._liveRpmMax = rpm;
							}
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060013F2 RID: 5106 RVA: 0x00097E90 File Offset: 0x00097E90
		private int MapRpmToLivePointerX(double rpm)
		{
			int result;
			try
			{
				if (this.mi_ProjectedPoints == null)
				{
					result = 0;
				}
				else
				{
					int num = checked(this.mi_ProjectedPoints.GetLength(0) - 1);
					if (num <= 0 || double.IsNaN(rpm) || double.IsInfinity(rpm))
					{
						result = 0;
					}
					else
					{
						object liveRpmRangeLock = this._liveRpmRangeLock;
						double liveRpmMin;
						double liveRpmMax;
						lock (liveRpmRangeLock)
						{
							liveRpmMin = this._liveRpmMin;
							liveRpmMax = this._liveRpmMax;
						}
						if (double.IsNaN(liveRpmMin) || double.IsNaN(liveRpmMax))
						{
							result = 0;
						}
						else if (Math.Abs(liveRpmMax - liveRpmMin) < 1E-06)
						{
							result = num / 2;
						}
						else
						{
							rpm = Math.Max(liveRpmMin, Math.Min(liveRpmMax, rpm));
							double num2 = Math.Max(0.0, Math.Min(1.0, (rpm - liveRpmMin) / (liveRpmMax - liveRpmMin)));
							result = Math.Max(0, Math.Min(num, checked((int)Math.Round(unchecked(num2 * (double)num)))));
						}
					}
				}
			}
			catch
			{
				result = 0;
			}
			return result;
		}

		// Token: 0x060013F3 RID: 5107 RVA: 0x00097FA4 File Offset: 0x00097FA4
		private int MapTpsToLivePointerY(double tps)
		{
			checked
			{
				int result;
				try
				{
					if (this.mi_ProjectedPoints == null)
					{
						result = 0;
					}
					else
					{
						int num = this.mi_ProjectedPoints.GetLength(1) - 1;
						if (num <= 0)
						{
							result = 0;
						}
						else
						{
							if (double.IsNaN(tps) || double.IsInfinity(tps))
							{
								tps = 0.0;
							}
							tps = Math.Max(0.0, Math.Min(100.0, tps));
							result = Math.Max(0, Math.Min(num, (int)Math.Round(unchecked(tps / 100.0 * (double)num))));
						}
					}
				}
				catch
				{
					result = 0;
				}
				return result;
			}
		}

		// Token: 0x060013F4 RID: 5108 RVA: 0x00098048 File Offset: 0x00098048
		private void DrawLiveECUPointer(Graphics g)
		{
			if (g == null || this.mi_ProjectedPoints == null || this.mi_PolyArr == null)
			{
				return;
			}
			object livePointerLock = this._livePointerLock;
			int livePointerX;
			int livePointerY;
			double livePointerZ;
			double livePointerRPM;
			double livePointerTPS;
			bool livePointerVisible;
			lock (livePointerLock)
			{
				livePointerX = this._livePointerX;
				livePointerY = this._livePointerY;
				livePointerZ = this._livePointerZ;
				livePointerRPM = this._livePointerRPM;
				livePointerTPS = this._livePointerTPS;
				livePointerVisible = this._livePointerVisible;
			}
			if (!livePointerVisible || livePointerX < 0 || livePointerY < 0)
			{
				return;
			}
			int length = this.mi_ProjectedPoints.GetLength(0);
			int length2 = this.mi_ProjectedPoints.GetLength(1);
			if (length == 0 || length2 == 0)
			{
				return;
			}
			Graph3D.cPoint2D cPoint2D;
			checked
			{
				int num = Math.Max(0, Math.Min(length - 1, livePointerX));
				int num2 = Math.Max(0, Math.Min(length2 - 1, livePointerY));
				try
				{
					cPoint2D = this.mi_ProjectedPoints[num, num2];
				}
				catch
				{
					return;
				}
				if (cPoint2D == null || !cPoint2D.IsValid)
				{
					return;
				}
			}
			float num3 = (float)cPoint2D.md_X + (float)this.mi_Mouse.mk_Offset.X + (float)this.mk_Offset2D.X;
			float num4 = (float)cPoint2D.md_Y + (float)this.mi_Mouse.mk_Offset.Y + (float)this.mk_Offset2D.Y;
			float num5 = (float)base.ClientSize.Width - num3;
			float num6 = num4;
			g.SmoothingMode = SmoothingMode.AntiAlias;
			g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
			float num7 = (float)this._livePointerSize / 2f;
			using (SolidBrush solidBrush = new SolidBrush(Color.White))
			{
				using (Pen pen = new Pen(Color.Black, 1.5f))
				{
					g.FillEllipse(solidBrush, num5 - num7, num6 - num7, num7 * 2f, num7 * 2f);
					g.DrawEllipse(pen, num5 - num7, num6 - num7, num7 * 2f, num7 * 2f);
				}
			}
			if (this._showLiveLabel)
			{
				this.DrawLiveLabel(g, num5, num6, livePointerZ, livePointerRPM, livePointerTPS, num7);
			}
		}

		// Token: 0x060013F5 RID: 5109 RVA: 0x00098280 File Offset: 0x00098280
		private void DrawLiveLabel(Graphics g, float px, float py, double z, double rpm, double tps, float halfSize)
		{
			if (g == null)
			{
				return;
			}
			FontFamily family;
			try
			{
				family = new FontFamily("ds-digital");
			}
			catch
			{
				family = new FontFamily("Segoe UI");
			}
			float num = Math.Max(13f, Math.Min(25f, (float)this._livePointerSize * 0.6f));
			float emSize = num * 0.7f;
			using (Font font = new Font(family, num, FontStyle.Bold))
			{
				using (Font font2 = new Font(family, emSize, FontStyle.Regular))
				{
					string text = string.Format("{0:F0}", z);
					string text2 = (rpm != 0.0 || tps != 0.0) ? string.Format("RPM: {0:F0} | TPS: {1:F1}", rpm, tps) : "MAP TUNING";
					SizeF sizeF = g.MeasureString(text, font);
					SizeF sizeF2 = g.MeasureString(text2, font2);
					float num2 = Math.Max(6f, (float)base.Width * 0.015f);
					float num3 = Math.Max(4f, (float)base.Height * 0.015f);
					float num4 = Math.Max(2f, num3 * 0.5f);
					float num5 = Math.Max(sizeF.Width, sizeF2.Width) + num2 * 2f;
					float num6 = sizeF.Height + sizeF2.Height + num4 + num3 * 2f;
					float num7 = halfSize + 8f;
					RectangleF clipBounds = g.ClipBounds;
					float num8 = px + num7;
					float num9 = py - num6 / 2f;
					if (num8 + num5 > clipBounds.Right - 2f)
					{
						num8 = px - num5 - num7;
					}
					if (num8 < clipBounds.Left + 2f)
					{
						num8 = px - num5 / 2f;
						num9 = py - num6 - num7 - 5f;
						if (num9 < clipBounds.Top + 2f)
						{
							num9 = py + num7 + 5f;
						}
					}
					if (num9 + num6 > clipBounds.Bottom - 2f)
					{
						num9 = py - num6 - num7 - 5f;
						if (num9 < clipBounds.Top + 2f)
						{
							num9 = clipBounds.Top + 2f;
						}
					}
					num8 = Math.Max(clipBounds.Left + 2f, Math.Min(clipBounds.Right - num5 - 2f, num8));
					num9 = Math.Max(clipBounds.Top + 2f, Math.Min(clipBounds.Bottom - num6 - 2f, num9));
					RectangleF rect = new RectangleF(num8, num9, num5, num6);
					using (Pen pen = new Pen(Color.FromArgb(100, 0, 122, 204), 1f)
					{
						DashStyle = DashStyle.Dot
					})
					{
						float num10 = rect.X + rect.Width / 2f;
						if (num10 > px)
						{
							g.DrawLine(pen, px + halfSize, py, rect.X, py);
						}
						else if (num10 < px)
						{
							g.DrawLine(pen, rect.Right, py, px - halfSize, py);
						}
						else if (num9 < py)
						{
							g.DrawLine(pen, px, py - halfSize, px, rect.Bottom);
						}
						else
						{
							g.DrawLine(pen, px, py + halfSize, px, rect.Y);
						}
						g.DrawLine(pen, px, py - halfSize - 3f, px, py + halfSize + 3f);
					}
					for (int i = Math.Max(2, Math.Min(6, this._livePointerSize / 8)); i >= 1; i = checked(i - 1))
					{
						float num11 = (float)i * Math.Max(1f, (float)this._livePointerSize / 40f);
						RectangleF rect2 = new RectangleF(rect.X + num11, rect.Y + num11, rect.Width, rect.Height);
						using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(80, Color.DimGray)))
						{
							using (GraphicsPath graphicsPath = Graph3D.CreateRoundedRect(rect2, Math.Min(8f, rect2.Width / 6f)))
							{
								g.FillPath(solidBrush, graphicsPath);
							}
						}
					}
					using (GraphicsPath graphicsPath2 = Graph3D.CreateRoundedRect(rect, Math.Min(10f, rect.Width / 6f)))
					{
						using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(rect, Color.FromArgb(230, 26, 44, 66), Color.FromArgb(230, 8, 16, 24), LinearGradientMode.Vertical))
						{
							g.FillPath(linearGradientBrush, graphicsPath2);
						}
					}
					float num12 = Math.Max(1f, Math.Min(2f, (float)this._livePointerSize / 25f));
					using (Pen pen2 = new Pen(Color.FromArgb(64, 153, 204, 255), num12))
					{
						using (GraphicsPath graphicsPath3 = Graph3D.CreateRoundedRect(new RectangleF(rect.X + 1f, rect.Y + 1f, rect.Width - 2f, rect.Height - 2f), Math.Min(9f, rect.Width / 6f)))
						{
							g.DrawPath(pen2, graphicsPath3);
						}
					}
					using (Pen pen3 = new Pen(Color.FromArgb(255, 0, 153, 204), num12 * 1.5f))
					{
						using (GraphicsPath graphicsPath4 = Graph3D.CreateRoundedRect(rect, Math.Min(10f, rect.Width / 6f)))
						{
							g.DrawPath(pen3, graphicsPath4);
						}
					}
					using (LinearGradientBrush linearGradientBrush2 = new LinearGradientBrush(new RectangleF(0f, 0f, sizeF.Width, sizeF.Height), Color.LightGreen, Color.Lime, LinearGradientMode.Horizontal))
					{
						g.DrawString(text, font, linearGradientBrush2, rect.X + (rect.Width - sizeF.Width) / 2f, rect.Y + num3);
					}
					using (SolidBrush solidBrush2 = new SolidBrush(Color.FromArgb(224, 200, 240, 255)))
					{
						g.DrawString(text2, font2, solidBrush2, rect.X + (rect.Width - sizeF2.Width) / 2f, rect.Y + num3 + sizeF.Height + num4);
					}
				}
			}
		}

		// Token: 0x060013F6 RID: 5110 RVA: 0x00098A70 File Offset: 0x00098A70
		private static GraphicsPath CreateRoundedRect(RectangleF rect, float radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			float num = radius * 2f;
			graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x060013F7 RID: 5111 RVA: 0x00098B18 File Offset: 0x00098B18
		protected override void OnMouseDown(MouseEventArgs e)
		{
			base.OnMouseDown(e);
			base.Focus();
			this.mk_LastMouseScreen = e.Location;
			if (this.mi_LiveMode || this.mb_LiveMode)
			{
				this.HandleLiveModeMouseDown(e);
				return;
			}
			if (this.mi_DrawObjects.Count == 0)
			{
				return;
			}
			Point point = checked(new Point(e.X - this.mi_Mouse.mk_Offset.X - this.mk_Offset2D.X, e.Y - this.mi_Mouse.mk_Offset.Y - this.mk_Offset2D.Y));
			this.mk_LastMouse = point;
			this.mi_Mouse.mk_LastPos = point;
			if (e.Button == MouseButtons.Right)
			{
				this.HandleRightMouseDown(point);
				return;
			}
			if (e.Button == MouseButtons.Left)
			{
				this.HandleLeftMouseDown(e, point);
				return;
			}
			if (e.Button == MouseButtons.Middle)
			{
				this.mi_Mouse.me_Action = Graph3D.eMouseAction.Move;
				this.Cursor = Cursors.SizeAll;
			}
		}

		// Token: 0x060013F8 RID: 5112 RVA: 0x00098C14 File Offset: 0x00098C14
		protected override void OnMouseMove(MouseEventArgs e)
		{
			base.OnMouseMove(e);
			if (this.mi_LiveMode || this.mb_LiveMode)
			{
				this.HandleLiveModeMouseMove(e);
				return;
			}
			checked
			{
				int num = e.X - this.mk_LastMouseScreen.X;
				int num2 = e.Y - this.mk_LastMouseScreen.Y;
				this.mk_LastMouseScreen = e.Location;
				Point point = new Point(e.X - this.mi_Mouse.mk_Offset.X - this.mk_Offset2D.X, e.Y - this.mi_Mouse.mk_Offset.Y - this.mk_Offset2D.Y);
				if (this.mb_SelectingArea)
				{
					this.HandleSelectionMove(e.Location);
					return;
				}
				if (this.mb_DragAreaEdit)
				{
					this.HandleAreaDrag(num2, point);
					return;
				}
				if (this.mb_DragPoint && this.mb_EditMode)
				{
					this.HandlePointDrag(num2, point);
					return;
				}
				if (this.mi_Mouse.me_Action == Graph3D.eMouseAction.Move)
				{
					Graph3D.cMouse cMouse = this.mi_Mouse;
					cMouse.mk_Offset.X = cMouse.mk_Offset.X + num;
					Graph3D.cMouse cMouse2 = this.mi_Mouse;
					cMouse2.mk_Offset.Y = cMouse2.mk_Offset.Y + num2;
					base.Invalidate();
				}
				else if (this.mi_Mouse.me_Action >= Graph3D.eMouseAction.Rho)
				{
					this.mi_Mouse.OnMouseMove(num, num2);
					this.mi_Transform.SetCoeficients(this.mi_Mouse);
					this.mi_DrawObjects.Clear();
					this.BuildGeometry();
					base.Invalidate();
				}
				else
				{
					this.UpdateHoverPoint(e.Location);
					this.CheckHover(e.Location);
				}
				this.mi_Mouse.mk_LastPos = point;
			}
		}

		// Token: 0x060013F9 RID: 5113 RVA: 0x00098DC0 File Offset: 0x00098DC0
		protected override void OnMouseUp(MouseEventArgs e)
		{
			base.OnMouseUp(e);
			if (this.mb_DragPoint || this.mb_DragAreaEdit)
			{
				try
				{
					this.mi_DrawObjects.Clear();
					this.BuildGeometry();
				}
				catch
				{
				}
			}
			checked
			{
				if (this.mb_SelectingArea)
				{
					this.UpdateSelectionFromRect();
					this.mb_SelectingArea = false;
					if (this.mi_SelectedPoints.Count > 0 && this.mi_PolyArr != null)
					{
						this.md_OriginalZValues = new double[this.mi_SelectedPoints.Count];
						for (int i = 0; i < this.mi_SelectedPoints.Count; i++)
						{
							Point point = this.mi_SelectedPoints[i];
							if (point.X >= 0 && point.X < this.mi_PolyArr.GetLength(0) && point.Y >= 0 && point.Y < this.mi_PolyArr.GetLength(1))
							{
								this.md_OriginalZValues[i] = this.mi_PolyArr[point.X, point.Y].md_Z;
							}
						}
						this.md_AccumulatedDrag = 0.0;
						this.mb_BlockEditActive = true;
					}
					base.Invalidate();
					this.SyncGridSelectionColorsFromGraph();
				}
				if (this.mb_DragAreaEdit || this.mb_DragPoint)
				{
					this.mb_DragAreaEdit = false;
					this.mb_DragPoint = false;
					if (this.mi_SelectedPoints.Count == 0)
					{
						this.mb_BlockEditActive = false;
						this.Cursor = Cursors.Arrow;
					}
					else
					{
						this.Cursor = Cursors.SizeNS;
					}
					this.md_OriginalZValues = null;
					this.md_AccumulatedDrag = 0.0;
					base.Invalidate();
				}
				this.mi_Mouse.me_Action = Graph3D.eMouseAction.None;
			}
		}

		// Token: 0x060013FA RID: 5114 RVA: 0x00098F74 File Offset: 0x00098F74
		protected override void OnMouseWheel(MouseEventArgs e)
		{
			base.OnMouseWheel(e);
			if (this._allowZoom)
			{
				this.mi_Mouse.OnMouseMove(0, e.Delta / 30);
				this.mi_Transform.SetCoeficients(this.mi_Mouse);
				this.mi_DrawObjects.Clear();
				this.BuildGeometry();
				this.SafeInvalidate();
			}
		}

		// Token: 0x060013FB RID: 5115 RVA: 0x00098FD0 File Offset: 0x00098FD0
		protected override void OnSizeChanged(EventArgs e)
		{
			base.OnSizeChanged(e);
			this.mi_Mouse.mk_Offset = Point.Empty;
			this.mi_Transform.SetSize(base.ClientSize);
			this.mi_DrawObjects.Clear();
			this.BuildGeometry();
			base.Invalidate();
		}

		// Token: 0x060013FC RID: 5116 RVA: 0x0009901C File Offset: 0x0009901C
		protected override void OnKeyDown(KeyEventArgs e)
		{
			base.OnKeyDown(e);
			if (e.KeyCode == Keys.Escape)
			{
				this.ResetEditState();
				return;
			}
			if (e.KeyCode == Keys.Delete && this.mi_SelectedPoints.Count > 0 && !this.mb_LiveMode)
			{
				this.DeleteSelectedPoints();
				return;
			}
			if (e.KeyCode == Keys.C && Control.ModifierKeys.HasFlag(Keys.Control))
			{
				this.ClearClickedPoints();
				base.Invalidate();
				e.Handled = true;
			}
		}

		// Token: 0x060013FD RID: 5117 RVA: 0x0000CA80 File Offset: 0x0000CA80
		private void OnTrackbarScroll(object sender, EventArgs e)
		{
			this.mi_Mouse.OnTrackBarScroll();
			this.mi_Transform.SetCoeficients(this.mi_Mouse);
			this.mi_DrawObjects.Clear();
			this.BuildGeometry();
			base.Invalidate();
		}

		// Token: 0x060013FE RID: 5118 RVA: 0x000990A0 File Offset: 0x000990A0
		private void UpdateHoverPoint(Point mp)
		{
			if (this.mi_ProjectedPoints == null)
			{
				return;
			}
			int num = this.ms32_HoverX;
			int num2 = this.ms32_HoverY;
			this.ms32_HoverX = -1;
			this.ms32_HoverY = -1;
			checked
			{
				for (int i = 0; i < this.mi_ProjectedPoints.GetLength(0); i++)
				{
					for (int j = 0; j < this.mi_ProjectedPoints.GetLength(1); j++)
					{
						Graph3D.cPoint2D cPoint2D = this.mi_ProjectedPoints[i, j];
						unchecked
						{
							if (cPoint2D != null && cPoint2D.IsValid)
							{
								double num3 = cPoint2D.md_X - (double)mp.X;
								double num4 = cPoint2D.md_Y - (double)mp.Y;
								if (Math.Sqrt(num3 * num3 + num4 * num4) < 12.0)
								{
									this.ms32_HoverX = j;
									this.ms32_HoverY = i;
									break;
								}
							}
						}
					}
				}
				if (num != this.ms32_HoverX || num2 != this.ms32_HoverY)
				{
					base.Invalidate();
				}
			}
		}

		// Token: 0x060013FF RID: 5119 RVA: 0x00099184 File Offset: 0x00099184
		private bool IsPointInSelection(int x, int y)
		{
			if (this.mi_ProjectedPoints == null || this.mk_SelectionRect.Width == 0 || this.mk_SelectionRect.Height == 0)
			{
				return false;
			}
			int length = this.mi_ProjectedPoints.GetLength(0);
			int length2 = this.mi_ProjectedPoints.GetLength(1);
			if (x < 0 || x >= length || y < 0 || y >= length2)
			{
				return false;
			}
			Graph3D.cPoint2D cPoint2D = this.mi_ProjectedPoints[x, y];
			if (cPoint2D == null || !cPoint2D.IsValid)
			{
				return false;
			}
			float num = (float)cPoint2D.md_X + (float)this.mi_Mouse.mk_Offset.X + (float)this.mk_Offset2D.X;
			float num2 = (float)cPoint2D.md_Y + (float)this.mi_Mouse.mk_Offset.Y + (float)this.mk_Offset2D.Y;
			float num3 = (float)base.ClientSize.Width - num;
			float num4 = num2;
			return checked(this.mk_SelectionRect.Contains((int)num3, (int)num4));
		}

		// Token: 0x06001400 RID: 5120 RVA: 0x00099270 File Offset: 0x00099270
		private void UpdateSelectionFromRect()
		{
			if (this.mi_ProjectedPoints == null)
			{
				return;
			}
			this.mi_SelectedPoints.Clear();
			if (this._selectedPointsSet == null)
			{
				this._selectedPointsSet = new HashSet<Point>();
			}
			else
			{
				this._selectedPointsSet.Clear();
			}
			this.ms32_SelectedX = -1;
			this.ms32_SelectedY = -1;
			int length = this.mi_ProjectedPoints.GetLength(0);
			int length2 = this.mi_ProjectedPoints.GetLength(1);
			checked
			{
				for (int i = 0; i < length; i++)
				{
					for (int j = 0; j < length2; j++)
					{
						if (this.IsPointInSelection(i, j))
						{
							Point item = new Point(i, j);
							this.mi_SelectedPoints.Add(item);
							this._selectedPointsSet.Add(item);
						}
					}
				}
				if (this.mi_SelectedPoints.Count == 1)
				{
					this.ms32_SelectedX = this.mi_SelectedPoints[0].X;
					this.ms32_SelectedY = this.mi_SelectedPoints[0].Y;
				}
				if (this.mi_SelectedPoints.Count > 0 && this.mi_PolyArr != null)
				{
					int length3 = this.mi_PolyArr.GetLength(0);
					int length4 = this.mi_PolyArr.GetLength(1);
					this.md_OriginalZValues = new double[this.mi_SelectedPoints.Count];
					for (int k = 0; k < this.mi_SelectedPoints.Count; k++)
					{
						Point point = this.mi_SelectedPoints[k];
						this.md_OriginalZValues[k] = ((point.X >= 0 && point.X < length3 && point.Y >= 0 && point.Y < length4) ? this.mi_PolyArr[point.X, point.Y].md_Z : 0.0);
					}
					this.md_AccumulatedDrag = 0.0;
					this.mb_BlockEditActive = true;
				}
				else
				{
					this.md_OriginalZValues = null;
					this.md_AccumulatedDrag = 0.0;
					this.mb_BlockEditActive = false;
				}
				this.NotifySelectionChangedToGrid();
			}
		}

		// Token: 0x06001401 RID: 5121 RVA: 0x00099474 File Offset: 0x00099474
		private void CheckHover(Point loc)
		{
			Graph3D.cDrawObj cDrawObj = null;
			checked
			{
				for (int i = this.mi_DrawObjects.Count - 1; i >= 0; i--)
				{
					Graph3D.cDrawObj cDrawObj2 = this.mi_DrawObjects[i];
					if (cDrawObj2.mi_Polygon != null && cDrawObj2.IsValid)
					{
						using (GraphicsPath graphicsPath = new GraphicsPath())
						{
							graphicsPath.AddPolygon(cDrawObj2.mi_Polygon.mk_Points);
							if (graphicsPath.IsVisible(loc.X, loc.Y))
							{
								cDrawObj = cDrawObj2;
								break;
							}
						}
					}
				}
				if (cDrawObj != this.hoveredObj)
				{
					this.hoveredObj = cDrawObj;
					base.Invalidate();
				}
			}
		}

		// Token: 0x06001402 RID: 5122 RVA: 0x0009951C File Offset: 0x0009951C
		private bool HitTestPoint(Point mp)
		{
			if (this.mi_ProjectedPoints == null)
			{
				return false;
			}
			int length = this.mi_ProjectedPoints.GetLength(0);
			int length2 = this.mi_ProjectedPoints.GetLength(1);
			if (length == 0 || length2 == 0)
			{
				return false;
			}
			int num = -1;
			int num2 = -1;
			double num3 = double.MaxValue;
			checked
			{
				for (int i = 0; i < length; i++)
				{
					for (int j = 0; j < length2; j++)
					{
						Graph3D.cPoint2D cPoint2D = this.mi_ProjectedPoints[i, j];
						unchecked
						{
							if (cPoint2D != null && cPoint2D.IsValid)
							{
								float num4 = (float)cPoint2D.md_X + (float)this.mi_Mouse.mk_Offset.X + (float)this.mk_Offset2D.X;
								float num5 = (float)cPoint2D.md_Y + (float)this.mi_Mouse.mk_Offset.Y + (float)this.mk_Offset2D.Y;
								double num6 = (double)((float)base.ClientSize.Width - num4);
								float num7 = num5;
								double num8 = num6 - (double)mp.X;
								double num9 = (double)num7 - (double)mp.Y;
								double num10 = num8 * num8 + num9 * num9;
								if (num10 < 225.0 && num10 < num3)
								{
									num3 = num10;
									num = i;
									num2 = j;
								}
							}
						}
					}
				}
				this.ms32_SelectedX = num;
				this.ms32_SelectedY = num2;
				return num >= 0;
			}
		}

		// Token: 0x06001403 RID: 5123 RVA: 0x00099674 File Offset: 0x00099674
		private bool IsPointUnderMouse(int x, int y, Point mousePos)
		{
			if (this.mi_ProjectedPoints == null)
			{
				return false;
			}
			int length = this.mi_ProjectedPoints.GetLength(0);
			int length2 = this.mi_ProjectedPoints.GetLength(1);
			if (x < 0 || x >= length || y < 0 || y >= length2)
			{
				return false;
			}
			Graph3D.cPoint2D cPoint2D;
			try
			{
				cPoint2D = this.mi_ProjectedPoints[x, y];
			}
			catch
			{
				return false;
			}
			if (cPoint2D == null || !cPoint2D.IsValid)
			{
				return false;
			}
			float num = (float)cPoint2D.md_X + (float)this.mi_Mouse.mk_Offset.X + (float)this.mk_Offset2D.X;
			float num2 = (float)cPoint2D.md_Y + (float)this.mi_Mouse.mk_Offset.Y + (float)this.mk_Offset2D.Y;
			float num3 = (float)base.ClientSize.Width - num;
			float num4 = num2;
			float num5 = num3 - (float)mousePos.X;
			float num6 = num4 - (float)mousePos.Y;
			return (float)Math.Sqrt((double)(num5 * num5 + num6 * num6)) < 15f;
		}

		// Token: 0x06001404 RID: 5124 RVA: 0x00099784 File Offset: 0x00099784
		private void HandleLiveModeMouseDown(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.mi_Mouse.me_Action = Graph3D.eMouseAction.Theta;
				this.Cursor = Cursors.NoMoveVert;
				return;
			}
			if (e.Button == MouseButtons.Middle)
			{
				this.mi_Mouse.me_Action = Graph3D.eMouseAction.Move;
				this.Cursor = Cursors.SizeAll;
			}
		}

		// Token: 0x06001405 RID: 5125 RVA: 0x000997DC File Offset: 0x000997DC
		private void HandleRightMouseDown(Point pos)
		{
			this.mb_SelectingArea = true;
			this.mk_SelectionStart = new Point(this.mk_LastMouseScreen.X, this.mk_LastMouseScreen.Y);
			this.mk_SelectionEnd = this.mk_SelectionStart;
			this.mk_SelectionRect = new Rectangle(this.mk_SelectionStart, Size.Empty);
			this.Cursor = Cursors.Cross;
			base.Invalidate();
		}

		// Token: 0x06001406 RID: 5126 RVA: 0x00099844 File Offset: 0x00099844
		private void HandleLiveModeMouseMove(MouseEventArgs e)
		{
			checked
			{
				int num = e.X - this.mk_LastMouseScreen.X;
				int num2 = e.Y - this.mk_LastMouseScreen.Y;
				this.mk_LastMouseScreen = e.Location;
				if (this.mi_Mouse.me_Action == Graph3D.eMouseAction.Move)
				{
					Graph3D.cMouse cMouse = this.mi_Mouse;
					cMouse.mk_Offset.X = cMouse.mk_Offset.X + num;
					Graph3D.cMouse cMouse2 = this.mi_Mouse;
					cMouse2.mk_Offset.Y = cMouse2.mk_Offset.Y + num2;
					base.Invalidate();
				}
				else if (this.mi_Mouse.me_Action >= Graph3D.eMouseAction.Rho)
				{
					this.mi_Mouse.OnMouseMove(num, num2);
					this.mi_Transform.SetCoeficients(this.mi_Mouse);
					this.mi_DrawObjects.Clear();
					this.BuildGeometry();
					base.Invalidate();
				}
				this.mi_Mouse.mk_LastPos = new Point(e.X - this.mi_Mouse.mk_Offset.X - this.mk_Offset2D.X, e.Y - this.mi_Mouse.mk_Offset.Y - this.mk_Offset2D.Y);
			}
		}

		// Token: 0x06001407 RID: 5127 RVA: 0x00099970 File Offset: 0x00099970
		private void HandleAreaDrag(int dy, Point pos)
		{
			if (!this.mb_BlockEditActive || this.mi_SelectedPoints.Count == 0 || this.mi_PolyArr == null || this.md_OriginalZValues == null || dy == 0)
			{
				return;
			}
			double effectiveDragSensitivity = this.GetEffectiveDragSensitivity();
			this.md_AccumulatedDrag += (double)dy * effectiveDragSensitivity;
			bool flag = false;
			int num = Math.Min(this.mi_SelectedPoints.Count, this.md_OriginalZValues.Length);
			for (int i = 0; i < num; i = checked(i + 1))
			{
				Point point = this.mi_SelectedPoints[i];
				int x = point.X;
				int y = point.Y;
				if (x >= 0 && x < this.mi_PolyArr.GetLength(0) && y >= 0 && y < this.mi_PolyArr.GetLength(1) && !this.IsBoundaryPoint(x, y))
				{
					double num2 = this.md_OriginalZValues[i] - this.md_AccumulatedDrag;
					double md_Z = this.mi_PolyArr[x, y].md_Z;
					if (Math.Abs(md_Z - num2) >= 0.0001)
					{
						this.mi_PolyArr[x, y].md_Z = num2;
						this.SetLiveZ(x, y, num2);
						this.OnPointValueChanged(x, y, md_Z, num2);
						flag = true;
					}
				}
			}
			if (flag)
			{
				this.mi_DrawObjects.Clear();
				this.BuildGeometry();
				base.Invalidate();
			}
			this.mk_LastMouse = pos;
		}

		// Token: 0x06001408 RID: 5128 RVA: 0x00099ADC File Offset: 0x00099ADC
		private void HandlePointDrag(int dy, Point pos)
		{
			if (this.ms32_SelectedX < 0 || this.ms32_SelectedY < 0 || this.mi_PolyArr == null || dy == 0)
			{
				return;
			}
			int num = this.ms32_SelectedX;
			int num2 = this.ms32_SelectedY;
			if (num < 0 || num >= this.mi_PolyArr.GetLength(0) || num2 < 0 || num2 >= this.mi_PolyArr.GetLength(1))
			{
				return;
			}
			if (this.IsBoundaryPoint(num, num2))
			{
				return;
			}
			double effectiveDragSensitivity = this.GetEffectiveDragSensitivity();
			this.md_AccumulatedDrag += (double)dy * effectiveDragSensitivity;
			double num3 = ((this.md_OriginalZValues != null && this.md_OriginalZValues.Length != 0) ? this.md_OriginalZValues[0] : this.mi_PolyArr[num, num2].md_Z) - this.md_AccumulatedDrag;
			double md_Z = this.mi_PolyArr[num, num2].md_Z;
			if (Math.Abs(md_Z - num3) < 0.0001)
			{
				this.mk_LastMouse = pos;
				return;
			}
			this.mi_PolyArr[num, num2].md_Z = num3;
			this.SetLiveZ(num, num2, num3);
			if (this.mi_ProjectedPoints != null)
			{
				int num4 = num2;
				int num5 = num;
				if (num4 >= 0 && num4 < this.mi_ProjectedPoints.GetLength(0) && num5 >= 0 && num5 < this.mi_ProjectedPoints.GetLength(1))
				{
					this.mi_ProjectedPoints[num4, num5] = this.mi_Transform.ProjectSurface(this.mi_PolyArr[num, num2], this.mi_MinMax.mi_Center3D);
				}
			}
			this.OnPointValueChanged(num, num2, md_Z, num3);
			base.Invalidate();
			this.mk_LastMouse = pos;
		}

		// Token: 0x06001409 RID: 5129 RVA: 0x00099C64 File Offset: 0x00099C64
		private void ResetEditState()
		{
			this.ms32_SelectedX = -1;
			this.ms32_SelectedY = -1;
			this.mi_SelectedPoints.Clear();
			this.mb_EditMode = false;
			this.mb_DragPoint = false;
			this.mb_DragAreaEdit = false;
			this.mb_SelectingArea = false;
			this.mb_BlockEditActive = false;
			this.Cursor = Cursors.Arrow;
			base.Invalidate();
		}

		// Token: 0x0600140A RID: 5130 RVA: 0x0000CAB5 File Offset: 0x0000CAB5
		private bool IsBoundaryPoint(int x, int y)
		{
			return checked(this.mi_PolyArr == null || x == 0 || y == 0 || x == this.mi_PolyArr.GetLength(0) - 1 || y == this.mi_PolyArr.GetLength(1) - 1);
		}

		// Token: 0x0600140B RID: 5131 RVA: 0x00099CC0 File Offset: 0x00099CC0
		private void SmoothNeighborGaussian(int cx, int cy, double deltaZ)
		{
			if (this.mi_PolyArr == null)
			{
				return;
			}
			int length = this.mi_PolyArr.GetLength(0);
			int length2 = this.mi_PolyArr.GetLength(1);
			checked
			{
				for (int i = -2; i <= 2; i++)
				{
					for (int j = -2; j <= 2; j++)
					{
						if (i != 0 || j != 0)
						{
							int num = cx + i;
							int num2 = cy + j;
							if (num >= 0 && num < length && num2 >= 0 && num2 < length2 && !this.IsBoundaryPoint(num, num2))
							{
								double num3 = Math.Sqrt((double)(i * i + j * j));
								unchecked
								{
									double num4 = Math.Exp(-(num3 * num3) / 3.0);
									this.mi_PolyArr[num, num2].md_Z -= deltaZ * num4 * 0.3;
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x0600140C RID: 5132 RVA: 0x00099D90 File Offset: 0x00099D90
		protected virtual void OnPointValueChanged(int x, int y, double oldValue, double newValue)
		{
			EventHandler<Graph3D.PointValueChangedEventArgs> pointValueChanged = this.PointValueChanged;
			if (pointValueChanged != null)
			{
				pointValueChanged(this, new Graph3D.PointValueChangedEventArgs(x, y, oldValue, newValue));
			}
			this.OnSurfaceDataChanged();
		}

		// Token: 0x0600140D RID: 5133 RVA: 0x00099DC0 File Offset: 0x00099DC0
		protected virtual void OnSurfaceDataChanged()
		{
			EventHandler surfaceDataChanged = this.SurfaceDataChanged;
			if (surfaceDataChanged != null)
			{
				surfaceDataChanged(this, EventArgs.Empty);
			}
		}

		// Token: 0x0600140F RID: 5135 RVA: 0x00099E34 File Offset: 0x00099E34
		private double CalculateInterval(double range)
		{
			double num = Math.Pow(10.0, Math.Floor(Math.Log10(range)));
			if (range / num >= 5.0)
			{
				return num;
			}
			if (range / (num / 2.0) >= 5.0)
			{
				return num / 2.0;
			}
			return num / 5.0;
		}

		// Token: 0x06001410 RID: 5136 RVA: 0x0000CAE9 File Offset: 0x0000CAE9
		private void UnlockNormalization()
		{
			this.mb_LockNormalization = false;
		}

		// Token: 0x06001411 RID: 5137 RVA: 0x0000CAF2 File Offset: 0x0000CAF2
		private string FormatLabel(double val)
		{
			return val.ToString("0.000", CultureInfo.InvariantCulture).TrimEnd(new char[]
			{
				'0'
			}).TrimEnd(new char[]
			{
				'.'
			});
		}

		// Token: 0x06001412 RID: 5138 RVA: 0x0000CB25 File Offset: 0x0000CB25
		private void InitializeControl()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.BackColor = Color.White;
			base.TabStop = true;
		}

		// Token: 0x06001413 RID: 5139 RVA: 0x00099E9C File Offset: 0x00099E9C
		private void InitializeDefaultColors()
		{
			this.SetAxisColor(Graph3D.eCoord.X, Color.DarkBlue);
			this.SetAxisColor(Graph3D.eCoord.Y, Color.DarkGreen);
			this.SetAxisColor(Graph3D.eCoord.Z, Color.DarkRed);
			this.mi_PolyLinePen = new Pen(Color.Black, 1f);
			this.mi_BorderPen = new Pen(Color.FromArgb(255, 180, 180, 180), 1f);
			this.mi_TopLegendBrush = new SolidBrush(Color.FromArgb(255, 200, 200, 150));
		}

		// Token: 0x06001414 RID: 5140 RVA: 0x0000CB45 File Offset: 0x0000CB45
		private void InitializeTransform()
		{
			this.mi_Transform.SetCoeficients(this.mi_Mouse);
		}

		// Token: 0x06001415 RID: 5141 RVA: 0x00099F30 File Offset: 0x00099F30
		private void InitializeInteraction()
		{
			this.mk_LastMouseScreen = Point.Empty;
			this.mi_LiveMode = false;
			this.mb_LiveMode = false;
			this.mb_FreezeGeometry = false;
			this.mb_LockNormalization = false;
			this.mb_DragAreaEdit = false;
			this.mb_EditMode = false;
			this.mb_DragPoint = false;
			this.mb_SelectingArea = false;
			this.mb_BlockEditActive = false;
		}

		// Token: 0x06001416 RID: 5142 RVA: 0x0000CB58 File Offset: 0x0000CB58
		private void ResetViewState()
		{
			this.mi_Mouse.mk_Offset = Point.Empty;
			this.mi_DrawObjects.Clear();
			this.mi_SelectedPoints.Clear();
			this._clickedPoints.Clear();
			this.mb_FreezeGeometry = false;
		}

		// Token: 0x06001417 RID: 5143 RVA: 0x00099F88 File Offset: 0x00099F88
		private void HandleLeftMouseDown(MouseEventArgs e, Point pos)
		{
			checked
			{
				if (this.mi_SelectedPoints != null && this.mi_SelectedPoints.Count > 0 && this.mi_PolyArr != null)
				{
					int length = this.mi_PolyArr.GetLength(0);
					int length2 = this.mi_PolyArr.GetLength(1);
					for (int i = this.mi_SelectedPoints.Count - 1; i >= 0; i--)
					{
						Point item = this.mi_SelectedPoints[i];
						if (item.X < 0 || item.X >= length || item.Y < 0 || item.Y >= length2)
						{
							this.mi_SelectedPoints.RemoveAt(i);
							if (this._selectedPointsSet != null)
							{
								this._selectedPointsSet.Remove(item);
							}
						}
					}
					bool flag = false;
					foreach (Point point in this.mi_SelectedPoints)
					{
						try
						{
							if (this.IsPointUnderMouse(point.X, point.Y, e.Location))
							{
								flag = true;
								break;
							}
						}
						catch (IndexOutOfRangeException)
						{
						}
					}
					if (flag)
					{
						this.mb_BlockEditActive = true;
						this.md_AccumulatedDrag = 0.0;
						this.md_OriginalZValues = new double[this.mi_SelectedPoints.Count];
						for (int j = 0; j < this.mi_SelectedPoints.Count; j++)
						{
							Point point2 = this.mi_SelectedPoints[j];
							this.md_OriginalZValues[j] = ((point2.X >= 0 && point2.X < length && point2.Y >= 0 && point2.Y < length2) ? this.mi_PolyArr[point2.X, point2.Y].md_Z : 0.0);
						}
						this.mb_DragAreaEdit = true;
						this.mb_DragPoint = false;
						this.mb_SelectingArea = false;
						this.mb_EditMode = true;
						this.Cursor = Cursors.SizeNS;
						base.Invalidate();
						return;
					}
				}
				if (this.mi_PolyArr != null && this.HitTestPoint(pos))
				{
					int length3 = this.mi_PolyArr.GetLength(0);
					int length4 = this.mi_PolyArr.GetLength(1);
					if (this.ms32_SelectedX >= 0 && this.ms32_SelectedX < length3 && this.ms32_SelectedY >= 0 && this.ms32_SelectedY < length4)
					{
						this.mb_DragPoint = true;
						this.mb_BlockEditActive = false;
						this.mb_EditMode = true;
						this.mb_SelectingArea = false;
						this.mb_DragAreaEdit = false;
						this.md_AccumulatedDrag = 0.0;
						this.md_OriginalZValues = new double[1];
						this.md_OriginalZValues[0] = this.mi_PolyArr[this.ms32_SelectedX, this.ms32_SelectedY].md_Z;
						this.mi_SelectedPoints.Clear();
						if (this._selectedPointsSet != null)
						{
							this._selectedPointsSet.Clear();
						}
						Point item2 = new Point(this.ms32_SelectedX, this.ms32_SelectedY);
						this.mi_SelectedPoints.Add(item2);
						if (this._selectedPointsSet == null)
						{
							this._selectedPointsSet = new HashSet<Point>();
						}
						this._selectedPointsSet.Add(item2);
						this.Cursor = Cursors.SizeNS;
						base.Invalidate();
						this.SyncGridSelectionColorsFromGraph();
						return;
					}
				}
				this.ms32_SelectedX = -1;
				this.ms32_SelectedY = -1;
				this.mi_SelectedPoints.Clear();
				if (this._selectedPointsSet != null)
				{
					this._selectedPointsSet.Clear();
				}
				this.mb_EditMode = false;
				this.mb_DragAreaEdit = false;
				this.mb_BlockEditActive = false;
				this.md_OriginalZValues = null;
				this.md_AccumulatedDrag = 0.0;
				this.Cursor = Cursors.Arrow;
				this.mi_Mouse.me_Action = Graph3D.eMouseAction.Theta;
				this.SyncGridSelectionColorsFromGraph();
			}
		}

		// Token: 0x06001418 RID: 5144 RVA: 0x0009A350 File Offset: 0x0009A350
		private void HandleSelectionMove(Point screenPos)
		{
			this.mk_SelectionEnd = screenPos;
			int x = Math.Min(this.mk_SelectionStart.X, this.mk_SelectionEnd.X);
			int y = Math.Min(this.mk_SelectionStart.Y, this.mk_SelectionEnd.Y);
			checked
			{
				int width = Math.Abs(this.mk_SelectionStart.X - this.mk_SelectionEnd.X);
				int height = Math.Abs(this.mk_SelectionStart.Y - this.mk_SelectionEnd.Y);
				this.mk_SelectionRect = new Rectangle(x, y, width, height);
				base.Invalidate();
			}
		}

		// Token: 0x06001419 RID: 5145 RVA: 0x0009A3EC File Offset: 0x0009A3EC
		private void DeleteSelectedPoints()
		{
			if (this.mi_PolyArr == null)
			{
				return;
			}
			foreach (Point point in this.mi_SelectedPoints)
			{
				if (!this.IsBoundaryPoint(point.X, point.Y))
				{
					double md_Z = this.mi_PolyArr[point.X, point.Y].md_Z;
					this.mi_PolyArr[point.X, point.Y].md_Z = this.mi_MinMax.md_MinZ;
					this.SetLiveZ(point.X, point.Y, this.mi_MinMax.md_MinZ);
					this.OnPointValueChanged(point.X, point.Y, md_Z, this.mi_MinMax.md_MinZ);
				}
			}
			this.mi_DrawObjects.Clear();
			this.BuildGeometry();
			base.Invalidate();
		}

		// Token: 0x0600141A RID: 5146 RVA: 0x0009A500 File Offset: 0x0009A500
		private double GetEffectiveDragSensitivity()
		{
			double num = 1.0;
			if (this.mi_MinMax != null)
			{
				num = Math.Abs(this.mi_MinMax.md_MaxZ - this.mi_MinMax.md_MinZ);
			}
			if (num < 1E-06)
			{
				num = 1.0;
			}
			return this.md_DragSensitivity * (num / 100.0);
		}

		// Token: 0x0600141C RID: 5148 RVA: 0x0009A564 File Offset: 0x0009A564
		private int MapRpmToLivePointerY(double rpm)
		{
			if (this.mi_ProjectedPoints == null)
			{
				return 0;
			}
			int num = checked(this.mi_ProjectedPoints.GetLength(1) - 1);
			if (num <= 0)
			{
				return 0;
			}
			if (double.IsNaN(rpm) || double.IsInfinity(rpm))
			{
				rpm = 0.0;
			}
			rpm = Math.Max(1000.0, Math.Min(3250.0, rpm));
			double num2 = (rpm - 1000.0) / 2250.0;
			return Math.Max(0, Math.Min(num, checked((int)Math.Round(unchecked(num2 * (double)num)))));
		}

		// Token: 0x0600141D RID: 5149 RVA: 0x0009A5F8 File Offset: 0x0009A5F8
		private int MapTpsToLivePointerX(double tps)
		{
			if (this.mi_ProjectedPoints == null)
			{
				return 0;
			}
			int num = checked(this.mi_ProjectedPoints.GetLength(0) - 1);
			if (num <= 0)
			{
				return 0;
			}
			if (double.IsNaN(tps) || double.IsInfinity(tps))
			{
				tps = 0.0;
			}
			tps = Math.Max(0.0, Math.Min(3.1, tps));
			double num2 = (tps - 0.0) / 3.1;
			return Math.Max(0, Math.Min(num, checked((int)Math.Round(unchecked(num2 * (double)num)))));
		}

		// Token: 0x0600141E RID: 5150 RVA: 0x0009A68C File Offset: 0x0009A68C
		public void SetSelectedPoints(IEnumerable<Point> pts)
		{
			if (this.mi_SelectedPoints == null)
			{
				this.mi_SelectedPoints = new List<Point>();
			}
			this.mi_SelectedPoints.Clear();
			if (this._selectedPointsSet == null)
			{
				this._selectedPointsSet = new HashSet<Point>();
			}
			else
			{
				this._selectedPointsSet.Clear();
			}
			this.ms32_SelectedX = -1;
			this.ms32_SelectedY = -1;
			if (pts != null)
			{
				foreach (Point item in pts)
				{
					if (item.X >= 0 && item.Y >= 0 && (this.mi_PolyArr == null || (item.X < this.mi_PolyArr.GetLength(0) && item.Y < this.mi_PolyArr.GetLength(1))) && this._selectedPointsSet.Add(item))
					{
						this.mi_SelectedPoints.Add(item);
					}
				}
				if (this.mi_SelectedPoints.Count == 1)
				{
					this.ms32_SelectedX = this.mi_SelectedPoints[0].X;
					this.ms32_SelectedY = this.mi_SelectedPoints[0].Y;
				}
			}
			base.Invalidate();
			this.NotifySelectionChangedToGrid();
		}

		// Token: 0x0600141F RID: 5151 RVA: 0x0009A7D0 File Offset: 0x0009A7D0
		public void AddSelectPoint(int x, int y)
		{
			if (this.mi_PolyArr == null)
			{
				return;
			}
			if (x < 0 || x >= this.mi_PolyArr.GetLength(0))
			{
				return;
			}
			if (y < 0 || y >= this.mi_PolyArr.GetLength(1))
			{
				return;
			}
			Point item = new Point(x, y);
			if (this._selectedPointsSet == null)
			{
				this._selectedPointsSet = new HashSet<Point>();
			}
			if (this._selectedPointsSet.Add(item))
			{
				this.mi_SelectedPoints.Add(item);
				base.Invalidate();
				this.NotifySelectionChangedToGrid();
			}
		}

		// Token: 0x06001420 RID: 5152 RVA: 0x0009A850 File Offset: 0x0009A850
		public void BindGridSelection(DataGridView grid)
		{
			if (grid == null)
			{
				return;
			}
			grid.SelectionChanged -= this.OnGridSelectionChanged;
			grid.SelectionChanged += this.OnGridSelectionChanged;
			grid.CellMouseDown -= this.OnGridCellMouseDown;
			grid.CellMouseDown += this.OnGridCellMouseDown;
			grid.CellMouseUp -= this.OnGridCellMouseUp;
			grid.CellMouseUp += this.OnGridCellMouseUp;
		}

		// Token: 0x06001421 RID: 5153 RVA: 0x0000CBB2 File Offset: 0x0000CBB2
		private void OnGridCellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left && e.RowIndex >= 0 && e.ColumnIndex >= 0)
			{
				this._suppressGridSelectionEvent = false;
				this.ClearSelection();
			}
		}

		// Token: 0x06001422 RID: 5154 RVA: 0x0000CBE0 File Offset: 0x0000CBE0
		private void OnGridCellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
		{
			this.SyncSelectionFromGrid(sender as DataGridView);
		}

		// Token: 0x06001423 RID: 5155 RVA: 0x0000CBEE File Offset: 0x0000CBEE
		private void OnGridSelectionChanged(object sender, EventArgs e)
		{
			if (this._suppressGridSelectionEvent)
			{
				return;
			}
			this.SyncSelectionFromGrid(sender as DataGridView);
		}

		// Token: 0x06001424 RID: 5156 RVA: 0x0009A8D0 File Offset: 0x0009A8D0
		private void SyncSelectionFromGrid(DataGridView grid)
		{
			if (grid == null || grid.IsDisposed || this.mi_PolyArr == null)
			{
				return;
			}
			this._suppressGridSelectionEvent = true;
			checked
			{
				try
				{
					int num = this._gridHasHeaderRow ? 1 : 0;
					int num2 = this._gridHasHeaderRow ? 1 : 0;
					HashSet<Point> hashSet = new HashSet<Point>();
					foreach (object obj in grid.SelectedCells)
					{
						DataGridViewCell dataGridViewCell = (DataGridViewCell)obj;
						int num3 = dataGridViewCell.ColumnIndex - num2;
						int num4 = dataGridViewCell.RowIndex - num;
						if (num3 >= 0 && num3 < this.mi_PolyArr.GetLength(0) && num4 >= 0 && num4 < this.mi_PolyArr.GetLength(1))
						{
							hashSet.Add(new Point(num3, num4));
						}
					}
					this.SetSelectedPoints(hashSet);
				}
				finally
				{
					this._suppressGridSelectionEvent = false;
				}
			}
		}

		// Token: 0x06001425 RID: 5157 RVA: 0x0009A9CC File Offset: 0x0009A9CC
		public void EnsureSurfaceFromGrid(DataGridView grid, bool autoBindSelection = true)
		{
			if (grid == null || grid.IsDisposed)
			{
				return;
			}
			int count = grid.Rows.Count;
			int count2 = grid.Columns.Count;
			if (count2 < 2 || count < 2)
			{
				return;
			}
			Graph3D.cPoint3D[,] array = new Graph3D.cPoint3D[count2, count];
			checked
			{
				for (int i = 0; i < count2; i++)
				{
					for (int j = 0; j < count; j++)
					{
						double z = 0.0;
						object value = grid.Rows[j].Cells[i].Value;
						double num = 0.0;
						if (value != null && value != DBNull.Value)
						{
							string text = Convert.ToString(value, CultureInfo.InvariantCulture);
							if (!string.IsNullOrEmpty(text) && double.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out num))
							{
								z = num;
							}
						}
						array[i, j] = new Graph3D.cPoint3D((double)i, (double)j, z);
					}
				}
				this.SetSurfacePoints(array, Graph3D.eNormalize.Separate);
				this._boundGrid = grid;
				this._gridHasHeaderRow = false;
				if (autoBindSelection)
				{
					this.BindGridSelection(grid);
				}
			}
		}

		// Token: 0x06001426 RID: 5158 RVA: 0x0009AAE0 File Offset: 0x0009AAE0
		private PointF ProjectedToScreen(Graph3D.cPoint2D p)
		{
			float num = (float)p.md_X + (float)this.mi_Mouse.mk_Offset.X + (float)this.mk_Offset2D.X;
			float y = (float)p.md_Y + (float)this.mi_Mouse.mk_Offset.Y + (float)this.mk_Offset2D.Y;
			return new PointF((float)base.ClientSize.Width - num, y);
		}

		// Token: 0x06001427 RID: 5159 RVA: 0x0009AB54 File Offset: 0x0009AB54
		private void SyncGridSelectionColorsFromGraph()
		{
			if (this._boundGrid == null || this._boundGrid.IsDisposed)
			{
				return;
			}
			if (this.mi_PolyArr == null)
			{
				return;
			}
			DataGridView boundGrid = this._boundGrid;
			if (boundGrid.InvokeRequired)
			{
				try
				{
					boundGrid.BeginInvoke(new Action(this.SyncGridSelectionColorsFromGraph));
				}
				catch
				{
				}
				return;
			}
			this._suppressGridSelectionEvent = true;
			checked
			{
				try
				{
					int num = this._gridHasHeaderRow ? 1 : 0;
					int num2 = this._gridHasHeaderRow ? 1 : 0;
					foreach (object obj in ((IEnumerable)boundGrid.Rows))
					{
						foreach (object obj2 in ((DataGridViewRow)obj).Cells)
						{
							DataGridViewCell dataGridViewCell = (DataGridViewCell)obj2;
							if (dataGridViewCell.RowIndex >= num && dataGridViewCell.ColumnIndex >= num2)
							{
								dataGridViewCell.Style.BackColor = Color.Empty;
								dataGridViewCell.Style.ForeColor = Color.Empty;
								dataGridViewCell.Style.SelectionBackColor = Color.Empty;
								dataGridViewCell.Style.SelectionForeColor = Color.Empty;
								dataGridViewCell.Selected = false;
							}
						}
					}
					HashSet<Point> selectedPointsSet = this._selectedPointsSet;
					if (selectedPointsSet != null && selectedPointsSet.Count > 0)
					{
						Color backColor = Color.FromArgb(80, 0, 200, 0);
						Color white = Color.White;
						foreach (Point point in selectedPointsSet)
						{
							int num3 = point.X + num2;
							int num4 = point.Y + num;
							if (num4 >= 0 && num4 < boundGrid.RowCount && num3 >= 0 && num3 < boundGrid.ColumnCount)
							{
								DataGridViewCell dataGridViewCell2 = boundGrid.Rows[num4].Cells[num3];
								dataGridViewCell2.Style.BackColor = backColor;
								dataGridViewCell2.Style.ForeColor = white;
								dataGridViewCell2.Style.SelectionBackColor = Color.FromArgb(140, 0, 200, 0);
								dataGridViewCell2.Style.SelectionForeColor = Color.White;
								dataGridViewCell2.Selected = true;
							}
						}
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine("SyncGridSelectionColorsFromGraph Error: " + ex.Message);
				}
				finally
				{
					this._suppressGridSelectionEvent = false;
				}
			}
		}

		// Token: 0x1400000E RID: 14
		// (add) Token: 0x06001428 RID: 5160 RVA: 0x0009AE5C File Offset: 0x0009AE5C
		// (remove) Token: 0x06001429 RID: 5161 RVA: 0x0009AE94 File Offset: 0x0009AE94
		public event EventHandler SelectionChangedInGraph;

		// Token: 0x0600142A RID: 5162 RVA: 0x0009AECC File Offset: 0x0009AECC
		private void NotifySelectionChangedToGrid()
		{
			this.SyncGridSelectionColorsFromGraph();
			try
			{
				EventHandler selectionChangedInGraph = this.SelectionChangedInGraph;
				if (selectionChangedInGraph != null)
				{
					selectionChangedInGraph(this, EventArgs.Empty);
				}
			}
			catch
			{
			}
		}

		// Token: 0x04001A97 RID: 6807
		private static readonly double[] VALUES_RHO = new double[]
		{
			300.0,
			1800.0,
			1350.0,
			2.0
		};

		// Token: 0x04001A98 RID: 6808
		private static readonly double[] VALUES_THETA = new double[]
		{
			0.0,
			170.0,
			10.0,
			0.25
		};

		// Token: 0x04001A99 RID: 6809
		private static readonly double[] VALUES_PHI = new double[]
		{
			0.0,
			360.0,
			270.0,
			0.4
		};

		// Token: 0x04001A9A RID: 6810
		private Graph3D.eRaster me_Raster;

		// Token: 0x04001A9B RID: 6811
		private Pen[] mi_AxisPens;

		// Token: 0x04001A9C RID: 6812
		private Pen[] mi_RasterPens;

		// Token: 0x04001A9D RID: 6813
		private Graph3D.cTransform mi_Transform;

		// Token: 0x04001A9E RID: 6814
		private List<Graph3D.cDrawObj> mi_DrawObjects;

		// Token: 0x04001A9F RID: 6815
		private Graph3D.cMouse mi_Mouse;

		// Token: 0x04001AA0 RID: 6816
		private Point mk_Offset2D;

		// Token: 0x04001AA1 RID: 6817
		private string[] ms_AxisLegends;

		// Token: 0x04001AA2 RID: 6818
		private SolidBrush[] mi_AxisBrushes;

		// Token: 0x04001AA3 RID: 6819
		private Pen mi_PolyLinePen;

		// Token: 0x04001AA4 RID: 6820
		private Pen mi_BorderPen;

		// Token: 0x04001AA5 RID: 6821
		private SolidBrush mi_TopLegendBrush;

		// Token: 0x04001AA6 RID: 6822
		private SolidBrush[] mi_SchemeBrushes;

		// Token: 0x04001AA7 RID: 6823
		private Pen[] mi_SchemePens;

		// Token: 0x04001AA8 RID: 6824
		private Graph3D.cPoint3D[,] mi_PolyArr;

		// Token: 0x04001AA9 RID: 6825
		private Graph3D.cScatter[] mi_ScatterArr;

		// Token: 0x04001AAA RID: 6826
		private Graph3D.cMinMax3D mi_MinMax;

		// Token: 0x04001AAB RID: 6827
		private Graph3D.cQuadrant mi_Quadrant;

		// Token: 0x04001AAC RID: 6828
		private int ms32_Points;

		// Token: 0x04001AAD RID: 6829
		private Graph3D.cDrawObj hoveredObj;

		// Token: 0x04001AAE RID: 6830
		private bool mb_EditMode;

		// Token: 0x04001AAF RID: 6831
		private bool mb_DragPoint;

		// Token: 0x04001AB0 RID: 6832
		private int ms32_SelectedX;

		// Token: 0x04001AB1 RID: 6833
		private int ms32_SelectedY;

		// Token: 0x04001AB2 RID: 6834
		private Point mk_LastMouse;

		// Token: 0x04001AB3 RID: 6835
		private Pen mi_SelectedPen;

		// Token: 0x04001AB4 RID: 6836
		private Graph3D.cPoint2D[,] mi_ProjectedPoints;

		// Token: 0x04001AB5 RID: 6837
		private int ms32_HoverX;

		// Token: 0x04001AB6 RID: 6838
		private int ms32_HoverY;

		// Token: 0x04001AB7 RID: 6839
		private Pen mi_HoverPen;

		// Token: 0x04001AB8 RID: 6840
		private bool mb_SelectingArea;

		// Token: 0x04001AB9 RID: 6841
		private Point mk_SelectionStart;

		// Token: 0x04001ABA RID: 6842
		private Point mk_SelectionEnd;

		// Token: 0x04001ABB RID: 6843
		private Rectangle mk_SelectionRect;

		// Token: 0x04001ABC RID: 6844
		private List<Point> mi_SelectedPoints;

		// Token: 0x04001ABD RID: 6845
		private Pen mi_SelectionPen;

		// Token: 0x04001ABE RID: 6846
		private SolidBrush mi_SelectionFill;

		// Token: 0x04001ABF RID: 6847
		private bool mb_DragAreaEdit;

		// Token: 0x04001AC0 RID: 6848
		private bool mb_BlockEditActive;

		// Token: 0x04001AC1 RID: 6849
		private double md_DragSensitivity;

		// Token: 0x04001AC2 RID: 6850
		private bool mb_LiveMode;

		// Token: 0x04001AC3 RID: 6851
		private bool mb_FreezeGeometry;

		// Token: 0x04001AC4 RID: 6852
		private bool mb_LockNormalization;

		// Token: 0x04001AC5 RID: 6853
		private Point mk_LastMouseScreen;

		// Token: 0x04001AC6 RID: 6854
		private double md_LockNormX;

		// Token: 0x04001AC7 RID: 6855
		private double md_LockNormY;

		// Token: 0x04001AC8 RID: 6856
		private double md_LockNormZ;

		// Token: 0x04001AC9 RID: 6857
		private double md_LockCenterX;

		// Token: 0x04001ACA RID: 6858
		private double md_LockCenterY;

		// Token: 0x04001ACB RID: 6859
		private double md_LockCenterZ;

		// Token: 0x04001ACC RID: 6860
		private readonly object _livePointerLock;

		// Token: 0x04001ACD RID: 6861
		private readonly object _liveRpmRangeLock;

		// Token: 0x04001ACE RID: 6862
		private bool _livePointerVisible;

		// Token: 0x04001ACF RID: 6863
		private int _livePointerX;

		// Token: 0x04001AD0 RID: 6864
		private int _livePointerY;

		// Token: 0x04001AD1 RID: 6865
		private double _livePointerZ;

		// Token: 0x04001AD2 RID: 6866
		private int _livePointerSize;

		// Token: 0x04001AD3 RID: 6867
		private bool _showLiveLabel;

		// Token: 0x04001AD4 RID: 6868
		private bool mi_LiveMode;

		// Token: 0x04001AD5 RID: 6869
		private double _livePointerRPM;

		// Token: 0x04001AD6 RID: 6870
		private double _livePointerTPS;

		// Token: 0x04001AD7 RID: 6871
		private double[,] _liveOverlayZ;

		// Token: 0x04001AD8 RID: 6872
		private double _liveRpmMin;

		// Token: 0x04001AD9 RID: 6873
		private double _liveRpmMax;

		// Token: 0x04001ADA RID: 6874
		private bool _showWireframe;

		// Token: 0x04001ADB RID: 6875
		private bool _autoRange;

		// Token: 0x04001ADC RID: 6876
		private Graph3D.eNormalize _currentNormalizeMode;

		// Token: 0x04001ADD RID: 6877
		private bool _showPoints;

		// Token: 0x04001ADE RID: 6878
		private bool _showCompareBins;

		// Token: 0x04001ADF RID: 6879
		private double[,] _compareBinData;

		// Token: 0x04001AE0 RID: 6880
		private List<Point> _allPoints;

		// Token: 0x04001AE1 RID: 6881
		private List<Point> _clickedPoints;

		// Token: 0x04001AE2 RID: 6882
		private bool _showClickedPoints;

		// Token: 0x04001AE3 RID: 6883
		private bool _allowDrag;

		// Token: 0x04001AE4 RID: 6884
		private bool _allowRotate;

		// Token: 0x04001AE5 RID: 6885
		private bool _allowZoom;

		// Token: 0x04001AE6 RID: 6886
		private double[] md_OriginalZValues;

		// Token: 0x04001AEA RID: 6890
		private double md_AccumulatedDrag;

		// Token: 0x04001AEB RID: 6891
		private DataGridView _boundGrid;

		// Token: 0x04001AEC RID: 6892
		private bool _gridHasHeaderRow;

		// Token: 0x04001AED RID: 6893
		private bool _suppressGridEvent;

		// Token: 0x04001AEE RID: 6894
		private bool _suppressSurfaceEvent;

		// Token: 0x04001AEF RID: 6895
		private double md_Dist;

		// Token: 0x04001AF0 RID: 6896
		private HashSet<Point> _selectedPointsSet;

		// Token: 0x04001AF1 RID: 6897
		private bool _suppressGridSelectionEvent;

		// Token: 0x020007E2 RID: 2018
		public enum eRaster
		{
			// Token: 0x04001AF4 RID: 6900
			Raster,
			// Token: 0x04001AF5 RID: 6901
			Off,
			// Token: 0x04001AF6 RID: 6902
			MainAxis
		}

		// Token: 0x020007E3 RID: 2019
		public enum eNormalize
		{
			// Token: 0x04001AF8 RID: 6904
			Separate,
			// Token: 0x04001AF9 RID: 6905
			MaintainXY,
			// Token: 0x04001AFA RID: 6906
			MaintainXYZ
		}

		// Token: 0x020007E4 RID: 2020
		public enum eCoord
		{
			// Token: 0x04001AFC RID: 6908
			X,
			// Token: 0x04001AFD RID: 6909
			Y,
			// Token: 0x04001AFE RID: 6910
			Z
		}

		// Token: 0x020007E5 RID: 2021
		private enum eMouseAction
		{
			// Token: 0x04001B00 RID: 6912
			None,
			// Token: 0x04001B01 RID: 6913
			Move,
			// Token: 0x04001B02 RID: 6914
			Rho,
			// Token: 0x04001B03 RID: 6915
			Theta,
			// Token: 0x04001B04 RID: 6916
			Phi
		}

		// Token: 0x020007E6 RID: 2022
		// (Invoke) Token: 0x0600142C RID: 5164
		public delegate double delRendererFunction(double X, double Y);

		// Token: 0x020007E7 RID: 2023
		public class PointValueChangedEventArgs : EventArgs
		{
			// Token: 0x17000107 RID: 263
			// (get) Token: 0x0600142F RID: 5167 RVA: 0x0000CC05 File Offset: 0x0000CC05
			// (set) Token: 0x06001430 RID: 5168 RVA: 0x0000CC0D File Offset: 0x0000CC0D
			public int X { get; set; }

			// Token: 0x17000108 RID: 264
			// (get) Token: 0x06001431 RID: 5169 RVA: 0x0000CC16 File Offset: 0x0000CC16
			// (set) Token: 0x06001432 RID: 5170 RVA: 0x0000CC1E File Offset: 0x0000CC1E
			public int Y { get; set; }

			// Token: 0x17000109 RID: 265
			// (get) Token: 0x06001433 RID: 5171 RVA: 0x0000CC27 File Offset: 0x0000CC27
			// (set) Token: 0x06001434 RID: 5172 RVA: 0x0000CC2F File Offset: 0x0000CC2F
			public double OldValue { get; set; }

			// Token: 0x1700010A RID: 266
			// (get) Token: 0x06001435 RID: 5173 RVA: 0x0000CC38 File Offset: 0x0000CC38
			// (set) Token: 0x06001436 RID: 5174 RVA: 0x0000CC40 File Offset: 0x0000CC40
			public double NewValue { get; set; }

			// Token: 0x06001437 RID: 5175 RVA: 0x0000CC49 File Offset: 0x0000CC49
			public PointValueChangedEventArgs(int x, int y, double oldVal, double newVal)
			{
				this.X = x;
				this.Y = y;
				this.OldValue = oldVal;
				this.NewValue = newVal;
			}
		}

		// Token: 0x020007E8 RID: 2024
		public class cPoint3D
		{
			// Token: 0x06001438 RID: 5176 RVA: 0x00002D8E File Offset: 0x00002D8E
			public cPoint3D()
			{
			}

			// Token: 0x06001439 RID: 5177 RVA: 0x0000CC6E File Offset: 0x0000CC6E
			public cPoint3D(double x, double y, double z)
			{
				this.md_X = x;
				this.md_Y = y;
				this.md_Z = z;
			}

			// Token: 0x0600143A RID: 5178 RVA: 0x0000CC8B File Offset: 0x0000CC8B
			public Graph3D.cPoint3D Clone()
			{
				return new Graph3D.cPoint3D(this.md_X, this.md_Y, this.md_Z);
			}

			// Token: 0x0600143B RID: 5179 RVA: 0x0000CCA4 File Offset: 0x0000CCA4
			public bool Equals(Graph3D.cPoint3D o)
			{
				return this.md_X == o.md_X && this.md_Y == o.md_Y && this.md_Z == o.md_Z;
			}

			// Token: 0x0600143C RID: 5180 RVA: 0x0000CCD2 File Offset: 0x0000CCD2
			public double GetValue(Graph3D.eCoord c)
			{
				if (c == Graph3D.eCoord.X)
				{
					return this.md_X;
				}
				if (c == Graph3D.eCoord.Y)
				{
					return this.md_Y;
				}
				return this.md_Z;
			}

			// Token: 0x0600143D RID: 5181 RVA: 0x0000CCEF File Offset: 0x0000CCEF
			public void SetValue(Graph3D.eCoord c, double v)
			{
				if (c == Graph3D.eCoord.X)
				{
					this.md_X = v;
					return;
				}
				if (c == Graph3D.eCoord.Y)
				{
					this.md_Y = v;
					return;
				}
				this.md_Z = v;
			}

			// Token: 0x0600143E RID: 5182 RVA: 0x0000CD0F File Offset: 0x0000CD0F
			public override string ToString()
			{
				return string.Format("{0:0.00}, {1:0.00}, {2:0.00}", this.md_X, this.md_Y, this.md_Z);
			}

			// Token: 0x04001B09 RID: 6921
			public double md_X;

			// Token: 0x04001B0A RID: 6922
			public double md_Y;

			// Token: 0x04001B0B RID: 6923
			public double md_Z;
		}

		// Token: 0x020007E9 RID: 2025
		public class cPoint2D
		{
			// Token: 0x1700010B RID: 267
			// (get) Token: 0x0600143F RID: 5183 RVA: 0x0000CD3C File Offset: 0x0000CD3C
			public PointF Coord
			{
				get
				{
					return new PointF((float)this.md_X, (float)this.md_Y);
				}
			}

			// Token: 0x1700010C RID: 268
			// (get) Token: 0x06001440 RID: 5184 RVA: 0x0009AF0C File Offset: 0x0009AF0C
			public bool IsValid
			{
				get
				{
					return !double.IsNaN(this.md_X) && Math.Abs(this.md_X) < 9999.9 && !double.IsNaN(this.md_Y) && Math.Abs(this.md_Y) < 9999.9;
				}
			}

			// Token: 0x06001441 RID: 5185 RVA: 0x0000CD51 File Offset: 0x0000CD51
			public override string ToString()
			{
				return string.Format("{0:0.00}, {1:0.00}", this.md_X, this.md_Y);
			}

			// Token: 0x04001B0C RID: 6924
			public double md_X;

			// Token: 0x04001B0D RID: 6925
			public double md_Y;
		}

		// Token: 0x020007EA RID: 2026
		public class cScatter
		{
			// Token: 0x06001443 RID: 5187 RVA: 0x0000CD73 File Offset: 0x0000CD73
			public cScatter(double x, double y, double z, Brush br)
			{
				this.mi_Point3D = new Graph3D.cPoint3D(x, y, z);
				this.mi_Brush = br;
			}

			// Token: 0x06001444 RID: 5188 RVA: 0x0009AF64 File Offset: 0x0009AF64
			public void SetPoint2D(Graph3D.cPoint2D p)
			{
				this.mk_Point = p.Coord;
				this.mb_Valid = p.IsValid;
				this.mk_Point.X = this.mk_Point.X - 3f;
				this.mk_Point.Y = this.mk_Point.Y - 3f;
			}

			// Token: 0x1700010D RID: 269
			// (get) Token: 0x06001445 RID: 5189 RVA: 0x0000CD91 File Offset: 0x0000CD91
			public bool IsValid
			{
				get
				{
					return this.mb_Valid;
				}
			}

			// Token: 0x04001B0E RID: 6926
			public Graph3D.cPoint3D mi_Point3D;

			// Token: 0x04001B0F RID: 6927
			public PointF mk_Point;

			// Token: 0x04001B10 RID: 6928
			public Brush mi_Brush;

			// Token: 0x04001B11 RID: 6929
			public Pen mi_Pen;

			// Token: 0x04001B12 RID: 6930
			public double md_FactorZ;

			// Token: 0x04001B13 RID: 6931
			public Graph3D.cScatter mi_Previous;

			// Token: 0x04001B14 RID: 6932
			public bool mb_Combine;

			// Token: 0x04001B15 RID: 6933
			private bool mb_Valid;
		}

		// Token: 0x020007EB RID: 2027
		private class cMinMax3D
		{
			// Token: 0x06001446 RID: 5190 RVA: 0x0009AFC4 File Offset: 0x0009AFC4
			public cMinMax3D(Graph3D.cPoint3D[,] pts)
			{
				checked
				{
					for (int i = 0; i < pts.GetLength(0); i++)
					{
						for (int j = 0; j < pts.GetLength(1); j++)
						{
							Graph3D.cPoint3D cPoint3D = pts[i, j];
							this.md_MinX = Math.Min(this.md_MinX, cPoint3D.md_X);
							this.md_MaxX = Math.Max(this.md_MaxX, cPoint3D.md_X);
							this.md_MinY = Math.Min(this.md_MinY, cPoint3D.md_Y);
							this.md_MaxY = Math.Max(this.md_MaxY, cPoint3D.md_Y);
							this.md_MinZ = Math.Min(this.md_MinZ, cPoint3D.md_Z);
							this.md_MaxZ = Math.Max(this.md_MaxZ, cPoint3D.md_Z);
						}
					}
				}
			}

			// Token: 0x06001447 RID: 5191 RVA: 0x0009B100 File Offset: 0x0009B100
			public cMinMax3D(Graph3D.cScatter[] arr)
			{
				checked
				{
					for (int i = 0; i < arr.Length; i++)
					{
						Graph3D.cPoint3D mi_Point3D = arr[i].mi_Point3D;
						this.md_MinX = Math.Min(this.md_MinX, mi_Point3D.md_X);
						this.md_MaxX = Math.Max(this.md_MaxX, mi_Point3D.md_X);
						this.md_MinY = Math.Min(this.md_MinY, mi_Point3D.md_Y);
						this.md_MaxY = Math.Max(this.md_MaxY, mi_Point3D.md_Y);
						this.md_MinZ = Math.Min(this.md_MinZ, mi_Point3D.md_Z);
						this.md_MaxZ = Math.Max(this.md_MaxZ, mi_Point3D.md_Z);
					}
				}
			}

			// Token: 0x04001B16 RID: 6934
			public double md_MinX = double.PositiveInfinity;

			// Token: 0x04001B17 RID: 6935
			public double md_MaxX = double.NegativeInfinity;

			// Token: 0x04001B18 RID: 6936
			public double md_MinY = double.PositiveInfinity;

			// Token: 0x04001B19 RID: 6937
			public double md_MaxY = double.NegativeInfinity;

			// Token: 0x04001B1A RID: 6938
			public double md_MinZ = double.PositiveInfinity;

			// Token: 0x04001B1B RID: 6939
			public double md_MaxZ = double.NegativeInfinity;

			// Token: 0x04001B1C RID: 6940
			public Graph3D.cPoint3D mi_Center3D = new Graph3D.cPoint3D();
		}

		// Token: 0x020007EC RID: 2028
		private class cLine
		{
			// Token: 0x06001448 RID: 5192 RVA: 0x0000CD99 File Offset: 0x0000CD99
			public bool CoordEquals(Graph3D.cLine o)
			{
				return this.mi_Points3D[0].Equals(o.mi_Points3D[0]) && this.mi_Points3D[1].Equals(o.mi_Points3D[1]);
			}

			// Token: 0x1700010E RID: 270
			// (get) Token: 0x06001449 RID: 5193 RVA: 0x0000CDC9 File Offset: 0x0000CDC9
			public bool IsValid
			{
				get
				{
					return this.mi_Points2D[0].IsValid && this.mi_Points2D[1].IsValid;
				}
			}

			// Token: 0x0600144A RID: 5194 RVA: 0x0009B220 File Offset: 0x0009B220
			public void CalcAngle2D()
			{
				this.md_Angle = Math.Atan2(this.mi_Points2D[1].md_Y - this.mi_Points2D[0].md_Y, this.mi_Points2D[1].md_X - this.mi_Points2D[0].md_X) * 180.0 / 3.141592653589793;
				if (this.md_Angle < 0.0)
				{
					this.md_Angle += 360.0;
				}
			}

			// Token: 0x04001B1D RID: 6941
			public Graph3D.eCoord me_Line;

			// Token: 0x04001B1E RID: 6942
			public Graph3D.eCoord me_Offset;

			// Token: 0x04001B1F RID: 6943
			public double md_Label;

			// Token: 0x04001B20 RID: 6944
			public double md_Sort;

			// Token: 0x04001B21 RID: 6945
			public double md_Angle;

			// Token: 0x04001B22 RID: 6946
			public Pen mi_Pen;

			// Token: 0x04001B23 RID: 6947
			public Graph3D.cPoint3D[] mi_Points3D = new Graph3D.cPoint3D[]
			{
				new Graph3D.cPoint3D(),
				new Graph3D.cPoint3D()
			};

			// Token: 0x04001B24 RID: 6948
			public Graph3D.cPoint2D[] mi_Points2D = new Graph3D.cPoint2D[]
			{
				new Graph3D.cPoint2D(),
				new Graph3D.cPoint2D()
			};
		}

		// Token: 0x020007ED RID: 2029
		private class cPolygon
		{
			// Token: 0x0600144C RID: 5196 RVA: 0x0009B2AC File Offset: 0x0009B2AC
			public cPolygon(params Graph3D.cPoint2D[] pts)
			{
				this.mb_Valid = true;
				this.mk_Points = new PointF[pts.Length];
				checked
				{
					for (int i = 0; i < pts.Length; i++)
					{
						if (pts[i].IsValid)
						{
							this.mk_Points[i] = pts[i].Coord;
						}
						else
						{
							this.mb_Valid = false;
						}
					}
				}
			}

			// Token: 0x1700010F RID: 271
			// (get) Token: 0x0600144D RID: 5197 RVA: 0x0000CE29 File Offset: 0x0000CE29
			public bool IsValid
			{
				get
				{
					return this.mb_Valid;
				}
			}

			// Token: 0x04001B25 RID: 6949
			public PointF[] mk_Points;

			// Token: 0x04001B26 RID: 6950
			public double md_FactorZ;

			// Token: 0x04001B27 RID: 6951
			private bool mb_Valid;
		}

		// Token: 0x020007EE RID: 2030
		private class cDrawObj
		{
			// Token: 0x0600144E RID: 5198 RVA: 0x0000CE31 File Offset: 0x0000CE31
			public cDrawObj(Graph3D.cPolygon p, double sort)
			{
				this.mi_Polygon = p;
				this.mb_Valid = p.IsValid;
				this.md_Sort = sort;
			}

			// Token: 0x0600144F RID: 5199 RVA: 0x0000CE53 File Offset: 0x0000CE53
			public cDrawObj(Graph3D.cScatter s, double sort)
			{
				this.mi_Scatter = s;
				this.mb_Valid = s.IsValid;
				this.md_Sort = sort;
			}

			// Token: 0x06001450 RID: 5200 RVA: 0x0000CE75 File Offset: 0x0000CE75
			public cDrawObj(Graph3D.cLine l, double sort)
			{
				this.mi_Line = l;
				this.mb_Valid = l.IsValid;
				this.md_Sort = sort;
			}

			// Token: 0x17000110 RID: 272
			// (get) Token: 0x06001451 RID: 5201 RVA: 0x0000CE97 File Offset: 0x0000CE97
			public bool IsValid
			{
				get
				{
					return this.mb_Valid;
				}
			}

			// Token: 0x04001B28 RID: 6952
			public Graph3D.cPolygon mi_Polygon;

			// Token: 0x04001B29 RID: 6953
			public Graph3D.cScatter mi_Scatter;

			// Token: 0x04001B2A RID: 6954
			public Graph3D.cLine mi_Line;

			// Token: 0x04001B2B RID: 6955
			public double md_Sort;

			// Token: 0x04001B2C RID: 6956
			private bool mb_Valid;
		}

		// Token: 0x020007EF RID: 2031
		private class cQuadrant
		{
			// Token: 0x06001452 RID: 5202 RVA: 0x0009B30C File Offset: 0x0009B30C
			public cQuadrant(double phi, Graph3D.cLine ax, Graph3D.cLine ay, Graph3D.cLine az)
			{
				int num = checked((int)(unchecked(phi + 45.0))) % 360 / 90;
				num = Math.Min(3, num);
				this.mb_BottomView = ((num == 0 && ax.md_Angle < 180.0) || (num == 1 && ay.md_Angle < 180.0) || (num == 2 && ax.md_Angle > 180.0) || (num == 3 && ay.md_Angle > 180.0));
				this.md_SortXY = (this.mb_BottomView ? 99999.9 : -99999.9);
				this.md_SortXZ = ((num == 1 || num == 2) ? 99999.9 : -99999.9);
				this.md_SortYZ = ((num == 0 || num == 1) ? 99999.9 : -99999.9);
				ax.md_Sort = this.md_SortXZ;
				ay.md_Sort = this.md_SortYZ;
				az.md_Sort = 0.0;
			}

			// Token: 0x04001B2D RID: 6957
			public double md_SortXY;

			// Token: 0x04001B2E RID: 6958
			public double md_SortXZ;

			// Token: 0x04001B2F RID: 6959
			public double md_SortYZ;

			// Token: 0x04001B30 RID: 6960
			public bool mb_BottomView;
		}

		// Token: 0x020007F0 RID: 2032
		private class cTransform
		{
			// Token: 0x06001453 RID: 5203 RVA: 0x0009B42C File Offset: 0x0009B42C
			public void SetCoeficients(Graph3D.cMouse m)
			{
				if (m == null)
				{
					return;
				}
				this.md_Rho = m.md_Rho;
				double num = m.md_Theta * 3.141592653589793 / 180.0;
				double num2 = (m.md_Phi - 180.0) * 3.141592653589793 / 180.0;
				this.md_sf = Math.Sin(num2);
				this.md_cf = Math.Cos(num2);
				this.md_st = Math.Sin(num);
				this.md_ct = Math.Cos(num);
			}

			// Token: 0x06001454 RID: 5204 RVA: 0x0009B4BC File Offset: 0x0009B4BC
			public void SetSize(Size sz)
			{
				double num = (double)sz.Width * 0.0254 / 96.0;
				double num2 = (double)sz.Height * 0.0254 / 96.0;
				this.md_FactX = (double)sz.Width / num;
				this.md_FactY = -((double)sz.Height / num2);
				this.md_OffsX = this.md_FactX * num / 2.0;
				this.md_OffsY = -this.md_FactY * num2 / 2.0;
			}

			// Token: 0x06001455 RID: 5205 RVA: 0x0009B558 File Offset: 0x0009B558
			public Graph3D.cPoint2D Project(Graph3D.cPoint3D p, Graph3D.cPoint3D center)
			{
				if (p == null || center == null)
				{
					return new Graph3D.cPoint2D();
				}
				double num = -(p.md_X - center.md_X) * this.md_NormalizeX;
				double num2 = (p.md_Y - center.md_Y) * this.md_NormalizeY;
				double num3 = (p.md_Z - center.md_Z) * this.md_NormalizeZ;
				double num4 = -this.md_sf * num + this.md_cf * num2;
				double num5 = -this.md_cf * this.md_ct * num - this.md_sf * this.md_ct * num2 + this.md_st * num3;
				double num6 = -this.md_cf * this.md_st * num - this.md_sf * this.md_st * num2 - this.md_ct * num3 + this.md_Rho;
				if (num6 <= 0.0)
				{
					num6 = 0.01;
				}
				return new Graph3D.cPoint2D
				{
					md_X = this.md_FactX * num4 * this.md_Dist / num6 + this.md_OffsX,
					md_Y = this.md_FactY * num5 * this.md_Dist / num6 + this.md_OffsY
				};
			}

			// Token: 0x06001456 RID: 5206 RVA: 0x0009B680 File Offset: 0x0009B680
			public Graph3D.cPoint2D ProjectSurface(Graph3D.cPoint3D p, Graph3D.cPoint3D center)
			{
				if (p == null || center == null)
				{
					return new Graph3D.cPoint2D();
				}
				double num = (p.md_X - center.md_X) * this.md_NormalizeX;
				double num2 = (p.md_Y - center.md_Y) * this.md_NormalizeY;
				double num3 = (p.md_Z - center.md_Z) * this.md_NormalizeZ;
				double num4 = -this.md_sf * num + this.md_cf * num2;
				double num5 = -this.md_cf * this.md_ct * num - this.md_sf * this.md_ct * num2 + this.md_st * num3;
				double num6 = -this.md_cf * this.md_st * num - this.md_sf * this.md_st * num2 - this.md_ct * num3 + this.md_Rho;
				if (num6 <= 0.0)
				{
					num6 = 0.01;
				}
				return new Graph3D.cPoint2D
				{
					md_X = this.md_FactX * num4 * this.md_Dist / num6 + this.md_OffsX,
					md_Y = this.md_FactY * num5 * this.md_Dist / num6 + this.md_OffsY
				};
			}

			// Token: 0x06001457 RID: 5207 RVA: 0x0000CE9F File Offset: 0x0000CE9F
			public double ProjectXYSurface(double x, double y)
			{
				return x * this.md_cf + y * this.md_sf;
			}

			// Token: 0x06001459 RID: 5209 RVA: 0x0000CEC9 File Offset: 0x0000CEC9
			public double ProjectXY(double x, double y)
			{
				return -x * this.md_cf + y * this.md_sf;
			}

			// Token: 0x04001B31 RID: 6961
			private double md_Dist = 0.5;

			// Token: 0x04001B32 RID: 6962
			private double md_sf;

			// Token: 0x04001B33 RID: 6963
			private double md_st;

			// Token: 0x04001B34 RID: 6964
			private double md_cf;

			// Token: 0x04001B35 RID: 6965
			private double md_ct;

			// Token: 0x04001B36 RID: 6966
			private double md_Rho;

			// Token: 0x04001B37 RID: 6967
			private double md_FactX;

			// Token: 0x04001B38 RID: 6968
			private double md_OffsX;

			// Token: 0x04001B39 RID: 6969
			private double md_FactY;

			// Token: 0x04001B3A RID: 6970
			private double md_OffsY;

			// Token: 0x04001B3B RID: 6971
			public double md_NormalizeX;

			// Token: 0x04001B3C RID: 6972
			public double md_NormalizeY;

			// Token: 0x04001B3D RID: 6973
			public double md_NormalizeZ;
		}

		// Token: 0x020007F1 RID: 2033
		private class cMouse
		{
			// Token: 0x0600145A RID: 5210 RVA: 0x0009B7A4 File Offset: 0x0009B7A4
			public void AssignTrackbar(Graph3D.eMouseAction action, TrackBar tb, EventHandler onScroll)
			{
				if (tb == null)
				{
					return;
				}
				double[] array = null;
				switch (action)
				{
				case Graph3D.eMouseAction.Rho:
					array = Graph3D.VALUES_RHO;
					this.mi_TrackRho = tb;
					break;
				case Graph3D.eMouseAction.Theta:
					array = Graph3D.VALUES_THETA;
					this.mi_TrackTheta = tb;
					break;
				case Graph3D.eMouseAction.Phi:
					array = Graph3D.VALUES_PHI;
					this.mi_TrackPhi = tb;
					break;
				}
				checked
				{
					if (array != null)
					{
						tb.Minimum = (int)array[0];
						tb.Maximum = (int)array[1];
						tb.Value = (int)array[2];
						tb.Scroll += onScroll;
					}
				}
			}

			// Token: 0x0600145B RID: 5211 RVA: 0x0009B820 File Offset: 0x0009B820
			public void OnTrackBarScroll()
			{
				if (this.mi_TrackRho != null)
				{
					this.md_Rho = (double)this.mi_TrackRho.Value;
				}
				if (this.mi_TrackTheta != null)
				{
					this.md_Theta = (double)this.mi_TrackTheta.Value;
				}
				if (this.mi_TrackPhi != null)
				{
					this.md_Phi = (double)this.mi_TrackPhi.Value;
				}
			}

			// Token: 0x0600145C RID: 5212 RVA: 0x0009B87C File Offset: 0x0009B87C
			public void OnMouseMove(int dx, int dy)
			{
				switch (this.me_Action)
				{
				case Graph3D.eMouseAction.Rho:
					this.md_Rho += (double)dy * Graph3D.VALUES_RHO[3];
					this.SetRho(this.md_Rho);
					return;
				case Graph3D.eMouseAction.Theta:
					this.md_Theta -= (double)dy * Graph3D.VALUES_THETA[3];
					this.SetTheta(this.md_Theta);
					this.md_Phi -= (double)dx * Graph3D.VALUES_PHI[3];
					this.SetPhi(this.md_Phi);
					return;
				case Graph3D.eMouseAction.Phi:
					this.md_Phi -= (double)dx * Graph3D.VALUES_PHI[3];
					this.SetPhi(this.md_Phi);
					return;
				default:
					return;
				}
			}

			// Token: 0x0600145D RID: 5213 RVA: 0x0000CEDD File Offset: 0x0000CEDD
			public void SetRho(double v)
			{
				this.md_Rho = Math.Max(Graph3D.VALUES_RHO[0], Math.Min(Graph3D.VALUES_RHO[1], v));
				if (this.mi_TrackRho != null)
				{
					this.mi_TrackRho.Value = checked((int)this.md_Rho);
				}
			}

			// Token: 0x0600145E RID: 5214 RVA: 0x0000CF18 File Offset: 0x0000CF18
			public void SetTheta(double v)
			{
				this.md_Theta = Math.Max(Graph3D.VALUES_THETA[0], Math.Min(Graph3D.VALUES_THETA[1], v));
				if (this.mi_TrackTheta != null)
				{
					this.mi_TrackTheta.Value = checked((int)this.md_Theta);
				}
			}

			// Token: 0x0600145F RID: 5215 RVA: 0x0009B934 File Offset: 0x0009B934
			public void SetPhi(double v)
			{
				this.md_Phi = v;
				while (this.md_Phi > 360.0)
				{
					this.md_Phi -= 360.0;
				}
				while (this.md_Phi < 0.0)
				{
					this.md_Phi += 360.0;
				}
				if (this.mi_TrackPhi != null)
				{
					this.mi_TrackPhi.Value = checked((int)this.md_Phi);
				}
			}

			// Token: 0x04001B3E RID: 6974
			public Graph3D.eMouseAction me_Action;

			// Token: 0x04001B3F RID: 6975
			public Point mk_LastPos;

			// Token: 0x04001B40 RID: 6976
			public Point mk_Offset;

			// Token: 0x04001B41 RID: 6977
			public TrackBar mi_TrackRho;

			// Token: 0x04001B42 RID: 6978
			public TrackBar mi_TrackTheta;

			// Token: 0x04001B43 RID: 6979
			public TrackBar mi_TrackPhi;

			// Token: 0x04001B44 RID: 6980
			public double md_Rho = Graph3D.VALUES_RHO[2];

			// Token: 0x04001B45 RID: 6981
			public double md_Theta = Graph3D.VALUES_THETA[2];

			// Token: 0x04001B46 RID: 6982
			public double md_Phi = Graph3D.VALUES_PHI[2];
		}
	}
}
