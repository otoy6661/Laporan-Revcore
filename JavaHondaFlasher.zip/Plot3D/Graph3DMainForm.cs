﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Plot3D
{
	// Token: 0x020007D9 RID: 2009
	public partial class Graph3DMainForm : Form
	{
		// Token: 0x1400000A RID: 10
		// (add) Token: 0x060012FF RID: 4863 RVA: 0x0008F63C File Offset: 0x0008F63C
		// (remove) Token: 0x06001300 RID: 4864 RVA: 0x0008F674 File Offset: 0x0008F674
		public event EventHandler<Graph3D.PointValueChangedEventArgs> PointValueChanged;

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x06001301 RID: 4865 RVA: 0x0000C2C5 File Offset: 0x0000C2C5
		public Graph3D Graph3DControl
		{
			get
			{
				return this.graphControl ?? this.graph3D;
			}
		}

		// Token: 0x06001302 RID: 4866 RVA: 0x0008F6AC File Offset: 0x0008F6AC
		public Graph3DMainForm()
		{
			this._wireFrameEnabled = false;
			this._autoRangeEnabled = true;
			this._heightColorEnabled = true;
			this._showAllPointsEnabled = false;
			this._showCompareBinsEnabled = false;
			this._dragGraphEnabled = true;
			this._rotateGraphEnabled = true;
			this._zoomGraphEnabled = true;
			this._autoRotateEnabled = false;
			this._autoRotateSpeed = 2;
			this._selectedColorIndex = 0;
			this.InitializeComponent();
			base.KeyPreview = true;
			base.KeyDown += this.Graph3DMainForm_KeyDown;
			this.graphControl = this.graph3D;
			this.InitializeTrackBars();
			this.InitializeAutoRotateTimer();
			if (this.graph3D != null)
			{
				this.graph3D.AssignTrackBars(this.trackRho, this.trackTheta, this.trackPhi);
				this.InitializeMenuItems();
				this.graph3D.PointValueChanged += delegate(object s, Graph3D.PointValueChangedEventArgs e)
				{
					EventHandler<Graph3D.PointValueChangedEventArgs> pointValueChanged = this.PointValueChanged;
					if (pointValueChanged != null)
					{
						pointValueChanged(s, e);
					}
					if (this.lblInfo != null && e != null)
					{
						this.lblInfo.Text = string.Format("Ptr: X={0}, Y={1}", e.X, e.Y);
					}
				};
				this.graph3D.SetCoefficients(1350.0, 70.0, 230.0);
				this.graph3D.MouseDown += delegate(object s, MouseEventArgs e)
				{
					if (this._dragGraphEnabled || this._rotateGraphEnabled || this._zoomGraphEnabled)
					{
						this._isDragging = true;
						this._lastMousePos = e.Location;
					}
				};
				this.graph3D.MouseUp += delegate(object s, MouseEventArgs e)
				{
					this._isDragging = false;
				};
				this.graph3D.MouseMove += delegate(object s, MouseEventArgs e)
				{
					if (this._isDragging && this.IsLiveModeActive())
					{
						bool flag = this._dragGraphEnabled && e.Button == MouseButtons.Left;
						bool flag2 = this._rotateGraphEnabled && (e.Button == MouseButtons.Right || e.Button == MouseButtons.Middle);
						if (flag || flag2)
						{
							this.graph3D.Invalidate();
						}
					}
				};
				this.graph3D.MouseWheel += delegate(object s, MouseEventArgs e)
				{
					if (this._zoomGraphEnabled && this.trackRho != null)
					{
						int num = (e.Delta > 0) ? 5 : -5;
						int num2 = checked(this.trackRho.Value + num);
						if (num2 >= this.trackRho.Minimum && num2 <= this.trackRho.Maximum)
						{
							this.trackRho.Value = num2;
						}
					}
				};
				this.UpdateGraphInteraction();
			}
			this.UpdateMenuState();
			this.InitRoundedNeonBorder();
		}

		// Token: 0x06001303 RID: 4867 RVA: 0x0008F81C File Offset: 0x0008F81C
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			try
			{
				if (this.graph3D != null)
				{
					this.graph3D.AssignTrackBars(this.trackRho, this.trackTheta, this.trackPhi);
				}
				this.graph3D.SetCoefficients(1350.0, 69.0, 345.0);
				this.ApplyDefaultColorScheme();
				this.UpdateMenuState();
				this.UpdatePerspectiveLabel();
				this.RepositionContentControls();
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error in OnLoad: " + ex.Message);
			}
		}

		// Token: 0x06001305 RID: 4869 RVA: 0x00090444 File Offset: 0x00090444
		private void Graph3DMainForm_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Control && e.KeyCode == Keys.E)
			{
				base.Close();
				return;
			}
			checked
			{
				if (e.KeyCode == Keys.Up && this.trackTheta != null && this.trackTheta.Value + 5 <= this.trackTheta.Maximum)
				{
					this.trackTheta.Value += 5;
					e.Handled = true;
					return;
				}
				if (e.KeyCode == Keys.Down && this.trackTheta != null && this.trackTheta.Value - 5 >= this.trackTheta.Minimum)
				{
					this.trackTheta.Value -= 5;
					e.Handled = true;
					return;
				}
				if (e.KeyCode == Keys.Left && this.trackPhi != null && this.trackPhi.Value - 5 >= this.trackPhi.Minimum)
				{
					this.trackPhi.Value -= 5;
					e.Handled = true;
					return;
				}
				if (e.KeyCode == Keys.Right && this.trackPhi != null && this.trackPhi.Value + 5 <= this.trackPhi.Maximum)
				{
					this.trackPhi.Value += 5;
					e.Handled = true;
					return;
				}
				if ((e.KeyCode == Keys.Add || e.KeyCode == Keys.Oemplus) && this.trackRho != null && this.trackRho.Value + 5 <= this.trackRho.Maximum)
				{
					this.trackRho.Value += 5;
					e.Handled = true;
					return;
				}
				if ((e.KeyCode == Keys.Subtract || e.KeyCode == Keys.OemMinus) && this.trackRho != null && this.trackRho.Value - 5 >= this.trackRho.Minimum)
				{
					this.trackRho.Value -= 5;
					e.Handled = true;
				}
			}
		}

		// Token: 0x06001307 RID: 4871 RVA: 0x00090680 File Offset: 0x00090680
		public void UpdateGraphValue(int x, int y, double value)
		{
			if (this.graph3D == null || this.graph3D.IsDisposed)
			{
				return;
			}
			try
			{
				this.graph3D.SetValueAt(x, y, value);
				this.graph3D.Invalidate();
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error update: " + ex.Message);
			}
		}

		// Token: 0x06001308 RID: 4872 RVA: 0x000906E8 File Offset: 0x000906E8
		public void BindToDataGridView(DataGridView grid)
		{
			if (this.graph3D == null || this.graph3D.IsDisposed || grid == null || grid.RowCount <= 0)
			{
				return;
			}
			checked
			{
				try
				{
					grid.SuspendLayout();
					int rowCount = grid.RowCount;
					int columnCount = grid.ColumnCount;
					Graph3D.cPoint3D[,] array = new Graph3D.cPoint3D[rowCount, columnCount];
					for (int i = 0; i < rowCount; i++)
					{
						for (int j = 0; j < columnCount; j++)
						{
							double z = 0.0;
							DataGridViewCell dataGridViewCell = grid[j, i];
							object obj = (dataGridViewCell != null) ? dataGridViewCell.Value : null;
							double num;
							if (obj != null && obj != DBNull.Value && double.TryParse(obj.ToString(), out num))
							{
								z = num;
							}
							array[i, j] = new Graph3D.cPoint3D((double)j, (double)i, z);
						}
					}
					if (this.graph3D.AxisX_Legend == null)
					{
						this.graph3D.AxisX_Legend = "Kolom";
					}
					if (this.graph3D.AxisY_Legend == null)
					{
						this.graph3D.AxisY_Legend = "Baris";
					}
					if (this.graph3D.AxisZ_Legend == null)
					{
						this.graph3D.AxisZ_Legend = "Nilai";
					}
					this.graph3D.SetSurfacePoints(array, Graph3D.eNormalize.Separate);
					if (this.lblInfo != null)
					{
						this.lblInfo.Text = string.Format("Points: {0}", rowCount * columnCount);
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine("Error BindGrid: " + ex.Message);
				}
				finally
				{
					grid.ResumeLayout(false);
				}
			}
		}

		// Token: 0x06001309 RID: 4873 RVA: 0x00090890 File Offset: 0x00090890
		public void HighlightPoint(int x, int y, double value)
		{
			if (this.graph3D == null || this.graph3D.IsDisposed)
			{
				return;
			}
			try
			{
				this.graph3D.SetValueAt(x, y, value);
				this.graph3D.SelectPoint(x, y);
				if (this.lblInfo != null)
				{
					this.lblInfo.Text = string.Format("Live Point : {0:F3}", value);
				}
				this.graph3D.Invalidate();
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error highlight: " + ex.Message);
			}
		}

		// Token: 0x0600130A RID: 4874 RVA: 0x00090928 File Offset: 0x00090928
		public void ClearHighlight()
		{
			if (this.graph3D == null || this.graph3D.IsDisposed)
			{
				return;
			}
			try
			{
				this.graph3D.ClearSelection();
				if (this.lblInfo != null)
				{
					this.lblInfo.Text = "Ready";
				}
				this.graph3D.Invalidate();
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error clear highlight: " + ex.Message);
			}
		}

		// Token: 0x0600130B RID: 4875 RVA: 0x000909A4 File Offset: 0x000909A4
		public void EnableLiveMode(bool enable)
		{
			if (this.graph3D == null || this.graph3D.IsDisposed)
			{
				return;
			}
			this.graph3D.EnableLiveMode(enable);
			if (enable)
			{
				if (this.lblInfo != null)
				{
					this.lblInfo.Text = "Live Mode: ON - Grafik terkunci";
				}
				if (this.dataSourceMenu != null)
				{
					this.dataSourceMenu.Enabled = false;
				}
				this.graph3D.SetLivePointer(0, 0);
				this.graph3D.Invalidate();
				return;
			}
			if (this.lblInfo != null)
			{
				this.lblInfo.Text = "Live Mode: OFF";
			}
			if (this.dataSourceMenu != null)
			{
				this.dataSourceMenu.Enabled = true;
			}
			this.graph3D.ClearLivePointer();
		}

		// Token: 0x0600130C RID: 4876 RVA: 0x0000C2D7 File Offset: 0x0000C2D7
		public bool IsLiveModeActive()
		{
			return this.graph3D != null && !this.graph3D.IsDisposed && this.graph3D.IsLiveModeActive();
		}

		// Token: 0x0600130D RID: 4877 RVA: 0x00090A54 File Offset: 0x00090A54
		public void UpdateLiveData(int x, int y, double value)
		{
			if (this.graph3D == null || this.graph3D.IsDisposed)
			{
				return;
			}
			try
			{
				if (double.IsNaN(value) || double.IsInfinity(value))
				{
					value = 0.0;
				}
				bool flag = true;
				if (this._isSelectionModeActive && !this._liveSelectionArea.IsEmpty)
				{
					flag = this._liveSelectionArea.Contains(x, y);
				}
				if (flag)
				{
					this.graph3D.UpdateLiveData(x, y, value);
					this.graph3D.SetLivePointer(x, y);
					if (this.lblInfo != null)
					{
						this.lblInfo.Text = string.Format("Live [{0},{1}] : {2:F3}", x, y, value);
					}
					this.graph3D.Invalidate();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error live data: " + ex.Message);
			}
		}

		// Token: 0x0600130E RID: 4878 RVA: 0x00090B3C File Offset: 0x00090B3C
		public void UpdateValueOnly(int x, int y, double value)
		{
			if (this.graph3D == null || this.graph3D.IsDisposed)
			{
				return;
			}
			try
			{
				if (double.IsNaN(value) || double.IsInfinity(value))
				{
					value = 0.0;
				}
				this.graph3D.UpdateValueOnly(x, y, value);
				if (this.lblInfo != null)
				{
					this.lblInfo.Text = string.Format("Live : {0:F3}", value);
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error update value: " + ex.Message);
			}
		}

		// Token: 0x0600130F RID: 4879 RVA: 0x00090BD8 File Offset: 0x00090BD8
		public void SetLivePointer(int x, int y)
		{
			if (this.graph3D == null || this.graph3D.IsDisposed)
			{
				return;
			}
			try
			{
				this.graph3D.SetLivePointer(x, y);
				this.graph3D.Invalidate();
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error set pointer: " + ex.Message);
			}
		}

		// Token: 0x06001310 RID: 4880 RVA: 0x00090C40 File Offset: 0x00090C40
		public void ClearLivePointer()
		{
			if (this.graph3D == null || this.graph3D.IsDisposed)
			{
				return;
			}
			try
			{
				this.graph3D.ClearLivePointer();
				if (this.lblInfo != null)
				{
					this.lblInfo.Text = "Ready";
				}
				this.graph3D.Invalidate();
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error clear pointer: " + ex.Message);
			}
		}

		// Token: 0x06001311 RID: 4881 RVA: 0x00090CBC File Offset: 0x00090CBC
		public void RebuildDrawObjects()
		{
			if (this.graph3D == null || this.graph3D.IsDisposed)
			{
				return;
			}
			try
			{
				this.graph3D.RebuildDrawObjects();
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error rebuild: " + ex.Message);
			}
		}

		// Token: 0x06001312 RID: 4882 RVA: 0x00090D18 File Offset: 0x00090D18
		public void SetLiveSelectionArea(Rectangle r)
		{
			this._liveSelectionArea = r;
			this._isSelectionModeActive = !r.IsEmpty;
			if (this.lblInfo != null)
			{
				this.lblInfo.Text = (this._isSelectionModeActive ? string.Format("Live Mode: ON - Area Terkunci [{0},{1} -> {2},{3}]", new object[]
				{
					r.X,
					r.Y,
					r.Right,
					r.Bottom
				}) : "Live Mode: ON - Full Range");
			}
			if (this.graph3D != null)
			{
				this.graph3D.Invalidate();
			}
		}

		// Token: 0x06001313 RID: 4883 RVA: 0x0000C2FB File Offset: 0x0000C2FB
		public void ClearLiveSelection()
		{
			this._liveSelectionArea = Rectangle.Empty;
			this._isSelectionModeActive = false;
			if (this.lblInfo != null)
			{
				this.lblInfo.Text = "Live Mode: ON - Full Range";
			}
			if (this.graph3D != null)
			{
				this.graph3D.Invalidate();
			}
		}

		// Token: 0x06001314 RID: 4884 RVA: 0x00090DC0 File Offset: 0x00090DC0
		private void UpdateMenuState()
		{
			if (this.wireFrameMenuItem != null)
			{
				this.wireFrameMenuItem.Checked = this._wireFrameEnabled;
			}
			if (this.autoRangeMenuItem != null)
			{
				this.autoRangeMenuItem.Checked = this._autoRangeEnabled;
			}
			if (this.heightColorMenuItem != null)
			{
				this.heightColorMenuItem.Checked = this._heightColorEnabled;
			}
			if (this.showAllPointsMenuItem != null)
			{
				this.showAllPointsMenuItem.Checked = this._showAllPointsEnabled;
			}
			if (this.showCompareBinsMenuItem != null)
			{
				this.showCompareBinsMenuItem.Checked = this._showCompareBinsEnabled;
			}
			if (this.dragGraphMenuItem != null)
			{
				this.dragGraphMenuItem.Checked = this._dragGraphEnabled;
			}
			if (this.rotateGraphMenuItem != null)
			{
				this.rotateGraphMenuItem.Checked = this._rotateGraphEnabled;
			}
			if (this.zoomGraphMenuItem != null)
			{
				this.zoomGraphMenuItem.Checked = this._zoomGraphEnabled;
			}
			if (this.autoRotateMenuItem != null)
			{
				this.autoRotateMenuItem.Checked = this._autoRotateEnabled;
			}
		}

		// Token: 0x06001315 RID: 4885 RVA: 0x00090EB0 File Offset: 0x00090EB0
		private void WireFrameMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				this._wireFrameEnabled = !this._wireFrameEnabled;
				if (this.wireFrameMenuItem != null)
				{
					this.wireFrameMenuItem.Checked = this._wireFrameEnabled;
				}
				if (this.graph3D != null)
				{
					this.graph3D.Raster = Graph3D.eRaster.Off;
					this.graph3D.PolygonLineColor = (this._wireFrameEnabled ? Color.Yellow : Color.FromArgb(45, 45, 48));
					PropertyInfo property = this.graph3D.GetType().GetProperty("ShowWireframe");
					if (property != null && property.CanWrite)
					{
						property.SetValue(this.graph3D, this._wireFrameEnabled);
					}
					this.graph3D.Invalidate();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error wireframe: " + ex.Message);
			}
		}

		// Token: 0x06001316 RID: 4886 RVA: 0x00090F94 File Offset: 0x00090F94
		private void AutoRangeMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				this._autoRangeEnabled = !this._autoRangeEnabled;
				if (this.autoRangeMenuItem != null)
				{
					this.autoRangeMenuItem.Checked = this._autoRangeEnabled;
				}
				if (this.graph3D != null)
				{
					PropertyInfo property = this.graph3D.GetType().GetProperty("AutoRange");
					if (property != null && property.CanWrite)
					{
						property.SetValue(this.graph3D, this._autoRangeEnabled);
					}
					else
					{
						this.graph3D.RebuildDrawObjects();
					}
					this.graph3D.Invalidate();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error auto-range: " + ex.Message);
			}
		}

		// Token: 0x06001317 RID: 4887 RVA: 0x00091054 File Offset: 0x00091054
		private void HeightColorMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				this._heightColorEnabled = !this._heightColorEnabled;
				if (this.heightColorMenuItem != null)
				{
					this.heightColorMenuItem.Checked = this._heightColorEnabled;
				}
				if (this.graph3D != null)
				{
					if (this._heightColorEnabled)
					{
						Color[] schema = ColorSchema.GetSchema(ColorSchema.eSchema.Graph4D);
						if (schema != null)
						{
							this.graph3D.SetColorScheme(schema, 3f);
						}
					}
					else
					{
						this.graph3D.SetColorScheme(new Color[]
						{
							Color.Gray
						}, 3f);
					}
					this.graph3D.Invalidate();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error height color: " + ex.Message);
			}
		}

		// Token: 0x06001318 RID: 4888 RVA: 0x00091110 File Offset: 0x00091110
		private void ShowAllPointsMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				this._showAllPointsEnabled = !this._showAllPointsEnabled;
				if (this.showAllPointsMenuItem != null)
				{
					this.showAllPointsMenuItem.Checked = this._showAllPointsEnabled;
				}
				if (this.graph3D != null)
				{
					PropertyInfo property = this.graph3D.GetType().GetProperty("ShowPoints");
					if (property != null && property.CanWrite)
					{
						property.SetValue(this.graph3D, this._showAllPointsEnabled);
					}
					this.graph3D.Invalidate();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error show points: " + ex.Message);
			}
		}

		// Token: 0x06001319 RID: 4889 RVA: 0x000911C0 File Offset: 0x000911C0
		private void ShowCompareBinsMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				this._showCompareBinsEnabled = !this._showCompareBinsEnabled;
				if (this.showCompareBinsMenuItem != null)
				{
					this.showCompareBinsMenuItem.Checked = this._showCompareBinsEnabled;
				}
				if (this.graph3D != null)
				{
					PropertyInfo propertyInfo = this.graph3D.GetType().GetProperty("ShowCompareBins") ?? this.graph3D.GetType().GetProperty("ShowBins");
					if (propertyInfo != null && propertyInfo.CanWrite)
					{
						propertyInfo.SetValue(this.graph3D, this._showCompareBinsEnabled);
					}
					this.graph3D.Invalidate();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error compare bins: " + ex.Message);
			}
		}

		// Token: 0x0600131A RID: 4890 RVA: 0x0009128C File Offset: 0x0009128C
		private void InitializeMenuItems()
		{
			checked
			{
				try
				{
					if (this.dataSourceMenu != null)
					{
						this.dataSourceMenu.DropDownItems.Clear();
						string[] array = new string[]
						{
							"Graph",
							"Formula",
							"Scatter"
						};
						for (int i = 0; i < array.Length; i++)
						{
							ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem(array[i])
							{
								Tag = i
							};
							toolStripMenuItem.Click += this.DataSourceMenuItem_Click;
							if (i == 0)
							{
								toolStripMenuItem.Checked = true;
							}
							this.dataSourceMenu.DropDownItems.Add(toolStripMenuItem);
						}
					}
					if (this.colorSchemeMenu != null)
					{
						this.colorSchemeMenu.DropDownItems.Clear();
						ToolStripMenuItem toolStripMenuItem2 = new ToolStripMenuItem("Graph 4D")
						{
							Tag = 0,
							Checked = true
						};
						toolStripMenuItem2.Click += this.ColorSchemeMenuItem_Click;
						this.colorSchemeMenu.DropDownItems.Add(toolStripMenuItem2);
						this._selectedColorIndex = 0;
					}
					this.InitializePerspectiveMenu();
					this.InitializeAutoRotateSpeedMenu();
					this.UpdateMenuState();
				}
				catch (Exception ex)
				{
					Console.WriteLine("Error initializing menu items: " + ex.Message);
				}
			}
		}

		// Token: 0x0600131B RID: 4891 RVA: 0x000913D0 File Offset: 0x000913D0
		private void DataSourceMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				ToolStripMenuItem toolStripMenuItem = sender as ToolStripMenuItem;
				if (toolStripMenuItem != null && this.dataSourceMenu != null && toolStripMenuItem.Tag != null)
				{
					foreach (object obj in this.dataSourceMenu.DropDownItems)
					{
						ToolStripMenuItem toolStripMenuItem2 = obj as ToolStripMenuItem;
						if (toolStripMenuItem2 != null)
						{
							toolStripMenuItem2.Checked = false;
						}
					}
					toolStripMenuItem.Checked = true;
					int num = Convert.ToInt32(toolStripMenuItem.Tag);
					if (this.graph3D != null)
					{
						if (num == 1)
						{
							this.SetFormula();
						}
						else if (num == 2)
						{
							this.SetScatterPlot(false);
						}
						if (this.lblInfo != null)
						{
							this.lblInfo.Text = "Points: " + this.graph3D.TotalPoints;
						}
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error datasource: " + ex.Message);
			}
		}

		// Token: 0x0600131C RID: 4892 RVA: 0x000914E0 File Offset: 0x000914E0
		private void SetFormula()
		{
			try
			{
				if (this.graph3D != null && !this.graph3D.IsDisposed)
				{
					Graph3D.delRendererFunction f_Function = (double x, double y) => 12.0 * Math.Sin(x) * Math.Cos(y) / (Math.Sqrt(Math.Sqrt(x * x + y * y)) + 0.2);
					this.graph3D.SetFunction(f_Function, new PointF(-10f, -10f), new PointF(10f, 10f), 0.5, Graph3D.eNormalize.MaintainXYZ);
					if (this.lblInfo != null)
					{
						this.lblInfo.Text = "Points: " + this.graph3D.TotalPoints;
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error SetFormula: " + ex.Message);
			}
		}

		// Token: 0x0600131D RID: 4893 RVA: 0x000915B4 File Offset: 0x000915B4
		private void SetScatterPlot(bool bLines)
		{
			try
			{
				if (this.graph3D != null && !this.graph3D.IsDisposed)
				{
					List<Graph3D.cScatter> list = new List<Graph3D.cScatter>();
					for (double num = -22.0; num < 22.0; num += 0.1)
					{
						double x = Math.Sin(num) * num;
						double y = Math.Cos(num) * num;
						double z = (num > 0.0) ? (num / 3.0) : num;
						list.Add(new Graph3D.cScatter(x, y, z, null));
					}
					if (bLines)
					{
						this.graph3D.SetScatterLines(list.ToArray(), Graph3D.eNormalize.Separate, 3f);
					}
					else
					{
						this.graph3D.SetScatterPoints(list.ToArray(), Graph3D.eNormalize.Separate);
					}
					if (this.lblInfo != null)
					{
						this.lblInfo.Text = "Points: " + this.graph3D.TotalPoints;
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error Scatter: " + ex.Message);
			}
		}

		// Token: 0x0600131E RID: 4894 RVA: 0x000916CC File Offset: 0x000916CC
		private void ColorSchemeMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				ToolStripMenuItem toolStripMenuItem = sender as ToolStripMenuItem;
				if (toolStripMenuItem != null && this.colorSchemeMenu != null)
				{
					foreach (object obj in this.colorSchemeMenu.DropDownItems)
					{
						ToolStripMenuItem toolStripMenuItem2 = obj as ToolStripMenuItem;
						if (toolStripMenuItem2 != null)
						{
							toolStripMenuItem2.Checked = false;
						}
					}
					toolStripMenuItem.Checked = true;
					this._selectedColorIndex = 0;
					if (this.graph3D != null && this._heightColorEnabled)
					{
						Color[] schema = ColorSchema.GetSchema(ColorSchema.eSchema.Graph4D);
						this.graph3D.PolygonLineColor = Color.Empty;
						if (schema != null)
						{
							this.graph3D.SetColorScheme(schema, 3f);
						}
						this.graph3D.Invalidate();
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error color: " + ex.Message);
			}
		}

		// Token: 0x0600131F RID: 4895 RVA: 0x000917C8 File Offset: 0x000917C8
		private void InitializePerspectiveMenu()
		{
			try
			{
				if (this.perspectiveMenu != null)
				{
					this.perspectiveMenu.DropDownItems.Clear();
					ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("Zoom");
					toolStripMenuItem.DropDownItems.Add(this.CreateSliderControl("Zoom", this.trackRho));
					this.perspectiveMenu.DropDownItems.Add(toolStripMenuItem);
					ToolStripMenuItem toolStripMenuItem2 = new ToolStripMenuItem("UP");
					toolStripMenuItem2.DropDownItems.Add(this.CreateSliderControl("UP", this.trackTheta));
					this.perspectiveMenu.DropDownItems.Add(toolStripMenuItem2);
					ToolStripMenuItem toolStripMenuItem3 = new ToolStripMenuItem("L-R");
					toolStripMenuItem3.DropDownItems.Add(this.CreateSliderControl("L-R", this.trackPhi));
					this.perspectiveMenu.DropDownItems.Add(toolStripMenuItem3);
					ToolStripMenuItem toolStripMenuItem4 = new ToolStripMenuItem("Reset All to Middle");
					toolStripMenuItem4.Click += this.ResetAllMenuItem_Click;
					this.perspectiveMenu.DropDownItems.Add(toolStripMenuItem4);
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error init perspective: " + ex.Message);
			}
		}

		// Token: 0x06001320 RID: 4896 RVA: 0x000918FC File Offset: 0x000918FC
		private void UpdatePerspectiveLabel()
		{
			try
			{
				if (this.lblPerspective != null && this.trackRho != null && this.trackTheta != null && this.trackPhi != null)
				{
					this.lblPerspective.Text = string.Format("Zoom: {0}  UP: {1}  L-R: {2}", this.trackRho.Value, this.trackTheta.Value, this.trackPhi.Value);
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error UpdatePerspectiveLabel: " + ex.Message);
			}
		}

		// Token: 0x06001321 RID: 4897 RVA: 0x00091998 File Offset: 0x00091998
		private void ResetPerspective_Click(object sender, EventArgs e)
		{
			try
			{
				if (this._autoRotateEnabled)
				{
					this._autoRotateEnabled = false;
					if (this._autoRotateTimer != null)
					{
						this._autoRotateTimer.Stop();
					}
					if (this.autoRotateMenuItem != null)
					{
						this.autoRotateMenuItem.Checked = false;
					}
				}
				if (this.trackRho != null)
				{
					this.trackRho.Value = 50;
				}
				if (this.trackTheta != null)
				{
					this.trackTheta.Value = 50;
				}
				if (this.trackPhi != null)
				{
					this.trackPhi.Value = 180;
				}
				if (this.graph3D != null)
				{
					this.graph3D.SetCoefficients(1350.0, 70.0, 230.0);
					this.graph3D.Invalidate();
				}
				this.UpdatePerspectiveLabel();
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error reset perspective: " + ex.Message);
			}
		}

		// Token: 0x06001322 RID: 4898 RVA: 0x00091A88 File Offset: 0x00091A88
		private void ResetAllMenuItem_Click(object sender, EventArgs e)
		{
			checked
			{
				try
				{
					if (this._autoRotateEnabled)
					{
						this._autoRotateEnabled = false;
						if (this._autoRotateTimer != null)
						{
							this._autoRotateTimer.Stop();
						}
						if (this.autoRotateMenuItem != null)
						{
							this.autoRotateMenuItem.Checked = false;
						}
					}
					if (this.trackRho != null)
					{
						this.trackRho.Value = this.trackRho.Minimum + (this.trackRho.Maximum - this.trackRho.Minimum) / 2;
					}
					if (this.trackTheta != null)
					{
						this.trackTheta.Value = this.trackTheta.Minimum + (this.trackTheta.Maximum - this.trackTheta.Minimum) / 2;
					}
					if (this.trackPhi != null)
					{
						this.trackPhi.Value = this.trackPhi.Minimum + (this.trackPhi.Maximum - this.trackPhi.Minimum) / 2;
					}
					if (this.graph3D != null)
					{
						this.graph3D.SetCoefficients(1350.0, 70.0, 230.0);
						this.graph3D.Invalidate();
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine("Error reset all: " + ex.Message);
				}
			}
		}

		// Token: 0x06001323 RID: 4899 RVA: 0x00091BE4 File Offset: 0x00091BE4
		private void SaveScreenshot_Click(object sender, EventArgs e)
		{
			if (this.graph3D == null || this.graph3D.IsDisposed)
			{
				return;
			}
			using (SaveFileDialog saveFileDialog = new SaveFileDialog())
			{
				saveFileDialog.Title = "Save as PNG image";
				saveFileDialog.Filter = "PNG Image|*.png";
				saveFileDialog.DefaultExt = ".png";
				if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
				{
					try
					{
						this.graph3D.GetScreenshot().Save(saveFileDialog.FileName, ImageFormat.Png);
					}
					catch (Exception ex)
					{
						MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
			}
		}

		// Token: 0x06001324 RID: 4900 RVA: 0x00091C94 File Offset: 0x00091C94
		private void InitializeTrackBars()
		{
			try
			{
				if (this.trackRho != null)
				{
					this.trackRho.Minimum = 10;
					this.trackRho.Maximum = 1000;
					this.trackRho.Value = 50;
					this.trackRho.TickFrequency = 10;
					this.trackRho.TickStyle = TickStyle.None;
				}
				if (this.trackTheta != null)
				{
					this.trackTheta.Minimum = 10;
					this.trackTheta.Maximum = 90;
					this.trackTheta.Value = 50;
					this.trackTheta.TickFrequency = 10;
					this.trackTheta.TickStyle = TickStyle.None;
				}
				if (this.trackPhi != null)
				{
					this.trackPhi.Minimum = 0;
					this.trackPhi.Maximum = 360;
					this.trackPhi.Value = 180;
					this.trackPhi.TickFrequency = 30;
					this.trackPhi.TickStyle = TickStyle.None;
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error init trackbars: " + ex.Message);
			}
		}

		// Token: 0x06001325 RID: 4901 RVA: 0x00091DAC File Offset: 0x00091DAC
		private ToolStripControlHost CreateSliderControl(string name, TrackBar tb)
		{
			if (tb == null)
			{
				return null;
			}
			tb.Width = 150;
			tb.Height = 45;
			tb.TickFrequency = Math.Max(1, checked(tb.Maximum - tb.Minimum) / 10);
			tb.TickStyle = TickStyle.BottomRight;
			tb.BackColor = Color.FromArgb(45, 45, 48);
			tb.ForeColor = Color.White;
			Label valueLabel = new Label
			{
				Text = tb.Value.ToString(),
				ForeColor = Color.White,
				BackColor = Color.Transparent,
				AutoSize = true,
				Location = new Point(160, 12)
			};
			Panel panel = new Panel();
			panel.Width = 200;
			panel.Height = 45;
			panel.BackColor = Color.FromArgb(45, 45, 48);
			tb.Location = new Point(5, 5);
			panel.Controls.Add(tb);
			panel.Controls.Add(valueLabel);
			tb.ValueChanged += delegate(object <p0>, EventArgs <p1>)
			{
				valueLabel.Text = tb.Value.ToString();
				this.UpdatePerspectiveLabel();
				if (this.graph3D != null && !this.graph3D.IsDisposed)
				{
					this.graph3D.Invalidate();
					this.graph3D.Refresh();
				}
			};
			return new ToolStripControlHost(panel)
			{
				AutoSize = false,
				Width = 200,
				Height = 45
			};
		}

		// Token: 0x06001326 RID: 4902 RVA: 0x00091F38 File Offset: 0x00091F38
		private void UpdateGraphInteraction()
		{
			if (this.graph3D == null || this.graph3D.IsDisposed)
			{
				return;
			}
			try
			{
				Type type = this.graph3D.GetType();
				PropertyInfo property = type.GetProperty("AllowDrag");
				if (property != null && property.CanWrite)
				{
					property.SetValue(this.graph3D, this._dragGraphEnabled);
				}
				PropertyInfo property2 = type.GetProperty("AllowRotate");
				if (property2 != null && property2.CanWrite)
				{
					property2.SetValue(this.graph3D, this._rotateGraphEnabled);
				}
				PropertyInfo property3 = type.GetProperty("AllowZoom");
				if (property3 != null && property3.CanWrite)
				{
					property3.SetValue(this.graph3D, this._zoomGraphEnabled);
				}
				this.graph3D.Cursor = ((!this._dragGraphEnabled && !this._rotateGraphEnabled && !this._zoomGraphEnabled) ? Cursors.Default : Cursors.Hand);
				if (this.lblInfo != null)
				{
					string text = "Interactions: ";
					text += (this._dragGraphEnabled ? "[Drag] " : "");
					text += (this._rotateGraphEnabled ? "[Rotate] " : "");
					text += (this._zoomGraphEnabled ? "[Zoom]" : "");
					if (!this._dragGraphEnabled && !this._rotateGraphEnabled && !this._zoomGraphEnabled)
					{
						text = "All interactions disabled";
					}
					this.lblInfo.Text = text;
				}
				this.graph3D.Invalidate();
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error update interaction: " + ex.Message);
			}
		}

		// Token: 0x06001327 RID: 4903 RVA: 0x0000C33A File Offset: 0x0000C33A
		private void DragGraphMenuItem_Click(object sender, EventArgs e)
		{
			this._dragGraphEnabled = !this._dragGraphEnabled;
			if (this.dragGraphMenuItem != null)
			{
				this.dragGraphMenuItem.Checked = this._dragGraphEnabled;
			}
			this.UpdateGraphInteraction();
		}

		// Token: 0x06001328 RID: 4904 RVA: 0x0000C36A File Offset: 0x0000C36A
		private void RotateGraphMenuItem_Click(object sender, EventArgs e)
		{
			this._rotateGraphEnabled = !this._rotateGraphEnabled;
			if (this.rotateGraphMenuItem != null)
			{
				this.rotateGraphMenuItem.Checked = this._rotateGraphEnabled;
			}
			this.UpdateGraphInteraction();
		}

		// Token: 0x06001329 RID: 4905 RVA: 0x0000C39A File Offset: 0x0000C39A
		private void ZoomGraphMenuItem_Click(object sender, EventArgs e)
		{
			this._zoomGraphEnabled = !this._zoomGraphEnabled;
			if (this.zoomGraphMenuItem != null)
			{
				this.zoomGraphMenuItem.Checked = this._zoomGraphEnabled;
			}
			this.UpdateGraphInteraction();
		}

		// Token: 0x0600132A RID: 4906 RVA: 0x00092100 File Offset: 0x00092100
		private void ApplyDefaultColorScheme()
		{
			try
			{
				if (this.graph3D != null && !this.graph3D.IsDisposed)
				{
					this._heightColorEnabled = true;
					this._selectedColorIndex = 0;
					this._wireFrameEnabled = false;
					this._showAllPointsEnabled = false;
					Color[] schema = ColorSchema.GetSchema(ColorSchema.eSchema.Graph4D);
					if (schema != null)
					{
						this.graph3D.PolygonLineColor = Color.Empty;
						this.graph3D.SetColorScheme(schema, 3f);
					}
					this.graph3D.Raster = Graph3D.eRaster.Off;
					PropertyInfo property = this.graph3D.GetType().GetProperty("ShowWireframe");
					if (property != null && property.CanWrite)
					{
						property.SetValue(this.graph3D, false);
					}
					PropertyInfo property2 = this.graph3D.GetType().GetProperty("ShowPoints");
					if (property2 != null && property2.CanWrite)
					{
						property2.SetValue(this.graph3D, false);
					}
					this.graph3D.Invalidate();
					this.graph3D.Refresh();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error ApplyDefaultColorScheme: " + ex.Message);
			}
		}

		// Token: 0x0600132B RID: 4907 RVA: 0x00092230 File Offset: 0x00092230
		private void InitializeAutoRotateSpeedMenu()
		{
			checked
			{
				try
				{
					if (this.autoRotateSpeedMenuItem != null)
					{
						this.autoRotateSpeedMenuItem.DropDownItems.Clear();
						int[] array = new int[]
						{
							1,
							2,
							4,
							6,
							10
						};
						string[] array2 = new string[]
						{
							"Slow",
							"Normal",
							"Fast",
							"Faster",
							"Very Fast"
						};
						for (int i = 0; i < array.Length; i++)
						{
							ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem(array2[i])
							{
								Tag = array[i],
								Checked = (array[i] == this._autoRotateSpeed)
							};
							toolStripMenuItem.Click += this.AutoRotateSpeedMenuItem_Click;
							this.autoRotateSpeedMenuItem.DropDownItems.Add(toolStripMenuItem);
						}
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine("Error init autorotate speed: " + ex.Message);
				}
			}
		}

		// Token: 0x0600132C RID: 4908 RVA: 0x00092320 File Offset: 0x00092320
		private void InitializeAutoRotateTimer()
		{
			try
			{
				if (this._autoRotateTimer != null)
				{
					this._autoRotateTimer.Stop();
					this._autoRotateTimer.Tick -= this.AutoRotateTimer_Tick;
					this._autoRotateTimer.Dispose();
					this._autoRotateTimer = null;
				}
				this._autoRotateTimer = new Timer
				{
					Interval = 50
				};
				this._autoRotateTimer.Tick += this.AutoRotateTimer_Tick;
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error init autorotate timer: " + ex.Message);
			}
		}

		// Token: 0x0600132D RID: 4909 RVA: 0x000923C0 File Offset: 0x000923C0
		private void AutoRotateTimer_Tick(object sender, EventArgs e)
		{
			try
			{
				if (this._autoRotateEnabled && this.graph3D != null && !this.graph3D.IsDisposed && this.trackPhi != null)
				{
					int num = checked(this.trackPhi.Value + Math.Max(1, this._autoRotateSpeed));
					if (num > this.trackPhi.Maximum)
					{
						num = this.trackPhi.Minimum;
					}
					this.trackPhi.Value = num;
					MethodInfo method = this.graph3D.GetType().GetMethod("OnTrackbarScroll", BindingFlags.Instance | BindingFlags.NonPublic);
					if (method != null)
					{
						method.Invoke(this.graph3D, new object[]
						{
							this.trackPhi,
							EventArgs.Empty
						});
					}
					else
					{
						this.graph3D.Invalidate();
					}
					this.UpdatePerspectiveLabel();
				}
			}
			catch (TargetInvocationException ex)
			{
				Console.WriteLine("Error AutoRotateTimer_Tick: " + ((ex.InnerException != null) ? ex.InnerException.Message : ex.Message));
			}
			catch (ObjectDisposedException)
			{
				if (this._autoRotateTimer != null)
				{
					this._autoRotateTimer.Stop();
				}
			}
			catch (Exception ex2)
			{
				Console.WriteLine("Error AutoRotateTimer_Tick: " + ex2.Message);
			}
		}

		// Token: 0x0600132E RID: 4910 RVA: 0x0009251C File Offset: 0x0009251C
		private void AutoRotateMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				this._autoRotateEnabled = !this._autoRotateEnabled;
				if (this.autoRotateMenuItem != null)
				{
					this.autoRotateMenuItem.Checked = this._autoRotateEnabled;
				}
				if (this._autoRotateEnabled)
				{
					if (this._autoRotateTimer == null)
					{
						this.InitializeAutoRotateTimer();
					}
					if (this._autoRotateTimer != null)
					{
						this._autoRotateTimer.Start();
					}
					if (this.lblInfo != null)
					{
						this.lblInfo.Text = "Auto Rotation: ON";
					}
					this.AutoRotateTimer_Tick(null, EventArgs.Empty);
				}
				else
				{
					if (this._autoRotateTimer != null)
					{
						this._autoRotateTimer.Stop();
					}
					if (this.lblInfo != null)
					{
						this.lblInfo.Text = "Auto Rotation: OFF";
					}
					if (this.graph3D != null && !this.graph3D.IsDisposed)
					{
						this.graph3D.Invalidate();
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error autorotate click: " + ex.Message);
			}
		}

		// Token: 0x0600132F RID: 4911 RVA: 0x00092618 File Offset: 0x00092618
		private void AutoRotateSpeedMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				ToolStripMenuItem toolStripMenuItem = sender as ToolStripMenuItem;
				if (toolStripMenuItem != null && toolStripMenuItem.Tag != null && this.autoRotateSpeedMenuItem != null)
				{
					foreach (object obj in this.autoRotateSpeedMenuItem.DropDownItems)
					{
						ToolStripMenuItem toolStripMenuItem2 = obj as ToolStripMenuItem;
						if (toolStripMenuItem2 != null)
						{
							toolStripMenuItem2.Checked = false;
						}
					}
					toolStripMenuItem.Checked = true;
					this._autoRotateSpeed = Math.Max(1, Convert.ToInt32(toolStripMenuItem.Tag));
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error autorotate speed: " + ex.Message);
			}
		}

		// Token: 0x06001330 RID: 4912
		[DllImport("user32.dll")]
		private static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x06001331 RID: 4913
		[DllImport("user32.dll")]
		private static extern bool ReleaseCapture();

		// Token: 0x06001332 RID: 4914 RVA: 0x000926DC File Offset: 0x000926DC
		private void InitRoundedNeonBorder()
		{
			if (this._neonBorderInitialized)
			{
				return;
			}
			this._neonBorderInitialized = true;
			base.FormBorderStyle = FormBorderStyle.None;
			base.Padding = new Padding(6);
			this.BackColor = Graph3DMainForm.BgDark;
			this.DoubleBuffered = true;
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.UpdateStyles();
			this.BuildCustomTitleBar();
			this.RepositionContentControls();
			base.HandleCreated += delegate(object s, EventArgs e)
			{
				this.ApplyRoundedRegion();
			};
			base.Resize += delegate(object s, EventArgs e)
			{
				this.ApplyRoundedRegion();
				this.RepositionContentControls();
			};
			if (base.IsHandleCreated)
			{
				this.ApplyRoundedRegion();
			}
		}

		// Token: 0x06001333 RID: 4915 RVA: 0x00092770 File Offset: 0x00092770
		private void BuildCustomTitleBar()
		{
			this._customTitleBar = new Panel
			{
				Dock = DockStyle.Top,
				Height = 36,
				BackColor = Graph3DMainForm.BgPanel,
				Padding = new Padding(10, 0, 10, 0)
			};
			this._customTitleIcon = new Label
			{
				Text = "\ud83d\udcca",
				Font = new Font("Segoe UI", 12f),
				ForeColor = Graph3DMainForm.NeonCyan,
				Location = new Point(10, 8),
				AutoSize = true,
				BackColor = Color.Transparent
			};
			this._customTitleLabel = new Label
			{
				Text = "GRAPH 3D — LIVE DATA VIEWER",
				Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
				ForeColor = Graph3DMainForm.NeonCyan,
				Location = new Point(34, 10),
				AutoSize = true,
				BackColor = Color.Transparent,
				Cursor = Cursors.SizeAll
			};
			if (this.menuStrip != null)
			{
				if (base.Controls.Contains(this.menuStrip))
				{
					base.Controls.Remove(this.menuStrip);
				}
				this.menuStrip.Dock = DockStyle.None;
				this.menuStrip.BackColor = Graph3DMainForm.BgPanel;
				this.menuStrip.ForeColor = Graph3DMainForm.FgText;
				this.menuStrip.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
				this.menuStrip.RenderMode = ToolStripRenderMode.Professional;
				this.menuStrip.GripStyle = ToolStripGripStyle.Hidden;
				this.menuStrip.Padding = new Padding(0);
				this.menuStrip.AutoSize = true;
				this.menuStrip.Location = new Point(280, 6);
				this.menuStrip.Visible = true;
				this.menuStrip.Renderer = new Graph3DMainForm.NeonMenuRenderer();
				this._customTitleBar.Controls.Add(this.menuStrip);
			}
			this._customBtnClose = this.MakeNeonButton("✕", Graph3DMainForm.NeonRed);
			this._customBtnMaximize = this.MakeNeonButton("⛶", Graph3DMainForm.NeonCyan);
			this._customBtnMinimize = this.MakeNeonButton("—", Graph3DMainForm.FgText);
			this._customBtnClose.Click += delegate(object s, EventArgs e)
			{
				base.Close();
			};
			this._customBtnMaximize.Click += delegate(object s, EventArgs e)
			{
				this.ToggleMaximize();
			};
			this._customBtnMinimize.Click += delegate(object s, EventArgs e)
			{
				base.WindowState = FormWindowState.Minimized;
			};
			this._customTitleBar.Controls.Add(this._customTitleIcon);
			this._customTitleBar.Controls.Add(this._customTitleLabel);
			this._customTitleBar.Controls.Add(this._customBtnClose);
			this._customTitleBar.Controls.Add(this._customBtnMaximize);
			this._customTitleBar.Controls.Add(this._customBtnMinimize);
			this._customTitleBar.Resize += checked(delegate(object s, EventArgs e)
			{
				this._customBtnClose.Location = new Point(this._customTitleBar.Width - 40, 6);
				this._customBtnMaximize.Location = new Point(this._customTitleBar.Width - 78, 6);
				this._customBtnMinimize.Location = new Point(this._customTitleBar.Width - 116, 6);
			});
			MouseEventHandler value = delegate(object s, MouseEventArgs e)
			{
				if (e.Button == MouseButtons.Left)
				{
					if (this._isCustomMaximized)
					{
						this.ToggleMaximize();
					}
					Graph3DMainForm.ReleaseCapture();
					Graph3DMainForm.SendMessage(base.Handle, 161, 2, 0);
				}
			};
			this._customTitleBar.MouseDown += value;
			this._customTitleLabel.MouseDown += value;
			this._customTitleIcon.MouseDown += value;
			EventHandler value2 = delegate(object s, EventArgs e)
			{
				this.ToggleMaximize();
			};
			this._customTitleBar.DoubleClick += value2;
			this._customTitleLabel.DoubleClick += value2;
			this._customTitleIcon.DoubleClick += value2;
			base.Controls.Add(this._customTitleBar);
			this._customTitleBar.BringToFront();
		}

		// Token: 0x06001334 RID: 4916 RVA: 0x00092AEC File Offset: 0x00092AEC
		private Button MakeNeonButton(string text, Color accent)
		{
			Button b = new Button
			{
				Text = text,
				Size = new Size(32, 28),
				Location = new Point(0, 6),
				FlatStyle = FlatStyle.Flat,
				BackColor = Graph3DMainForm.BgCard,
				ForeColor = accent,
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				Cursor = Cursors.Hand,
				TabStop = false,
				UseVisualStyleBackColor = false
			};
			b.FlatAppearance.BorderSize = 0;
			b.FlatAppearance.MouseOverBackColor = Color.Transparent;
			b.FlatAppearance.MouseDownBackColor = Color.Transparent;
			b.Paint += delegate(object s, PaintEventArgs ev)
			{
				Button button = (Button)s;
				ev.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				using (GraphicsPath graphicsPath = Graph3DMainForm.CreateRoundedPath(checked(new Rectangle(0, 0, button.Width - 1, button.Height - 1)), 8))
				{
					using (SolidBrush solidBrush = new SolidBrush(button.BackColor))
					{
						ev.Graphics.FillPath(solidBrush, graphicsPath);
					}
					using (Pen pen = new Pen(button.ForeColor, 1.4f))
					{
						ev.Graphics.DrawPath(pen, graphicsPath);
					}
				}
				TextRenderer.DrawText(ev.Graphics, button.Text, button.Font, button.ClientRectangle, button.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			};
			b.MouseEnter += delegate(object s, EventArgs e)
			{
				b.BackColor = Color.FromArgb(30, 42, 52);
				b.Invalidate();
			};
			b.MouseLeave += delegate(object s, EventArgs e)
			{
				b.BackColor = Graph3DMainForm.BgCard;
				b.Invalidate();
			};
			return b;
		}

		// Token: 0x06001335 RID: 4917 RVA: 0x00092C10 File Offset: 0x00092C10
		private void ToggleMaximize()
		{
			if (!this._isCustomMaximized)
			{
				this._restoreBounds = base.Bounds;
				this._isCustomMaximized = true;
				Screen screen = Screen.FromControl(this);
				base.Bounds = screen.WorkingArea;
				this._customBtnMaximize.Text = "❐";
			}
			else
			{
				this._isCustomMaximized = false;
				base.Bounds = this._restoreBounds;
				this._customBtnMaximize.Text = "⛶";
			}
			this._customBtnMaximize.Invalidate();
			this.ApplyRoundedRegion();
			this.RepositionContentControls();
		}

		// Token: 0x06001336 RID: 4918 RVA: 0x0008EF50 File Offset: 0x0008EF50
		private static GraphicsPath CreateRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			if (rect.Width <= 0 || rect.Height <= 0)
			{
				return graphicsPath;
			}
			checked
			{
				int num = radius * 2;
				if (num > rect.Width)
				{
					num = rect.Width;
				}
				if (num > rect.Height)
				{
					num = rect.Height;
				}
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x06001337 RID: 4919 RVA: 0x00092C98 File Offset: 0x00092C98
		private void ApplyRoundedRegion()
		{
			if (base.Width <= 0 || base.Height <= 0)
			{
				return;
			}
			try
			{
				using (GraphicsPath graphicsPath = Graph3DMainForm.CreateRoundedPath(new Rectangle(0, 0, base.Width, base.Height), 14))
				{
					Region region = base.Region;
					base.Region = new Region(graphicsPath);
					if (region != null)
					{
						region.Dispose();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06001338 RID: 4920 RVA: 0x00092D20 File Offset: 0x00092D20
		private void RepositionContentControls()
		{
			if (!this._neonBorderInitialized)
			{
				return;
			}
			int num = 42;
			int num2 = 6;
			checked
			{
				int num3 = base.ClientSize.Width - 12;
				int num4 = base.ClientSize.Height - num - 6;
				if (num3 < 20 || num4 < 20)
				{
					return;
				}
				if (this.graph3D != null && !this.graph3D.IsDisposed)
				{
					this.graph3D.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
					this.graph3D.Location = new Point(num2, num);
					this.graph3D.Size = new Size(num3, num4 - 45);
				}
				if (this.lblPerspective != null && !this.lblPerspective.IsDisposed)
				{
					this.lblPerspective.Location = new Point(num2 + 6, num + num4 - 40);
					this.lblPerspective.BringToFront();
				}
				if (this.lblInfo != null && !this.lblInfo.IsDisposed)
				{
					this.lblInfo.Location = new Point(num2 + 6, num + num4 - 22);
					this.lblInfo.BringToFront();
				}
				if (this.label1 != null && !this.label1.IsDisposed)
				{
					this.label1.Visible = false;
				}
				if (this.menuStrip != null && this._customTitleBar != null)
				{
					int num5 = Math.Min(280, this._customTitleBar.Width - 320);
					if (num5 < 100)
					{
						num5 = 100;
					}
					this.menuStrip.Location = new Point(num5, 6);
				}
			}
		}

		// Token: 0x06001339 RID: 4921 RVA: 0x00092E94 File Offset: 0x00092E94
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			if (base.Width < 5 || base.Height < 5)
			{
				return;
			}
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			using (GraphicsPath graphicsPath = Graph3DMainForm.CreateRoundedPath(checked(new Rectangle(2, 2, base.Width - 5, base.Height - 5)), 14))
			{
				using (Pen pen = new Pen(Color.FromArgb(25, 0, 255, 230), 8f))
				{
					using (Pen pen2 = new Pen(Color.FromArgb(60, 0, 255, 230), 5f))
					{
						using (Pen pen3 = new Pen(Color.FromArgb(120, 0, 255, 230), 2f))
						{
							using (Pen pen4 = new Pen(Graph3DMainForm.NeonCyan, 1.2f))
							{
								graphics.DrawPath(pen, graphicsPath);
								graphics.DrawPath(pen2, graphicsPath);
								graphics.DrawPath(pen3, graphicsPath);
								graphics.DrawPath(pen4, graphicsPath);
							}
						}
					}
				}
			}
		}

		// Token: 0x04001A3B RID: 6715
		private bool _wireFrameEnabled;

		// Token: 0x04001A3C RID: 6716
		private bool _autoRangeEnabled;

		// Token: 0x04001A3D RID: 6717
		private bool _heightColorEnabled;

		// Token: 0x04001A3E RID: 6718
		private bool _showAllPointsEnabled;

		// Token: 0x04001A3F RID: 6719
		private bool _showCompareBinsEnabled;

		// Token: 0x04001A40 RID: 6720
		private bool _dragGraphEnabled;

		// Token: 0x04001A41 RID: 6721
		private bool _rotateGraphEnabled;

		// Token: 0x04001A42 RID: 6722
		private bool _zoomGraphEnabled;

		// Token: 0x04001A43 RID: 6723
		private bool _autoRotateEnabled;

		// Token: 0x04001A44 RID: 6724
		private int _autoRotateSpeed;

		// Token: 0x04001A45 RID: 6725
		private int _selectedColorIndex;

		// Token: 0x04001A46 RID: 6726
		private bool _isDragging;

		// Token: 0x04001A47 RID: 6727
		private Point _lastMousePos;

		// Token: 0x04001A4C RID: 6732
		private Graph3D graphControl;

		// Token: 0x04001A54 RID: 6740
		private ToolStripSeparator separator1;

		// Token: 0x04001A5F RID: 6751
		private ToolStripSeparator separator2;

		// Token: 0x04001A65 RID: 6757
		private Rectangle _liveSelectionArea;

		// Token: 0x04001A66 RID: 6758
		private bool _isSelectionModeActive;

		// Token: 0x04001A6B RID: 6763
		private const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x04001A6C RID: 6764
		private const int HT_CAPTION = 2;

		// Token: 0x04001A6D RID: 6765
		private const int CORNER_RADIUS = 14;

		// Token: 0x04001A6E RID: 6766
		private const int CUSTOM_TITLE_HEIGHT = 36;

		// Token: 0x04001A6F RID: 6767
		private static readonly Color NeonCyan = Color.FromArgb(0, 255, 230);

		// Token: 0x04001A70 RID: 6768
		private static readonly Color NeonRed = Color.FromArgb(255, 90, 105);

		// Token: 0x04001A71 RID: 6769
		private static readonly Color BgPanel = Color.FromArgb(16, 23, 30);

		// Token: 0x04001A72 RID: 6770
		private static readonly Color BgCard = Color.FromArgb(20, 28, 36);

		// Token: 0x04001A73 RID: 6771
		private static readonly Color FgText = Color.FromArgb(225, 238, 245);

		// Token: 0x04001A74 RID: 6772
		private static readonly Color BgDark = Color.FromArgb(10, 15, 20);

		// Token: 0x04001A75 RID: 6773
		private Panel _customTitleBar;

		// Token: 0x04001A76 RID: 6774
		private Label _customTitleLabel;

		// Token: 0x04001A77 RID: 6775
		private Label _customTitleIcon;

		// Token: 0x04001A78 RID: 6776
		private Button _customBtnClose;

		// Token: 0x04001A79 RID: 6777
		private Button _customBtnMaximize;

		// Token: 0x04001A7A RID: 6778
		private Button _customBtnMinimize;

		// Token: 0x04001A7B RID: 6779
		private Rectangle _restoreBounds;

		// Token: 0x04001A7C RID: 6780
		private bool _isCustomMaximized;

		// Token: 0x04001A7D RID: 6781
		private bool _neonBorderInitialized;

		// Token: 0x020007DD RID: 2013
		private sealed class NeonMenuRenderer : ToolStripProfessionalRenderer
		{
			// Token: 0x0600135B RID: 4955 RVA: 0x0000C4D5 File Offset: 0x0000C4D5
			public NeonMenuRenderer() : base(new Graph3DMainForm.NeonMenuRenderer.NeonColorTable())
			{
			}

			// Token: 0x0600135C RID: 4956 RVA: 0x00093368 File Offset: 0x00093368
			protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
			{
				checked
				{
					if (e.Item.Selected && e.Item.Enabled)
					{
						using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(40, Graph3DMainForm.NeonCyan)))
						{
							e.Graphics.FillRectangle(solidBrush, new Rectangle(Point.Empty, e.Item.Size));
						}
						using (Pen pen = new Pen(Color.FromArgb(180, Graph3DMainForm.NeonCyan), 1f))
						{
							e.Graphics.DrawRectangle(pen, 0, 0, e.Item.Width - 1, e.Item.Height - 1);
							return;
						}
					}
					base.OnRenderMenuItemBackground(e);
				}
			}

			// Token: 0x0600135D RID: 4957 RVA: 0x00093448 File Offset: 0x00093448
			protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
			{
				if (e.Item.Selected)
				{
					e.TextColor = Graph3DMainForm.NeonCyan;
				}
				else if (e.Item.Enabled)
				{
					e.TextColor = Graph3DMainForm.FgText;
				}
				else
				{
					e.TextColor = Color.FromArgb(100, 100, 100);
				}
				base.OnRenderItemText(e);
			}

			// Token: 0x020007DE RID: 2014
			private sealed class NeonColorTable : ProfessionalColorTable
			{
				// Token: 0x170000E1 RID: 225
				// (get) Token: 0x0600135E RID: 4958 RVA: 0x0000C4E2 File Offset: 0x0000C4E2
				public override Color MenuItemSelected
				{
					get
					{
						return Color.FromArgb(40, Graph3DMainForm.NeonCyan);
					}
				}

				// Token: 0x170000E2 RID: 226
				// (get) Token: 0x0600135F RID: 4959 RVA: 0x0000C4E2 File Offset: 0x0000C4E2
				public override Color MenuItemSelectedGradientBegin
				{
					get
					{
						return Color.FromArgb(40, Graph3DMainForm.NeonCyan);
					}
				}

				// Token: 0x170000E3 RID: 227
				// (get) Token: 0x06001360 RID: 4960 RVA: 0x0000C4E2 File Offset: 0x0000C4E2
				public override Color MenuItemSelectedGradientEnd
				{
					get
					{
						return Color.FromArgb(40, Graph3DMainForm.NeonCyan);
					}
				}

				// Token: 0x170000E4 RID: 228
				// (get) Token: 0x06001361 RID: 4961 RVA: 0x0000C4F0 File Offset: 0x0000C4F0
				public override Color MenuItemBorder
				{
					get
					{
						return Color.FromArgb(180, Graph3DMainForm.NeonCyan);
					}
				}

				// Token: 0x170000E5 RID: 229
				// (get) Token: 0x06001362 RID: 4962 RVA: 0x0000C501 File Offset: 0x0000C501
				public override Color MenuBorder
				{
					get
					{
						return Color.FromArgb(60, Graph3DMainForm.NeonCyan);
					}
				}

				// Token: 0x170000E6 RID: 230
				// (get) Token: 0x06001363 RID: 4963 RVA: 0x0000C50F File Offset: 0x0000C50F
				public override Color MenuItemPressedGradientBegin
				{
					get
					{
						return Graph3DMainForm.BgCard;
					}
				}

				// Token: 0x170000E7 RID: 231
				// (get) Token: 0x06001364 RID: 4964 RVA: 0x0000C516 File Offset: 0x0000C516
				public override Color MenuItemPressedGradientEnd
				{
					get
					{
						return Graph3DMainForm.BgPanel;
					}
				}

				// Token: 0x170000E8 RID: 232
				// (get) Token: 0x06001365 RID: 4965 RVA: 0x0000C516 File Offset: 0x0000C516
				public override Color ToolStripDropDownBackground
				{
					get
					{
						return Graph3DMainForm.BgPanel;
					}
				}

				// Token: 0x170000E9 RID: 233
				// (get) Token: 0x06001366 RID: 4966 RVA: 0x0000C516 File Offset: 0x0000C516
				public override Color ImageMarginGradientBegin
				{
					get
					{
						return Graph3DMainForm.BgPanel;
					}
				}

				// Token: 0x170000EA RID: 234
				// (get) Token: 0x06001367 RID: 4967 RVA: 0x0000C516 File Offset: 0x0000C516
				public override Color ImageMarginGradientMiddle
				{
					get
					{
						return Graph3DMainForm.BgPanel;
					}
				}

				// Token: 0x170000EB RID: 235
				// (get) Token: 0x06001368 RID: 4968 RVA: 0x0000C516 File Offset: 0x0000C516
				public override Color ImageMarginGradientEnd
				{
					get
					{
						return Graph3DMainForm.BgPanel;
					}
				}

				// Token: 0x170000EC RID: 236
				// (get) Token: 0x06001369 RID: 4969 RVA: 0x0000C516 File Offset: 0x0000C516
				public override Color ToolStripGradientBegin
				{
					get
					{
						return Graph3DMainForm.BgPanel;
					}
				}

				// Token: 0x170000ED RID: 237
				// (get) Token: 0x0600136A RID: 4970 RVA: 0x0000C516 File Offset: 0x0000C516
				public override Color ToolStripGradientMiddle
				{
					get
					{
						return Graph3DMainForm.BgPanel;
					}
				}

				// Token: 0x170000EE RID: 238
				// (get) Token: 0x0600136B RID: 4971 RVA: 0x0000C516 File Offset: 0x0000C516
				public override Color ToolStripGradientEnd
				{
					get
					{
						return Graph3DMainForm.BgPanel;
					}
				}
			}
		}
	}
}
