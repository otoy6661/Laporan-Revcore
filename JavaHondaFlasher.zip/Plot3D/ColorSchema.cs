﻿using System;
using System.Drawing;

namespace Plot3D
{
	// Token: 0x020007DF RID: 2015
	public class ColorSchema
	{
		// Token: 0x0600136D RID: 4973 RVA: 0x000934A4 File Offset: 0x000934A4
		public static Color[] GetSchema(ColorSchema.eSchema schema)
		{
			Color[] array = new Color[16384];
			checked
			{
				for (int i = 0; i < 16384; i++)
				{
					double num = (double)i / 16383.0;
					double val = 0.0;
					double val2 = 0.0;
					double val3 = 0.0;
					unchecked
					{
						switch (schema)
						{
						case ColorSchema.eSchema.Autumn:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.ColorCube:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.Cool:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.Copper:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.Flag:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.Hot:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.Hsv:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.Lines:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.Pink:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.Prism:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.Rainbow1:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.Rainbow2:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.Spring:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.Summer:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.Winter:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						case ColorSchema.eSchema.Graph4D:
							val = 0.13572138 + num * (4.6153926 + num * (-42.66032258 + num * (132.13108234 + num * (-152.94239396 + num * 59.28637943))));
							val2 = 0.09140261 + num * (2.19418839 + num * (4.84296658 + num * (-14.18503333 + num * (4.27729857 + num * 2.82956604))));
							val3 = 0.1066733 + num * (12.64194608 + num * (-60.58204836 + num * (110.36276771 + num * (-89.90310912 + num * 27.34824973))));
							break;
						}
					}
					array[i] = Color.FromArgb(255, (int)(unchecked(ColorSchema.Clamp(val) * 255.0 + 0.5)), (int)(unchecked(ColorSchema.Clamp(val2) * 255.0 + 0.5)), (int)(unchecked(ColorSchema.Clamp(val3) * 255.0 + 0.5)));
				}
				return array;
			}
		}

		// Token: 0x0600136F RID: 4975 RVA: 0x0000C51D File Offset: 0x0000C51D
		private static double Clamp(double val)
		{
			return Math.Max(0.0, Math.Min(1.0, val));
		}

		// Token: 0x04001A85 RID: 6789
		private const int COLOR_COUNT = 16384;

		// Token: 0x020007E0 RID: 2016
		public enum eSchema
		{
			// Token: 0x04001A87 RID: 6791
			Autumn,
			// Token: 0x04001A88 RID: 6792
			ColorCube,
			// Token: 0x04001A89 RID: 6793
			Cool,
			// Token: 0x04001A8A RID: 6794
			Copper,
			// Token: 0x04001A8B RID: 6795
			Flag,
			// Token: 0x04001A8C RID: 6796
			Hot,
			// Token: 0x04001A8D RID: 6797
			Hsv,
			// Token: 0x04001A8E RID: 6798
			Lines,
			// Token: 0x04001A8F RID: 6799
			Pink,
			// Token: 0x04001A90 RID: 6800
			Prism,
			// Token: 0x04001A91 RID: 6801
			Rainbow1,
			// Token: 0x04001A92 RID: 6802
			Rainbow2,
			// Token: 0x04001A93 RID: 6803
			Spring,
			// Token: 0x04001A94 RID: 6804
			Summer,
			// Token: 0x04001A95 RID: 6805
			Winter,
			// Token: 0x04001A96 RID: 6806
			Graph4D
		}
	}
}
