﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020005E7 RID: 1511
	public class RoundedTextBox : UserControl
	{
		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06000E89 RID: 3721 RVA: 0x00009FE8 File Offset: 0x00009FE8
		// (set) Token: 0x06000E8A RID: 3722 RVA: 0x00009FF0 File Offset: 0x00009FF0
		public int CornerRadius
		{
			get
			{
				return this._cornerRadius;
			}
			set
			{
				this._cornerRadius = value;
				this.UpdateRegion();
				base.Invalidate();
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000E8B RID: 3723 RVA: 0x0000A005 File Offset: 0x0000A005
		// (set) Token: 0x06000E8C RID: 3724 RVA: 0x0000A00D File Offset: 0x0000A00D
		public Color BorderColor
		{
			get
			{
				return this._borderColor;
			}
			set
			{
				this._borderColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000E8D RID: 3725 RVA: 0x0000A01C File Offset: 0x0000A01C
		// (set) Token: 0x06000E8E RID: 3726 RVA: 0x0000A024 File Offset: 0x0000A024
		public float BorderWidth
		{
			get
			{
				return this._borderWidth;
			}
			set
			{
				this._borderWidth = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000E8F RID: 3727 RVA: 0x0000A033 File Offset: 0x0000A033
		// (set) Token: 0x06000E90 RID: 3728 RVA: 0x0000A040 File Offset: 0x0000A040
		public override string Text
		{
			get
			{
				return this._inner.Text;
			}
			set
			{
				this._inner.Text = value;
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000E91 RID: 3729 RVA: 0x0000A04E File Offset: 0x0000A04E
		// (set) Token: 0x06000E92 RID: 3730 RVA: 0x0000A05B File Offset: 0x0000A05B
		public bool ReadOnly
		{
			get
			{
				return this._inner.ReadOnly;
			}
			set
			{
				this._inner.ReadOnly = value;
			}
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000E93 RID: 3731 RVA: 0x0000A069 File Offset: 0x0000A069
		// (set) Token: 0x06000E94 RID: 3732 RVA: 0x0000A076 File Offset: 0x0000A076
		public HorizontalAlignment TextAlign
		{
			get
			{
				return this._inner.TextAlign;
			}
			set
			{
				this._inner.TextAlign = value;
			}
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x06000E95 RID: 3733 RVA: 0x0000A084 File Offset: 0x0000A084
		public TextBox InnerTextBox
		{
			get
			{
				return this._inner;
			}
		}

		// Token: 0x06000E96 RID: 3734 RVA: 0x0006A7E8 File Offset: 0x0006A7E8
		public RoundedTextBox()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.BackColor = Color.Transparent;
			this._inner = new TextBox();
			this._inner.BorderStyle = BorderStyle.None;
			this._inner.BackColor = Color.FromArgb(9, 13, 17);
			this._inner.ForeColor = Color.LightGray;
			this._inner.Font = new Font("Consolas", 9f);
			this._inner.Location = new Point(8, 6);
			this._inner.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this._inner.Width = base.Width - 16;
			base.Controls.Add(this._inner);
		}

		// Token: 0x06000E97 RID: 3735 RVA: 0x0000A08C File Offset: 0x0000A08C
		protected override void OnHandleCreated(EventArgs e)
		{
			base.OnHandleCreated(e);
			this.UpdateRegion();
		}

		// Token: 0x06000E98 RID: 3736 RVA: 0x0006A8D8 File Offset: 0x0006A8D8
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.UpdateRegion();
			this._inner.Location = new Point(8, (base.Height - this._inner.Height) / 2);
			this._inner.Width = base.Width - 16;
		}

		// Token: 0x06000E99 RID: 3737 RVA: 0x0000A09B File Offset: 0x0000A09B
		private void UpdateRegion()
		{
			RoundedHelper.SetRegion(this, this._cornerRadius);
		}

		// Token: 0x06000E9A RID: 3738 RVA: 0x0006A92C File Offset: 0x0006A92C
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.Half;
			Control parent = base.Parent;
			Color color = (parent != null) ? parent.BackColor : this.BackColor;
			graphics.Clear(color);
			using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(new RectangleF(0.5f, 0.5f, (float)base.Width - 1f, (float)base.Height - 1f), this._cornerRadius))
			{
				using (SolidBrush solidBrush = new SolidBrush(this._inner.BackColor))
				{
					graphics.FillPath(solidBrush, graphicsPath);
				}
				using (Pen pen = new Pen(this._borderColor, this._borderWidth))
				{
					pen.Alignment = PenAlignment.Center;
					pen.LineJoin = LineJoin.Round;
					graphics.DrawPath(pen, graphicsPath);
				}
			}
		}

		// Token: 0x04001377 RID: 4983
		private TextBox _inner;

		// Token: 0x04001378 RID: 4984
		private int _cornerRadius = 6;

		// Token: 0x04001379 RID: 4985
		private Color _borderColor = Color.FromArgb(0, 255, 230);

		// Token: 0x0400137A RID: 4986
		private float _borderWidth = 1f;
	}
}
