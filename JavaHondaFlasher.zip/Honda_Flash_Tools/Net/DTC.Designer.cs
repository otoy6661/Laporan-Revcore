﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000319 RID: 793
	public partial class DTC : global::System.Windows.Forms.Form
	{
		// Token: 0x06000A2D RID: 2605 RVA: 0x00007CF4 File Offset: 0x00007CF4
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000A2E RID: 2606 RVA: 0x0004C348 File Offset: 0x0004C348
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			this.BackColor = global::System.Drawing.Color.FromArgb(10, 12, 18);
			base.ClientSize = new global::System.Drawing.Size(760, 560);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			base.TopMost = true;
			this.DoubleBuffered = true;
			this.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Regular);
			this.Text = "HONDA ECU FLASH TOOLS - DIAGNOSTIC TROUBLE CODE";
			base.KeyPreview = true;
			base.SetStyle(global::System.Windows.Forms.ControlStyles.UserPaint | global::System.Windows.Forms.ControlStyles.ResizeRedraw | global::System.Windows.Forms.ControlStyles.AllPaintingInWmPaint | global::System.Windows.Forms.ControlStyles.OptimizedDoubleBuffer, true);
			base.UpdateStyles();
			base.Padding = new global::System.Windows.Forms.Padding(6);
			base.KeyDown += delegate(object s, global::System.Windows.Forms.KeyEventArgs e)
			{
				if (e.KeyCode == global::System.Windows.Forms.Keys.Escape)
				{
					this.Close();
				}
			};
			this.SerialPort_0 = new global::System.IO.Ports.SerialPort(this.components);
			this.Timer_0 = new global::System.Windows.Forms.Timer(this.components);
			this.dataviewFaultCodes = new global::System.Windows.Forms.DataGridView();
			this.Column1 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column2 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column3 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			((global::System.ComponentModel.ISupportInitialize)this.dataviewFaultCodes).BeginInit();
			this.dataviewFaultCodes.AllowUserToAddRows = false;
			this.dataviewFaultCodes.AllowUserToDeleteRows = false;
			this.dataviewFaultCodes.AllowUserToResizeRows = false;
			this.dataviewFaultCodes.BackgroundColor = global::System.Drawing.Color.FromArgb(20, 22, 30);
			this.dataviewFaultCodes.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.dataviewFaultCodes.CellBorderStyle = global::System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
			this.dataviewFaultCodes.ColumnHeadersBorderStyle = global::System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
			this.dataviewFaultCodes.EnableHeadersVisualStyles = false;
			this.dataviewFaultCodes.GridColor = global::System.Drawing.Color.FromArgb(40, 45, 58);
			this.dataviewFaultCodes.MultiSelect = false;
			this.dataviewFaultCodes.Name = "dataviewFaultCodes";
			this.dataviewFaultCodes.ReadOnly = true;
			this.dataviewFaultCodes.RowHeadersVisible = false;
			this.dataviewFaultCodes.RowTemplate.Height = 30;
			this.dataviewFaultCodes.SelectionMode = global::System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dataviewFaultCodes.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.dataviewFaultCodes.TabIndex = 0;
			global::System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new global::System.Windows.Forms.DataGridViewCellStyle();
			dataGridViewCellStyle.BackColor = global::System.Drawing.Color.FromArgb(28, 32, 44);
			dataGridViewCellStyle.ForeColor = global::System.Drawing.Color.FromArgb(0, 240, 255);
			dataGridViewCellStyle.Font = new global::System.Drawing.Font("Segoe UI Semibold", 9.5f, global::System.Drawing.FontStyle.Bold);
			dataGridViewCellStyle.Alignment = global::System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle.SelectionBackColor = global::System.Drawing.Color.FromArgb(28, 32, 44);
			dataGridViewCellStyle.SelectionForeColor = global::System.Drawing.Color.FromArgb(0, 240, 255);
			this.dataviewFaultCodes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
			this.dataviewFaultCodes.ColumnHeadersHeight = 38;
			this.dataviewFaultCodes.ColumnHeadersHeightSizeMode = global::System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			global::System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new global::System.Windows.Forms.DataGridViewCellStyle();
			dataGridViewCellStyle2.BackColor = global::System.Drawing.Color.FromArgb(20, 22, 30);
			dataGridViewCellStyle2.ForeColor = global::System.Drawing.Color.FromArgb(220, 230, 240);
			dataGridViewCellStyle2.SelectionBackColor = global::System.Drawing.Color.FromArgb(0, 130, 170);
			dataGridViewCellStyle2.SelectionForeColor = global::System.Drawing.Color.White;
			dataGridViewCellStyle2.Font = new global::System.Drawing.Font("Segoe UI", 8.75f, global::System.Drawing.FontStyle.Regular);
			this.dataviewFaultCodes.DefaultCellStyle = dataGridViewCellStyle2;
			this.dataviewFaultCodes.AlternatingRowsDefaultCellStyle.BackColor = global::System.Drawing.Color.FromArgb(24, 27, 36);
			this.Column1.HeaderText = "No";
			this.Column1.Name = "Column1";
			this.Column1.ReadOnly = true;
			this.Column1.Width = 55;
			this.Column2.HeaderText = "Kode DTC";
			this.Column2.Name = "Column2";
			this.Column2.ReadOnly = true;
			this.Column2.Width = 130;
			this.Column3.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.Column3.HeaderText = "Keterangan";
			this.Column3.Name = "Column3";
			this.Column3.ReadOnly = true;
			this.dataviewFaultCodes.Columns.AddRange(new global::System.Windows.Forms.DataGridViewColumn[]
			{
				this.Column1,
				this.Column2,
				this.Column3
			});
			((global::System.ComponentModel.ISupportInitialize)this.dataviewFaultCodes).EndInit();
			this.button1 = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.button2 = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.btnCloseX = new global::System.Windows.Forms.Button();
			this.stsSNCable = new global::System.Windows.Forms.Label();
			this.txtCOMName = new global::System.Windows.Forms.Label();
			global::System.Windows.Forms.Panel panel = new global::System.Windows.Forms.Panel
			{
				Dock = global::System.Windows.Forms.DockStyle.Fill,
				BackColor = global::System.Drawing.Color.FromArgb(10, 12, 18),
				Padding = new global::System.Windows.Forms.Padding(0)
			};
			global::System.Windows.Forms.Panel panel2 = new global::System.Windows.Forms.Panel
			{
				Dock = global::System.Windows.Forms.DockStyle.Top,
				Height = 52,
				BackColor = global::System.Drawing.Color.Transparent
			};
			global::System.Windows.Forms.Panel panel3 = new global::System.Windows.Forms.Panel
			{
				Dock = global::System.Windows.Forms.DockStyle.Left,
				Width = 74,
				BackColor = global::System.Drawing.Color.Transparent
			};
			panel3.Paint += delegate(object s, global::System.Windows.Forms.PaintEventArgs e)
			{
				e.Graphics.SmoothingMode = global::System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
				e.Graphics.FillEllipse(global::System.Drawing.Brushes.IndianRed, 18, 20, 12, 12);
				e.Graphics.FillEllipse(global::System.Drawing.Brushes.Gold, 36, 20, 12, 12);
				e.Graphics.FillEllipse(global::System.Drawing.Brushes.MediumSeaGreen, 54, 20, 12, 12);
			};
			global::System.Windows.Forms.Label label = new global::System.Windows.Forms.Label
			{
				Text = "DIAGNOSTIC TROUBLE CODE",
				ForeColor = global::System.Drawing.Color.FromArgb(0, 240, 255),
				BackColor = global::System.Drawing.Color.Transparent,
				Font = new global::System.Drawing.Font("Segoe UI Semibold", 11.5f, global::System.Drawing.FontStyle.Bold),
				AutoSize = false,
				Dock = global::System.Windows.Forms.DockStyle.Fill,
				TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft,
				Padding = new global::System.Windows.Forms.Padding(10, 0, 0, 0)
			};
			this.btnCloseX.Text = "✕";
			this.btnCloseX.Dock = global::System.Windows.Forms.DockStyle.Right;
			this.btnCloseX.Width = 52;
			this.btnCloseX.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnCloseX.FlatAppearance.BorderSize = 0;
			this.btnCloseX.BackColor = global::System.Drawing.Color.FromArgb(22, 26, 36);
			this.btnCloseX.ForeColor = global::System.Drawing.Color.FromArgb(180, 190, 200);
			this.btnCloseX.Font = new global::System.Drawing.Font("Segoe UI", 11f, global::System.Drawing.FontStyle.Bold);
			this.btnCloseX.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.btnCloseX.TabStop = false;
			this.btnCloseX.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.FromArgb(220, 50, 60);
			this.btnCloseX.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(180, 30, 40);
			this.btnCloseX.Click += delegate(object s, global::System.EventArgs e)
			{
				this.Close();
			};
			panel2.Controls.Add(label);
			panel2.Controls.Add(panel3);
			panel2.Controls.Add(this.btnCloseX);
			bool dragging = false;
			global::System.Drawing.Point dragStart = global::System.Drawing.Point.Empty;
			global::System.Action<object, global::System.Windows.Forms.MouseEventArgs> onDown = delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
			{
				if (e.Button == global::System.Windows.Forms.MouseButtons.Left)
				{
					dragging = true;
					dragStart = e.Location;
				}
			};
			checked
			{
				global::System.Action<object, global::System.Windows.Forms.MouseEventArgs> onMove = delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
				{
					if (dragging)
					{
						this.Location = new global::System.Drawing.Point(this.Location.X + e.X - dragStart.X, this.Location.Y + e.Y - dragStart.Y);
					}
				};
				global::System.Action<object, global::System.Windows.Forms.MouseEventArgs> onUp = delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
				{
					dragging = false;
				};
				panel2.MouseDown += delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
				{
					onDown(s, e);
				};
				panel2.MouseMove += delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
				{
					onMove(s, e);
				};
				panel2.MouseUp += delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
				{
					onUp(s, e);
				};
				label.MouseDown += delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
				{
					onDown(s, e);
				};
				label.MouseMove += delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
				{
					onMove(s, e);
				};
				label.MouseUp += delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
				{
					onUp(s, e);
				};
				global::System.Windows.Forms.Panel panel4 = new global::System.Windows.Forms.Panel
				{
					Dock = global::System.Windows.Forms.DockStyle.Bottom,
					Height = 76,
					BackColor = global::System.Drawing.Color.Transparent,
					Padding = new global::System.Windows.Forms.Padding(18, 16, 18, 16)
				};
				this.button2.Text = "RESET DTC";
				this.button2.Dock = global::System.Windows.Forms.DockStyle.Fill;
				this.button2.BackColor = global::System.Drawing.Color.FromArgb(0, 160, 200);
				this.button2.ForeColor = global::System.Drawing.Color.White;
				this.button2.Font = new global::System.Drawing.Font("Segoe UI Semibold", 10.5f, global::System.Drawing.FontStyle.Bold);
				this.button2.Cursor = global::System.Windows.Forms.Cursors.Hand;
				this.button2.Margin = new global::System.Windows.Forms.Padding(6, 0, 6, 0);
				this.button2.Click += new global::System.EventHandler(this.button2_Click);
				this.button1.Text = "RESET ECM";
				this.button1.Dock = global::System.Windows.Forms.DockStyle.Fill;
				this.button1.BackColor = global::System.Drawing.Color.FromArgb(200, 50, 70);
				this.button1.ForeColor = global::System.Drawing.Color.White;
				this.button1.Font = new global::System.Drawing.Font("Segoe UI Semibold", 10.5f, global::System.Drawing.FontStyle.Bold);
				this.button1.Cursor = global::System.Windows.Forms.Cursors.Hand;
				this.button1.Margin = new global::System.Windows.Forms.Padding(6, 0, 6, 0);
				this.button1.Click += new global::System.EventHandler(this.button1_Click);
				global::System.Windows.Forms.TableLayoutPanel tableLayoutPanel = new global::System.Windows.Forms.TableLayoutPanel
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					ColumnCount = 2,
					RowCount = 1,
					BackColor = global::System.Drawing.Color.Transparent
				};
				tableLayoutPanel.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Percent, 50f));
				tableLayoutPanel.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Percent, 50f));
				tableLayoutPanel.Controls.Add(this.button2, 0, 0);
				tableLayoutPanel.Controls.Add(this.button1, 1, 0);
				panel4.Controls.Add(tableLayoutPanel);
				global::System.Windows.Forms.Panel panel5 = new global::System.Windows.Forms.Panel
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					BackColor = global::System.Drawing.Color.FromArgb(10, 12, 18),
					Padding = new global::System.Windows.Forms.Padding(18, 14, 18, 10)
				};
				global::System.Windows.Forms.Panel panel6 = new global::System.Windows.Forms.Panel
				{
					Dock = global::System.Windows.Forms.DockStyle.Bottom,
					Height = 30,
					BackColor = global::System.Drawing.Color.Transparent
				};
				this.stsSNCable.Text = "● Cable: —";
				this.stsSNCable.ForeColor = global::System.Drawing.Color.FromArgb(120, 220, 140);
				this.stsSNCable.Font = new global::System.Drawing.Font("Segoe UI", 8.75f, global::System.Drawing.FontStyle.Bold);
				this.stsSNCable.AutoSize = true;
				this.stsSNCable.Location = new global::System.Drawing.Point(0, 7);
				this.stsSNCable.BackColor = global::System.Drawing.Color.Transparent;
				this.txtCOMName.Text = "● COM: —";
				this.txtCOMName.ForeColor = global::System.Drawing.Color.FromArgb(0, 220, 240);
				this.txtCOMName.Font = new global::System.Drawing.Font("Segoe UI", 8.75f, global::System.Drawing.FontStyle.Bold);
				this.txtCOMName.AutoSize = true;
				this.txtCOMName.Location = new global::System.Drawing.Point(220, 7);
				this.txtCOMName.BackColor = global::System.Drawing.Color.Transparent;
				panel6.Controls.Add(this.stsSNCable);
				panel6.Controls.Add(this.txtCOMName);
				panel5.Controls.Add(this.dataviewFaultCodes);
				panel5.Controls.Add(panel6);
				panel.Controls.Add(panel5);
				panel.Controls.Add(panel4);
				panel.Controls.Add(panel2);
				base.Controls.Clear();
				base.Controls.Add(panel);
				base.Paint += delegate(object s, global::System.Windows.Forms.PaintEventArgs e)
				{
					e.Graphics.SmoothingMode = global::System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
					e.Graphics.PixelOffsetMode = global::System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
					int width = this.ClientSize.Width;
					int height = this.ClientSize.Height;
					using (global::System.Drawing.Pen pen = new global::System.Drawing.Pen(global::System.Drawing.Color.FromArgb(50, 0, 255, 220), 1f))
					{
						using (global::System.Drawing.Drawing2D.GraphicsPath roundedPath = this.GetRoundedPath(new global::System.Drawing.Rectangle(4, 4, width - 9, height - 9), 16))
						{
							e.Graphics.DrawPath(pen, roundedPath);
						}
					}
					using (global::System.Drawing.Pen pen2 = new global::System.Drawing.Pen(global::System.Drawing.Color.FromArgb(110, 0, 255, 220), 1f))
					{
						using (global::System.Drawing.Drawing2D.GraphicsPath roundedPath2 = this.GetRoundedPath(new global::System.Drawing.Rectangle(3, 3, width - 7, height - 7), 15))
						{
							e.Graphics.DrawPath(pen2, roundedPath2);
						}
					}
					using (global::System.Drawing.Pen pen3 = new global::System.Drawing.Pen(global::System.Drawing.Color.FromArgb(255, 0, 255, 220), 1f))
					{
						using (global::System.Drawing.Drawing2D.GraphicsPath roundedPath3 = this.GetRoundedPath(new global::System.Drawing.Rectangle(2, 2, width - 5, height - 5), 14))
						{
							e.Graphics.DrawPath(pen3, roundedPath3);
						}
					}
					using (global::System.Drawing.Pen pen4 = new global::System.Drawing.Pen(global::System.Drawing.Color.FromArgb(70, 0, 0, 0), 1f))
					{
						using (global::System.Drawing.Drawing2D.GraphicsPath roundedPath4 = this.GetRoundedPath(new global::System.Drawing.Rectangle(5, 5, width - 11, height - 11), 12))
						{
							e.Graphics.DrawPath(pen4, roundedPath4);
						}
					}
				};
				base.Load += new global::System.EventHandler(this.DTC_Load);
				base.ResumeLayout(false);
			}
		}

		// Token: 0x04000BCB RID: 3019
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000BCC RID: 3020
		private global::System.Windows.Forms.DataGridView dataviewFaultCodes;

		// Token: 0x04000BCD RID: 3021
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Column1;

		// Token: 0x04000BCE RID: 3022
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Column2;

		// Token: 0x04000BCF RID: 3023
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Column3;

		// Token: 0x04000BD0 RID: 3024
		private global::System.IO.Ports.SerialPort SerialPort_0;

		// Token: 0x04000BD1 RID: 3025
		private global::System.Windows.Forms.Timer Timer_0;

		// Token: 0x04000BD2 RID: 3026
		private global::System.Windows.Forms.Label stsSNCable;

		// Token: 0x04000BD3 RID: 3027
		private global::System.Windows.Forms.Label txtCOMName;

		// Token: 0x04000BD5 RID: 3029
		private global::System.Windows.Forms.Button button1;

		// Token: 0x04000BD6 RID: 3030
		private global::System.Windows.Forms.Button button2;

		// Token: 0x04000BD7 RID: 3031
		private global::System.Windows.Forms.Button btnCloseX;
	}
}
