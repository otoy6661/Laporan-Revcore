﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020009D4 RID: 2516
	public class NeonRoundedPanel : Panel
	{
		// Token: 0x170001ED RID: 493
		// (get) Token: 0x06001B5D RID: 7005 RVA: 0x00010508 File Offset: 0x00010508
		// (set) Token: 0x06001B5E RID: 7006 RVA: 0x00010510 File Offset: 0x00010510
		public int CornerRadius { get; set; } = 8;

		// Token: 0x170001EE RID: 494
		// (get) Token: 0x06001B5F RID: 7007 RVA: 0x00010519 File Offset: 0x00010519
		// (set) Token: 0x06001B60 RID: 7008 RVA: 0x00010521 File Offset: 0x00010521
		public Color BorderColor { get; set; } = Color.FromArgb(0, 255, 255);

		// Token: 0x170001EF RID: 495
		// (get) Token: 0x06001B61 RID: 7009 RVA: 0x0001052A File Offset: 0x0001052A
		// (set) Token: 0x06001B62 RID: 7010 RVA: 0x00010532 File Offset: 0x00010532
		public int BorderWidth { get; set; } = 1;

		// Token: 0x170001F0 RID: 496
		// (get) Token: 0x06001B63 RID: 7011 RVA: 0x0001053B File Offset: 0x0001053B
		// (set) Token: 0x06001B64 RID: 7012 RVA: 0x00010543 File Offset: 0x00010543
		public Color NeonGlowColor { get; set; } = Color.FromArgb(60, 0, 255, 255);

		// Token: 0x170001F1 RID: 497
		// (get) Token: 0x06001B65 RID: 7013 RVA: 0x0001054C File Offset: 0x0001054C
		// (set) Token: 0x06001B66 RID: 7014 RVA: 0x00010554 File Offset: 0x00010554
		public int NeonGlowWidth { get; set; } = 3;

		// Token: 0x06001B67 RID: 7015 RVA: 0x000D4EA8 File Offset: 0x000D4EA8
		public NeonRoundedPanel()
		{
			this.DoubleBuffered = true;
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.Padding = new Padding(6);
		}

		// Token: 0x06001B68 RID: 7016 RVA: 0x000D4F20 File Offset: 0x000D4F20
		private GraphicsPath RoundedPath(Rectangle r, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			checked
			{
				int num = radius * 2;
				if (num <= 0)
				{
					graphicsPath.AddRectangle(r);
					return graphicsPath;
				}
				graphicsPath.AddArc(r.X, r.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(r.Right - num, r.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(r.Right - num, r.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(r.X, r.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x06001B69 RID: 7017 RVA: 0x000D4FD4 File Offset: 0x000D4FD4
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			using (SolidBrush solidBrush = new SolidBrush(this.BackColor))
			{
				graphics.FillRectangle(solidBrush, base.ClientRectangle);
			}
			Rectangle r = checked(new Rectangle(0, 0, base.Width - 1, base.Height - 1));
			if (this.NeonGlowWidth > 0)
			{
				using (Pen pen = new Pen(this.NeonGlowColor, (float)this.NeonGlowWidth))
				{
					using (GraphicsPath graphicsPath = this.RoundedPath(r, this.CornerRadius))
					{
						graphics.DrawPath(pen, graphicsPath);
					}
				}
			}
			if (this.BorderWidth > 0)
			{
				using (Pen pen2 = new Pen(this.BorderColor, (float)this.BorderWidth))
				{
					using (GraphicsPath graphicsPath2 = this.RoundedPath(r, this.CornerRadius))
					{
						graphics.DrawPath(pen2, graphicsPath2);
					}
				}
			}
			base.OnPaint(e);
		}
	}
}
