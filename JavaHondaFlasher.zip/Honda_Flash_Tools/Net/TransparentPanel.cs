﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000683 RID: 1667
	public class TransparentPanel : Panel
	{
		// Token: 0x06001001 RID: 4097 RVA: 0x0000ADD5 File Offset: 0x0000ADD5
		public TransparentPanel()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.BackColor = Color.Transparent;
			this.DoubleBuffered = true;
		}
	}
}
