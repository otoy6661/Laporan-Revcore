﻿using System;
using System.Text;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000350 RID: 848
	public static class Conversions
	{
		// Token: 0x06000B5E RID: 2910 RVA: 0x00051320 File Offset: 0x00051320
		public static double Val(object expression)
		{
			if (expression == null)
			{
				return 0.0;
			}
			string text = expression.ToString();
			if (string.IsNullOrWhiteSpace(text))
			{
				return 0.0;
			}
			if (text.StartsWith("&H"))
			{
				try
				{
					return (double)Convert.ToInt32(text.Substring(2), 16);
				}
				catch
				{
					return 0.0;
				}
			}
			bool flag = false;
			bool flag2 = false;
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < text.Length; i++)
			{
				char c = text[i];
				if (char.IsDigit(c))
				{
					stringBuilder.Append(c);
				}
				else if (c == '.' && !flag)
				{
					stringBuilder.Append(c);
					flag = true;
				}
				else if (c == '-' && i == 0 && !flag2)
				{
					stringBuilder.Append(c);
					flag2 = true;
				}
				else if (c != '+')
				{
					break;
				}
			}
			if (stringBuilder.Length == 0)
			{
				return 0.0;
			}
			double result;
			try
			{
				result = double.Parse(stringBuilder.ToString());
			}
			catch
			{
				result = 0.0;
			}
			return result;
		}

		// Token: 0x06000B5F RID: 2911 RVA: 0x000086B6 File Offset: 0x000086B6
		public static string ToString(object value)
		{
			return ((value != null) ? value.ToString() : null) ?? string.Empty;
		}

		// Token: 0x06000B60 RID: 2912 RVA: 0x00051448 File Offset: 0x00051448
		public static int ToInteger(object value)
		{
			int result;
			try
			{
				result = Convert.ToInt32(value);
			}
			catch
			{
				result = 0;
			}
			return result;
		}
	}
}
