﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200077D RID: 1917
	public static class AutoUpdateManager
	{
		// Token: 0x14000003 RID: 3
		// (add) Token: 0x06001248 RID: 4680 RVA: 0x000893EC File Offset: 0x000893EC
		// (remove) Token: 0x06001249 RID: 4681 RVA: 0x00089420 File Offset: 0x00089420
		public static event Action<string> OnStatusChanged;

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x0600124A RID: 4682 RVA: 0x00089454 File Offset: 0x00089454
		// (remove) Token: 0x0600124B RID: 4683 RVA: 0x00089488 File Offset: 0x00089488
		public static event Action<int> OnProgressChanged;

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x0600124C RID: 4684 RVA: 0x000894BC File Offset: 0x000894BC
		// (remove) Token: 0x0600124D RID: 4685 RVA: 0x000894F0 File Offset: 0x000894F0
		public static event Action<VersionInfo__0> OnUpdateAvailable;

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x0600124E RID: 4686 RVA: 0x00089524 File Offset: 0x00089524
		// (remove) Token: 0x0600124F RID: 4687 RVA: 0x00089558 File Offset: 0x00089558
		public static event Action<string> OnUpdateFailed;

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x06001250 RID: 4688 RVA: 0x0000BF99 File Offset: 0x0000BF99
		// (set) Token: 0x06001251 RID: 4689 RVA: 0x0000BFA0 File Offset: 0x0000BFA0
		public static VersionInfo__0 LatestInfo { get; private set; }

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x06001252 RID: 4690 RVA: 0x0000BFA8 File Offset: 0x0000BFA8
		public static bool IsChecking
		{
			get
			{
				return Interlocked.CompareExchange(ref AutoUpdateManager._isChecking, 0, 0) != 0;
			}
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x06001253 RID: 4691 RVA: 0x0000BFB9 File Offset: 0x0000BFB9
		public static string CurrentVersion
		{
			get
			{
				return AutoUpdateManager.GetCurrentVersion();
			}
		}

		// Token: 0x06001254 RID: 4692 RVA: 0x0008958C File Offset: 0x0008958C
		private static string GetCurrentVersion()
		{
			string result;
			try
			{
				Assembly assembly = Assembly.GetEntryAssembly() ?? Assembly.GetExecutingAssembly();
				object[] customAttributes = assembly.GetCustomAttributes(typeof(AssemblyInformationalVersionAttribute), false);
				if (customAttributes != null && customAttributes.Length != 0)
				{
					string text = ((AssemblyInformationalVersionAttribute)customAttributes[0]).InformationalVersion;
					if (!string.IsNullOrWhiteSpace(text))
					{
						int num = text.IndexOf('+');
						if (num >= 0)
						{
							text = text.Substring(0, num);
						}
						return text.Trim();
					}
				}
				Version version = assembly.GetName().Version;
				result = ((version == null) ? "0.0.0.0" : version.ToString());
			}
			catch
			{
				result = "0.0.0.0";
			}
			return result;
		}

		// Token: 0x06001255 RID: 4693 RVA: 0x0008963C File Offset: 0x0008963C
		public static Task<VersionInfo__0> CheckForUpdateAsync(bool silent = false, CancellationToken ct = default(CancellationToken))
		{
			return Task.Run<VersionInfo__0>(() => AutoUpdateManager.CheckForUpdate(silent, ct), ct);
		}

		// Token: 0x06001256 RID: 4694 RVA: 0x00089674 File Offset: 0x00089674
		private static VersionInfo__0 CheckForUpdate(bool silent, CancellationToken ct)
		{
			if (Interlocked.CompareExchange(ref AutoUpdateManager._isChecking, 1, 0) != 0)
			{
				AutoUpdateManager.Raise<string>(AutoUpdateManager.OnStatusChanged, "Pemeriksaan update sedang berjalan.");
				return AutoUpdateManager.LatestInfo;
			}
			VersionInfo__0 result;
			try
			{
				ct.ThrowIfCancellationRequested();
				AutoUpdateManager.Raise<string>(AutoUpdateManager.OnStatusChanged, "Menghubungkan ke server update...");
				string json = AutoUpdateManager.DownloadText("https://raw.githubusercontent.com/Kiems57garage/Honda-flash-tools/main/version.txt", ct, 15000);
				ct.ThrowIfCancellationRequested();
				VersionInfo__0 versionInfo__ = new VersionInfo__0();
				string jsonValue = AutoUpdateManager.GetJsonValue(json, "version");
				if (string.IsNullOrWhiteSpace(jsonValue))
				{
					throw new InvalidDataException("Manifest tidak berisi field version.");
				}
				versionInfo__.Version = jsonValue.Trim();
				versionInfo__.DownloadUrl = AutoUpdateManager.GetJsonValue(json, "downloadUrl");
				versionInfo__.Sha256 = AutoUpdateManager.GetJsonValue(json, "sha256");
				versionInfo__.Notes = AutoUpdateManager.GetJsonValue(json, "notes");
				long sizeBytes = 0L;
				long.TryParse(AutoUpdateManager.GetJsonValue(json, "sizeBytes"), out sizeBytes);
				versionInfo__.SizeBytes = sizeBytes;
				if (string.IsNullOrWhiteSpace(versionInfo__.DownloadUrl))
				{
					versionInfo__.DownloadUrl = "https://github.com/Kiems57garage/Honda-flash-tools/releases/download/1.0.2.2/TAWON.BALAP.PRO.KLINE.LOCK.exe";
				}
				if (!AutoUpdateManager.IsAllowedDownloadUrl(versionInfo__.DownloadUrl))
				{
					throw new InvalidDataException("URL download bukan alamat release yang diizinkan: " + versionInfo__.DownloadUrl);
				}
				if (!string.IsNullOrWhiteSpace(versionInfo__.Sha256) && !AutoUpdateManager.IsValidSha256(versionInfo__.Sha256))
				{
					throw new InvalidDataException("SHA-256 pada manifest tidak valid.");
				}
				AutoUpdateManager.LatestInfo = versionInfo__;
				if (AutoUpdateManager.IsNewerVersion(versionInfo__.Version, AutoUpdateManager.CurrentVersion))
				{
					AutoUpdateManager.Raise<string>(AutoUpdateManager.OnStatusChanged, "Update tersedia: " + versionInfo__.Version);
					AutoUpdateManager.Raise<VersionInfo__0>(AutoUpdateManager.OnUpdateAvailable, versionInfo__);
				}
				else
				{
					AutoUpdateManager.Raise<string>(AutoUpdateManager.OnStatusChanged, "Aplikasi sudah menggunakan versi terbaru.");
					if (!silent)
					{
						CustomMessageBox__1.Show(string.Concat(new string[]
						{
							"Versi aplikasi saat ini: ",
							AutoUpdateManager.CurrentVersion,
							"\nVersi server: ",
							versionInfo__.Version,
							"\nTidak ada update yang diperlukan."
						}), "Pemeriksaan Update", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				result = versionInfo__;
			}
			catch (OperationCanceledException)
			{
				AutoUpdateManager.Raise<string>(AutoUpdateManager.OnStatusChanged, "Pemeriksaan update dibatalkan.");
				throw;
			}
			catch (Exception ex)
			{
				AutoUpdateManager.Log("CheckForUpdate: " + ex);
				AutoUpdateManager.Raise<string>(AutoUpdateManager.OnStatusChanged, "Pemeriksaan update gagal.");
				AutoUpdateManager.Raise<string>(AutoUpdateManager.OnUpdateFailed, ex.Message);
				if (!silent)
				{
					CustomMessageBox__1.Show("Gagal memeriksa update:\n" + ex.Message, "Auto Update", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				result = null;
			}
			finally
			{
				Interlocked.Exchange(ref AutoUpdateManager._isChecking, 0);
			}
			return result;
		}

		// Token: 0x06001257 RID: 4695 RVA: 0x00089914 File Offset: 0x00089914
		private static string DownloadText(string url, CancellationToken ct, int timeout)
		{
			ct.ThrowIfCancellationRequested();
			HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
			request.Method = "GET";
			request.Timeout = timeout;
			request.ReadWriteTimeout = timeout;
			request.AllowAutoRedirect = true;
			request.UserAgent = "TAWON-BALAP-PRO-Updater/1.0";
			request.Headers.Add("Cache-Control", "no-cache, no-store, must-revalidate");
			request.Headers.Add("Pragma", "no-cache");
			request.Headers.Add("Expires", "0");
			string result;
			using (ct.Register(delegate()
			{
				try
				{
					request.Abort();
				}
				catch
				{
				}
			}))
			{
				using (HttpWebResponse httpWebResponse = (HttpWebResponse)request.GetResponse())
				{
					if (httpWebResponse.StatusCode != HttpStatusCode.OK)
					{
						throw new WebException("Gagal mengambil manifest update. Status: " + httpWebResponse.StatusCode);
					}
					using (Stream responseStream = httpWebResponse.GetResponseStream())
					{
						using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8, true))
						{
							string text = streamReader.ReadToEnd();
							ct.ThrowIfCancellationRequested();
							result = text;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001258 RID: 4696 RVA: 0x00089AAC File Offset: 0x00089AAC
		public static Task<bool> DownloadAndApplyAsync(VersionInfo__0 info, CancellationToken ct = default(CancellationToken))
		{
			return Task.Run<bool>(() => AutoUpdateManager.DownloadAndApply(info, ct), ct);
		}

		// Token: 0x06001259 RID: 4697 RVA: 0x00089AE4 File Offset: 0x00089AE4
		private static bool DownloadAndApply(VersionInfo__0 info, CancellationToken ct)
		{
			string text = Path.Combine(Path.GetTempPath(), "TAWON_BALAP_PRO_Update");
			string text2 = Path.Combine(text, "TAWON.BALAP.PRO.KLINE.LOCK.exe.part");
			string text3 = Path.Combine(text, "TAWON.BALAP.PRO.KLINE.LOCK.exe");
			checked
			{
				bool result;
				try
				{
					if (info == null)
					{
						throw new ArgumentNullException("info");
					}
					string text4 = info.DownloadUrl;
					if (string.IsNullOrWhiteSpace(text4))
					{
						text4 = "https://github.com/Kiems57garage/Honda-flash-tools/releases/download/1.0.2.2/TAWON.BALAP.PRO.KLINE.LOCK.exe";
					}
					if (!AutoUpdateManager.IsAllowedDownloadUrl(text4))
					{
						throw new InvalidDataException("Alamat download tidak diizinkan: " + text4);
					}
					if (!string.IsNullOrWhiteSpace(info.Sha256) && !AutoUpdateManager.IsValidSha256(info.Sha256))
					{
						throw new InvalidDataException("SHA-256 manifest tidak valid.");
					}
					ct.ThrowIfCancellationRequested();
					Directory.CreateDirectory(text);
					AutoUpdateManager.TryDelete(text2);
					AutoUpdateManager.TryDelete(text3);
					AutoUpdateManager.Raise<int>(AutoUpdateManager.OnProgressChanged, 0);
					AutoUpdateManager.Raise<string>(AutoUpdateManager.OnStatusChanged, "Mengunduh update...");
					HttpWebRequest request = (HttpWebRequest)WebRequest.Create(text4);
					request.Method = "GET";
					request.Timeout = 300000;
					request.ReadWriteTimeout = 300000;
					request.AllowAutoRedirect = true;
					request.UserAgent = "TAWON-BALAP-PRO-Updater/1.0";
					request.AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate);
					using (ct.Register(delegate()
					{
						try
						{
							request.Abort();
						}
						catch
						{
						}
					}))
					{
						using (HttpWebResponse httpWebResponse = (HttpWebResponse)request.GetResponse())
						{
							if (httpWebResponse.StatusCode != HttpStatusCode.OK)
							{
								throw new WebException("Server tidak mengirim file update. Status: " + httpWebResponse.StatusCode);
							}
							long contentLength = httpWebResponse.ContentLength;
							long num = 0L;
							using (Stream responseStream = httpWebResponse.GetResponseStream())
							{
								using (FileStream fileStream = new FileStream(text2, FileMode.Create, FileAccess.Write, FileShare.None))
								{
									byte[] array = new byte[81920];
									int num2;
									while ((num2 = responseStream.Read(array, 0, array.Length)) > 0)
									{
										ct.ThrowIfCancellationRequested();
										fileStream.Write(array, 0, num2);
										num += unchecked((long)num2);
										if (contentLength > 0L)
										{
											int num3 = (int)(num * 100L / contentLength);
											if (num3 < 0)
											{
												num3 = 0;
											}
											if (num3 > 100)
											{
												num3 = 100;
											}
											AutoUpdateManager.Raise<int>(AutoUpdateManager.OnProgressChanged, num3);
										}
									}
									fileStream.Flush();
								}
							}
						}
					}
					ct.ThrowIfCancellationRequested();
					FileInfo fileInfo = new FileInfo(text2);
					if (!fileInfo.Exists || fileInfo.Length <= 0L)
					{
						throw new InvalidDataException("File update kosong atau tidak berhasil diunduh.");
					}
					AutoUpdateManager.Raise<string>(AutoUpdateManager.OnStatusChanged, "Memverifikasi file update...");
					if (!string.IsNullOrWhiteSpace(info.Sha256))
					{
						string text5 = AutoUpdateManager.ComputeSha256(text2);
						if (!string.Equals(text5, info.Sha256.Trim(), StringComparison.OrdinalIgnoreCase))
						{
							throw new InvalidDataException("Verifikasi SHA-256 gagal. File update mungkin tidak lengkap.\nExpected: " + info.Sha256.Trim() + "\nActual:   " + text5);
						}
					}
					AutoUpdateManager.TryDelete(text3);
					File.Move(text2, text3);
					AutoUpdateManager.Raise<int>(AutoUpdateManager.OnProgressChanged, 100);
					AutoUpdateManager.Raise<string>(AutoUpdateManager.OnStatusChanged, "Download selesai. Menyiapkan updater...");
					AutoUpdateManager.LaunchUpdater(text3);
					result = true;
				}
				catch (OperationCanceledException)
				{
					AutoUpdateManager.TryDelete(text2);
					AutoUpdateManager.Raise<string>(AutoUpdateManager.OnStatusChanged, "Download update dibatalkan.");
					throw;
				}
				catch (Exception ex)
				{
					AutoUpdateManager.Log("DownloadAndApply: " + ex);
					AutoUpdateManager.TryDelete(text2);
					AutoUpdateManager.Raise<string>(AutoUpdateManager.OnStatusChanged, "Download update gagal.");
					AutoUpdateManager.Raise<string>(AutoUpdateManager.OnUpdateFailed, ex.Message);
					CustomMessageBox__1.Show("Gagal mengunduh atau menyiapkan update:\n" + ex.Message, "Auto Update", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					result = false;
				}
				return result;
			}
		}

		// Token: 0x0600125A RID: 4698 RVA: 0x00089F14 File Offset: 0x00089F14
		private static void LaunchUpdater(string updateFile)
		{
			if (string.IsNullOrWhiteSpace(updateFile))
			{
				throw new ArgumentException("Path file update kosong.", "updateFile");
			}
			if (!File.Exists(updateFile))
			{
				throw new FileNotFoundException("File update tidak ditemukan.", updateFile);
			}
			FileInfo fileInfo = new FileInfo(updateFile);
			if (fileInfo.Length < 1024L)
			{
				throw new InvalidDataException(string.Format("File update tidak valid (terlalu kecil: {0} bytes).", fileInfo.Length));
			}
			string executablePath = Application.ExecutablePath;
			string directoryName = Path.GetDirectoryName(executablePath);
			if (string.IsNullOrWhiteSpace(directoryName))
			{
				throw new InvalidOperationException("Folder aplikasi tidak ditemukan.");
			}
			updateFile = Path.GetFullPath(updateFile);
			string text = executablePath + ".bak";
			try
			{
				if (File.Exists(text))
				{
					File.Delete(text);
				}
				File.Copy(executablePath, text, true);
			}
			catch
			{
			}
			string text2 = Path.GetDirectoryName(updateFile);
			if (string.IsNullOrWhiteSpace(text2))
			{
				text2 = Path.GetTempPath();
			}
			string text3 = Path.Combine(text2, "apply_update.cmd");
			int id = Process.GetCurrentProcess().Id;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("@echo off");
			stringBuilder.AppendLine("setlocal EnableExtensions");
			stringBuilder.AppendLine("cd /d \"" + directoryName + "\"");
			stringBuilder.AppendLine("set \"APP=" + executablePath + "\"");
			stringBuilder.AppendLine("set \"NEW=" + updateFile + "\"");
			stringBuilder.AppendLine("set \"BAK=" + text + "\"");
			stringBuilder.AppendLine("set \"NEWTMP=%APP%.new\"");
			stringBuilder.AppendLine("set /a COUNT=0");
			stringBuilder.AppendLine();
			stringBuilder.AppendLine(":WAIT");
			stringBuilder.AppendLine(string.Format("tasklist /FI \"PID eq {0}\" 2>NUL | findstr /I \"{0}\" >NUL", id));
			stringBuilder.AppendLine("if not errorlevel 1 (");
			stringBuilder.AppendLine("  set /a COUNT+=1");
			stringBuilder.AppendLine("  if %COUNT% GEQ 60 goto FORCE");
			stringBuilder.AppendLine("  timeout /t 1 /nobreak >NUL");
			stringBuilder.AppendLine("  goto WAIT");
			stringBuilder.AppendLine(")");
			stringBuilder.AppendLine();
			stringBuilder.AppendLine(":INSTALL");
			stringBuilder.AppendLine("if exist \"%NEWTMP%\" del /F /Q \"%NEWTMP%\" >NUL 2>&1");
			stringBuilder.AppendLine("copy /Y \"%NEW%\" \"%NEWTMP%\" >NUL");
			stringBuilder.AppendLine("if errorlevel 1 goto FAILED");
			stringBuilder.AppendLine("if exist \"%APP%\" del /F /Q \"%APP%\" >NUL 2>&1");
			stringBuilder.AppendLine("move /Y \"%NEWTMP%\" \"%APP%\" >NUL");
			stringBuilder.AppendLine("if errorlevel 1 goto FAILED");
			stringBuilder.AppendLine("start \"\" \"%APP%\"");
			stringBuilder.AppendLine("goto CLEANUP");
			stringBuilder.AppendLine();
			stringBuilder.AppendLine(":FAILED");
			stringBuilder.AppendLine("if exist \"%BAK%\" (");
			stringBuilder.AppendLine("  if exist \"%APP%\" del /F /Q \"%APP%\" >NUL 2>&1");
			stringBuilder.AppendLine("  copy /Y \"%BAK%\" \"%APP%\" >NUL");
			stringBuilder.AppendLine(")");
			stringBuilder.AppendLine("pause");
			stringBuilder.AppendLine("goto CLEANUP");
			stringBuilder.AppendLine();
			stringBuilder.AppendLine(":FORCE");
			stringBuilder.AppendLine("goto INSTALL");
			stringBuilder.AppendLine();
			stringBuilder.AppendLine(":CLEANUP");
			stringBuilder.AppendLine("if exist \"%NEWTMP%\" del /F /Q \"%NEWTMP%\" >NUL 2>&1");
			stringBuilder.AppendLine("if exist \"%NEW%\" del /F /Q \"%NEW%\" >NUL 2>&1");
			stringBuilder.AppendLine("if exist \"%BAK%\" del /F /Q \"%BAK%\" >NUL 2>&1");
			stringBuilder.AppendLine("del \"%~f0\" >NUL 2>&1");
			stringBuilder.AppendLine("exit /b 0");
			File.WriteAllText(text3, stringBuilder.ToString(), Encoding.Default);
			Process.Start(new ProcessStartInfo
			{
				FileName = "cmd.exe",
				Arguments = "/c call \"" + text3 + "\"",
				WorkingDirectory = text2,
				UseShellExecute = false,
				CreateNoWindow = true,
				WindowStyle = ProcessWindowStyle.Hidden
			});
			Application.Exit();
		}

		// Token: 0x0600125B RID: 4699 RVA: 0x0008A2E0 File Offset: 0x0008A2E0
		private static string GetJsonValue(string json, string key)
		{
			if (string.IsNullOrEmpty(json) || string.IsNullOrEmpty(key))
			{
				return string.Empty;
			}
			string text = "\"" + key + "\"";
			int num = json.IndexOf(text, StringComparison.OrdinalIgnoreCase);
			if (num < 0)
			{
				return string.Empty;
			}
			checked
			{
				int num2 = json.IndexOf(':', num + text.Length);
				if (num2 < 0)
				{
					return string.Empty;
				}
				int num3 = num2 + 1;
				while (num3 < json.Length && char.IsWhiteSpace(json[num3]))
				{
					num3++;
				}
				if (num3 >= json.Length)
				{
					return string.Empty;
				}
				if (json[num3] == 'n' && num3 + 3 < json.Length && json.Substring(num3, 4).Equals("null", StringComparison.OrdinalIgnoreCase))
				{
					return string.Empty;
				}
				if (json[num3] == '"')
				{
					num3++;
					StringBuilder stringBuilder = new StringBuilder();
					bool flag = false;
					for (int i = num3; i < json.Length; i++)
					{
						char c = json[i];
						if (flag)
						{
							if (c <= '\\')
							{
								if (c != '"')
								{
									if (c != '/')
									{
										if (c != '\\')
										{
											goto IL_1E9;
										}
										stringBuilder.Append('\\');
									}
									else
									{
										stringBuilder.Append('/');
									}
								}
								else
								{
									stringBuilder.Append('"');
								}
							}
							else if (c <= 'f')
							{
								if (c != 'b')
								{
									if (c != 'f')
									{
										goto IL_1E9;
									}
									stringBuilder.Append('\f');
								}
								else
								{
									stringBuilder.Append('\b');
								}
							}
							else if (c != 'n')
							{
								switch (c)
								{
								case 'r':
									stringBuilder.Append('\r');
									break;
								case 's':
									goto IL_1E9;
								case 't':
									stringBuilder.Append('\t');
									break;
								case 'u':
								{
									int num4;
									if (i + 4 < json.Length && int.TryParse(json.Substring(i + 1, 4), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out num4))
									{
										stringBuilder.Append((char)num4);
										i += 4;
									}
									break;
								}
								default:
									goto IL_1E9;
								}
							}
							else
							{
								stringBuilder.Append('\n');
							}
							IL_1F3:
							flag = false;
							goto IL_213;
							IL_1E9:
							stringBuilder.Append(c);
							goto IL_1F3;
						}
						if (c == '\\')
						{
							flag = true;
						}
						else
						{
							if (c == '"')
							{
								break;
							}
							stringBuilder.Append(c);
						}
						IL_213:;
					}
					return stringBuilder.ToString();
				}
				int num5 = num3;
				while (num3 < json.Length && json[num3] != ',' && json[num3] != '}' && !char.IsWhiteSpace(json[num3]))
				{
					num3++;
				}
				return json.Substring(num5, num3 - num5).Trim();
			}
		}

		// Token: 0x0600125C RID: 4700 RVA: 0x0008A564 File Offset: 0x0008A564
		public static bool IsNewerVersion(string remoteVersion, string localVersion)
		{
			Version v;
			Version v2;
			return Version.TryParse(AutoUpdateManager.NormalizeVersion(remoteVersion), out v) && (!Version.TryParse(AutoUpdateManager.NormalizeVersion(localVersion), out v2) || v > v2);
		}

		// Token: 0x0600125D RID: 4701 RVA: 0x0008A59C File Offset: 0x0008A59C
		private static string NormalizeVersion(string value)
		{
			if (string.IsNullOrWhiteSpace(value))
			{
				return "0.0.0.0";
			}
			value = value.Trim();
			if (value.StartsWith("v", StringComparison.OrdinalIgnoreCase))
			{
				value = value.Substring(1);
			}
			int num = value.IndexOf('-');
			if (num >= 0)
			{
				value = value.Substring(0, num);
			}
			return value;
		}

		// Token: 0x0600125E RID: 4702 RVA: 0x0008A5F0 File Offset: 0x0008A5F0
		private static string ComputeSha256(string filePath)
		{
			checked
			{
				string result;
				using (SHA256 sha = SHA256.Create())
				{
					using (FileStream fileStream = File.OpenRead(filePath))
					{
						byte[] array = sha.ComputeHash(fileStream);
						StringBuilder stringBuilder = new StringBuilder(array.Length * 2);
						for (int i = 0; i < array.Length; i++)
						{
							stringBuilder.Append(array[i].ToString("x2"));
						}
						result = stringBuilder.ToString();
					}
				}
				return result;
			}
		}

		// Token: 0x0600125F RID: 4703 RVA: 0x0008A684 File Offset: 0x0008A684
		private static void Raise<T>(Action<T> handler, T value)
		{
			if (handler == null)
			{
				return;
			}
			Delegate[] invocationList = handler.GetInvocationList();
			checked
			{
				for (int i = 0; i < invocationList.Length; i++)
				{
					try
					{
						((Action<!!0>)invocationList[i])(value);
					}
					catch
					{
					}
				}
			}
		}

		// Token: 0x06001260 RID: 4704 RVA: 0x0008A6D0 File Offset: 0x0008A6D0
		private static void TryDelete(string path)
		{
			try
			{
				if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
				{
					File.Delete(path);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06001261 RID: 4705 RVA: 0x0008A708 File Offset: 0x0008A708
		private static bool IsAllowedDownloadUrl(string url)
		{
			if (string.IsNullOrWhiteSpace(url))
			{
				return false;
			}
			Uri uri;
			if (!Uri.TryCreate(url, UriKind.Absolute, out uri))
			{
				return false;
			}
			if (uri.Scheme != Uri.UriSchemeHttps)
			{
				return false;
			}
			string a = uri.Host.ToLowerInvariant();
			if (!(a == "github.com") && !(a == "objects.githubusercontent.com") && !(a == "github-releases.githubusercontent.com"))
			{
				return false;
			}
			string text = uri.AbsolutePath.ToLowerInvariant();
			return !(a == "github.com") || text.StartsWith("/kiems57garage/honda-flash-tools/releases/download/", StringComparison.Ordinal) || text.StartsWith("/kiems57garage/honda-flash-tools/releases/latest/download/", StringComparison.Ordinal);
		}

		// Token: 0x06001262 RID: 4706 RVA: 0x0008A7B0 File Offset: 0x0008A7B0
		private static bool IsValidSha256(string hash)
		{
			if (string.IsNullOrWhiteSpace(hash))
			{
				return false;
			}
			hash = hash.Trim();
			if (hash.Length != 64)
			{
				return false;
			}
			foreach (char c in hash)
			{
				if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F'))
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x06001263 RID: 4707 RVA: 0x0008A818 File Offset: 0x0008A818
		static AutoUpdateManager()
		{
			try
			{
				ServicePointManager.SecurityProtocol = (SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
				ServicePointManager.Expect100Continue = false;
				ServicePointManager.DefaultConnectionLimit = 8;
			}
			catch
			{
			}
		}

		// Token: 0x06001264 RID: 4708 RVA: 0x0008A850 File Offset: 0x0008A850
		private static void Log(string message)
		{
			try
			{
				File.AppendAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "update_error.log"), DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " | " + message + Environment.NewLine);
			}
			catch
			{
			}
		}

		// Token: 0x04001934 RID: 6452
		public const string UpdateManifestUrl = "https://raw.githubusercontent.com/Kiems57garage/Honda-flash-tools/main/version.txt";

		// Token: 0x04001935 RID: 6453
		private const int HttpTimeoutMs = 15000;

		// Token: 0x04001936 RID: 6454
		private const int DownloadTimeoutMs = 300000;

		// Token: 0x04001937 RID: 6455
		private static int _isChecking;

		// Token: 0x0400193D RID: 6461
		private const string DefaultDownloadUrl = "https://github.com/Kiems57garage/Honda-flash-tools/releases/download/1.0.2.1/TAWON.BALAP.PRO.KLINE.LOCK.exe";

		// Token: 0x0400193E RID: 6462
		private const string UpdateFileBaseName = "TAWON.BALAP.PRO.KLINE.LOCK.exe";
	}
}
