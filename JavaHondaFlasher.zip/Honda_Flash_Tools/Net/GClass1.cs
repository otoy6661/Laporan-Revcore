﻿using System;
using System.Collections.Generic;
using System.IO.Ports;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200034E RID: 846
	public class GClass1
	{
		// Token: 0x17000027 RID: 39
		// (get) Token: 0x06000B57 RID: 2903 RVA: 0x00008694 File Offset: 0x00008694
		// (set) Token: 0x06000B58 RID: 2904 RVA: 0x0000869C File Offset: 0x0000869C
		public string String_0 { get; set; }

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x06000B59 RID: 2905 RVA: 0x000086A5 File Offset: 0x000086A5
		// (set) Token: 0x06000B5A RID: 2906 RVA: 0x000086AD File Offset: 0x000086AD
		public string String_1 { get; set; }

		// Token: 0x06000B5B RID: 2907 RVA: 0x000512A0 File Offset: 0x000512A0
		public static List<GClass1> smethod_0()
		{
			List<GClass1> list = new List<GClass1>();
			foreach (string text in SerialPort.GetPortNames())
			{
				list.Add(new GClass1
				{
					String_0 = text,
					String_1 = text
				});
			}
			return list;
		}
	}
}
