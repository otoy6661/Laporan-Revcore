﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000538 RID: 1336
	public partial class MainForm : global::System.Windows.Forms.Form
	{
		// Token: 0x06000D49 RID: 3401 RVA: 0x000094B3 File Offset: 0x000094B3
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000D4A RID: 3402 RVA: 0x000647C8 File Offset: 0x000647C8
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Honda_Flash_Tools.Net.MainForm));
			this.TbXdfPath = new global::System.Windows.Forms.TextBox();
			this.BtnSelectXdf = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.TbUnlockedXDF = new global::System.Windows.Forms.TextBox();
			this.BtnDecrypt = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.LblOpenPassword = new global::System.Windows.Forms.Label();
			this.LblModifyPassword = new global::System.Windows.Forms.Label();
			this.TbOpenPassword = new global::System.Windows.Forms.TextBox();
			this.TbModifyPassword = new global::System.Windows.Forms.TextBox();
			this.LblUnlockedXDF = new global::System.Windows.Forms.Label();
			this.BtnSaveUnlockedXdf = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.BtnRemovePassword = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.BtnChangePassword = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.btnCloseX = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.mainPanel = new global::System.Windows.Forms.Panel();
			base.SuspendLayout();
			this.mainPanel.SuspendLayout();
			base.BackColor = global::Honda_Flash_Tools.Net.MainForm.BgBase;
			base.ForeColor = global::Honda_Flash_Tools.Net.MainForm.TextPrimary;
			base.TopMost = true;
			base.ClientSize = new global::System.Drawing.Size(560, 470);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Padding = new global::System.Windows.Forms.Padding(4);
			try
			{
				base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			}
			catch
			{
			}
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "MainForm";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "\ud83d\udd12 Unlock Password XDF Elegant \ud83d\udd12";
			this.mainPanel.BackColor = global::System.Drawing.Color.Transparent;
			this.mainPanel.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.mainPanel.Font = new global::System.Drawing.Font("Segoe UI", 8.5f, global::System.Drawing.FontStyle.Regular);
			this.mainPanel.ForeColor = global::Honda_Flash_Tools.Net.MainForm.TextPrimary;
			this.mainPanel.Location = new global::System.Drawing.Point(4, 4);
			this.mainPanel.Name = "mainPanel";
			this.mainPanel.Padding = new global::System.Windows.Forms.Padding(22);
			base.Controls.Add(this.mainPanel);
			global::System.Windows.Forms.Label label = new global::System.Windows.Forms.Label();
			label.Name = "lblTitle";
			label.Text = "\ud83d\udd12  UNLOCK XDF";
			label.Font = new global::System.Drawing.Font("Segoe UI", 15f, global::System.Drawing.FontStyle.Bold);
			label.ForeColor = global::Honda_Flash_Tools.Net.MainForm.Accent;
			label.BackColor = global::System.Drawing.Color.Transparent;
			label.AutoSize = true;
			label.Location = new global::System.Drawing.Point(22, 18);
			global::System.Windows.Forms.Label label2 = new global::System.Windows.Forms.Label();
			label2.Name = "lblSubtitle";
			label2.Text = "TunerPro XDF/ADX password unlocker";
			label2.Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Italic);
			label2.ForeColor = global::Honda_Flash_Tools.Net.MainForm.TextMuted;
			label2.BackColor = global::System.Drawing.Color.Transparent;
			label2.AutoSize = true;
			label2.Location = new global::System.Drawing.Point(24, 46);
			global::System.Windows.Forms.Panel panel = new global::System.Windows.Forms.Panel();
			panel.Name = "headerDiv";
			panel.BackColor = global::Honda_Flash_Tools.Net.MainForm.BorderSoft;
			panel.Location = new global::System.Drawing.Point(22, 70);
			panel.Size = new global::System.Drawing.Size(516, 1);
			global::System.Windows.Forms.Label label3 = new global::System.Windows.Forms.Label();
			label3.Name = "lblPath";
			label3.Text = "XDF FILE";
			label3.Font = new global::System.Drawing.Font("Segoe UI", 7.5f, global::System.Drawing.FontStyle.Bold);
			label3.ForeColor = global::Honda_Flash_Tools.Net.MainForm.TextMuted;
			label3.BackColor = global::System.Drawing.Color.Transparent;
			label3.AutoSize = true;
			label3.Location = new global::System.Drawing.Point(22, 84);
			this.TbXdfPath.BackColor = global::Honda_Flash_Tools.Net.MainForm.BgInput;
			this.TbXdfPath.ForeColor = global::Honda_Flash_Tools.Net.MainForm.TextPrimary;
			this.TbXdfPath.Font = new global::System.Drawing.Font("Consolas", 8.5f);
			this.TbXdfPath.Location = new global::System.Drawing.Point(22, 102);
			this.TbXdfPath.Name = "TbXdfPath";
			this.TbXdfPath.Size = new global::System.Drawing.Size(388, 22);
			this.TbXdfPath.TabIndex = 0;
			this.TbXdfPath.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.TbXdfPath.ReadOnly = true;
			this.BtnSelectXdf.BackColor = global::Honda_Flash_Tools.Net.MainForm.BgSurface;
			this.BtnSelectXdf.ForeColor = global::Honda_Flash_Tools.Net.MainForm.AccentSoft;
			this.BtnSelectXdf.Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Bold);
			this.BtnSelectXdf.Location = new global::System.Drawing.Point(416, 100);
			this.BtnSelectXdf.Name = "BtnSelectXdf";
			this.BtnSelectXdf.Size = new global::System.Drawing.Size(122, 26);
			this.BtnSelectXdf.TabIndex = 1;
			this.BtnSelectXdf.Text = "\ud83d\udcc2  PILIH FILE";
			this.BtnSelectXdf.CornerRadius = 13;
			this.BtnSelectXdf.BorderColor = global::Honda_Flash_Tools.Net.MainForm.BorderSoft;
			this.BtnSelectXdf.BorderWidth = 1f;
			this.BtnSelectXdf.HoverBackColor = global::System.Drawing.Color.FromArgb(0, 60, 70);
			this.BtnSelectXdf.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.BtnSelectXdf.Click += new global::System.EventHandler(this.BtnSelectXdf_Click);
			this.BtnDecrypt.BackColor = global::Honda_Flash_Tools.Net.MainForm.Accent;
			this.BtnDecrypt.ForeColor = global::System.Drawing.Color.FromArgb(10, 15, 25);
			this.BtnDecrypt.Font = new global::System.Drawing.Font("Segoe UI", 9.5f, global::System.Drawing.FontStyle.Bold);
			this.BtnDecrypt.Location = new global::System.Drawing.Point(22, 138);
			this.BtnDecrypt.Name = "BtnDecrypt";
			this.BtnDecrypt.Size = new global::System.Drawing.Size(516, 38);
			this.BtnDecrypt.TabIndex = 2;
			this.BtnDecrypt.Text = "\ud83d\udd13  DEKRIPSI XDF";
			this.BtnDecrypt.CornerRadius = 12;
			this.BtnDecrypt.BorderColor = global::System.Drawing.Color.Transparent;
			this.BtnDecrypt.BorderWidth = 0f;
			this.BtnDecrypt.HoverBackColor = global::System.Drawing.Color.FromArgb(0, 200, 230);
			this.BtnDecrypt.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.BtnDecrypt.Click += new global::System.EventHandler(this.BtnDecrypt_Click);
			this.LblOpenPassword.AutoSize = false;
			this.LblOpenPassword.ForeColor = global::Honda_Flash_Tools.Net.MainForm.TextMuted;
			this.LblOpenPassword.Font = new global::System.Drawing.Font("Segoe UI", 7.5f, global::System.Drawing.FontStyle.Bold);
			this.LblOpenPassword.Location = new global::System.Drawing.Point(22, 190);
			this.LblOpenPassword.Name = "LblOpenPassword";
			this.LblOpenPassword.Size = new global::System.Drawing.Size(120, 14);
			this.LblOpenPassword.Text = "OPEN PASSWORD";
			this.TbOpenPassword.BackColor = global::Honda_Flash_Tools.Net.MainForm.BgInput;
			this.TbOpenPassword.ForeColor = global::Honda_Flash_Tools.Net.MainForm.Accent;
			this.TbOpenPassword.Font = new global::System.Drawing.Font("Consolas", 8.5f, global::System.Drawing.FontStyle.Bold);
			this.TbOpenPassword.Location = new global::System.Drawing.Point(22, 208);
			this.TbOpenPassword.Name = "TbOpenPassword";
			this.TbOpenPassword.ReadOnly = true;
			this.TbOpenPassword.Size = new global::System.Drawing.Size(248, 22);
			this.TbOpenPassword.TabIndex = 3;
			this.TbOpenPassword.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.TbOpenPassword.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.LblModifyPassword.AutoSize = false;
			this.LblModifyPassword.ForeColor = global::Honda_Flash_Tools.Net.MainForm.TextMuted;
			this.LblModifyPassword.Font = new global::System.Drawing.Font("Segoe UI", 7.5f, global::System.Drawing.FontStyle.Bold);
			this.LblModifyPassword.Location = new global::System.Drawing.Point(290, 190);
			this.LblModifyPassword.Name = "LblModifyPassword";
			this.LblModifyPassword.Size = new global::System.Drawing.Size(120, 14);
			this.LblModifyPassword.Text = "MODIFY PASSWORD";
			this.TbModifyPassword.BackColor = global::Honda_Flash_Tools.Net.MainForm.BgInput;
			this.TbModifyPassword.ForeColor = global::Honda_Flash_Tools.Net.MainForm.Accent;
			this.TbModifyPassword.Font = new global::System.Drawing.Font("Consolas", 8.5f, global::System.Drawing.FontStyle.Bold);
			this.TbModifyPassword.Location = new global::System.Drawing.Point(290, 208);
			this.TbModifyPassword.Name = "TbModifyPassword";
			this.TbModifyPassword.ReadOnly = true;
			this.TbModifyPassword.Size = new global::System.Drawing.Size(248, 22);
			this.TbModifyPassword.TabIndex = 4;
			this.TbModifyPassword.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.TbModifyPassword.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.LblUnlockedXDF.AutoSize = false;
			this.LblUnlockedXDF.ForeColor = global::Honda_Flash_Tools.Net.MainForm.TextMuted;
			this.LblUnlockedXDF.Font = new global::System.Drawing.Font("Segoe UI", 7.5f, global::System.Drawing.FontStyle.Bold);
			this.LblUnlockedXDF.Location = new global::System.Drawing.Point(22, 244);
			this.LblUnlockedXDF.Name = "LblUnlockedXDF";
			this.LblUnlockedXDF.Size = new global::System.Drawing.Size(300, 14);
			this.LblUnlockedXDF.Text = "UNLOCKED XDF PREVIEW";
			this.TbUnlockedXDF.BackColor = global::Honda_Flash_Tools.Net.MainForm.BgInput;
			this.TbUnlockedXDF.ForeColor = global::Honda_Flash_Tools.Net.MainForm.AccentSoft;
			this.TbUnlockedXDF.Location = new global::System.Drawing.Point(22, 262);
			this.TbUnlockedXDF.Multiline = true;
			this.TbUnlockedXDF.Name = "TbUnlockedXDF";
			this.TbUnlockedXDF.ReadOnly = true;
			this.TbUnlockedXDF.ScrollBars = global::System.Windows.Forms.ScrollBars.Both;
			this.TbUnlockedXDF.Size = new global::System.Drawing.Size(516, 110);
			this.TbUnlockedXDF.Font = new global::System.Drawing.Font("Consolas", 7.5f);
			this.TbUnlockedXDF.TabIndex = 5;
			this.TbUnlockedXDF.WordWrap = false;
			this.TbUnlockedXDF.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			int num = 10;
			int num2 = 165;
			int height = 34;
			checked
			{
				int num3 = num2 * 3 + num * 2;
				int num4 = (560 - num3) / 2;
				int y = 388;
				this.BtnSaveUnlockedXdf.BackColor = global::Honda_Flash_Tools.Net.MainForm.BgSurface;
				this.BtnSaveUnlockedXdf.ForeColor = global::Honda_Flash_Tools.Net.MainForm.Accent;
				this.BtnSaveUnlockedXdf.Font = new global::System.Drawing.Font("Segoe UI", 8.5f, global::System.Drawing.FontStyle.Bold);
				this.BtnSaveUnlockedXdf.Location = new global::System.Drawing.Point(num4, y);
				this.BtnSaveUnlockedXdf.Name = "BtnSaveUnlockedXdf";
				this.BtnSaveUnlockedXdf.Size = new global::System.Drawing.Size(num2, height);
				this.BtnSaveUnlockedXdf.TabIndex = 6;
				this.BtnSaveUnlockedXdf.Text = "\ud83d\udcbe  SIMPAN XDF";
				this.BtnSaveUnlockedXdf.CornerRadius = 10;
				this.BtnSaveUnlockedXdf.BorderColor = global::Honda_Flash_Tools.Net.MainForm.BorderSoft;
				this.BtnSaveUnlockedXdf.BorderWidth = 1f;
				this.BtnSaveUnlockedXdf.HoverBackColor = global::System.Drawing.Color.FromArgb(0, 60, 70);
				this.BtnSaveUnlockedXdf.Cursor = global::System.Windows.Forms.Cursors.Hand;
				this.BtnSaveUnlockedXdf.Click += new global::System.EventHandler(this.BtnSaveUnlockedXdf_Click);
				this.BtnRemovePassword.BackColor = global::Honda_Flash_Tools.Net.MainForm.BgSurface;
				this.BtnRemovePassword.ForeColor = global::Honda_Flash_Tools.Net.MainForm.Accent;
				this.BtnRemovePassword.Font = new global::System.Drawing.Font("Segoe UI", 8.5f, global::System.Drawing.FontStyle.Bold);
				this.BtnRemovePassword.Location = new global::System.Drawing.Point(num4 + num2 + num, y);
				this.BtnRemovePassword.Name = "BtnRemovePassword";
				this.BtnRemovePassword.Size = new global::System.Drawing.Size(num2, height);
				this.BtnRemovePassword.TabIndex = 7;
				this.BtnRemovePassword.Text = "\ud83d\uddd1  HAPUS PASSWORD";
				this.BtnRemovePassword.CornerRadius = 10;
				this.BtnRemovePassword.BorderColor = global::Honda_Flash_Tools.Net.MainForm.BorderSoft;
				this.BtnRemovePassword.BorderWidth = 1f;
				this.BtnRemovePassword.HoverBackColor = global::System.Drawing.Color.FromArgb(0, 60, 70);
				this.BtnRemovePassword.Enabled = false;
				this.BtnRemovePassword.Cursor = global::System.Windows.Forms.Cursors.Hand;
				this.BtnRemovePassword.Click += new global::System.EventHandler(this.BtnRemovePassword_Click);
				this.BtnChangePassword.BackColor = global::Honda_Flash_Tools.Net.MainForm.BgSurface;
				this.BtnChangePassword.ForeColor = global::Honda_Flash_Tools.Net.MainForm.Accent;
				this.BtnChangePassword.Font = new global::System.Drawing.Font("Segoe UI", 8.5f, global::System.Drawing.FontStyle.Bold);
				this.BtnChangePassword.Location = new global::System.Drawing.Point(num4 + 2 * (num2 + num), y);
				this.BtnChangePassword.Name = "BtnChangePassword";
				this.BtnChangePassword.Size = new global::System.Drawing.Size(num2, height);
				this.BtnChangePassword.TabIndex = 8;
				this.BtnChangePassword.Text = "\ud83d\udd11  GANTI PASSWORD";
				this.BtnChangePassword.CornerRadius = 10;
				this.BtnChangePassword.BorderColor = global::Honda_Flash_Tools.Net.MainForm.BorderSoft;
				this.BtnChangePassword.BorderWidth = 1f;
				this.BtnChangePassword.HoverBackColor = global::System.Drawing.Color.FromArgb(0, 60, 70);
				this.BtnChangePassword.Enabled = false;
				this.BtnChangePassword.Cursor = global::System.Windows.Forms.Cursors.Hand;
				this.BtnChangePassword.Click += new global::System.EventHandler(this.BtnChangePassword_Click);
				global::System.Windows.Forms.Label label4 = new global::System.Windows.Forms.Label();
				label4.Name = "lblFooter";
				label4.AutoSize = false;
				label4.BackColor = global::System.Drawing.Color.Transparent;
				label4.Font = new global::System.Drawing.Font("Segoe UI", 7f, global::System.Drawing.FontStyle.Italic);
				label4.ForeColor = global::Honda_Flash_Tools.Net.MainForm.TextMuted;
				label4.Location = new global::System.Drawing.Point(22, 434);
				label4.Size = new global::System.Drawing.Size(516, 14);
				label4.Text = "© JAVA TECH ELEGANT  •  ESC to close  •  Drag header to move";
				label4.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
				this.mainPanel.Controls.Add(label);
				this.mainPanel.Controls.Add(label2);
				this.mainPanel.Controls.Add(panel);
				this.mainPanel.Controls.Add(label3);
				this.mainPanel.Controls.Add(this.TbXdfPath);
				this.mainPanel.Controls.Add(this.BtnSelectXdf);
				this.mainPanel.Controls.Add(this.BtnDecrypt);
				this.mainPanel.Controls.Add(this.LblOpenPassword);
				this.mainPanel.Controls.Add(this.TbOpenPassword);
				this.mainPanel.Controls.Add(this.LblModifyPassword);
				this.mainPanel.Controls.Add(this.TbModifyPassword);
				this.mainPanel.Controls.Add(this.LblUnlockedXDF);
				this.mainPanel.Controls.Add(this.TbUnlockedXDF);
				this.mainPanel.Controls.Add(this.BtnSaveUnlockedXdf);
				this.mainPanel.Controls.Add(this.BtnRemovePassword);
				this.mainPanel.Controls.Add(this.BtnChangePassword);
				this.mainPanel.Controls.Add(label4);
				this.mainPanel.ResumeLayout(false);
				this.mainPanel.PerformLayout();
				base.ResumeLayout(false);
				base.PerformLayout();
				base.Load += new global::System.EventHandler(this.MainForm_Load);
			}
		}

		// Token: 0x04001193 RID: 4499
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04001194 RID: 4500
		private global::System.Windows.Forms.TextBox TbXdfPath;

		// Token: 0x04001195 RID: 4501
		private global::System.Windows.Forms.TextBox TbUnlockedXDF;

		// Token: 0x04001196 RID: 4502
		private global::System.Windows.Forms.Label LblOpenPassword;

		// Token: 0x04001197 RID: 4503
		private global::System.Windows.Forms.Label LblModifyPassword;

		// Token: 0x04001198 RID: 4504
		private global::System.Windows.Forms.TextBox TbOpenPassword;

		// Token: 0x04001199 RID: 4505
		private global::System.Windows.Forms.TextBox TbModifyPassword;

		// Token: 0x0400119A RID: 4506
		private global::System.Windows.Forms.Label LblUnlockedXDF;

		// Token: 0x0400119B RID: 4507
		private static readonly global::System.Drawing.Color BgBase = global::System.Drawing.Color.FromArgb(15, 17, 26);

		// Token: 0x0400119C RID: 4508
		private static readonly global::System.Drawing.Color BgSurface = global::System.Drawing.Color.FromArgb(24, 27, 38);

		// Token: 0x0400119D RID: 4509
		private static readonly global::System.Drawing.Color BgInput = global::System.Drawing.Color.FromArgb(32, 36, 50);

		// Token: 0x0400119E RID: 4510
		private static readonly global::System.Drawing.Color BorderSoft = global::System.Drawing.Color.FromArgb(48, 54, 72);

		// Token: 0x0400119F RID: 4511
		private static readonly global::System.Drawing.Color Accent = global::System.Drawing.Color.FromArgb(0, 229, 255);

		// Token: 0x040011A0 RID: 4512
		private static readonly global::System.Drawing.Color AccentSoft = global::System.Drawing.Color.FromArgb(120, 200, 230);

		// Token: 0x040011A1 RID: 4513
		private static readonly global::System.Drawing.Color TextPrimary = global::System.Drawing.Color.FromArgb(235, 240, 250);

		// Token: 0x040011A2 RID: 4514
		private static readonly global::System.Drawing.Color TextMuted = global::System.Drawing.Color.FromArgb(150, 160, 180);

		// Token: 0x040011A7 RID: 4519
		private global::System.Windows.Forms.Panel mainPanel;

		// Token: 0x040011A8 RID: 4520
		private global::Honda_Flash_Tools.Net.RoundedButton BtnSelectXdf;

		// Token: 0x040011A9 RID: 4521
		private global::Honda_Flash_Tools.Net.RoundedButton BtnDecrypt;

		// Token: 0x040011AA RID: 4522
		private global::Honda_Flash_Tools.Net.RoundedButton BtnSaveUnlockedXdf;

		// Token: 0x040011AB RID: 4523
		private global::Honda_Flash_Tools.Net.RoundedButton BtnRemovePassword;

		// Token: 0x040011AC RID: 4524
		private global::Honda_Flash_Tools.Net.RoundedButton BtnChangePassword;

		// Token: 0x040011AD RID: 4525
		private global::Honda_Flash_Tools.Net.RoundedButton btnCloseX;
	}
}
