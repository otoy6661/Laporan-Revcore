﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020005EB RID: 1515
	public class RoundedDropDown : ToolStripDropDown
	{
		// Token: 0x06000EBC RID: 3772 RVA: 0x0006ACD8 File Offset: 0x0006ACD8
		public RoundedDropDown(Color borderColor, int cornerRadius)
		{
			this._borderColor = borderColor;
			this._cornerRadius = cornerRadius;
			base.Padding = new Padding(2);
			base.DropShadowEnabled = true;
			base.BackColor = Color.FromArgb(19, 25, 32);
			base.SetStyle(ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		}

		// Token: 0x06000EBD RID: 3773 RVA: 0x0000A1CF File Offset: 0x0000A1CF
		protected override void OnHandleCreated(EventArgs e)
		{
			base.OnHandleCreated(e);
			this.UpdateRegion();
		}

		// Token: 0x06000EBE RID: 3774 RVA: 0x0000A1DE File Offset: 0x0000A1DE
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.UpdateRegion();
		}

		// Token: 0x06000EBF RID: 3775 RVA: 0x0000A1ED File Offset: 0x0000A1ED
		private void UpdateRegion()
		{
			if (base.Width <= 0 || base.Height <= 0)
			{
				return;
			}
			RoundedHelper.SetRegion(this, this._cornerRadius);
		}

		// Token: 0x06000EC0 RID: 3776 RVA: 0x0006AD2C File Offset: 0x0006AD2C
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			e.Graphics.PixelOffsetMode = PixelOffsetMode.Half;
			using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(new RectangleF(0.5f, 0.5f, (float)base.Width - 1f, (float)base.Height - 1f), this._cornerRadius))
			{
				using (Pen pen = new Pen(this._borderColor, 1f))
				{
					pen.Alignment = PenAlignment.Center;
					pen.LineJoin = LineJoin.Round;
					e.Graphics.DrawPath(pen, graphicsPath);
				}
			}
		}

		// Token: 0x04001386 RID: 4998
		private readonly Color _borderColor;

		// Token: 0x04001387 RID: 4999
		private readonly int _cornerRadius;
	}
}
