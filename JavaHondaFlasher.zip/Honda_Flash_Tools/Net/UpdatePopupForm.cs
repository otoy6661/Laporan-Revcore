﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000783 RID: 1923
	public partial class UpdatePopupForm : Form
	{
		// Token: 0x0600126F RID: 4719 RVA: 0x0008A940 File Offset: 0x0008A940
		public UpdatePopupForm(VersionInfo info)
		{
			if (info == null)
			{
				throw new ArgumentNullException("info");
			}
			this._version = info.Version;
			this._downloadUrl = info.DownloadUrl;
			this._sha256 = info.Sha256;
			this._sizeBytes = info.SizeBytes;
			this._notes = info.Notes;
			this.InitializeUI();
			this.WireAutoUpdateEvents();
		}

		// Token: 0x06001270 RID: 4720 RVA: 0x0008A9AC File Offset: 0x0008A9AC
		private void InitializeUI()
		{
			base.SuspendLayout();
			base.FormBorderStyle = FormBorderStyle.None;
			base.StartPosition = FormStartPosition.CenterParent;
			this.BackColor = UpdatePopupForm.BgBase;
			this.ForeColor = Color.White;
			base.ClientSize = new Size(640, 500);
			base.TopMost = true;
			base.ShowInTaskbar = false;
			this.DoubleBuffered = true;
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.ApplyRoundedRegion(14);
			this.lblTitle = new Label
			{
				Text = "\ud83d\udcab UPDATE DEPPLOY MAP TUNING",
				Font = new Font("TAHOMA", 14f, FontStyle.Bold),
				ForeColor = UpdatePopupForm.Accent,
				BackColor = Color.Transparent,
				AutoSize = true,
				Location = new Point(22, 18)
			};
			base.Controls.Add(this.lblTitle);
			this.lblVersion = new Label
			{
				Text = "\ud83d\udef8 Versi terbaru: v" + (this._version ?? "-"),
				Font = new Font("Segoe UI", 9f, FontStyle.Italic),
				ForeColor = UpdatePopupForm.AccentSoft,
				BackColor = Color.Transparent,
				AutoSize = true,
				Location = new Point(24, 48)
			};
			base.Controls.Add(this.lblVersion);
			checked
			{
				Panel value = new Panel
				{
					BackColor = UpdatePopupForm.BorderSoft,
					Location = new Point(22, 78),
					Size = new Size(base.ClientSize.Width - 44, 1)
				};
				base.Controls.Add(value);
				this.lblChangeTitle = new Label
				{
					Text = "Changelog:",
					Font = new Font("Segoe UI", 9f, FontStyle.Bold),
					ForeColor = UpdatePopupForm.Accent,
					BackColor = Color.Transparent,
					AutoSize = true,
					Location = new Point(22, 90)
				};
				base.Controls.Add(this.lblChangeTitle);
				this.pnlChangelog = new NeonRoundedPanel
				{
					Location = new Point(22, 112),
					Size = new Size(base.ClientSize.Width - 44, 240),
					BackColor = UpdatePopupForm.BgInput,
					CornerRadius = 8,
					BorderColor = Color.FromArgb(0, 255, 255),
					BorderWidth = 1,
					NeonGlowColor = Color.FromArgb(60, 0, 255, 255),
					NeonGlowWidth = 3,
					Padding = new Padding(6)
				};
				base.Controls.Add(this.pnlChangelog);
				this.rtbChangelog = new NeonRoundedRichTextBox
				{
					Dock = DockStyle.Fill,
					BackColor = UpdatePopupForm.BgInput,
					ForeColor = Color.Cyan,
					Font = new Font("Consolas", 9f),
					ReadOnly = true,
					DetectUrls = false,
					WordWrap = true,
					TabStop = true,
					ShortcutsEnabled = true,
					HideSelection = false,
					AutoScrollToEnd = true,
					BorderStyle = BorderStyle.None,
					ScrollBars = RichTextBoxScrollBars.Vertical,
					Text = (string.IsNullOrWhiteSpace(this._notes) ? "(Changelog belum tersedia di server)" : this._notes)
				};
				this.pnlChangelog.Controls.Add(this.rtbChangelog);
				this.lblStatus = new Label
				{
					Text = "Siap mengunduh update.",
					Font = new Font("Segoe UI", 8.5f, FontStyle.Regular),
					ForeColor = Color.Cyan,
					BackColor = Color.Transparent,
					AutoSize = false,
					TextAlign = ContentAlignment.MiddleLeft,
					Location = new Point(22, 366),
					Size = new Size(base.ClientSize.Width - 130, 22)
				};
				base.Controls.Add(this.lblStatus);
				this.lblProgressPct = new Label
				{
					Text = "0%",
					Font = new Font("Consolas", 9f, FontStyle.Bold),
					ForeColor = UpdatePopupForm.Accent,
					BackColor = Color.Transparent,
					TextAlign = ContentAlignment.MiddleRight,
					Location = new Point(base.ClientSize.Width - 100, 366),
					Size = new Size(78, 22)
				};
				base.Controls.Add(this.lblProgressPct);
				this.progressBar = new RoundedProgressBar
				{
					Minimum = 0,
					Maximum = 100,
					Value = 0,
					Location = new Point(22, 390),
					Size = new Size(base.ClientSize.Width - 44, 16),
					CornerRadius = 8,
					TrackColor = UpdatePopupForm.BgInput,
					BarColor = UpdatePopupForm.Accent,
					BarColor2 = new Color?(UpdatePopupForm.AccentSoft),
					BorderColor = UpdatePopupForm.BorderSoft,
					BorderWidth = 1
				};
				base.Controls.Add(this.progressBar);
				int num = 400;
				int num2 = (base.ClientSize.Width - num) / 2;
				this.btnUpdate = new RoundedButton
				{
					Text = "▶  Update Sekarang",
					Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
					Size = new Size(190, 38),
					Location = new Point(num2, 434),
					BackColor = UpdatePopupForm.BgSurface,
					ForeColor = UpdatePopupForm.Accent,
					BorderColor = UpdatePopupForm.Accent,
					BorderWidth = 1f,
					CornerRadius = 10,
					HoverBackColor = Color.FromArgb(0, 60, 70),
					Cursor = Cursors.Hand
				};
				this.btnUpdate.Click += this.BtnUpdate_Click;
				base.Controls.Add(this.btnUpdate);
				this.btnLater = new RoundedButton
				{
					Text = "♻️ Mungkin Nanti",
					Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
					Size = new Size(190, 38),
					Location = new Point(num2 + 190 + 20, 434),
					BackColor = UpdatePopupForm.BgSurface,
					ForeColor = UpdatePopupForm.Accent,
					BorderColor = UpdatePopupForm.Accent,
					BorderWidth = 1f,
					CornerRadius = 10,
					HoverBackColor = Color.FromArgb(0, 50, 55),
					Cursor = Cursors.Hand
				};
				this.btnLater.Click += this.BtnLater_Click;
				base.Controls.Add(this.btnLater);
				this.btnClose = new RoundedButton
				{
					Text = "✕",
					Font = new Font("Segoe UI", 9f, FontStyle.Bold),
					Size = new Size(28, 28),
					Location = new Point(base.ClientSize.Width - 40, 14),
					BackColor = UpdatePopupForm.BgSurface,
					ForeColor = UpdatePopupForm.AccentSoft,
					BorderColor = UpdatePopupForm.BorderSoft,
					BorderWidth = 1f,
					CornerRadius = 14,
					HoverBackColor = UpdatePopupForm.Danger,
					Cursor = Cursors.Hand,
					TabStop = false
				};
				this.btnClose.Click += this.BtnClose_Click;
				base.Controls.Add(this.btnClose);
				base.MouseDown += this.DragHeader;
				this.lblTitle.MouseDown += this.DragHeader;
				this.lblVersion.MouseDown += this.DragHeader;
				base.KeyPreview = true;
				base.KeyDown += this.OnKeyDownHandler;
				base.ResumeLayout(false);
				base.PerformLayout();
			}
		}

		// Token: 0x06001271 RID: 4721 RVA: 0x0000BFE6 File Offset: 0x0000BFE6
		private void OnKeyDownHandler(object sender, KeyEventArgs e)
		{
			if (e.KeyCode != Keys.Escape)
			{
				return;
			}
			if (this._downloading)
			{
				this.RequestCancel();
				return;
			}
			base.Close();
		}

		// Token: 0x06001272 RID: 4722 RVA: 0x0008B1B8 File Offset: 0x0008B1B8
		private void WireAutoUpdateEvents()
		{
			if (this._eventsWired)
			{
				return;
			}
			this._eventsWired = true;
			AutoUpdateManager.OnStatusChanged += this.OnStatusChangedHandler;
			AutoUpdateManager.OnProgressChanged += this.OnProgressChangedHandler;
			AutoUpdateManager.OnUpdateFailed += this.OnUpdateFailedHandler;
		}

		// Token: 0x06001273 RID: 4723 RVA: 0x0008B208 File Offset: 0x0008B208
		private void UnwireAutoUpdateEvents()
		{
			if (!this._eventsWired)
			{
				return;
			}
			this._eventsWired = false;
			AutoUpdateManager.OnStatusChanged -= this.OnStatusChangedHandler;
			AutoUpdateManager.OnProgressChanged -= this.OnProgressChangedHandler;
			AutoUpdateManager.OnUpdateFailed -= this.OnUpdateFailedHandler;
		}

		// Token: 0x06001274 RID: 4724 RVA: 0x0008B258 File Offset: 0x0008B258
		private void OnStatusChangedHandler(string s)
		{
			this.SafeUi(delegate
			{
				if (this.lblStatus != null && !this.lblStatus.IsDisposed)
				{
					this.lblStatus.ForeColor = Color.Cyan;
					this.lblStatus.Text = s;
				}
			});
		}

		// Token: 0x06001275 RID: 4725 RVA: 0x0008B28C File Offset: 0x0008B28C
		private void OnProgressChangedHandler(int p)
		{
			this.SafeUi(delegate
			{
				if (this.progressBar == null || this.progressBar.IsDisposed)
				{
					return;
				}
				int num = Math.Max(0, Math.Min(100, p));
				this.progressBar.Value = num;
				if (this.lblProgressPct != null && !this.lblProgressPct.IsDisposed)
				{
					this.lblProgressPct.Text = num + "%";
				}
			});
		}

		// Token: 0x06001276 RID: 4726 RVA: 0x0008B2C0 File Offset: 0x0008B2C0
		private void OnUpdateFailedHandler(string m)
		{
			this.SafeUi(delegate
			{
				if (this.lblStatus != null && !this.lblStatus.IsDisposed)
				{
					this.lblStatus.Text = m;
					this.lblStatus.ForeColor = UpdatePopupForm.Danger;
				}
				this.SetDownloading(false);
			});
		}

		// Token: 0x06001277 RID: 4727 RVA: 0x0008B2F4 File Offset: 0x0008B2F4
		private void SafeUi(Action a)
		{
			if (base.IsDisposed || base.Disposing)
			{
				return;
			}
			if (base.InvokeRequired)
			{
				try
				{
					base.BeginInvoke(a);
				}
				catch
				{
				}
				return;
			}
			try
			{
				a();
			}
			catch
			{
			}
		}

		// Token: 0x06001278 RID: 4728 RVA: 0x0008B350 File Offset: 0x0008B350
		private async void BtnUpdate_Click(object sender, EventArgs e)
		{
			if (!this._downloading)
			{
				this.SetDownloading(true);
				this._cts = new CancellationTokenSource();
				if (this.lblStatus != null && !this.lblStatus.IsDisposed)
				{
					this.lblStatus.ForeColor = Color.Cyan;
					this.lblStatus.Text = "Memulai unduhan...";
				}
				if (this.lblProgressPct != null && !this.lblProgressPct.IsDisposed)
				{
					this.lblProgressPct.Text = "0%";
				}
				if (this.progressBar != null && !this.progressBar.IsDisposed)
				{
					this.progressBar.Value = 0;
				}
				bool cancelled = false;
				try
				{
					bool flag = await AutoUpdateManager.DownloadAndApplyAsync(new VersionInfo__0
					{
						Version = this._version,
						DownloadUrl = this._downloadUrl,
						Sha256 = this._sha256,
						SizeBytes = this._sizeBytes,
						Notes = this._notes
					}, this._cts.Token).ConfigureAwait(true);
					if (this._cts != null && this._cts.IsCancellationRequested)
					{
						cancelled = true;
					}
					else if (!flag && !base.IsDisposed)
					{
						this.SetDownloading(false);
					}
				}
				catch (OperationCanceledException)
				{
					cancelled = true;
				}
				catch (Exception ex)
				{
					Exception ex2;
					Exception ex = ex2;
					this.SafeUi(delegate
					{
						if (this.lblStatus != null && !this.lblStatus.IsDisposed)
						{
							this.lblStatus.ForeColor = UpdatePopupForm.Danger;
							this.lblStatus.Text = "Update gagal: " + ex.Message;
						}
						this.SetDownloading(false);
					});
				}
				finally
				{
					if (cancelled && !base.IsDisposed && !base.Disposing)
					{
						this.SafeUi(delegate
						{
							if (this.progressBar != null && !this.progressBar.IsDisposed)
							{
								this.progressBar.Value = 0;
							}
							if (this.lblProgressPct != null && !this.lblProgressPct.IsDisposed)
							{
								this.lblProgressPct.Text = "0%";
							}
							if (this.lblStatus != null && !this.lblStatus.IsDisposed)
							{
								this.lblStatus.ForeColor = UpdatePopupForm.AccentSoft;
								this.lblStatus.Text = "Update dibatalkan.";
							}
							this.SetDownloading(false);
						});
					}
					if (this._cts != null)
					{
						try
						{
							this._cts.Dispose();
						}
						catch
						{
						}
						this._cts = null;
					}
				}
			}
		}

		// Token: 0x06001279 RID: 4729 RVA: 0x0000C008 File Offset: 0x0000C008
		private void BtnLater_Click(object sender, EventArgs e)
		{
			if (this._downloading)
			{
				this.RequestCancel();
				return;
			}
			base.Close();
		}

		// Token: 0x0600127A RID: 4730 RVA: 0x0000C008 File Offset: 0x0000C008
		private void BtnClose_Click(object sender, EventArgs e)
		{
			if (this._downloading)
			{
				this.RequestCancel();
				return;
			}
			base.Close();
		}

		// Token: 0x0600127B RID: 4731 RVA: 0x0008B38C File Offset: 0x0008B38C
		private void SetDownloading(bool on)
		{
			this._downloading = on;
			if (this.btnUpdate != null && !this.btnUpdate.IsDisposed)
			{
				this.btnUpdate.Enabled = !on;
				this.btnUpdate.Text = (on ? "⏳ Mengunduh..." : "⬇  Update Sekarang");
				this.btnUpdate.Invalidate();
			}
			if (this.btnLater != null && !this.btnLater.IsDisposed)
			{
				this.btnLater.Enabled = true;
				if (on)
				{
					this.btnLater.Text = "✕ Batalkan";
					this.btnLater.ForeColor = UpdatePopupForm.Danger;
					this.btnLater.BorderColor = UpdatePopupForm.Danger;
					this.btnLater.HoverBackColor = UpdatePopupForm.DangerHover;
				}
				else
				{
					this.btnLater.Text = "Mungkin Nanti";
					this.btnLater.ForeColor = UpdatePopupForm.Accent;
					this.btnLater.BorderColor = UpdatePopupForm.Accent;
					this.btnLater.HoverBackColor = Color.FromArgb(0, 50, 55);
				}
				this.btnLater.Invalidate();
			}
			if (this.btnClose != null && !this.btnClose.IsDisposed)
			{
				this.btnClose.Enabled = true;
				this.btnClose.Invalidate();
			}
		}

		// Token: 0x0600127C RID: 4732 RVA: 0x00024C64 File Offset: 0x00024C64
		private GraphicsPath RoundedPath(Rectangle r, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			checked
			{
				int num = radius * 2;
				graphicsPath.AddArc(r.X, r.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(r.Right - num, r.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(r.Right - num, r.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(r.X, r.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x0600127D RID: 4733 RVA: 0x0008B4D4 File Offset: 0x0008B4D4
		private void ApplyRoundedRegion(int radius)
		{
			using (GraphicsPath graphicsPath = this.RoundedPath(new Rectangle(0, 0, base.Width, base.Height), radius))
			{
				base.Region = new Region(graphicsPath);
			}
		}

		// Token: 0x0600127E RID: 4734 RVA: 0x0008B524 File Offset: 0x0008B524
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.Half;
			int width = base.ClientSize.Width;
			int height = base.ClientSize.Height;
			checked
			{
				using (Pen pen = new Pen(Color.FromArgb(80, UpdatePopupForm.Accent), 4f))
				{
					using (GraphicsPath graphicsPath = this.RoundedPath(new Rectangle(2, 2, width - 4, height - 4), 13))
					{
						graphics.DrawPath(pen, graphicsPath);
					}
				}
				using (Pen pen2 = new Pen(UpdatePopupForm.Accent, 1.6f))
				{
					using (GraphicsPath graphicsPath2 = this.RoundedPath(new Rectangle(2, 2, width - 4, height - 4), 13))
					{
						graphics.DrawPath(pen2, graphicsPath2);
					}
				}
				using (Pen pen3 = new Pen(UpdatePopupForm.BorderSoft, 1f))
				{
					using (GraphicsPath graphicsPath3 = this.RoundedPath(new Rectangle(5, 5, width - 10, height - 10), 11))
					{
						graphics.DrawPath(pen3, graphicsPath3);
					}
				}
				using (Pen pen4 = new Pen(UpdatePopupForm.Accent, 2f))
				{
					graphics.DrawLine(pen4, 22, 66, width - 22, 66);
				}
			}
		}

		// Token: 0x0600127F RID: 4735 RVA: 0x0000C01F File Offset: 0x0000C01F
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.ApplyRoundedRegion(14);
			base.Invalidate();
		}

		// Token: 0x06001280 RID: 4736 RVA: 0x0000C036 File Offset: 0x0000C036
		private void DragHeader(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				UpdatePopupForm.Native.ReleaseCapture();
				UpdatePopupForm.Native.SendMessage(base.Handle, 161, (IntPtr)2, IntPtr.Zero);
			}
		}

		// Token: 0x06001281 RID: 4737 RVA: 0x0008B6E4 File Offset: 0x0008B6E4
		protected override void OnFormClosing(FormClosingEventArgs e)
		{
			if (this._downloading && e.CloseReason == CloseReason.UserClosing)
			{
				this.RequestCancel();
				e.Cancel = true;
				return;
			}
			if (this._cts != null)
			{
				try
				{
					this._cts.Cancel();
				}
				catch
				{
				}
			}
			base.OnFormClosing(e);
		}

		// Token: 0x06001284 RID: 4740 RVA: 0x0008B860 File Offset: 0x0008B860
		public UpdatePopupForm(VersionInfo__0 info)
		{
			if (info == null)
			{
				throw new ArgumentNullException("info");
			}
			this._version = info.Version;
			this._downloadUrl = info.DownloadUrl;
			this._sha256 = info.Sha256;
			this._sizeBytes = info.SizeBytes;
			this._notes = info.Notes;
			this.InitializeUI();
			this.WireAutoUpdateEvents();
		}

		// Token: 0x06001285 RID: 4741 RVA: 0x0008B8CC File Offset: 0x0008B8CC
		private void RequestCancel()
		{
			try
			{
				if (this._cts != null && !this._cts.IsCancellationRequested)
				{
					this._cts.Cancel();
				}
			}
			catch
			{
			}
			this.SafeUi(delegate
			{
				if (this.lblStatus != null && !this.lblStatus.IsDisposed)
				{
					this.lblStatus.ForeColor = UpdatePopupForm.AccentSoft;
					this.lblStatus.Text = "Membatalkan update...";
				}
				if (this.btnLater != null && !this.btnLater.IsDisposed)
				{
					this.btnLater.Enabled = false;
					this.btnLater.Text = "⏳ Membatalkan...";
					this.btnLater.Invalidate();
				}
				if (this.btnClose != null && !this.btnClose.IsDisposed)
				{
					this.btnClose.Enabled = false;
				}
			});
		}

		// Token: 0x04001946 RID: 6470
		private static readonly Color BgBase = Color.FromArgb(9, 9, 11);

		// Token: 0x04001947 RID: 6471
		private static readonly Color BgSurface = Color.FromArgb(17, 17, 20);

		// Token: 0x04001948 RID: 6472
		private static readonly Color BgInput = Color.FromArgb(24, 24, 27);

		// Token: 0x04001949 RID: 6473
		private static readonly Color BorderSoft = Color.FromArgb(39, 39, 42);

		// Token: 0x0400194A RID: 6474
		private static readonly Color Accent = Color.FromArgb(0, 255, 255);

		// Token: 0x0400194B RID: 6475
		private static readonly Color AccentSoft = Color.FromArgb(64, 224, 208);

		// Token: 0x0400194C RID: 6476
		private static readonly Color TextMuted = Color.FromArgb(150, 160, 180);

		// Token: 0x0400194D RID: 6477
		private static readonly Color Danger = Color.FromArgb(239, 68, 68);

		// Token: 0x0400194E RID: 6478
		private Label lblTitle;

		// Token: 0x0400194F RID: 6479
		private Label lblVersion;

		// Token: 0x04001950 RID: 6480
		private Label lblChangeTitle;

		// Token: 0x04001951 RID: 6481
		private Label lblStatus;

		// Token: 0x04001952 RID: 6482
		private Label lblProgressPct;

		// Token: 0x04001953 RID: 6483
		private RoundedButton btnUpdate;

		// Token: 0x04001954 RID: 6484
		private RoundedButton btnLater;

		// Token: 0x04001955 RID: 6485
		private RoundedButton btnClose;

		// Token: 0x04001957 RID: 6487
		private bool _downloading;

		// Token: 0x04001958 RID: 6488
		private bool _eventsWired;

		// Token: 0x04001959 RID: 6489
		private RoundedProgressBar progressBar;

		// Token: 0x0400195A RID: 6490
		private static readonly Color DangerHover = Color.FromArgb(60, 20, 20);

		// Token: 0x0400195B RID: 6491
		private readonly string _version;

		// Token: 0x0400195C RID: 6492
		private readonly string _downloadUrl;

		// Token: 0x0400195D RID: 6493
		private readonly string _sha256;

		// Token: 0x0400195E RID: 6494
		private readonly long _sizeBytes;

		// Token: 0x0400195F RID: 6495
		private readonly string _notes;

		// Token: 0x04001960 RID: 6496
		private NeonRoundedPanel pnlChangelog;

		// Token: 0x04001961 RID: 6497
		private NeonRoundedRichTextBox rtbChangelog;

		// Token: 0x02000784 RID: 1924
		private static class Native
		{
			// Token: 0x06001288 RID: 4744
			[DllImport("user32.dll")]
			public static extern bool ReleaseCapture();

			// Token: 0x06001289 RID: 4745
			[DllImport("user32.dll")]
			public static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);
		}
	}
}
