﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020005E5 RID: 1509
	public class RoundedPanel : Panel
	{
		// Token: 0x17000039 RID: 57
		// (get) Token: 0x06000E6D RID: 3693 RVA: 0x00009EA0 File Offset: 0x00009EA0
		// (set) Token: 0x06000E6E RID: 3694 RVA: 0x00009EA8 File Offset: 0x00009EA8
		public int CornerRadius
		{
			get
			{
				return this._cornerRadius;
			}
			set
			{
				this._cornerRadius = value;
				this.UpdateRegion();
				base.Invalidate();
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x06000E6F RID: 3695 RVA: 0x00009EBD File Offset: 0x00009EBD
		// (set) Token: 0x06000E70 RID: 3696 RVA: 0x00009EC5 File Offset: 0x00009EC5
		public Color BorderColor
		{
			get
			{
				return this._borderColor;
			}
			set
			{
				this._borderColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x06000E71 RID: 3697 RVA: 0x00009ED4 File Offset: 0x00009ED4
		// (set) Token: 0x06000E72 RID: 3698 RVA: 0x00009EDC File Offset: 0x00009EDC
		public float BorderWidth
		{
			get
			{
				return this._borderWidth;
			}
			set
			{
				this._borderWidth = value;
				base.Invalidate();
			}
		}

		// Token: 0x06000E73 RID: 3699 RVA: 0x0006A450 File Offset: 0x0006A450
		public RoundedPanel()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.BackColor = Color.Transparent;
		}

		// Token: 0x06000E74 RID: 3700 RVA: 0x00009EEB File Offset: 0x00009EEB
		protected override void OnHandleCreated(EventArgs e)
		{
			base.OnHandleCreated(e);
			this.UpdateRegion();
		}

		// Token: 0x06000E75 RID: 3701 RVA: 0x00009EFA File Offset: 0x00009EFA
		protected override void OnResize(EventArgs eventargs)
		{
			base.OnResize(eventargs);
			this.UpdateRegion();
		}

		// Token: 0x06000E76 RID: 3702 RVA: 0x00009F09 File Offset: 0x00009F09
		private void UpdateRegion()
		{
			RoundedHelper.SetRegion(this, this._cornerRadius);
		}

		// Token: 0x06000E77 RID: 3703 RVA: 0x0006A4B4 File Offset: 0x0006A4B4
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.Half;
			graphics.InterpolationMode = InterpolationMode.Default;
			Control parent = base.Parent;
			Color color = (parent != null) ? parent.BackColor : this._innerBackColor;
			graphics.Clear(color);
			using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(new RectangleF(0.5f, 0.5f, (float)base.Width - 1f, (float)base.Height - 1f), this._cornerRadius))
			{
				using (SolidBrush solidBrush = new SolidBrush(this._innerBackColor))
				{
					graphics.FillPath(solidBrush, graphicsPath);
				}
				using (Pen pen = new Pen(this._borderColor, this._borderWidth))
				{
					pen.Alignment = PenAlignment.Center;
					pen.LineJoin = LineJoin.Round;
					pen.StartCap = LineCap.Round;
					pen.EndCap = LineCap.Round;
					graphics.DrawPath(pen, graphicsPath);
				}
			}
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000E78 RID: 3704 RVA: 0x00009F17 File Offset: 0x00009F17
		// (set) Token: 0x06000E79 RID: 3705 RVA: 0x00009F1F File Offset: 0x00009F1F
		public Color InnerBackColor
		{
			get
			{
				return this._innerBackColor;
			}
			set
			{
				this._innerBackColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x0400136D RID: 4973
		private int _cornerRadius = 12;

		// Token: 0x0400136E RID: 4974
		private Color _borderColor = Color.FromArgb(0, 255, 230);

		// Token: 0x0400136F RID: 4975
		private float _borderWidth = 1.5f;

		// Token: 0x04001370 RID: 4976
		private Color _innerBackColor = Color.FromArgb(22, 28, 35);
	}
}
