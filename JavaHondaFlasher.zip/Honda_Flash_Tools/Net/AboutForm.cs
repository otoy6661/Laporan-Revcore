﻿using System;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020003FC RID: 1020
	public partial class AboutForm : Form
	{
		// Token: 0x06000CE7 RID: 3303 RVA: 0x000091B9 File Offset: 0x000091B9
		public new void SetStyle(ControlStyles flag, bool value)
		{
			base.SetStyle(flag, value);
		}
	}
}
