﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000348 RID: 840
	public class SimpleChart : Control
	{
		// Token: 0x17000020 RID: 32
		// (get) Token: 0x06000B33 RID: 2867 RVA: 0x0000850B File Offset: 0x0000850B
		// (set) Token: 0x06000B34 RID: 2868 RVA: 0x00008513 File Offset: 0x00008513
		public List<double> Points
		{
			get
			{
				return this.points;
			}
			set
			{
				this.points = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x06000B35 RID: 2869 RVA: 0x00008522 File Offset: 0x00008522
		// (set) Token: 0x06000B36 RID: 2870 RVA: 0x0000852A File Offset: 0x0000852A
		public double MinValue
		{
			get
			{
				return this.minValue;
			}
			set
			{
				this.minValue = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x06000B37 RID: 2871 RVA: 0x00008539 File Offset: 0x00008539
		// (set) Token: 0x06000B38 RID: 2872 RVA: 0x00008541 File Offset: 0x00008541
		public double MaxValue
		{
			get
			{
				return this.maxValue;
			}
			set
			{
				this.maxValue = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x06000B39 RID: 2873 RVA: 0x00008550 File Offset: 0x00008550
		// (set) Token: 0x06000B3A RID: 2874 RVA: 0x00008558 File Offset: 0x00008558
		public double Interval
		{
			get
			{
				return this.interval;
			}
			set
			{
				this.interval = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x06000B3B RID: 2875 RVA: 0x00008567 File Offset: 0x00008567
		// (set) Token: 0x06000B3C RID: 2876 RVA: 0x0000856F File Offset: 0x0000856F
		public Color LineColor
		{
			get
			{
				return this.lineColor;
			}
			set
			{
				this.lineColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x06000B3D RID: 2877 RVA: 0x0000857E File Offset: 0x0000857E
		// (set) Token: 0x06000B3E RID: 2878 RVA: 0x00008586 File Offset: 0x00008586
		public int MaxPoints
		{
			get
			{
				return this.maxPoints;
			}
			set
			{
				this.maxPoints = value;
			}
		}

		// Token: 0x06000B3F RID: 2879 RVA: 0x0000858F File Offset: 0x0000858F
		public void AddY(double value)
		{
			this.points.Add(value);
			if (this.points.Count > this.maxPoints)
			{
				this.points.RemoveAt(0);
			}
			base.Invalidate();
		}

		// Token: 0x06000B40 RID: 2880 RVA: 0x000085C2 File Offset: 0x000085C2
		public void ClearPoints()
		{
			this.points.Clear();
			base.Invalidate();
		}

		// Token: 0x06000B41 RID: 2881 RVA: 0x0005084C File Offset: 0x0005084C
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			if (this.points.Count == 0)
			{
				return;
			}
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			Pen pen = new Pen(Color.FromArgb(70, 70, 70), 1f);
			float num = (float)base.Height / 5f;
			for (int i = 1; i < 5; i++)
			{
				float num2 = (float)base.Height - (float)i * num;
				graphics.DrawLine(pen, 0f, num2, (float)base.Width, num2);
			}
			if (this.points.Count > 1)
			{
				float num3 = (float)base.Width / (float)(this.maxPoints - 1);
				float num4 = (float)(this.maxValue - this.minValue);
				using (Pen pen2 = new Pen(this.lineColor, 2f))
				{
					for (int j = 1; j < this.points.Count; j++)
					{
						float x = (float)(j - 1) * num3;
						float y = (float)base.Height - (float)((this.points[j - 1] - this.minValue) / (double)num4 * (double)base.Height);
						float x2 = (float)j * num3;
						float y2 = (float)base.Height - (float)((this.points[j] - this.minValue) / (double)num4 * (double)base.Height);
						graphics.DrawLine(pen2, x, y, x2, y2);
					}
				}
			}
			if (this.points.Count > 0)
			{
				double num5 = this.points[this.points.Count - 1];
				using (Font font = new Font("Arial", 10f))
				{
					using (Brush brush = new SolidBrush(Color.White))
					{
						string s = num5.ToString("F1");
						graphics.DrawString(s, font, brush, 5f, 5f);
					}
				}
			}
		}

		// Token: 0x04000C98 RID: 3224
		private List<double> points = new List<double>();

		// Token: 0x04000C99 RID: 3225
		private double minValue;

		// Token: 0x04000C9A RID: 3226
		private double maxValue = 100.0;

		// Token: 0x04000C9B RID: 3227
		private double interval = 10.0;

		// Token: 0x04000C9C RID: 3228
		private Color lineColor = Color.Red;

		// Token: 0x04000C9D RID: 3229
		private int maxPoints = 50;
	}
}
