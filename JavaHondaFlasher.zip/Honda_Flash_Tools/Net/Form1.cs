﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000531 RID: 1329
	public partial class Form1 : Form
	{
		// Token: 0x06000D15 RID: 3349 RVA: 0x00009259 File Offset: 0x00009259
		public Form1()
		{
			this.InitializeComponent();
			this.ApplyRoundedFormRegion();
			this.ApplyNeonBorderAndDrag();
		}

		// Token: 0x06000D16 RID: 3350 RVA: 0x000616B8 File Offset: 0x000616B8
		private void btnOpenFile_Click(object sender, EventArgs e)
		{
			this.OpenFileDialog1.Filter = "Bin File (*.bin)|*.bin|All file (*.*)|*.*";
			this.OpenFileDialog1.Title = "Select Bin File";
			this.OpenFileDialog1.FileName = "";
			if (this.OpenFileDialog1.ShowDialog() != DialogResult.OK)
			{
				return;
			}
			this.path1 = this.OpenFileDialog1.FileName;
			this.TextBox1.Text = this.path1;
			if (File.Exists(this.path1))
			{
				this.data = File.ReadAllBytes(this.path1);
				this.txtMotor.Text = "";
				this.txtIDModel.Text = "";
				this.txtIDRegion.Text = "";
				this.txtMCU.Text = "";
				this.txtSize.Text = "";
				this.txtTipeEcu.Text = "";
				this.CekECM();
				this.Checksum();
				this.kela();
				return;
			}
			CustomMessageBox__1.Show("File tidak ditemukan!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x06000D17 RID: 3351 RVA: 0x000617D0 File Offset: 0x000617D0
		private void btnCorrection_Click(object sender, EventArgs e)
		{
			CustomMessageBox__1.Show("Checksum = good", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			BinaryWriter binaryWriter = new BinaryWriter(File.Open(this.path1, FileMode.Open, FileAccess.ReadWrite));
			binaryWriter.BaseStream.Seek((long)this.AlamatChecksum, SeekOrigin.Begin);
			binaryWriter.Write(this.H1);
			binaryWriter.BaseStream.Seek((long)(checked(this.AlamatChecksum + 1)), SeekOrigin.Begin);
			binaryWriter.Write(this.H2);
			binaryWriter.Close();
			this.lblStatus.ForeColor = Form1.Success;
			this.lblStatus.Text = "✔  Checksum valid, no need correction";
		}

		// Token: 0x06000D18 RID: 3352 RVA: 0x0006186C File Offset: 0x0006186C
		private void kela()
		{
			if (this.ECMID != "010123" && this.ECMID != "010173" && this.ECMID != "010169" && this.ECMID != "0101AE" && this.ECMID != "0101BE")
			{
				this.btnCorrection.Enabled = false;
				this.lblStatus.ForeColor = Form1.Warning;
				this.lblStatus.Text = "      File Not suport. contact admin";
				CustomMessageBox__1.Show(" Sorry bin file is not allowed", "FAILED", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				base.Close();
			}
		}

		// Token: 0x06000D19 RID: 3353 RVA: 0x00009273 File Offset: 0x00009273
		private void Clear()
		{
			this.Num1 = 0;
			this.Num2 = 0;
			this.Num3 = 0UL;
			this.Num4 = 0;
			this.Num5 = 0;
			this.H1 = 0;
			this.H2 = 0;
			this.n = 0;
		}

		// Token: 0x06000D1A RID: 3354 RVA: 0x0006191C File Offset: 0x0006191C
		private void Checksum()
		{
			this.Clear();
			checked
			{
				while (this.n * 4 + 1 < this.data.Length)
				{
					this.Num1 = (ushort)this.data[this.n * 4];
					this.Num2 = (ushort)this.data[1 + this.n * 4];
					this.Num3 += (ulong)(unchecked((long)((ushort)(this.Num2 << 8) | this.Num1)));
					ref int ptr = ref this.n;
					this.n = ptr + 1;
				}
				this.Num4 = (ushort)((long)this.Num3 & 65535L);
				if (this.Num4 == 0)
				{
					this.lblStatus.ForeColor = Form1.Success;
					this.lblStatus.Text = "✔  Checksum valid, no need correction";
					this.btnCorrection.Enabled = false;
				}
				else
				{
					this.lblStatus.ForeColor = Form1.Danger;
					this.lblStatus.Text = "✖  Checksum invalid, need correction";
					this.btnCorrection.Enabled = true;
				}
				this.Clear();
				this.data[this.AlamatChecksum] = 0;
				this.data[this.AlamatChecksum + 1] = 0;
				while (this.n * 4 + 1 < this.data.Length)
				{
					this.Num1 = (ushort)this.data[this.n * 4];
					this.Num2 = (ushort)this.data[1 + this.n * 4];
					this.Num3 += (ulong)(unchecked((long)((ushort)(this.Num2 << 8) | this.Num1)));
					ref int ptr2 = ref this.n;
					this.n = ptr2 + 1;
				}
				this.Num4 = (ushort)((long)this.Num3 & 65535L);
				this.Num5 = (ushort)(65536 - (int)this.Num4);
				this.H1 = (byte)(this.Num5 & 255);
				this.H2 = (byte)(unchecked((ushort)((uint)this.Num5 >> 8)) & 255);
			}
		}

		// Token: 0x06000D1B RID: 3355 RVA: 0x00061B00 File Offset: 0x00061B00
		private void CekECM()
		{
			this.ECMID = "";
			this.ECMID1 = "";
			if (this.data.Length > 1402 && this.data[1400] == 1)
			{
				this.ECMID = this.data[1400].ToString("X2") + this.data[1401].ToString("X2") + this.data[1402].ToString("X2");
			}
			if (this.data.Length > 110573 && this.data[110572] != 0)
			{
				this.ECMID1 = this.data[110572].ToString("X2") + this.data[110573].ToString("X2");
			}
			if (this.data.Length > 1930 && this.data[1928] == 1)
			{
				this.ECMID = this.data[1928].ToString("X2") + this.data[1929].ToString("X2") + this.data[1930].ToString("X2");
			}
			if (string.IsNullOrEmpty(this.ECMID1) && this.data.Length > 110573 && this.data[110572] != 0)
			{
				this.ECMID1 = this.data[110572].ToString("X2") + this.data[110573].ToString("X2");
			}
			if (this.data.Length > 2050 && this.data[2048] == 1)
			{
				this.ECMID = this.data[2048].ToString("X2") + this.data[2049].ToString("X2") + this.data[2050].ToString("X2");
			}
			if (string.IsNullOrEmpty(this.ECMID1) && this.data.Length > 110573 && this.data[110572] != 0)
			{
				this.ECMID1 = this.data[110572].ToString("X2") + this.data[110573].ToString("X2");
			}
			if (this.data.Length > 1402 && this.data[1400] == 1)
			{
				this.ECMID = this.data[1400].ToString("X2") + this.data[1401].ToString("X2") + this.data[1402].ToString("X2");
			}
			if (string.IsNullOrEmpty(this.ECMID1) && this.data.Length > 110573 && this.data[110572] != 0)
			{
				this.ECMID1 = this.data[110572].ToString("X2") + this.data[110573].ToString("X2");
			}
			if (this.ECMID == "010123")
			{
				this.txtIDModel.Text = this.ECMID;
				this.txtIDRegion.Text = this.ECMID1;
				this.txtMotor.Text = "Honda Vario 125";
				this.AlamatChecksum = 179056;
				this.txtSize.Text = "384 KB";
				this.txtMCU.Text = "V850";
				this.txtTipeEcu.Text = "30400-KZR-601";
				return;
			}
			if (this.ECMID == "010173")
			{
				this.txtIDModel.Text = this.ECMID;
				this.txtIDRegion.Text = this.ECMID1;
				this.txtMotor.Text = "Honda Vario 125";
				this.AlamatChecksum = 179056;
				this.txtSize.Text = "384 KB";
				this.txtMCU.Text = "V850";
				this.txtTipeEcu.Text = "30400-KZR-651";
				return;
			}
			if (this.ECMID == "010169")
			{
				this.txtIDModel.Text = this.ECMID;
				this.txtIDRegion.Text = this.ECMID1;
				this.txtMotor.Text = "Honda Vario 125";
				this.AlamatChecksum = 179056;
				this.txtSize.Text = "384 KB";
				this.txtMCU.Text = "V850";
				this.txtTipeEcu.Text = "30400-KZR-B11";
				return;
			}
			if (this.ECMID == "0101BE")
			{
				this.txtIDModel.Text = this.ECMID;
				this.txtIDRegion.Text = this.ECMID1;
				this.txtMotor.Text = "Honda Vario 125";
				this.AlamatChecksum = 179056;
				this.txtSize.Text = "384 KB";
				this.txtMCU.Text = "V850";
				this.txtTipeEcu.Text = "30400-KZR-B21";
				return;
			}
			if (this.ECMID == "0101AE")
			{
				this.txtIDModel.Text = this.ECMID;
				this.txtIDRegion.Text = this.ECMID1;
				this.txtMotor.Text = "Honda Vario 125";
				this.AlamatChecksum = 179056;
				this.txtSize.Text = "384 KB";
				this.txtMCU.Text = "V850";
				this.txtTipeEcu.Text = "30400-KZR-B31";
				return;
			}
			this.txtIDModel.Text = "?";
			this.txtIDRegion.Text = "?";
			this.txtMotor.Text = "?";
			this.txtSize.Text = "?";
			this.txtMCU.Text = "?";
			this.txtTipeEcu.Text = "?";
			this.kela();
		}

		// Token: 0x06000D1C RID: 3356 RVA: 0x000092AE File Offset: 0x000092AE
		private void btnAbout_Click(object sender, EventArgs e)
		{
			CustomMessageBox__1.Show("Honda Flash Tools v1.0\n\nA tool for validating and correcting Honda ECU checksums.\n\n© JAVA TECH ELEGANT", "About", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		// Token: 0x06000D1D RID: 3357 RVA: 0x000092C3 File Offset: 0x000092C3
		private void btnSupport_Click(object sender, EventArgs e)
		{
			CustomMessageBox__1.Show("Supported ECU Models:\nAll models are for Honda Vario 125\nKZR SERIES ALL VARIAN", "Supported ECU Models", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		// Token: 0x06000D20 RID: 3360 RVA: 0x0004D38C File Offset: 0x0004D38C
		private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = radius * 2;
			graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x06000D22 RID: 3362 RVA: 0x000638FC File Offset: 0x000638FC
		private void ApplyRoundedFormRegion()
		{
			int radius = 14;
			using (GraphicsPath roundedPath = this.GetRoundedPath(new Rectangle(0, 0, base.Width, base.Height), radius))
			{
				base.Region = new Region(roundedPath);
			}
		}

		// Token: 0x06000D23 RID: 3363 RVA: 0x00063950 File Offset: 0x00063950
		private void ApplyNeonBorderAndDrag()
		{
			checked
			{
				RoundedButton roundedButton = new RoundedButton
				{
					Text = "✕",
					Size = new Size(28, 28),
					Location = new Point(base.Width - 34, 28),
					BackColor = Form1.BgSurface,
					ForeColor = Form1.AccentSoft,
					Font = new Font("Segoe UI", 9f, FontStyle.Bold),
					Cursor = Cursors.Hand,
					TabStop = false,
					Anchor = (AnchorStyles.Top | AnchorStyles.Right),
					CornerRadius = 14,
					BorderColor = Form1.BorderSoft,
					BorderWidth = 1f,
					HoverBackColor = Color.FromArgb(220, 50, 50)
				};
				roundedButton.Click += delegate(object s, EventArgs e)
				{
					this.Close();
				};
				base.Controls.Add(roundedButton);
				roundedButton.BringToFront();
				bool dragging = false;
				Point dragStart = Point.Empty;
				base.MouseDown += delegate(object s, MouseEventArgs e)
				{
					if (e.Button == MouseButtons.Left && e.Y <= 100)
					{
						dragging = true;
						dragStart = e.Location;
					}
				};
				base.MouseMove += delegate(object s, MouseEventArgs e)
				{
					if (dragging)
					{
						this.Location = new Point(this.Location.X + e.X - dragStart.X, this.Location.Y + e.Y - dragStart.Y);
					}
				};
				base.MouseUp += delegate(object s, MouseEventArgs e)
				{
					dragging = false;
				};
				base.KeyPreview = true;
				base.KeyDown += delegate(object s, KeyEventArgs e)
				{
					if (e.KeyCode == Keys.Escape)
					{
						this.Close();
					}
				};
				base.Paint += this.Form1_Paint;
				base.Resize += delegate(object s, EventArgs e)
				{
					this.ApplyRoundedFormRegion();
					this.Invalidate();
				};
			}
		}

		// Token: 0x06000D24 RID: 3364 RVA: 0x00063AC4 File Offset: 0x00063AC4
		private void Form1_Paint(object sender, PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.Half;
			int width = base.ClientSize.Width;
			int height = base.ClientSize.Height;
			using (Pen pen = new Pen(Color.FromArgb(80, Form1.Accent), 3f))
			{
				using (GraphicsPath roundedPath = this.GetRoundedPath(new Rectangle(2, 2, width - 4, height - 4), 12))
				{
					graphics.DrawPath(pen, roundedPath);
				}
			}
			using (Pen pen2 = new Pen(Form1.Accent, 1.5f))
			{
				using (GraphicsPath roundedPath2 = this.GetRoundedPath(new Rectangle(2, 2, width - 4, height - 4), 12))
				{
					graphics.DrawPath(pen2, roundedPath2);
				}
			}
			using (Pen pen3 = new Pen(Form1.BorderSoft, 1f))
			{
				using (GraphicsPath roundedPath3 = this.GetRoundedPath(new Rectangle(4, 4, width - 8, height - 8), 10))
				{
					graphics.DrawPath(pen3, roundedPath3);
				}
			}
		}

		// Token: 0x04001153 RID: 4435
		private string path1;

		// Token: 0x04001154 RID: 4436
		private byte[] data;

		// Token: 0x04001155 RID: 4437
		private ushort Num1;

		// Token: 0x04001156 RID: 4438
		private ushort Num2;

		// Token: 0x04001157 RID: 4439
		private ushort Num4;

		// Token: 0x04001158 RID: 4440
		private ushort Num5;

		// Token: 0x04001159 RID: 4441
		private ulong Num3;

		// Token: 0x0400115A RID: 4442
		private byte H1;

		// Token: 0x0400115B RID: 4443
		private byte H2;

		// Token: 0x0400115C RID: 4444
		private string ECMID;

		// Token: 0x0400115D RID: 4445
		private string ECMID1;

		// Token: 0x0400115E RID: 4446
		private int n;

		// Token: 0x0400115F RID: 4447
		private int AlamatChecksum;

		// Token: 0x0400117E RID: 4478
		private static readonly Color Success = Color.FromArgb(74, 222, 128);

		// Token: 0x0400117F RID: 4479
		private static readonly Color Warning = Color.FromArgb(250, 204, 21);

		// Token: 0x04001180 RID: 4480
		private static readonly Color Danger = Color.FromArgb(248, 113, 113);
	}
}
