﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020005E8 RID: 1512
	public class RoundedCheckBox : CheckBox
	{
		// Token: 0x17000048 RID: 72
		// (get) Token: 0x06000E9B RID: 3739 RVA: 0x0000A0A9 File Offset: 0x0000A0A9
		// (set) Token: 0x06000E9C RID: 3740 RVA: 0x0000A0B1 File Offset: 0x0000A0B1
		public int BoxSize
		{
			get
			{
				return this._boxSize;
			}
			set
			{
				this._boxSize = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x06000E9D RID: 3741 RVA: 0x0000A0C0 File Offset: 0x0000A0C0
		// (set) Token: 0x06000E9E RID: 3742 RVA: 0x0000A0C8 File Offset: 0x0000A0C8
		public int CornerRadius
		{
			get
			{
				return this._cornerRadius;
			}
			set
			{
				this._cornerRadius = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x06000E9F RID: 3743 RVA: 0x0000A0D7 File Offset: 0x0000A0D7
		// (set) Token: 0x06000EA0 RID: 3744 RVA: 0x0000A0DF File Offset: 0x0000A0DF
		public Color BoxBackColor
		{
			get
			{
				return this._boxBackColor;
			}
			set
			{
				this._boxBackColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x06000EA1 RID: 3745 RVA: 0x0000A0EE File Offset: 0x0000A0EE
		// (set) Token: 0x06000EA2 RID: 3746 RVA: 0x0000A0F6 File Offset: 0x0000A0F6
		public Color BoxBorderColor
		{
			get
			{
				return this._boxBorderColor;
			}
			set
			{
				this._boxBorderColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x06000EA3 RID: 3747 RVA: 0x0000A105 File Offset: 0x0000A105
		// (set) Token: 0x06000EA4 RID: 3748 RVA: 0x0000A10D File Offset: 0x0000A10D
		public Color CheckColor
		{
			get
			{
				return this._checkColor;
			}
			set
			{
				this._checkColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x06000EA5 RID: 3749 RVA: 0x0006AA34 File Offset: 0x0006AA34
		public RoundedCheckBox()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.BackColor = Color.Transparent;
		}

		// Token: 0x06000EA6 RID: 3750 RVA: 0x0006AAB8 File Offset: 0x0006AAB8
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.Half;
			Control parent = base.Parent;
			Color color = (parent != null) ? parent.BackColor : this.BackColor;
			graphics.Clear(color);
			using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(new RectangleF(0.5f, 0.5f, (float)this._boxSize - 1f, (float)this._boxSize - 1f), this._cornerRadius))
			{
				using (SolidBrush solidBrush = new SolidBrush(this._boxBackColor))
				{
					graphics.FillPath(solidBrush, graphicsPath);
				}
				using (Pen pen = new Pen(this._boxBorderColor, this._borderWidth))
				{
					pen.Alignment = PenAlignment.Center;
					pen.LineJoin = LineJoin.Round;
					graphics.DrawPath(pen, graphicsPath);
				}
			}
			if (base.Checked)
			{
				using (Pen pen2 = new Pen(this._checkColor, 2f))
				{
					pen2.StartCap = LineCap.Round;
					pen2.EndCap = LineCap.Round;
					pen2.LineJoin = LineJoin.Round;
					float num = (float)this._boxSize / 2f;
					float num2 = (float)this._boxSize / 2f;
					PointF pointF = new PointF(num - 4.5f, num2 + 0.5f);
					PointF pointF2 = new PointF(num - 1.5f, num2 + 3.5f);
					PointF pointF3 = new PointF(num + 4.5f, num2 - 3.5f);
					graphics.DrawLines(pen2, new PointF[]
					{
						pointF,
						pointF2,
						pointF3
					});
				}
			}
			Rectangle bounds = new Rectangle(this._boxSize + 6, 0, base.Width - this._boxSize - 6, base.Height);
			TextRenderer.DrawText(graphics, this.Text, this.Font, bounds, this.ForeColor, TextFormatFlags.VerticalCenter);
		}

		// Token: 0x0400137B RID: 4987
		private int _boxSize = 16;

		// Token: 0x0400137C RID: 4988
		private int _cornerRadius = 4;

		// Token: 0x0400137D RID: 4989
		private Color _boxBackColor = Color.FromArgb(9, 13, 17);

		// Token: 0x0400137E RID: 4990
		private Color _boxBorderColor = Color.FromArgb(0, 255, 230);

		// Token: 0x0400137F RID: 4991
		private Color _checkColor = Color.FromArgb(0, 255, 230);

		// Token: 0x04001380 RID: 4992
		private float _borderWidth = 1.5f;
	}
}
