﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200039B RID: 923
	public partial class SMK : Form
	{
		// Token: 0x06000C39 RID: 3129 RVA: 0x0005AC74 File Offset: 0x0005AC74
		public SMK()
		{
			this.components = new Container();
			this.InitializeComponent();
			this.comboBox1.Items.Add("TYPE ECM");
			this.comboBox1.Items.Add("ADV 150 - 30400-K0WA-N01");
			this.comboBox1.Items.Add("ADV 160 - 30400-K0WL-NXX");
			this.comboBox1.Items.Add("BEAT 110 - 30400-K1AL-NB1");
			this.comboBox1.Items.Add("PCX 150 - 30400-K97G-NXX");
			this.comboBox1.Items.Add("PCX 160 - 30400-K1ZG-NXX");
			this.comboBox1.Items.Add("PCX 160 - 30400-K1ZN-NXX");
			this.comboBox1.Items.Add("STYLO 160 - 30400-K3VA-N01");
			this.comboBox1.Items.Add("SCOOPY 110 - 30400-K2F-NXX");
			this.comboBox1.Items.Add("VARIO 125 - 30400-K2VG-N42");
			this.comboBox1.Items.Add("VARIO 150 - 30400-K59J-A71");
			this.comboBox1.Items.Add("VARIO 160 - 30400-K2SA-N02");
			if (this.comboBox1.Items.Count > 0)
			{
				this.comboBox1.SelectedIndex = 0;
			}
			this.ApplyRoundedFormRegion();
			this.ApplyHeaderAndDrag();
		}

		// Token: 0x06000C3A RID: 3130 RVA: 0x0005ADD8 File Offset: 0x0005ADD8
		private bool InitFtdiIso()
		{
			byte[] array = new byte[1];
			byte[] array2 = new byte[]
			{
				1
			};
			uint num = 0U;
			if (Class15__1.FT_Open(0U, ref SMK.ftHandle) != 0U)
			{
				Class15__1.FT_Close(SMK.ftHandle);
				return false;
			}
			if (Class15__1.FT_Purge(SMK.ftHandle, 3U) != 0U)
			{
				Class15__1.FT_Close(SMK.ftHandle);
				return false;
			}
			if (Class15__1.FT_SetBitMode(SMK.ftHandle, 0, 0) != 0U)
			{
				Class15__1.FT_Close(SMK.ftHandle);
				return false;
			}
			if (Class15__1.FT_SetDataCharacteristics(SMK.ftHandle, 8, 0, 0) != 0U)
			{
				Class15__1.FT_Close(SMK.ftHandle);
				return false;
			}
			if (Class15__1.FT_SetBaudRate(SMK.ftHandle, 10400U) != 0U)
			{
				Class15__1.FT_Close(SMK.ftHandle);
				return false;
			}
			if (Class15__1.FT_SetTimeouts(SMK.ftHandle, 50U, 0U) != 0U)
			{
				Class15__1.FT_Close(SMK.ftHandle);
				return false;
			}
			if (Class15__1.FT_SetLatencyTimer(SMK.ftHandle, 8) != 0U)
			{
				Class15__1.FT_Close(SMK.ftHandle);
				return false;
			}
			if (Class15__1.FT_SetBitMode(SMK.ftHandle, 1, 1) != 0U)
			{
				Class15__1.FT_Close(SMK.ftHandle);
				return false;
			}
			checked
			{
				if (Class15__1.FT_Write(SMK.ftHandle, array, (uint)array.Length, ref num) != 0U)
				{
					Class15__1.FT_Close(SMK.ftHandle);
					return false;
				}
				Thread.Sleep(70);
				if (Class15__1.FT_Write(SMK.ftHandle, array2, (uint)array2.Length, ref num) != 0U)
				{
					Class15__1.FT_Close(SMK.ftHandle);
					return false;
				}
				if (Class15__1.FT_SetBitMode(SMK.ftHandle, 0, 0) != 0U)
				{
					Class15__1.FT_Close(SMK.ftHandle);
					return false;
				}
				if (Class15__1.FT_SetBaudRate(SMK.ftHandle, 10400U) != 0U)
				{
					Class15__1.FT_Close(SMK.ftHandle);
					return false;
				}
				if (Class15__1.FT_Purge(SMK.ftHandle, 3U) != 0U)
				{
					Class15__1.FT_Close(SMK.ftHandle);
					return false;
				}
				Thread.Sleep(130);
				return true;
			}
		}

		// Token: 0x06000C3B RID: 3131 RVA: 0x0005AF78 File Offset: 0x0005AF78
		private bool SendCommand6(byte[] command, int commandSize, ref byte[] reply, ref uint replySize, int sleepMs = 0)
		{
			byte[] array = new byte[256];
			List<byte> list = new List<byte>();
			uint num = 0U;
			uint num2 = 0U;
			uint num3 = 0U;
			long num4 = (long)(checked(50 + 2 * commandSize));
			checked
			{
				if (Class15__1.FT_Write(SMK.ftHandle, command, (uint)commandSize, ref num) != 0U)
				{
					return false;
				}
				if (Class15__1.FT_SetLatencyTimer(SMK.ftHandle, 8) != 0U)
				{
					return false;
				}
				if (sleepMs > 0)
				{
					Thread.Sleep(sleepMs);
				}
				Stopwatch stopwatch = new Stopwatch();
				stopwatch.Start();
				bool flag;
				do
				{
					if (Class15__1.FT_GetQueueStatus(SMK.ftHandle, ref num2) == 0U && num2 > 0U && Class15__1.FT_Read(SMK.ftHandle, array, num2, ref num3) == 0U && num3 > 0U)
					{
						list.AddRange(array.Take((int)num3));
						if (num2 == 0U)
						{
							break;
						}
					}
					flag = (stopwatch.ElapsedMilliseconds >= num4);
				}
				while (!flag);
				stopwatch.Stop();
				Class15__1.FT_Purge(SMK.ftHandle, 3U);
				if (list.Count > 0)
				{
					replySize = (uint)list.Count;
					reply = list.ToArray();
					return true;
				}
				return false;
			}
		}

		// Token: 0x06000C3C RID: 3132 RVA: 0x0005B060 File Offset: 0x0005B060
		private void eeprom1()
		{
			this.lblStatus.Text = " Proses READ ID KEIHIN ,Silahkan tunggu sebentar. ";
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			byte[] array = new byte[]
			{
				254,
				4,
				114,
				140
			};
			byte[] array2 = new byte[]
			{
				114,
				5,
				0,
				240,
				153
			};
			byte[] array3 = new byte[]
			{
				39,
				11,
				224,
				72,
				101,
				108,
				108,
				111,
				72,
				111,
				67
			};
			byte[] array4 = new byte[]
			{
				39,
				11,
				224,
				119,
				65,
				114,
				101,
				89,
				111,
				117,
				34
			};
			byte[] array5 = new byte[256];
			byte[] array6 = new byte[]
			{
				130,
				130,
				16,
				6,
				0,
				230
			};
			byte[] array7 = new byte[]
			{
				130,
				130,
				16,
				6,
				1,
				229
			};
			uint num = 0U;
			List<byte> list = new List<byte>();
			checked
			{
				if (this.InitFtdiIso())
				{
					base.Invoke(new MethodInvoker(delegate()
					{
						this.progressBar1.Maximum = 256;
						this.progressBar1.Value = 0;
					}));
					if (this.SendCommand6(array, array.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response: " + BitConverter.ToString(array5, 0, (int)num));
					}
					Thread.Sleep(150);
					if (this.SendCommand6(array2, array2.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response: " + BitConverter.ToString(array5, 0, (int)num));
					}
					Thread.Sleep(150);
					if (this.SendCommand6(array3, array3.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response: " + BitConverter.ToString(array5, 0, (int)num));
					}
					Thread.Sleep(150);
					if (this.SendCommand6(array4, array4.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response2: " + BitConverter.ToString(array5, 0, (int)num));
					}
					if (this.SendCommand6(array6, array6.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response7: " + BitConverter.ToString(array5, 0, (int)num));
					}
					if (this.SendCommand6(array7, array7.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response8: " + BitConverter.ToString(array5, 0, (int)num));
					}
					Console.WriteLine("Response Data:");
					int num2 = 0;
					for (int i = 0; i < 10; i++)
					{
						byte[] array8 = new byte[]
						{
							130,
							130,
							16,
							6,
							0,
							0
						};
						this.SendCommand6(array8, array8.Length, ref array5, ref num, 0);
						Thread.Sleep(10);
						if (num >= 12U)
						{
							num2++;
						}
					}
					MethodInvoker method = delegate()
					{
						this.progressBar1.Value = 0;
						this.PERSEN.Text = "0 %";
						this.label2.Text = "0 Detik";
					};
					for (int j = 0; j <= 255; j++)
					{
						byte[] array9 = new byte[]
						{
							130,
							130,
							16,
							6,
							0,
							0
						};
						this.SendCommand6(array9, array9.Length, ref array5, ref num, 0);
						Thread.Sleep(10);
						Console.WriteLine(string.Format("Alamat {0:X2}, Full Response: {1}, Panjang: {2}", j, BitConverter.ToString(array5, 0, (int)num), num));
						if (num >= 12U)
						{
							int k = 10;
							int num3 = Math.Min((int)num, 12);
							while (k < num3)
							{
								Console.Write(array5[k].ToString("X2") + " ");
								if (k >= 10 && k < 12)
								{
									list.Add(array5[k]);
								}
								k++;
							}
							Console.WriteLine();
						}
						else if (num >= 6U)
						{
							Console.Write(string.Concat(new string[]
							{
								"Extracted: ",
								array5[4].ToString("X2"),
								" ",
								array5[5].ToString("X2"),
								" "
							}));
							list.Add(array5[4]);
							list.Add(array5[5]);
							Console.WriteLine();
						}
						else
						{
							Console.WriteLine(string.Format("Data tidak cukup untuk alamat {0:X2}. Panjang respons: {1}", j, num));
						}
						int currentIndex = j;
						method = delegate()
						{
							this.progressBar1.Value = currentIndex + 1;
							int num4 = (currentIndex + 1) * 100 / 256;
							this.PERSEN.Text = string.Format("{0} %", num4);
							TimeSpan elapsed = stopwatch.Elapsed;
							this.label2.Text = string.Format("{0} Detik", elapsed.Seconds);
						};
						base.Invoke(method);
					}
					stopwatch.Stop();
					base.Invoke(new MethodInvoker(delegate()
					{
						this.lblStatus.Text = " Proses READ ID KEIHIN selesai. ";
					}));
					this.binBytes = list.ToArray();
					this.SaveFileOnUIThread1(list);
					Console.WriteLine(string.Format("Total data yang dibaca: {0} bytes", list.Count));
					return;
				}
				base.Invoke(new MethodInvoker(delegate()
				{
					this.lblStatus.Text = " Gagal menginisialisasi FTDI. ";
					CustomMessageBoxSMK.Show("Gagal menginisialisasi FTDI. Periksa koneksi Anda.", "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
				}));
			}
		}

		// Token: 0x06000C3D RID: 3133 RVA: 0x0005B4C8 File Offset: 0x0005B4C8
		private void eeprom()
		{
			this.lblStatus.Text = " Proses READ ID Shindengen ,Silahkan tunggu sebentar... ";
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			byte[] array = new byte[]
			{
				254,
				4,
				114,
				140
			};
			byte[] array2 = new byte[]
			{
				114,
				5,
				0,
				240,
				153
			};
			byte[] array3 = new byte[]
			{
				145,
				145,
				13,
				223,
				158,
				141,
				154,
				134,
				144,
				138,
				140,
				155,
				136
			};
			byte[] array4 = new byte[]
			{
				145,
				145,
				13,
				223,
				146,
				158,
				134,
				150,
				139,
				141,
				134,
				192,
				106
			};
			byte[] array5 = new byte[256];
			uint num = 0U;
			List<byte> list = new List<byte>();
			checked
			{
				if (this.InitFtdiIso())
				{
					base.Invoke(new Action(delegate()
					{
						this.progressBar1.Maximum = 256;
						this.progressBar1.Value = 0;
					}));
					if (this.SendCommand6(array, array.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("R1: " + BitConverter.ToString(array5, 0, (int)num));
					}
					Thread.Sleep(150);
					if (this.SendCommand6(array2, array2.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("R2: " + BitConverter.ToString(array5, 0, (int)num));
					}
					Thread.Sleep(150);
					if (this.SendCommand6(array3, array3.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("R3: " + BitConverter.ToString(array5, 0, (int)num));
					}
					Thread.Sleep(150);
					if (this.SendCommand6(array4, array4.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("R4: " + BitConverter.ToString(array5, 0, (int)num));
					}
					byte[] array6 = new byte[]
					{
						145,
						145,
						7,
						64,
						0,
						0,
						0
					};
					array6[6] = this.CalcChecksumShindengen(array6, 6);
					if (this.SendCommand6(array6, array6.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Init: " + BitConverter.ToString(array5, 0, (int)num));
					}
					Thread.Sleep(150);
					Console.WriteLine("Response Data:");
					for (int i = 0; i <= 255; i++)
					{
						ushort num2 = (ushort)(i * 2);
						byte[] array7 = new byte[]
						{
							145,
							145,
							7,
							64,
							0,
							0,
							0
						};
						array7[4] = (byte)(num2 & 255);
						array7[5] = (byte)(num2 >> 8 & 255);
						array7[6] = this.CalcChecksumShindengen(array7, 6);
						this.SendCommand6(array7, array7.Length, ref array5, ref num, 0);
						Thread.Sleep(50);
						Console.WriteLine(string.Format("Addr {0:X2}, RSP: {1}, Len: {2}", i, BitConverter.ToString(array5, 0, (int)num), num));
						if (num >= 8U)
						{
							list.Add(array5[6]);
							list.Add(array5[7]);
						}
						else if (num >= 6U)
						{
							list.Add(array5[4]);
							list.Add(array5[5]);
						}
						else
						{
							list.Add(0);
							list.Add(0);
						}
						int currentIndex = i;
						Action method = delegate()
						{
							this.progressBar1.Value = currentIndex + 1;
							int num3 = (currentIndex + 1) * 100 / 256;
							this.PERSEN.Text = string.Format("{0} %", num3);
							this.label2.Text = string.Format("{0} Detik", stopwatch.Elapsed.Seconds);
						};
						base.Invoke(method);
					}
					stopwatch.Stop();
					base.Invoke(new Action(delegate()
					{
						this.lblStatus.Text = " Proses READ ID Shindengen selesai. ";
					}));
					this.binBytes = list.ToArray();
					if (!list.Any((byte b) => b > 0) || list.Distinct<byte>().Count<byte>() <= 3)
					{
						Console.WriteLine("WARNING: Data tidak valid");
					}
					this.SaveFileOnUIThread1(list);
					Console.WriteLine(string.Format("Total: {0} bytes", list.Count));
					return;
				}
				base.Invoke(new Action(delegate()
				{
					this.lblStatus.Text = " Gagal menginisialisasi FTDI. ";
					CustomMessageBoxSMK.Show("Gagal menginisialisasi FTDI. Periksa koneksi Anda.", "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
				}));
			}
		}

		// Token: 0x06000C3E RID: 3134 RVA: 0x0005B870 File Offset: 0x0005B870
		private void SaveFileOnUIThread(List<byte> collectedData)
		{
			base.Invoke(new MethodInvoker(delegate()
			{
				string text = "C:\\Users\\S'COM\\Desktop\\File EEPROM READ ID";
				string path = "File EEPROM READ ID .bin";
				string text2 = Path.Combine(text, path);
				if (!Directory.Exists(text))
				{
					Directory.CreateDirectory(text);
				}
				File.WriteAllBytes(text2, collectedData.ToArray());
				Console.WriteLine("Data berhasil disimpan ke: " + text2);
				this.progressBar1.Value = 0;
				this.baca();
			}));
		}

		// Token: 0x06000C3F RID: 3135 RVA: 0x0005B8A4 File Offset: 0x0005B8A4
		private void SaveFileOnUIThread1(List<byte> collectedData)
		{
			base.Invoke(new MethodInvoker(delegate()
			{
				string text = "C:\\File EEPROM READ ID";
				object selectedItem = this.comboBox1.SelectedItem;
				string arg = ((selectedItem != null) ? selectedItem.ToString() : null) ?? "Default";
				string path = string.Format("{0}{1: dd-MM-yyyy}.bin", arg, DateTime.Now);
				string text2 = Path.Combine(text, path);
				if (!Directory.Exists(text))
				{
					Directory.CreateDirectory(text);
				}
				try
				{
					File.WriteAllBytes(text2, collectedData.ToArray());
					Console.WriteLine("Data berhasil disimpan ke: " + text2);
					this.progressBar1.Value = 0;
					this.baca();
				}
				catch (Exception ex)
				{
					Console.WriteLine("Gagal menyimpan file: " + ex.Message);
				}
			}));
		}

		// Token: 0x06000C40 RID: 3136 RVA: 0x0005B8D8 File Offset: 0x0005B8D8
		private void baca()
		{
			try
			{
				if (this.binBytes == null)
				{
					CustomMessageBox__0.Show("Tidak ada data yang dikumpulkan. Silakan jalankan fungsi EEPROM terlebih dahulu.", "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
				}
				else if (this.comboBox1.SelectedItem.ToString() == "VARIO 150 - 30400-K59J-A71")
				{
					if (this.binBytes.Length >= 88)
					{
						this.ProcessPcxValues(new byte[]
						{
							this.binBytes[144],
							this.binBytes[145]
						}, new byte[]
						{
							this.binBytes[160],
							this.binBytes[161]
						});
					}
					else
					{
						CustomMessageBox__0.Show("Gagal Read Data\r\nRestart your ECM\r\nUlangi Dari Awal", "READ ECM ID", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
				else if (this.comboBox1.SelectedItem.ToString() == "ADV 150 - 30400-K0WA-N01")
				{
					if (this.binBytes.Length >= 88)
					{
						this.ProcessPcxValues(new byte[]
						{
							this.binBytes[64],
							this.binBytes[65]
						}, new byte[]
						{
							this.binBytes[80],
							this.binBytes[81]
						});
					}
					else
					{
						CustomMessageBox__0.Show("Gagal Read Data\r\nRestart your ECM\r\nUlangi Dari Awal", "READ ECM ID", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
				else if (this.comboBox1.SelectedItem.ToString() == "PCX 150 - 30400-K97G-NXX")
				{
					if (this.binBytes.Length >= 88)
					{
						this.ProcessPcxValues(new byte[]
						{
							this.binBytes[64],
							this.binBytes[65]
						}, new byte[]
						{
							this.binBytes[80],
							this.binBytes[81]
						});
					}
					else
					{
						CustomMessageBox__0.Show("Gagal Read Data\r\nRestart your ECM\r\nUlangi Dari Awal", "READ ECM ID", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
				else if (this.comboBox1.SelectedItem.ToString() == "VARIO 125 - 30400-K2VG-N42")
				{
					if (this.binBytes.Length >= 88)
					{
						this.ProcessPcxValues(new byte[]
						{
							this.binBytes[60],
							this.binBytes[61]
						}, new byte[]
						{
							this.binBytes[62],
							this.binBytes[63]
						});
					}
					else
					{
						CustomMessageBox__0.Show("Gagal Read Data\r\nRestart your ECM\r\nUlangi Dari Awal", "READ ECM ID", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
				else if (this.comboBox1.SelectedItem.ToString() == "PCX 160 - 30400-K1ZG-NXX")
				{
					if (this.binBytes.Length >= 88)
					{
						this.ProcessPcxValues(new byte[]
						{
							this.binBytes[64],
							this.binBytes[65]
						}, new byte[]
						{
							this.binBytes[76],
							this.binBytes[77]
						});
					}
					else
					{
						CustomMessageBox__0.Show("Gagal Read Data\r\nRestart your ECM\r\nUlangi Dari Awal", "READ ECM ID", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
				else if (this.comboBox1.SelectedItem.ToString() == "PCX 160 - 30400-K1ZN-NXX")
				{
					if (this.binBytes.Length >= 88)
					{
						this.ProcessPcxValues(new byte[]
						{
							this.binBytes[64],
							this.binBytes[65]
						}, new byte[]
						{
							this.binBytes[76],
							this.binBytes[77]
						});
					}
					else
					{
						CustomMessageBox__0.Show("Gagal Read Data\r\nRestart your ECM\r\nUlangi Dari Awal", "READ ECM ID", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
				else if (this.comboBox1.SelectedItem.ToString() == "BEAT 110 - 30400-K1AL-NB1")
				{
					if (this.binBytes.Length >= 88)
					{
						this.ProcessPcxValues(new byte[]
						{
							this.binBytes[60],
							this.binBytes[61]
						}, new byte[]
						{
							this.binBytes[62],
							this.binBytes[63]
						});
					}
					else
					{
						CustomMessageBox__0.Show("Gagal Read Data\r\nRestart your ECM\r\nUlangi Dari Awal", "READ ECM ID", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
				else if (this.comboBox1.SelectedItem.ToString() == "STYLO 160 - 30400-K3VA-N01")
				{
					if (this.binBytes.Length >= 88)
					{
						this.ProcessPcxValues(new byte[]
						{
							this.binBytes[60],
							this.binBytes[61]
						}, new byte[]
						{
							this.binBytes[62],
							this.binBytes[63]
						});
					}
					else
					{
						CustomMessageBox__0.Show("Gagal Read Data\r\nRestart your ECM\r\nUlangi Dari Awal", "READ ECM ID", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
				else if (this.comboBox1.SelectedItem.ToString() == "VARIO 160 - 30400-K2SA-N02")
				{
					if (this.binBytes.Length >= 88)
					{
						this.ProcessPcxValues(new byte[]
						{
							this.binBytes[60],
							this.binBytes[61]
						}, new byte[]
						{
							this.binBytes[62],
							this.binBytes[63]
						});
					}
					else
					{
						CustomMessageBox__0.Show("Gagal Read Data\r\nRestart your ECM\r\nUlangi Dari Awal", "READ ECM ID", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
				else if (this.comboBox1.SelectedItem.ToString() == "ADV 160 - 30400-K0WL-NXX")
				{
					if (this.binBytes.Length >= 88)
					{
						this.ProcessPcxValues(new byte[]
						{
							this.binBytes[64],
							this.binBytes[65]
						}, new byte[]
						{
							this.binBytes[76],
							this.binBytes[77]
						});
					}
					else
					{
						CustomMessageBox__0.Show("Gagal Read Data\r\nRestart your ECM\r\nUlangi Dari Awal", "READ ECM ID", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
				else if (this.comboBox1.SelectedItem.ToString() == "SCOOPY 110 - 30400-K2F-NXX")
				{
					if (this.binBytes.Length >= 88)
					{
						this.ProcessKEIHIN(new byte[]
						{
							this.binBytes[70],
							this.binBytes[71]
						}, new byte[]
						{
							this.binBytes[72],
							this.binBytes[73]
						});
					}
					else
					{
						CustomMessageBox__0.Show("Gagal Read Data\r\nRestart your ECM\r\nUlangi Dari Awal", "READ ECM ID", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
			}
			catch (Exception ex)
			{
				CustomMessageBox__0.Show("Terjadi kesalahan saat memproses data: " + ex.Message, "READ ECM ID", MessageBoxButtons.OK, MessageBoxIcon.None);
			}
		}

		// Token: 0x06000C41 RID: 3137 RVA: 0x0005BF08 File Offset: 0x0005BF08
		private void ProcessPcxValueskh(byte[] firstValue, byte[] secondValue)
		{
			try
			{
				string str = BitConverter.ToString(firstValue).Replace("-", "");
				string str2 = BitConverter.ToString(secondValue).Replace("-", "");
				string text = str + str2;
				if (text.Length == 8)
				{
					if (text == "00000000")
					{
						SMK.ecmIdStr = "000000000";
					}
					else
					{
						string hex = text.Substring(0, 4);
						string hex2 = this.SwapBytes(hex);
						string hex3 = this.RightShift(hex2, 2);
						string str3 = this.SubtractHex(hex3, "2000");
						string hex4 = text.Substring(4, 4);
						string hex5 = this.XorHex(hex4, "80");
						string str4 = this.SwapBytes(hex5);
						SMK.ecmIdStr = Convert.ToInt64(str3 + str4, 16).ToString().PadLeft(9, '0');
						this.textBox3.Text = SMK.ecmIdStr;
						this.textBox2.Text = SMK.ecmIdStr;
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000C42 RID: 3138 RVA: 0x00008D06 File Offset: 0x00008D06
		private string SwapBytes(string hex)
		{
			if (hex.Length != 4)
			{
				throw new FormatException("DATA ERROR");
			}
			return hex.Substring(2, 2) + hex.Substring(0, 2);
		}

		// Token: 0x06000C43 RID: 3139 RVA: 0x0005C014 File Offset: 0x0005C014
		private string RightShift(string hex, int shift)
		{
			return (Convert.ToInt32(hex, 16) >> shift).ToString("X4");
		}

		// Token: 0x06000C44 RID: 3140 RVA: 0x0005C03C File Offset: 0x0005C03C
		private string SubtractHex(string hex1, string hex2)
		{
			return (checked(Convert.ToInt32(hex1, 16) - Convert.ToInt32(hex2, 16))).ToString("X4");
		}

		// Token: 0x06000C45 RID: 3141 RVA: 0x0005C068 File Offset: 0x0005C068
		private string XorHex(string hex1, string hex2)
		{
			return (Convert.ToInt32(hex1, 16) ^ Convert.ToInt32(hex2, 16)).ToString("X4");
		}

		// Token: 0x06000C46 RID: 3142 RVA: 0x0005C094 File Offset: 0x0005C094
		private void ProcessKEIHIN(byte[] firstValue, byte[] secondValue)
		{
			string str = BitConverter.ToString(firstValue).Replace("-", " ");
			string str2 = BitConverter.ToString(secondValue).Replace("-", " ");
			checked
			{
				try
				{
					string[] array = (str2 + " " + str).Split(new char[]
					{
						' ',
						',',
						'-',
						':'
					}, StringSplitOptions.RemoveEmptyEntries);
					if (array.Length % 4 != 0)
					{
						CustomMessageBox__0.Show("Jumlah byte harus kelipatan 4.", "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
					else
					{
						for (int i = 0; i < array.Length; i += 4)
						{
							uint num = (uint)this.ConvertInputToByte(array[i]);
							byte b = this.ConvertInputToByte(array[i + 1]);
							byte b2 = this.ConvertInputToByte(array[i + 2]);
							uint num2 = (uint)((int)this.ConvertInputToByte(array[i + 3]) << 8 | (int)b2);
							uint num3 = num << 16 | (uint)((uint)b << 24) | num2;
							num3.ToString().PadLeft(9, '0');
							this.value1 = Convert.ToByte(num3 >> 16 & 255U);
							this.value2 = Convert.ToByte(num3 >> 24 & 255U);
							this.value3 = Convert.ToByte(num3 & 255U);
							this.value4 = Convert.ToByte(num3 >> 8 & 255U);
							string text = string.Format("{0:X2} {1:X2} {2:X2} {3:X2}", new object[]
							{
								this.value3,
								this.value4,
								this.value1,
								this.value2
							});
							this.textBox3.Text = text;
							this.textBox3_TextChanged();
						}
					}
				}
				catch (Exception ex)
				{
					CustomMessageBox__0.Show("Terjadi kesalahan: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
				}
			}
		}

		// Token: 0x06000C47 RID: 3143 RVA: 0x0005C26C File Offset: 0x0005C26C
		private void textBox3_TextChanged()
		{
			string[] array = this.textBox3.Text.Trim().Split(new char[]
			{
				' '
			});
			if (array.Length < 4)
			{
				CustomMessageBox__0.Show("Input harus terdiri dari 4 byte hexadecimal, dipisahkan oleh spasi.", "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
				return;
			}
			try
			{
				int num = Convert.ToInt32(array[0], 16);
				int num2 = Convert.ToInt32(array[1], 16);
				int num3 = Convert.ToInt32(array[2], 16);
				int num4 = Convert.ToInt32(array[3], 16);
				long num5 = (long)(num2 << 8 | num);
				long num6 = (long)(num4 << 8 | num3);
				checked
				{
					long num7 = (num5 * 65536L >> 2) - 536870912L;
					long num8 = num6 ^ 32768L;
					long num9 = num7 + num8;
					this.textBox2.Text = num9.ToString("D9");
				}
			}
			catch (Exception ex)
			{
				CustomMessageBox__0.Show("Error in conversion: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
			}
		}

		// Token: 0x06000C48 RID: 3144 RVA: 0x0005C35C File Offset: 0x0005C35C
		private void ProcessPcxValues(byte[] firstValue, byte[] secondValue)
		{
			string str = BitConverter.ToString(firstValue).Replace("-", " ");
			string str2 = BitConverter.ToString(secondValue).Replace("-", " ");
			checked
			{
				try
				{
					string[] array = (str2 + " " + str).Split(new char[]
					{
						' ',
						',',
						'-',
						':'
					}, StringSplitOptions.RemoveEmptyEntries);
					if (array.Length % 4 != 0)
					{
						CustomMessageBox__0.Show("Jumlah byte harus kelipatan 4.", "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
					else
					{
						this.textBox2.Text = "";
						for (int i = 0; i < array.Length; i += 4)
						{
							byte b = this.ConvertInputToByte(array[i]);
							uint num = (uint)this.ConvertInputToByte(array[i + 1]);
							byte b2 = this.ConvertInputToByte(array[i + 2]);
							uint num2 = (uint)((int)this.ConvertInputToByte(array[i + 3]) << 8 | (int)b2);
							uint num3 = num << 24 | (uint)((uint)b << 16) | num2;
							string text = num3.ToString().PadLeft(9, '0');
							this.textBox2.Text = (text ?? "");
							this.value1 = Convert.ToByte(num3 >> 16 & 255U);
							this.value2 = Convert.ToByte(num3 >> 24 & 255U);
							this.value3 = Convert.ToByte(num3 & 255U);
							this.value4 = Convert.ToByte(num3 >> 8 & 255U);
						}
					}
				}
				catch (Exception ex)
				{
					CustomMessageBox__0.Show("Terjadi kesalahan: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
				}
			}
		}

		// Token: 0x06000C49 RID: 3145 RVA: 0x00008D31 File Offset: 0x00008D31
		private byte ConvertInputToByte(string input)
		{
			if (string.IsNullOrEmpty(input))
			{
				throw new ArgumentException("Input tidak boleh kosong.");
			}
			return Convert.ToByte(input, 16);
		}

		// Token: 0x06000C4A RID: 3146 RVA: 0x0005C4FC File Offset: 0x0005C4FC
		private async void button1_Click(object sender, EventArgs e)
		{
			if (this.comboBox1.SelectedItem == null)
			{
				CustomMessageBox__0.Show("Tidak Dapat Dijalankan. Silakan Pilih Type ECM terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.None);
			}
			else
			{
				string item = this.comboBox1.SelectedItem.ToString();
				HashSet<string> hashSet = new HashSet<string>(StringComparer.Ordinal)
				{
					"SCOOPY 110 - 30400-K2F-NXX"
				};
				HashSet<string> hashSet2 = new HashSet<string>(StringComparer.Ordinal)
				{
					"VARIO 150 - 30400-K59J-A71",
					"ADV 150 - 30400-K0WA-N01",
					"PCX 150 - 30400-K97G-NXX",
					"VARIO 125 - 30400-K2VG-N42",
					"PCX 160 - 30400-K1ZG-NXX",
					"PCX 160 - 30400-K1ZN-NXX",
					"BEAT 110 - 30400-K1AL-NB1",
					"STYLO 160 - 30400-K3VA-N01",
					"VARIO 160 - 30400-K2SA-N02",
					"ADV 160 - 30400-K0WL-NXX"
				};
				try
				{
					if (hashSet.Contains(item))
					{
						this.label1.Text = " \ud83d\udd11 READ ID BARCODE ";
						this.lblStatus.Text = "⏳ OFF-ON Kontak Untuk Konek ke EEprom";
						await Task.Delay(2000);
						if (this.eepromThread == null || !this.eepromThread.IsAlive)
						{
							this.eepromThread = new Thread(new ThreadStart(this.eeprom1))
							{
								IsBackground = true
							};
							this.eepromThread.Start();
						}
					}
					else if (hashSet2.Contains(item))
					{
						this.label1.Text = " \ud83d\udd11 READ ID BARCODE ";
						this.lblStatus.Text = "⏳ OFF-ON Kontak Untuk Konek ke EEprom";
						await Task.Delay(2000);
						if (this.eepromThread == null || !this.eepromThread.IsAlive)
						{
							this.eepromThread = new Thread(new ThreadStart(this.eeprom))
							{
								IsBackground = true
							};
							this.eepromThread.Start();
						}
					}
					else
					{
						CustomMessageBox__0.Show("Model tidak ditemukan.", "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
				catch (Exception ex)
				{
					CustomMessageBox__0.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
				}
			}
		}

		// Token: 0x06000C4B RID: 3147 RVA: 0x0005C538 File Offset: 0x0005C538
		private async void button2_Click(object sender, EventArgs e)
		{
			if (this.comboBox1.SelectedItem == null)
			{
				CustomMessageBox__0.Show("Tidak Dapat Dijalankan. Silakan Pilih Type ECM terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.None);
			}
			else
			{
				try
				{
					this.lblStatus.Text = " OFF-ON Kontak Untuk Konek ke EEprom";
					await Task.Delay(3000);
					if (this.eepromThread == null || !this.eepromThread.IsAlive)
					{
						this.eepromThread = new Thread(new ThreadStart(this.eepromkeihin3))
						{
							IsBackground = true
						};
						this.eepromThread.Start();
					}
					else
					{
						CustomMessageBox__0.Show("Process is already running.", "Info", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
				catch (Exception ex)
				{
					CustomMessageBox__0.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
				}
			}
		}

		// Token: 0x06000C4C RID: 3148 RVA: 0x0005C574 File Offset: 0x0005C574
		private void eepromkeihin3()
		{
			this.lblStatus.Text = " PROSES RESET EEPROM KEIHIN ,Silahkan tunggu sebentar ";
			byte[] array = new byte[]
			{
				254,
				4,
				114,
				140
			};
			byte[] array2 = new byte[]
			{
				114,
				5,
				0,
				240,
				153
			};
			byte[] array3 = new byte[]
			{
				39,
				11,
				224,
				72,
				101,
				108,
				108,
				111,
				72,
				111,
				67
			};
			byte[] array4 = new byte[]
			{
				39,
				11,
				224,
				119,
				65,
				114,
				101,
				89,
				111,
				117,
				34
			};
			byte[] array5 = new byte[256];
			byte[] array6 = new byte[]
			{
				130,
				130,
				16,
				6,
				0,
				230
			};
			byte[] array7 = new byte[]
			{
				130,
				130,
				16,
				6,
				1,
				229
			};
			uint num = 0U;
			checked
			{
				if (this.InitFtdiIso())
				{
					base.Invoke(new MethodInvoker(delegate()
					{
						this.progressBar1.Maximum = 256;
						this.progressBar1.Value = 0;
					}));
					if (this.SendCommand6(array, array.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response: " + BitConverter.ToString(array5, 0, (int)num));
					}
					Thread.Sleep(150);
					if (this.SendCommand6(array2, array2.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response: " + BitConverter.ToString(array5, 0, (int)num));
					}
					Thread.Sleep(150);
					if (this.SendCommand6(array3, array3.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response: " + BitConverter.ToString(array5, 0, (int)num));
					}
					Thread.Sleep(150);
					if (this.SendCommand6(array4, array4.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response2: " + BitConverter.ToString(array5, 0, (int)num));
						if (num < 13U)
						{
							CustomMessageBoxSMK.Show("Security Access Failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
							return;
						}
					}
					if (this.SendCommand6(array6, array6.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response7: " + BitConverter.ToString(array5, 0, (int)num));
					}
					if (this.SendCommand6(array7, array7.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response8: " + BitConverter.ToString(array5, 0, (int)num));
					}
					for (int i = 0; i <= 255; i++)
					{
						byte[] array8 = new byte[]
						{
							130,
							130,
							16,
							6,
							0,
							0
						};
						array8[4] = (byte)i;
						array8[5] = (byte)(256 - (282 + i) % 256);
						this.SendCommand6(array8, array8.Length, ref array5, ref num, 0);
						if (num > 12U)
						{
							for (int j = 10; j < (int)Math.Min(num, 12U); j++)
							{
								if (j == 10 || j == 11)
								{
									this.collectedData2.Add(array5[j]);
								}
							}
						}
						int current = i;
						base.Invoke(new MethodInvoker(delegate()
						{
							this.progressBar1.Value = current + 1;
						}));
					}
					this.binBytes = this.collectedData2.ToArray();
					if (this.collectedData2.Count >= 74)
					{
						this.collectedData2[70] = 0;
						this.collectedData2[71] = 0;
						this.collectedData2[72] = 0;
						this.collectedData2[73] = 0;
					}
					int count = this.collectedData2.Count;
					for (int k = 0; k < 256; k++)
					{
						int num2 = k * 2 % count;
						byte b = (count > 0 && num2 < count) ? this.collectedData2[num2] : 0;
						byte b2 = (count > 0) ? this.collectedData2[(num2 + 1) % count] : 0;
						byte[] array9 = new byte[]
						{
							130,
							130,
							20,
							8,
							0,
							0,
							0,
							0
						};
						array9[4] = (byte)k;
						array9[5] = b;
						array9[6] = b2;
						array9[7] = (byte)(256 - (288 + (int)((byte)k) + (int)b) % 256);
						this.SendCommand6(array9, array9.Length, ref array5, ref num, 0);
						int currentY = k;
						base.Invoke(new MethodInvoker(delegate()
						{
							this.progressBar1.Value = currentY + 1;
						}));
					}
					base.Invoke(new MethodInvoker(delegate()
					{
						this.textBox2.Text = "000000000";
						this.lblStatus.Text = " Reset EEPROM KEIHIN SELESAI !!! ";
					}));
				}
			}
		}

		// Token: 0x06000C4D RID: 3149 RVA: 0x0005C988 File Offset: 0x0005C988
		private async void button3_Click(object sender, EventArgs e)
		{
			if (this.comboBox1.SelectedItem == null)
			{
				CustomMessageBox__0.Show("Tidak Dapat Dijalankan. Silakan Pilih Type ECM terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.None);
			}
			else
			{
				try
				{
					this.lblStatus.Text = " OFF-ON KONTAK UNTUK KONEK KE EEPROM ... ";
					await Task.Delay(3000);
					if (this.eepromThread == null || !this.eepromThread.IsAlive)
					{
						this.eepromThread = new Thread(new ThreadStart(this.eeprom3))
						{
							IsBackground = true
						};
						this.eepromThread.Start();
					}
					else
					{
						CustomMessageBox__0.Show("Process is already running.", "Info", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
				catch (Exception ex)
				{
					CustomMessageBox__0.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
				}
			}
		}

		// Token: 0x06000C4E RID: 3150 RVA: 0x0005C9C4 File Offset: 0x0005C9C4
		private void eeprom3()
		{
			this.lblStatus.Text = " PROSES RESET ID SHINDENGEN ,Silahkan tunggu sebentar ";
			byte[] array = new byte[]
			{
				254,
				4,
				114,
				140
			};
			byte[] array2 = new byte[]
			{
				114,
				5,
				0,
				240,
				153
			};
			byte[] array3 = new byte[]
			{
				145,
				145,
				13,
				223,
				158,
				141,
				154,
				134,
				144,
				138,
				140,
				155,
				136
			};
			byte[] array4 = new byte[]
			{
				145,
				145,
				13,
				223,
				146,
				158,
				134,
				150,
				139,
				141,
				134,
				192,
				106
			};
			byte[] array5 = new byte[256];
			uint num = 0U;
			List<byte> list = new List<byte>();
			checked
			{
				if (this.InitFtdiIso())
				{
					base.Invoke(new MethodInvoker(delegate()
					{
						this.progressBar1.Maximum = 256;
						this.progressBar1.Value = 0;
					}));
					if (this.SendCommand6(array, array.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response: " + BitConverter.ToString(array5, 0, (int)num));
					}
					Thread.Sleep(150);
					if (this.SendCommand6(array2, array2.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response: " + BitConverter.ToString(array5, 0, (int)num));
					}
					Thread.Sleep(150);
					if (this.SendCommand6(array3, array3.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response: " + BitConverter.ToString(array5, 0, (int)num));
					}
					Thread.Sleep(150);
					if (this.SendCommand6(array4, array4.Length, ref array5, ref num, 0))
					{
						Console.WriteLine("Response2: " + BitConverter.ToString(array5, 0, (int)num));
						if (num < 15U)
						{
							CustomMessageBoxSMK.Show("Security Access Failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
							return;
						}
					}
					for (int i = 0; i <= 255; i++)
					{
						byte[] array6 = new byte[]
						{
							145,
							145,
							7,
							64,
							0,
							0,
							0
						};
						this.SendCommand6(array6, array6.Length, ref array5, ref num, 0);
						if (num > 12U)
						{
							for (int j = 11; j < (int)Math.Min(num, 13U); j++)
							{
								if (j == 11 || j == 12)
								{
									list.Add(array5[j]);
								}
							}
						}
						int current = i;
						base.Invoke(new MethodInvoker(delegate()
						{
							this.progressBar1.Value = current + 1;
						}));
					}
					this.binBytes = list.ToArray();
					int num2 = 32;
					while (num2 <= 175 && num2 < this.binBytes.Length)
					{
						this.binBytes[num2] = 0;
						num2++;
					}
					for (int k = 0; k < 256; k++)
					{
						byte[] array7 = new byte[]
						{
							145,
							145,
							9,
							65,
							0,
							0,
							0,
							0,
							0
						};
						this.SendCommand6(array7, array7.Length, ref array5, ref num, 0);
						int currentY = k;
						base.Invoke(new MethodInvoker(delegate()
						{
							this.progressBar1.Value = currentY + 1;
						}));
					}
					base.Invoke(new MethodInvoker(delegate()
					{
						this.textBox2.Text = "000000000";
						this.lblStatus.Text = " PROSES RESET ID SHINDENGEN SELESAI !!! ";
					}));
				}
			}
		}

		// Token: 0x06000C4F RID: 3151 RVA: 0x0005CC98 File Offset: 0x0005CC98
		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (this.comboBox1.SelectedItem == null)
			{
				return;
			}
			string a = this.comboBox1.SelectedItem.ToString();
			if (a == "TYPE ECM")
			{
				this.lblStatus.Text = "\ud83d\udd0d Silahkan pilih type ECM terlebih dahulu";
				this.textBox2.Text = "000000000";
				this.textBox1.Text = "";
				return;
			}
			foreach (string b in new string[]
			{
				"PCX 160 - 30400-K1ZG-NXX",
				"PCX 160 - 30400-K1ZN-NXX",
				"ADV 150 - 30400-K0WA-N01",
				"ADV 160 - 30400-K0WL-NXX",
				"STYLO 160 - 30400-K3VA-N01",
				"SCOOPY 110 - 30400-K2F-NXX",
				"VARIO 160 - 30400-K2SA-N02",
				"PCX 150 - 30400-K97G-NXX",
				"VARIO 125 - 30400-K2VG-N42",
				"BEAT 110 - 30400-K1AL-NB1",
				"VARIO 150 - 30400-K59J-A71"
			})
			{
				if (a == b)
				{
					this.lblStatus.Text = "\ud83d\udd0d Silahkan pilih Menu Read atau Reset";
					return;
				}
			}
		}

		// Token: 0x06000C50 RID: 3152 RVA: 0x00008D4E File Offset: 0x00008D4E
		private void SMK_Load(object sender, EventArgs e)
		{
			this.textBox2.Text = "\ud83d\udd11 ---------";
			this.lblStatus.Text = "\ud83d\udd0d Silahkan pilih type ECM terlebih dahulu";
		}

		// Token: 0x06000C53 RID: 3155 RVA: 0x0005D8D8 File Offset: 0x0005D8D8
		static SMK()
		{
			SMK.ftHandle = IntPtr.Zero;
		}

		// Token: 0x06000C54 RID: 3156 RVA: 0x00008D8F File Offset: 0x00008D8F
		private void SetUiForRead()
		{
			this.label1.Text = " \ud83d\udd11 READ ID BARCODE ";
			this.lblStatus.Text = "⏳ OFF-ON Kontak Untuk Konek ke EEprom";
		}

		// Token: 0x06000C55 RID: 3157 RVA: 0x00024C64 File Offset: 0x00024C64
		private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			checked
			{
				int num = radius * 2;
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x06000C56 RID: 3158 RVA: 0x0005D9CC File Offset: 0x0005D9CC
		private void ApplyRoundedFormRegion()
		{
			using (GraphicsPath roundedPath = this.GetRoundedPath(new Rectangle(0, 0, base.Width, base.Height), 14))
			{
				base.Region = new Region(roundedPath);
			}
		}

		// Token: 0x06000C57 RID: 3159 RVA: 0x0005DA20 File Offset: 0x0005DA20
		private void ApplyHeaderAndDrag()
		{
			checked
			{
				RoundedButton roundedButton = new RoundedButton
				{
					Text = "✕",
					Size = new Size(28, 28),
					Location = new Point(base.Width - 44, 28),
					BackColor = SMK.BgSurface,
					ForeColor = SMK.AccentSoft,
					Font = new Font("Segoe UI", 9f, FontStyle.Bold),
					Cursor = Cursors.Hand,
					TabStop = false,
					Anchor = (AnchorStyles.Top | AnchorStyles.Right),
					CornerRadius = 14,
					BorderColor = SMK.BorderSoft,
					BorderWidth = 1f,
					HoverBackColor = Color.FromArgb(220, 50, 50)
				};
				roundedButton.Click += delegate(object s, EventArgs e)
				{
					this.Close();
				};
				base.Controls.Add(roundedButton);
				roundedButton.BringToFront();
				bool dragging = false;
				Point dragStart = Point.Empty;
				base.MouseDown += delegate(object s, MouseEventArgs e)
				{
					if (e.Button == MouseButtons.Left && e.Y <= 78)
					{
						dragging = true;
						dragStart = e.Location;
					}
				};
				base.MouseMove += delegate(object s, MouseEventArgs e)
				{
					if (dragging)
					{
						this.Location = new Point(this.Location.X + e.X - dragStart.X, this.Location.Y + e.Y - dragStart.Y);
					}
				};
				base.MouseUp += delegate(object s, MouseEventArgs e)
				{
					dragging = false;
				};
				base.KeyPreview = true;
				base.KeyDown += delegate(object s, KeyEventArgs e)
				{
					if (e.KeyCode == Keys.Escape)
					{
						this.Close();
					}
				};
				base.Paint += delegate(object s, PaintEventArgs e)
				{
					Graphics graphics = e.Graphics;
					graphics.SmoothingMode = SmoothingMode.AntiAlias;
					graphics.PixelOffsetMode = PixelOffsetMode.Half;
					int width = this.ClientSize.Width;
					int height = this.ClientSize.Height;
					using (Pen pen = new Pen(Color.FromArgb(80, SMK.Accent), 3f))
					{
						using (GraphicsPath roundedPath = this.GetRoundedPath(new Rectangle(2, 2, width - 4, height - 4), 12))
						{
							graphics.DrawPath(pen, roundedPath);
						}
					}
					using (Pen pen2 = new Pen(SMK.Accent, 1.5f))
					{
						using (GraphicsPath roundedPath2 = this.GetRoundedPath(new Rectangle(2, 2, width - 4, height - 4), 12))
						{
							graphics.DrawPath(pen2, roundedPath2);
						}
					}
					using (Pen pen3 = new Pen(SMK.BorderSoft, 1f))
					{
						using (GraphicsPath roundedPath3 = this.GetRoundedPath(new Rectangle(4, 4, width - 8, height - 8), 10))
						{
							graphics.DrawPath(pen3, roundedPath3);
						}
					}
				};
				base.Resize += delegate(object s, EventArgs e)
				{
					this.ApplyRoundedFormRegion();
					this.Invalidate();
				};
			}
		}

		// Token: 0x06000C58 RID: 3160 RVA: 0x0005DB94 File Offset: 0x0005DB94
		private byte CalcChecksumShindengen(byte[] data, int length)
		{
			if (data == null || length <= 0)
			{
				return 0;
			}
			int num = 0;
			for (int i = 0; i < length; i++)
			{
				num += (int)data[i];
			}
			return checked((byte)(num & 255));
		}

		// Token: 0x06000C60 RID: 3168 RVA: 0x0005DBC8 File Offset: 0x0005DBC8
		private byte CalcChecksumHondaKLine(byte[] data, int length)
		{
			if (data == null)
			{
				throw new ArgumentNullException("data");
			}
			if (length < 0 || length > data.Length)
			{
				throw new ArgumentOutOfRangeException("length");
			}
			int num = 0;
			checked
			{
				for (int i = 0; i < length; i++)
				{
					num += (int)data[i];
				}
			}
			return (byte)(256 - (num & 255));
		}

		// Token: 0x04000E1A RID: 3610
		private static IntPtr ftHandle;

		// Token: 0x04000E1B RID: 3611
		private byte[] binBytes;

		// Token: 0x04000E1C RID: 3612
		private static string ecmIdStr;

		// Token: 0x04000E1D RID: 3613
		private Thread eepromThread;

		// Token: 0x04000E1E RID: 3614
		private byte value1;

		// Token: 0x04000E1F RID: 3615
		private byte value2;

		// Token: 0x04000E20 RID: 3616
		private byte value3;

		// Token: 0x04000E21 RID: 3617
		private byte value4;

		// Token: 0x04000E22 RID: 3618
		private List<byte> collectedData2 = new List<byte>();

		// Token: 0x04000E34 RID: 3636
		private static readonly Color AccentSoft = Color.FromArgb(120, 200, 230);

		// Token: 0x04000E37 RID: 3639
		private static readonly Color Success = Color.FromArgb(74, 222, 128);

		// Token: 0x04000E38 RID: 3640
		private static readonly Color Warning = Color.FromArgb(250, 204, 21);

		// Token: 0x04000E39 RID: 3641
		private static readonly Color Danger = Color.FromArgb(248, 113, 113);
	}
}
