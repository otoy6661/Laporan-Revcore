﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000575 RID: 1397
	public partial class Form2 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000D9D RID: 3485 RVA: 0x000097EE File Offset: 0x000097EE
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000D9E RID: 3486 RVA: 0x00067A68 File Offset: 0x00067A68
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Honda_Flash_Tools.Net.MainForm));
			try
			{
				base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			}
			catch
			{
			}
			this.lblRemappingMode = new global::System.Windows.Forms.Label();
			this.lblVersion = new global::System.Windows.Forms.Label();
			this.lblCopyright = new global::System.Windows.Forms.Label();
			this.lblRenew = new global::System.Windows.Forms.Label();
			this.lblEcuMode = new global::System.Windows.Forms.Label();
			this.pictureBoxLogo = new global::System.Windows.Forms.PictureBox();
			this.btnOk = new global::Honda_Flash_Tools.Net.RoundedButton();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBoxLogo).BeginInit();
			base.SuspendLayout();
			this.lblRemappingMode.Text = "Remapping Mode\r\nDiagnostic Tools\r\nRead Id Smartkey";
			this.lblRemappingMode.AutoSize = true;
			this.lblRemappingMode.ForeColor = global::Honda_Flash_Tools.Net.Form2.ForeColorDefault;
			this.lblRemappingMode.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.lblRemappingMode.BackColor = global::System.Drawing.Color.Transparent;
			this.lblRemappingMode.Location = new global::System.Drawing.Point(168, 12);
			this.lblVersion.Text = "Version 2.0.2.6";
			this.lblVersion.AutoSize = true;
			this.lblVersion.ForeColor = global::Honda_Flash_Tools.Net.Form2.NeonCyan;
			this.lblVersion.Font = new global::System.Drawing.Font("Segoe UI", 8.5f, global::System.Drawing.FontStyle.Bold);
			this.lblVersion.BackColor = global::System.Drawing.Color.Transparent;
			this.lblVersion.Location = new global::System.Drawing.Point(168, 52);
			this.lblCopyright.Text = "No Crack!!!\r\nCopyright (c) 2026";
			this.lblCopyright.AutoSize = true;
			this.lblCopyright.ForeColor = global::Honda_Flash_Tools.Net.Form2.ForeMuted;
			this.lblCopyright.Font = new global::System.Drawing.Font("Segoe UI", 7.5f, global::System.Drawing.FontStyle.Italic);
			this.lblCopyright.BackColor = global::System.Drawing.Color.Transparent;
			this.lblCopyright.Location = new global::System.Drawing.Point(168, 65);
			this.lblRenew.Text = "";
			this.lblRenew.Visible = false;
			this.lblEcuMode.Text = "";
			this.lblEcuMode.Visible = false;
			try
			{
				this.pictureBoxLogo.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			}
			catch
			{
			}
			this.pictureBoxLogo.Location = new global::System.Drawing.Point(12, 12);
			this.pictureBoxLogo.Size = new global::System.Drawing.Size(150, 90);
			this.pictureBoxLogo.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBoxLogo.BackColor = global::System.Drawing.Color.Transparent;
			this.pictureBoxLogo.TabStop = false;
			this.btnOk.Text = "OK";
			this.btnOk.ForeColor = global::Honda_Flash_Tools.Net.Form2.NeonGreen;
			this.btnOk.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Bold);
			this.btnOk.Location = new global::System.Drawing.Point(12, 115);
			this.btnOk.Size = new global::System.Drawing.Size(150, 30);
			this.btnOk.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.btnOk.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.btnOk.Click += new global::System.EventHandler(this.button1_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(5f, 11f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(280, 160);
			this.BackColor = global::Honda_Flash_Tools.Net.Form2.BackPanel;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.ShowInTaskbar = false;
			this.Text = "Honda Remap Mode";
			base.Padding = new global::System.Windows.Forms.Padding(16);
			base.Controls.Add(this.btnOk);
			base.Controls.Add(this.pictureBoxLogo);
			base.Controls.Add(this.lblCopyright);
			base.Controls.Add(this.lblVersion);
			base.Controls.Add(this.lblRemappingMode);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBoxLogo).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
			checked
			{
				base.Paint += delegate(object s, global::System.Windows.Forms.PaintEventArgs e)
				{
					e.Graphics.SmoothingMode = global::System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
					e.Graphics.PixelOffsetMode = global::System.Drawing.Drawing2D.PixelOffsetMode.Half;
					int width = this.ClientSize.Width;
					int height = this.ClientSize.Height;
					using (global::System.Drawing.Pen pen = new global::System.Drawing.Pen(global::System.Drawing.Color.FromArgb(0, 255, 230), 2f))
					{
						using (global::System.Drawing.Drawing2D.GraphicsPath roundedRect = global::Honda_Flash_Tools.Net.Form2.GetRoundedRect(new global::System.Drawing.Rectangle(1, 1, width - 2, height - 2), 14))
						{
							e.Graphics.DrawPath(pen, roundedRect);
						}
					}
					using (global::System.Drawing.Pen pen2 = new global::System.Drawing.Pen(global::System.Drawing.Color.DarkCyan, 1.5f))
					{
						using (global::System.Drawing.Drawing2D.GraphicsPath roundedRect2 = global::Honda_Flash_Tools.Net.Form2.GetRoundedRect(new global::System.Drawing.Rectangle(8, 8, width - 16, height - 16), 12))
						{
							e.Graphics.DrawPath(pen2, roundedRect2);
						}
					}
				};
				base.Resize += delegate(object s, global::System.EventArgs e)
				{
					this.ApplyRoundedRegion();
					this.Invalidate();
				};
				bool dragging = false;
				global::System.Drawing.Point dragStart = global::System.Drawing.Point.Empty;
				base.MouseDown += delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
				{
					if (e.Button == global::System.Windows.Forms.MouseButtons.Left)
					{
						dragging = true;
						dragStart = e.Location;
					}
				};
				base.MouseMove += delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
				{
					if (dragging)
					{
						this.Location = new global::System.Drawing.Point(this.Location.X + e.X - dragStart.X, this.Location.Y + e.Y - dragStart.Y);
					}
				};
				base.MouseUp += delegate(object s, global::System.Windows.Forms.MouseEventArgs e)
				{
					dragging = false;
				};
				base.KeyPreview = true;
				base.KeyDown += delegate(object s, global::System.Windows.Forms.KeyEventArgs e)
				{
					if (e.KeyCode == global::System.Windows.Forms.Keys.Escape)
					{
						this.Close();
					}
				};
				this.ApplyRoundedRegion();
			}
		}

		// Token: 0x04001241 RID: 4673
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400124B RID: 4683
		private global::System.Windows.Forms.Label lblRemappingMode;

		// Token: 0x0400124C RID: 4684
		private global::System.Windows.Forms.Label lblVersion;

		// Token: 0x0400124D RID: 4685
		private global::System.Windows.Forms.Label lblCopyright;

		// Token: 0x0400124E RID: 4686
		private global::System.Windows.Forms.Label lblRenew;

		// Token: 0x0400124F RID: 4687
		private global::System.Windows.Forms.Label lblEcuMode;

		// Token: 0x04001250 RID: 4688
		private global::System.Windows.Forms.PictureBox pictureBoxLogo;

		// Token: 0x04001251 RID: 4689
		private global::System.Windows.Forms.Button btnOk;

		// Token: 0x04001252 RID: 4690
		private static readonly global::System.Drawing.Color BackPanel = global::System.Drawing.Color.FromArgb(28, 28, 32);

		// Token: 0x04001253 RID: 4691
		private static readonly global::System.Drawing.Color NeonCyan = global::System.Drawing.Color.FromArgb(0, 229, 255);

		// Token: 0x04001255 RID: 4693
		private static readonly global::System.Drawing.Color NeonGreen = global::System.Drawing.Color.FromArgb(57, 255, 20);

		// Token: 0x04001256 RID: 4694
		private static readonly global::System.Drawing.Color ForeColorDefault = global::System.Drawing.Color.FromArgb(235, 235, 240);

		// Token: 0x04001257 RID: 4695
		private static readonly global::System.Drawing.Color ForeMuted = global::System.Drawing.Color.FromArgb(150, 150, 160);
	}
}
