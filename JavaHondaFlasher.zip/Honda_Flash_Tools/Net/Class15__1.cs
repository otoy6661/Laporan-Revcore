﻿using System;
using System.Runtime.InteropServices;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200063F RID: 1599
	public static class Class15__1
	{
		// Token: 0x06000F80 RID: 3968
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_Open(uint deviceNumber, ref IntPtr ftHandle);

		// Token: 0x06000F81 RID: 3969
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_Close(IntPtr ftHandle);

		// Token: 0x06000F82 RID: 3970
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_Read(IntPtr ftHandle, byte[] buffer, uint bytesToRead, ref uint bytesReturned);

		// Token: 0x06000F83 RID: 3971
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_Write(IntPtr ftHandle, byte[] buffer, uint bytesToWrite, ref uint bytesWritten);

		// Token: 0x06000F84 RID: 3972
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_SetBaudRate(IntPtr ftHandle, uint baudRate);

		// Token: 0x06000F85 RID: 3973
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_SetDataCharacteristics(IntPtr ftHandle, byte wordLength, byte stopBits, byte parity);

		// Token: 0x06000F86 RID: 3974
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_SetTimeouts(IntPtr ftHandle, uint readTimeout, uint writeTimeout);

		// Token: 0x06000F87 RID: 3975
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_SetLatencyTimer(IntPtr ftHandle, byte latency);

		// Token: 0x06000F88 RID: 3976
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_Purge(IntPtr ftHandle, uint mask);

		// Token: 0x06000F89 RID: 3977
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_SetBitMode(IntPtr ftHandle, byte mask, byte enable);

		// Token: 0x06000F8A RID: 3978
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_GetQueueStatus(IntPtr ftHandle, ref uint rxBytes);

		// Token: 0x04001451 RID: 5201
		private const string FTDI_DLL = "ftd2xx.dll";

		// Token: 0x02000640 RID: 1600
		public enum Enum5 : uint
		{
			// Token: 0x04001453 RID: 5203
			const_0,
			// Token: 0x04001454 RID: 5204
			const_1,
			// Token: 0x04001455 RID: 5205
			const_2,
			// Token: 0x04001456 RID: 5206
			const_3,
			// Token: 0x04001457 RID: 5207
			const_4,
			// Token: 0x04001458 RID: 5208
			const_5,
			// Token: 0x04001459 RID: 5209
			const_6,
			// Token: 0x0400145A RID: 5210
			const_7,
			// Token: 0x0400145B RID: 5211
			const_8,
			// Token: 0x0400145C RID: 5212
			const_9,
			// Token: 0x0400145D RID: 5213
			const_10,
			// Token: 0x0400145E RID: 5214
			const_11,
			// Token: 0x0400145F RID: 5215
			const_12,
			// Token: 0x04001460 RID: 5216
			const_13,
			// Token: 0x04001461 RID: 5217
			const_14,
			// Token: 0x04001462 RID: 5218
			const_15,
			// Token: 0x04001463 RID: 5219
			const_16,
			// Token: 0x04001464 RID: 5220
			const_17,
			// Token: 0x04001465 RID: 5221
			const_18,
			// Token: 0x04001466 RID: 5222
			const_19
		}
	}
}
