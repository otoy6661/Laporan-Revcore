﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200054D RID: 1357
	public partial class CustomMessageBox__2 : global::System.Windows.Forms.Form
	{
	}
}
