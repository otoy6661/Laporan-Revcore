﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200054F RID: 1359
	public partial class CustomMessageBox__0 : Form
	{
		// Token: 0x06000D7D RID: 3453 RVA: 0x00066C28 File Offset: 0x00066C28
		public CustomMessageBox__0()
		{
			base.FormBorderStyle = FormBorderStyle.None;
			base.StartPosition = FormStartPosition.CenterScreen;
			this.BackColor = CustomMessageBox__0.BgDark;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.ShowInTaskbar = false;
			base.Width = 440;
			base.Height = 300;
			base.TopMost = true;
			base.Padding = new Padding(2);
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		}

		// Token: 0x06000D7E RID: 3454 RVA: 0x00066CA8 File Offset: 0x00066CA8
		public static DialogResult Show(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
		{
			DialogResult dialogResult;
			using (CustomMessageBox__0 customMessageBox__ = new CustomMessageBox__0())
			{
				customMessageBox__.SetupDialog(message, title, buttons, icon);
				customMessageBox__.ShowDialog();
				dialogResult = CustomMessageBox__0._dialogResult;
			}
			return dialogResult;
		}

		// Token: 0x06000D7F RID: 3455 RVA: 0x00066CF0 File Offset: 0x00066CF0
		private void SetupDialog(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
		{
			base.Controls.Clear();
			this.contentPanel = new RoundedPanel();
			this.contentPanel.Dock = DockStyle.Fill;
			this.contentPanel.CornerRadius = this._cornerRadius;
			this.contentPanel.BorderColor = CustomMessageBox__0.Cyan;
			this.contentPanel.BorderWidth = 1f;
			this.contentPanel.InnerBackColor = CustomMessageBox__0.BgPanel;
			this.contentPanel.Padding = new Padding(20);
			base.Controls.Add(this.contentPanel);
			PictureBox pictureBox = new PictureBox
			{
				Location = new Point(18, 22),
				Size = new Size(28, 28),
				SizeMode = PictureBoxSizeMode.StretchImage,
				BackColor = Color.Transparent
			};
			if (icon == MessageBoxIcon.Asterisk || icon == MessageBoxIcon.Asterisk)
			{
				pictureBox.Image = SystemIcons.Information.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Exclamation || icon == MessageBoxIcon.Exclamation)
			{
				pictureBox.Image = SystemIcons.Warning.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Hand || icon == MessageBoxIcon.Hand || icon == MessageBoxIcon.Hand)
			{
				pictureBox.Image = SystemIcons.Error.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Question)
			{
				pictureBox.Image = SystemIcons.Question.ToBitmap();
			}
			this.contentPanel.Controls.Add(pictureBox);
			this.titleLabel = new Label
			{
				Text = title,
				Font = new Font("Segoe UI", 12f, FontStyle.Bold),
				ForeColor = CustomMessageBox__0.TextTitle,
				BackColor = Color.Transparent,
				Location = new Point(56, 18),
				AutoSize = true
			};
			this.contentPanel.Controls.Add(this.titleLabel);
			Panel value = new Panel
			{
				BackColor = CustomMessageBox__0.CyanDark,
				Location = new Point(18, 50),
				Size = new Size(base.Width - 36, 1),
				Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
			};
			this.contentPanel.Controls.Add(value);
			Label value2 = new Label
			{
				Text = message,
				Font = new Font("Segoe UI", 9.5f),
				ForeColor = CustomMessageBox__0.TextFore,
				BackColor = Color.Transparent,
				Location = new Point(20, 64),
				Width = base.Width - 80,
				Height = 120,
				AutoSize = false,
				Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
			};
			this.contentPanel.Controls.Add(value2);
			int num = 90;
			int num2 = 34;
			int num3 = 10;
			int width = this.contentPanel.ClientSize.Width;
			int height = this.contentPanel.ClientSize.Height;
			int left = this.contentPanel.Padding.Left;
			int right = this.contentPanel.Padding.Right;
			int bottom = this.contentPanel.Padding.Bottom;
			int num4 = width - left - right;
			int num5 = 0;
			if (buttons == MessageBoxButtons.OK)
			{
				num5 = 1;
			}
			else if (buttons == MessageBoxButtons.OKCancel || buttons == MessageBoxButtons.YesNo)
			{
				num5 = 2;
			}
			else if (buttons == MessageBoxButtons.YesNoCancel)
			{
				num5 = 3;
			}
			int num6 = num5 * num + (num5 - 1) * num3;
			int num7 = left + (num4 - num6) / 2;
			int top = height - num2 - bottom;
			if (buttons == MessageBoxButtons.OK)
			{
				this.CreateButton("OK", num7, top, num, num2, DialogResult.OK);
				return;
			}
			if (buttons == MessageBoxButtons.OKCancel)
			{
				this.CreateButton("OK", num7, top, num, num2, DialogResult.OK);
				this.CreateButton("Cancel", num7 + num + num3, top, num, num2, DialogResult.Cancel);
				return;
			}
			if (buttons == MessageBoxButtons.YesNo)
			{
				this.CreateButton("Yes", num7, top, num, num2, DialogResult.Yes);
				this.CreateButton("No", num7 + num + num3, top, num, num2, DialogResult.No);
				return;
			}
			if (buttons == MessageBoxButtons.YesNoCancel)
			{
				this.CreateButton("Yes", num7, top, num, num2, DialogResult.Yes);
				this.CreateButton("No", num7 + num + num3, top, num, num2, DialogResult.No);
				this.CreateButton("Cancel", num7 + (num + num3) * 2, top, num, num2, DialogResult.Cancel);
			}
		}

		// Token: 0x06000D80 RID: 3456 RVA: 0x000670F8 File Offset: 0x000670F8
		private void CreateButton(string text, int left, int top, int width, int height, DialogResult result)
		{
			RoundedButton roundedButton = new RoundedButton
			{
				Text = text,
				Location = new Point(left, top),
				Size = new Size(width, height),
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				ForeColor = CustomMessageBox__0.Cyan,
				BackColor = CustomMessageBox__0.BgButton,
				CornerRadius = 8,
				BorderColor = CustomMessageBox__0.Cyan,
				BorderWidth = 1f,
				HoverBackColor = CustomMessageBox__0.BgButtonHover,
				Cursor = Cursors.Hand
			};
			roundedButton.Click += delegate(object sender, EventArgs e)
			{
				CustomMessageBox__0._dialogResult = result;
				this.Close();
			};
			this.contentPanel.Controls.Add(roundedButton);
		}

		// Token: 0x06000D81 RID: 3457 RVA: 0x000671C8 File Offset: 0x000671C8
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.Half;
			graphics.Clear(this.BackColor);
			using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(new RectangleF(1.5f, 1.5f, (float)base.Width - 3f, (float)base.Height - 3f), this._cornerRadius))
			{
				using (Pen pen = new Pen(CustomMessageBox__0.Cyan, 2f))
				{
					pen.Alignment = PenAlignment.Center;
					pen.LineJoin = LineJoin.Round;
					graphics.DrawPath(pen, graphicsPath);
				}
			}
		}

		// Token: 0x06000D82 RID: 3458 RVA: 0x000096BB File Offset: 0x000096BB
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			this.UpdateFormRegion();
		}

		// Token: 0x06000D83 RID: 3459 RVA: 0x000096CA File Offset: 0x000096CA
		protected override void OnMouseDown(MouseEventArgs e)
		{
			base.OnMouseDown(e);
			if (e.Button == MouseButtons.Left)
			{
				CustomMessageBox__0.ReleaseCapture();
				CustomMessageBox__0.SendMessage(base.Handle, 161, 2, 0);
			}
		}

		// Token: 0x06000D84 RID: 3460
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x06000D85 RID: 3461
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		// Token: 0x06000D87 RID: 3463 RVA: 0x000096F9 File Offset: 0x000096F9
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.UpdateFormRegion();
			base.Invalidate();
		}

		// Token: 0x06000D88 RID: 3464 RVA: 0x0000970E File Offset: 0x0000970E
		private void UpdateFormRegion()
		{
			if (base.Width <= 0 || base.Height <= 0)
			{
				return;
			}
			RoundedHelper.SetRegion(this, this._cornerRadius);
		}

		// Token: 0x040011ED RID: 4589
		private static DialogResult _dialogResult;

		// Token: 0x040011EE RID: 4590
		private const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x040011EF RID: 4591
		private const int HT_CAPTION = 2;

		// Token: 0x040011F0 RID: 4592
		private Label titleLabel;

		// Token: 0x040011F1 RID: 4593
		private static readonly Color Cyan = Color.FromArgb(0, 255, 230);

		// Token: 0x040011F2 RID: 4594
		private static readonly Color CyanDark = Color.FromArgb(0, 145, 135);

		// Token: 0x040011F3 RID: 4595
		private static readonly Color BgDark = Color.FromArgb(18, 23, 29);

		// Token: 0x040011F4 RID: 4596
		private static readonly Color BgPanel = Color.FromArgb(22, 28, 35);

		// Token: 0x040011F5 RID: 4597
		private static readonly Color BgButton = Color.FromArgb(32, 40, 47);

		// Token: 0x040011F6 RID: 4598
		private static readonly Color BgButtonHover = Color.FromArgb(45, 60, 70);

		// Token: 0x040011F7 RID: 4599
		private static readonly Color TextFore = Color.FromArgb(235, 240, 245);

		// Token: 0x040011F8 RID: 4600
		private static readonly Color TextTitle = Color.FromArgb(255, 215, 0);

		// Token: 0x040011F9 RID: 4601
		private RoundedPanel contentPanel;

		// Token: 0x040011FA RID: 4602
		private int _cornerRadius = 14;
	}
}
