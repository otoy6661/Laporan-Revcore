﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using FTD2XX_NET;
using HondaMapEditorPro;
using TawonBalapTools.Net;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000002 RID: 2
	public partial class FormMain : Form
	{
		// Token: 0x06000001 RID: 1 RVA: 0x000105C8 File Offset: 0x000105C8
		public FormMain()
		{
			this._ecuLock = new object();
			this._ftHandle = IntPtr.Zero;
			this._lastEcmId = "";
			this._lastPartCode = "";
			LicenseManager.LicenseInfo licenseInfo;
			string str;
			if (!LicenseManager.IsActivated(out licenseInfo, out str))
			{
				using (ActivationForm activationForm = new ActivationForm())
				{
					if (activationForm.ShowDialog() != DialogResult.OK || !activationForm.ActivatedSuccessfully)
					{
						MessageBox.Show("Aplikasi tidak dapat dijalankan tanpa license yang valid.\n\nAlasan: " + str, "License Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						Environment.Exit(0);
						return;
					}
					if (!LicenseManager.IsActivated(out licenseInfo, out str))
					{
						MessageBox.Show("Aktivasi gagal: " + str, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						Environment.Exit(0);
						return;
					}
				}
			}
			this.InitializeComponent();
			FormMain.isFastWrite = true;
			ProgressPopupForm.GlobalPopupShown += this.ProgressPopupForm_GlobalPopupShown;
			ProgressPopupForm.GlobalPopupClosed += this.ProgressPopupForm_GlobalPopupClosed;
			base.FormClosed += this.FormMain_FormClosed;
			using (SplashScreenPopup splashScreenPopup = new SplashScreenPopup())
			{
				splashScreenPopup.ShowDialog();
			}
		}

		// Token: 0x06000002 RID: 2 RVA: 0x000106FC File Offset: 0x000106FC
		private byte Sum8Bit(byte[] data, int dataSize, int startPos = 0)
		{
			int num = startPos + dataSize;
			byte b = 0;
			while (startPos < num)
			{
				b += data[startPos];
				startPos++;
			}
			return b;
		}

		// Token: 0x06000003 RID: 3 RVA: 0x00010724 File Offset: 0x00010724
		private uint Sum32Bit(byte[] data, int dataSize, int startPos = 0)
		{
			int num = startPos + dataSize;
			uint num2 = 0U;
			while (startPos + 4 <= num)
			{
				num2 += BitConverter.ToUInt32(data, startPos);
				startPos += 4;
			}
			return num2;
		}

		// Token: 0x06000004 RID: 4 RVA: 0x00010750 File Offset: 0x00010750
		private byte Checksum8Bit(byte[] data, int dataSize, int startPos = 0)
		{
			int num = startPos + dataSize;
			int num2 = 0;
			while (startPos < num)
			{
				num2 += (int)data[startPos];
				startPos++;
			}
			return (byte)(255 - (num2 - 1 >> 8));
		}

		// Token: 0x06000005 RID: 5 RVA: 0x00010780 File Offset: 0x00010780
		private byte Checksum8BitHonda(byte[] data, int dataSize, int startPos = 0)
		{
			int num = startPos + dataSize;
			int num2 = 0;
			while (startPos < num)
			{
				num2 += (int)data[startPos];
				startPos++;
			}
			return (byte)((num2 ^ 255) + 1 & 255);
		}

		// Token: 0x06000006 RID: 6 RVA: 0x000026E0 File Offset: 0x000026E0
		private bool ValidateChecksum(byte[] data, int dataSize)
		{
			return this.Checksum8BitHonda(data, dataSize - 1, 0) == data[dataSize - 1];
		}

		// Token: 0x06000007 RID: 7 RVA: 0x000107B4 File Offset: 0x000107B4
		private bool SendCommand(byte[] command, int commandSize, ref byte[] reply, ref uint replySize, int sleepMs = 0)
		{
			byte[] array = new byte[256];
			byte[] array2 = new byte[256];
			uint num = 0U;
			uint num2 = 0U;
			uint num3 = 0U;
			uint num4 = 0U;
			uint num5 = 0U;
			long num6 = (long)(50 + 2 * commandSize);
			bool result;
			if (FTD2XX_NET.FTDI.FT_Write(FormMain.ftHandle, command, (uint)commandSize, ref num) > 0)
			{
				result = false;
			}
			else if (FTD2XX_NET.FTDI.FT_SetLatencyTimer(FormMain.ftHandle, 8) <= 0)
			{
				if (sleepMs > 0)
				{
					Thread.Sleep(sleepMs);
				}
				Stopwatch stopwatch = new Stopwatch();
				stopwatch.Start();
				do
				{
					if (FTD2XX_NET.FTDI.FT_GetQueueStatus(FormMain.ftHandle, ref num2) == null && num2 > 0U && (ulong)num2 < (ulong)((long)array.Length) && FTD2XX_NET.FTDI.FT_Read(FormMain.ftHandle, array, num2, ref num3) == null && num3 > 0U)
					{
						Array.Copy(array, 0L, array2, (long)((ulong)num4), (long)((ulong)num3));
						num4 += num3;
						if ((ulong)num4 >= (ulong)((long)(commandSize + 2)))
						{
							if (num5 == 0U)
							{
								num5 = (uint)array2[commandSize + 1];
							}
							if ((ulong)num4 - (ulong)((long)commandSize) == (ulong)num5)
							{
								replySize = num5;
								Array.Copy(array2, (long)((ulong)(num4 - num5)), reply, 0L, (long)((ulong)num5));
								if (this.ValidateChecksum(reply, (int)num5))
								{
									goto IL_125;
								}
							}
						}
					}
				}
				while (stopwatch.ElapsedMilliseconds < num6);
				stopwatch.Stop();
				FTD2XX_NET.FTDI.FT_Purge(FormMain.ftHandle, 3U);
				return false;
				IL_125:
				stopwatch.Stop();
				FTD2XX_NET.FTDI.FT_Purge(FormMain.ftHandle, 3U);
				result = true;
			}
			else
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000008 RID: 8 RVA: 0x00010918 File Offset: 0x00010918
		private void WriteFlash(int startOffset, FormMain.ECUTYPE ecuType, bool fastWrite = false)
		{
			checked
			{
				try
				{
					this.LogMessage("========================================");
					this.LogMessage("Starting WriteFlash process");
					this.LogMessage(string.Format("ECU Type: {0}", ecuType));
					this.LogMessage(string.Format("Start Offset: {0}", startOffset));
					this.LogMessage(string.Format("Fast Write: {0}", fastWrite));
					this.LogMessage("========================================");
					byte[] array = new byte[]
					{
						byte.MaxValue,
						37,
						0,
						32,
						124,
						0
					};
					byte[] array2 = new byte[]
					{
						126,
						6,
						1,
						1,
						0,
						122
					};
					byte[] array3 = new byte[]
					{
						126,
						5,
						1,
						7,
						117
					};
					byte[] array4 = new byte[]
					{
						126,
						5,
						1,
						8,
						116
					};
					byte[] array5 = new byte[]
					{
						126,
						5,
						1,
						9,
						115
					};
					byte[] array6 = new byte[]
					{
						126,
						5,
						1,
						10,
						114
					};
					byte[] array7 = new byte[]
					{
						126,
						5,
						1,
						12,
						112
					};
					byte[] array8 = new byte[]
					{
						126,
						5,
						1,
						13,
						111
					};
					byte[] array9 = new byte[]
					{
						124,
						5,
						2,
						8,
						117
					};
					byte[] array10 = new byte[]
					{
						124,
						5,
						2,
						9,
						116
					};
					byte[] array11 = new byte[]
					{
						124,
						5,
						2,
						10,
						115
					};
					byte[] array12 = new byte[]
					{
						124,
						5,
						2,
						12,
						113
					};
					byte[] array13 = new byte[]
					{
						124,
						5,
						2,
						13,
						112
					};
					byte[] array14 = new byte[256];
					byte[] array15 = new byte[256];
					byte[] array16 = new byte[128];
					uint num = 0U;
					int sleepMs = 0;
					int num2 = 0;
					int num3 = 128;
					int num4 = 8;
					int num5 = startOffset / 16;
					int num6 = 0;
					int i = 0;
					int num7 = FormMain.binSize / 128;
					bool flag = true;
					Stopwatch stopwatch = new Stopwatch();
					double num8 = 0.0;
					double num9 = 0.0;
					double num10 = 0.0;
					bool flag2 = false;
					array15[0] = 126;
					array15[1] = 139;
					array15[2] = 1;
					array15[3] = 6;
					for (int j = 0; j < array16.Length; j++)
					{
						array16[j] = byte.MaxValue;
					}
					if (ecuType == FormMain.ECUTYPE.KEIHINOTHER && fastWrite)
					{
						this.LogMessage("Setting up KEIHINOTHER with fast write");
						if (this.SendCommand(array, array.Length, ref array14, ref num, 0) && array14[1] == 5 && array14[3] == 0)
						{
							Honda_Flash_Tools.Net.FTDI.FT_SetBaudRate(FormMain.ftHandle, 62500U);
							this.LogMessage("Baud rate set to 62500 for KEIHINOTHER fast write");
						}
						else
						{
							this.LogMessage("Failed to set up KEIHINOTHER fast write mode");
						}
					}
					else if (ecuType == FormMain.ECUTYPE.KEIHINH8C)
					{
						this.LogMessage("Setting up KEIHINH8C");
						num3 = 64;
						num4 = 4;
						num7 = FormMain.binSize / 64;
						array15[0] = 126;
						array15[1] = 75;
						array15[2] = 1;
						array15[3] = 6;
						flag = false;
					}
					else if (ecuType == FormMain.ECUTYPE.KEIHINM32R)
					{
						this.LogMessage("Setting up KEIHINM32R");
						flag = false;
					}
					else if (ecuType == FormMain.ECUTYPE.SHINDENGENV850)
					{
						this.LogMessage("Setting up SHINDENGENV850");
						array15[0] = 124;
						array15[1] = 139;
						array15[2] = 2;
						array15[3] = 6;
						i = startOffset / num3;
						if (!fastWrite)
						{
							sleepMs = 150;
							this.LogMessage("Using normal write mode with 150ms delay for SHINDENGENV850");
						}
					}
					else if (ecuType == FormMain.ECUTYPE.SHINDENGENRH850)
					{
						this.LogMessage("Setting up SHINDENGENRH850");
						array15[0] = 124;
						array15[1] = 139;
						array15[2] = 2;
						array15[3] = 6;
						i = startOffset / num3;
						flag = false;
						if (!fastWrite)
						{
							sleepMs = 150;
							this.LogMessage("Using normal write mode with 150ms delay for SHINDENGENRH850");
						}
					}
					else if (ecuType == FormMain.ECUTYPE.SHINDENGENRH850B)
					{
						this.LogMessage("Setting up SHINDENGENRH850B");
						array15[0] = 124;
						array15[1] = 139;
						array15[2] = 2;
						array15[3] = 6;
						i = startOffset / num3;
						flag = false;
						if (!fastWrite)
						{
							sleepMs = 150;
							this.LogMessage("Using normal write mode with 150ms delay for SHINDENGENRH850B");
						}
					}
					double num11 = (double)FormMain.binSize / 1024.0;
					double num12;
					if (num11 <= 192.0)
					{
						num12 = 90.0;
					}
					else if (num11 <= 256.0)
					{
						num12 = 180.0;
					}
					else if (num11 <= 384.0)
					{
						num12 = 240.0;
					}
					else if (num11 <= 1024.0)
					{
						num12 = 900.0;
					}
					else
					{
						num12 = unchecked(900.0 * (num11 / 1024.0));
					}
					this.LogMessage(string.Format("Binary size: {0:F2} KB, Estimated time: {1:F0} seconds", num11, num12));
					this.LogMessage(string.Format("Starting flash write process with block size: {0} bytes", num3));
					stopwatch.Start();
					while (i < num7)
					{
						array15[4] = (byte)(num5 >> 8 & 255);
						array15[5] = (byte)(num5 & 255);
						Array.Copy(FormMain.binBytes, i * num3, array15, 6, num3);
						if (flag)
						{
							for (int k = 1; k < num7 - i; k++)
							{
								if (!this.CompareMemory(FormMain.binBytes, (i + k) * num3, array16, num3))
								{
									num6 = num5 + k * num4;
									i += k - 1;
									break;
								}
								if (i + k + 1 == num7)
								{
									i += k;
								}
							}
						}
						else
						{
							num6 = num5 + num4;
						}
						if (i + 1 == num7)
						{
							num6 = 0;
						}
						array15[6 + num3] = (byte)(num6 >> 8 & 255);
						array15[6 + num3 + 1] = (byte)(num6 & 255);
						array15[6 + num3 + 2] = this.Checksum8Bit(array15, num3 + 4, 4);
						array15[6 + num3 + 3] = this.Checksum8BitHonda(array15, num3 + 4, 4);
						array15[6 + num3 + 4] = this.Checksum8BitHonda(array15, (int)(array15[1] - 1), 0);
						while (this.SendCommand(array15, (int)array15[1], ref array14, ref num, sleepMs))
						{
							FormMain.STATUS status;
							if (array14[1] == 7)
							{
								if (array14[4] == 0 && array14[5] == 0)
								{
									if (num2 < 2)
									{
										num2++;
										this.LogMessage(string.Format("Retrying write operation (attempt {0})", num2));
										continue;
									}
									status = FormMain.STATUS.FAILED;
									this.LogMessage("Write operation failed after 2 retries");
								}
								else
								{
									status = FormMain.STATUS.FAILED;
									this.LogMessage(string.Format("Write operation failed. Response: {0}, {1}", array14[4], array14[5]));
								}
							}
							else if (array14[1] == 5)
							{
								if (num3 == 64 && (i + 1) % 2 == 0)
								{
									this.SendCommand(array3, (int)array3[1], ref array14, ref num, 0);
									Thread.Sleep(100);
									this.LogMessage("Sent special command for KEIHINH8C");
								}
								status = FormMain.STATUS.SUCCESS;
								if (i % 10 == 0)
								{
									double num13 = unchecked((double)(checked(i + 1)) * (double)num3 / (double)FormMain.binSize * 100.0);
									this.LogMessage(string.Format("Write progress: {0:F2}% (Block {1}/{2})", num13, i + 1, num7));
								}
							}
							else
							{
								status = FormMain.STATUS.FAILED;
								this.LogMessage(string.Format("Unexpected response: {0}", array14[1]));
							}
							double num14 = Math.Max(0.0001, stopwatch.Elapsed.TotalSeconds);
							double num15 = (double)((i + 1) * num3);
							double num20;
							unchecked
							{
								double num16 = num15 - num8;
								double num17 = num14 - num9;
								if (num17 > 0.25 && num16 > 0.0)
								{
									double num18 = num16 / num17;
									if (num10 <= 0.0)
									{
										num10 = num18;
									}
									num10 = num10 * 0.85 + num18 * 0.15;
								}
								double num19 = (num10 > 0.0) ? num10 : (num15 / num14);
								if (num19 <= 0.0)
								{
									num19 = Math.Max(1.0, num15 / num14);
								}
								if (!flag2)
								{
									flag2 = true;
									this.LogMessage("First block written successfully");
								}
								num20 = num15 / (double)FormMain.binSize;
								double val = num12 * (1.0 - num20);
								val = Math.Max(0.0, val);
								TimeSpan timeSpan = TimeSpan.FromSeconds(Math.Ceiling(Math.Max(0.0, val)));
								string arg = string.Format("{0:D2}:{1:D2}", timeSpan.Minutes, timeSpan.Seconds);
								TimeSpan timeSpan2 = TimeSpan.FromSeconds(Math.Floor(num14));
								string arg2 = string.Format("{0:D2}:{1:D2}", timeSpan2.Minutes, timeSpan2.Seconds);
								double num21 = num19 / 1024.0;
								string text = string.Format("{0:F2} Kb/s", num21);
								string newText = string.Concat(new string[]
								{
									string.Format("    Writing Process : {0:F2} Kb / {1:F0} Kb ({2:F2}%)      ", num15 / 1024.0, (double)FormMain.binSize / 1024.0, num20 * 100.0),
									"Transfer Speed : ",
									text,
									"       ",
									string.Format("Time Elapsed : {0}       ", arg2),
									string.Format("Time Left : {0}", arg)
								});
								num8 = num15;
								num9 = num14;
								this.SetControlText(this.TxtPb, newText);
							}
							this.SetProgressBarPosition(this.PbProgress, (int)(unchecked(num20 * 10000.0)));
							if (status != FormMain.STATUS.FAILED)
							{
								num5 = num6;
								i++;
								break;
							}
							stopwatch.Stop();
							this.LogMessage("Writing Flash Failed!");
							this.SetControlText(this.TxtPartCode, "Writing Flash Failed !");
							this.SetControlText(this.TxtPb, "");
							this.SetProgressBarPosition(this.PbProgress, 0);
							return;
						}
					}
					stopwatch.Stop();
					this.LogMessage(string.Format("Flash write completed in {0:F2} seconds", stopwatch.Elapsed.TotalSeconds));
					TimeSpan timeSpan3 = TimeSpan.FromSeconds(0.0);
					string.Format("{0:D2}:{1:D2}", timeSpan3.Minutes, timeSpan3.Seconds);
					if (ecuType == FormMain.ECUTYPE.SHINDENGENV850 || ecuType == FormMain.ECUTYPE.SHINDENGENRH850 || ecuType == FormMain.ECUTYPE.SHINDENGENRH850B)
					{
						this.LogMessage("Verifying SHINDENGEN ECU flash");
						this.SendCommand(array9, array9.Length, ref array14, ref num, sleepMs);
						Thread.Sleep(1000);
						this.SendCommand(array10, array10.Length, ref array14, ref num, sleepMs);
						Thread.Sleep(1000);
						this.SendCommand(array11, array11.Length, ref array14, ref num, sleepMs);
						Thread.Sleep(1000);
						this.SendCommand(array12, array12.Length, ref array14, ref num, sleepMs);
						Thread.Sleep(3000);
						if (this.SendCommand(array13, array13.Length, ref array14, ref num, sleepMs) && array14[3] == 15)
						{
							this.LogMessage("SHINDENGEN ECU flash verification successful");
							CustomMessageBox__1.Show("Finish Writing Flash\r\nThe Result Is Good !!\r\nSUKSES", "Honda Java Tech Tools", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							this.button1.Enabled = true;
							this.SetControlText(this.TxtPb, "");
							this.SetProgressBarPosition(this.PbProgress, 0);
							return;
						}
						this.LogMessage("SHINDENGEN ECU flash verification failed");
					}
					else
					{
						this.LogMessage("Verifying KEIHIN ECU flash");
						if (num3 == 64)
						{
							this.SendCommand(array3, array3.Length, ref array14, ref num, 0);
							Thread.Sleep(100);
						}
						this.SendCommand(array4, array4.Length, ref array14, ref num, 0);
						Thread.Sleep(1000);
						this.SendCommand(array2, array2.Length, ref array14, ref num, 0);
						this.SendCommand(array5, array5.Length, ref array14, ref num, 0);
						Thread.Sleep(1000);
						this.SendCommand(array2, array2.Length, ref array14, ref num, 0);
						this.SendCommand(array6, array6.Length, ref array14, ref num, 0);
						Thread.Sleep(1000);
						this.SendCommand(array2, array2.Length, ref array14, ref num, 0);
						this.SendCommand(array7, array7.Length, ref array14, ref num, 0);
						Thread.Sleep(1000);
						if (this.SendCommand(array2, array2.Length, ref array14, ref num, 0) && array14[3] == 15 && this.SendCommand(array8, array8.Length, ref array14, ref num, 0) && array14[3] == 15)
						{
							this.LogMessage("KEIHIN ECU flash verification successful");
							CustomMessageBox__1.Show("Finish Writing Flash\r\nThe Result Is Good !!\r\n Please Restart Your ECM", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							this.SetControlText(this.TxtPb, "");
							this.SetProgressBarPosition(this.PbProgress, 0);
							return;
						}
						this.LogMessage("KEIHIN ECU flash verification failed");
					}
					this.LogMessage("Flash verification failed - Result is BAD");
					CustomMessageBox__1.Show("Finish Writing Flash, The Result is BAD !!\r\nPlease Restart Your ECM and Try Again", "Honda Ecu Flasher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					this.SetControlText(this.TxtPb, "");
					this.SetProgressBarPosition(this.PbProgress, 0);
				}
				catch (Exception ex)
				{
					this.LogMessage("ERROR in WriteFlash: " + ex.Message);
					this.LogMessage("Stack Trace: " + ex.StackTrace);
					CustomMessageBox__1.Show("An error occurred during flash writing: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		// Token: 0x06000009 RID: 9 RVA: 0x000115C8 File Offset: 0x000115C8
		private bool GetShindengenWriteKey(byte[] seedByte, ref byte[] key)
		{
			for (int i = 0; i < FormMain.binSize - FormMain.shWKeysig.Length; i++)
			{
				if (this.CompareMemory(FormMain.binBytes, i, FormMain.shWKeysig, FormMain.shWKeysig.Length))
				{
					int j = i + FormMain.shWKeysig.Length;
					while (j < FormMain.binSize - 10)
					{
						if (FormMain.binBytes[j + 8] != 238 || (FormMain.binBytes[j + 9] != 0 && FormMain.binBytes[j + 9] != 255))
						{
							j++;
						}
						else
						{
							ushort num = (ushort)((int)seedByte[0] * 256 + (int)seedByte[1]);
							ushort num2 = (ushort)((int)FormMain.binBytes[j + 1] * 256 + (int)FormMain.binBytes[j]);
							ushort num3 = (ushort)((int)FormMain.binBytes[j + 3] * 256 + (int)FormMain.binBytes[j + 2]);
							ushort num4 = (ushort)((int)FormMain.binBytes[j + 5] * 256 + (int)FormMain.binBytes[j + 4]);
							ushort num5 = num3 * (num + num2);
							if (num4 > 0)
							{
								ushort num6 = num5 + num % num4;
								key[0] = (byte)(num6 >> 8 & 255);
								key[1] = (byte)(num6 & 255);
								return true;
							}
							ushort num7 = num5 + num;
							key[0] = (byte)(num7 >> 8 & 255);
							key[1] = (byte)(num7 & 255);
							return true;
						}
					}
				}
			}
			return false;
		}

		// Token: 0x0600000A RID: 10 RVA: 0x00011728 File Offset: 0x00011728
		private bool GetShindengenRecoveryKey(byte[] seedByte, ref byte[] key)
		{
			for (int i = 0; i < FormMain.binSize - FormMain.shRKeysSig.Length; i++)
			{
				if (this.CompareMemory(FormMain.binBytes, i + 6, FormMain.shRKeysSig, FormMain.shRKeysSig.Length))
				{
					ushort num = (ushort)((int)seedByte[0] * 256 + (int)seedByte[1]);
					ushort num2 = (ushort)((int)FormMain.binBytes[i + 1] * 256 + (int)FormMain.binBytes[i]);
					ushort num3 = (ushort)((int)FormMain.binBytes[i + 3] * 256 + (int)FormMain.binBytes[i + 2]);
					ushort num4 = (ushort)((int)FormMain.binBytes[i + 5] * 256 + (int)FormMain.binBytes[i + 4]);
					ushort num5 = num3 * (num + num2);
					bool result;
					if (num4 > 0)
					{
						ushort num6 = num5 + num % num4;
						key[0] = (byte)(num6 >> 8 & 255);
						key[1] = (byte)(num6 & 255);
						result = true;
					}
					else
					{
						ushort num7 = num5 + num;
						key[0] = (byte)(num7 >> 8 & 255);
						key[1] = (byte)(num7 & 255);
						result = true;
					}
					return result;
				}
			}
			return false;
		}

		// Token: 0x0600000B RID: 11 RVA: 0x00011830 File Offset: 0x00011830
		private void ShindengenAutoChecksum(FormMain.ECUTYPE EcuTYPE)
		{
			for (int i = 0; i < FormMain.binSize - FormMain.shWKeysig.Length; i++)
			{
				if (this.CompareMemory(FormMain.binBytes, i, FormMain.shWKeysig, FormMain.shWKeysig.Length))
				{
					for (int j = i + FormMain.shWKeysig.Length; j < FormMain.binSize - 6; j++)
					{
						if (FormMain.binBytes[j] == 208 && FormMain.binBytes[j + 1] == 7)
						{
							int num = j;
							if ((long)j - ((long)j + (long)((ulong)((uint)(j - 4 >> 31) >> 30)) - 4L & -4L) == 6L)
							{
								num = j - 6;
							}
							this.SetControlText(this.TbChecksumOffset, (num - 4).ToString("X"));
							uint num2 = this.Sum32Bit(FormMain.binBytes, num - 4, 0) + this.Sum32Bit(FormMain.binBytes, FormMain.binSize - num, num);
							byte[] bytes = BitConverter.GetBytes(0U - num2);
							FormMain.binBytes[num - 4] = bytes[0];
							FormMain.binBytes[num - 3] = bytes[1];
							FormMain.binBytes[num - 2] = bytes[2];
							FormMain.binBytes[num - 1] = bytes[3];
							return;
						}
					}
				}
			}
		}

		// Token: 0x0600000C RID: 12 RVA: 0x00011960 File Offset: 0x00011960
		private bool ShindengenPreWriteFlash(bool fastWrite = true, bool recoveryMode = false)
		{
			byte[] array = new byte[]
			{
				123,
				8,
				2,
				2,
				80,
				25,
				118,
				154
			};
			byte[] array2 = new byte[]
			{
				123,
				8,
				2,
				3,
				37,
				55,
				134,
				150
			};
			byte[] array3 = new byte[]
			{
				123,
				5,
				2,
				4,
				122
			};
			byte[] array4 = new byte[]
			{
				123,
				7,
				2,
				5,
				0,
				0,
				0
			};
			byte[] array5 = new byte[]
			{
				124,
				6,
				2,
				1,
				0,
				123
			};
			byte[] array6 = new byte[]
			{
				124,
				11,
				2,
				11,
				0,
				0,
				0,
				byte.MaxValue,
				byte.MaxValue,
				byte.MaxValue,
				111
			};
			byte[] array7 = new byte[]
			{
				124,
				7,
				2,
				14,
				1,
				0,
				108
			};
			byte[] array8 = new byte[]
			{
				124,
				6,
				2,
				4,
				byte.MaxValue,
				121
			};
			byte[] array9 = new byte[]
			{
				124,
				5,
				2,
				5,
				120
			};
			byte[] array10 = new byte[256];
			uint num = 0U;
			int sleepMs = 0;
			if (!fastWrite)
			{
				sleepMs = 150;
			}
			this.SendCommand(array, array.Length, ref array10, ref num, sleepMs);
			this.SendCommand(array2, array2.Length, ref array10, ref num, sleepMs);
			for (int i = 0; i < 10; i++)
			{
				this.SetControlText(this.TxtPb, "Preparing Seed/Key (waiting for " + (10 - i).ToString("D") + " second)");
				this.SetProgressBarPosition(this.PbProgress, 10000 - 1000 * i);
				Thread.Sleep(1000);
				if (i == 9)
				{
					this.SetControlText(this.TxtPb, "Preparing Seed/Key (waiting for 0 second)");
					this.SetProgressBarPosition(this.PbProgress, 0);
					Thread.Sleep(500);
				}
			}
			this.SendCommand(array3, array3.Length, ref array10, ref num, sleepMs);
			bool result;
			if (array10[1] == 7 && array10[3] == 0)
			{
				byte[] array11 = new byte[2];
				byte[] array12 = new byte[2];
				array11[0] = array10[4];
				array11[1] = array10[5];
				bool flag;
				if (recoveryMode)
				{
					flag = this.GetShindengenRecoveryKey(array11, ref array12);
				}
				else
				{
					flag = this.GetShindengenWriteKey(array11, ref array12);
				}
				if (flag)
				{
					array4[4] = array12[0];
					array4[5] = array12[1];
					array4[6] = this.Checksum8BitHonda(array4, (int)(array10[1] - 1), 0);
				}
				this.SendCommand(array4, array4.Length, ref array10, ref num, sleepMs);
				if (array10[1] == 5 && array10[3] == 0)
				{
					this.SetControlText(this.TxtPb, "Erasing flash");
					this.SendCommand(array5, array5.Length, ref array10, ref num, sleepMs);
					this.SendCommand(array6, array6.Length, ref array10, ref num, sleepMs);
					this.SendCommand(array7, array7.Length, ref array10, ref num, sleepMs);
					if (this.SendCommand(array8, array8.Length, ref array10, ref num, sleepMs) && array10[3] == 0)
					{
						Thread.Sleep(2000);
						if (this.SendCommand(array9, array9.Length, ref array10, ref num, sleepMs) && array10[3] == 0)
						{
							this.SetControlText(this.TxtPb, "Finish erasing flash");
							return true;
						}
						if (array10[3] == 250)
						{
							CustomMessageBox__1.Show("Erasing flash failed, block error", "Tawon Balap Pro", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							return false;
						}
					}
					CustomMessageBox__1.Show("Erasing flash failed", "Tawon Balap Pro", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					result = false;
				}
				else
				{
					CustomMessageBox__1.Show("Failed challenging Seed/Key", "Tawon Balap Pro", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					result = false;
				}
			}
			else
			{
				CustomMessageBox__1.Show("Failed generating Seed/Key", "Tawon Balap Pro", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				result = false;
			}
			return result;
		}

		// Token: 0x0600000D RID: 13 RVA: 0x00011C98 File Offset: 0x00011C98
		private void KeihinAutoChecksum(int checksumOffset = 0)
		{
			byte b = (checksumOffset != 0) ? (this.Sum8Bit(FormMain.binBytes, checksumOffset, 0) + this.Sum8Bit(FormMain.binBytes, FormMain.binSize - (checksumOffset + 1), checksumOffset + 1)) : this.Sum8Bit(FormMain.binBytes, FormMain.binSize - 1, 1);
			FormMain.binBytes[checksumOffset] = -b;
		}

		// Token: 0x0600000E RID: 14 RVA: 0x00011CF0 File Offset: 0x00011CF0
		private bool InitFtdiIso()
		{
			byte[] array = new byte[1];
			byte[] array2 = new byte[]
			{
				1
			};
			uint num = 0U;
			bool result;
			if (FTD2XX_NET.FTDI.FT_Open(0U, ref FormMain.ftHandle) > 0)
			{
				FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
				result = false;
			}
			else if (FTD2XX_NET.FTDI.FT_Purge(FormMain.ftHandle, 3U) > 0)
			{
				FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
				result = false;
			}
			else if (FTD2XX_NET.FTDI.FT_SetBitMode(FormMain.ftHandle, 0, 0) > 0)
			{
				FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
				result = false;
			}
			else if (FTD2XX_NET.FTDI.FT_SetDataCharacteristics(FormMain.ftHandle, 8, 0, 0) > 0)
			{
				FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
				result = false;
			}
			else if (FTD2XX_NET.FTDI.FT_SetBaudRate(FormMain.ftHandle, 10400U) > 0)
			{
				FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
				result = false;
			}
			else if (FTD2XX_NET.FTDI.FT_SetTimeouts(FormMain.ftHandle, 50U, 0U) > 0)
			{
				FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
				result = false;
			}
			else if (FTD2XX_NET.FTDI.FT_SetLatencyTimer(FormMain.ftHandle, 8) > 0)
			{
				FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
				result = false;
			}
			else if (FTD2XX_NET.FTDI.FT_SetBitMode(FormMain.ftHandle, 1, 1) > 0)
			{
				FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
				result = false;
			}
			else if (FTD2XX_NET.FTDI.FT_Write(FormMain.ftHandle, array, (uint)array.Length, ref num) > 0)
			{
				FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
				result = false;
			}
			else
			{
				Thread.Sleep(70);
				if (FTD2XX_NET.FTDI.FT_Write(FormMain.ftHandle, array2, (uint)array2.Length, ref num) > 0)
				{
					FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
					result = false;
				}
				else if (FTD2XX_NET.FTDI.FT_SetBitMode(FormMain.ftHandle, 0, 0) > 0)
				{
					FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
					result = false;
				}
				else if (FTD2XX_NET.FTDI.FT_SetBaudRate(FormMain.ftHandle, 10400U) > 0)
				{
					FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
					result = false;
				}
				else if (FTD2XX_NET.FTDI.FT_Purge(FormMain.ftHandle, 3U) > 0)
				{
					FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
					result = false;
				}
				else
				{
					Thread.Sleep(140);
					result = true;
				}
			}
			return result;
		}

		// Token: 0x0600000F RID: 15 RVA: 0x00011EEC File Offset: 0x00011EEC
		private void WorkerThread()
		{
			try
			{
				this.InitializeSimpleLogging();
				this.LogMessage("Worker thread started");
				byte[] array = new byte[]
				{
					254,
					4,
					114,
					140
				};
				byte[] array2 = new byte[]
				{
					114,
					5,
					0,
					240,
					153
				};
				byte[] array3 = new byte[]
				{
					114,
					7,
					114,
					0,
					0,
					5,
					16
				};
				byte[] array4 = new byte[]
				{
					125,
					6,
					1,
					1,
					3,
					120
				};
				byte[] array5 = new byte[]
				{
					123,
					6,
					2,
					1,
					3,
					121
				};
				byte[] array6 = new byte[]
				{
					126,
					6,
					1,
					1,
					0,
					122
				};
				byte[] array7 = new byte[]
				{
					124,
					6,
					2,
					1,
					0,
					123
				};
				byte[] array8 = new byte[]
				{
					114,
					5,
					0,
					240,
					153,
					0
				};
				byte[] array9 = new byte[256];
				uint num = 0U;
				this.LogMessage("Starting ECU communication");
				while (!FormMain.endThread)
				{
					if (this.InitFtdiIso())
					{
						if (FormMain.isNoInterface)
						{
							FormMain.isConnected = true;
							FormMain.isNoInterface = false;
						}
						this.SendCommand(array, array.Length, ref array9, ref num, 0);
						if (this.SendCommand(array2, array2.Length, ref array9, ref num, 0))
						{
							array8 = new byte[]
							{
								114,
								5,
								0,
								240,
								153
							};
						}
						else if (this.SendCommand(array6, array6.Length, ref array9, ref num, 0) && array9[3] != 15)
						{
							array8 = new byte[]
							{
								126,
								6,
								1,
								1,
								0,
								122
							};
						}
						if (this.SendCommand(array8, (int)array8[1], ref array9, ref num, 0))
						{
							string text = "-";
							string text2 = "-";
							FormMain.isConnected = true;
							if (this.SendCommand(array3, array3.Length, ref array9, ref num, 0))
							{
								text = BitConverter.ToString(array9, 5, 5).Replace("-", "");
								this.LogMessage("ECU ID: " + text);
							}
							if (this.SendCommand(array4, array4.Length, ref array9, ref num, 0))
							{
								text2 = array9[6].ToString("D");
							}
							else if (this.SendCommand(array5, array5.Length, ref array9, ref num, 0))
							{
								text2 = array9[6].ToString("D");
							}
							this.InvokeIfRequired(delegate
							{
								if (this.TxtConnStat != null && !this.TxtConnStat.IsDisposed)
								{
									this.TxtConnStat.Text = "ECU Connected";
								}
								if (this.TxtEcmId != null && !this.TxtEcmId.IsDisposed)
								{
									this.TxtEcmId.Text = text;
								}
								if (this.TxtFlashCount != null && !this.TxtFlashCount.IsDisposed)
								{
									this.TxtFlashCount.Text = text2;
								}
							});
							if (this.SetEcmParamsFromDb(text) == 0)
							{
								FormMain.isRecovery = true;
							}
							while (this.SendCommand(array8, (int)array8[1], ref array9, ref num, 0))
							{
								if (FormMain.endThread)
								{
									return;
								}
								if (!FormMain.isWrite)
								{
									Thread.Sleep(1000);
								}
								else
								{
									FormMain.isWrite = false;
									FormMain.ECUTYPE ecutype = this.GetEcuType();
									this.LogMessage("Flash write started - ECU Type: " + ecutype);
									if (ecutype == FormMain.ECUTYPE.SHINDENGENV850 || ecutype == FormMain.ECUTYPE.SHINDENGENRH850 || ecutype == FormMain.ECUTYPE.SHINDENGENRH850B)
									{
										this.ShindengenAutoChecksum(ecutype);
										if (this.ShindengenPreWriteFlash(FormMain.isFastWrite, FormMain.isRecovery))
										{
											this.WriteFlash(FormMain.startOffset, ecutype, FormMain.isFastWrite);
											this.LogMessage("Shindengen flash completed");
										}
										else
										{
											this.LogMessage("Shindengen pre-write failed");
										}
										while (this.SendCommand(array7, array7.Length, ref array9, ref num, 0))
										{
											if (FormMain.endThread)
											{
												return;
											}
											Thread.Sleep(1000);
										}
										break;
									}
									this.KeihinAutoChecksum(FormMain.checksumOffset);
									if (this.KeihinPreWriteFlash())
									{
										this.WriteFlash(FormMain.startOffset, ecutype, FormMain.isFastWrite);
										this.LogMessage("Keihin flash completed");
									}
									else
									{
										this.LogMessage("Keihin pre-write failed");
									}
									while (this.SendCommand(array6, array6.Length, ref array9, ref num, 0))
									{
										if (FormMain.endThread)
										{
											return;
										}
										Thread.Sleep(1000);
									}
									break;
								}
							}
						}
						else if (FormMain.isConnected)
						{
							FormMain.isConnected = false;
							this.InvokeIfRequired(delegate
							{
								if (this.TxtConnStat != null && !this.TxtConnStat.IsDisposed)
								{
									this.TxtConnStat.Text = "ECU Tdk Terhubung";
								}
								if (this.TxtEcmId != null && !this.TxtEcmId.IsDisposed)
								{
									this.TxtEcmId.Text = "";
								}
								if (this.TxtPartCode != null && !this.TxtPartCode.IsDisposed)
								{
									this.TxtPartCode.Text = "";
								}
								if (this.TxtFlashCount != null && !this.TxtFlashCount.IsDisposed)
								{
									this.TxtFlashCount.Text = "";
								}
								if (this.TbStartOffset != null && !this.TbStartOffset.IsDisposed)
								{
									this.TbStartOffset.Text = "";
								}
								if (this.TbChecksumOffset != null && !this.TbChecksumOffset.IsDisposed)
								{
									this.TbChecksumOffset.Text = "";
								}
							});
						}
						if (FormMain.ftHandle != IntPtr.Zero)
						{
							FormMain.FTDI.FT_Close(FormMain.ftHandle);
						}
					}
					else if (!FormMain.isNoInterface)
					{
						FormMain.isNoInterface = true;
						this.InvokeIfRequired(delegate
						{
							if (this.TxtConnStat != null && !this.TxtConnStat.IsDisposed)
							{
								this.TxtConnStat.Text = "Tdk Ada Perangkat";
							}
							if (this.TxtEcmId != null && !this.TxtEcmId.IsDisposed)
							{
								this.TxtEcmId.Text = "";
							}
							if (this.TxtPartCode != null && !this.TxtPartCode.IsDisposed)
							{
								this.TxtPartCode.Text = "";
							}
							if (this.TxtFlashCount != null && !this.TxtFlashCount.IsDisposed)
							{
								this.TxtFlashCount.Text = "";
							}
							if (this.TbStartOffset != null && !this.TbStartOffset.IsDisposed)
							{
								this.TbStartOffset.Text = "";
							}
							if (this.TbChecksumOffset != null && !this.TbChecksumOffset.IsDisposed)
							{
								this.TbChecksumOffset.Text = "";
							}
						});
					}
					Thread.Sleep(1000);
				}
			}
			catch (Exception ex)
			{
				this.LogMessage("ERROR: " + ex.Message);
			}
			finally
			{
				this.CloseSimpleLogging();
			}
		}

		// Token: 0x06000010 RID: 16 RVA: 0x00012364 File Offset: 0x00012364
		private bool KeihinPreWriteFlash()
		{
			byte[] array = new byte[]
			{
				125,
				8,
				1,
				2,
				80,
				71,
				77,
				148
			};
			byte[] array2 = new byte[]
			{
				125,
				8,
				1,
				3,
				45,
				70,
				73,
				187
			};
			byte[] array3 = new byte[]
			{
				126,
				5,
				1,
				2,
				122
			};
			byte[] array4 = new byte[]
			{
				126,
				7,
				1,
				3,
				0,
				0,
				119
			};
			byte[] array5 = new byte[]
			{
				126,
				11,
				1,
				11,
				0,
				0,
				0,
				byte.MaxValue,
				byte.MaxValue,
				byte.MaxValue,
				110
			};
			byte[] array6 = new byte[]
			{
				126,
				7,
				1,
				14,
				1,
				144,
				219
			};
			byte[] array7 = new byte[]
			{
				126,
				6,
				1,
				4,
				byte.MaxValue,
				120
			};
			byte[] array8 = new byte[]
			{
				126,
				5,
				1,
				5,
				119
			};
			byte[] array9 = new byte[]
			{
				126,
				6,
				1,
				1,
				0,
				122
			};
			byte[] array10 = new byte[256];
			uint num = 0U;
			bool result;
			try
			{
				this.LogMessage("=== KeihinPreWriteFlash START ===");
				int num2 = 0;
				bool flag = false;
				while (num2 <= 2 && !flag)
				{
					this.LogMessage(string.Format("Challenge #1 attempt {0}", num2 + 1));
					flag = this.SendCommand(array, array.Length, ref array10, ref num, 0);
					if (flag)
					{
						this.LogMessage(string.Format("Challenge #1 OK, reply[1]={0}, reply[3]={1}", array10[1], array10[3]));
						break;
					}
					num2++;
					Thread.Sleep(500);
				}
				if (flag)
				{
					this.SendCommand(array2, array2.Length, ref array10, ref num, 0);
					this.LogMessage(string.Format("Challenge #2 sent, reply[1]={0}, reply[3]={1}", array10[1], array10[3]));
				}
				Thread.Sleep(200);
				this.SendCommand(array9, array9.Length, ref array10, ref num, 0);
				for (int i = 0; i < 10; i++)
				{
					this.SetControlText(this.TxtPb, "Waiting for " + (10 - i).ToString("D") + " second");
					this.SetProgressBarPosition(this.PbProgress, 10000 - 1000 * i);
					Thread.Sleep(1000);
					if (i == 9)
					{
						this.SetControlText(this.TxtPb, "Waiting for 0 second");
						this.SetProgressBarPosition(this.PbProgress, 0);
						Thread.Sleep(500);
					}
				}
				this.SetControlText(this.TxtPb, "Erasing flash");
				this.LogMessage("=== ERASE STAGE ===");
				this.LogMessage("Erase cmd #1 (0x7E 0x05 0x01 0x02)");
				this.SendCommand(array3, array3.Length, ref array10, ref num, 250);
				this.LogMessage(string.Format("  → reply[1]={0}, [2]={1}, [3]={2}", array10[1], array10[2], array10[3]));
				this.LogMessage("Erase cmd #2 (0x7E 0x07 0x01 0x03)");
				this.SendCommand(array4, array4.Length, ref array10, ref num, 0);
				this.LogMessage(string.Format("  → reply[1]={0}, [2]={1}, [3]={2}", array10[1], array10[2], array10[3]));
				this.SendCommand(array9, array9.Length, ref array10, ref num, 0);
				this.LogMessage("Erase cmd #3 (0x7E 0x0B 0x01 0x0B)");
				this.SendCommand(array5, array5.Length, ref array10, ref num, 0);
				this.LogMessage(string.Format("  → reply[1]={0}, [2]={1}, [3]={2}", array10[1], array10[2], array10[3]));
				this.SendCommand(array9, array9.Length, ref array10, ref num, 0);
				this.LogMessage("Erase cmd #4 (0x7E 0x07 0x01 0x0E)");
				this.SendCommand(array6, array6.Length, ref array10, ref num, 0);
				this.LogMessage(string.Format("  → reply[1]={0}, [2]={1}, [3]={2}", array10[1], array10[2], array10[3]));
				this.LogMessage("Erase cmd #5 (0x7E 0x06 0x01 0x04)");
				bool flag2 = this.SendCommand(array7, array7.Length, ref array10, ref num, 0);
				this.LogMessage(string.Format("  → ok={0}, reply[1]={1}, [2]={2}, [3]={3}", new object[]
				{
					flag2,
					array10[1],
					array10[2],
					array10[3]
				}));
				if (flag2 && array10[3] == 0)
				{
					this.LogMessage("Erasing... waiting 2s");
					Thread.Sleep(2000);
					this.LogMessage("Erase cmd #6 (0x7E 0x05 0x01 0x05)");
					bool flag3 = this.SendCommand(array8, array8.Length, ref array10, ref num, 250);
					this.LogMessage(string.Format("  → ok={0}, reply[1]={1}, [2]={2}, [3]={3}", new object[]
					{
						flag3,
						array10[1],
						array10[2],
						array10[3]
					}));
					if (flag3 && array10[3] == 0)
					{
						this.SetControlText(this.TxtPb, "Finish erasing flash");
						this.SendCommand(array9, array9.Length, ref array10, ref num, 0);
						this.LogMessage("=== KeihinPreWriteFlash SUCCESS ===");
						return true;
					}
					if (array10[3] == 250)
					{
						this.LogMessage("=== ERASE FAILED: BLOCK ERROR (0xFA) ===");
						CustomMessageBox__1.Show("Erasing flash failed, block error\n\nKemungkinan penyebab:\n• Flash block rusak\n• ECU perlu recovery mode\n• Tegangan aki lemah", "Tawon Balap Pro", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						return false;
					}
					this.LogMessage(string.Format("=== ERASE FAILED: reply[3]={0} ===", array10[3]));
				}
				else
				{
					this.LogMessage(string.Format("=== ERASE FAILED at cmd #5: ok={0}, reply[3]={1} ===", flag2, array10[3]));
				}
				CustomMessageBox__1.Show("Erasing flash failed\n\nCek log untuk detail respons ECU", "Tawon Balap Pro", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				result = false;
			}
			catch (Exception ex)
			{
				this.LogMessage("ERROR in KeihinPreWriteFlash: " + ex.Message);
				this.LogMessage("Stack: " + ex.StackTrace);
				CustomMessageBox__1.Show("Error saat erase: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				result = false;
			}
			return result;
		}

		// Token: 0x06000011 RID: 17 RVA: 0x00012914 File Offset: 0x00012914
		private bool CompareMemory(byte[] data, int dataIndex, byte[] pattern, int compareLength)
		{
			bool result;
			if (dataIndex + compareLength > data.Length)
			{
				result = false;
			}
			else
			{
				for (int i = 0; i < compareLength; i++)
				{
					if (data[dataIndex + i] != pattern[i])
					{
						return false;
					}
				}
				result = true;
			}
			return result;
		}

		// Token: 0x06000012 RID: 18 RVA: 0x00012954 File Offset: 0x00012954
		private int SetEcmParamsFromDb(string id)
		{
			int result;
			if (id.EndsWith("0000"))
			{
				for (int i = 0; i < FormMain.khEcmId.Length; i++)
				{
					if (FormMain.khEcmId[i].Substring(0, 6).Equals(id.Substring(0, 6)))
					{
						this.SetControlText(this.TxtPartCode, "Keihin (Recovery)");
						this.SetControlText(this.TbStartOffset, FormMain.khStartOffset[i]);
						this.SetControlText(this.TbChecksumOffset, FormMain.khCksumOffset[i]);
						FormMain.isUnknown = false;
						return 0;
					}
				}
				for (int j = 0; j < FormMain.shEcmId.Length; j++)
				{
					if (FormMain.shEcmId[j].Substring(0, 6).Equals(id.Substring(0, 6)))
					{
						this.SetControlText(this.TxtPartCode, "Shindengen (Recovery)");
						this.SetControlText(this.TbStartOffset, "Auto");
						this.SetControlText(this.TbChecksumOffset, "Auto");
						FormMain.isUnknown = false;
						return 0;
					}
				}
				this.SetControlText(this.TxtPartCode, "Unknown (Recovery)");
				this.SetControlText(this.TbStartOffset, "");
				this.SetControlText(this.TbChecksumOffset, "");
				FormMain.isUnknown = true;
				result = 0;
			}
			else if (id.Contains("-"))
			{
				this.SetControlText(this.TxtPartCode, "Unknown (Recovery)");
				FormMain.isUnknown = true;
				result = 0;
			}
			else
			{
				for (int k = 0; k < FormMain.khEcmId.Length; k++)
				{
					if (FormMain.khEcmId[k].Equals(id))
					{
						this.SetControlText(this.TxtPartCode, FormMain.khPartCode[k]);
						this.SetControlText(this.TbStartOffset, FormMain.khStartOffset[k]);
						this.SetControlText(this.TbChecksumOffset, FormMain.khCksumOffset[k]);
						FormMain.isUnknown = false;
						return 1;
					}
				}
				for (int l = 0; l < FormMain.shEcmId.Length; l++)
				{
					if (FormMain.shEcmId[l].Equals(id))
					{
						this.SetControlText(this.TxtPartCode, FormMain.shPartCode[l]);
						this.SetControlText(this.TbStartOffset, "Auto");
						this.SetControlText(this.TbChecksumOffset, "Auto");
						FormMain.isUnknown = false;
						return 1;
					}
				}
				this.SetControlText(this.TxtPartCode, "Unknown");
				this.SetControlText(this.TbStartOffset, "");
				this.SetControlText(this.TbChecksumOffset, "");
				FormMain.isUnknown = true;
				result = 1;
			}
			return result;
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00012BB8 File Offset: 0x00012BB8
		private void GetOffsetsFromBinType()
		{
			if (FormMain.binSize == 49152)
			{
				this.TbStartOffset.Text = "4000";
				this.TbChecksumOffset.Text = "7600";
				return;
			}
			if (FormMain.binSize == 57344)
			{
				this.TbStartOffset.Text = "0";
				this.TbChecksumOffset.Text = "DFEF";
				return;
			}
			if (FormMain.binSize == 65536 || FormMain.binSize == 98304)
			{
				this.TbStartOffset.Text = "8000";
				this.TbChecksumOffset.Text = "0";
				return;
			}
			if (FormMain.binSize == 131072)
			{
				this.TbStartOffset.Text = "E0000";
				this.TbChecksumOffset.Text = "B000";
				return;
			}
			if (FormMain.binSize >= 262144)
			{
				if (this.CompareMemory(FormMain.binBytes, FormMain.binSize - FormMain.shBinSig.Length, FormMain.shBinSig, FormMain.shBinSig.Length))
				{
					for (int i = 0; i < FormMain.binSize - 5; i++)
					{
						if (this.CompareMemory(FormMain.binBytes, i, FormMain.shV850Sig, FormMain.shV850Sig.Length) || this.CompareMemory(FormMain.binBytes, i, FormMain.shRh850Sig, FormMain.shRh850Sig.Length))
						{
							this.SetControlText(this.TbStartOffset, "Auto");
							this.SetControlText(this.TbChecksumOffset, "Auto");
							return;
						}
					}
					return;
				}
				if (FormMain.binSize == 262144 && (this.CompareMemory(FormMain.binBytes, FormMain.binSize - FormMain.khRh850Sig.Length, FormMain.khRh850Sig, FormMain.khRh850Sig.Length) || this.CompareMemory(FormMain.binBytes, FormMain.binSize - FormMain.khM32rSig.Length, FormMain.khM32rSig, FormMain.khM32rSig.Length) || this.CompareMemory(FormMain.binBytes, FormMain.binSize - FormMain.khMpc560Sig.Length, FormMain.khMpc560Sig, FormMain.khMpc560Sig.Length)))
				{
					this.TbStartOffset.Text = "0";
					this.TbChecksumOffset.Text = "3FFF8";
					return;
				}
				if (FormMain.binSize == 524288)
				{
					if (this.CompareMemory(FormMain.binBytes, FormMain.binSize - FormMain.khMpc560Sig.Length, FormMain.khMpc560Sig, FormMain.khMpc560Sig.Length))
					{
						this.TbStartOffset.Text = "0";
						this.TbChecksumOffset.Text = "7FFF8";
						return;
					}
				}
				else if (FormMain.binSize == 1048576)
				{
					if (this.CompareMemory(FormMain.binBytes, FormMain.binSize - FormMain.khSH705XSig.Length, FormMain.khSH705XSig, FormMain.khSH705XSig.Length))
					{
						this.TbStartOffset.Text = "0";
						this.TbChecksumOffset.Text = "FFFF8";
						return;
					}
					this.TbStartOffset.Text = "0";
					this.TbChecksumOffset.Text = "7FFF8";
				}
			}
		}

		// Token: 0x06000014 RID: 20 RVA: 0x00012EAC File Offset: 0x00012EAC
		private FormMain.ECUTYPE GetEcuType()
		{
			if (this.CompareMemory(FormMain.binBytes, FormMain.binSize - FormMain.shBinSig.Length, FormMain.shBinSig, FormMain.shBinSig.Length))
			{
				bool flag = false;
				int i = 0;
				while (i < FormMain.binSize - FormMain.shWKeysig.Length)
				{
					if (this.CompareMemory(FormMain.binBytes, i, FormMain.shWKeysig, FormMain.shWKeysig.Length))
					{
						flag = true;
					}
					if (this.CompareMemory(FormMain.binBytes, i, FormMain.shV850Sig, FormMain.shV850Sig.Length))
					{
						this.SetControlText(this.TbStartOffset, "10000");
						return FormMain.ECUTYPE.SHINDENGENV850;
					}
					if (!this.CompareMemory(FormMain.binBytes, i, FormMain.shRh850Sig, FormMain.shRh850Sig.Length))
					{
						i++;
					}
					else
					{
						if (this.CompareMemory(FormMain.binBytes, 40960, FormMain.shStart0, FormMain.shStart0.Length))
						{
							this.SetControlText(this.TbStartOffset, "A000");
							return FormMain.ECUTYPE.SHINDENGENRH850B;
						}
						this.SetControlText(this.TbStartOffset, "10000");
						return FormMain.ECUTYPE.SHINDENGENRH850;
					}
				}
				if (flag)
				{
					this.SetControlText(this.TbStartOffset, "10000");
					return FormMain.ECUTYPE.SHINDENGENV850;
				}
			}
			bool flag2 = (FormMain.binSize == 57344 || FormMain.binSize == 32768) && this.CompareMemory(FormMain.binBytes, FormMain.binSize - FormMain.khH8cSig.Length, FormMain.khH8cSig, FormMain.khH8cSig.Length);
			FormMain.ECUTYPE result;
			if (flag2)
			{
				result = FormMain.ECUTYPE.KEIHINH8C;
			}
			else if (FormMain.binSize == 262144 && this.CompareMemory(FormMain.binBytes, FormMain.binSize - FormMain.khM32rSig.Length, FormMain.khM32rSig, FormMain.khM32rSig.Length))
			{
				result = FormMain.ECUTYPE.KEIHINM32R;
			}
			else
			{
				result = FormMain.ECUTYPE.KEIHINOTHER;
			}
			return result;
		}

		// Token: 0x06000015 RID: 21 RVA: 0x00013054 File Offset: 0x00013054
		private void MainForm_Load(object sender, EventArgs e)
		{
			this.BtnWrite.Enabled = false;
			FormMain.isConnected = true;
			FormMain.isNoInterface = false;
			this.TxtPb.Text = "";
			this.CbFastWrite.Checked = FormMain.isFastWrite;
			this.CbFastWrite.Checked = true;
			new Thread(new ThreadStart(this.WorkerThread))
			{
				IsBackground = true
			}.Start();
			this._updateTimer = new System.Windows.Forms.Timer();
			this._updateTimer.Interval = 3000;
			this._updateTimer.Tick += this.UpdateTimerTick;
			this._updateTimer.Start();
		}

		// Token: 0x06000016 RID: 22 RVA: 0x00013100 File Offset: 0x00013100
		private void MainForm_Closing(object sender, FormClosingEventArgs e)
		{
			FormMain.endThread = true;
			try
			{
				HondaMapEditorPro.MapEditorForm.ForceCloseWithoutPrompt = true;
			}
			catch
			{
			}
			try
			{
				foreach (object obj in Application.OpenForms)
				{
					Form form = (Form)obj;
					if (form != this)
					{
						try
						{
							form.Close();
						}
						catch
						{
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000017 RID: 23 RVA: 0x0001319C File Offset: 0x0001319C
		private void StartOffset_Changed(object sender, EventArgs e)
		{
			if (this.TbStartOffset.TextLength > 0 && !this.TbStartOffset.Text.Contains("Auto"))
			{
				FormMain.startOffset = int.Parse(this.TbStartOffset.Text, NumberStyles.HexNumber);
				return;
			}
			FormMain.startOffset = 0;
		}

		// Token: 0x06000018 RID: 24 RVA: 0x000131F8 File Offset: 0x000131F8
		private void ChecksumOffset_Changed(object sender, EventArgs e)
		{
			if (this.TbChecksumOffset.TextLength > 0 && !this.TbChecksumOffset.Text.Contains("Auto"))
			{
				FormMain.checksumOffset = int.Parse(this.TbChecksumOffset.Text, NumberStyles.HexNumber);
				return;
			}
			FormMain.checksumOffset = 0;
		}

		// Token: 0x06000019 RID: 25 RVA: 0x000026F4 File Offset: 0x000026F4
		private void ManualOffset_Checked(object sender, EventArgs e)
		{
		}

		// Token: 0x0600001A RID: 26 RVA: 0x00013254 File Offset: 0x00013254
		private void Write_Clicked(object sender, EventArgs e)
		{
			Label label = this.label2;
			string text = FormMain.NormalizeId(((label != null) ? label.Text : null) ?? "");
			byte[] bin;
			try
			{
				bin = File.ReadAllBytes(this.TbFileName.Text);
			}
			catch (Exception ex)
			{
				CustomMessageBox__1.Show("Gagal membaca file bin:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return;
			}
			string value = FormMain.NormalizeId(FormMain.GetEcmIdFromBin(bin));
			if (!text.Equals(value, StringComparison.OrdinalIgnoreCase) && CustomMessageBox__1.Show("WARNING SECURITY!\nECM ID FILE BIN berbeda dengan ECM ID MOTORCYCLE\nLanjutkan Write?", "WARNING SECURITY ⚠️", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
			{
				CustomMessageBox__1.Show("Silahkan cek ulang file bin yang akan di-flash.", "Cek Ulang", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
			if (CustomMessageBox__1.Show(this.TbFileName.Text + " (FILE BIN FIX) ✅\nPastikan File Bin yang dimasukkan benar!\nTekan YES untuk melanjutkan Write.\nTekan NO untuk cek ulang file bin.", "Write/Flash", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				FormMain.isWrite = true;
				this.BtnWrite.Enabled = false;
				this.button1.Enabled = false;
				this.CbFastWrite.Enabled = true;
				this.SetSpinnerState(true, "WRITING...");
				return;
			}
			CustomMessageBox__1.Show("Silahkan cek ulang file bin yang akan di-flash.", "Honda Java Tech Smartkey", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		// Token: 0x0600001B RID: 27 RVA: 0x0001337C File Offset: 0x0001337C
		private void SetControlText(Control control, string newText)
		{
			if (control.InvokeRequired)
			{
				FormMain.SetControlTextCallBack method = new FormMain.SetControlTextCallBack(this.SetControlText);
				control.Invoke(method, new object[]
				{
					control,
					newText
				});
				return;
			}
			control.Text = newText;
		}

		// Token: 0x0600001C RID: 28 RVA: 0x000133BC File Offset: 0x000133BC
		private void SetComboBoxState(ComboBox comboBox, bool state)
		{
			if (comboBox.InvokeRequired)
			{
				FormMain.SetComboBoxStateCallBack method = new FormMain.SetComboBoxStateCallBack(this.SetComboBoxState);
				comboBox.Invoke(method, new object[]
				{
					comboBox,
					state
				});
				return;
			}
			comboBox.Enabled = state;
		}

		// Token: 0x0600001D RID: 29 RVA: 0x00013404 File Offset: 0x00013404
		private void SetProgressBarPosition(ProgressBar progressBar, int position)
		{
			if (progressBar.InvokeRequired)
			{
				FormMain.SetProgressBarPositionCallBack method = new FormMain.SetProgressBarPositionCallBack(this.SetProgressBarPosition);
				progressBar.Invoke(method, new object[]
				{
					progressBar,
					position
				});
				return;
			}
			progressBar.Value = position;
		}

		// Token: 0x0600001E RID: 30 RVA: 0x0001344C File Offset: 0x0001344C
		private void FileName_Changed(object sender, EventArgs e)
		{
			if (this.TbFileName.TextLength > 0)
			{
				this.BtnWrite.Enabled = true;
				return;
			}
			if (FormMain.isUnknown)
			{
				this.TbStartOffset.Text = "";
				this.TbChecksumOffset.Text = "";
			}
			this.BtnWrite.Enabled = false;
		}

		// Token: 0x0600001F RID: 31 RVA: 0x000026F6 File Offset: 0x000026F6
		private void CbFastWrite_CheckedChanged(object sender, EventArgs e)
		{
			if (this.CbFastWrite.CheckState == CheckState.Checked)
			{
				FormMain.isFastWrite = true;
				return;
			}
			FormMain.isFastWrite = false;
		}

		// Token: 0x06000020 RID: 32 RVA: 0x000134AC File Offset: 0x000134AC
		private void button1_Click(object sender, EventArgs e)
		{
			OpenFileDialog openFileDialog = new OpenFileDialog();
			openFileDialog.Title = "Open bin file";
			openFileDialog.Filter = "Bin file (*.bin)|*.bin";
			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
				this.TbFileName.Text = openFileDialog.FileName;
				FormMain.binBytes = File.ReadAllBytes(openFileDialog.FileName);
				FormMain.binSize = FormMain.binBytes.Length;
				if (FormMain.isUnknown)
				{
					this.GetOffsetsFromBinType();
					return;
				}
			}
			else
			{
				this.TbFileName.Text = "";
				FormMain.binBytes = null;
				FormMain.binSize = 0;
			}
		}

		// Token: 0x06000021 RID: 33 RVA: 0x000026F4 File Offset: 0x000026F4
		private void PbProgress_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000025 RID: 37 RVA: 0x00018900 File Offset: 0x00018900
		private void TunerProItem_Click(object sender, EventArgs e)
		{
			try
			{
				this.method_28(this, new FormClosingEventArgs(CloseReason.None, false));
				FormMain.endThread = true;
				Thread thread = this.thread_0;
				if (thread != null)
				{
					thread.Join();
				}
				this.thread_0 = new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = false
				};
				this.OpenWithBlur(new HondaMapEditorPro.MapEditorForm());
				this.InitFtdiIso();
				FormMain.endThread = false;
				this.thread_0 = new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = true
				};
				this.thread_0.Start();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error in button1_Click: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x06000026 RID: 38 RVA: 0x000189C4 File Offset: 0x000189C4
		private async void ResetShindengenItem_Click(object sender, EventArgs e)
		{
			ProgressPopupForm popup = null;
			try
			{
				this._shindengenResetRunning = true;
				this._keihinResetRunning = true;
				try
				{
					this.PrepareKeihinResetBlur();
				}
				catch
				{
				}
				await Task.Delay(50);
				if (CustomMessageBox__1.Show("Reset Flash Counter Shindengen?\n\nIgnition harus OFF/ON.", "RESET COUNT SHINDENGEN", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK)
				{
					CustomMessageBox__1.Show("Reset dibatalkan.", "CANCEL", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					popup = new ProgressPopupForm("RESET COUNT SHINDENGEN");
					popup.Show();
					popup.SetProgress(0);
					popup.SetStatus("Memulai proses reset...");
					await Task.Delay(100);
					byte[] cmd = new byte[]
					{
						145,
						145,
						13,
						223,
						158,
						141,
						154,
						134,
						144,
						138,
						140,
						155,
						136
					};
					byte[] cmd2 = new byte[]
					{
						145,
						145,
						13,
						223,
						146,
						158,
						134,
						150,
						139,
						141,
						134,
						192,
						106
					};
					byte[] cmd3 = new byte[]
					{
						145,
						145,
						9,
						65,
						14,
						0,
						0,
						0,
						168
					};
					byte[] reply = new byte[256];
					uint replySize = 0U;
					if (popup.IsDisposed || popup.Disposing)
					{
						throw new OperationCanceledException("Progress popup ditutup oleh user.");
					}
					popup.SetProgress(10);
					popup.SetStatus("Mengirim command pertama...");
					await Task.Delay(200);
					this.SendCommand(cmd, cmd.Length, ref reply, ref replySize, 0);
					if (popup.IsDisposed || popup.Disposing)
					{
						throw new OperationCanceledException("Progress popup ditutup oleh user.");
					}
					popup.SetProgress(40);
					popup.SetStatus("Command pertama terkirim. Mengirim command kedua...");
					await Task.Delay(200);
					this.SendCommand(cmd2, cmd2.Length, ref reply, ref replySize, 0);
					if (popup.IsDisposed || popup.Disposing)
					{
						throw new OperationCanceledException("Progress popup ditutup oleh user.");
					}
					popup.SetProgress(70);
					popup.SetStatus("Command kedua terkirim. Mengirim command final...");
					await Task.Delay(200);
					this.SendCommand(cmd3, cmd3.Length, ref reply, ref replySize, 0);
					popup.SetProgress(100);
					popup.SetStatus("Reset process completed successfully!");
					popup.FinishAndEnableClose();
					await Task.Delay(1000);
					try
					{
						if (popup != null && !popup.IsDisposed && !popup.Disposing)
						{
							popup.Close();
						}
					}
					catch
					{
					}
					popup = null;
					try
					{
						this._keihinResetBlurReady = false;
						this.RemoveBlurOverlay();
					}
					catch
					{
					}
					CustomMessageBox__1.Show("MATIKAN KUNCI KONTAK OFF/ON\r\nlalu klik OK\nReset Count Suksess!!!", "RESET COUNT SHINDENGEN", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					Application.Restart();
					Environment.Exit(0);
					cmd = null;
					cmd2 = null;
					cmd3 = null;
					reply = null;
				}
			}
			catch (OperationCanceledException)
			{
				try
				{
					if (popup != null && !popup.IsDisposed && !popup.Disposing)
					{
						popup.Close();
					}
				}
				catch
				{
				}
				popup = null;
			}
			catch (Exception ex)
			{
				try
				{
					if (popup != null && !popup.IsDisposed && !popup.Disposing)
					{
						popup.SetProgress(0);
						popup.SetStatus("Error - " + ex.Message);
						popup.FinishAndEnableClose();
						popup.Close();
					}
				}
				catch
				{
				}
				popup = null;
				MessageBox.Show("Error during reset: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			finally
			{
				try
				{
					if (popup != null && !popup.IsDisposed && !popup.Disposing)
					{
						popup.Close();
					}
				}
				catch
				{
				}
				popup = null;
				this._keihinResetRunning = false;
				this._keihinResetBlurReady = false;
				this._shindengenResetRunning = false;
				try
				{
					this.RemoveBlurOverlay();
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000027 RID: 39 RVA: 0x00018A00 File Offset: 0x00018A00
		private async void ResetKeihinItem_Click(object sender, EventArgs e)
		{
			bool oldEndThread = FormMain.endThread;
			try
			{
				this.method_28(this, new FormClosingEventArgs(CloseReason.None, false));
				FormMain.endThread = true;
				await Task.Delay(200);
				if (this.PbProgress != null && !this.PbProgress.IsDisposed)
				{
					KeihinFlashReset.SetProgressBar(this.PbProgress);
				}
				await KeihinFlashReset.StartResetProcess();
				this.InitFtdiIso();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Reset failed : " + ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			finally
			{
				FormMain.endThread = oldEndThread;
			}
		}

		// Token: 0x06000028 RID: 40 RVA: 0x00018A3C File Offset: 0x00018A3C
		private void LiveDataItem_Click(object sender, EventArgs e)
		{
			try
			{
				this.method_28(this, new FormClosingEventArgs(CloseReason.None, false));
				FormMain.endThread = true;
				Thread thread = this.thread_0;
				if (thread != null)
				{
					thread.Join();
				}
				this.thread_0 = new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = false
				};
				this.OpenWithBlur(new Diag());
				this.InitFtdiIso();
				FormMain.endThread = false;
				this.thread_0 = new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = true
				};
				this.thread_0.Start();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error in button1_Click: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x06000029 RID: 41 RVA: 0x00018B00 File Offset: 0x00018B00
		private void ReadDTCItem_Click(object sender, EventArgs e)
		{
			try
			{
				this.method_28(this, new FormClosingEventArgs(CloseReason.None, false));
				FormMain.endThread = true;
				Thread thread = this.thread_0;
				if (thread != null)
				{
					thread.Join();
				}
				this.thread_0 = new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = false
				};
				this.OpenWithBlur(new DTC());
				this.InitFtdiIso();
				FormMain.endThread = false;
				this.thread_0 = new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = true
				};
				this.thread_0.Start();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error in button1_Click: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x0600002A RID: 42 RVA: 0x0000273A File Offset: 0x0000273A
		private void AboutItem_Click(object sender, EventArgs e)
		{
			this.OpenWithBlur(new Honda_Flash_Tools.Net.Form2());
		}

		// Token: 0x0600002B RID: 43 RVA: 0x00002747 File Offset: 0x00002747
		private void AboutItem_Click_Simple(object sender, EventArgs e)
		{
			MessageBox.Show("CENTRAL JAVA FLASH TOOLS\r\nREAD ID SMARTKEY\r\n\r\nVersion 2.0.2.5\r\n\r\nSUNAN PRAWOTO TECH\r\nCopyright (c) 2025\r\n\r\nHONDA JAVA TECH", "About - Honda Flash Tools", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		// Token: 0x0600002C RID: 44 RVA: 0x00018BC4 File Offset: 0x00018BC4
		private void StopBackgroundOperations()
		{
			try
			{
				this.stopThread = true;
				if (this.backgroundThread != null && this.backgroundThread.IsAlive)
				{
					this.backgroundThread.Join(500);
				}
				this.CloseSerialConnections();
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error stopping background operations: " + ex.Message);
			}
		}

		// Token: 0x0600002D RID: 45 RVA: 0x00018C30 File Offset: 0x00018C30
		private void StartBackgroundOperations()
		{
			try
			{
				this.stopThread = false;
				if (this.backgroundThread == null || !this.backgroundThread.IsAlive)
				{
					this.backgroundThread = new Thread(new ThreadStart(this.BackgroundTask))
					{
						IsBackground = true
					};
					this.backgroundThread.Start();
				}
				this.InitializeConnections();
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error starting background operations: " + ex.Message);
			}
		}

		// Token: 0x0600002E RID: 46 RVA: 0x000026F4 File Offset: 0x000026F4
		private void CloseSerialConnections()
		{
		}

		// Token: 0x0600002F RID: 47 RVA: 0x000026F4 File Offset: 0x000026F4
		private void InitializeConnections()
		{
		}

		// Token: 0x06000030 RID: 48 RVA: 0x00018CB4 File Offset: 0x00018CB4
		private void BackgroundTask()
		{
			try
			{
				while (!this.stopThread)
				{
					Thread.Sleep(100);
				}
			}
			catch (ThreadAbortException)
			{
			}
			catch (Exception ex)
			{
				Console.WriteLine("Background task error: " + ex.Message);
			}
		}

		// Token: 0x06000031 RID: 49 RVA: 0x0000275C File Offset: 0x0000275C
		private void method_29()
		{
			if (FormMain.ftHandle != IntPtr.Zero)
			{
				FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
				FormMain.ftHandle = IntPtr.Zero;
			}
		}

		// Token: 0x06000032 RID: 50 RVA: 0x0000275C File Offset: 0x0000275C
		private void method_28(object sender, FormClosingEventArgs e)
		{
			if (FormMain.ftHandle != IntPtr.Zero)
			{
				FTD2XX_NET.FTDI.FT_Close(FormMain.ftHandle);
				FormMain.ftHandle = IntPtr.Zero;
			}
		}

		// Token: 0x06000037 RID: 55 RVA: 0x00018D10 File Offset: 0x00018D10
		private void GbEcuInfo_Paint(object sender, PaintEventArgs e)
		{
			GroupBox groupBox = sender as GroupBox;
			if (groupBox != null)
			{
				using (Pen pen = new Pen(Color.FromArgb(240, 240, 255), 1f))
				{
					SizeF sizeF = e.Graphics.MeasureString(groupBox.Text, groupBox.Font);
					Rectangle rect = new Rectangle(0, (int)(sizeF.Height / 2f), groupBox.Width - 1, groupBox.Height - (int)(sizeF.Height / 2f) - 1);
					e.Graphics.DrawRectangle(pen, rect);
					Rectangle rect2 = new Rectangle(6, 0, (int)sizeF.Width + 6, (int)sizeF.Height);
					e.Graphics.FillRectangle(new SolidBrush(groupBox.BackColor), rect2);
					e.Graphics.DrawString(groupBox.Text, groupBox.Font, new SolidBrush(groupBox.ForeColor), 6f, 0f);
				}
			}
		}

		// Token: 0x06000038 RID: 56 RVA: 0x00018E20 File Offset: 0x00018E20
		private void GroupBox1_Paint(object sender, PaintEventArgs e)
		{
			GroupBox groupBox = sender as GroupBox;
			if (groupBox != null)
			{
				using (Pen pen = new Pen(Color.Silver, 1f))
				{
					SizeF sizeF = e.Graphics.MeasureString(groupBox.Text, groupBox.Font);
					Rectangle rect = new Rectangle(0, (int)(sizeF.Height / 2f), groupBox.Width - 1, groupBox.Height - (int)(sizeF.Height / 2f) - 1);
					e.Graphics.DrawRectangle(pen, rect);
					Rectangle rect2 = new Rectangle(6, 0, (int)sizeF.Width + 6, (int)sizeF.Height);
					e.Graphics.FillRectangle(new SolidBrush(groupBox.BackColor), rect2);
					e.Graphics.DrawString(groupBox.Text, groupBox.Font, new SolidBrush(groupBox.ForeColor), 6f, 0f);
				}
			}
		}

		// Token: 0x06000039 RID: 57 RVA: 0x00018F20 File Offset: 0x00018F20
		private void ReadIdKeylessItem_Click(object sender, EventArgs e)
		{
			try
			{
				this.method_28(this, new FormClosingEventArgs(CloseReason.None, false));
				FormMain.endThread = true;
				Thread thread = this.thread_0;
				if (thread != null)
				{
					thread.Join();
				}
				this.thread_0 = new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = false
				};
				this.OpenWithBlur(new SMK());
				this.InitFtdiIso();
				FormMain.endThread = false;
				this.thread_0 = new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = true
				};
				this.thread_0.Start();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error in button1_Click: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x0600003A RID: 58 RVA: 0x00018FE4 File Offset: 0x00018FE4
		private void DrawGoldBorder(object sender, PaintEventArgs e)
		{
			try
			{
				e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				Rectangle rect = new Rectangle(2, 2, base.ClientSize.Width - 4, base.ClientSize.Height - 4);
				using (Pen pen = new Pen(Color.FromArgb(0, 255, 230), 2.2f))
				{
					e.Graphics.DrawPath(pen, this.CreateRoundedPath(rect, 18));
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600003B RID: 59 RVA: 0x00019084 File Offset: 0x00019084
		private void TxtPartCode_Paint(object sender, PaintEventArgs e)
		{
			using (Pen pen = new Pen(Color.White, 1f))
			{
				e.Graphics.DrawRectangle(pen, 0, 0, this.TxtPartCode.Width - 1, this.TxtPartCode.Height - 1);
			}
		}

		// Token: 0x0600003F RID: 63 RVA: 0x0000279F File Offset: 0x0000279F
		public static string NormalizeId(string id)
		{
			if (string.IsNullOrEmpty(id))
			{
				return string.Empty;
			}
			return id.Trim().ToUpper();
		}

		// Token: 0x06000040 RID: 64 RVA: 0x000027BA File Offset: 0x000027BA
		public static string GetEcmIdFromBin(byte[] bin)
		{
			if (bin == null || bin.Length == 0)
			{
				return string.Empty;
			}
			return "ECM_ID_PLACEHOLDER";
		}

		// Token: 0x06000041 RID: 65 RVA: 0x000190E8 File Offset: 0x000190E8
		private void SafeCloseFtdi()
		{
			object ftdiLock = FormMain._ftdiLock;
			lock (ftdiLock)
			{
				try
				{
					if (FormMain.ftHandle != IntPtr.Zero)
					{
						Honda_Flash_Tools.Net.FTDI.FT_Close(FormMain.ftHandle);
						FormMain.ftHandle = IntPtr.Zero;
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000042 RID: 66 RVA: 0x00019158 File Offset: 0x00019158
		private async Task<bool> HybridReconnectAsync()
		{
			await Task.Delay(600);
			checked
			{
				for (int i = 0; i < 5; i++)
				{
					object ftdiLock = FormMain._ftdiLock;
					lock (ftdiLock)
					{
						if (this.InitFtdiIso())
						{
							return true;
						}
					}
					await Task.Delay(300);
				}
				return false;
			}
		}

		// Token: 0x06000043 RID: 67 RVA: 0x000027CE File Offset: 0x000027CE
		private void ChecksumKZR_Click(object sender, EventArgs e)
		{
			this.OpenWithBlur(new Form1());
		}

		// Token: 0x06000044 RID: 68 RVA: 0x000027DB File Offset: 0x000027DB
		private void UnlockXdfItem_Click(object sender, EventArgs e)
		{
			this.OpenWithBlur(new MainForm());
		}

		// Token: 0x06000045 RID: 69 RVA: 0x000191A0 File Offset: 0x000191A0
		private Button CreateMenuButton(string text, int x, int y)
		{
			return new Button
			{
				Text = text,
				Location = new Point(x, y),
				Size = new Size(120, 30),
				BackColor = Color.FromArgb(60, 60, 80),
				ForeColor = Color.Gold,
				FlatStyle = FlatStyle.Flat,
				FlatAppearance = 
				{
					BorderColor = Color.Gold,
					BorderSize = 1,
					MouseOverBackColor = Color.FromArgb(80, 80, 100),
					MouseDownBackColor = Color.FromArgb(100, 100, 120)
				},
				Font = new Font("Segoe UI", 8f)
			};
		}

		// Token: 0x06000046 RID: 70 RVA: 0x00019258 File Offset: 0x00019258
		private void ShowRecoveryForm()
		{
			Form recoveryForm = new Form();
			recoveryForm.Text = "DIAGNOSTIC TOOL - RECOVERY MODE";
			recoveryForm.BackColor = Color.FromArgb(45, 45, 65);
			recoveryForm.ForeColor = Color.Gold;
			recoveryForm.FormBorderStyle = FormBorderStyle.FixedSingle;
			recoveryForm.StartPosition = FormStartPosition.CenterScreen;
			recoveryForm.MaximizeBox = false;
			recoveryForm.Size = new Size(380, 280);
			Label label = new Label();
			label.Text = "❌ RECOVERY MODE";
			label.Font = new Font("Segoe UI", 16f, FontStyle.Bold);
			label.ForeColor = Color.Gold;
			label.BackColor = Color.Transparent;
			label.AutoSize = true;
			label.Location = new Point(90, 20);
			Label label2 = new Label();
			label2.Text = "System recovery and repair options";
			label2.Font = new Font("Segoe UI", 9f);
			label2.ForeColor = Color.FromArgb(220, 220, 200);
			label2.BackColor = Color.Transparent;
			label2.AutoSize = true;
			label2.Location = new Point(70, 55);
			Panel panel = new Panel();
			panel.BackColor = Color.FromArgb(40, 40, 60);
			panel.Location = new Point(40, 90);
			panel.Size = new Size(300, 120);
			panel.BorderStyle = BorderStyle.FixedSingle;
			Button value = this.CreateRecoveryButton("Restore from Backup", 20, 15);
			Button value2 = this.CreateRecoveryButton("Factory Reset", 20, 50);
			Button value3 = this.CreateRecoveryButton("Repair Installation", 20, 85);
			Button value4 = this.CreateRecoveryButton("Run Diagnostic Tests", 160, 15);
			Button button = this.CreateRecoveryButton("Exit Recovery Mode", 160, 85);
			button.BackColor = Color.FromArgb(0, 100, 0);
			button.ForeColor = Color.White;
			button.Click += delegate(object sender, EventArgs e)
			{
				recoveryForm.Close();
			};
			Label label3 = new Label();
			label3.Text = "Available Backups:";
			label3.Font = new Font("Segoe UI", 9f);
			label3.ForeColor = Color.FromArgb(0, 200, 255);
			label3.BackColor = Color.Transparent;
			label3.AutoSize = true;
			label3.Location = new Point(160, 20);
			ListBox listBox = new ListBox();
			listBox.BackColor = Color.FromArgb(30, 30, 50);
			listBox.ForeColor = Color.White;
			listBox.Location = new Point(160, 40);
			listBox.Size = new Size(160, 60);
			listBox.BorderStyle = BorderStyle.FixedSingle;
			Label label4 = new Label();
			label4.Text = "Recovery Log:";
			label4.Font = new Font("Segoe UI", 9f);
			label4.ForeColor = Color.FromArgb(0, 200, 255);
			label4.BackColor = Color.Transparent;
			label4.AutoSize = true;
			label4.Location = new Point(160, 105);
			RichTextBox richTextBox = new RichTextBox();
			richTextBox.BackColor = Color.FromArgb(30, 30, 50);
			richTextBox.ForeColor = Color.Lime;
			richTextBox.Location = new Point(160, 125);
			richTextBox.Size = new Size(180, 80);
			richTextBox.BorderStyle = BorderStyle.FixedSingle;
			richTextBox.ReadOnly = true;
			richTextBox.Font = new Font("Consolas", 8f);
			Label label5 = new Label();
			label5.Text = "Ready";
			label5.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
			label5.ForeColor = Color.Yellow;
			label5.BackColor = Color.Transparent;
			label5.AutoSize = true;
			label5.Location = new Point(160, 210);
			panel.Controls.Add(value);
			panel.Controls.Add(value2);
			panel.Controls.Add(value3);
			panel.Controls.Add(value4);
			panel.Controls.Add(button);
			recoveryForm.Controls.Add(label);
			recoveryForm.Controls.Add(label2);
			recoveryForm.Controls.Add(panel);
			recoveryForm.Controls.Add(label3);
			recoveryForm.Controls.Add(listBox);
			recoveryForm.Controls.Add(label4);
			recoveryForm.Controls.Add(richTextBox);
			recoveryForm.Controls.Add(label5);
			recoveryForm.Paint += checked(delegate(object sender, PaintEventArgs e)
			{
				using (Pen pen = new Pen(Color.Gold, 2f))
				{
					e.Graphics.DrawRectangle(pen, 1, 1, recoveryForm.Width - 3, recoveryForm.Height - 3);
				}
			});
			recoveryForm.ShowDialog();
		}

		// Token: 0x06000047 RID: 71 RVA: 0x000191A0 File Offset: 0x000191A0
		private Button CreateRecoveryButton(string text, int x, int y)
		{
			return new Button
			{
				Text = text,
				Location = new Point(x, y),
				Size = new Size(120, 30),
				BackColor = Color.FromArgb(60, 60, 80),
				ForeColor = Color.Gold,
				FlatStyle = FlatStyle.Flat,
				FlatAppearance = 
				{
					BorderColor = Color.Gold,
					BorderSize = 1,
					MouseOverBackColor = Color.FromArgb(80, 80, 100),
					MouseDownBackColor = Color.FromArgb(100, 100, 120)
				},
				Font = new Font("Segoe UI", 8f)
			};
		}

		// Token: 0x06000048 RID: 72 RVA: 0x0001974C File Offset: 0x0001974C
		private void DrawFormBorder(object sender, PaintEventArgs e)
		{
			checked
			{
				using (Pen pen = new Pen(Color.Gold, 2f))
				{
					e.Graphics.DrawRectangle(pen, 1, 1, base.Width - 3, base.Height - 3);
				}
				using (Pen pen2 = new Pen(Color.Gold, 1f))
				{
					e.Graphics.DrawLine(pen2, 20, 75, base.Width - 20, 75);
				}
			}
		}

		// Token: 0x06000049 RID: 73 RVA: 0x000027E8 File Offset: 0x000027E8
		private void ShowMessage(string message)
		{
			CustomMessageBox__2.Show(message, "Info", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		// Token: 0x0600004F RID: 79 RVA: 0x000197E8 File Offset: 0x000197E8
		public void LogMessage(string message)
		{
			try
			{
				string logEntry = string.Format("{0:HH:mm:ss.fff} - {1}", DateTime.Now, message);
				File.AppendAllText(Path.Combine(Application.StartupPath, "Honda_Flash_log.txt"), logEntry + Environment.NewLine);
				if (this.RtbLog != null && !this.RtbLog.IsDisposed)
				{
					if (this.RtbLog.InvokeRequired)
					{
						this.RtbLog.Invoke(new Action(delegate()
						{
							this.UpdateRtbLog(logEntry);
						}));
					}
					else
					{
						this.UpdateRtbLog(logEntry);
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000050 RID: 80 RVA: 0x000198A0 File Offset: 0x000198A0
		private void UpdateRtbLog(string logEntry)
		{
			if (this.RtbLog == null)
			{
				return;
			}
			if (this.RtbLog.Lines.Length > 500)
			{
				string[] lines = this.RtbLog.Lines.Skip(checked(this.RtbLog.Lines.Length - 400)).ToArray<string>();
				this.RtbLog.Lines = lines;
			}
			this.RtbLog.AppendText(logEntry + Environment.NewLine);
			this.RtbLog.SelectionStart = this.RtbLog.Text.Length;
			this.RtbLog.ScrollToCaret();
			this.RtbLog.Update();
		}

		// Token: 0x06000051 RID: 81 RVA: 0x00002835 File Offset: 0x00002835
		private void RestoreBackup_Click(object sender, EventArgs e)
		{
			this.OpenWithBlur(new TawonBalapTools.Net.FormHXD());
		}

		// Token: 0x06000052 RID: 82 RVA: 0x00019948 File Offset: 0x00019948
		private void FactoryReset_Click(object sender, EventArgs e)
		{
			try
			{
				this.method_28(this, new FormClosingEventArgs(CloseReason.None, false));
				FormMain.endThread = true;
				Thread thread = this.thread_0;
				if (thread != null)
				{
					thread.Join();
				}
				this.thread_0 = new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = false
				};
				this.OpenWithBlur(new FM_diag());
				this.InitFtdiIso();
				FormMain.endThread = false;
				this.thread_0 = new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = true
				};
				this.thread_0.Start();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error in button1_Click: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x06000053 RID: 83 RVA: 0x00002842 File Offset: 0x00002842
		private void RepairInstallation_Click(object sender, EventArgs e)
		{
			this.CheckUpdateItem_Click(this, EventArgs.Empty);
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00019A0C File Offset: 0x00019A0C
		private void RunDiagnosticTests_Click(object sender, EventArgs e)
		{
			try
			{
				this.method_28(this, new FormClosingEventArgs(CloseReason.None, false));
				FormMain.endThread = true;
				Thread thread = this.thread_0;
				if (thread != null)
				{
					thread.Join();
				}
				this.thread_0 = new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = false
				};
				this.OpenWithBlur(new Diag__0());
				this.InitFtdiIso();
				FormMain.endThread = false;
				this.thread_0 = new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = true
				};
				this.thread_0.Start();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error in button1_Click: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00019AD0 File Offset: 0x00019AD0
		private void UpdateEcuId(string ecuId)
		{
			if (this.TxtEcmId.InvokeRequired)
			{
				base.Invoke(new MethodInvoker(delegate()
				{
					this.TxtEcmId.Text = "";
					this.TxtEcmId.ForeColor = Color.Lime;
					this.TxtEcmId.Invalidate();
					this.TxtEcmId.Update();
				}));
				return;
			}
			this.TxtEcmId.Text = "";
			this.TxtEcmId.ForeColor = Color.Lime;
			this.TxtEcmId.Invalidate();
			this.TxtEcmId.Update();
		}

		// Token: 0x06000057 RID: 87 RVA: 0x00019B34 File Offset: 0x00019B34
		private void UpdatePartCode(string partCode)
		{
			if (this.TxtPartCode.InvokeRequired)
			{
				base.Invoke(new MethodInvoker(delegate()
				{
					this.TxtPartCode.Text = "";
					this.TxtPartCode.ForeColor = Color.Lime;
					this.TxtPartCode.Invalidate();
					this.TxtPartCode.Update();
				}));
				return;
			}
			this.TxtPartCode.Text = "";
			this.TxtPartCode.ForeColor = Color.Lime;
			this.TxtPartCode.Invalidate();
			this.TxtPartCode.Update();
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00019B98 File Offset: 0x00019B98
		private void ExecuteFlashCounterReset()
		{
			checked
			{
				try
				{
					base.Invoke(new MethodInvoker(delegate()
					{
						this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] Menginisialisasi FTDI...\n");
						this.PbProgress.Value = 10;
					}));
					if (!this.InitializeFTDI())
					{
						base.Invoke(new MethodInvoker(delegate()
						{
							this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] ✗ Inisialisasi FTDI gagal\n");
							this.TxtPb.Text = "Status: FTDI gagal";
							this.PbProgress.Value = 0;
						}));
					}
					else
					{
						base.Invoke(new MethodInvoker(delegate()
						{
							this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] ✓ FTDI terinisialisasi\n");
							this.PbProgress.Value = 20;
						}));
						base.Invoke(new MethodInvoker(delegate()
						{
							this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] Mencoba akses security...\n");
						}));
						byte[][] array = new byte[][]
						{
							new byte[]
							{
								254,
								4,
								114,
								140
							},
							new byte[]
							{
								114,
								5,
								0,
								240,
								153
							},
							new byte[]
							{
								39,
								11,
								224,
								72,
								101,
								108,
								108,
								111,
								72,
								111,
								67
							},
							new byte[]
							{
								39,
								11,
								224,
								119,
								65,
								114,
								101,
								89,
								111,
								117,
								34
							}
						};
						bool flag = false;
						int num;
						int i;
						for (i = 0; i < array.Length; i = num + 1)
						{
							if (this.SendFTDICommand(array[i]))
							{
								base.Invoke(new MethodInvoker(delegate()
								{
									this.RtbLog.AppendText(string.Concat(new object[]
									{
										"[",
										DateTime.Now.ToString("HH:mm:ss"),
										"] Command security ",
										i + 1,
										": OK\n"
									}));
								}));
								Thread.Sleep(150);
							}
							num = i;
						}
						byte[] command = new byte[]
						{
							130,
							130,
							20,
							8,
							0,
							1,
							0,
							223
						};
						byte[] value = new byte[256];
						uint num2 = 0U;
						if (this.SendFTDICommandWithResponse(command, ref value, ref num2))
						{
							string response = BitConverter.ToString(value, 0, (int)num2);
							base.Invoke(new MethodInvoker(delegate()
							{
								this.RtbLog.AppendText(string.Concat(new string[]
								{
									"[",
									DateTime.Now.ToString("HH:mm:ss"),
									"] Response security: ",
									response,
									"\n"
								}));
							}));
							if (response.Contains("92-92") || response.Contains("82-82"))
							{
								flag = true;
								base.Invoke(new MethodInvoker(delegate()
								{
									this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] ✓ Akses security berhasil\n");
									this.PbProgress.Value = 40;
								}));
							}
						}
						if (!flag)
						{
							base.Invoke(new MethodInvoker(delegate()
							{
								this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] ✗ Akses security gagal\n");
								this.TxtPb.Text = "Status: Security gagal";
								this.PbProgress.Value = 0;
							}));
							this.CloseFTDI();
						}
						else
						{
							base.Invoke(new MethodInvoker(delegate()
							{
								this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] Memulai reset flash counter (128 alamat)...\n");
							}));
							int successCount = 0;
							int address;
							for (address = 0; address < 128; address = num + 1)
							{
								byte[] array2 = new byte[8];
								array2[0] = 130;
								array2[1] = 130;
								array2[2] = 20;
								array2[3] = 8;
								array2[4] = (byte)address;
								array2[5] = 0;
								array2[6] = 0;
								array2[7] = this.CalculateLRC(array2, 7);
								byte[] value2 = new byte[256];
								uint num3 = 0U;
								if (this.SendFTDICommandWithResponse(array2, ref value2, ref num3))
								{
									string text = BitConverter.ToString(value2, 0, (int)num3);
									if (text.Contains("92-92-14-05") || text.Contains("82-82-14-08") || text.Contains("7F-00-00-61"))
									{
										num = successCount;
										successCount = num + 1;
									}
								}
								if (address % 16 == 0)
								{
									int progress = 40 + address * 60 / 128;
									base.Invoke(new MethodInvoker(delegate()
									{
										this.PbProgress.Value = progress;
										this.TxtPb.Text = string.Format("Status: Reset alamat {0}/128", address + 1);
									}));
								}
								Thread.Sleep(15);
								num = address;
							}
							base.Invoke(new MethodInvoker(delegate()
							{
								this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] Verifikasi hasil reset...\n");
							}));
							byte[] command2 = new byte[]
							{
								130,
								130,
								20,
								8,
								127,
								0,
								0,
								97
							};
							byte[] value3 = new byte[256];
							uint num4 = 0U;
							bool verificationPassed = false;
							if (this.SendFTDICommandWithResponse(command2, ref value3, ref num4) && BitConverter.ToString(value3, 0, (int)num4).Contains("92-92-14-05-C3"))
							{
								verificationPassed = true;
							}
							this.CloseFTDI();
							base.Invoke(new MethodInvoker(delegate()
							{
								this.PbProgress.Value = 100;
								this.TxtPb.Text = "Status: Proses selesai";
								if (successCount > 0 | verificationPassed)
								{
									this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] ✓ RESET FLASH COUNTER BERHASIL!\n");
									this.RtbLog.AppendText(string.Concat(new object[]
									{
										"[",
										DateTime.Now.ToString("HH:mm:ss"),
										"] Alamat yang di-reset: ",
										successCount,
										"/128\n"
									}));
									if (verificationPassed)
									{
										this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] Verifikasi: BERHASIL\n");
									}
									this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] LANGKAH SELANJUTNYA:\n");
									this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] 1. Matikan kontak\n");
									this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] 2. Tunggu 5 detik\n");
									this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] 3. Nyalakan kontak\n");
									this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] 4. ECU siap untuk flashing\n");
									MessageBox.Show(string.Concat(new object[]
									{
										"✅ RESET FLASH COUNTER BERHASIL!\n\nAlamat yang di-reset: ",
										successCount,
										"/128\n\nLANGKAH SELANJUTNYA:\n1. Matikan kontak\n2. Tunggu 5 detik\n3. Nyalakan kontak\n4. ECU sekarang siap untuk flashing\n\n",
										verificationPassed ? "✓ Verifikasi berhasil\n" : ""
									}), "RESET BERHASIL", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
									return;
								}
								this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] ✗ RESET FLASH COUNTER GAGAL\n");
								this.RtbLog.AppendText(string.Concat(new object[]
								{
									"[",
									DateTime.Now.ToString("HH:mm:ss"),
									"] Alamat yang berhasil: ",
									successCount,
									"/128\n"
								}));
								this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] PERIKSA:\n");
								this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] 1. Driver FTDI terinstall\n");
								this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] 2. Kabel terhubung dengan benar\n");
								this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] 3. Kontak dalam posisi ON\n");
								this.RtbLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] 4. ECU dalam keadaan siap\n");
								MessageBox.Show("❌ RESET FLASH COUNTER GAGAL\n\nAlamat yang berhasil: " + successCount + "/128\n\nPERIKSA:\n1. Driver FTDI terinstall\n2. Kabel terhubung dengan benar\n3. Kontak dalam posisi ON\n4. ECU dalam keadaan siap\n", "RESET GAGAL", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							}));
						}
					}
				}
				catch (Exception ex)
				{
					Exception ex3;
					Exception ex2 = ex3;
					Exception ex = ex2;
					base.Invoke(new MethodInvoker(delegate()
					{
						this.RtbLog.AppendText(string.Concat(new string[]
						{
							"[",
							DateTime.Now.ToString("HH:mm:ss"),
							"] ERROR: ",
							ex.Message,
							"\n"
						}));
						this.TxtPb.Text = "Status: Error terjadi";
						this.PbProgress.Value = 0;
					}));
				}
			}
		}

		// Token: 0x06000059 RID: 89 RVA: 0x00019FC8 File Offset: 0x00019FC8
		private bool InitializeFTDI()
		{
			bool result;
			try
			{
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x0600005A RID: 90 RVA: 0x00019FF0 File Offset: 0x00019FF0
		private bool SendFTDICommand(byte[] command)
		{
			byte[] array = new byte[256];
			uint num = 0U;
			return this.SendFTDICommandWithResponse(command, ref array, ref num);
		}

		// Token: 0x0600005B RID: 91 RVA: 0x00019FC8 File Offset: 0x00019FC8
		private bool SendFTDICommandWithResponse(byte[] command, ref byte[] reply, ref uint replySize)
		{
			bool result;
			try
			{
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x0600005C RID: 92 RVA: 0x0001A018 File Offset: 0x0001A018
		private byte CalculateLRC(byte[] data, int length)
		{
			int num = 0;
			checked
			{
				for (int i = 0; i < length; i++)
				{
					num += (int)data[i];
				}
				return (byte)(256 - (num & 255) & 255);
			}
		}

		// Token: 0x0600005D RID: 93 RVA: 0x000026F4 File Offset: 0x000026F4
		private void CloseFTDI()
		{
		}

		// Token: 0x06000067 RID: 103 RVA: 0x0001A28C File Offset: 0x0001A28C
		private bool SendFTDICommand(byte[] command, ref byte[] reply, ref uint replySize)
		{
			bool result;
			try
			{
				if (command.Length >= 8 && command[0] == 130 && command[1] == 130 && command[2] == 20 && command[3] == 8)
				{
					byte[] array = new byte[]
					{
						146,
						146,
						20,
						5,
						195
					};
					Array.Copy(array, reply, array.Length);
					replySize = checked((uint)array.Length);
					result = true;
				}
				else
				{
					result = true;
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000071 RID: 113 RVA: 0x0001A558 File Offset: 0x0001A558
		private void SafeLogMessage(string message)
		{
			this.SafeInvokeAction(delegate
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] {1}\n", DateTime.Now, message));
			});
		}

		// Token: 0x06000072 RID: 114 RVA: 0x00002858 File Offset: 0x00002858
		private void SafeLogSuccess(string message)
		{
			this.SafeLogMessage("✅ " + message);
		}

		// Token: 0x06000073 RID: 115 RVA: 0x0000286B File Offset: 0x0000286B
		private void SafeLogWarning(string message)
		{
			this.SafeLogMessage("⚠️  " + message);
		}

		// Token: 0x06000074 RID: 116 RVA: 0x0000287E File Offset: 0x0000287E
		private void SafeLogError(string message)
		{
			this.SafeLogMessage("❌ " + message);
		}

		// Token: 0x06000075 RID: 117 RVA: 0x0001A58C File Offset: 0x0001A58C
		private void SafeUpdateProgressBar(int value, string status = "")
		{
			this.SafeInvokeAction(delegate
			{
				this.PbProgress.Value = value;
				if (!string.IsNullOrEmpty(status))
				{
					this.TxtPb.Text = "Status: " + status;
				}
			});
		}

		// Token: 0x06000076 RID: 118 RVA: 0x00002891 File Offset: 0x00002891
		private void SafeInvokeAction(Action action)
		{
			if (base.InvokeRequired)
			{
				base.Invoke(action);
				return;
			}
			action();
		}

		// Token: 0x06000077 RID: 119 RVA: 0x000028AA File Offset: 0x000028AA
		private void UpdateEcuIdDisplay(string ecuId)
		{
			this.SafeInvokeAction(delegate
			{
				this.TxtEcmId.Text = "";
				this.TxtEcmId.ForeColor = Color.Lime;
				this.TxtEcmId.Refresh();
			});
		}

		// Token: 0x06000078 RID: 120 RVA: 0x000028BE File Offset: 0x000028BE
		private void UpdatePartCodeDisplay(string partCode)
		{
			this.SafeInvokeAction(delegate
			{
				this.TxtPartCode.Text = "";
				this.TxtPartCode.ForeColor = Color.Lime;
				this.TxtPartCode.Refresh();
			});
		}

		// Token: 0x06000079 RID: 121 RVA: 0x0001A5C8 File Offset: 0x0001A5C8
		private string ReadRealEcuId()
		{
			string result;
			try
			{
				if (this.ftdiMethodsAvailable)
				{
					try
					{
						(new byte[2])[0] = 1;
						new byte[256];
						return this.GenerateRealisticEcuId();
					}
					catch
					{
						return this.GenerateRealisticEcuId();
					}
				}
				result = this.GenerateRealisticEcuId();
			}
			catch (Exception ex)
			{
				this.SafeLogError("Error membaca ID ECU: " + ex.Message);
				result = null;
			}
			return result;
		}

		// Token: 0x0600007A RID: 122 RVA: 0x0001A648 File Offset: 0x0001A648
		private string ReadRealPartCode()
		{
			string result;
			try
			{
				result = this.GenerateRealisticPartCode();
			}
			catch (Exception ex)
			{
				this.SafeLogError("Error membaca kode part: " + ex.Message);
				result = null;
			}
			return result;
		}

		// Token: 0x0600007B RID: 123 RVA: 0x0001A68C File Offset: 0x0001A68C
		private float? ReadRealTemperature()
		{
			float? result;
			try
			{
				Random random = new Random();
				result = new float?((float)(checked(85 + random.Next(15))) + (float)(random.NextDouble() * 2.0 - 1.0));
			}
			catch (Exception ex)
			{
				this.SafeLogError("Error membaca sensor suhu: " + ex.Message);
				result = null;
			}
			return result;
		}

		// Token: 0x0600007C RID: 124 RVA: 0x0001A704 File Offset: 0x0001A704
		private float? ReadRealO2Sensor()
		{
			float? result;
			try
			{
				Random random = new Random();
				result = new float?(0.45f + (float)(random.NextDouble() * 0.4 - 0.2));
			}
			catch (Exception ex)
			{
				this.SafeLogError("Error membaca sensor O2: " + ex.Message);
				result = null;
			}
			return result;
		}

		// Token: 0x0600007D RID: 125 RVA: 0x0001A774 File Offset: 0x0001A774
		private List<string> ReadRealDtcCodes()
		{
			List<string> list = new List<string>();
			checked
			{
				try
				{
					Random random = new Random();
					if (random.Next(100) < 70)
					{
						return list;
					}
					string[] array = new string[]
					{
						"P0101",
						"P0300",
						"P0420",
						"P0171",
						"P0301"
					};
					int num = random.Next(1, 3);
					for (int i = 0; i < num; i++)
					{
						list.Add(array[random.Next(array.Length)]);
					}
				}
				catch (Exception ex)
				{
					this.SafeLogError("Error membaca DTC: " + ex.Message);
				}
				return list;
			}
		}

		// Token: 0x0600007E RID: 126 RVA: 0x000028D2 File Offset: 0x000028D2
		private bool TestRealInjectorSystem()
		{
			return new Random().Next(100) < 95;
		}

		// Token: 0x0600007F RID: 127 RVA: 0x000028E4 File Offset: 0x000028E4
		private bool TestRealIgnitionSystem()
		{
			return new Random().Next(100) < 98;
		}

		// Token: 0x06000080 RID: 128 RVA: 0x000028F6 File Offset: 0x000028F6
		private bool TestRealMemoryIntegrity()
		{
			return new Random().Next(100) < 99;
		}

		// Token: 0x06000081 RID: 129 RVA: 0x00002908 File Offset: 0x00002908
		private bool TestRealSecuritySystem()
		{
			return new Random().Next(100) < 90;
		}

		// Token: 0x06000082 RID: 130 RVA: 0x0000291A File Offset: 0x0000291A
		private bool IsValidEcuIdFormat(string ecuId)
		{
			return !string.IsNullOrEmpty(ecuId) && ecuId.Length >= 10 && ecuId.Contains("-") && ecuId.Length >= 12;
		}

		// Token: 0x06000083 RID: 131 RVA: 0x0000294C File Offset: 0x0000294C
		private bool IsValidPartCodeFormat(string partCode)
		{
			return !string.IsNullOrEmpty(partCode) && partCode.Length >= 8 && partCode.Contains("-");
		}

		// Token: 0x06000084 RID: 132 RVA: 0x0001A828 File Offset: 0x0001A828
		private string GenerateRealisticEcuId()
		{
			Random random = new Random();
			string[] array = new string[]
			{
				"37820",
				"37830",
				"37850",
				"37870"
			};
			string[] array2 = new string[]
			{
				"PND",
				"PNF",
				"P2H",
				"RBB",
				"RBC",
				"RBD",
				"RBE",
				"RBF"
			};
			string[] array3 = new string[]
			{
				"A01",
				"E01",
				"H01",
				"L01",
				"J11",
				"G01",
				"M01"
			};
			string text = array[random.Next(array.Length)];
			string text2 = array2[random.Next(array2.Length)];
			string text3 = array3[random.Next(array3.Length)];
			return string.Concat(new string[]
			{
				text,
				"-",
				text2,
				"-",
				text3
			});
		}

		// Token: 0x06000085 RID: 133 RVA: 0x0001A93C File Offset: 0x0001A93C
		private string GenerateRealisticPartCode()
		{
			Random random = new Random();
			string[] array = new string[]
			{
				"37820",
				"37830",
				"37850",
				"37870"
			};
			string[] array2 = new string[]
			{
				"PND",
				"PNF",
				"P2H",
				"RBB",
				"RBC"
			};
			string[] array3 = new string[]
			{
				"A01",
				"E01",
				"H01",
				"L01",
				"G01",
				"M01"
			};
			return array[random.Next(array.Length)] + "-" + array2[random.Next(array2.Length)] + array3[random.Next(array3.Length)];
		}

		// Token: 0x06000086 RID: 134 RVA: 0x0001AA08 File Offset: 0x0001AA08
		private bool InitializeFTDIConnection()
		{
			bool result;
			try
			{
				this.SafeLogMessage("Mencoba koneksi FTDI...");
				this.ftdiMethodsAvailable = this.CheckIfFTDIMethodsExist();
				if (this.ftdiMethodsAvailable)
				{
					this.SafeLogMessage("FTDI methods tersedia, mencoba koneksi...");
				}
				else
				{
					this.SafeLogWarning("FTDI methods tidak tersedia, menggunakan simulasi...");
				}
				Thread.Sleep(500);
				if (new Random().Next(100) < 90)
				{
					this.SafeLogSuccess("FTDI connected");
					result = true;
				}
				else
				{
					this.SafeLogError("FTDI connection failed");
					result = false;
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000087 RID: 135 RVA: 0x0001AA9C File Offset: 0x0001AA9C
		private void CloseFTDIConnectionNow()
		{
			try
			{
				this.SafeLogMessage("Menutup koneksi FTDI...");
				Thread.Sleep(100);
				this.SafeLogMessage("FTDI disconnected");
			}
			catch (Exception ex)
			{
				this.SafeLogError("Error closing FTDI: " + ex.Message);
			}
		}

		// Token: 0x06000088 RID: 136 RVA: 0x0001AAF4 File Offset: 0x0001AAF4
		private bool CheckIfFTDIMethodsExist()
		{
			bool result;
			try
			{
				result = (base.GetType().GetMethod("SendFTDICommand", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic) != null);
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000089 RID: 137 RVA: 0x0001AB34 File Offset: 0x0001AB34
		private void ShowDiagnosticResults(string ecuId, string partCode, float? temperature, float? o2Voltage, int dtcCount)
		{
			CustomMessageBox__2.Show(string.Concat(new string[]
			{
				"\ud83d\udcca HASIL TES DIAGNOSTIK \ud83d\udcca\n\n",
				string.Format("Waktu: {0:HH:mm:ss}\n", DateTime.Now),
				new string('─', 40),
				"\n\n\ud83d\udccb INFORMASI ECU:\n   • ID ECU: ",
				ecuId,
				"\n   • Kode Part: ",
				partCode,
				"\n\n\ud83c\udf21️  SENSOR:\n   • Suhu: ",
				(temperature != null) ? string.Format("{0:F1}°C", temperature.Value) : "ERROR",
				"\n   • Sensor O2: ",
				(o2Voltage != null) ? string.Format("{0:F2}V", o2Voltage.Value) : "ERROR",
				"\n\n⚙️  SISTEM:\n   • Injektor: OK ✓\n   • Pengapian: OK ✓\n   • Memori: OK ✓\n   • Keamanan: OK ✓\n\n\ud83d\udea8 DIAGNOSTIC TROUBLE CODES:\n",
				string.Format("   • Jumlah DTC: {0}\n", dtcCount),
				"   • Status: ",
				(dtcCount == 0) ? "TIDAK ADA DTC ✓" : "ADA DTC ⚠️",
				"\n\n",
				new string('═', 40),
				"\nKESIMPULAN: SISTEM ECU ",
				(dtcCount == 0) ? "BERFUNGSI NORMAL" : "MEMBUTUHKAN PERBAIKAN"
			}), "LAPORAN DIAGNOSTIK", MessageBoxButtons.OK, (dtcCount == 0) ? MessageBoxIcon.Asterisk : MessageBoxIcon.Exclamation);
		}

		// Token: 0x0600008B RID: 139 RVA: 0x0001AD0C File Offset: 0x0001AD0C
		private void ResetUI()
		{
			this.RtbLog.AppendText("\n" + new string('=', 60) + "\n");
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83c\udfcd️ DIAGNOSTIC TESTS MOTOR HONDA DIMULAI \ud83c\udfcd️\n", DateTime.Now));
			this.RtbLog.AppendText(new string('=', 60) + "\n");
			this.TxtPb.Text = "Status: Inisialisasi...";
			this.PbProgress.Value = 0;
			this.TxtEcmId.Text = "";
			this.TxtPartCode.Text = "";
		}

		// Token: 0x0600008C RID: 140 RVA: 0x0001ADB8 File Offset: 0x0001ADB8
		private void LogToUI(string message)
		{
			if (base.InvokeRequired)
			{
				base.Invoke(new Action(delegate()
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] {1}\n", DateTime.Now, message));
				}));
				return;
			}
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] {1}\n", DateTime.Now, message));
		}

		// Token: 0x0600008D RID: 141 RVA: 0x0001AE1C File Offset: 0x0001AE1C
		private void UpdateProgressUI(int value, string status = "")
		{
			if (base.InvokeRequired)
			{
				base.Invoke(new Action(delegate()
				{
					if (!string.IsNullOrEmpty(status))
					{
						this.TxtPb.Text = "Status: " + status;
					}
				}));
				return;
			}
			if (!string.IsNullOrEmpty(status))
			{
				this.TxtPb.Text = "Status: " + status;
			}
		}

		// Token: 0x0600008E RID: 142 RVA: 0x0000296C File Offset: 0x0000296C
		private void UpdateEcuIdUI(string ecuId)
		{
			if (base.InvokeRequired)
			{
				base.Invoke(new Action(delegate()
				{
					this.TxtEcmId.Text = "";
					this.TxtEcmId.ForeColor = Color.Lime;
				}));
				return;
			}
			this.TxtEcmId.Text = "";
			this.TxtEcmId.ForeColor = Color.Lime;
		}

		// Token: 0x0600008F RID: 143 RVA: 0x000029AA File Offset: 0x000029AA
		private void UpdatePartCodeUI(string partCode)
		{
			if (base.InvokeRequired)
			{
				base.Invoke(new Action(delegate()
				{
					this.TxtPartCode.Text = "";
					this.TxtPartCode.ForeColor = Color.Lime;
				}));
				return;
			}
			this.TxtPartCode.Text = "";
			this.TxtPartCode.ForeColor = Color.Lime;
		}

		// Token: 0x06000090 RID: 144 RVA: 0x0001AE84 File Offset: 0x0001AE84
		private bool InitializeMotorConnection()
		{
			bool result;
			try
			{
				this.LogToUI("Mencoba koneksi ke ECU Motor Honda...");
				Thread.Sleep(500);
				if (new Random().Next(100) < 90)
				{
					this.LogToUI("✅ ECU Motor Honda terhubung");
					result = true;
				}
				else
				{
					this.LogToUI("❌ Gagal menghubungkan ke ECU Motor");
					result = false;
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000091 RID: 145 RVA: 0x0001AEEC File Offset: 0x0001AEEC
		private void CloseMotorConnection()
		{
			try
			{
				this.LogToUI("Menutup koneksi ECU Motor...");
				Thread.Sleep(100);
				this.LogToUI("Koneksi ECU Motor ditutup");
			}
			catch (Exception ex)
			{
				this.LogToUI("❌ Error menutup koneksi: " + ex.Message);
			}
		}

		// Token: 0x06000092 RID: 146 RVA: 0x0001AF44 File Offset: 0x0001AF44
		private string ReadMotorEcuId()
		{
			string result;
			try
			{
				string[] array = new string[]
				{
					"0104290F01",
					"0104110F01",
					"0104530F01",
					"0104AF0F01",
					"0104080F01",
					"0104F00F01",
					"0102A40101",
					"0100F91103",
					"0101340F01",
					"0101A10F01",
					"01018B0F01",
					"01006A0101",
					"01006A0301",
					"0102F60102",
					"0101390102",
					"01011B0F02",
					"0101DA0F01",
					"0103130F11",
					"0103130F01",
					"0102E70F01",
					"0102A22101",
					"0101080801",
					"0102B70401",
					"01004C0701",
					"01004C0601",
					"0101F20101",
					"0101F20F01",
					"0101F20801",
					"0101250101",
					"0101250501",
					"0101250B02",
					"0101250B01",
					"0101DE0101",
					"0101DE0F01",
					"0102780F01",
					"0102780D01",
					"0100390101",
					"01019C0101",
					"01027D0D01",
					"01014E1201",
					"01019C1201",
					"0103050101",
					"0103BF0E01",
					"0100300101",
					"01000F0202",
					"01000F0302",
					"01000F0102",
					"01001A0101",
					"01002B0401",
					"01002B0402",
					"01002B0301",
					"01002B0502",
					"01002B0101",
					"01005E0103",
					"01005E0601",
					"01005E0301",
					"01005E0503",
					"01005E0401",
					"0100B00301",
					"0100B00401",
					"0100B00501",
					"0100B00801",
					"0100B00102",
					"0100B00601",
					"0100B70601",
					"0100B70501",
					"0100B70301",
					"0100B70101",
					"0100B70401",
					"0100F30501",
					"0100F30301",
					"0100F30401",
					"0100F30601",
					"0100F30101",
					"0101830D01",
					"0101830401",
					"0101830302",
					"0101830101",
					"0102480401",
					"0102490E01",
					"0102490501",
					"0102490101",
					"0103380D01",
					"0103380101",
					"01005EFD74",
					"0102850111",
					"0102850101",
					"01028501FF",
					"0100C60102",
					"0102A10101",
					"0100FA1001",
					"0101110F01",
					"0101B10F01",
					"0102040F01",
					"0102A00D01",
					"0103250F01",
					"0103250F11",
					"0100C50D02",
					"0100B80502",
					"0100B80F01",
					"0101790F02",
					"0101790101",
					"0101320671",
					"0101E40601",
					"0101E40F03",
					"0101E40F11",
					"0103DC0F01",
					"0101740101",
					"0102B70D02",
					"0101250701",
					"0101DD0F01",
					"0101DD0D01",
					"0102F20511",
					"0102F20111",
					"0100E00101",
					"0100020302",
					"0100020202",
					"0100020203",
					"01001B0301",
					"01001B0101",
					"01001B0401",
					"0100330103",
					"0100330302",
					"01007C0102",
					"0101420101",
					"0101420401",
					"0100330171",
					"0101420171",
					"01014E0401",
					"01014E0D03",
					"01019C0D02",
					"0102101011",
					"01027D0701",
					"01027D0101",
					"01027D0E02",
					"01031A0101",
					"01031A1801",
					"01031A0D01",
					"0103BE0E01",
					"01031A1201",
					"01031A0501",
					"01025C0F01",
					"0102560101",
					"0102DE0501",
					"0102DD0501",
					"0102320F01",
					"0103160801",
					"01011A0D01",
					"01011A0503",
					"0102360D01",
					"0102360101",
					"01015B0D01",
					"0102890101",
					"0102360F01",
					"0104070D01",
					"0104070501",
					"0102E80501",
					"0103B60503",
					"0102E90501",
					"0103261801",
					"01009C0101",
					"01029E1801",
					"0102B50D01",
					"01008F0101",
					"0100ED0101",
					"0100FB0E02",
					"01010C1101",
					"01015F1101",
					"0103141101",
					"0103110F01",
					"0101350501",
					"0101350101",
					"0102130501",
					"0102570501",
					"0101CA0F01",
					"0103920F01",
					"0801DF0101",
					"01006D1101",
					"0100B41101",
					"0101700F01",
					"0102CA0501",
					"0101820101",
					"0101220801",
					"01025A0D01",
					"0101870F02",
					"0102E40F01",
					"0102D71F01",
					"0101CD1801",
					"0103931801",
					"0D02FC0401",
					"0104130F01",
					"01027F0F01",
					"0102810D01",
					"01006B0801",
					"0100450103",
					"0100530101",
					"0102B10101",
					"0101B80103",
					"0101C90F01",
					"0101021101",
					"01011E0F01",
					"01030E0501",
					"0101BA0D01",
					"0100E80F02",
					"0801EB0502",
					"0101FA0F01",
					"0101F80F01",
					"0102F80F01",
					"0101200F01",
					"0101F30F01",
					"0100AA0301",
					"0101030101",
					"0101030301",
					"0101190101",
					"0800AB0301",
					"0800AB0101",
					"0100FC0101",
					"0801040101",
					"0801040301",
					"08017D0101",
					"08017D0301",
					"01007B0101",
					"0100CE0D02",
					"0101880D01",
					"0102681101",
					"01034C0D01",
					"0102B90D01",
					"0102AD1801",
					"0101CB1101",
					"0103591101",
					"08024C0101",
					"08024CFFFF",
					"0802E60E01",
					"0802E60E02",
					"0802E60102",
					"08024CFFFE",
					"0101310802",
					"0103100F01",
					"0104A40F01",
					"0103110F01",
					"0104A50F01",
					"0104130F01",
					"0104F10F01",
					"0105A70F01",
					"0105A80F01",
					"01005F0F01",
					"01002D0F01",
					"01046B0F01",
					"01037B0F01",
					"01037C0D01",
					"01012F1101",
					"01012F1102",
					"01012F1103",
					"01037A0F02",
					"01037A0F03",
					"0103790F02",
					"0103790F03",
					"0104040F01",
					"0104030F01",
					"0101D40F01",
					"0101D30F01",
					"0101411101",
					"0101411102",
					"0101AB1101",
					"0101AB1102",
					"0101AB1103",
					"0101461101",
					"0101461102",
					"0101461103",
					"0102170A01",
					"0102180F01",
					"0101C40F01",
					"0102450F01",
					"0103060F01",
					"0103151801",
					"0101E20F01",
					"0101C50F01",
					"0102470F01",
					"0102460F01",
					"0103080F01",
					"0103090F01",
					"01030B0F03",
					"0102420F01",
					"0102410F01",
					"0102E30F01",
					"0102E20F01",
					"0103001101",
					"0102970701",
					"0102C70F01",
					"0103470F01",
					"0101230F01",
					"0101730F01",
					"0101690F01",
					"0101BE0F01",
					"0101AE0F01",
					"0104D90F01",
					"0104D80F01",
					"0105030F01",
					"0105020F01",
					"0104DA1F01",
					"01048D0F01",
					"01048C0F01",
					"0103CF0D01",
					"0103090F03",
					"0103060F03",
					"01058B0F11",
					"01058C0F01",
					"01058F0F01",
					"01058D0F01",
					"01058B0F01",
					"01037A0F01",
					"0103790F01",
					"0105770F01",
					"0105B60F01",
					"0105B80F01",
					"0105B70F01"
				};
				Random random = new Random();
				if (random.Next(100) < 80)
				{
					result = array[random.Next(array.Length)];
				}
				else
				{
					result = "UNKNOWN";
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000093 RID: 147 RVA: 0x0001BCF0 File Offset: 0x0001BCF0
		private string ReadMotorPartCode(string ecuId)
		{
			string result;
			try
			{
				if (!string.IsNullOrEmpty(ecuId) && ecuId != "UNKNOWN")
				{
					result = ecuId;
				}
				else
				{
					result = "UNKNOWN";
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000094 RID: 148 RVA: 0x0001BD34 File Offset: 0x0001BD34
		private int? ReadMotorRpm(string ecuId)
		{
			checked
			{
				int? result;
				try
				{
					Random random = new Random();
					if (ecuId.Contains("K26"))
					{
						if (random.Next(100) < 70)
						{
							result = new int?(1500 + random.Next(1000));
						}
						else
						{
							result = new int?(0);
						}
					}
					else if (random.Next(100) < 80)
					{
						result = new int?(1200 + random.Next(800));
					}
					else
					{
						result = new int?(0);
					}
				}
				catch
				{
					result = null;
				}
				return result;
			}
		}

		// Token: 0x06000095 RID: 149 RVA: 0x0001BDD0 File Offset: 0x0001BDD0
		private float? ReadMotorTemperature(string ecuId)
		{
			float? result;
			try
			{
				Random random = new Random();
				float value = 85f;
				if (ecuId.Contains("K26-9"))
				{
					value = 80f + (float)random.Next(15);
				}
				else if (ecuId.Contains("K29-3"))
				{
					value = 85f + (float)random.Next(20);
				}
				result = new float?(value);
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000096 RID: 150 RVA: 0x0001BE4C File Offset: 0x0001BE4C
		private float? ReadMotorTPS(string ecuId)
		{
			checked
			{
				float? result;
				try
				{
					Random random = new Random();
					int num = random.Next(100);
					float value;
					if (num < 60)
					{
						value = (float)random.Next(0, 6);
					}
					else if (num < 85)
					{
						value = (float)(5 + random.Next(26));
					}
					else if (num < 95)
					{
						value = (float)(30 + random.Next(41));
					}
					else
					{
						value = (float)(70 + random.Next(31));
					}
					result = new float?(value);
				}
				catch
				{
					result = null;
				}
				return result;
			}
		}

		// Token: 0x06000097 RID: 151 RVA: 0x0001BED8 File Offset: 0x0001BED8
		private float? ReadMotorMAP(string ecuId)
		{
			float? result;
			try
			{
				Random random = new Random();
				float value;
				if (random.Next(100) < 80)
				{
					value = 98f + (float)(random.NextDouble() * 4.0 - 2.0);
				}
				else
				{
					value = (float)(checked(90 + random.Next(20)));
				}
				result = new float?(value);
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000098 RID: 152 RVA: 0x0001BF50 File Offset: 0x0001BF50
		private float? ReadMotorVoltage(string ecuId)
		{
			float? result;
			try
			{
				Random random = new Random();
				float value;
				if (random.Next(100) < 85)
				{
					value = 13.2f + (float)(random.NextDouble() * 1.2 - 0.6);
				}
				else if (random.Next(100) < 70)
				{
					value = 11.5f + (float)(random.NextDouble() * 1.0);
				}
				else
				{
					value = 14.5f + (float)(random.NextDouble() * 1.0);
				}
				result = new float?(value);
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000099 RID: 153 RVA: 0x0001BFF8 File Offset: 0x0001BFF8
		private List<string> ReadMotorDtcCodes(string ecuId)
		{
			List<string> list = new List<string>();
			checked
			{
				try
				{
					Random random = new Random();
					int num = 20;
					if (random.Next(100) < num)
					{
						string[] array = new string[]
						{
							"P0101",
							"P0102",
							"P0103",
							"P0112",
							"P0113",
							"P0122",
							"P0123",
							"P0134",
							"P0300",
							"P0301"
						};
						int num2 = random.Next(1, 3);
						for (int i = 0; i < num2; i++)
						{
							list.Add(array[random.Next(array.Length)]);
						}
					}
				}
				catch
				{
				}
				return list;
			}
		}

		// Token: 0x0600009A RID: 154 RVA: 0x00002908 File Offset: 0x00002908
		private bool TestMotorInjector(string ecuId)
		{
			return new Random().Next(100) < 90;
		}

		// Token: 0x0600009B RID: 155 RVA: 0x000028D2 File Offset: 0x000028D2
		private bool TestMotorIgnition(string ecuId)
		{
			return new Random().Next(100) < 95;
		}

		// Token: 0x0600009C RID: 156 RVA: 0x000029E8 File Offset: 0x000029E8
		private bool TestMotorFuelPump(string ecuId)
		{
			return new Random().Next(100) < 92;
		}

		// Token: 0x0600009D RID: 157 RVA: 0x000029FA File Offset: 0x000029FA
		private bool TestMotorImmobilizer(string ecuId)
		{
			return new Random().Next(100) < 85;
		}

		// Token: 0x0600009E RID: 158 RVA: 0x00002908 File Offset: 0x00002908
		private bool TestMotorSideStand(string ecuId)
		{
			return new Random().Next(100) < 90;
		}

		// Token: 0x0600009F RID: 159 RVA: 0x0001C0C0 File Offset: 0x0001C0C0
		private void ShowMotorDiagnosticSummary(string ecuId, string partCode, int? rpm, float? temperature, float? tpsValue, float? mapValue, float? voltage, int dtcCount)
		{
			string str = "Unknown Model";
			string str2 = "Unknown CC";
			if (ecuId.Contains("K26-900") || ecuId.Contains("K26-901") || ecuId.Contains("K26-902"))
			{
				str = "Honda Beat";
				str2 = "110cc";
			}
			else if (ecuId.Contains("K26-910") || ecuId.Contains("K26-911") || ecuId.Contains("K26-912"))
			{
				str = "Honda Vario";
				str2 = "110cc/125cc/150cc";
			}
			else if (ecuId.Contains("K26-920") || ecuId.Contains("K26-921") || ecuId.Contains("K26-922"))
			{
				str = "Honda Scoopy";
				str2 = "110cc";
			}
			else if (ecuId.Contains("K26-930") || ecuId.Contains("K26-931") || ecuId.Contains("K26-932"))
			{
				str = "Honda PCX";
				str2 = "150cc";
			}
			else if (ecuId.Contains("K26-940") || ecuId.Contains("K26-941") || ecuId.Contains("K26-942"))
			{
				str = "Honda ADV";
				str2 = "150cc";
			}
			else if (ecuId.Contains("K29-300") || ecuId.Contains("K29-301") || ecuId.Contains("K29-302"))
			{
				str = "Honda CB150R";
				str2 = "150cc";
			}
			else if (ecuId.Contains("K29-310") || ecuId.Contains("K29-311") || ecuId.Contains("K29-312"))
			{
				str = "Honda CBR150R";
				str2 = "150cc";
			}
			string text = "\ud83c\udfcd️ HASIL TES DIAGNOSTIK MOTOR HONDA \ud83c\udfcd️\n\n";
			text += string.Format("Waktu: {0:HH:mm:ss}\n", DateTime.Now);
			text = text + new string('─', 50) + "\n\n";
			text += "\ud83d\udccb INFORMASI ECU MOTOR:\n";
			text = text + "   • Model: " + str + "\n";
			text = text + "   • Kapasitas: " + str2 + "\n";
			text = text + "   • ID ECU: " + ecuId + "\n";
			text = text + "   • Kode Part: " + partCode + "\n\n";
			text += "\ud83d\udcca DATA SENSOR:\n";
			text = text + "   • RPM Engine: " + ((rpm != null) ? string.Format("{0} RPM", rpm.Value) : "ERROR") + "\n";
			text = text + "   • Suhu Engine: " + ((temperature != null) ? string.Format("{0:F1}°C", temperature.Value) : "ERROR") + "\n";
			text = text + "   • TPS: " + ((tpsValue != null) ? string.Format("{0:F1}%", tpsValue.Value) : "ERROR") + "\n";
			text = text + "   • MAP Sensor: " + ((mapValue != null) ? string.Format("{0:F1} kPa", mapValue.Value) : "ERROR") + "\n";
			text = text + "   • Battery Voltage: " + ((voltage != null) ? string.Format("{0:F1}V", voltage.Value) : "ERROR") + "\n\n";
			text += "⚙️  HASIL TES SISTEM:\n";
			text += "   • Injektor: OK ✓\n";
			text += "   • Pengapian: OK ✓\n";
			text += "   • Fuel Pump: OK ✓\n";
			text += "   • Immobilizer: OK ✓\n";
			text += "   • Side Stand Sensor: OK ✓\n\n";
			text += "\ud83d\udea8 DIAGNOSTIC TROUBLE CODES:\n";
			text += string.Format("   • Jumlah DTC: {0}\n", dtcCount);
			text = text + "   • Status: " + ((dtcCount == 0) ? "TIDAK ADA DTC ✓" : "ADA DTC ⚠️") + "\n\n";
			text = text + new string('═', 50) + "\n";
			if (dtcCount == 0)
			{
				text += "✅ KESIMPULAN: SISTEM ECU MOTOR BERFUNGSI NORMAL\n";
				text += "   Motor siap digunakan";
				CustomMessageBox__2.Show(text, "LAPORAN DIAGNOSTIK MOTOR - NORMAL", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
			text += "⚠️  KESIMPULAN: SISTEM ECU MOTOR MEMBUTUHKAN PERBAIKAN\n";
			text += string.Format("   Ditemukan {0} kode kesalahan", dtcCount);
			CustomMessageBox__2.Show(text, "LAPORAN DIAGNOSTIK MOTOR - PERHATIAN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}

		// Token: 0x060000A6 RID: 166 RVA: 0x00002B1A File Offset: 0x00002B1A
		private bool IsValidMotorEcuId(string ecuId)
		{
			return !string.IsNullOrEmpty(ecuId) && (ecuId.StartsWith("38770-") && ecuId.Length >= 12) && ecuId.Contains("-");
		}

		// Token: 0x060000A7 RID: 167 RVA: 0x00002B4A File Offset: 0x00002B4A
		private string GeneratePartCodeFromEcuId(string ecuId)
		{
			if (string.IsNullOrEmpty(ecuId))
			{
				return "N/A";
			}
			return ecuId;
		}

		// Token: 0x060000A8 RID: 168 RVA: 0x0001C508 File Offset: 0x0001C508
		private bool VerifyEcuDataConsistency(string ecuId, string partCode)
		{
			string value = ecuId.Split(new char[]
			{
				'-'
			})[0];
			return partCode.Contains(value);
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x0001C530 File Offset: 0x0001C530
		private string DetectMotorModelFromEcuId(string ecuId)
		{
			if (ecuId.Contains("K26-900"))
			{
				return "Honda Beat";
			}
			if (ecuId.Contains("K26-901"))
			{
				return "Honda Beat Street";
			}
			if (ecuId.Contains("K26-910"))
			{
				return "Honda Vario 110";
			}
			if (ecuId.Contains("K26-911"))
			{
				return "Honda Vario 125";
			}
			if (ecuId.Contains("K26-912"))
			{
				return "Honda Vario 150";
			}
			if (ecuId.Contains("K26-920"))
			{
				return "Honda Scoopy";
			}
			if (ecuId.Contains("K26-930"))
			{
				return "Honda PCX";
			}
			if (ecuId.Contains("K26-940"))
			{
				return "Honda ADV";
			}
			if (ecuId.Contains("K29-300"))
			{
				return "Honda CB150R";
			}
			if (ecuId.Contains("K29-310"))
			{
				return "Honda CBR150R";
			}
			if (ecuId.Contains("K29-330"))
			{
				return "Honda Verza";
			}
			if (ecuId.Contains("K29-340"))
			{
				return "Honda Sonic";
			}
			return "Honda Motor";
		}

		// Token: 0x060000AA RID: 170 RVA: 0x0001C628 File Offset: 0x0001C628
		private string DetectMotorCCFromEcuId(string ecuId)
		{
			if (ecuId.Contains("K26-900") || ecuId.Contains("K26-901") || ecuId.Contains("K26-910") || ecuId.Contains("K26-920"))
			{
				return "110cc";
			}
			if (ecuId.Contains("K26-911"))
			{
				return "125cc";
			}
			if (ecuId.Contains("K26-912") || ecuId.Contains("K26-930") || ecuId.Contains("K26-940") || ecuId.Contains("K29-300") || ecuId.Contains("K29-310") || ecuId.Contains("K29-330") || ecuId.Contains("K29-340"))
			{
				return "150cc";
			}
			return "Unknown CC";
		}

		// Token: 0x060000AB RID: 171 RVA: 0x0001C6E8 File Offset: 0x0001C6E8
		private int GetRealisticRpmForModel(string model, Random rand)
		{
			checked
			{
				if (model.Contains("Beat") || model.Contains("Vario 110") || model.Contains("Scoopy"))
				{
					if (rand.Next(100) >= 80)
					{
						return 0;
					}
					return 1500 + rand.Next(1000);
				}
				else if (model.Contains("PCX") || model.Contains("ADV") || model.Contains("CB") || model.Contains("CBR"))
				{
					if (rand.Next(100) >= 85)
					{
						return 0;
					}
					return 1300 + rand.Next(800);
				}
				else
				{
					if (rand.Next(100) >= 75)
					{
						return 0;
					}
					return 1400 + rand.Next(900);
				}
			}
		}

		// Token: 0x060000AC RID: 172 RVA: 0x00002B5B File Offset: 0x00002B5B
		private float GetRealisticTemperatureForModel(string model, Random rand)
		{
			checked
			{
				if (model.Contains("150"))
				{
					return (float)(85 + rand.Next(20));
				}
				return (float)(80 + rand.Next(15));
			}
		}

		// Token: 0x060000AD RID: 173 RVA: 0x00002B83 File Offset: 0x00002B83
		private float GetRealisticVoltageForModel(string model, Random rand)
		{
			return 13.2f + (float)(rand.NextDouble() * 1.2 - 0.6);
		}

		// Token: 0x060000AE RID: 174 RVA: 0x0001C7B0 File Offset: 0x0001C7B0
		private List<string> ReadDtcForModel(string model, Random rand)
		{
			List<string> list = new List<string>();
			int num = (model.Contains("Beat") || model.Contains("Vario 110")) ? 30 : 20;
			checked
			{
				if (rand.Next(100) < num)
				{
					string[] array = new string[]
					{
						"P0101",
						"P0102",
						"P0103",
						"P0112",
						"P0113",
						"P0122",
						"P0123",
						"P0134",
						"P0300",
						"P0301"
					};
					int num2 = rand.Next(1, 3);
					for (int i = 0; i < num2; i++)
					{
						list.Add(array[rand.Next(array.Length)]);
					}
				}
				return list;
			}
		}

		// Token: 0x060000AF RID: 175 RVA: 0x0001C878 File Offset: 0x0001C878
		private bool TestInjectorSystem(string model, Random rand)
		{
			int num = (model.Contains("CBR") || model.Contains("PCX")) ? 95 : 90;
			return rand.Next(100) < num;
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x0001C8B4 File Offset: 0x0001C8B4
		private bool TestIgnitionSystem(string model, Random rand)
		{
			int num = 95;
			return rand.Next(100) < num;
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x0001C8D0 File Offset: 0x0001C8D0
		private bool TestFuelPumpSystem(string model, Random rand)
		{
			int num = model.Contains("ADV") ? 88 : 92;
			return rand.Next(100) < num;
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x0001C8FC File Offset: 0x0001C8FC
		private void ShowDiagnosticSummary(string ecuId, string partCode, string model, string cc, int rpm, float temp, float voltage, int dtcCount, bool injectorOk, bool ignitionOk, bool fuelPumpOk)
		{
			string text = "\ud83c\udfcd️ LAPORAN DIAGNOSTIK MOTOR HONDA \ud83c\udfcd️\n\n";
			text += "\ud83d\udccb DATA DARI PANEL3:\n";
			text = text + "   • ECU ID: " + ecuId + "\n";
			text = text + "   • Part Code: " + partCode + "\n";
			text = string.Concat(new string[]
			{
				text,
				"   • Model: ",
				model,
				" ",
				cc,
				"\n\n"
			});
			text += "\ud83d\udcca HASIL PEMERIKSAAN:\n";
			text += string.Format("   • RPM Engine: {0}\n", rpm);
			text += string.Format("   • Suhu Engine: {0}°C\n", temp);
			text += string.Format("   • Battery Voltage: {0:F1}V\n\n", voltage);
			text += "⚙️  STATUS SISTEM:\n";
			text = text + "   • Injektor: " + (injectorOk ? "OK ✓" : "GAGAL ✗") + "\n";
			text = text + "   • Pengapian: " + (ignitionOk ? "OK ✓" : "GAGAL ✗") + "\n";
			text = text + "   • Fuel Pump: " + (fuelPumpOk ? "OK ✓" : "GAGAL ✗") + "\n";
			text += string.Format("   • DTC Found: {0} kode\n\n", dtcCount);
			text += "\ud83c\udfaf KESIMPULAN:\n";
			if (dtcCount == 0 && injectorOk && ignitionOk && fuelPumpOk)
			{
				text += "   ✅ SISTEM BERFUNGSI NORMAL\n";
				text += "   Data sesuai dengan Panel3 ✓";
				CustomMessageBox__2.Show(text, "DIAGNOSTIK - NORMAL", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
			text += "   ⚠️  PERLU PERBAIKAN\n";
			text += string.Format("   {0} kode DTC ditemukan", dtcCount);
			CustomMessageBox__2.Show(text, "DIAGNOSTIK - PERHATIAN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x0001CAC4 File Offset: 0x0001CAC4
		private string ExtractEcuCodeFromPartCode(string partCodeText)
		{
			if (string.IsNullOrEmpty(partCodeText))
			{
				return "";
			}
			Match match = new Regex("\\b38770-[A-Z0-9]{2,3}-[A-Z0-9]{2,3}\\b").Match(partCodeText);
			if (match.Success)
			{
				return match.Value;
			}
			return "";
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x0001CB04 File Offset: 0x0001CB04
		private string ExtractPartCodeFromText(string text)
		{
			if (string.IsNullOrEmpty(text))
			{
				return "";
			}
			string text2 = this.ExtractEcuCodeFromPartCode(text);
			if (!string.IsNullOrEmpty(text2))
			{
				return text2;
			}
			return text;
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x0001CB34 File Offset: 0x0001CB34
		private string DetectMotorModelFromData(string ecuId, string partCode)
		{
			if (!string.IsNullOrEmpty(partCode))
			{
				if (partCode.Contains("BEAT"))
				{
					return "Honda Beat";
				}
				if (partCode.Contains("VARIO"))
				{
					return "Honda Vario";
				}
				if (partCode.Contains("SCOOPY"))
				{
					return "Honda Scoopy";
				}
				if (partCode.Contains("PCX"))
				{
					return "Honda PCX";
				}
				if (partCode.Contains("ADV"))
				{
					return "Honda ADV";
				}
				if (partCode.Contains("CB") && partCode.Contains("150"))
				{
					return "Honda CB150R";
				}
				if (partCode.Contains("CBR") && partCode.Contains("150"))
				{
					return "Honda CBR150R";
				}
				if (partCode.Contains("VERZA"))
				{
					return "Honda Verza";
				}
				if (partCode.Contains("SONIC"))
				{
					return "Honda Sonic";
				}
			}
			if (!string.IsNullOrEmpty(ecuId) && ecuId.Contains("38770-"))
			{
				if (ecuId.Contains("K26-900") || ecuId.Contains("K26-901"))
				{
					return "Honda Beat";
				}
				if (ecuId.Contains("K26-910") || ecuId.Contains("K26-911") || ecuId.Contains("K26-912"))
				{
					return "Honda Vario";
				}
				if (ecuId.Contains("K26-920"))
				{
					return "Honda Scoopy";
				}
				if (ecuId.Contains("K26-930"))
				{
					return "Honda PCX";
				}
				if (ecuId.Contains("K26-940"))
				{
					return "Honda ADV";
				}
				if (ecuId.Contains("K29-300"))
				{
					return "Honda CB150R";
				}
				if (ecuId.Contains("K29-310"))
				{
					return "Honda CBR150R";
				}
				if (ecuId.Contains("K29-330"))
				{
					return "Honda Verza";
				}
				if (ecuId.Contains("K29-340"))
				{
					return "Honda Sonic";
				}
				if (ecuId.Contains("K46-"))
				{
					return "Honda Beat";
				}
			}
			return "Honda Motor";
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x0001CD18 File Offset: 0x0001CD18
		private string DetectMotorCCFromData(string partCode)
		{
			if (string.IsNullOrEmpty(partCode))
			{
				return "Unknown CC";
			}
			if (partCode.Contains("110"))
			{
				return "110cc";
			}
			if (partCode.Contains("125"))
			{
				return "125cc";
			}
			if (partCode.Contains("150"))
			{
				return "150cc";
			}
			if (partCode.Contains("160"))
			{
				return "160cc";
			}
			return "110cc";
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x0001CD84 File Offset: 0x0001CD84
		private void SaveECUDataBeforeReset()
		{
			try
			{
				string text = Path.Combine(Application.StartupPath, "Backup", "FactoryReset");
				Directory.CreateDirectory(text);
				string text2 = Path.Combine(text, string.Format("ECU_Backup_{0:yyyyMMdd_HHmmss}.txt", DateTime.Now));
				using (StreamWriter streamWriter = new StreamWriter(text2))
				{
					streamWriter.WriteLine(string.Format("=== ECU DATA BACKUP - {0:yyyy-MM-dd HH:mm:ss} ===", DateTime.Now));
					TextWriter textWriter = streamWriter;
					string str = "ECU ID: ";
					Label txtEcmId = this.TxtEcmId;
					textWriter.WriteLine(str + (((txtEcmId != null) ? txtEcmId.Text : null) ?? "N/A"));
					TextWriter textWriter2 = streamWriter;
					string str2 = "Part Code: ";
					Label txtPartCode = this.TxtPartCode;
					textWriter2.WriteLine(str2 + (((txtPartCode != null) ? txtPartCode.Text : null) ?? "N/A"));
					TextWriter textWriter3 = streamWriter;
					string str3 = "Flash Count: ";
					Label txtFlashCount = this.TxtFlashCount;
					textWriter3.WriteLine(str3 + (((txtFlashCount != null) ? txtFlashCount.Text : null) ?? "0"));
					TextWriter textWriter4 = streamWriter;
					string str4 = "Start Offset: ";
					TextBox tbStartOffset = this.TbStartOffset;
					textWriter4.WriteLine(str4 + (((tbStartOffset != null) ? tbStartOffset.Text : null) ?? "0"));
					TextWriter textWriter5 = streamWriter;
					string str5 = "Checksum Offset: ";
					TextBox tbChecksumOffset = this.TbChecksumOffset;
					textWriter5.WriteLine(str5 + (((tbChecksumOffset != null) ? tbChecksumOffset.Text : null) ?? "0"));
					streamWriter.WriteLine("=== END BACKUP ===");
				}
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udcbe Data ECU berhasil dibackup ke: {1}\n", DateTime.Now, text2));
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Gagal backup data: {1}\n", DateTime.Now, ex.Message));
			}
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x0001CF54 File Offset: 0x0001CF54
		private bool IsValidECUID(string ecuId)
		{
			if (string.IsNullOrEmpty(ecuId) || ecuId == "N/A")
			{
				return false;
			}
			if (ecuId.Length < 10)
			{
				return false;
			}
			if (!ecuId.Contains("-"))
			{
				return false;
			}
			bool flag = false;
			bool flag2 = false;
			foreach (char c in ecuId)
			{
				if (char.IsDigit(c))
				{
					flag = true;
				}
				if (char.IsLetter(c))
				{
					flag2 = true;
				}
			}
			return flag && flag2;
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x00002BA6 File Offset: 0x00002BA6
		private bool IsValidPartCode(string partCode)
		{
			return !string.IsNullOrEmpty(partCode) && !(partCode == "N/A") && partCode.Length >= 8;
		}

		// Token: 0x060000BA RID: 186 RVA: 0x0001CFC8 File Offset: 0x0001CFC8
		private void SaveECUInfoToLogFile(string ecuId, string partCode)
		{
			try
			{
				string text = Path.Combine(Application.StartupPath, "Logs", "FactoryReset");
				Directory.CreateDirectory(text);
				using (StreamWriter streamWriter = new StreamWriter(Path.Combine(text, string.Format("FactoryReset_{0:yyyyMMdd}.log", DateTime.Now)), true))
				{
					streamWriter.WriteLine(string.Format("[{0:yyyy-MM-dd HH:mm:ss}] FACTORY RESET INITIATED", DateTime.Now));
					streamWriter.WriteLine("  ECU ID: " + ecuId);
					streamWriter.WriteLine("  Part Code: " + partCode);
					streamWriter.WriteLine("  User: " + Environment.UserName);
					streamWriter.WriteLine("  Machine: " + Environment.MachineName);
					streamWriter.WriteLine("---");
				}
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Gagal menulis log: {1}\n", DateTime.Now, ex.Message));
			}
		}

		// Token: 0x060000BB RID: 187 RVA: 0x0001D0D4 File Offset: 0x0001D0D4
		private void ExecuteFactoryResetProcess(string ecuId, string partCode)
		{
			checked
			{
				try
				{
					for (int i = 1; i <= 20; i++)
					{
						this.PbProgress.Value = i;
						this.TxtPb.Text = string.Format("Status: Persiapan reset ({0}%)", i);
						Application.DoEvents();
						Thread.Sleep(20);
					}
					for (int j = 21; j <= 40; j++)
					{
						this.PbProgress.Value = j;
						this.TxtPb.Text = string.Format("Status: Reset konfigurasi ECU ({0}%)", j);
						Application.DoEvents();
						Thread.Sleep(30);
					}
					for (int k = 41; k <= 60; k++)
					{
						this.PbProgress.Value = k;
						this.TxtPb.Text = string.Format("Status: Menghapus data tuning ({0}%)", k);
						Application.DoEvents();
						Thread.Sleep(25);
					}
					for (int l = 61; l <= 80; l++)
					{
						this.PbProgress.Value = l;
						this.TxtPb.Text = string.Format("Status: Reset flash counter ({0}%)", l);
						Application.DoEvents();
						Thread.Sleep(20);
					}
					for (int m = 81; m <= 100; m++)
					{
						this.PbProgress.Value = m;
						this.TxtPb.Text = string.Format("Status: Finalisasi reset ({0}%)", m);
						Application.DoEvents();
						Thread.Sleep(15);
					}
					Thread.Sleep(500);
				}
				catch (Exception ex)
				{
					throw new Exception("Error dalam proses reset: " + ex.Message, ex);
				}
			}
		}

		// Token: 0x060000BC RID: 188 RVA: 0x0001D270 File Offset: 0x0001D270
		private void ResetApplicationData()
		{
			this.TxtFlashCount.Text = "0";
			if (this.TxtEcmId.Text == "N/A" || string.IsNullOrEmpty(this.TxtEcmId.Text))
			{
				this.TxtEcmId.Text = "N/A";
			}
			if (this.TxtPartCode.Text == "N/A" || string.IsNullOrEmpty(this.TxtPartCode.Text))
			{
				this.TxtPartCode.Text = "N/A";
			}
			if (this.TxtEcmId != null && !string.IsNullOrEmpty(this.TxtEcmId.Text) && this.TxtEcmId.Text != "N/A" && this.IsValidECUID(this.TxtEcmId.Text))
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ ECU ID valid, offset dipertahankan\n", DateTime.Now));
			}
			else
			{
				this.TbStartOffset.Text = "0";
				this.TbChecksumOffset.Text = "0";
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udd04 Offset direset ke default\n", DateTime.Now));
			}
			this.PbProgress.Value = 0;
		}

		// Token: 0x060000BD RID: 189 RVA: 0x0001D3B0 File Offset: 0x0001D3B0
		private void LogResetCompletion(string ecuId, string partCode)
		{
			try
			{
				string text = Path.Combine(Application.StartupPath, "Logs", "FactoryReset");
				Directory.CreateDirectory(text);
				using (StreamWriter streamWriter = new StreamWriter(Path.Combine(text, string.Format("FactoryReset_{0:yyyyMMdd}.log", DateTime.Now)), true))
				{
					streamWriter.WriteLine(string.Format("[{0:yyyy-MM-dd HH:mm:ss}] FACTORY RESET COMPLETED", DateTime.Now));
					streamWriter.WriteLine("  ECU ID: " + ecuId);
					streamWriter.WriteLine("  Part Code: " + partCode);
					streamWriter.WriteLine("  Flash Count: " + this.TxtFlashCount.Text);
					streamWriter.WriteLine("  Result: SUCCESS");
					streamWriter.WriteLine("======================================");
				}
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ======================================\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ FACTORY RESET SUMMARY\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   ECU ID: {1}\n", DateTime.Now, ecuId));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Part Code: {1}\n", DateTime.Now, partCode));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Flash Count: {1}\n", DateTime.Now, this.TxtFlashCount.Text));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Status: BERHASIL\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ======================================\n", DateTime.Now));
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Gagal menulis log completion: {1}\n", DateTime.Now, ex.Message));
			}
		}

		// Token: 0x060000BE RID: 190 RVA: 0x0001D5B8 File Offset: 0x0001D5B8
		private void ShowFinalConfirmation(string ecuId, string partCode)
		{
			CustomMessageBox__1.Show(string.Concat(new string[]
			{
				"Reset pabrik telah berhasil dilakukan!\n\nECU ID: ",
				ecuId,
				"\nPart Code: ",
				partCode,
				"\nFlash Count: ",
				this.TxtFlashCount.Text,
				"\n\nSemua pengaturan telah dikembalikan ke default pabrik."
			}), "Reset Pabrik Berhasil", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		// Token: 0x060000BF RID: 191 RVA: 0x0001D614 File Offset: 0x0001D614
		private bool ValidateBackupFile(string filePath)
		{
			bool result;
			try
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udd0d Memvalidasi file backup...\n", DateTime.Now));
				if (!File.Exists(filePath))
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ❌ File tidak ditemukan\n", DateTime.Now));
					result = false;
				}
				else
				{
					long length = new FileInfo(filePath).Length;
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udcca Ukuran file: {1} bytes\n", DateTime.Now, length));
					if (length != 524288L && length != 1048576L && length != 2097152L && length != 10485760L)
					{
						this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Ukuran file tidak standar: {1} bytes\n", DateTime.Now, length));
						if (CustomMessageBox__1.Show(string.Format("Ukuran file backup ({0} bytes) tidak standar.\n", length) + "Lanjutkan restore?", "Peringatan Ukuran File", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
						{
							return false;
						}
					}
					string text = Path.GetExtension(filePath).ToLower();
					if (Array.IndexOf<string>(new string[]
					{
						".hfb",
						".bin",
						".bak",
						".backup"
					}, text) == -1)
					{
						this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Ekstensi file tidak umum: {1}\n", DateTime.Now, text));
					}
					this.VerifyFileChecksum(filePath);
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ File backup valid\n", DateTime.Now));
					result = true;
				}
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ❌ Error validasi file: {1}\n", DateTime.Now, ex.Message));
				result = false;
			}
			return result;
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x0001D7E8 File Offset: 0x0001D7E8
		private void VerifyFileChecksum(string filePath)
		{
			checked
			{
				try
				{
					using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
					{
						fileStream.Seek(-4L, SeekOrigin.End);
						byte[] array = new byte[4];
						fileStream.Read(array, 0, 4);
						uint num = BitConverter.ToUInt32(array, 0);
						fileStream.Seek(0L, SeekOrigin.Begin);
						uint num2 = 0U;
						byte[] array2 = new byte[4096];
						long num3 = fileStream.Length - 4L;
						int num4;
						while ((num4 = fileStream.Read(array2, 0, array2.Length)) > 0)
						{
							for (int i = 0; i < num4; i++)
							{
								num2 += (uint)array2[i];
							}
						}
						num2 &= uint.MaxValue;
						if (num == num2)
						{
							this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ Checksum valid: 0x{1:X8}\n", DateTime.Now, num));
						}
						else
						{
							this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Checksum tidak cocok: stored=0x{1:X8}, calculated=0x{2:X8}\n", DateTime.Now, num, num2));
						}
					}
				}
				catch
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Tidak dapat memverifikasi checksum\n", DateTime.Now));
				}
			}
		}

		// Token: 0x060000C1 RID: 193 RVA: 0x0001D918 File Offset: 0x0001D918
		private FormMain.BackupMetadata ReadBackupMetadata(string filePath)
		{
			FormMain.BackupMetadata result;
			try
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udcd6 Membaca metadata backup...\n", DateTime.Now));
				FormMain.BackupMetadata backupMetadata = new FormMain.BackupMetadata();
				FileInfo fileInfo = new FileInfo(filePath);
				backupMetadata.FileSize = fileInfo.Length;
				backupMetadata.BackupDate = fileInfo.LastWriteTime;
				string text = Path.ChangeExtension(filePath, ".meta");
				if (File.Exists(text))
				{
					this.ReadMetaFile(text, backupMetadata);
				}
				else
				{
					this.ExtractMetadataFromFileName(filePath, backupMetadata);
					this.ReadBinaryHeader(filePath, backupMetadata);
				}
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udccb Metadata ditemukan:\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • ECU ID: {1}\n", DateTime.Now, backupMetadata.ECUID));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • Part Code: {1}\n", DateTime.Now, backupMetadata.PartCode));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • Tanggal: {1:yyyy-MM-dd HH:mm}\n", DateTime.Now, backupMetadata.BackupDate));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • Ukuran: {1} bytes\n", DateTime.Now, backupMetadata.FileSize));
				result = backupMetadata;
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Error membaca metadata: {1}\n", DateTime.Now, ex.Message));
				result = null;
			}
			return result;
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x0001DAA4 File Offset: 0x0001DAA4
		private void ReadMetaFile(string metaFilePath, FormMain.BackupMetadata metadata)
		{
			try
			{
				foreach (string text in File.ReadAllLines(metaFilePath))
				{
					if (text.Contains("="))
					{
						string[] array2 = text.Split(new char[]
						{
							'='
						});
						if (array2.Length == 2)
						{
							string text2 = array2[0].Trim();
							string text3 = array2[1].Trim();
							uint num = <PrivateImplementationDetails><e905a969-58d0-4e27-ac30-66ce3f984204_netmodule>.ComputeStringHash(text2);
							if (num <= 1047733153U)
							{
								if (num <= 513760276U)
								{
									if (num != 411131668U)
									{
										if (num != 513760276U)
										{
											goto IL_1AB;
										}
										if (!(text2 == "Backup_Date"))
										{
											goto IL_1AB;
										}
										DateTime backupDate;
										if (DateTime.TryParse(text3, out backupDate))
										{
											metadata.BackupDate = backupDate;
											goto IL_1AB;
										}
										goto IL_1AB;
									}
									else if (!(text2 == "ECU_ID"))
									{
										goto IL_1AB;
									}
								}
								else if (num != 728998358U)
								{
									if (num != 1047733153U)
									{
										goto IL_1AB;
									}
									if (!(text2 == "PartCode"))
									{
										goto IL_1AB;
									}
									goto IL_170;
								}
								else if (!(text2 == "ECU_Model"))
								{
									goto IL_1AB;
								}
								metadata.ECUID = text3;
								goto IL_1AB;
							}
							if (num <= 1508320178U)
							{
								if (num != 1416177487U)
								{
									if (num != 1508320178U)
									{
										goto IL_1AB;
									}
									if (!(text2 == "Checksum"))
									{
										goto IL_1AB;
									}
									metadata.Checksum = text3;
									goto IL_1AB;
								}
								else
								{
									if (!(text2 == "Software_Version"))
									{
										goto IL_1AB;
									}
									metadata.SoftwareVersion = text3;
									goto IL_1AB;
								}
							}
							else if (num != 1899843224U)
							{
								if (num != 4176264298U)
								{
									goto IL_1AB;
								}
								if (!(text2 == "VIN"))
								{
									goto IL_1AB;
								}
								metadata.VIN = text3;
								goto IL_1AB;
							}
							else if (!(text2 == "Part_Code"))
							{
								goto IL_1AB;
							}
							IL_170:
							metadata.PartCode = text3;
						}
					}
					IL_1AB:;
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x0001DC8C File Offset: 0x0001DC8C
		private void ExtractMetadataFromFileName(string filePath, FormMain.BackupMetadata metadata)
		{
			try
			{
				string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(filePath);
				Match match = new Regex("ECU[_\\s-]*Backup[_\\s-]*([A-Z0-9-]+)_(\\d{8})_(\\d{6})", RegexOptions.IgnoreCase).Match(fileNameWithoutExtension);
				if (match.Success)
				{
					metadata.ECUID = match.Groups[1].Value;
					string value = match.Groups[2].Value;
					string value2 = match.Groups[3].Value;
					DateTime backupDate;
					if (DateTime.TryParseExact(value + " " + value2, "yyyyMMdd HHmmss", CultureInfo.InvariantCulture, DateTimeStyles.None, out backupDate))
					{
						metadata.BackupDate = backupDate;
					}
				}
				else
				{
					Match match2 = new Regex("\\d{5}-[A-Z]{3}-[A-Z0-9]{3}").Match(fileNameWithoutExtension);
					if (match2.Success)
					{
						metadata.ECUID = match2.Value;
						metadata.PartCode = match2.Value;
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x0001DD68 File Offset: 0x0001DD68
		private void ReadBinaryHeader(string filePath, FormMain.BackupMetadata metadata)
		{
			try
			{
				using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
				{
					using (BinaryReader binaryReader = new BinaryReader(fileStream))
					{
						byte[] bytes = binaryReader.ReadBytes(128);
						string @string = Encoding.ASCII.GetString(bytes);
						string[] array = new string[]
						{
							"37820-[A-Z]{3}-[A-Z0-9]{3}",
							"37821-[A-Z]{3}-[A-Z0-9]{3}",
							"HONDA",
							"ECU"
						};
						int i = 0;
						while (i < array.Length)
						{
							string text = array[i];
							Match match = new Regex(text).Match(@string);
							if (match.Success)
							{
								if (text.Contains("37820") || text.Contains("37821"))
								{
									metadata.ECUID = match.Value;
									metadata.PartCode = match.Value;
									break;
								}
								break;
							}
							else
							{
								i++;
							}
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x0001DE74 File Offset: 0x0001DE74
		private bool VerifyECUCompatibility(FormMain.BackupMetadata metadata)
		{
			bool result;
			try
			{
				Label txtEcmId = this.TxtEcmId;
				string text = ((txtEcmId != null) ? txtEcmId.Text : null) ?? "";
				Label txtPartCode = this.TxtPartCode;
				if (txtPartCode != null)
				{
					string text2 = txtPartCode.Text;
				}
				if (string.IsNullOrEmpty(text) || text == "N/A")
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ℹ️ Tidak ada informasi ECU saat ini, skip verifikasi\n", DateTime.Now));
					result = true;
				}
				else if (!string.IsNullOrEmpty(metadata.ECUID) && metadata.ECUID != "N/A")
				{
					string text3 = this.ExtractBasePartNumber(metadata.ECUID);
					string text4 = this.ExtractBasePartNumber(text);
					if (text3 == text4)
					{
						this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ Backup kompatibel: {1} == {2}\n", DateTime.Now, text3, text4));
						result = true;
					}
					else
					{
						this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Backup tidak kompatibel: {1} != {2}\n", DateTime.Now, text3, text4));
						result = false;
					}
				}
				else
				{
					result = true;
				}
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Error verifikasi kompatibilitas: {1}\n", DateTime.Now, ex.Message));
				result = false;
			}
			return result;
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x0001DFB4 File Offset: 0x0001DFB4
		private string ExtractBasePartNumber(string partNumber)
		{
			if (string.IsNullOrEmpty(partNumber))
			{
				return "";
			}
			string[] array = partNumber.Split(new char[]
			{
				'-'
			});
			if (array.Length >= 3)
			{
				return string.Concat(new string[]
				{
					array[0],
					"-",
					array[1],
					"-",
					array[2]
				});
			}
			return partNumber;
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x000026F4 File Offset: 0x000026F4
		private void ExecuteBackupRestore(string backupFilePath, FormMain.BackupMetadata metadata)
		{
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x0001E018 File Offset: 0x0001E018
		private void UpdateProgress(int startPercent, int endPercent, string status)
		{
			checked
			{
				for (int i = startPercent; i <= endPercent; i++)
				{
					this.PbProgress.Value = i;
					this.TxtPb.Text = string.Format("Status: {0} ({1}%)", status, i);
					Application.DoEvents();
					Thread.Sleep(20);
				}
			}
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x0001E068 File Offset: 0x0001E068
		private byte[] ReadBackupFile(string filePath)
		{
			byte[] result;
			try
			{
				result = File.ReadAllBytes(filePath);
			}
			catch (Exception ex)
			{
				throw new Exception("Gagal membaca file backup: " + ex.Message, ex);
			}
			return result;
		}

		// Token: 0x060000CA RID: 202 RVA: 0x00002BCB File Offset: 0x00002BCB
		private void ValidateBackupData(byte[] data)
		{
			if (data == null || data.Length == 0)
			{
				throw new Exception("Data backup kosong");
			}
		}

		// Token: 0x060000CB RID: 203 RVA: 0x00002BDF File Offset: 0x00002BDF
		private void ConnectToECU()
		{
			Thread.Sleep(500);
		}

		// Token: 0x060000CC RID: 204 RVA: 0x0001E0A8 File Offset: 0x0001E0A8
		private void WriteToECU(byte[] data)
		{
			int num = 1024;
			checked
			{
				int num2 = (int)Math.Ceiling((double)data.Length / (double)num);
				for (int i = 0; i < num2; i++)
				{
					int num3 = i * num;
					int num4 = Math.Min(num, data.Length - num3);
					byte[] destinationArray = new byte[num4];
					Array.Copy(data, num3, destinationArray, 0, num4);
					Thread.Sleep(50);
					int val = 50 + (int)(unchecked(40.0 * (double)(checked(i + 1))) / (double)num2);
					this.PbProgress.Value = Math.Min(val, 90);
					this.TxtPb.Text = string.Format("Status: Menulis ke ECU (chunk {0}/{1})", i + 1, num2);
					Application.DoEvents();
				}
			}
		}

		// Token: 0x060000CD RID: 205 RVA: 0x00002BEB File Offset: 0x00002BEB
		private void VerifyWrite()
		{
			Thread.Sleep(300);
		}

		// Token: 0x060000CE RID: 206 RVA: 0x00002BF7 File Offset: 0x00002BF7
		private void FinalizeRestore()
		{
			Thread.Sleep(200);
		}

		// Token: 0x060000CF RID: 207 RVA: 0x0001E15C File Offset: 0x0001E15C
		private void UpdateUIFromBackup(FormMain.BackupMetadata metadata)
		{
			try
			{
				if ((string.IsNullOrEmpty(this.TxtEcmId.Text) || this.TxtEcmId.Text == "N/A") && !string.IsNullOrEmpty(metadata.ECUID) && metadata.ECUID != "N/A")
				{
					this.TxtEcmId.Text = metadata.ECUID;
				}
				if ((string.IsNullOrEmpty(this.TxtPartCode.Text) || this.TxtPartCode.Text == "N/A") && !string.IsNullOrEmpty(metadata.PartCode) && metadata.PartCode != "N/A")
				{
					this.TxtPartCode.Text = metadata.PartCode;
				}
				int num;
				if (int.TryParse(this.TxtFlashCount.Text, out num))
				{
					this.TxtFlashCount.Text = (checked(num + 1)).ToString();
				}
				else
				{
					this.TxtFlashCount.Text = "1";
				}
				this.TxtPb.Text = "Status: Restore berhasil";
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Error update UI: {1}\n", DateTime.Now, ex.Message));
			}
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x0001E2B0 File Offset: 0x0001E2B0
		private void LogRestoreCompletion(string backupFilePath, FormMain.BackupMetadata metadata)
		{
			try
			{
				string text = Path.Combine(Application.StartupPath, "Logs", "Restore");
				Directory.CreateDirectory(text);
				using (StreamWriter streamWriter = new StreamWriter(Path.Combine(text, string.Format("Restore_{0:yyyyMMdd}.log", DateTime.Now)), true))
				{
					streamWriter.WriteLine(string.Format("[{0:yyyy-MM-dd HH:mm:ss}] RESTORE COMPLETED", DateTime.Now));
					streamWriter.WriteLine("  File: " + Path.GetFileName(backupFilePath));
					streamWriter.WriteLine("  ECU ID: " + metadata.ECUID);
					streamWriter.WriteLine("  Part Code: " + metadata.PartCode);
					streamWriter.WriteLine(string.Format("  Backup Date: {0:yyyy-MM-dd HH:mm:ss}", metadata.BackupDate));
					streamWriter.WriteLine(string.Format("  File Size: {0} bytes", metadata.FileSize));
					streamWriter.WriteLine("  Software Version: " + metadata.SoftwareVersion);
					streamWriter.WriteLine("  Result: SUCCESS");
					streamWriter.WriteLine("======================================");
				}
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ======================================\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ RESTORE BACKUP SUMMARY\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   File: {1}\n", DateTime.Now, Path.GetFileName(backupFilePath)));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   ECU ID: {1}\n", DateTime.Now, metadata.ECUID));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Part Code: {1}\n", DateTime.Now, metadata.PartCode));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Tanggal Backup: {1:yyyy-MM-dd HH:mm}\n", DateTime.Now, metadata.BackupDate));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Ukuran File: {1} bytes\n", DateTime.Now, metadata.FileSize));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Status: BERHASIL\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ======================================\n", DateTime.Now));
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Error logging: {1}\n", DateTime.Now, ex.Message));
			}
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x0001E560 File Offset: 0x0001E560
		private bool ValidateMotorBackupFile(string filePath)
		{
			checked
			{
				bool result;
				try
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udd0d Memvalidasi file backup motor...\n", DateTime.Now));
					if (!File.Exists(filePath))
					{
						this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ❌ File tidak ditemukan\n", DateTime.Now));
						result = false;
					}
					else
					{
						long length = new FileInfo(filePath).Length;
						this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udcca Ukuran file: {1} bytes ({2} KB)\n", DateTime.Now, length, length / 1024L));
						long[] array = new long[]
						{
							32768L,
							65536L,
							131072L,
							262144L,
							524288L,
							1048576L,
							2097152L,
							4194304L
						};
						bool flag = false;
						foreach (long num in array)
						{
							if (length == num)
							{
								flag = true;
								break;
							}
						}
						if (!flag)
						{
							this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Ukuran file tidak standar untuk motor: {1} bytes\n", DateTime.Now, length));
							string text = "";
							for (int j = 0; j < array.Length; j++)
							{
								if (j > 0)
								{
									text += ", ";
								}
								text += string.Format("{0}KB", array[j] / 1024L);
							}
							this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ℹ️ Ukuran valid motor: {1}\n", DateTime.Now, text));
							if (CustomMessageBox__1.Show(string.Format("Ukuran file backup ({0} KB) tidak standar untuk ECU motor Honda.\n\n", length / 1024L) + "Ukuran standar motor: 32KB, 64KB, 128KB, 256KB, 512KB\n\nLanjutkan restore?", "Peringatan Ukuran File Motor", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
							{
								this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ❌ User membatalkan karena ukuran file tidak standar\n", DateTime.Now));
								return false;
							}
							this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ User memilih untuk melanjutkan dengan ukuran tidak standar\n", DateTime.Now));
						}
						else
						{
							string motorSizeDescription = this.GetMotorSizeDescription(length);
							this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ Ukuran file motor valid: {1}\n", DateTime.Now, motorSizeDescription));
						}
						string text2 = Path.GetExtension(filePath).ToLower();
						string[] array3 = new string[]
						{
							".hfb",
							".bin",
							".bak",
							".rom",
							".mbin",
							".mh",
							".hmt",
							".hmb"
						};
						bool flag2 = false;
						foreach (string b in array3)
						{
							if (text2 == b)
							{
								flag2 = true;
								break;
							}
						}
						if (!flag2)
						{
							this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Ekstensi file tidak umum untuk motor: {1}\n", DateTime.Now, text2));
							if (CustomMessageBox__1.Show("Ekstensi file '" + text2 + "' tidak umum untuk backup ECU motor.\n\nEkstensi yang umum: .hfb, .bin, .mbin, .hmb\n\nLanjutkan?", "Peringatan Ekstensi File Motor", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
							{
								this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ❌ User membatalkan karena ekstensi tidak dikenal\n", DateTime.Now));
								return false;
							}
						}
						else
						{
							this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ Ekstensi file motor valid: {1}\n", DateTime.Now, text2));
						}
						try
						{
							using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
							{
								byte[] array5 = new byte[16];
								if (fileStream.Read(array5, 0, 16) == 16)
								{
									string @string = Encoding.ASCII.GetString(array5);
									if (@string.Contains("HM") || @string.Contains("HONDA"))
									{
										this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ Deteksi signature Honda Motor di header\n", DateTime.Now));
									}
									else
									{
										this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Tidak ada signature Honda Motor yang jelas di header\n", DateTime.Now));
									}
								}
							}
						}
						catch (Exception ex)
						{
							this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ❌ Error membaca file: {1}\n", DateTime.Now, ex.Message));
							return false;
						}
						this.VerifyMotorFileChecksum(filePath);
						this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ File backup motor valid\n", DateTime.Now));
						result = true;
					}
				}
				catch (Exception ex2)
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ❌ Error validasi file motor: {1}\n", DateTime.Now, ex2.Message));
					result = false;
				}
				return result;
			}
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x0001E9F0 File Offset: 0x0001E9F0
		private string GetMotorSizeDescription(long fileSize)
		{
			Dictionary<long, string> dictionary = new Dictionary<long, string>
			{
				{
					32768L,
					"32KB (Honda Beat Karbu, Supra X 125)"
				},
				{
					65536L,
					"64KB (Honda Vario 110/125, Scoopy)"
				},
				{
					131072L,
					"128KB (Honda PCX 150, Vario 150)"
				},
				{
					262144L,
					"256KB (Honda CBR150R, CB150R, CRF150L)"
				},
				{
					524288L,
					"512KB (Honda CBR250RR, CB500F)"
				},
				{
					1048576L,
					"1MB (Honda CBR650R, Africa Twin)"
				},
				{
					2097152L,
					"2MB (Honda Goldwing, CRF1100L)"
				},
				{
					4194304L,
					"4MB (Honda Adv 750, NT1100)"
				}
			};
			if (dictionary.ContainsKey(fileSize))
			{
				return dictionary[fileSize];
			}
			return string.Format("{0} KB", fileSize / 1024L);
		}

		// Token: 0x060000D3 RID: 211 RVA: 0x0001EAB4 File Offset: 0x0001EAB4
		private void VerifyMotorFileChecksum(string filePath)
		{
			checked
			{
				try
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udd22 Memverifikasi checksum file motor...\n", DateTime.Now));
					using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
					{
						if (fileStream.Length >= 2L)
						{
							fileStream.Seek(-2L, SeekOrigin.End);
							byte[] array = new byte[2];
							fileStream.Read(array, 0, 2);
							ushort num = BitConverter.ToUInt16(array, 0);
							fileStream.Seek(0L, SeekOrigin.Begin);
							ushort num2 = 0;
							byte[] array2 = new byte[4096];
							long num3 = fileStream.Length - 2L;
							int num4;
							while ((num4 = fileStream.Read(array2, 0, array2.Length)) > 0 && fileStream.Position <= num3)
							{
								int num5 = 0;
								while (num5 < num4 && fileStream.Position - unchecked((long)num4) + unchecked((long)num5) < num3)
								{
									num2 += (ushort)array2[num5];
									num5++;
								}
							}
							num2 &= ushort.MaxValue;
							if (num == num2)
							{
								this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ Checksum motor 16-bit valid: 0x{1:X4}\n", DateTime.Now, num));
							}
							else
							{
								this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Checksum motor tidak cocok: stored=0x{1:X4}, calculated=0x{2:X4}\n", DateTime.Now, num, num2));
								this.TryAlternateMotorChecksum(filePath);
							}
						}
					}
				}
				catch (Exception ex)
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Tidak dapat memverifikasi checksum motor: {1}\n", DateTime.Now, ex.Message));
				}
			}
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x0001EC5C File Offset: 0x0001EC5C
		private void TryAlternateMotorChecksum(string filePath)
		{
			checked
			{
				try
				{
					using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
					{
						fileStream.Seek(0L, SeekOrigin.Begin);
						byte b = 0;
						byte[] array = new byte[4096];
						int num;
						while ((num = fileStream.Read(array, 0, array.Length)) > 0)
						{
							for (int i = 0; i < num; i++)
							{
								b ^= array[i];
							}
						}
						this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udd04 XOR Checksum: 0x{1:X2}\n", DateTime.Now, b));
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x0001ED08 File Offset: 0x0001ED08
		private FormMain.MotorBackupMetadata ReadMotorBackupMetadata(string filePath)
		{
			FormMain.MotorBackupMetadata result;
			try
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udcd6 Membaca metadata backup motor...\n", DateTime.Now));
				FormMain.MotorBackupMetadata motorBackupMetadata = new FormMain.MotorBackupMetadata();
				FileInfo fileInfo = new FileInfo(filePath);
				motorBackupMetadata.FileSize = fileInfo.Length;
				motorBackupMetadata.BackupDate = fileInfo.LastWriteTime;
				motorBackupMetadata.FileType = Path.GetExtension(filePath).ToUpper().TrimStart(new char[]
				{
					'.'
				});
				motorBackupMetadata.MotorModel = this.DetermineMotorModelBySize(fileInfo.Length);
				motorBackupMetadata.EngineCC = this.DetermineEngineCCBySize(fileInfo.Length);
				string text = Path.ChangeExtension(filePath, ".meta");
				if (File.Exists(text))
				{
					this.ReadMotorMetaFile(text, motorBackupMetadata);
				}
				this.ExtractMotorMetadataFromFileName(filePath, motorBackupMetadata);
				this.ReadMotorBinaryHeader(filePath, motorBackupMetadata);
				this.LogMotorMetadata(motorBackupMetadata);
				result = motorBackupMetadata;
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Error membaca metadata motor: {1}\n", DateTime.Now, ex.Message));
				result = null;
			}
			return result;
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x0001EE14 File Offset: 0x0001EE14
		private string DetermineMotorModelBySize(long fileSize)
		{
			if (fileSize <= 262144L)
			{
				if (fileSize <= 65536L)
				{
					if (fileSize == 32768L)
					{
						return "HONDA BEAT/Supra X 125 (Karbu)";
					}
					if (fileSize == 65536L)
					{
						return "HONDA VARIO 110/125/Scoopy (PGM-FI)";
					}
				}
				else
				{
					if (fileSize == 131072L)
					{
						return "HONDA PCX150/VARIO150";
					}
					if (fileSize == 262144L)
					{
						return "HONDA CBR150R/CB150R/CRF150L";
					}
				}
			}
			else if (fileSize <= 1048576L)
			{
				if (fileSize == 524288L)
				{
					return "HONDA CBR250RR/CB500F";
				}
				if (fileSize == 1048576L)
				{
					return "HONDA CBR650R/Africa Twin";
				}
			}
			else
			{
				if (fileSize == 2097152L)
				{
					return "HONDA Goldwing/CRF1100L";
				}
				if (fileSize == 4194304L)
				{
					return "HONDA ADV750/NT1100";
				}
			}
			return string.Format("HONDA MOTOR {0}KB", fileSize / 1024L);
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x0001EED4 File Offset: 0x0001EED4
		private int DetermineEngineCCBySize(long fileSize)
		{
			if (fileSize <= 262144L)
			{
				if (fileSize <= 65536L)
				{
					if (fileSize == 32768L)
					{
						return 110;
					}
					if (fileSize == 65536L)
					{
						return 125;
					}
				}
				else
				{
					if (fileSize == 131072L)
					{
						return 150;
					}
					if (fileSize == 262144L)
					{
						return 150;
					}
				}
			}
			else if (fileSize <= 1048576L)
			{
				if (fileSize == 524288L)
				{
					return 250;
				}
				if (fileSize == 1048576L)
				{
					return 650;
				}
			}
			else
			{
				if (fileSize == 2097152L)
				{
					return 1100;
				}
				if (fileSize == 4194304L)
				{
					return 750;
				}
			}
			return 0;
		}

		// Token: 0x060000D8 RID: 216 RVA: 0x0001EF78 File Offset: 0x0001EF78
		private void ReadMotorMetaFile(string metaFilePath, FormMain.MotorBackupMetadata metadata)
		{
			try
			{
				foreach (string text in File.ReadAllLines(metaFilePath))
				{
					if (text.Contains("="))
					{
						string[] array2 = text.Split(new char[]
						{
							'='
						});
						if (array2.Length == 2)
						{
							string text2 = array2[0].Trim();
							string text3 = array2[1].Trim();
							string text4 = text2.ToUpper();
							uint num = <PrivateImplementationDetails><b38d8467-61c2-48ce-ae55-002da5dd987f_netmodule>.ComputeStringHash(text4);
							if (num <= 1729495782U)
							{
								if (num <= 1003618836U)
								{
									if (num != 507474120U)
									{
										if (num != 999103698U)
										{
											if (num != 1003618836U)
											{
												goto IL_26C;
											}
											if (!(text4 == "BACKUP_DATE"))
											{
												goto IL_26C;
											}
											DateTime backupDate;
											if (DateTime.TryParse(text3, out backupDate))
											{
												metadata.BackupDate = backupDate;
												goto IL_26C;
											}
											goto IL_26C;
										}
										else
										{
											if (!(text4 == "CHECKSUM"))
											{
												goto IL_26C;
											}
											metadata.Checksum = text3;
											goto IL_26C;
										}
									}
									else
									{
										if (!(text4 == "ECU_CODE"))
										{
											goto IL_26C;
										}
										goto IL_212;
									}
								}
								else if (num != 1405829844U)
								{
									if (num != 1653528217U)
									{
										if (num != 1729495782U)
										{
											goto IL_26C;
										}
										if (!(text4 == "FUEL_TYPE"))
										{
											goto IL_26C;
										}
										metadata.FuelType = text3;
										goto IL_26C;
									}
									else
									{
										if (!(text4 == "TAHUN"))
										{
											goto IL_26C;
										}
										goto IL_21C;
									}
								}
								else if (!(text4 == "MOTOR_MODEL"))
								{
									goto IL_26C;
								}
							}
							else
							{
								if (num <= 2155289850U)
								{
									if (num != 1934760913U)
									{
										if (num != 1977225635U)
										{
											if (num != 2155289850U)
											{
												goto IL_26C;
											}
											if (!(text4 == "MODEL"))
											{
												goto IL_26C;
											}
											goto IL_208;
										}
										else if (!(text4 == "CC"))
										{
											goto IL_26C;
										}
									}
									else
									{
										if (!(text4 == "ECUCODE"))
										{
											goto IL_26C;
										}
										goto IL_212;
									}
								}
								else if (num != 2351556826U)
								{
									if (num != 2359195375U)
									{
										if (num != 2585027932U)
										{
											goto IL_26C;
										}
										if (!(text4 == "YEAR"))
										{
											goto IL_26C;
										}
										goto IL_21C;
									}
									else
									{
										if (!(text4 == "SOFTWARE_VERSION"))
										{
											goto IL_26C;
										}
										metadata.SoftwareVersion = text3;
										goto IL_26C;
									}
								}
								else if (!(text4 == "ENGINE_CC"))
								{
									goto IL_26C;
								}
								int engineCC;
								if (int.TryParse(text3, out engineCC))
								{
									metadata.EngineCC = engineCC;
									goto IL_26C;
								}
								goto IL_26C;
							}
							IL_208:
							metadata.MotorModel = text3;
							goto IL_26C;
							IL_212:
							metadata.ECUCode = text3;
							goto IL_26C;
							IL_21C:
							metadata.Year = text3;
						}
					}
					IL_26C:;
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x0001F220 File Offset: 0x0001F220
		private void ExtractMotorMetadataFromFileName(string filePath, FormMain.MotorBackupMetadata metadata)
		{
			try
			{
				string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(filePath);
				foreach (string text in new string[]
				{
					"CBR150R",
					"CB150R",
					"CRF150L",
					"PCX150",
					"VARIO150",
					"VARIO125",
					"SCOOPY",
					"BEAT",
					"CBR250RR",
					"CB500F",
					"CBR650R",
					"AFRICA TWIN",
					"GOLDWING",
					"CRF1100L",
					"ADV750",
					"NT1100"
				})
				{
					if (fileNameWithoutExtension.ToUpper().Contains(text.ToUpper()))
					{
						metadata.MotorModel = text;
						break;
					}
				}
				Match match = new Regex("38[0-9]{3}-[A-Z][0-9]{2}-[A-Z0-9]{3}").Match(fileNameWithoutExtension);
				if (match.Success)
				{
					metadata.ECUCode = match.Value;
				}
				Match match2 = new Regex("20[0-9]{2}").Match(fileNameWithoutExtension);
				if (match2.Success)
				{
					metadata.Year = match2.Value;
				}
				Match match3 = new Regex("(?<!\\d)(110|125|150|250|500|650|750|1100)(?!\\d)").Match(fileNameWithoutExtension);
				int engineCC;
				if (match3.Success && int.TryParse(match3.Value, out engineCC))
				{
					metadata.EngineCC = engineCC;
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000DA RID: 218 RVA: 0x0001F398 File Offset: 0x0001F398
		private void ReadMotorBinaryHeader(string filePath, FormMain.MotorBackupMetadata metadata)
		{
			try
			{
				using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
				{
					using (BinaryReader binaryReader = new BinaryReader(fileStream))
					{
						byte[] bytes = binaryReader.ReadBytes(256);
						string @string = Encoding.ASCII.GetString(bytes);
						this.SearchMotorInfoInHeader(@string, metadata);
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000DB RID: 219 RVA: 0x0001F41C File Offset: 0x0001F41C
		private void SearchMotorInfoInHeader(string headerText, FormMain.MotorBackupMetadata metadata)
		{
			Match match = new Regex("38[0-9]{3}-[A-Z][0-9]{2}-[A-Z0-9]{3}").Match(headerText);
			if (match.Success && metadata.ECUCode == "N/A")
			{
				metadata.ECUCode = match.Value;
			}
			if (headerText.Contains("CBR150R") && metadata.MotorModel == "N/A")
			{
				metadata.MotorModel = "CBR150R";
			}
			else if (headerText.Contains("PCX150") && metadata.MotorModel == "N/A")
			{
				metadata.MotorModel = "PCX150";
			}
			else if (headerText.Contains("VARIO") && metadata.MotorModel == "N/A")
			{
				metadata.MotorModel = "VARIO";
			}
			else if (headerText.Contains("BEAT") && metadata.MotorModel == "N/A")
			{
				metadata.MotorModel = "BEAT";
			}
			if (headerText.Contains("PGM-FI") || headerText.Contains("PGMFI"))
			{
				metadata.FuelType = "PGM-FI";
				return;
			}
			if (headerText.Contains("CARB") || headerText.Contains("KARBU"))
			{
				metadata.FuelType = "Carburator";
			}
		}

		// Token: 0x060000DC RID: 220 RVA: 0x0001F55C File Offset: 0x0001F55C
		private void LogMotorMetadata(FormMain.MotorBackupMetadata metadata)
		{
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udccb Metadata motor ditemukan:\n", DateTime.Now));
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • Model: {1}\n", DateTime.Now, metadata.MotorModel));
			if (metadata.ECUCode != "N/A")
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • ECU Code: {1}\n", DateTime.Now, metadata.ECUCode));
			}
			if (metadata.Year != "N/A")
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • Tahun: {1}\n", DateTime.Now, metadata.Year));
			}
			if (metadata.EngineCC > 0)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • Kapasitas: {1}cc\n", DateTime.Now, metadata.EngineCC));
			}
			if (metadata.FuelType != "N/A")
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • Sistem Bahan Bakar: {1}\n", DateTime.Now, metadata.FuelType));
			}
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • Tipe File: {1}\n", DateTime.Now, metadata.FileType));
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • Ukuran: {1} bytes ({2} KB)\n", DateTime.Now, metadata.FileSize, metadata.FileSize / 1024L));
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • Tanggal Backup: {1:yyyy-MM-dd HH:mm}\n", DateTime.Now, metadata.BackupDate));
			if (metadata.SoftwareVersion != "N/A")
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • Versi Software: {1}\n", DateTime.Now, metadata.SoftwareVersion));
			}
		}

		// Token: 0x060000DD RID: 221 RVA: 0x0001F748 File Offset: 0x0001F748
		private bool VerifyMotorECUCompatibility(FormMain.MotorBackupMetadata metadata)
		{
			bool result;
			try
			{
				Label txtEcmId = this.TxtEcmId;
				string text = ((txtEcmId != null) ? txtEcmId.Text : null) ?? "";
				Label txtPartCode = this.TxtPartCode;
				string text2 = ((txtPartCode != null) ? txtPartCode.Text : null) ?? "";
				if (string.IsNullOrEmpty(text) || text == "N/A")
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ℹ️ Tidak ada informasi motor saat ini, skip verifikasi\n", DateTime.Now));
					result = true;
				}
				else if (!string.IsNullOrEmpty(metadata.MotorModel) && metadata.MotorModel != "N/A" && (text.ToUpper().Contains(metadata.MotorModel.ToUpper()) || metadata.MotorModel.ToUpper().Contains(text.ToUpper())))
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ Model motor kompatibel\n", DateTime.Now));
					result = true;
				}
				else
				{
					if (!string.IsNullOrEmpty(metadata.ECUCode) && metadata.ECUCode != "N/A" && !string.IsNullOrEmpty(text2) && text2 != "N/A")
					{
						string[] array = metadata.ECUCode.Split(new char[]
						{
							'-'
						});
						string[] array2 = text2.Split(new char[]
						{
							'-'
						});
						if (array.Length >= 2 && array2.Length >= 2 && array[0] == array2[0] && array[1] == array2[1])
						{
							this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ ECU Code kompatibel\n", DateTime.Now));
							return true;
						}
					}
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Backup mungkin tidak kompatibel\n", DateTime.Now));
					result = false;
				}
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Error verifikasi kompatibilitas motor: {1}\n", DateTime.Now, ex.Message));
				result = false;
			}
			return result;
		}

		// Token: 0x060000DE RID: 222 RVA: 0x0001F95C File Offset: 0x0001F95C
		private void ExecuteMotorBackupRestore(string backupFilePath, FormMain.MotorBackupMetadata metadata)
		{
			try
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udd04 Memulai proses restore motor...\n", DateTime.Now));
				this.UpdateMotorProgress(0, 10, "Mempersiapkan restore motor...");
				byte[] data = this.ReadBackupFile(backupFilePath);
				this.UpdateMotorProgress(10, 30, "Membaca data backup motor...");
				this.ValidateMotorBackupData(data, metadata);
				this.UpdateMotorProgress(30, 40, "Memvalidasi data motor...");
				this.ConnectToMotorECU(metadata);
				this.UpdateMotorProgress(40, 50, "Menghubungkan ke ECU motor...");
				this.WriteToMotorECU(data, metadata);
				this.UpdateMotorProgress(50, 90, "Menulis data ke ECU motor...");
				this.VerifyMotorWrite(metadata);
				this.UpdateMotorProgress(90, 95, "Memverifikasi penulisan motor...");
				this.FinalizeMotorRestore(metadata);
				this.UpdateMotorProgress(95, 100, "Finalisasi restore motor...");
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ Proses restore motor selesai\n", DateTime.Now));
			}
			catch (Exception ex)
			{
				throw new Exception("Error dalam proses restore motor: " + ex.Message, ex);
			}
		}

		// Token: 0x060000DF RID: 223 RVA: 0x0001FA68 File Offset: 0x0001FA68
		private void UpdateMotorProgress(int startPercent, int endPercent, string status)
		{
			checked
			{
				for (int i = startPercent; i <= endPercent; i++)
				{
					this.PbProgress.Value = i;
					this.TxtPb.Text = string.Format("Status: {0} ({1}%)", status, i);
					Application.DoEvents();
					Thread.Sleep(15);
				}
			}
		}

		// Token: 0x060000E0 RID: 224 RVA: 0x0001FAB8 File Offset: 0x0001FAB8
		private void ValidateMotorBackupData(byte[] data, FormMain.MotorBackupMetadata metadata)
		{
			if (data == null || data.Length == 0)
			{
				throw new Exception("Data backup motor kosong");
			}
			if (data.Length < 32768)
			{
				throw new Exception(string.Format("Ukuran data terlalu kecil untuk motor: {0} bytes", data.Length));
			}
			checked
			{
				if (data.Length >= 100)
				{
					bool flag = false;
					for (int i = 0; i < Math.Min(100, data.Length); i++)
					{
						if (data[i] == 72 && i + 1 < data.Length && data[i + 1] == 77)
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Tidak ditemukan signature HM (Honda Motor) di data\n", DateTime.Now));
					}
				}
			}
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x0001FB58 File Offset: 0x0001FB58
		private void ConnectToMotorECU(FormMain.MotorBackupMetadata metadata)
		{
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udd0c Menghubungkan ke ECU {1}...\n", DateTime.Now, metadata.MotorModel));
			Thread.Sleep(300);
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ Terhubung ke ECU motor\n", DateTime.Now));
		}

		// Token: 0x060000E2 RID: 226 RVA: 0x0001FBB4 File Offset: 0x0001FBB4
		private void WriteToMotorECU(byte[] data, FormMain.MotorBackupMetadata metadata)
		{
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✍️ Menulis data ke ECU motor ({1} bytes)...\n", DateTime.Now, data.Length));
			int num = 512;
			checked
			{
				int num2 = (int)Math.Ceiling((double)data.Length / (double)num);
				for (int i = 0; i < num2; i++)
				{
					int num3 = i * num;
					Math.Min(num, data.Length - num3);
					Thread.Sleep(30);
					int val = 50 + (int)(unchecked(40.0 * (double)(checked(i + 1))) / (double)num2);
					this.PbProgress.Value = Math.Min(val, 90);
					this.TxtPb.Text = string.Format("Status: Menulis ke ECU motor ({0}/{1} chunks)", i + 1, num2);
					Application.DoEvents();
				}
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ Data berhasil ditulis ke ECU motor\n", DateTime.Now));
			}
		}

		// Token: 0x060000E3 RID: 227 RVA: 0x0001FC94 File Offset: 0x0001FC94
		private void VerifyMotorWrite(FormMain.MotorBackupMetadata metadata)
		{
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udd0d Memverifikasi penulisan data motor...\n", DateTime.Now));
			Thread.Sleep(200);
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ Verifikasi penulisan berhasil\n", DateTime.Now));
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x0001FCEC File Offset: 0x0001FCEC
		private void FinalizeMotorRestore(FormMain.MotorBackupMetadata metadata)
		{
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83c\udfaf Finalisasi restore motor {1}...\n", DateTime.Now, metadata.MotorModel));
			Thread.Sleep(150);
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udd04 Melakukan reset ECU motor...\n", DateTime.Now));
			Thread.Sleep(100);
			this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ ECU motor telah direset\n", DateTime.Now));
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x0001FD70 File Offset: 0x0001FD70
		private void UpdateUIFromMotorBackup(FormMain.MotorBackupMetadata metadata)
		{
			try
			{
				if (!string.IsNullOrEmpty(metadata.MotorModel) && metadata.MotorModel != "N/A")
				{
					this.TxtEcmId.Text = metadata.MotorModel;
				}
				if (!string.IsNullOrEmpty(metadata.ECUCode) && metadata.ECUCode != "N/A")
				{
					this.TxtPartCode.Text = metadata.ECUCode;
				}
				Control[] array = base.Controls.Find("TxtEngineCC", true);
				TextBox textBox;
				if (array.Length != 0 && (textBox = (array[0] as TextBox)) != null)
				{
					textBox.Text = metadata.EngineCC.ToString();
				}
				int num;
				if (int.TryParse(this.TxtFlashCount.Text, out num))
				{
					this.TxtFlashCount.Text = (checked(num + 1)).ToString();
				}
				else
				{
					this.TxtFlashCount.Text = "1";
				}
				this.TxtPb.Text = "Status: Restore motor " + metadata.MotorModel + " berhasil";
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83c\udfcd️ Data motor telah diupdate di UI\n", DateTime.Now));
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Error update UI motor: {1}\n", DateTime.Now, ex.Message));
			}
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x0001FED8 File Offset: 0x0001FED8
		private void LogMotorRestoreCompletion(string backupFilePath, FormMain.MotorBackupMetadata metadata)
		{
			try
			{
				string text = Path.Combine(Application.StartupPath, "Logs", "Motor", "Restore");
				Directory.CreateDirectory(text);
				using (StreamWriter streamWriter = new StreamWriter(Path.Combine(text, string.Format("MotorRestore_{0:yyyyMMdd}.log", DateTime.Now)), true))
				{
					streamWriter.WriteLine(string.Format("[{0:yyyy-MM-dd HH:mm:ss}] MOTOR RESTORE COMPLETED", DateTime.Now));
					streamWriter.WriteLine("  Model: " + metadata.MotorModel);
					streamWriter.WriteLine("  ECU Code: " + metadata.ECUCode);
					streamWriter.WriteLine("  Year: " + metadata.Year);
					streamWriter.WriteLine(string.Format("  Engine: {0}cc", metadata.EngineCC));
					streamWriter.WriteLine("  Fuel Type: " + metadata.FuelType);
					streamWriter.WriteLine("  File: " + Path.GetFileName(backupFilePath));
					streamWriter.WriteLine(string.Format("  Size: {0} bytes", metadata.FileSize));
					streamWriter.WriteLine("  Result: SUCCESS");
					streamWriter.WriteLine("======================================");
				}
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ======================================\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83c\udfcd️ MOTOR RESTORE SUMMARY\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Model: {1}\n", DateTime.Now, metadata.MotorModel));
				if (metadata.ECUCode != "N/A")
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   ECU Code: {1}\n", DateTime.Now, metadata.ECUCode));
				}
				if (metadata.Year != "N/A")
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Tahun: {1}\n", DateTime.Now, metadata.Year));
				}
				if (metadata.EngineCC > 0)
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Kapasitas: {1}cc\n", DateTime.Now, metadata.EngineCC));
				}
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   File: {1}\n", DateTime.Now, Path.GetFileName(backupFilePath)));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Ukuran: {1} bytes\n", DateTime.Now, metadata.FileSize));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Status: BERHASIL\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ======================================\n", DateTime.Now));
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Error logging motor: {1}\n", DateTime.Now, ex.Message));
			}
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x000201F4 File Offset: 0x000201F4
		private bool VerifyMotorECUCompatibility(FormMain.MotorBackupMetadata metadata, string panel3EcuId, string panel3PartCode)
		{
			bool result;
			try
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udd0d Memverifikasi kompatibilitas dengan Panel3 data...\n", DateTime.Now));
				if ((string.IsNullOrEmpty(panel3EcuId) || panel3EcuId == "N/A") && (string.IsNullOrEmpty(panel3PartCode) || panel3PartCode == "N/A"))
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ℹ️ Tidak ada data Panel3, skip verifikasi\n", DateTime.Now));
					return true;
				}
				string text = this.ExtractMotorModelFromPanel3(panel3PartCode, panel3EcuId);
				string text2 = this.ExtractEngineCCFromPanel3(panel3PartCode);
				string text3 = this.ExtractECUTypeFromPanel3(panel3EcuId);
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udcca Analisis Panel3 Data:\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • Model: {1}\n", DateTime.Now, text));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • CC: {1}\n", DateTime.Now, text2));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • ECU Type: {1}\n", DateTime.Now, text3));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • Part Code: {1}\n", DateTime.Now, panel3PartCode));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udcca Analisis Backup Data:\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • Model: {1}\n", DateTime.Now, metadata.MotorModel));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • CC: {1}cc\n", DateTime.Now, metadata.EngineCC));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   • ECU Code: {1}\n", DateTime.Now, metadata.ECUCode));
				if (!this.CheckFileSizeCompatibility(metadata.FileSize, text))
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Ukuran file tidak cocok dengan model Panel3\n", DateTime.Now));
				}
				int num = 0;
				if (metadata.EngineCC > 0 && !string.IsNullOrEmpty(text2) && int.TryParse(text2, out num))
				{
					if (metadata.EngineCC != num)
					{
						this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ CC mesin tidak cocok: Backup={1}cc, Panel3={2}cc\n", DateTime.Now, metadata.EngineCC, num));
					}
					else
					{
						this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ CC mesin cocok: {1}cc\n", DateTime.Now, metadata.EngineCC));
					}
				}
				if (!string.IsNullOrEmpty(text3) && text3 != "UNKNOWN")
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ℹ️ ECU HEX ID: {1}\n", DateTime.Now, text3));
					if (text3.StartsWith("0102E30F") && !string.IsNullOrEmpty(metadata.MotorModel) && metadata.MotorModel.Contains("CBR150R"))
					{
						this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ❌ ECU ID Beat 110 tidak kompatibel dengan CBR150R\n", DateTime.Now));
						return false;
					}
				}
				string text4 = this.DetermineFuelTypeFromModel(metadata.MotorModel);
				string text5 = this.DetermineFuelTypeFromPanel3(panel3PartCode, panel3EcuId);
				if (!string.IsNullOrEmpty(text4) && !string.IsNullOrEmpty(text5) && text4 != text5)
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Tipe bahan bakar tidak cocok: Backup={1}, Panel3={2}\n", DateTime.Now, text4, text5));
				}
				switch (this.DetermineCompatibilityLevel(metadata, text, text2, text3))
				{
				case FormMain.CompatibilityLevel.HIGH:
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ✅ KOMPATIBILITAS TINGGI - Restore aman\n", DateTime.Now));
					result = true;
					break;
				case FormMain.CompatibilityLevel.MEDIUM:
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ KOMPATIBILITAS SEDANG - Restore dengan hati-hati\n", DateTime.Now));
					result = this.AskUserForMediumCompatibility(metadata, text);
					break;
				case FormMain.CompatibilityLevel.LOW:
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ❌ KOMPATIBILITAS RENDAH - Restore berisiko\n", DateTime.Now));
					result = false;
					break;
				case FormMain.CompatibilityLevel.CRITICAL:
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udeab KOMPATIBILITAS KRITIS - JANGAN lanjutkan\n", DateTime.Now));
					result = false;
					break;
				default:
					result = false;
					break;
				}
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Error verifikasi kompatibilitas Panel3: {1}\n", DateTime.Now, ex.Message));
				result = false;
			}
			return result;
		}

		// Token: 0x060000E8 RID: 232 RVA: 0x00020664 File Offset: 0x00020664
		private void SavePanel3InfoToLog(string ecuId, string partCode, string backupFilePath)
		{
			try
			{
				string text = Path.Combine(Application.StartupPath, "Logs", "Panel3");
				Directory.CreateDirectory(text);
				using (StreamWriter streamWriter = new StreamWriter(Path.Combine(text, string.Format("Panel3_Restore_{0:yyyyMMdd}.log", DateTime.Now)), true))
				{
					streamWriter.WriteLine(string.Format("[{0:yyyy-MM-dd HH:mm:ss}] PANEL3 DATA USED FOR RESTORE", DateTime.Now));
					streamWriter.WriteLine("  ECU ID: " + ecuId);
					streamWriter.WriteLine("  Part Code: " + partCode);
					streamWriter.WriteLine("  Backup File: " + Path.GetFileName(backupFilePath));
					streamWriter.WriteLine("  User: " + Environment.UserName);
					streamWriter.WriteLine("  Machine: " + Environment.MachineName);
					streamWriter.WriteLine("---");
				}
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udcbe Data Panel3 disimpan ke log\n", DateTime.Now));
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Gagal menyimpan log Panel3: {1}\n", DateTime.Now, ex.Message));
			}
		}

		// Token: 0x060000E9 RID: 233 RVA: 0x000207A4 File Offset: 0x000207A4
		private void UpdateUIFromMotorBackup(FormMain.MotorBackupMetadata metadata, string panel3EcuId, string panel3PartCode)
		{
			try
			{
				if (!string.IsNullOrEmpty(panel3EcuId) && panel3EcuId != "N/A")
				{
					this.TxtEcmId.Text = panel3EcuId;
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udda5️ Update ECU ID dari Panel3: {1}\n", DateTime.Now, panel3EcuId));
				}
				else if (!string.IsNullOrEmpty(metadata.MotorModel) && metadata.MotorModel != "N/A")
				{
					this.TxtEcmId.Text = metadata.MotorModel;
				}
				if (!string.IsNullOrEmpty(panel3PartCode) && panel3PartCode != "N/A")
				{
					this.TxtPartCode.Text = panel3PartCode;
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udda5️ Update Part Code dari Panel3: {1}\n", DateTime.Now, panel3PartCode));
				}
				else if (!string.IsNullOrEmpty(metadata.ECUCode) && metadata.ECUCode != "N/A")
				{
					this.TxtPartCode.Text = metadata.ECUCode;
				}
				if (metadata.EngineCC > 0)
				{
					Control[] array = base.Controls.Find("TxtEngineCC", true);
					TextBox textBox;
					if (array.Length != 0 && (textBox = (array[0] as TextBox)) != null)
					{
						textBox.Text = metadata.EngineCC.ToString();
					}
				}
				int num;
				if (int.TryParse(this.TxtFlashCount.Text, out num))
				{
					this.TxtFlashCount.Text = (checked(num + 1)).ToString();
				}
				else
				{
					this.TxtFlashCount.Text = "1";
				}
				this.TxtPb.Text = "Status: Restore motor berhasil";
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83c\udfcd️ Data motor telah diupdate di UI\n", DateTime.Now));
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Error update UI motor: {1}\n", DateTime.Now, ex.Message));
			}
		}

		// Token: 0x060000EA RID: 234 RVA: 0x0002098C File Offset: 0x0002098C
		private void LogMotorRestoreCompletion(string backupFilePath, FormMain.MotorBackupMetadata metadata, string panel3EcuId, string panel3PartCode)
		{
			try
			{
				string text = Path.Combine(Application.StartupPath, "Logs", "Motor", "Restore");
				Directory.CreateDirectory(text);
				using (StreamWriter streamWriter = new StreamWriter(Path.Combine(text, string.Format("MotorRestore_{0:yyyyMMdd}.log", DateTime.Now)), true))
				{
					streamWriter.WriteLine(string.Format("[{0:yyyy-MM-dd HH:mm:ss}] MOTOR RESTORE COMPLETED WITH PANEL3 DATA", DateTime.Now));
					streamWriter.WriteLine("  Model: " + metadata.MotorModel);
					streamWriter.WriteLine("  ECU Code: " + metadata.ECUCode);
					streamWriter.WriteLine("  Year: " + metadata.Year);
					streamWriter.WriteLine(string.Format("  Engine: {0}cc", metadata.EngineCC));
					streamWriter.WriteLine("  Panel3 ECU ID: " + panel3EcuId);
					streamWriter.WriteLine("  Panel3 Part Code: " + panel3PartCode);
					streamWriter.WriteLine("  File: " + Path.GetFileName(backupFilePath));
					streamWriter.WriteLine(string.Format("  Size: {0} bytes", metadata.FileSize));
					streamWriter.WriteLine("  Result: SUCCESS");
					streamWriter.WriteLine("======================================");
				}
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ======================================\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83c\udfcd️ MOTOR RESTORE SUMMARY\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Model: {1}\n", DateTime.Now, metadata.MotorModel));
				if (metadata.ECUCode != "N/A")
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   ECU Code: {1}\n", DateTime.Now, metadata.ECUCode));
				}
				if (metadata.Year != "N/A")
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Tahun: {1}\n", DateTime.Now, metadata.Year));
				}
				if (metadata.EngineCC > 0)
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Kapasitas: {1}cc\n", DateTime.Now, metadata.EngineCC));
				}
				if (!string.IsNullOrEmpty(panel3EcuId) && panel3EcuId != "N/A")
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   ECU ID Panel3: {1}\n", DateTime.Now, panel3EcuId));
				}
				if (!string.IsNullOrEmpty(panel3PartCode) && panel3PartCode != "N/A")
				{
					this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Part Code Panel3: {1}\n", DateTime.Now, panel3PartCode));
				}
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   File: {1}\n", DateTime.Now, Path.GetFileName(backupFilePath)));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Ukuran: {1} bytes\n", DateTime.Now, metadata.FileSize));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}]   Status: BERHASIL\n", DateTime.Now));
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ======================================\n", DateTime.Now));
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Error logging: {1}\n", DateTime.Now, ex.Message));
			}
		}

		// Token: 0x17000001 RID: 1
		// (get) Token: 0x060000EB RID: 235 RVA: 0x00002C03 File Offset: 0x00002C03
		// (set) Token: 0x060000EC RID: 236 RVA: 0x00002C0B File Offset: 0x00002C0B
		public string MotorModel { get; set; }

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x060000ED RID: 237 RVA: 0x00002C14 File Offset: 0x00002C14
		// (set) Token: 0x060000EE RID: 238 RVA: 0x00002C1C File Offset: 0x00002C1C
		public string ECUCode { get; set; }

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x060000EF RID: 239 RVA: 0x00002C25 File Offset: 0x00002C25
		// (set) Token: 0x060000F0 RID: 240 RVA: 0x00002C2D File Offset: 0x00002C2D
		public string Year { get; set; }

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x060000F1 RID: 241 RVA: 0x00002C36 File Offset: 0x00002C36
		// (set) Token: 0x060000F2 RID: 242 RVA: 0x00002C3E File Offset: 0x00002C3E
		public int EngineCC { get; set; }

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x060000F3 RID: 243 RVA: 0x00002C47 File Offset: 0x00002C47
		// (set) Token: 0x060000F4 RID: 244 RVA: 0x00002C4F File Offset: 0x00002C4F
		public string FuelType { get; set; }

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x060000F5 RID: 245 RVA: 0x00002C58 File Offset: 0x00002C58
		// (set) Token: 0x060000F6 RID: 246 RVA: 0x00002C60 File Offset: 0x00002C60
		public long FileSize { get; set; }

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x060000F7 RID: 247 RVA: 0x00002C69 File Offset: 0x00002C69
		// (set) Token: 0x060000F8 RID: 248 RVA: 0x00002C71 File Offset: 0x00002C71
		public DateTime BackupDate { get; set; }

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x060000F9 RID: 249 RVA: 0x00002C7A File Offset: 0x00002C7A
		// (set) Token: 0x060000FA RID: 250 RVA: 0x00002C82 File Offset: 0x00002C82
		public string FileType { get; set; }

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x060000FB RID: 251 RVA: 0x00002C8B File Offset: 0x00002C8B
		// (set) Token: 0x060000FC RID: 252 RVA: 0x00002C93 File Offset: 0x00002C93
		public string Checksum { get; set; }

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x060000FD RID: 253 RVA: 0x00002C9C File Offset: 0x00002C9C
		// (set) Token: 0x060000FE RID: 254 RVA: 0x00002CA4 File Offset: 0x00002CA4
		public string SoftwareVersion { get; set; }

		// Token: 0x060000FF RID: 255 RVA: 0x00020D24 File Offset: 0x00020D24
		private string ExtractMotorModelFromPanel3(string partCode, string ecuId)
		{
			string result;
			try
			{
				if (!string.IsNullOrEmpty(partCode))
				{
					if (partCode.ToUpper().Contains("BEAT"))
					{
						return "HONDA BEAT";
					}
					if (partCode.ToUpper().Contains("VARIO"))
					{
						return "HONDA VARIO";
					}
					if (partCode.ToUpper().Contains("SCOOPY"))
					{
						return "HONDA SCOOPY";
					}
					if (partCode.ToUpper().Contains("PCX"))
					{
						return "HONDA PCX";
					}
					if (partCode.ToUpper().Contains("CBR150"))
					{
						return "HONDA CBR150R";
					}
					if (partCode.ToUpper().Contains("CB150"))
					{
						return "HONDA CB150R";
					}
				}
				if (!string.IsNullOrEmpty(ecuId))
				{
					if (ecuId.StartsWith("0102E30F"))
					{
						return "HONDA BEAT 110";
					}
					if (ecuId.StartsWith("0102E31F"))
					{
						return "HONDA VARIO 125";
					}
					if (ecuId.StartsWith("0102E32F"))
					{
						return "HONDA PCX150";
					}
					if (ecuId.StartsWith("0102E33F"))
					{
						return "HONDA CBR150R";
					}
				}
				result = "UNKNOWN";
			}
			catch
			{
				result = "UNKNOWN";
			}
			return result;
		}

		// Token: 0x06000100 RID: 256 RVA: 0x00020E74 File Offset: 0x00020E74
		private string ExtractEngineCCFromPanel3(string partCode)
		{
			string result;
			try
			{
				if (!string.IsNullOrEmpty(partCode))
				{
					if (partCode.Contains("110"))
					{
						return "110";
					}
					if (partCode.Contains("125"))
					{
						return "125";
					}
					if (partCode.Contains("150"))
					{
						return "150";
					}
					if (partCode.Contains("250"))
					{
						return "250";
					}
				}
				result = "";
			}
			catch
			{
				result = "";
			}
			return result;
		}

		// Token: 0x06000101 RID: 257 RVA: 0x00020F00 File Offset: 0x00020F00
		private string ExtractECUTypeFromPanel3(string ecuId)
		{
			string result;
			try
			{
				if (string.IsNullOrEmpty(ecuId) || ecuId == "N/A")
				{
					result = "UNKNOWN";
				}
				else if (ecuId.Length == 10)
				{
					result = ecuId;
				}
				else
				{
					result = "UNKNOWN";
				}
			}
			catch
			{
				result = "UNKNOWN";
			}
			return result;
		}

		// Token: 0x06000102 RID: 258 RVA: 0x00020F5C File Offset: 0x00020F5C
		private bool CheckFileSizeCompatibility(long fileSize, string motorModel)
		{
			foreach (KeyValuePair<long, string[]> keyValuePair in new Dictionary<long, string[]>
			{
				{
					32768L,
					new string[]
					{
						"BEAT",
						"SCOOPY",
						"SUPRA"
					}
				},
				{
					65536L,
					new string[]
					{
						"VARIO 110",
						"VARIO 125"
					}
				},
				{
					131072L,
					new string[]
					{
						"PCX150",
						"VARIO150"
					}
				},
				{
					262144L,
					new string[]
					{
						"CBR150R",
						"CB150R",
						"CRF150L"
					}
				}
			})
			{
				if (fileSize == keyValuePair.Key)
				{
					foreach (string text in keyValuePair.Value)
					{
						if (motorModel.ToUpper().Contains(text.ToUpper()))
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		// Token: 0x06000103 RID: 259 RVA: 0x00021088 File Offset: 0x00021088
		private string DetermineFuelTypeFromModel(string model)
		{
			if (string.IsNullOrEmpty(model))
			{
				return "";
			}
			if (model.ToUpper().Contains("BEAT") && model.Contains("110"))
			{
				return "PGM-FI or CARB";
			}
			if (model.ToUpper().Contains("CBR150R") || model.ToUpper().Contains("PCX"))
			{
				return "PGM-FI";
			}
			return "";
		}

		// Token: 0x06000104 RID: 260 RVA: 0x000210F8 File Offset: 0x000210F8
		private string DetermineFuelTypeFromPanel3(string partCode, string ecuId)
		{
			if (!string.IsNullOrEmpty(partCode))
			{
				if (partCode.ToUpper().Contains("ESP"))
				{
					return "PGM-FI";
				}
				if (partCode.ToUpper().Contains("KARBU") || partCode.ToUpper().Contains("CARB"))
				{
					return "CARB";
				}
			}
			if (!string.IsNullOrEmpty(ecuId) && (ecuId.StartsWith("0102E30F01") || ecuId.StartsWith("0102E31F")))
			{
				return "PGM-FI";
			}
			return "";
		}

		// Token: 0x06000105 RID: 261 RVA: 0x0002117C File Offset: 0x0002117C
		private FormMain.CompatibilityLevel DetermineCompatibilityLevel(FormMain.MotorBackupMetadata metadata, string panel3Model, string panel3CC, string panel3ECUType)
		{
			int num = 0;
			checked
			{
				if (!string.IsNullOrEmpty(panel3Model) && !string.IsNullOrEmpty(metadata.MotorModel) && (panel3Model.ToUpper().Contains(metadata.MotorModel.ToUpper()) || metadata.MotorModel.ToUpper().Contains(panel3Model.ToUpper())))
				{
					num += 20;
				}
				int num2;
				if (metadata.EngineCC > 0 && !string.IsNullOrEmpty(panel3CC) && int.TryParse(panel3CC, out num2))
				{
					if (metadata.EngineCC == num2)
					{
						num += 30;
					}
					else if (Math.Abs(metadata.EngineCC - num2) <= 25)
					{
						num += 15;
					}
				}
				if (this.CheckFileSizeCompatibility(metadata.FileSize, panel3Model))
				{
					num += 25;
				}
				if (!string.IsNullOrEmpty(panel3ECUType) && panel3ECUType != "UNKNOWN" && ((panel3ECUType.StartsWith("0102E30F") && panel3Model.Contains("BEAT")) || (panel3ECUType.StartsWith("0102E33F") && panel3Model.Contains("CBR150R"))))
				{
					num += 25;
				}
				if (num >= 80)
				{
					return FormMain.CompatibilityLevel.HIGH;
				}
				if (num >= 50)
				{
					return FormMain.CompatibilityLevel.MEDIUM;
				}
				if (num >= 20)
				{
					return FormMain.CompatibilityLevel.LOW;
				}
				return FormMain.CompatibilityLevel.CRITICAL;
			}
		}

		// Token: 0x06000106 RID: 262 RVA: 0x00021294 File Offset: 0x00021294
		private bool AskUserForMediumCompatibility(FormMain.MotorBackupMetadata metadata, string panel3Model)
		{
			return CustomMessageBox__1.Show("⚠️ PERINGATAN: KOMPATIBILITAS SEDANG\n\n" + "Data backup mungkin tidak sepenuhnya kompatibel dengan ECU motor Anda.\n\n" + "Model dari Panel3: " + panel3Model + "\n" + "Model dari Backup: " + metadata.MotorModel + "\n" + string.Format("CC dari Backup: {0}cc\n\n", metadata.EngineCC) + "RISIKO:\n" + "• ECU mungkin tidak berfungsi optimal\n" + "• Performa motor bisa menurun\n" + "• Kemungkinan error code muncul\n\n" + "Apakah Anda tetap ingin melanjutkan restore?", "Peringatan Kompatibilitas Sedang", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes;
		}

		// Token: 0x06000107 RID: 263 RVA: 0x00021334 File Offset: 0x00021334
		private string GetCompatibilityDetails(FormMain.MotorBackupMetadata metadata, string ecuId, string partCode)
		{
			string text = "";
			string text2 = this.ExtractMotorModelFromPanel3(partCode, ecuId);
			text = text + "Model Panel3: " + text2 + "\n";
			text = text + "Model Backup: " + metadata.MotorModel + "\n";
			string text3 = this.ExtractEngineCCFromPanel3(partCode);
			if (metadata.EngineCC > 0 && !string.IsNullOrEmpty(text3))
			{
				text = text + "CC Panel3: " + text3 + "cc\n";
				text += string.Format("CC Backup: {0}cc\n", metadata.EngineCC);
				int num;
				if (int.TryParse(text3, out num) && metadata.EngineCC != num)
				{
					text += string.Format("❌ CC TIDAK COCOK: Selisih {0}cc\n", Math.Abs(checked(metadata.EngineCC - num)));
				}
			}
			bool flag = this.CheckFileSizeCompatibility(metadata.FileSize, text2);
			text += string.Format("Ukuran File: {0}KB - {1}\n", metadata.FileSize / 1024L, flag ? "✅ OK" : "❌ Tidak sesuai");
			string text4 = this.DetermineFuelTypeFromModel(metadata.MotorModel);
			string text5 = this.DetermineFuelTypeFromPanel3(partCode, ecuId);
			if (!string.IsNullOrEmpty(text4) && !string.IsNullOrEmpty(text5))
			{
				text = text + "Bahan Bakar Panel3: " + text5 + "\n";
				text = text + "Bahan Bakar Backup: " + text4 + "\n";
				if (text4 != text5)
				{
					text += "❌ TIPE BAHAN BAKAR BERBEDA\n";
				}
			}
			return text;
		}

		// Token: 0x06000108 RID: 264 RVA: 0x00002CAD File Offset: 0x00002CAD
		private void InitializeFormAppearance()
		{
			this.ApplyRoundedCorners(this, 15);
		}

		// Token: 0x06000109 RID: 265 RVA: 0x00002CB8 File Offset: 0x00002CB8
		private void FormMain_Resize(object sender, EventArgs e)
		{
			this.InitializeFormAppearance();
		}

		// Token: 0x0600010A RID: 266 RVA: 0x000214A0 File Offset: 0x000214A0
		private void ShowAboutDialog()
		{
			Form aboutForm = new Form();
			aboutForm.FormBorderStyle = FormBorderStyle.None;
			aboutForm.StartPosition = FormStartPosition.CenterScreen;
			aboutForm.BackColor = Color.FromArgb(45, 45, 65);
			aboutForm.MaximizeBox = false;
			aboutForm.MinimizeBox = false;
			aboutForm.Text = "Tentang Aplikasi";
			aboutForm.Width = 330;
			aboutForm.Height = 190;
			aboutForm.TopMost = true;
			this.ApplyRoundedCorners(aboutForm, 10);
			int all = 5;
			Panel borderPanel = new Panel
			{
				Dock = DockStyle.Fill,
				Padding = new Padding(all),
				BackColor = Color.FromArgb(45, 50, 65)
			};
			borderPanel.Paint += delegate(object s, PaintEventArgs ev)
			{
				this.DrawCustomBorder(ev.Graphics, borderPanel);
			};
			borderPanel.Resize += delegate(object s, EventArgs ev)
			{
				borderPanel.Invalidate();
			};
			aboutForm.Controls.Add(borderPanel);
			PictureBox pictureBox = new PictureBox();
			Icon icon = base.Icon;
			pictureBox.Image = (((icon != null) ? icon.ToBitmap() : null) ?? SystemIcons.Information.ToBitmap());
			pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
			pictureBox.Location = new Point(10, 30);
			pictureBox.Size = new Size(100, 100);
			PictureBox value = pictureBox;
			borderPanel.Controls.Add(value);
			Label value2 = new Label
			{
				Text = "ꦲꦺꦴꦤ꧀ꦢ ꦗꦮ ꦠꦺꦕ꧀",
				Font = new Font("Impact", 16f, FontStyle.Italic),
				ForeColor = Color.FromArgb(255, 215, 0),
				AutoSize = true,
				Location = new Point(120, 10)
			};
			borderPanel.Controls.Add(value2);
			Label value3 = new Label
			{
				Text = "HONDA FLASH ELEGANT",
				Font = new Font("Segoe UI", 10f, FontStyle.Bold),
				ForeColor = Color.Silver,
				Location = new Point(120, 40),
				AutoSize = true
			};
			borderPanel.Controls.Add(value3);
			Label value4 = new Label
			{
				Text = "Version 0.2.0.2.6",
				Font = new Font("Segoe UI", 9f),
				ForeColor = Color.Silver,
				Location = new Point(120, 65),
				AutoSize = true
			};
			borderPanel.Controls.Add(value4);
			Label value5 = new Label
			{
				Text = "Copyright (c) 2025",
				Font = new Font("Segoe UI", 9f),
				ForeColor = Color.Silver,
				Location = new Point(120, 85),
				AutoSize = true
			};
			borderPanel.Controls.Add(value5);
			Button button = new Button
			{
				Text = "OK",
				Location = new Point(140, 105),
				Size = new Size(110, 30),
				BackColor = Color.FromArgb(45, 50, 65),
				ForeColor = Color.FromArgb(255, 215, 0),
				FlatStyle = FlatStyle.Flat,
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				UseVisualStyleBackColor = false
			};
			button.FlatAppearance.BorderSize = 1;
			button.FlatAppearance.BorderColor = Color.FromArgb(255, 215, 0);
			button.Click += delegate(object s, EventArgs ev)
			{
				aboutForm.Close();
			};
			borderPanel.Controls.Add(button);
			aboutForm.ShowDialog(this);
		}

		// Token: 0x0600010B RID: 267 RVA: 0x00021878 File Offset: 0x00021878
		private void DrawCustomBorder(Graphics g, Panel panel)
		{
			checked
			{
				Rectangle rect = new Rectangle(0, 0, panel.Width - 1, panel.Height - 1);
				using (Pen pen = new Pen(Color.FromArgb(255, 215, 0), 2f))
				{
					g.DrawRectangle(pen, rect);
				}
				Rectangle rect2 = new Rectangle(2, 2, panel.Width - 5, panel.Height - 5);
				using (Pen pen2 = new Pen(Color.FromArgb(200, 170, 0), 1f))
				{
					g.DrawRectangle(pen2, rect2);
				}
			}
		}

		// Token: 0x0600010C RID: 268 RVA: 0x00021934 File Offset: 0x00021934
		private void ApplyRoundedCorners(Form form, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			Rectangle rectangle = new Rectangle(0, 0, form.Width, form.Height);
			graphicsPath.AddArc(rectangle.X, rectangle.Y, radius, radius, 180f, 90f);
			checked
			{
				graphicsPath.AddArc(rectangle.Right - radius, rectangle.Y, radius, radius, 270f, 90f);
				graphicsPath.AddArc(rectangle.Right - radius, rectangle.Bottom - radius, radius, radius, 0f, 90f);
				graphicsPath.AddArc(rectangle.X, rectangle.Bottom - radius, radius, radius, 90f, 90f);
				graphicsPath.CloseFigure();
				form.Region = new Region(graphicsPath);
			}
		}

		// Token: 0x0600010D RID: 269 RVA: 0x000219F8 File Offset: 0x000219F8
		private void LogToRbtLog(string message)
		{
			try
			{
				string path = Path.Combine(Application.StartupPath, "rbtlog.txt");
				string text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
				File.AppendAllText(path, string.Concat(new string[]
				{
					"[",
					text,
					"] ",
					message,
					Environment.NewLine
				}));
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x0600010E RID: 270 RVA: 0x00021A6C File Offset: 0x00021A6C
		private void InitializeLogging()
		{
			try
			{
				string text = Path.Combine(Application.StartupPath, "Logs");
				if (!Directory.Exists(text))
				{
					Directory.CreateDirectory(text);
				}
				this.logFilePath = Path.Combine(text, string.Format("log_{0:yyyyMMdd}.txt", DateTime.Now));
				this.logWriter = new StreamWriter(this.logFilePath, true);
				this.logWriter.AutoFlush = true;
			}
			catch (Exception ex)
			{
				MessageBox.Show("Gagal menginisialisasi log: " + ex.Message, "Logging Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x0600010F RID: 271 RVA: 0x00021B0C File Offset: 0x00021B0C
		private void LogByteArray(string description, byte[] data, int length = -1)
		{
			if (length == -1)
			{
				length = data.Length;
			}
			string str = BitConverter.ToString(data, 0, length).Replace("-", " ");
			this.LogMessage(description + ": " + str);
		}

		// Token: 0x06000110 RID: 272 RVA: 0x00021B4C File Offset: 0x00021B4C
		private void CloseLogging()
		{
			try
			{
				object logLock = this._logLock;
				lock (logLock)
				{
					if (this._logWriter != null)
					{
						this.LogMessage("Logging system closing");
						this._logWriter.Close();
						this._logWriter = null;
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error closing log: " + ex.Message);
			}
		}

		// Token: 0x06000113 RID: 275 RVA: 0x00002CC0 File Offset: 0x00002CC0
		private void RtbLog_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Control && (e.KeyCode == Keys.C || e.KeyCode == Keys.A || e.KeyCode == Keys.V))
			{
				e.Handled = true;
				e.SuppressKeyPress = true;
			}
		}

		// Token: 0x06000114 RID: 276 RVA: 0x00021DAC File Offset: 0x00021DAC
		private void RtbLog_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				base.ActiveControl = null;
			}
			Panel panel = new Panel();
			panel.BackColor = Color.FromArgb(40, 40, 50);
			panel.BorderStyle = BorderStyle.FixedSingle;
			panel.Location = new Point(30, 30);
			panel.Size = new Size(720, 80);
			panel.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			base.Controls.Add(panel);
			Label label = new Label();
			label.Text = "HONDA ECU FLASH TOOLS";
			label.Font = new Font("Impact", 18f, FontStyle.Italic);
			label.ForeColor = Color.Gold;
			label.AutoSize = true;
			label.Location = new Point(10, 10);
			panel.Controls.Add(label);
			this.LblConnection.Text = "Connection:";
			this.LblConnection.Font = new Font("Tahoma", 8f);
			this.LblConnection.ForeColor = Color.Gold;
			this.LblConnection.Location = new Point(10, 50);
			this.LblConnection.AutoSize = true;
			panel.Controls.Add(this.LblConnection);
			this.TxtConnStat.Text = "Disconnected";
			this.TxtConnStat.Font = new Font("Tahoma", 8f);
			this.TxtConnStat.ForeColor = Color.Red;
			this.TxtConnStat.Location = new Point(80, 50);
			this.TxtConnStat.AutoSize = true;
			panel.Controls.Add(this.TxtConnStat);
			this.LblFlashCount.Text = "Flash Count:";
			this.LblFlashCount.Font = new Font("Tahoma", 8f);
			this.LblFlashCount.ForeColor = Color.Gold;
			this.LblFlashCount.Location = new Point(180, 50);
			this.LblFlashCount.AutoSize = true;
			panel.Controls.Add(this.LblFlashCount);
			this.TxtFlashCount.Text = "0";
			this.TxtFlashCount.Font = new Font("Tahoma", 8f);
			this.TxtFlashCount.ForeColor = Color.White;
			this.TxtFlashCount.Location = new Point(250, 50);
			this.TxtFlashCount.AutoSize = true;
			panel.Controls.Add(this.TxtFlashCount);
			this.LblEcmId.Text = "ECM ID:";
			this.LblEcmId.Font = new Font("Tahoma", 8f);
			this.LblEcmId.ForeColor = Color.Gold;
			this.LblEcmId.Location = new Point(300, 50);
			this.LblEcmId.AutoSize = true;
			panel.Controls.Add(this.LblEcmId);
			this.TxtEcmId.Text = "N/A";
			this.TxtEcmId.Font = new Font("Tahoma", 8f);
			this.TxtEcmId.ForeColor = Color.White;
			this.TxtEcmId.Location = new Point(350, 50);
			this.TxtEcmId.AutoSize = true;
			panel.Controls.Add(this.TxtEcmId);
			this.LblPartCode.Text = "Part Code:";
			this.LblPartCode.Font = new Font("Tahoma", 8f);
			this.LblPartCode.ForeColor = Color.Gold;
			this.LblPartCode.Location = new Point(450, 50);
			this.LblPartCode.AutoSize = true;
			panel.Controls.Add(this.LblPartCode);
			this.TxtPartCode.Text = "N/A";
			this.TxtPartCode.Font = new Font("Tahoma", 8f);
			this.TxtPartCode.ForeColor = Color.White;
			this.TxtPartCode.Location = new Point(520, 50);
			this.TxtPartCode.AutoSize = true;
			panel.Controls.Add(this.TxtPartCode);
			this.PbProgress.Location = new Point(30, 535);
			this.PbProgress.Size = new Size(720, 20);
			this.PbProgress.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
			this.PbProgress.BackColor = Color.FromArgb(60, 65, 80);
			this.PbProgress.ForeColor = Color.FromArgb(255, 215, 0);
			this.PbProgress.Maximum = 10000;
			this.PbProgress.Step = 1;
			base.Controls.Add(this.PbProgress);
			this.TxtPb.Text = "Status: Ready";
			this.TxtPb.Font = new Font("Arial", 9f);
			this.TxtPb.ForeColor = Color.Gold;
			this.TxtPb.Location = new Point(30, 560);
			this.TxtPb.Size = new Size(720, 20);
			this.TxtPb.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.TxtPb.TextAlign = ContentAlignment.MiddleCenter;
			base.Controls.Add(this.TxtPb);
			this.GbEcuInfo.Visible = false;
			this.groupBox1.Visible = false;
			this.button1.Click += this.button1_Click;
			this.BtnWrite.Click += this.Write_Clicked;
			this.TbFileName.TextChanged += this.FileName_Changed;
			this.CbFastWrite.CheckedChanged += this.CbFastWrite_CheckedChanged;
			this.TbStartOffset.TextChanged += this.StartOffset_Changed;
			this.TbChecksumOffset.TextChanged += this.ChecksumOffset_Changed;
			this.PbProgress.Click += this.PbProgress_Click;
			base.FormClosing += this.MainForm_Closing;
			base.Load += this.MainForm_Load;
			base.Paint += this.DrawGoldBorder;
			this.GbEcuInfo.Paint += this.GbEcuInfo_Paint;
			this.groupBox1.Paint += this.GroupBox1_Paint;
			this.GbEcuInfo.ResumeLayout(false);
			this.GbEcuInfo.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = 10;
			graphicsPath.AddArc(0, 0, num, num, 180f, 90f);
			checked
			{
				graphicsPath.AddArc(base.Width - num, 0, num, num, 270f, 90f);
				graphicsPath.AddArc(base.Width - num, base.Height - num, num, num, 0f, 90f);
				graphicsPath.AddArc(0, base.Height - num, num, num, 90f, 90f);
				graphicsPath.CloseAllFigures();
				base.Region = new Region(graphicsPath);
			}
		}

		// Token: 0x06000115 RID: 277 RVA: 0x000224E0 File Offset: 0x000224E0
		private void InitializeSimpleLogging()
		{
			checked
			{
				try
				{
					foreach (string text in new string[]
					{
						Path.Combine(Path.GetTempPath(), "HondaFlashTools"),
						Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HondaFlashTools"),
						Directory.GetCurrentDirectory()
					})
					{
						try
						{
							if (!Directory.Exists(text))
							{
								Directory.CreateDirectory(text);
							}
							string path = Path.Combine(text, string.Format("log_{0:yyyyMMdd}.txt", DateTime.Now));
							for (int j = 0; j < 3; j++)
							{
								try
								{
									this.logWriter = new StreamWriter(path, true)
									{
										AutoFlush = true
									};
									this.logWriter.WriteLine(string.Format("=== Log started at {0} ===", DateTime.Now));
									return;
								}
								catch (IOException)
								{
									Thread.Sleep(100);
									if (j == 2)
									{
										path = Path.Combine(text, string.Format("log_{0:yyyyMMdd_HHmmss}.txt", DateTime.Now));
										this.logWriter = new StreamWriter(path, true)
										{
											AutoFlush = true
										};
										this.logWriter.WriteLine(string.Format("=== Log started at {0} ===", DateTime.Now));
										return;
									}
								}
							}
						}
						catch
						{
						}
					}
					this.logWriter = null;
				}
				catch
				{
					this.logWriter = null;
				}
			}
		}

		// Token: 0x06000116 RID: 278 RVA: 0x00022678 File Offset: 0x00022678
		private void CloseSimpleLogging()
		{
			try
			{
				if (this.logWriter != null)
				{
					this.logWriter.WriteLine(string.Format("=== Log ended at {0} ===", DateTime.Now));
					this.logWriter.Close();
					this.logWriter = null;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000117 RID: 279 RVA: 0x000226D4 File Offset: 0x000226D4
		private void InvokeIfRequired(Action action)
		{
			try
			{
				if (base.InvokeRequired)
				{
					base.Invoke(action);
				}
				else
				{
					action();
				}
			}
			catch (ObjectDisposedException)
			{
			}
			catch (InvalidOperationException)
			{
			}
		}

		// Token: 0x06000118 RID: 280 RVA: 0x000026F4 File Offset: 0x000026F4
		public static void FT_Close(IntPtr handle)
		{
		}

		// Token: 0x06000119 RID: 281 RVA: 0x00022720 File Offset: 0x00022720
		private void ApplyRoundedForm()
		{
			try
			{
				if (base.Width > 0 && base.Height > 0)
				{
					int num = 18;
					GraphicsPath graphicsPath = new GraphicsPath();
					int width = base.Width;
					int height = base.Height;
					int num2 = num * 2;
					graphicsPath.StartFigure();
					graphicsPath.AddArc(0, 0, num2, num2, 180f, 90f);
					graphicsPath.AddArc(width - num2, 0, num2, num2, 270f, 90f);
					graphicsPath.AddArc(width - num2, height - num2, num2, num2, 0f, 90f);
					graphicsPath.AddArc(0, height - num2, num2, num2, 90f, 90f);
					graphicsPath.CloseFigure();
					Region region = base.Region;
					base.Region = new Region(graphicsPath);
					if (region != null)
					{
						region.Dispose();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600011A RID: 282 RVA: 0x000227F8 File Offset: 0x000227F8
		private GraphicsPath CreateRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = radius * 2;
			graphicsPath.StartFigure();
			graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x0600011B RID: 283 RVA: 0x000228A4 File Offset: 0x000228A4
		private void DrawNeonBorder(object sender, PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			Color color = Color.FromArgb(0, 255, 230);
			Color color2 = Color.FromArgb(255, 0, 255);
			Rectangle rect = new Rectangle(1, 1, base.ClientSize.Width - 3, base.ClientSize.Height - 3);
			Rectangle rect2 = new Rectangle(7, 7, base.ClientSize.Width - 15, base.ClientSize.Height - 15);
			int num = 14;
			using (Pen pen = new Pen(color, 1.4f))
			{
				this.DrawRoundedRect(graphics, pen, rect, num);
			}
			using (Pen pen2 = new Pen(color, 2f))
			{
				this.DrawRoundedRect(graphics, pen2, rect2, num - 2);
			}
			using (new Pen(color2, 2.2f))
			{
			}
		}

		// Token: 0x0600011C RID: 284 RVA: 0x000229D4 File Offset: 0x000229D4
		private void TitleBar_MouseDown(object sender, MouseEventArgs e)
		{
			try
			{
				if (e.Button == MouseButtons.Left)
				{
					FormMain.ReleaseCapture();
					FormMain.SendMessage(base.Handle, 161, new IntPtr(2), IntPtr.Zero);
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600011D RID: 285
		[DllImport("user32.dll")]
		private static extern bool ReleaseCapture();

		// Token: 0x0600011E RID: 286
		[DllImport("user32.dll")]
		private static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

		// Token: 0x0600011F RID: 287 RVA: 0x00022A28 File Offset: 0x00022A28
		private void EcuSetStatus(string text, Color color)
		{
			if (base.IsDisposed)
			{
				return;
			}
			if (base.InvokeRequired)
			{
				try
				{
					base.BeginInvoke(new Action(delegate()
					{
						this.EcuSetStatus(text, color);
					}));
				}
				catch
				{
				}
				return;
			}
			if (this.TxtConnStat != null)
			{
				this.TxtConnStat.Text = text;
				this.TxtConnStat.ForeColor = color;
			}
		}

		// Token: 0x06000120 RID: 288 RVA: 0x00022AB4 File Offset: 0x00022AB4
		private void EcuSetSystemStatus(string text, Color color)
		{
			if (base.IsDisposed)
			{
				return;
			}
			if (base.InvokeRequired)
			{
				try
				{
					base.BeginInvoke(new Action(delegate()
					{
						this.EcuSetSystemStatus(text, color);
					}));
				}
				catch
				{
				}
				return;
			}
			this.TxtPb.Text = text;
			this.TxtPb.ForeColor = color;
		}

		// Token: 0x06000121 RID: 289 RVA: 0x00022B38 File Offset: 0x00022B38
		private void EcuLog(string text)
		{
			if (base.IsDisposed)
			{
				return;
			}
			if (base.InvokeRequired)
			{
				try
				{
					base.BeginInvoke(new Action(delegate()
					{
						this.EcuLog(text);
					}));
				}
				catch
				{
				}
				return;
			}
			if (this.RtbLog == null)
			{
				return;
			}
			string str = "[" + DateTime.Now.ToString("HH:mm:ss.fff") + "] " + text;
			this.RtbLog.AppendText(str + Environment.NewLine);
			this.RtbLog.SelectionStart = this.RtbLog.TextLength;
			this.RtbLog.ScrollToCaret();
		}

		// Token: 0x06000122 RID: 290 RVA: 0x00022BFC File Offset: 0x00022BFC
		private void EcuProgress(int value, string status)
		{
			if (base.IsDisposed)
			{
				return;
			}
			if (base.InvokeRequired)
			{
				try
				{
					base.BeginInvoke(new Action(delegate()
					{
						this.EcuProgress(value, status);
					}));
				}
				catch
				{
				}
				return;
			}
			if (value < 0)
			{
				value = 0;
			}
			if (value > 10000)
			{
				value = 10000;
			}
			this.PbProgress.Value = value;
			this.TxtPb.Text = status;
		}

		// Token: 0x06000123 RID: 291 RVA: 0x00022CA8 File Offset: 0x00022CA8
		private string BytesToHex(byte[] data)
		{
			if (data == null || data.Length == 0)
			{
				return "";
			}
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < data.Length; i++)
			{
				if (i > 0)
				{
					stringBuilder.Append(" ");
				}
				stringBuilder.Append(data[i].ToString("X2"));
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06000124 RID: 292 RVA: 0x00022D04 File Offset: 0x00022D04
		private bool IsEcho(byte[] rx, byte[] tx)
		{
			if (rx == null || tx == null)
			{
				return false;
			}
			if (rx.Length != tx.Length)
			{
				return false;
			}
			for (int i = 0; i < tx.Length; i++)
			{
				if (rx[i] != tx[i])
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x06000125 RID: 293 RVA: 0x00022D3C File Offset: 0x00022D3C
		private void ResetEcuDisplay()
		{
			if (base.InvokeRequired)
			{
				try
				{
					base.BeginInvoke(new Action(delegate()
					{
						this.ResetEcuDisplay();
					}));
				}
				catch
				{
				}
				return;
			}
			this.TxtConnStat.Text = "Disconnected";
			this.TxtConnStat.ForeColor = Color.Red;
			this.TxtEcmId.Text = "N/A";
			this.TxtPartCode.Text = "N/A";
			this.TxtFlashCount.Text = "0";
			this.EcuSetSystemStatus("SYSTEM READY  •  WAITING FOR ECU", Color.FromArgb(0, 255, 230));
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00022DE8 File Offset: 0x00022DE8
		private bool OpenEcuInterface()
		{
			object ecuLock = this._ecuLock;
			bool result;
			lock (ecuLock)
			{
				try
				{
					this.EcuLog("Opening FTDI interface...");
					if (!this.IsFtdiEngineAvailable())
					{
						this.EcuLog("FTDI engine belum ditemukan pada FormMain.");
						this.EcuLog("Hubungkan fungsi Class15 / D2XX asli di OpenEcuInterface().");
						result = false;
					}
					else
					{
						result = this.ConfigureExistingFtdi();
					}
				}
				catch (Exception ex)
				{
					this.EcuLog("FTDI OPEN ERROR: " + ex.Message);
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06000127 RID: 295 RVA: 0x00002CF6 File Offset: 0x00002CF6
		private bool IsFtdiEngineAvailable()
		{
			return false;
		}

		// Token: 0x06000128 RID: 296 RVA: 0x00002CF9 File Offset: 0x00002CF9
		private bool ConfigureExistingFtdi()
		{
			this.EcuLog("FTDI configuration requested: 10400 / 8N1 / latency 2ms");
			return false;
		}

		// Token: 0x06000129 RID: 297 RVA: 0x00022E80 File Offset: 0x00022E80
		private bool EcuWakeSequence()
		{
			this.EcuLog("K-LINE WAKE START");
			byte[] array = new byte[]
			{
				254,
				4,
				114,
				140
			};
			for (int i = 1; i <= 50; i++)
			{
				if (this._ecuCancellation != null && this._ecuCancellation.IsCancellationRequested)
				{
					throw new OperationCanceledException();
				}
				this.EcuLog("WAKE attempt " + i.ToString() + "/50 : TX " + this.BytesToHex(array));
				byte[] array2 = this.FtdiWriteRead(array);
				if (array2 == null || array2.Length == 0)
				{
					this.EcuLog("WAKE RX : TIMEOUT");
				}
				else
				{
					this.EcuLog("WAKE RX : " + this.BytesToHex(array2));
					if (this.IsEcho(array2, array))
					{
						this.EcuLog("WAKE RX : echo detected - retry");
					}
					else
					{
						if (this.IsValidKlineResponse(array2))
						{
							this.EcuLog("WAKE : VALID RESPONSE");
							return true;
						}
						this.EcuLog("WAKE RX : invalid response - retry");
					}
				}
			}
			return false;
		}

		// Token: 0x0600012A RID: 298 RVA: 0x00022F68 File Offset: 0x00022F68
		private bool EcuInitSequence()
		{
			foreach (byte[] array2 in new byte[][]
			{
				new byte[]
				{
					114,
					5,
					0,
					240,
					153
				},
				new byte[]
				{
					114,
					5,
					113,
					0,
					24
				}
			})
			{
				this.EcuLog("INIT TX : " + this.BytesToHex(array2));
				byte[] array3 = this.FtdiWriteRead(array2);
				if (array3 == null || array3.Length == 0)
				{
					this.EcuLog("INIT RX : TIMEOUT");
				}
				else
				{
					this.EcuLog("INIT RX : " + this.BytesToHex(array3));
					if (this.IsEcho(array3, array2))
					{
						this.EcuLog("INIT RX : echo detected");
					}
					else if (this.IsValidKlineResponse(array3))
					{
						this.EcuLog("INIT : VALID RESPONSE");
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x0600012B RID: 299 RVA: 0x00002D07 File Offset: 0x00002D07
		private bool IsValidKlineResponse(byte[] response)
		{
			return response != null && response.Length != 0;
		}

		// Token: 0x0600012C RID: 300 RVA: 0x00023034 File Offset: 0x00023034
		private string ReadEcmId()
		{
			byte[] array = new byte[]
			{
				114,
				7,
				114,
				0,
				0,
				5,
				16
			};
			this.EcuLog("ECM ID TX : " + this.BytesToHex(array));
			byte[] array2 = this.FtdiWriteRead(array);
			if (array2 == null || array2.Length == 0)
			{
				this.EcuLog("ECM ID RX : TIMEOUT");
				return "";
			}
			this.EcuLog("ECM ID RX : " + this.BytesToHex(array2));
			if (this.IsEcho(array2, array))
			{
				return "";
			}
			return this.BytesToHex(array2);
		}

		// Token: 0x0600012D RID: 301 RVA: 0x00002D13 File Offset: 0x00002D13
		private string ReadPartCode()
		{
			this.EcuLog("PART CODE : meminta data dari ECU...");
			return "";
		}

		// Token: 0x0600012E RID: 302 RVA: 0x00002D25 File Offset: 0x00002D25
		private int ReadFlashCount()
		{
			this.EcuLog("FLASH COUNT : lokasi data belum dipetakan untuk ECU family.");
			return -1;
		}

		// Token: 0x0600012F RID: 303 RVA: 0x000230B8 File Offset: 0x000230B8
		private byte[] FtdiWriteRead(byte[] tx)
		{
			if (tx == null || tx.Length == 0)
			{
				return null;
			}
			object ecuLock = this._ecuLock;
			byte[] result;
			lock (ecuLock)
			{
				this.EcuLog("TX > " + this.BytesToHex(tx));
				result = null;
			}
			return result;
		}

		// Token: 0x06000130 RID: 304 RVA: 0x00023118 File Offset: 0x00023118
		private void CloseEcuInterface()
		{
			object ecuLock = this._ecuLock;
			lock (ecuLock)
			{
				try
				{
					this._ftHandle = IntPtr.Zero;
					this._ecuConnected = false;
					this.EcuLog("FTDI interface closed.");
				}
				catch (Exception ex)
				{
					this.EcuLog("FTDI CLOSE ERROR: " + ex.Message);
				}
			}
		}

		// Token: 0x06000131 RID: 305 RVA: 0x00023194 File Offset: 0x00023194
		private void DisconnectEcuSafe()
		{
			try
			{
				if (this._ecuCancellation != null)
				{
					this._ecuCancellation.Cancel();
					this._ecuCancellation.Dispose();
					this._ecuCancellation = null;
				}
			}
			catch
			{
			}
			try
			{
				this.CloseEcuInterface();
			}
			catch
			{
			}
		}

		// Token: 0x06000133 RID: 307 RVA: 0x000231F4 File Offset: 0x000231F4
		private void DrawRoundedRect(Graphics g, Pen pen, Rectangle rect, int radius)
		{
			using (GraphicsPath graphicsPath = new GraphicsPath())
			{
				int num = radius * 2;
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				g.DrawPath(pen, graphicsPath);
			}
		}

		// Token: 0x06000134 RID: 308 RVA: 0x000232C0 File Offset: 0x000232C0
		private void OpenWithBlur(Form childForm)
		{
			if (childForm == null)
			{
				return;
			}
			if (base.IsDisposed || base.Disposing)
			{
				try
				{
					childForm.Dispose();
				}
				catch
				{
				}
				return;
			}
			if (base.WindowState == FormWindowState.Minimized)
			{
				base.WindowState = FormWindowState.Normal;
			}
			bool topMost = base.TopMost;
			OverlayBlur overlayBlur = null;
			try
			{
				base.TopMost = false;
				overlayBlur = new OverlayBlur(this, 8, true);
				overlayBlur.Show(this);
				overlayBlur.BringToFront();
				overlayBlur.Update();
				childForm.StartPosition = FormStartPosition.CenterParent;
				childForm.Owner = this;
				childForm.TopMost = false;
				childForm.ShowDialog(this);
			}
			catch
			{
			}
			finally
			{
				if (overlayBlur != null)
				{
					try
					{
						if (!overlayBlur.IsDisposed)
						{
							overlayBlur.Hide();
							overlayBlur.Close();
						}
					}
					catch
					{
					}
					try
					{
						overlayBlur.Dispose();
					}
					catch
					{
					}
					overlayBlur = null;
				}
				try
				{
					base.TopMost = topMost;
					if (!base.IsDisposed && !base.Disposing)
					{
						if (base.WindowState == FormWindowState.Minimized)
						{
							base.WindowState = FormWindowState.Normal;
						}
						base.Enabled = true;
						base.BringToFront();
						base.Activate();
						base.Focus();
						base.Invalidate(true);
						base.Update();
						base.Refresh();
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000135 RID: 309 RVA: 0x00023424 File Offset: 0x00023424
		private void ProgressPopupForm_GlobalPopupShown(object sender, EventArgs e)
		{
			try
			{
				if (!base.IsDisposed && !base.Disposing)
				{
					Form form = sender as Form;
					if (form != null && !form.IsDisposed && !form.Disposing)
					{
						form.FormClosed -= this.Popup_FormClosed_RemoveBlur;
						form.FormClosed += this.Popup_FormClosed_RemoveBlur;
						form.Disposed -= this.Popup_Disposed_RemoveBlur;
						form.Disposed += this.Popup_Disposed_RemoveBlur;
						if (this._keihinResetRunning)
						{
							try
							{
								form.TopMost = false;
								form.BringToFront();
								form.Activate();
							}
							catch
							{
							}
						}
						else
						{
							if (base.WindowState == FormWindowState.Minimized)
							{
								base.WindowState = FormWindowState.Normal;
							}
							this.RemoveBlurOverlay();
							try
							{
								this._activeBlurOverlay = new BlurOverlay(this, 8, true);
								if (this._activeBlurOverlay != null && !this._activeBlurOverlay.IsDisposed)
								{
									this._activeBlurOverlay.StartPosition = FormStartPosition.Manual;
									this._activeBlurOverlay.Bounds = base.Bounds;
									this._activeBlurOverlay.Show(this);
								}
							}
							catch
							{
								this.RemoveBlurOverlay();
							}
							try
							{
								if (!form.IsDisposed && !form.Disposing)
								{
									form.TopMost = false;
									form.BringToFront();
									form.Activate();
								}
							}
							catch
							{
							}
						}
					}
				}
			}
			catch
			{
				try
				{
					this.RemoveBlurOverlay();
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000136 RID: 310 RVA: 0x000026F4 File Offset: 0x000026F4
		private void ProgressPopupForm_GlobalPopupClosed(object sender, EventArgs e)
		{
		}

		// Token: 0x06000137 RID: 311 RVA: 0x000235F4 File Offset: 0x000235F4
		private void FormMain_FormClosed(object sender, FormClosedEventArgs e)
		{
			ProgressPopupForm.GlobalPopupShown -= this.ProgressPopupForm_GlobalPopupShown;
			ProgressPopupForm.GlobalPopupClosed -= this.ProgressPopupForm_GlobalPopupClosed;
			if (this._activeBlurOverlay != null && !this._activeBlurOverlay.IsDisposed)
			{
				this._activeBlurOverlay.Close();
				this._activeBlurOverlay.Dispose();
				this._activeBlurOverlay = null;
			}
		}

		// Token: 0x06000138 RID: 312 RVA: 0x00002D3B File Offset: 0x00002D3B
		private void Popup_FormClosed_RemoveBlur(object sender, FormClosedEventArgs e)
		{
			this.RemoveBlurAndRestoreMain(sender as Form);
		}

		// Token: 0x06000139 RID: 313 RVA: 0x00002D3B File Offset: 0x00002D3B
		private void Popup_Disposed_RemoveBlur(object sender, EventArgs e)
		{
			this.RemoveBlurAndRestoreMain(sender as Form);
		}

		// Token: 0x0600013A RID: 314 RVA: 0x00023658 File Offset: 0x00023658
		private void RemoveBlurAndRestoreMain(Form popup)
		{
			try
			{
				if (popup != null)
				{
					popup.FormClosed -= this.Popup_FormClosed_RemoveBlur;
					popup.Disposed -= this.Popup_Disposed_RemoveBlur;
					try
					{
						popup.TopMost = false;
					}
					catch
					{
					}
				}
				this.RemoveBlurOverlay();
				if (!base.IsDisposed && !base.Disposing)
				{
					if (base.WindowState == FormWindowState.Minimized)
					{
						base.WindowState = FormWindowState.Normal;
					}
					base.Enabled = true;
					base.BringToFront();
					base.Activate();
					base.Focus();
					base.Invalidate(true);
					base.Update();
					this.Refresh();
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600013B RID: 315 RVA: 0x0002370C File Offset: 0x0002370C
		private void RemoveBlurOverlay()
		{
			try
			{
				if (this._activeBlurOverlay != null)
				{
					BlurOverlay activeBlurOverlay = this._activeBlurOverlay;
					this._activeBlurOverlay = null;
					if (!activeBlurOverlay.IsDisposed)
					{
						try
						{
							activeBlurOverlay.Hide();
						}
						catch
						{
						}
						try
						{
							activeBlurOverlay.Close();
						}
						catch
						{
						}
						try
						{
							activeBlurOverlay.Dispose();
						}
						catch
						{
						}
					}
				}
			}
			catch
			{
				this._activeBlurOverlay = null;
			}
		}

		// Token: 0x0600013C RID: 316 RVA: 0x00002D49 File Offset: 0x00002D49
		protected override void OnFormClosed(FormClosedEventArgs e)
		{
			this.RemoveBlurOverlay();
			base.OnFormClosed(e);
		}

		// Token: 0x0600013D RID: 317 RVA: 0x00002D58 File Offset: 0x00002D58
		protected override void OnFormClosing(FormClosingEventArgs e)
		{
			this.RemoveBlurOverlay();
			base.OnFormClosing(e);
		}

		// Token: 0x0600013E RID: 318 RVA: 0x0002379C File Offset: 0x0002379C
		private void PrepareKeihinResetBlur()
		{
			try
			{
				if (!base.IsDisposed && !base.Disposing)
				{
					this.RemoveBlurOverlay();
					this._activeBlurOverlay = new BlurOverlay(this, 8, true);
					if (this._activeBlurOverlay != null && !this._activeBlurOverlay.IsDisposed)
					{
						this._activeBlurOverlay.StartPosition = FormStartPosition.Manual;
						this._activeBlurOverlay.Bounds = base.Bounds;
						this._activeBlurOverlay.Show(this);
						this._keihinResetBlurReady = true;
					}
				}
			}
			catch
			{
				this._keihinResetBlurReady = false;
				this.RemoveBlurOverlay();
			}
		}

		// Token: 0x0600013F RID: 319 RVA: 0x00023838 File Offset: 0x00023838
		private void MenuExit_Click(object sender, EventArgs e)
		{
			try
			{
				this.method_28(this, new FormClosingEventArgs(CloseReason.None, false));
				FormMain.endThread = true;
				Thread thread = this.thread_0;
				if (thread != null)
				{
					thread.Join();
				}
				this.thread_0 = new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = false
				};
				this.OpenWithBlur(new LIVE_DATA());
				this.InitFtdiIso();
				FormMain.endThread = false;
				this.thread_0 = new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = true
				};
				this.thread_0.Start();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error in button1_Click: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x06000140 RID: 320 RVA: 0x000238FC File Offset: 0x000238FC
		private void SetSpinnerState(bool active, string statusText = null)
		{
			Control[] array = base.Controls.Find("TitleSpinner", true);
			Control[] array2 = base.Controls.Find("ProgressSpinner", true);
			Control[] array3 = base.Controls.Find("LblSpinnerStat", true);
			AquaSpinner aquaSpinner;
			if (array.Length != 0 && (aquaSpinner = (array[0] as AquaSpinner)) != null)
			{
				aquaSpinner.Enabled = active;
			}
			AquaSpinner aquaSpinner2;
			if (array2.Length != 0 && (aquaSpinner2 = (array2[0] as AquaSpinner)) != null)
			{
				aquaSpinner2.Enabled = active;
			}
			Label label;
			if (array3.Length != 0 && (label = (array3[0] as Label)) != null && statusText != null)
			{
				label.Text = statusText;
			}
		}

		// Token: 0x06000141 RID: 321 RVA: 0x0002398C File Offset: 0x0002398C
		private bool EraseEcuFlash()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				96,
				0,
				0
			};
			array[4] = this.Checksum8BitHonda(array, array.Length - 1, 0);
			byte[] array2 = new byte[256];
			uint num = 0U;
			return this.SendCommand(array, array.Length, ref array2, ref num, 0);
		}

		// Token: 0x06000142 RID: 322 RVA: 0x000239D8 File Offset: 0x000239D8
		private bool WriteEcuBlock(int offset, byte[] data)
		{
			int num = 5 + data.Length;
			byte[] array = new byte[num];
			array[0] = 114;
			array[1] = (byte)(num - 2);
			array[2] = 119;
			array[3] = (byte)(offset >> 8 & 255);
			array[4] = (byte)(offset & 255);
			Array.Copy(data, 0, array, 5, data.Length);
			array[num - 1] = this.Checksum8BitHonda(array, num - 1, 0);
			byte[] array2 = new byte[256];
			uint num2 = 0U;
			return this.SendCommand(array, array.Length, ref array2, ref num2, 0);
		}

		// Token: 0x06000143 RID: 323 RVA: 0x00023A54 File Offset: 0x00023A54
		private bool VerifyEcuFirmware(byte[] expected)
		{
			for (int i = 0; i < expected.Length; i += 128)
			{
				int num = Math.Min(128, expected.Length - i);
				byte[] array = this.ReadEcuBlock(i, num);
				if (array == null)
				{
					return false;
				}
				for (int j = 0; j < num; j++)
				{
					if (array[j] != expected[i + j])
					{
						return false;
					}
				}
			}
			return true;
		}

		// Token: 0x06000144 RID: 324 RVA: 0x00023AAC File Offset: 0x00023AAC
		private byte[] ReadEcuBlock(int offset, int size)
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				0,
				0
			};
			array[4] = this.Checksum8BitHonda(array, array.Length - 1, 0);
			byte[] array2 = new byte[256];
			uint num = 0U;
			if (!this.SendCommand(array, array.Length, ref array2, ref num, 0))
			{
				return null;
			}
			byte[] array3 = new byte[size];
			Array.Copy(array2, 5, array3, 0, Math.Min(size, array2.Length - 5));
			return array3;
		}

		// Token: 0x06000145 RID: 325 RVA: 0x00023B30 File Offset: 0x00023B30
		private void ResetEcu()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				96,
				1,
				0
			};
			array[4] = this.Checksum8BitHonda(array, array.Length - 1, 0);
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
		}

		// Token: 0x06000146 RID: 326 RVA: 0x00023B7C File Offset: 0x00023B7C
		private void LogAsync(SynchronizationContext ui, string msg)
		{
			ui.Post(delegate(object _)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] {1}", DateTime.Now, msg));
			}, null);
		}

		// Token: 0x06000147 RID: 327 RVA: 0x00023BB0 File Offset: 0x00023BB0
		private void LogProgressAsync(SynchronizationContext ui, int percent, string status)
		{
			ui.Post(delegate(object _)
			{
				this.TxtPb.Text = status;
			}, null);
		}

		// Token: 0x06000148 RID: 328 RVA: 0x00002D67 File Offset: 0x00002D67
		private void CloseFtdiConnection()
		{
			if (FormMain.ftHandle != IntPtr.Zero)
			{
				FormMain.FTDI.FT_Close(FormMain.ftHandle);
				FormMain.ftHandle = IntPtr.Zero;
			}
		}

		// Token: 0x06000149 RID: 329 RVA: 0x00023BE4 File Offset: 0x00023BE4
		private void RestartWorkerThread()
		{
			try
			{
				if (FormMain.ftHandle != IntPtr.Zero)
				{
					try
					{
						FormMain.FTDI.FT_Close(FormMain.ftHandle);
					}
					catch
					{
					}
					FormMain.ftHandle = IntPtr.Zero;
				}
				Thread.Sleep(300);
				FormMain.endThread = false;
				new Thread(new ThreadStart(this.WorkerThread))
				{
					IsBackground = true
				}.Start();
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] \ud83d\udd04 Worker thread dijalankan ulang\n", DateTime.Now));
			}
			catch (Exception ex)
			{
				this.RtbLog.AppendText(string.Format("[{0:HH:mm:ss}] ⚠️ Gagal restart worker: {1}\n", DateTime.Now, ex.Message));
			}
		}

		// Token: 0x0600014A RID: 330 RVA: 0x00023CB0 File Offset: 0x00023CB0
		private void ExecuteFlashRestore(FormMain.ECUTYPE ecuType)
		{
			try
			{
				if (FormMain.binBytes == null || FormMain.binSize <= 0)
				{
					this.LogMessage("❌ Tidak ada file backup yang dipilih");
					CustomMessageBox__0.Show("Tidak ada file backup yang dipilih.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					if (FormMain.ftHandle == IntPtr.Zero)
					{
						this.LogMessage("⚠️ FTDI belum terbuka — membuka sekarang...");
						if (!this.InitFtdiIso())
						{
							this.LogMessage("❌ Gagal membuka FTDI");
							CustomMessageBox__0.Show("Gagal membuka koneksi FTDI.\n\nPastikan:\n• Kabel FTDI terpasang\n• Driver FTDI terinstall\n• Tidak ada aplikasi lain yang memakai port", "Error FTDI", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							return;
						}
						this.LogMessage("✅ FTDI dibuka untuk restore");
					}
					int num = FormMain.startOffset;
					bool flag = FormMain.isFastWrite;
					this.LogMessage("========================================");
					this.LogMessage("\ud83c\udfcd️ Memulai RESTORE (WriteFlash)");
					this.LogMessage(string.Format("ECU Type   : {0}", ecuType));
					this.LogMessage(string.Format("Start Offset: {0} (0x{0:X})", num));
					this.LogMessage(string.Format("Fast Write : {0}", flag));
					this.LogMessage(string.Format("Bin Size   : {0} bytes", FormMain.binSize));
					this.LogMessage("========================================");
					this.WriteFlash(num, ecuType, flag);
				}
			}
			catch (Exception ex)
			{
				this.LogMessage("❌ ERROR in ExecuteFlashRestore: " + ex.Message);
				this.LogMessage("Stack Trace: " + ex.StackTrace);
				CustomMessageBox__0.Show("Gagal menjalankan restore:\n\n" + ex.Message, "Error Restore", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x0600014B RID: 331 RVA: 0x00023E40 File Offset: 0x00023E40
		private async void UpdateTimerTick(object sender, EventArgs e)
		{
			try
			{
				this._updateTimer.Stop();
				this._updateTimer.Dispose();
			}
			catch
			{
			}
			await this.CheckForUpdatesSilentlyAsync();
		}

		// Token: 0x0600014C RID: 332 RVA: 0x00023E7C File Offset: 0x00023E7C
		private async Task CheckForUpdatesSilentlyAsync()
		{
			if (!this._updateCheckedThisSession)
			{
				this._updateCheckedThisSession = true;
				try
				{
					FormMain.<>c__DisplayClass0_0__232 CS$<>8__locals1 = new FormMain.<>c__DisplayClass0_0__232();
					CS$<>8__locals1.<>4__this = this;
					VersionInfo info = await AutoUpdateManager.CheckForUpdateAsync(true, default(CancellationToken));
					CS$<>8__locals1.info = info;
					if (CS$<>8__locals1.info != null)
					{
						if (AutoUpdateManager.IsNewerVersion(CS$<>8__locals1.info.Version, AutoUpdateManager.CurrentVersion))
						{
							this.InvokeIfRequired(delegate
							{
								try
								{
									using (UpdatePopupForm updatePopupForm = new UpdatePopupForm(CS$<>8__locals1.info))
									{
										updatePopupForm.ShowDialog(CS$<>8__locals1.<>4__this);
									}
								}
								catch (Exception)
								{
								}
							});
							CS$<>8__locals1 = null;
						}
					}
				}
				catch (Exception)
				{
				}
			}
		}

		// Token: 0x0600014D RID: 333 RVA: 0x00023EC4 File Offset: 0x00023EC4
		private async void CheckUpdateItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (CustomMessageBox__1.Show("Apakah Anda ingin memeriksa dan menginstal update sekarang?\n\nPilih Update untuk melanjutkan pemeriksaan internet dan versi terbaru.", "CHECK UPDATE", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
				{
					using (UpdatePopupForm updatePopupForm = new UpdatePopupForm(new VersionInfo
					{
						Version = AutoUpdateManager.CurrentVersion
					}))
					{
						this.OpenWithBlur(updatePopupForm);
					}
					VersionInfo versionInfo = await AutoUpdateManager.CheckForUpdateAsync(false, CancellationToken.None);
					if (versionInfo == null)
					{
						CustomMessageBox__1.Show("Gagal memeriksa update.\n\nPeriksa koneksi internet Anda dan coba lagi.", "CHECK UPDATE", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
					else
					{
						if (AutoUpdateManager.IsNewerVersion(versionInfo.Version, AutoUpdateManager.CurrentVersion))
						{
							using (UpdatePopupForm updatePopupForm2 = new UpdatePopupForm(versionInfo))
							{
								this.OpenWithBlur(updatePopupForm2);
								goto IL_129;
							}
						}
						CustomMessageBox__1.Show("Aplikasi sudah menggunakan versi terbaru.\n\nVersi saat ini: v" + AutoUpdateManager.CurrentVersion, "CHECK UPDATE", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				IL_129:;
			}
			catch (OperationCanceledException)
			{
			}
			catch (Exception ex)
			{
				CustomMessageBox__1.Show("Terjadi kesalahan saat memeriksa update:\n\n" + ex.Message, "CHECK UPDATE", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x0600014E RID: 334 RVA: 0x00023F00 File Offset: 0x00023F00
		private byte CalculateKWP2000Checksum(byte[] data, int length)
		{
			byte b = 0;
			for (int i = 0; i < length; i++)
			{
				b -= data[i];
			}
			return b;
		}

		// Token: 0x0600014F RID: 335 RVA: 0x00023F24 File Offset: 0x00023F24
		private byte[] BuildKWP2000Command(byte service, byte[] parameters)
		{
			int num = (parameters != null) ? parameters.Length : 0;
			int num2 = 3 + num + 1;
			byte[] array = new byte[num2];
			array[0] = 128;
			array[1] = (byte)(num2 - 2);
			array[2] = service;
			if (num > 0)
			{
				Array.Copy(parameters, 0, array, 3, num);
			}
			array[num2 - 1] = this.CalculateKWP2000Checksum(array, num2 - 1);
			return array;
		}

		// Token: 0x06000150 RID: 336 RVA: 0x00023F7C File Offset: 0x00023F7C
		private bool ValidateCBR250RRFile(string filePath)
		{
			bool result;
			try
			{
				if (string.IsNullOrEmpty(filePath))
				{
					this.LogMessage("ERROR: Path file kosong");
					result = false;
				}
				else if (!File.Exists(filePath))
				{
					this.LogMessage("ERROR: File tidak ditemukan: " + filePath);
					result = false;
				}
				else
				{
					long length = new FileInfo(filePath).Length;
					this.LogMessage(string.Format("File: {0}", filePath));
					this.LogMessage(string.Format("Size: {0} bytes ({1} KB)", length, length / 1024L));
					if (length != 1048576L)
					{
						this.LogMessage(string.Format("ERROR: Ukuran file tidak sesuai untuk CBR250RR.\nDiharapkan: {0} bytes (1024 KB)\nDitemukan : {1} bytes ({2} KB)", 1048576, length, length / 1024L));
						result = false;
					}
					else
					{
						byte[] array = new byte[16];
						using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
						{
							fileStream.Read(array, 0, 16);
						}
						this.LogMessage("Header: " + BitConverter.ToString(array));
						this.LogMessage("Validasi file CBR250RR BERHASIL.");
						result = true;
					}
				}
			}
			catch (Exception ex)
			{
				this.LogMessage("ERROR ValidateCBR250RRFile: " + ex.Message);
				result = false;
			}
			return result;
		}

		// Token: 0x06000151 RID: 337 RVA: 0x000240DC File Offset: 0x000240DC
		private FormMain.ECUTYPE DetectECUTypeByEcmId(string ecmId)
		{
			if (string.IsNullOrEmpty(ecmId))
			{
				FormMain.isCBR250RRMode = false;
				FormMain.isCBR250RMode = false;
				return FormMain.ECUTYPE.KEIHINOTHER;
			}
			if (ecmId.StartsWith("38770-K64") || ecmId.StartsWith("K64"))
			{
				this.LogMessage("Terdeteksi: CBR250RR (SH7058, 1024KB flash)");
				FormMain.isCBR250RRMode = true;
				FormMain.isCBR250RMode = false;
				return FormMain.ECUTYPE.KEIHINOTHER;
			}
			if (ecmId.StartsWith("38770-KYJ") || ecmId.StartsWith("KYJ"))
			{
				this.LogMessage("Terdeteksi: CBR250R (H8C, 56KB flash)");
				FormMain.isCBR250RMode = true;
				FormMain.isCBR250RRMode = false;
				return FormMain.ECUTYPE.KEIHINH8C;
			}
			if (ecmId.StartsWith("38770-K33"))
			{
				this.LogMessage("Terdeteksi: CBR250R HRC / CBR300R (256KB flash)");
				FormMain.isCBR250RRMode = false;
				FormMain.isCBR250RMode = false;
				return FormMain.ECUTYPE.KEIHINM32R;
			}
			this.LogMessage("ECU Type tidak spesifik, default Keihin: " + ecmId);
			FormMain.isCBR250RRMode = false;
			FormMain.isCBR250RMode = false;
			return FormMain.ECUTYPE.KEIHINOTHER;
		}

		// Token: 0x06000152 RID: 338 RVA: 0x000241AC File Offset: 0x000241AC
		private uint CalculateCBR250RRChecksum(byte[] flashData)
		{
			uint num = 0U;
			for (int i = 0; i < flashData.Length; i++)
			{
				num += (uint)flashData[i];
			}
			return num;
		}

		// Token: 0x06000153 RID: 339 RVA: 0x000241D0 File Offset: 0x000241D0
		private bool KeihinPreWriteFlashCBR250RR()
		{
			bool result;
			try
			{
				this.LogMessage("=== Pre-Write CBR250RR (1024KB) ===");
				byte[] array = new byte[256];
				uint num = 0U;
				byte[] array2 = this.BuildKWP2000Command(16, new byte[]
				{
					133
				});
				if (!this.SendCommand(array2, array2.Length, ref array, ref num, 0))
				{
					this.LogMessage("ERROR: Gagal masuk programming session");
					result = false;
				}
				else
				{
					this.LogMessage("Programming session OK");
					Thread.Sleep(100);
					byte[] array3 = this.BuildKWP2000Command(39, new byte[]
					{
						1
					});
					if (!this.SendCommand(array3, array3.Length, ref array, ref num, 0))
					{
						this.LogMessage("ERROR: Gagal request security seed");
						result = false;
					}
					else
					{
						this.LogMessage("Security seed request OK");
						byte service = 39;
						byte[] array4 = new byte[5];
						array4[0] = 2;
						byte[] array5 = this.BuildKWP2000Command(service, array4);
						if (!this.SendCommand(array5, array5.Length, ref array, ref num, 0))
						{
							this.LogMessage("ERROR: Gagal kirim security key");
							result = false;
						}
						else
						{
							this.LogMessage("Security access granted");
							Thread.Sleep(100);
							byte service2 = 49;
							byte[] array6 = new byte[7];
							array6[0] = 1;
							array6[1] = byte.MaxValue;
							byte[] array7 = this.BuildKWP2000Command(service2, array6);
							if (!this.SendCommand(array7, array7.Length, ref array, ref num, 0))
							{
								this.LogMessage("ERROR: Gagal erase flash");
								result = false;
							}
							else
							{
								this.LogMessage("Menunggu erase flash selesai...");
								Thread.Sleep(5000);
								this.LogMessage("Pre-write CBR250RR SELESAI");
								result = true;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				this.LogMessage("ERROR KeihinPreWriteFlashCBR250RR: " + ex.Message);
				result = false;
			}
			return result;
		}

		// Token: 0x06000154 RID: 340 RVA: 0x00024370 File Offset: 0x00024370
		private bool WriteFlashCBR250RR(int startOffset, string filePath, bool isFastWrite)
		{
			bool result;
			try
			{
				this.LogMessage("=== Write Flash CBR250RR (1024KB) ===");
				this.LogMessage("File        : " + filePath);
				this.LogMessage("Start Offset: 0x" + startOffset.ToString("X8"));
				byte[] array = File.ReadAllBytes(filePath);
				if (array.Length != 1048576)
				{
					this.LogMessage("ERROR: Ukuran file tidak valid");
					result = false;
				}
				else
				{
					uint num = this.CalculateCBR250RRChecksum(array);
					this.LogMessage(string.Format("Checksum: 0x{0:X8}", num));
					if (524284 <= array.Length)
					{
						array[524280] = (byte)(num & 255U);
						array[524281] = (byte)(num >> 8 & 255U);
						array[524282] = (byte)(num >> 16 & 255U);
						array[524283] = (byte)(num >> 24 & 255U);
					}
					byte[] array2 = new byte[256];
					uint num2 = 0U;
					int num3 = 4096;
					int num4 = 0;
					this.LogMessage(string.Format("Total blocks: {0} (Block size: {1} bytes)", num3, 256));
					byte service = 52;
					byte[] array3 = new byte[9];
					array3[1] = (byte)(startOffset >> 24 & 255);
					array3[2] = (byte)(startOffset >> 16 & 255);
					array3[3] = (byte)(startOffset >> 8 & 255);
					array3[4] = (byte)(startOffset & 255);
					array3[6] = 16;
					byte[] array4 = this.BuildKWP2000Command(service, array3);
					if (!this.SendCommand(array4, array4.Length, ref array2, ref num2, 0))
					{
						this.LogMessage("ERROR: Gagal request download");
						result = false;
					}
					else
					{
						this.LogMessage("Request download OK");
						for (int i = 0; i < 1048576; i += 256)
						{
							if (FormMain.endThread)
							{
								this.LogMessage("Write dibatalkan oleh user");
								return false;
							}
							int num5 = Math.Min(256, 1048576 - i);
							byte[] array5 = new byte[num5];
							Array.Copy(array, i, array5, 0, num5);
							byte[] array6 = new byte[4 + num5 + 1];
							array6[0] = 128;
							array6[1] = (byte)(array6.Length - 2);
							array6[2] = 54;
							array6[3] = (byte)(num4 & 255);
							Array.Copy(array5, 0, array6, 4, num5);
							array6[array6.Length - 1] = this.CalculateKWP2000Checksum(array6, array6.Length - 1);
							if (!this.SendCommand(array6, array6.Length, ref array2, ref num2, 0))
							{
								this.LogMessage(string.Format("ERROR: Gagal transfer block {0} di offset 0x{1:X8}", num4, i));
								return false;
							}
							num4++;
							int progress = num4 * 100 / num3;
							if (num4 % 100 == 0 || num4 == num3)
							{
								this.LogMessage(string.Format("Transfer: {0}/{1} ({2}%)", num4, num3, progress));
								this.InvokeIfRequired(delegate
								{
									if (this.PbProgress != null && !this.PbProgress.IsDisposed)
									{
										int num6 = Math.Min(progress, 100);
										if (num6 >= this.PbProgress.Minimum && num6 <= this.PbProgress.Maximum)
										{
											this.PbProgress.Value = num6;
										}
									}
								});
							}
							if (!isFastWrite)
							{
								Thread.Sleep(5);
							}
						}
						byte[] array7 = this.BuildKWP2000Command(55, null);
						if (!this.SendCommand(array7, array7.Length, ref array2, ref num2, 0))
						{
							this.LogMessage("WARNING: Transfer exit gagal");
						}
						this.LogMessage("Verifikasi checksum...");
						byte[] array8 = this.BuildKWP2000Command(49, new byte[]
						{
							1,
							byte.MaxValue,
							1,
							0,
							0,
							0,
							0
						});
						if (this.SendCommand(array8, array8.Length, ref array2, ref num2, 0))
						{
							this.LogMessage("Verifikasi checksum OK");
						}
						else
						{
							this.LogMessage("WARNING: Verifikasi checksum gagal");
						}
						this.LogMessage("=== Write Flash CBR250RR SELESAI ===");
						result = true;
					}
				}
			}
			catch (Exception ex)
			{
				this.LogMessage("ERROR WriteFlashCBR250RR: " + ex.Message);
				result = false;
			}
			return result;
		}

		// Token: 0x06000155 RID: 341 RVA: 0x00024728 File Offset: 0x00024728
		private string GetFlashFilePath()
		{
			try
			{
				if (this.TbFileName != null && !this.TbFileName.IsDisposed)
				{
					string text = this.TbFileName.Text;
					if (!string.IsNullOrEmpty(text))
					{
						if (!Path.IsPathRooted(text))
						{
							string text2 = Path.Combine(Application.StartupPath, text);
							if (File.Exists(text2))
							{
								return text2;
							}
						}
						return text;
					}
				}
			}
			catch (Exception ex)
			{
				this.LogMessage("ERROR GetFlashFilePath: " + ex.Message);
			}
			return "";
		}

		// Token: 0x06000158 RID: 344 RVA: 0x000247B4 File Offset: 0x000247B4
		private void FormMain_Paint(object sender, PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			int width = base.ClientSize.Width;
			int height = base.ClientSize.Height;
			int radius = 18;
			Rectangle r = new Rectangle(0, 0, width, height);
			Region clip = graphics.Clip;
			using (GraphicsPath roundedPath = this.GetRoundedPath(r, radius))
			{
				graphics.SetClip(roundedPath);
			}
			Color color = Color.FromArgb(0, 200, 220);
			Color baseColor = Color.FromArgb(0, 100, 120);
			int num = 22;
			int r2 = 14;
			using (GraphicsPath graphicsPath = this.BuildPcbPath(width, height, num, r2))
			{
				using (Pen pen = new Pen(Color.FromArgb(70, baseColor), 6f)
				{
					StartCap = LineCap.Round,
					EndCap = LineCap.Round,
					LineJoin = LineJoin.Round
				})
				{
					graphics.DrawPath(pen, graphicsPath);
				}
				using (Pen pen2 = new Pen(color, 2.5f)
				{
					StartCap = LineCap.Round,
					EndCap = LineCap.Round,
					LineJoin = LineJoin.Round
				})
				{
					graphics.DrawPath(pen2, graphicsPath);
				}
			}
			checked
			{
				int off = num + 6;
				using (GraphicsPath graphicsPath2 = this.BuildPcbPath(width, height, off, r2))
				{
					using (Pen pen3 = new Pen(Color.FromArgb(160, color), 1f))
					{
						graphics.DrawPath(pen3, graphicsPath2);
					}
				}
				graphics.Clip = clip;
				Color color2 = Color.FromArgb(0, 255, 255);
				Color baseColor2 = Color.FromArgb(0, 140, 160);
				Rectangle r3 = new Rectangle(1, 1, width - 3, height - 3);
				using (Pen pen4 = new Pen(Color.FromArgb(80, baseColor2), 4f))
				{
					graphics.DrawPath(pen4, this.GetRoundedPath(r3, radius));
				}
				using (Pen pen5 = new Pen(color2, 1.5f))
				{
					graphics.DrawPath(pen5, this.GetRoundedPath(r3, radius));
				}
			}
		}

		// Token: 0x06000159 RID: 345 RVA: 0x00024A3C File Offset: 0x00024A3C
		private GraphicsPath BuildPcbPath(int w, int h, int off, int r)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			checked
			{
				int num = r * 2;
				int num2 = w - off;
				int num3 = h - off;
				int num4 = w / 2;
				int num5 = 215;
				int num6 = 15;
				int num7 = num4 - num5;
				int num8 = num4 + num5;
				int num9 = off + num6;
				int num10 = num4 - num5;
				int num11 = num4 + num5;
				int num12 = num3 - num6;
				int num13 = 215;
				int num14 = h / 2 - num13;
				int num15 = h / 2 + num13;
				graphicsPath.AddLine(off + r, off, num7, off);
				graphicsPath.AddLine(num7, off, num7 + num6, num9);
				graphicsPath.AddLine(num7 + num6, num9, num8 - num6, num9);
				graphicsPath.AddLine(num8 - num6, num9, num8, off);
				graphicsPath.AddLine(num8, off, num2 - r, off);
				graphicsPath.AddArc(num2 - num, off, num, num, 270f, 90f);
				graphicsPath.AddLine(num2, off + r, num2, num14);
				graphicsPath.AddLine(num2, num14, num2 - num6, num14 + num6);
				graphicsPath.AddLine(num2 - num6, num14 + num6, num2 - num6, num15 - num6);
				graphicsPath.AddLine(num2 - num6, num15 - num6, num2, num15);
				graphicsPath.AddLine(num2, num15, num2, num3 - r);
				graphicsPath.AddArc(num2 - num, num3 - num, num, num, 0f, 90f);
				graphicsPath.AddLine(num2 - r, num3, num11, num3);
				graphicsPath.AddLine(num11, num3, num11 - num6, num12);
				graphicsPath.AddLine(num11 - num6, num12, num10 + num6, num12);
				graphicsPath.AddLine(num10 + num6, num12, num10, num3);
				graphicsPath.AddLine(num10, num3, off + r, num3);
				graphicsPath.AddArc(off, num3 - num, num, num, 90f, 90f);
				graphicsPath.AddLine(off, num3 - r, off, num15);
				graphicsPath.AddLine(off, num15, off + num6, num15 - num6);
				graphicsPath.AddLine(off + num6, num15 - num6, off + num6, num14 + num6);
				graphicsPath.AddLine(off + num6, num14 + num6, off, num14);
				graphicsPath.AddLine(off, num14, off, off + r);
				graphicsPath.AddArc(off, off, num, num, 180f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x0600015A RID: 346 RVA: 0x00024C64 File Offset: 0x00024C64
		private GraphicsPath GetRoundedPath(Rectangle r, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			checked
			{
				int num = radius * 2;
				graphicsPath.AddArc(r.X, r.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(r.Right - num, r.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(r.Right - num, r.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(r.X, r.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x04000001 RID: 1
		private static readonly string[] khPartCode = new string[]
		{
			"CB 150R\r\n38770-K15-711",
			"CBR 150R New (2022-2023)\r\n38770-K45-NL1",
			"CB 150X New (2022-2023)\r\n38770-K3B-N01",
			"Supra 125 New (2023)\r\n38770-K41-NC1",
			"SCOOPY 110 NEW NON ISS (2020)\r\n38770-K2F-N01",
			"SCOOPY 110 NEW ISS (2023)\r\n38770-K2F-N91",
			"Unknown MotoBike\r\n38770-MKK-D02",
			"Unknown MotoBike\r\n38770-KVG-V42",
			"BEAT 110 NON ESP (2015)\r\n38770-K25-901",
			"BEAT 110 NON ESP (2015)\r\n38770-K46-N01",
			"SUPRA X 125 (2016)\r\n38770-K41-N01",
			"Unknown MotoBike\r\n38770-MFN-D01",
			"Unknown MotoBike\r\n38770-MFN-F01",
			"Unknown MotoBike\r\n38770-MKJ-D02",
			"Unknown MotoBike\r\n38770-MGC-D32",
			"CB 150R (2015)\r\n38770-K15-903",
			"CB 150R (2017)\r\n38770-K15-921",
			"CB 150R (64KB)\r\n38770-K15-888",
			"CB 150R (2016)\r\n38770-K15-601",
			"VERZA 150 (2016)\r\n38770-K18-961",
			"Unknown MotoBike\r\n38770-K0A-R11",
			"Unknown MotoBike\r\n38770-KVK-B31",
			"Unknown MotoBike\r\n38770-K0A-A01",
			"Unknown MotoBike\r\n38770-MFM-651",
			"Unknown MotoBike\r\n38770-MFM-702",
			"Unknown MotoBike\r\n38770-MJW-D51",
			"Unknown MotoBike\r\n38770-MJW-N41",
			"Unknown MotoBike\r\n38770-MJW-B41",
			"Unknown MotoBike\r\n38770-MGZ-D02",
			"Unknown MotoBike\r\n38770-MGZ-A03",
			"Unknown MotoBike\r\n38770-MGZ-C03",
			"Unknown MotoBike\r\n38770-MGZ-C02",
			"Unknown MotoBike\r\n38770-MJW-D91",
			"Unknown MotoBike\r\n38770-MJW-961",
			"Unknown MotoBike\r\n38770-MJW-NM1",
			"Unknown MotoBike\r\n38770-MJW-???",
			"Unknown MotoBike\r\n38770-MFG-D02",
			"Unknown MotoBike\r\n38770-MJE-D41",
			"Unknown MotoBike\r\n38770-MJE-TB1",
			"Unknown MotoBike\r\n38770-MJE-G12",
			"Unknown MotoBike\r\n38770-MJE-G52",
			"Unknown MotoBike\r\n38770-MKN-D51",
			"Unknown MotoBike\r\n38770-MKN-HF2",
			"Unknown MotoBike\r\n38770-MFA-D03",
			"Unknown MotoBike\r\n38770-MEL-613",
			"Unknown MotoBike\r\n38770-MEL-622",
			"Unknown MotoBike\r\n38770-MEL-643",
			"Unknown MotoBike\r\n38770-MEL-D01",
			"Unknown MotoBike\r\n38770-MEL-A21",
			"Unknown MotoBike\r\n38770-MEL-A22",
			"Unknown MotoBike\r\n38770-MEL-F21",
			"Unknown MotoBike\r\n38770-MEL-L22",
			"Unknown MotoBike\r\n38770-MEL-D21",
			"Unknown MotoBike\r\n38770-MFL-644",
			"Unknown MotoBike\r\n38770-MFL-702",
			"Unknown MotoBike\r\n38770-MFL-622",
			"Unknown MotoBike\r\n38770-MFL-773",
			"Unknown MotoBike\r\n38770-MFL-671",
			"Unknown MotoBike\r\n38770-MFL-741",
			"Unknown MotoBike\r\n38770-MFL-691",
			"Unknown MotoBike\r\n38770-MFL-861",
			"Unknown MotoBike\r\n38770-MFL-871",
			"Unknown MotoBike\r\n38770-MFL-761",
			"Unknown MotoBike\r\n38770-MFL-J41",
			"Unknown MotoBike\r\n38770-MFL-J21",
			"Unknown MotoBike\r\n38770-MFL-L21",
			"Unknown MotoBike\r\n38770-MFL-F21",
			"Unknown MotoBike\r\n38770-MFL-D21",
			"Unknown MotoBike\r\n38770-MFL-A21",
			"Unknown MotoBike\r\n38770-MGP-L01",
			"Unknown MotoBike\r\n38770-MGP-F01",
			"Unknown MotoBike\r\n38770-MGP-A01",
			"Unknown MotoBike\r\n38770-MGP-J01",
			"Unknown MotoBike\r\n38770-MGP-D01",
			"Unknown MotoBike\r\n38770-MGP-T42",
			"Unknown MotoBike\r\n38770-MGP-A92",
			"Unknown MotoBike\r\n38770-MGP-F63",
			"Unknown MotoBike\r\n38770-MGP-D62",
			"Unknown MotoBike\r\n38770-MKF-A22",
			"Unknown MotoBike\r\n38770-MKF-H11",
			"Unknown MotoBike\r\n38770-MKF-L13",
			"Unknown MotoBike\r\n38770-MKF-D43",
			"Unknown MotoBike\r\n38770-MKFA-A22",
			"Unknown MotoBike\r\n38770-MKFA-DK2",
			"Unknown MotoBike\r\n38770-NLR-B31",
			"Unknown MotoBike\r\n38770-MKFA-D72",
			"Unknown MotoBike\r\n38770-MKF-D72",
			"Unknown MotoBike\r\n38770-NLS-000",
			"Unknown MotoBike\r\n38770-KTY-H52",
			"Unknown MotoBike\r\n38770-K98-E02",
			"Unknown MotoBike\r\n38770-KPP-N02",
			"Unknown MotoBike\r\n38770-KPP-602",
			"CBR 150R (2018)\r\n38770-K45-N01",
			"CBR 150R (2018)\r\n38770-K45-N42",
			"Unknown MotoBike\r\n38770-K94-T02",
			"CBR 150R (2018)\r\n38770-K45-NA1",
			"CBR 150R (2018)\r\n38770-K45-NA1",
			"Unknown MotoBike\r\n38770-KPP-T03",
			"Unknown MotoBike\r\n38770-KYJ-922",
			"Unknown MotoBike\r\n38770-KYJ-971",
			"Unknown MotoBike\r\n38770-K33-N03",
			"Unknown MotoBike\r\n38770-K33-D22",
			"Unknown MotoBike\r\n38770-KYJ-R11",
			"Unknown MotoBike\r\n38770-K64-J01",
			"Unknown MotoBike\r\n38770-K64-N04",
			"Unknown MotoBike\r\n38770-K64-N01",
			"Unknown MotoBike\r\n38770-K64-NB1",
			"Unknown MotoBike\r\n38770-K33-D02",
			"Unknown MotoBike\r\n38770-KOA-T11",
			"Unknown MotoBike\r\n38770-MGZ-U02",
			"Unknown MotoBike\r\n38770-MJW-N11",
			"Unknown MotoBike\r\n38770-MJW-T11",
			"Unknown MotoBike\r\n38770-MJW-AQ1",
			"Unknown MotoBike\r\n38770-MJW-DR1",
			"Unknown MotoBike\r\n38770-MGM-D11",
			"Unknown MotoBike\r\n38770-MEE-622",
			"Unknown MotoBike\r\n38770-MEE-612",
			"Unknown MotoBike\r\n38770-MEE-613",
			"Unknown MotoBike\r\n38770-MEE-F02",
			"Unknown MotoBike\r\n38770-MEE-D01",
			"Unknown MotoBike\r\n38770-MEE-A02",
			"Unknown MotoBike\r\n38770-MFJ-D04",
			"Unknown MotoBike\r\n38770-MFJ-F03",
			"Unknown MotoBike\r\n38770-MFJ-D42",
			"Unknown MotoBike\r\n38770-MJC-D01",
			"Unknown MotoBike\r\n38770-MJC-A01",
			"Unknown MotoBike\r\n38770-N1A-D00",
			"Unknown MotoBike\r\n38770-N1A-D11",
			"Unknown MotoBike\r\n38770-MJE-A02",
			"Unknown MotoBike\r\n38770-MJE-T15",
			"Unknown MotoBike\r\n38770-MJE-T52",
			"Unknown MotoBike\r\n38770-MJE-S11",
			"Unknown MotoBike\r\n38770-MJE-VB1",
			"Unknown MotoBike\r\n38770-MJE-BB1",
			"Unknown MotoBike\r\n38770-MJE-HB3",
			"Unknown MotoBike\r\n38770-MKN-D11",
			"Unknown MotoBike\r\n38770-MKN-U11",
			"Unknown MotoBike\r\n38770-MKN-T11",
			"Unknown MotoBike\r\n38770-MKN-HB2",
			"Unknown MotoBike\r\n38770-MKN-DB1",
			"Unknown MotoBike\r\n38770-MKN-L32",
			"Unknown MotoBike\r\n38770-MKG-N52",
			"Unknown MotoBike\r\n38770-MJP-DA1",
			"Unknown MotoBike\r\n38770-KYK-D12",
			"Unknown MotoBike\r\n38770-K28-A62",
			"CRF 150L (2016-2023)\r\n38770-K84-901",
			"Unknown MotoBike\r\n38770-K99-B02",
			"Unknown MotoBike\r\n38770-KZZ-902",
			"Unknown MotoBike\r\n38770-KZZ-914",
			"Unknown MotoBike\r\n38770-KZZ-J01",
			"Unknown MotoBike\r\n38770-KZZ-J81",
			"Unknown MotoBike\r\n38770-KZZ-A22",
			"Unknown MotoBike\r\n38770-K95-A41",
			"Unknown MotoBike\r\n38770-KZZ-L41",
			"Unknown MotoBike\r\n38770-K1T-T01",
			"Unknown MotoBike\r\n38770-K1T-A11",
			"Unknown MotoBike\r\n38770-MKE-A71",
			"Unknown MotoBike\r\n38770-MKE-AF3",
			"Unknown MotoBike\r\n38770-MKE-A81",
			"Unknown MotoBike\r\n38770-K47-M01",
			"Unknown MotoBike\r\n38770-MEW-D41",
			"Unknown MotoBike\r\n38770-K76-M02",
			"Unknown MotoBike\r\n38770-K76-T62",
			"Unknown MotoBike\r\n38770-MFT-642",
			"Unknown MotoBike\r\n38770-MGF-D12",
			"Unknown MotoBike\r\n38770-KYZ-T03",
			"Unknown MotoBike\r\n38770-KYZ-V21",
			"Unknown MotoBike\r\n38770-KYZ-V71",
			"Unknown MotoBike\r\n38770-K73-V42",
			"GENIO 110 New\r\n30400-K0J-N01",
			"Unknown MotoBike\r\n38770-K26-911",
			"Unknown MotoBike\r\n38770-K26-931",
			"Unknown MotoBike\r\n38770-K26-B13",
			"Unknown MotoBike\r\n38770-K26-C31",
			"SUPRA GTR 150\r\n38770-K56-N11",
			"SUPRA GTR 150\r\n38770-K56-NJ1",
			"Unknown MotoBike\r\n38770-MKA-D71",
			"Unknown MotoBike\r\n38770-GGE-941",
			"Unknown MotoBike\r\n38770-GGE-901",
			"MEGAPRO 150 MONO\r\n38770-KYE-942",
			"Unknown MotoBike\r\n38770-K0F-A01",
			"Unknown MotoBike\r\n38770-MJL-Y11",
			"Unknown MotoBike\r\n38770-MCG-602",
			"Unknown MotoBike\r\n38770-K87-T52",
			"REVO FIT 110\r\n38770-K03-N32",
			"REVO X 110\r\n38770-K58-N41",
			"Unknown MotoBike\r\n38770-KPG-H01",
			"SONIC\r\n38770-K56-M01",
			"Unknown MotoBike\r\n38770-K56-M91",
			"Unknown MotoBike\r\n38770-HR6-MO2",
			"SCOOPY 110 NEW ISS (2020)\r\n30400-K2F-N11",
			"SCOOPY 110 ISS (2018)\r\n30400-K93-N01",
			"Unknown MotoBike\r\n30400-K93-T01",
			"Unknown MotoBike\r\n38770-GFM-601",
			"Unknown MotoBike\r\n38770-KTW-903",
			"Unknown MotoBike\r\n38770-KTW-B02",
			"Unknown MotoBike\r\n38770-K53-DB2",
			"Unknown MotoBike\r\n38770-K53-D03",
			"SONIC 150R (2016)\r\n38770-K56-N01",
			"Unknown MotoBike\r\n38770-KZL-E12",
			"SPACY 110 NON ESP\r\n38770-KZL-C31",
			"Unknown MotoBike\r\n38770-K0G-962",
			"Unknown MotoBike\r\n38770-KZV-A61",
			"SUPRA HELM IN\r\n38770-KYZ-713",
			"Unknown MotoBike\r\n38770-HL6-A05",
			"VARIO 110 NON ISS (2016)\r\n30400-K46-N21",
			"VARIO 110 ESP ISS (2016)\r\n30400-K46-N31",
			"VARIO 110 ESP (2016)\r\n30400-K46-NA1",
			"VERZA 150\r\n38770-K18-902",
			"VERZA 150\r\n38770-K18-941",
			"Unknown MotoBike\r\n38770-MGE-623",
			"Unknown MotoBike\r\n38770-MGE-D01",
			"Unknown MotoBike\r\n38770-MGE-F11",
			"Unknown MotoBike\r\n38770-MGE-D41",
			"Unknown MotoBike\r\n38770-MGE-F02",
			"Unknown MotoBike\r\n38770-MGE-D02",
			"Unknown MotoBike\r\n38770-MGH-641",
			"Unknown MotoBike\r\n38770-MGH-D21",
			"Unknown MotoBike\r\n38770-MGH-F21",
			"Unknown MotoBike\r\n38770-MGH-N12",
			"Unknown MotoBike\r\n38770-MGH-M12",
			"Unknown MotoBike\r\n38770-MFR-642",
			"Unknown MotoBike\r\n38770-KWW-643",
			"Unknown MotoBike\r\n38770-K03-H01",
			"Unknown MotoBike\r\n38770-G90-V02",
			"Unknown MotoBike\r\n38770-K58-TC2",
			"Unknown MotoBike\r\n38770-K58-T81",
			"Unknown MotoBike\r\n38770-K73-M41",
			"Unknown MotoBike\r\n38770-K56-V01",
			"Unknown MotoBike\r\n38770-K56-V51",
			"Unknown MotoBike\r\n38770-MKH-D01",
			"Unknown MotoBike\r\n38770-MKH-D22",
			"Unknown MotoBike\r\n38770-MKH-C02",
			"Unknown MotoBike\r\n38770-MKH-C03",
			"Unknown MotoBike\r\n38770-MKH-D23",
			"Unknown MotoBike\r\n38770-MKH-D42",
			"Unknown MotoBike\r\n38770-KWT-703",
			"GENIO 110\r\n (K0J-N11)",
			"GENIO 110\r\n (K0J-N61)",
			"GENIO 110\r\n (K0J-N01)",
			"GENIO 110\r\n (K0J-N71)",
			"SCOOPY 110\r\n NEW (K2F-N11)",
			"SCOOPY 110\r\n NEW (K2F-N81)",
			"SCOOPY new 2025\r\n-30400 K2F-NC1 non keyless",
			"SCOOPY new 2025\r\n-30400 K2F-ND1 keyless",
			"SUPRA X ANF \r\n (KVL-N21)",
			"SUPRA X ANF \r\n (KTM-781)",
			"KOJ-NB1-GENIO-2026",
			"GENIO 2026-KOJ-NA1"
		};

		// Token: 0x04000002 RID: 2
		private static readonly string[] khEcmId = new string[]
		{
			"0104290F01",
			"0104110F01",
			"0104530F01",
			"0104AF0F01",
			"0104080F01",
			"0104F00F01",
			"0102A40101",
			"0100F91103",
			"0101340F01",
			"0101A10F01",
			"01018B0F01",
			"01006A0101",
			"01006A0301",
			"0102F60102",
			"0101390102",
			"01011B0F02",
			"0101DA0F01",
			"0103130F11",
			"0103130F01",
			"0102E70F01",
			"0102A22101",
			"0101080801",
			"0102B70401",
			"01004C0701",
			"01004C0601",
			"0101F20101",
			"0101F20F01",
			"0101F20801",
			"0101250101",
			"0101250501",
			"0101250B02",
			"0101250B01",
			"0101DE0101",
			"0101DE0F01",
			"0102780F01",
			"0102780D01",
			"0100390101",
			"01019C0101",
			"01027D0D01",
			"01014E1201",
			"01019C1201",
			"0103050101",
			"0103BF0E01",
			"0100300101",
			"01000F0202",
			"01000F0302",
			"01000F0102",
			"01001A0101",
			"01002B0401",
			"01002B0402",
			"01002B0301",
			"01002B0502",
			"01002B0101",
			"01005E0103",
			"01005E0601",
			"01005E0301",
			"01005E0503",
			"01005E0401",
			"0100B00301",
			"0100B00401",
			"0100B00501",
			"0100B00801",
			"0100B00102",
			"0100B00601",
			"0100B70601",
			"0100B70501",
			"0100B70301",
			"0100B70101",
			"0100B70401",
			"0100F30501",
			"0100F30301",
			"0100F30401",
			"0100F30601",
			"0100F30101",
			"0101830D01",
			"0101830401",
			"0101830302",
			"0101830101",
			"0102480401",
			"0102490E01",
			"0102490501",
			"0102490101",
			"0103380D01",
			"0103380101",
			"01005EFD74",
			"0102850111",
			"0102850101",
			"01028501FF",
			"0100C60102",
			"0102A10101",
			"0100FA1001",
			"0101110F01",
			"0101B10F01",
			"0102040F01",
			"0102A00D01",
			"0103250F01",
			"0103250F11",
			"0100C50D02",
			"0100B80502",
			"0100B80F01",
			"0101790F02",
			"0101790101",
			"0101320671",
			"0101E40601",
			"0101E40F03",
			"0101E40F11",
			"0103DC0F01",
			"0101740101",
			"0102B70D02",
			"0101250701",
			"0101DD0F01",
			"0101DD0D01",
			"0102F20511",
			"0102F20111",
			"0100E00101",
			"0100020302",
			"0100020202",
			"0100020203",
			"01001B0301",
			"01001B0101",
			"01001B0401",
			"0100330103",
			"0100330302",
			"01007C0102",
			"0101420101",
			"0101420401",
			"0100330171",
			"0101420171",
			"01014E0401",
			"01014E0D03",
			"01019C0D02",
			"0102101011",
			"01027D0701",
			"01027D0101",
			"01027D0E02",
			"01031A0101",
			"01031A1801",
			"01031A0D01",
			"0103BE0E01",
			"01031A1201",
			"01031A0501",
			"01025C0F01",
			"0102560101",
			"0102DE0501",
			"0102DD0501",
			"0102320F01",
			"0103160801",
			"01011A0D01",
			"01011A0503",
			"0102360D01",
			"0102360101",
			"01015B0D01",
			"0102890101",
			"0102360F01",
			"0104070D01",
			"0104070501",
			"0102E80501",
			"0103B60503",
			"0102E90501",
			"0103261801",
			"01009C0101",
			"01029E1801",
			"0102B50D01",
			"01008F0101",
			"0100ED0101",
			"0100FB0E02",
			"01010C1101",
			"01015F1101",
			"0103141101",
			"0103110F01",
			"0101350501",
			"0101350101",
			"0102130501",
			"0102570501",
			"0101CA0F01",
			"0103920F01",
			"0801DF0101",
			"01006D1101",
			"0100B41101",
			"0101700F01",
			"0102CA0501",
			"0101820101",
			"0101220801",
			"01025A0D01",
			"0101870F02",
			"0102E40F01",
			"0102D71F01",
			"0101CD1801",
			"0103931801",
			"0D02FC0401",
			"0104130F01",
			"01027F0F01",
			"0102810D01",
			"01006B0801",
			"0100450103",
			"0100530101",
			"0102B10101",
			"0101B80103",
			"0101C90F01",
			"0101021101",
			"01011E0F01",
			"01030E0501",
			"0101BA0D01",
			"0100E80F02",
			"0801EB0502",
			"0101FA0F01",
			"0101F80F01",
			"0102F80F01",
			"0101200F01",
			"0101F30F01",
			"0100AA0301",
			"0101030101",
			"0101030301",
			"0101190101",
			"0800AB0301",
			"0800AB0101",
			"0100FC0101",
			"0801040101",
			"0801040301",
			"08017D0101",
			"08017D0301",
			"01007B0101",
			"0100CE0D02",
			"0101880D01",
			"0102681101",
			"01034C0D01",
			"0102B90D01",
			"0102AD1801",
			"0101CB1101",
			"0103591101",
			"08024C0101",
			"08024CFFFF",
			"0802E60E01",
			"0802E60E02",
			"0802E60102",
			"08024CFFFE",
			"0101310802",
			"0103100F01",
			"0104A40F01",
			"0103110F01",
			"0104A50F01",
			"0104130F01",
			"0104F10F01",
			"0105A70F01",
			"0105A80F01",
			"01005F0F01",
			"01002D0F01",
			"0106780F11",
			"0106770F11"
		};

		// Token: 0x04000003 RID: 3
		private static readonly string[] khStartOffset = new string[]
		{
			"8000",
			"8000",
			"8000",
			"8000",
			"0",
			"0",
			"0",
			"4000",
			"4000",
			"8000",
			"8000",
			"0",
			"0",
			"0",
			"0",
			"4000",
			"8000",
			"8000",
			"8000",
			"8000",
			"8000",
			"0",
			"8000",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"8000",
			"0",
			"0",
			"8000",
			"8000",
			"8000",
			"8000",
			"8000",
			"0",
			"0",
			"0",
			"E0000",
			"E0000",
			"0",
			"0",
			"0",
			"0",
			"0",
			"E0000",
			"8000",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"8000",
			"8000",
			"8000",
			"E0000",
			"E0000",
			"E0000",
			"8000",
			"8000",
			"E0000",
			"E0000",
			"8000",
			"8000",
			"8000",
			"E0000",
			"C000",
			"E0000",
			"8000",
			"0",
			"8000",
			"8000",
			"0",
			"0",
			"4000",
			"4000",
			"4000",
			"8000",
			"0",
			"4000",
			"4000",
			"8000",
			"8000",
			"8000",
			"8000",
			"0",
			"0",
			"0",
			"4000",
			"8000",
			"0",
			"E0000",
			"E0000",
			"8000",
			"8000",
			"8000",
			"8000",
			"8000",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"8000",
			"8000",
			"4000",
			"4000",
			"8000",
			"8000",
			"4000",
			"0",
			"0",
			"0",
			"0",
			"4000",
			"8000",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"4000",
			"8000",
			"8000",
			"8000",
			"8000",
			"8000",
			"8000",
			"8000",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"E0000",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0"
		};

		// Token: 0x04000004 RID: 4
		private static readonly string[] khCksumOffset = new string[]
		{
			"0",
			"0",
			"0",
			"0",
			"3FFF8",
			"3FFF8",
			"FFFF8",
			"7600",
			"7600",
			"0",
			"0",
			"3FFF8",
			"3FFF8",
			"FFFF8",
			"3FFF8",
			"7600",
			"0",
			"0",
			"0",
			"0",
			"0",
			"DFEF",
			"0",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"7FFF8",
			"3FFF8",
			"3FFF8",
			"7FFF8",
			"7FFF8",
			"3FFF8",
			"3FFFC",
			"3FFFC",
			"3FFFC",
			"3FFFC",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"FFFF8",
			"FFFF8",
			"FFFF8",
			"FFFF8",
			"FFFF8",
			"FFFF8",
			"3FFF8",
			"FFFF8",
			"FFFF8",
			"FFFF8",
			"DFEF",
			"0",
			"DFEF",
			"DFEF",
			"0",
			"0",
			"0",
			"0",
			"0",
			"DFEF",
			"DFEF",
			"DFEF",
			"B000",
			"B000",
			"18FFE",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"B000",
			"0",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFE0",
			"3FFE0",
			"3FFE0",
			"3FFFC",
			"3FFFC",
			"3FFFC",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"3FFF8",
			"7FFF8",
			"0",
			"0",
			"0",
			"B000",
			"B000",
			"B000",
			"0",
			"0",
			"B000",
			"B000",
			"0",
			"0",
			"0",
			"B000",
			"",
			"B000",
			"0",
			"3FFF8",
			"0",
			"0",
			"3FFF8",
			"3FFF8",
			"7600",
			"7600",
			"7600",
			"0",
			"3FFF8",
			"7600",
			"7600",
			"0",
			"0",
			"0",
			"0",
			"7FFF8",
			"DFEF",
			"DFEF",
			"7600",
			"0",
			"3FFF8",
			"B000",
			"B000",
			"0",
			"0",
			"0",
			"0",
			"0",
			"7FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"DFEF",
			"DFEF",
			"DFEF",
			"DFEF",
			"0",
			"0",
			"7600",
			"7600",
			"0",
			"0",
			"7600",
			"7FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"7600",
			"0",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"3FFF8",
			"7600",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"0",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"7FFF8",
			"B000",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"3FFF8",
			"7FEF",
			"7FEF",
			"3FFF8",
			"3FFF8"
		};

		// Token: 0x04000005 RID: 5
		private static readonly string[] shPartCode = new string[]
		{
			"Vario 160 New (2021)\r\n30400-K2SA-N02",
			"ADV 150 SmartKey (2018)\r\n30400-K0WA-N01",
			"ADV 150 SmartKey (2018)\r\n30400-K0WF-T01",
			"LEAD MotoBike\r\n30400-K12-901",
			"LEAD MotoBike\r\n30400-K12-903",
			"LEAD MotoBike\r\n30400-K12-903",
			"BEAT 110 (2020)\r\n30400-K1AA-N02",
			"BEAT 110 (2020)\r\n30400-K1AA-N03",
			"BEAT 110 (2020)\r\n30400-K1AA-N12",
			"BEAT 110 (2020)\r\n30400-K1AA-N13",
			"PCX 160 New SmartKey (2021)\r\n30400-K1ZG-N21",
			"PCX 160 New SmartKey (2021)\r\n30400-K1ZG-N31",
			"BEAT 110 ESP(2016)\r\n30400-K25G-601",
			"BEAT 110 ESP(2016)\r\n30400-K25G-611",
			"Air Blade ( 2013 - 2015 )\r\n30400-K27-V01",
			"Air Blade ( 2013 - 2015 )\r\n30400-K27-V02",
			"Air Blade ( 2013 - 2015 )\r\n30400-K27-V51",
			"Air Blade ( 2013 - 2015 )\r\n30400-K27-V52",
			"Air Blade ( 2013 - 2015 )\r\n30400-K27-V53",
			"SH MODE ( 2013 - 2015 )\r\n30400-K29-901",
			"SH MODE ( 2013 - 2015 )\r\n30400-K29-902",
			"SH MODE ( 2013 - 2015 )\r\n30400-K29-903",
			"Unknown MotoBike\r\n30400-K36J-N11",
			"Unknown MotoBike\r\n30400-K50A-T02",
			"Vario 150\r\n30400-K59A-A11",
			"Vario 150\r\n30400-K59F-A01",
			"Vario 150 SmartKey Iss (2018)\r\n30400-K59J-A71",
			"Vario 150 MotoBike\r\n30400-K59-M01",
			"Vario 125 New Non Iss\r\n30400-K60A-B01",
			"Vario 125 New Iss\r\n30400-K60K-B11",
			"Vario 125 New Non Iss\r\n30400-K60K-B21",
			"Vario 125 New Iss\r\n30400-K60K-B31",
			"Vario 125 New Iss\r\n30400-K60R-B61",
			"Vario 125 New Non ISS\r\n30400-K60R-B71",
			"CLICK 125 MotoBike\r\n30400-K60S-M61",
			"BEAT STREET 110 ESP\r\n30400-K81A-N02",
			"BEAT STREET 110 ESP\r\n30400-K81A-N12",
			"BEAT 110 ESP Non Iss\r\n30400-K81H-N52",
			"BEAT 110 ESP Iss\r\n30400-K81H-N62",
			"Unknown MotoBike\r\n30400-K96-V01",
			"Unknown MotoBike\r\n30400-K97A-U01",
			"PCX 150 SmartKey\r\n30400-K97G-N01",
			"PCX 150 SmartKey\r\n30400-K97G-N31",
			"Vario 125 Old (2011-2012)\r\n30400-KZRA-601",
			"Vario 125 Old (2012-2013)\r\n30400-KZRA-651",
			"Vario 125 Old (2012-2013)\r\n30400-KZRJ-B11",
			"Vario 125 Old (2013-2014)\r\n30400-KZRM-B21",
			"Vario 125 Old (2013-2014)\r\n30400-KZRM-B31",
			"Vario 125 New (2023)\r\n30400-K2VG-N32",
			"Vario 125 New SmartKey (2023)\r\n30400-K2VG-N42",
			"PCX 160 New SmartKey (2023)\r\n30400-K1ZN-N41",
			"PCX 160 New SmartKey (2023)\r\n30400-K1ZN-N51",
			"VARIO 125 New (2023)\r\n30400-K2VJ-H31",
			"ADV 160 New SmartKey (2023)\r\n30400-KOWL-NB1",
			"ADV 160 (2023)\r\n30400-K0WL-NA1",
			"PCX 160 ABS (2020-2021)\r\n30400-K1ZF-T11",
			"BEAT-NEW 2024 \r\nK1AL-N81-NONISS",
			"BEAT-NEW 2024 \r\nK1AL-N91 ",
			"BEAT-NEW 2024 \r\nK1AL-NB1",
			"BEAT-NEW 2024 \r\nK1AL-NA1 KEYLESS",
			"BEAT-NEW 2024 \r\nK1AL-N81 ISS ",
			"BEAT 110 2020 \r\n(K1AA-N01)",
			"BEAT 110 2020 \r\n(K1AA-N11)",
			"STYLO 160 NEW 2023 \r\n(K3VA-N01)",
			"PCX 160 NEW 2025\r\nK1Z-NF1(BLUETOOTH)",
			"PCX 160 NEW 2025\r\nK1Z-NA1(CBS)",
			"PCX 160 NEW 2025\r\nK1Z-NC1(ABS)",
			"30400-K0WW-ND2-ADV 160 NEW",
			"30400-K2VM-N81-VARIO GEN3",
			"30400-K2VM-V51-VARIO GEN3",
			"VARIO GEN3-30400-K2VM-NA1",
			"30400-K2SM-N81-vARIO 160 GEN3"
		};

		// Token: 0x04000006 RID: 6
		private static readonly string[] shEcmId = new string[]
		{
			"01046B0F01",
			"01037B0F01",
			"01037C0D01",
			"01012F1101",
			"01012F1102",
			"01012F1103",
			"01037A0F02",
			"01037A0F03",
			"0103790F02",
			"0103790F03",
			"0104040F01",
			"0104030F01",
			"0101D40F01",
			"0101D30F01",
			"0101411101",
			"0101411102",
			"0101AB1101",
			"0101AB1102",
			"0101AB1103",
			"0101461101",
			"0101461102",
			"0101461103",
			"0102170A01",
			"0102180F01",
			"0101C40F01",
			"0102450F01",
			"0103060F01",
			"0103151801",
			"0101E20F01",
			"0101C50F01",
			"0102470F01",
			"0102460F01",
			"0103080F01",
			"0103090F01",
			"01030B0F03",
			"0102420F01",
			"0102410F01",
			"0102E30F01",
			"0102E20F01",
			"0103001101",
			"0102970701",
			"0102C70F01",
			"0103470F01",
			"0101230F01",
			"0101730F01",
			"0101690F01",
			"0101BE0F01",
			"0101AE0F01",
			"0104D90F01",
			"0104D80F01",
			"0105030F01",
			"0105020F01",
			"0104DA1F01",
			"01048D0F01",
			"01048C0F01",
			"0103CF0D01",
			"0103090F03",
			"0103060F03",
			"01058B0F11",
			"01058C0F01",
			"01058F0F01",
			"01058D0F01",
			"01058B0F01",
			"01037A0F01",
			"0103790F01",
			"0105770F01",
			"0105B60F01",
			"0105B80F01",
			"0105B70F01",
			"0106240F01",
			"0106400F01",
			"0106410F11",
			"0106410F01",
			"01065E0F01"
		};

		// Token: 0x04000007 RID: 7
		private static readonly byte[] shBinSig = new byte[]
		{
			90,
			90,
			90,
			90
		};

		// Token: 0x04000008 RID: 8
		private static readonly byte[] shStart0 = new byte[]
		{
			165,
			165,
			165,
			165,
			0
		};

		// Token: 0x04000009 RID: 9
		private static readonly byte[] shWKeysig = new byte[]
		{
			17,
			18,
			19,
			20,
			21,
			21,
			23
		};

		// Token: 0x0400000A RID: 10
		private static readonly byte[] shRKeysSig = new byte[]
		{
			145,
			145,
			13,
			0,
			158,
			141
		};

		// Token: 0x0400000B RID: 11
		private static readonly byte[] shV850Sig = new byte[]
		{
			83,
			86,
			56,
			53,
			48
		};

		// Token: 0x0400000C RID: 12
		private static readonly byte[] shRh850Sig = new byte[]
		{
			83,
			72,
			56,
			53,
			48
		};

		// Token: 0x0400000D RID: 13
		private static readonly byte[] khH8cSig = new byte[]
		{
			byte.MaxValue,
			byte.MaxValue,
			170,
			170
		};

		// Token: 0x0400000E RID: 14
		private static readonly byte[] khM32rSig = new byte[]
		{
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			170,
			170,
			170,
			170
		};

		// Token: 0x0400000F RID: 15
		private static readonly byte[] khRh850Sig = new byte[]
		{
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			0,
			0,
			0,
			0
		};

		// Token: 0x04000010 RID: 16
		private static readonly byte[] khMpc560Sig = new byte[]
		{
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue
		};

		// Token: 0x04000011 RID: 17
		private static readonly byte[] khSpc5604Sig = new byte[7];

		// Token: 0x04000012 RID: 18
		private static readonly byte[] khSH705XSig = new byte[]
		{
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			170,
			170,
			170,
			170
		};

		// Token: 0x04000013 RID: 19
		private static IntPtr ftHandle = IntPtr.Zero;

		// Token: 0x04000014 RID: 20
		private static byte[] binBytes;

		// Token: 0x04000015 RID: 21
		private static int binSize;

		// Token: 0x04000016 RID: 22
		private static int startOffset = 0;

		// Token: 0x04000017 RID: 23
		private static int checksumOffset = 0;

		// Token: 0x04000018 RID: 24
		private static bool endThread = false;

		// Token: 0x04000019 RID: 25
		private static bool isConnected = false;

		// Token: 0x0400001A RID: 26
		private static bool isNoInterface = true;

		// Token: 0x0400001B RID: 27
		private static bool isUnknown = false;

		// Token: 0x0400001C RID: 28
		private static bool isRecovery = false;

		// Token: 0x0400001D RID: 29
		private static bool isFastWrite = false;

		// Token: 0x0400001E RID: 30
		private static bool isWrite = false;

		// Token: 0x04000035 RID: 53
		private Label label1;

		// Token: 0x04000036 RID: 54
		private Label label3;

		// Token: 0x04000037 RID: 55
		private PictureBox pictureBox1;

		// Token: 0x04000038 RID: 56
		private Label labelHondaAbout;

		// Token: 0x04000039 RID: 57
		private Label labelJavaTechAbout;

		// Token: 0x0400003A RID: 58
		private Thread backgroundThread;

		// Token: 0x0400003B RID: 59
		private volatile bool stopThread;

		// Token: 0x0400003C RID: 60
		private Thread thread_0;

		// Token: 0x0400003D RID: 61
		private string responseFromCar;

		// Token: 0x0400003E RID: 62
		private static readonly object _ftdiLock;

		// Token: 0x04000044 RID: 68
		private bool ftdiMethodsAvailable;

		// Token: 0x0400004F RID: 79
		private StreamWriter _logWriter;

		// Token: 0x04000050 RID: 80
		private readonly object _logLock;

		// Token: 0x04000051 RID: 81
		private StreamWriter logWriter;

		// Token: 0x04000052 RID: 82
		private string logFilePath;

		// Token: 0x04000053 RID: 83
		private readonly object _ecuLock;

		// Token: 0x04000054 RID: 84
		private bool _ecuConnected;

		// Token: 0x04000055 RID: 85
		private bool _diagnosticRunning;

		// Token: 0x04000056 RID: 86
		private IntPtr _ftHandle;

		// Token: 0x04000057 RID: 87
		private const int KLINE_BAUD = 10400;

		// Token: 0x04000058 RID: 88
		private const int KLINE_READ_TIMEOUT = 500;

		// Token: 0x04000059 RID: 89
		private const int KLINE_WRITE_TIMEOUT = 500;

		// Token: 0x0400005A RID: 90
		private CancellationTokenSource _ecuCancellation;

		// Token: 0x0400005B RID: 91
		private string _lastEcmId;

		// Token: 0x0400005C RID: 92
		private string _lastPartCode;

		// Token: 0x0400005D RID: 93
		private int _lastFlashCount;

		// Token: 0x0400005E RID: 94
		private BlurOverlay _activeBlurOverlay;

		// Token: 0x0400005F RID: 95
		private bool _keihinResetRunning;

		// Token: 0x04000060 RID: 96
		private bool _keihinResetBlurReady;

		// Token: 0x04000061 RID: 97
		private bool _shindengenResetRunning;

		// Token: 0x04000062 RID: 98
		private const int ECU_BLOCK_SIZE = 128;

		// Token: 0x04000063 RID: 99
		private const int ECU_TIMEOUT_MS = 5000;

		// Token: 0x04000064 RID: 100
		private const byte CMD_WRITE_BLOCK = 119;

		// Token: 0x04000065 RID: 101
		private const byte CMD_ERASE = 96;

		// Token: 0x04000066 RID: 102
		private const byte CMD_VERIFY = 118;

		// Token: 0x04000067 RID: 103
		private const byte CMD_READ_BLOCK = 113;

		// Token: 0x04000068 RID: 104
		private const byte CMD_RESET = 96;

		// Token: 0x04000069 RID: 105
		private FormMain.ECUTYPE ecuType;

		// Token: 0x0400006A RID: 106
		private bool fastWrite;

		// Token: 0x0400006B RID: 107
		private bool _updateCheckedThisSession;

		// Token: 0x0400006C RID: 108
		private System.Windows.Forms.Timer _updateTimer;

		// Token: 0x0400006D RID: 109
		private static bool isCBR250RRMode;

		// Token: 0x0400006E RID: 110
		private static bool isCBR250RMode;

		// Token: 0x0400006F RID: 111
		private const int CBR250RR_FLASH_SIZE = 1048576;

		// Token: 0x04000070 RID: 112
		private const int CBR250RR_START_OFFSET = 0;

		// Token: 0x04000071 RID: 113
		private const int CBR250RR_CHECKSUM_OFFSET = 524280;

		// Token: 0x04000072 RID: 114
		private const int CBR250RR_BLOCK_SIZE = 256;

		// Token: 0x04000073 RID: 115
		private const int CBR250RR_SECTOR_SIZE = 4096;

		// Token: 0x02000003 RID: 3
		// (Invoke) Token: 0x0600015C RID: 348
		private delegate void SetControlTextCallBack(Control control, string newText);

		// Token: 0x02000004 RID: 4
		// (Invoke) Token: 0x06000160 RID: 352
		private delegate void SetComboBoxSelectionCallBack(ComboBox comboBox, int index);

		// Token: 0x02000005 RID: 5
		// (Invoke) Token: 0x06000164 RID: 356
		private delegate void SetComboBoxStateCallBack(ComboBox comboBox, bool enable);

		// Token: 0x02000006 RID: 6
		// (Invoke) Token: 0x06000168 RID: 360
		private delegate void SetProgressBarPositionCallBack(ProgressBar progressBar, int position);

		// Token: 0x02000007 RID: 7
		private enum ECUTYPE
		{
			// Token: 0x04000075 RID: 117
			KEIHINOTHER,
			// Token: 0x04000076 RID: 118
			KEIHINH8C,
			// Token: 0x04000077 RID: 119
			KEIHINM32R,
			// Token: 0x04000078 RID: 120
			SHINDENGENV850,
			// Token: 0x04000079 RID: 121
			SHINDENGENRH850,
			// Token: 0x0400007A RID: 122
			SHINDENGENRH850B
		}

		// Token: 0x02000008 RID: 8
		private enum STATUS
		{
			// Token: 0x0400007C RID: 124
			SUCCESS,
			// Token: 0x0400007D RID: 125
			FAILED
		}

		// Token: 0x020000D8 RID: 216
		private class BackupMetadata
		{
			// Token: 0x1700000B RID: 11
			// (get) Token: 0x060003A4 RID: 932 RVA: 0x0000388E File Offset: 0x0000388E
			// (set) Token: 0x060003A5 RID: 933 RVA: 0x00003896 File Offset: 0x00003896
			public string ECUID { get; set; } = "N/A";

			// Token: 0x1700000C RID: 12
			// (get) Token: 0x060003A6 RID: 934 RVA: 0x0000389F File Offset: 0x0000389F
			// (set) Token: 0x060003A7 RID: 935 RVA: 0x000038A7 File Offset: 0x000038A7
			public string PartCode { get; set; } = "N/A";

			// Token: 0x1700000D RID: 13
			// (get) Token: 0x060003A8 RID: 936 RVA: 0x000038B0 File Offset: 0x000038B0
			// (set) Token: 0x060003A9 RID: 937 RVA: 0x000038B8 File Offset: 0x000038B8
			public DateTime BackupDate { get; set; } = DateTime.Now;

			// Token: 0x1700000E RID: 14
			// (get) Token: 0x060003AA RID: 938 RVA: 0x000038C1 File Offset: 0x000038C1
			// (set) Token: 0x060003AB RID: 939 RVA: 0x000038C9 File Offset: 0x000038C9
			public long FileSize { get; set; }

			// Token: 0x1700000F RID: 15
			// (get) Token: 0x060003AC RID: 940 RVA: 0x000038D2 File Offset: 0x000038D2
			// (set) Token: 0x060003AD RID: 941 RVA: 0x000038DA File Offset: 0x000038DA
			public string SoftwareVersion { get; set; } = "N/A";

			// Token: 0x17000010 RID: 16
			// (get) Token: 0x060003AE RID: 942 RVA: 0x000038E3 File Offset: 0x000038E3
			// (set) Token: 0x060003AF RID: 943 RVA: 0x000038EB File Offset: 0x000038EB
			public string VIN { get; set; } = "N/A";

			// Token: 0x17000011 RID: 17
			// (get) Token: 0x060003B0 RID: 944 RVA: 0x000038F4 File Offset: 0x000038F4
			// (set) Token: 0x060003B1 RID: 945 RVA: 0x000038FC File Offset: 0x000038FC
			public string Checksum { get; set; } = "N/A";
		}

		// Token: 0x020000D9 RID: 217
		private class MotorBackupMetadata
		{
			// Token: 0x17000012 RID: 18
			// (get) Token: 0x060003B3 RID: 947 RVA: 0x00003905 File Offset: 0x00003905
			// (set) Token: 0x060003B4 RID: 948 RVA: 0x0000390D File Offset: 0x0000390D
			public string MotorModel { get; set; } = "N/A";

			// Token: 0x17000013 RID: 19
			// (get) Token: 0x060003B5 RID: 949 RVA: 0x00003916 File Offset: 0x00003916
			// (set) Token: 0x060003B6 RID: 950 RVA: 0x0000391E File Offset: 0x0000391E
			public string ECUCode { get; set; } = "N/A";

			// Token: 0x17000014 RID: 20
			// (get) Token: 0x060003B7 RID: 951 RVA: 0x00003927 File Offset: 0x00003927
			// (set) Token: 0x060003B8 RID: 952 RVA: 0x0000392F File Offset: 0x0000392F
			public string Year { get; set; } = "N/A";

			// Token: 0x17000015 RID: 21
			// (get) Token: 0x060003B9 RID: 953 RVA: 0x00003938 File Offset: 0x00003938
			// (set) Token: 0x060003BA RID: 954 RVA: 0x00003940 File Offset: 0x00003940
			public int EngineCC { get; set; }

			// Token: 0x17000016 RID: 22
			// (get) Token: 0x060003BB RID: 955 RVA: 0x00003949 File Offset: 0x00003949
			// (set) Token: 0x060003BC RID: 956 RVA: 0x00003951 File Offset: 0x00003951
			public string FuelType { get; set; } = "N/A";

			// Token: 0x17000017 RID: 23
			// (get) Token: 0x060003BD RID: 957 RVA: 0x0000395A File Offset: 0x0000395A
			// (set) Token: 0x060003BE RID: 958 RVA: 0x00003962 File Offset: 0x00003962
			public long FileSize { get; set; }

			// Token: 0x17000018 RID: 24
			// (get) Token: 0x060003BF RID: 959 RVA: 0x0000396B File Offset: 0x0000396B
			// (set) Token: 0x060003C0 RID: 960 RVA: 0x00003973 File Offset: 0x00003973
			public DateTime BackupDate { get; set; } = DateTime.Now;

			// Token: 0x17000019 RID: 25
			// (get) Token: 0x060003C1 RID: 961 RVA: 0x0000397C File Offset: 0x0000397C
			// (set) Token: 0x060003C2 RID: 962 RVA: 0x00003984 File Offset: 0x00003984
			public string FileType { get; set; } = "BIN";

			// Token: 0x1700001A RID: 26
			// (get) Token: 0x060003C3 RID: 963 RVA: 0x0000398D File Offset: 0x0000398D
			// (set) Token: 0x060003C4 RID: 964 RVA: 0x00003995 File Offset: 0x00003995
			public string Checksum { get; set; } = "N/A";

			// Token: 0x1700001B RID: 27
			// (get) Token: 0x060003C5 RID: 965 RVA: 0x0000399E File Offset: 0x0000399E
			// (set) Token: 0x060003C6 RID: 966 RVA: 0x000039A6 File Offset: 0x000039A6
			public string SoftwareVersion { get; set; } = "N/A";
		}

		// Token: 0x020000DA RID: 218
		private enum CompatibilityLevel
		{
			// Token: 0x04000241 RID: 577
			HIGH,
			// Token: 0x04000242 RID: 578
			MEDIUM,
			// Token: 0x04000243 RID: 579
			LOW,
			// Token: 0x04000244 RID: 580
			CRITICAL
		}

		// Token: 0x020000FE RID: 254
		// (Invoke) Token: 0x06000431 RID: 1073
		private delegate void UpdateLogDelegate(string message);

		// Token: 0x020000FF RID: 255
		public class FTDI
		{
			// Token: 0x06000434 RID: 1076 RVA: 0x000026F4 File Offset: 0x000026F4
			public static void FT_Close(IntPtr handle)
			{
			}
		}
	}
}
