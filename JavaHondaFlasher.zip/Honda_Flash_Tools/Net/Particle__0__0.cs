﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000751 RID: 1873
	public class Particle__0__0
	{
		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x0600117D RID: 4477 RVA: 0x0000B903 File Offset: 0x0000B903
		// (set) Token: 0x0600117E RID: 4478 RVA: 0x0000B90B File Offset: 0x0000B90B
		public float X { get; set; }

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x0600117F RID: 4479 RVA: 0x0000B914 File Offset: 0x0000B914
		// (set) Token: 0x06001180 RID: 4480 RVA: 0x0000B91C File Offset: 0x0000B91C
		public float Y { get; set; }

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x06001181 RID: 4481 RVA: 0x0000B925 File Offset: 0x0000B925
		// (set) Token: 0x06001182 RID: 4482 RVA: 0x0000B92D File Offset: 0x0000B92D
		public float VX { get; set; }

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x06001183 RID: 4483 RVA: 0x0000B936 File Offset: 0x0000B936
		// (set) Token: 0x06001184 RID: 4484 RVA: 0x0000B93E File Offset: 0x0000B93E
		public float VY { get; set; }

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x06001185 RID: 4485 RVA: 0x0000B947 File Offset: 0x0000B947
		// (set) Token: 0x06001186 RID: 4486 RVA: 0x0000B94F File Offset: 0x0000B94F
		public float Life { get; set; }

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x06001187 RID: 4487 RVA: 0x0000B958 File Offset: 0x0000B958
		// (set) Token: 0x06001188 RID: 4488 RVA: 0x0000B960 File Offset: 0x0000B960
		public float MaxLife { get; set; }

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x06001189 RID: 4489 RVA: 0x0000B969 File Offset: 0x0000B969
		// (set) Token: 0x0600118A RID: 4490 RVA: 0x0000B971 File Offset: 0x0000B971
		public float Size { get; set; }

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x0600118B RID: 4491 RVA: 0x0000B97A File Offset: 0x0000B97A
		// (set) Token: 0x0600118C RID: 4492 RVA: 0x0000B982 File Offset: 0x0000B982
		public float Rotation { get; set; }
	}
}
