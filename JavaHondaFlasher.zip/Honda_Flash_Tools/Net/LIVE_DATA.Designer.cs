﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000678 RID: 1656
	public partial class LIVE_DATA : global::System.Windows.Forms.Form
	{
		// Token: 0x06000FC3 RID: 4035 RVA: 0x0000AAD1 File Offset: 0x0000AAD1
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000FC4 RID: 4036 RVA: 0x00072EF4 File Offset: 0x00072EF4
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Honda_Flash_Tools.Net.MainForm));
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.BackColor = global::Honda_Flash_Tools.Net.LIVE_DATA.BgDark;
			this.DoubleBuffered = true;
			base.SetStyle(global::System.Windows.Forms.ControlStyles.UserPaint | global::System.Windows.Forms.ControlStyles.ResizeRedraw | global::System.Windows.Forms.ControlStyles.AllPaintingInWmPaint | global::System.Windows.Forms.ControlStyles.OptimizedDoubleBuffer, true);
			base.ClientSize = new global::System.Drawing.Size(1360, 720);
			base.Name = "LIVE_DATA";
			this.Text = "DIAGNOSTIC TOOL - REMAPPING MODE";
			base.Padding = new global::System.Windows.Forms.Padding(12);
			this.SerialPort_0 = new global::System.IO.Ports.SerialPort(this.components);
			this.Timer_0 = new global::System.Windows.Forms.Timer(this.components);
			global::System.Windows.Forms.Panel header = new global::System.Windows.Forms.Panel
			{
				Dock = global::System.Windows.Forms.DockStyle.Top,
				Height = 70,
				Padding = new global::System.Windows.Forms.Padding(25, 16, 25, 16),
				BackColor = global::System.Drawing.Color.FromArgb(14, 20, 28)
			};
			global::System.Windows.Forms.Label label = new global::System.Windows.Forms.Label
			{
				Text = "LIVE DATA  •  ECU TELEMETRY",
				Font = new global::System.Drawing.Font("Segoe UI", 18f, global::System.Drawing.FontStyle.Bold),
				ForeColor = global::Honda_Flash_Tools.Net.LIVE_DATA.NeonCyan,
				AutoSize = true,
				Location = new global::System.Drawing.Point(25, 12)
			};
			global::System.Windows.Forms.Label label2 = new global::System.Windows.Forms.Label
			{
				Text = "Real-time parameter monitoring  •  Remapping mode",
				Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Italic),
				ForeColor = global::Honda_Flash_Tools.Net.LIVE_DATA.TextSoft,
				AutoSize = true,
				Location = new global::System.Drawing.Point(27, 42)
			};
			this.stsSNCable = new global::System.Windows.Forms.Label
			{
				Text = "Cable: —",
				Font = new global::System.Drawing.Font("Segoe UI Semibold", 10f),
				ForeColor = global::Honda_Flash_Tools.Net.LIVE_DATA.NeonAmber,
				AutoSize = true,
				Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right),
				Location = new global::System.Drawing.Point(1250, 25)
			};
			header.Controls.AddRange(new global::System.Windows.Forms.Control[]
			{
				label,
				label2,
				this.stsSNCable
			});
			checked
			{
				header.Resize += delegate(object s, global::System.EventArgs e)
				{
					this.stsSNCable.Location = new global::System.Drawing.Point(header.Width - this.stsSNCable.Width - 70, 25);
				};
				this.txtCOMName = new global::System.Windows.Forms.Label
				{
					Visible = false
				};
				header.Controls.Add(this.txtCOMName);
				base.Controls.Add(header);
				global::System.Windows.Forms.TableLayoutPanel tableLayoutPanel = new global::System.Windows.Forms.TableLayoutPanel
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					Padding = new global::System.Windows.Forms.Padding(15),
					ColumnCount = 2,
					RowCount = 1,
					BackColor = global::Honda_Flash_Tools.Net.LIVE_DATA.BgDark
				};
				tableLayoutPanel.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Absolute, 360f));
				tableLayoutPanel.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Percent, 100f));
				base.Controls.Add(tableLayoutPanel);
				tableLayoutPanel.BringToFront();
				global::System.Windows.Forms.Panel panel = new global::System.Windows.Forms.Panel
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					BackColor = global::Honda_Flash_Tools.Net.LIVE_DATA.BgDark,
					Padding = new global::System.Windows.Forms.Padding(6)
				};
				tableLayoutPanel.Controls.Add(panel, 0, 0);
				this.rpmGaugePanel = new global::System.Windows.Forms.Panel
				{
					Dock = global::System.Windows.Forms.DockStyle.Top,
					Height = 300,
					BackColor = global::Honda_Flash_Tools.Net.LIVE_DATA.BgDark
				};
				this.tpsGaugePanel = new global::System.Windows.Forms.Panel
				{
					Dock = global::System.Windows.Forms.DockStyle.Top,
					Height = 300,
					BackColor = global::Honda_Flash_Tools.Net.LIVE_DATA.BgDark
				};
				panel.Controls.Add(this.tpsGaugePanel);
				panel.Controls.Add(this.rpmGaugePanel);
				global::System.Windows.Forms.Panel panel2 = new global::System.Windows.Forms.Panel
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					BackColor = global::Honda_Flash_Tools.Net.LIVE_DATA.BgDark,
					Padding = new global::System.Windows.Forms.Padding(6)
				};
				tableLayoutPanel.Controls.Add(panel2, 1, 0);
				global::System.Windows.Forms.TableLayoutPanel tableLayoutPanel2 = new global::System.Windows.Forms.TableLayoutPanel
				{
					Dock = global::System.Windows.Forms.DockStyle.Top,
					Height = 140,
					ColumnCount = 2,
					RowCount = 1,
					BackColor = global::Honda_Flash_Tools.Net.LIVE_DATA.BgDark
				};
				tableLayoutPanel2.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Percent, 50f));
				tableLayoutPanel2.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Percent, 50f));
				panel2.Controls.Add(tableLayoutPanel2);
				this.label_rpm = this.MakeBigValueLabel(global::Honda_Flash_Tools.Net.LIVE_DATA.NeonGreen);
				this.TPS = this.MakeBigValueLabel(global::Honda_Flash_Tools.Net.LIVE_DATA.NeonCyan);
				tableLayoutPanel2.Controls.Add(this.MakeCard("ENGINE RPM", this.label_rpm, "\ud83d\udcc8"), 0, 0);
				tableLayoutPanel2.Controls.Add(this.MakeCard("THROTTLE POS", this.TPS, "\ud83c\udfaf"), 1, 0);
				global::System.Windows.Forms.TableLayoutPanel tableLayoutPanel3 = new global::System.Windows.Forms.TableLayoutPanel
				{
					Dock = global::System.Windows.Forms.DockStyle.Fill,
					Padding = new global::System.Windows.Forms.Padding(0, 12, 0, 0),
					ColumnCount = 4,
					RowCount = 5,
					BackColor = global::Honda_Flash_Tools.Net.LIVE_DATA.BgDark
				};
				for (int i = 0; i < 4; i++)
				{
					tableLayoutPanel3.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Percent, 25f));
				}
				for (int j = 0; j < 5; j++)
				{
					tableLayoutPanel3.RowStyles.Add(new global::System.Windows.Forms.RowStyle(global::System.Windows.Forms.SizeType.Percent, 20f));
				}
				panel2.Controls.Add(tableLayoutPanel3);
				tableLayoutPanel3.BringToFront();
				this.label_injector = this.MakeSmallValueLabel();
				this.label_ignition = this.MakeSmallValueLabel();
				this.label_suhu = this.MakeSmallValueLabel();
				this.label_afr = this.MakeSmallValueLabel();
				this.label_tps_volt = this.MakeSmallValueLabel();
				this.label_O2_volt = this.MakeSmallValueLabel();
				this.label_iat_volt = this.MakeSmallValueLabel();
				this.label_iat_temp = this.MakeSmallValueLabel();
				this.label_map = this.MakeSmallValueLabel();
				this.label_map_volt = this.MakeSmallValueLabel();
				this.ect_volt = this.MakeSmallValueLabel();
				this.label_batrei = this.MakeSmallValueLabel();
				this.label_fuel_flow = this.MakeSmallValueLabel();
				this.label_coeffisient = this.MakeSmallValueLabel();
				this.label_iacv = this.MakeSmallValueLabel();
				this.label_fuelpump = this.MakeSmallValueLabel();
				this.label_stand_samping = this.MakeSmallValueLabel();
				this.label_stater = this.MakeSmallValueLabel();
				this.label_relay = this.MakeSmallValueLabel();
				this.label_miL = this.MakeSmallValueLabel();
				this.txtMaxRPM = this.MakeSmallValueLabel();
				int num = 0;
				tableLayoutPanel3.Controls.Add(this.MakeCard("INJECTOR", this.label_injector, "\ud83d\udc89"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("IGNITION", this.label_ignition, "⚡"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("ENGINE TEMP", this.label_suhu, "\ud83c\udf21"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("AFR", this.label_afr, "\ud83d\udd04"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("TPS VOLT", this.label_tps_volt, "\ud83d\udcc8"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("O2 VOLT", this.label_O2_volt, "\ud83d\udd0b"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("IAT VOLT", this.label_iat_volt, "⚡"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("IAT TEMP", this.label_iat_temp, "\ud83c\udf21"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("MAP", this.label_map, "\ud83d\udcca"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("MAP VOLT", this.label_map_volt, "⚡"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("ECT VOLT", this.ect_volt, "\ud83c\udf21"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("BATTERY", this.label_batrei, "\ud83d\udd0b"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("FUEL FLOW", this.label_fuel_flow, "\ud83d\udca7"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("COEF", this.label_coeffisient, "\ud83d\udcca"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("IACV", this.label_iacv, "⚙"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("FUEL PUMP", this.label_fuelpump, "⛽"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("SIDE STAND", this.label_stand_samping, "\ud83d\udef5"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("STARTER", this.label_stater, "⚡"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("RELAY", this.label_relay, "\ud83d\udd0c"), num % 4, num / 4);
				num++;
				tableLayoutPanel3.Controls.Add(this.MakeCard("MIL", this.label_miL, "\ud83d\udca1"), num % 4, num / 4);
				this.label1 = new global::System.Windows.Forms.Label
				{
					Visible = false
				};
				this.label2 = new global::System.Windows.Forms.Label
				{
					Visible = false
				};
				this.txtCurrentTPS = new global::System.Windows.Forms.TextBox
				{
					Visible = false
				};
				this.txtMaxTPS = new global::System.Windows.Forms.TextBox
				{
					Visible = false
				};
				this.comGraphTPS = new global::System.Windows.Forms.ComboBox
				{
					Visible = false
				};
				this.comGraphTPS.SelectedIndexChanged += new global::System.EventHandler(this.comGraphTPS_SelectedIndexChanged);
				this.panel1 = new global::System.Windows.Forms.Panel
				{
					Visible = false
				};
				base.Controls.AddRange(new global::System.Windows.Forms.Control[]
				{
					this.txtCurrentTPS,
					this.txtMaxTPS,
					this.comGraphTPS,
					this.label1,
					this.label2,
					this.panel1
				});
				this.Timer_0.Tick += new global::System.EventHandler(this.Timer_0_Tick);
				base.FormClosed += new global::System.Windows.Forms.FormClosedEventHandler(this.LIVE_DATA_FormClosed);
				base.Load += new global::System.EventHandler(this.LIVE_DATA_Load);
			}
		}

		// Token: 0x040014C3 RID: 5315
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040014C4 RID: 5316
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040014C5 RID: 5317
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x040014C6 RID: 5318
		private global::System.Windows.Forms.Label label_rpm;

		// Token: 0x040014C7 RID: 5319
		private global::System.Windows.Forms.Label TPS;

		// Token: 0x040014C8 RID: 5320
		private global::System.Windows.Forms.Label label_injector;

		// Token: 0x040014C9 RID: 5321
		private global::System.Windows.Forms.Label label_ignition;

		// Token: 0x040014CA RID: 5322
		private global::System.Windows.Forms.Label label_afr;

		// Token: 0x040014CB RID: 5323
		private global::System.Windows.Forms.Label label_suhu;

		// Token: 0x040014CC RID: 5324
		private global::System.Windows.Forms.Label label_batrei;

		// Token: 0x040014CD RID: 5325
		private global::System.Windows.Forms.Label label_map;

		// Token: 0x040014CE RID: 5326
		private global::System.Windows.Forms.Label label_O2_volt;

		// Token: 0x040014CF RID: 5327
		private global::System.Windows.Forms.Label label_tps_volt;

		// Token: 0x040014D0 RID: 5328
		private global::System.Windows.Forms.Label label_iat_temp;

		// Token: 0x040014D1 RID: 5329
		private global::System.Windows.Forms.Label label_iat_volt;

		// Token: 0x040014D2 RID: 5330
		private global::System.Windows.Forms.Label label_fuel_flow;

		// Token: 0x040014D3 RID: 5331
		private global::System.Windows.Forms.Label label_fuelpump;

		// Token: 0x040014D4 RID: 5332
		private global::System.Windows.Forms.Label label_stand_samping;

		// Token: 0x040014D5 RID: 5333
		private global::System.Windows.Forms.Label label_stater;

		// Token: 0x040014D6 RID: 5334
		private global::System.Windows.Forms.Label label_relay;

		// Token: 0x040014D7 RID: 5335
		private global::System.Windows.Forms.Label label_miL;

		// Token: 0x040014D8 RID: 5336
		private global::System.Windows.Forms.Label label_iacv;

		// Token: 0x040014D9 RID: 5337
		private global::System.Windows.Forms.Label label_coeffisient;

		// Token: 0x040014DA RID: 5338
		private global::System.Windows.Forms.Label ect_volt;

		// Token: 0x040014DB RID: 5339
		private global::System.Windows.Forms.Label label_map_volt;

		// Token: 0x040014DC RID: 5340
		private global::System.Windows.Forms.Label txtMaxRPM;

		// Token: 0x040014DD RID: 5341
		private global::System.Windows.Forms.Label txtCOMName;

		// Token: 0x040014DE RID: 5342
		private global::System.Windows.Forms.Label stsSNCable;

		// Token: 0x040014DF RID: 5343
		private global::System.Windows.Forms.TextBox txtCurrentTPS;

		// Token: 0x040014E0 RID: 5344
		private global::System.Windows.Forms.TextBox txtMaxTPS;

		// Token: 0x040014E1 RID: 5345
		private global::System.Windows.Forms.ComboBox comGraphTPS;

		// Token: 0x040014E2 RID: 5346
		private global::System.IO.Ports.SerialPort SerialPort_0;

		// Token: 0x040014E3 RID: 5347
		private global::System.Windows.Forms.Timer Timer_0;

		// Token: 0x040014E4 RID: 5348
		private global::System.Windows.Forms.Label label2;

		// Token: 0x04001507 RID: 5383
		private static readonly global::System.Drawing.Color BgDark = global::System.Drawing.Color.FromArgb(10, 14, 22);

		// Token: 0x0400150A RID: 5386
		private static readonly global::System.Drawing.Color NeonCyan = global::System.Drawing.Color.FromArgb(0, 255, 220);

		// Token: 0x0400150B RID: 5387
		private static readonly global::System.Drawing.Color NeonAmber = global::System.Drawing.Color.FromArgb(255, 180, 0);

		// Token: 0x0400150D RID: 5389
		private static readonly global::System.Drawing.Color NeonGreen = global::System.Drawing.Color.FromArgb(0, 255, 140);

		// Token: 0x0400150E RID: 5390
		private static readonly global::System.Drawing.Color TextSoft = global::System.Drawing.Color.FromArgb(150, 170, 190);

		// Token: 0x04001511 RID: 5393
		private global::System.Windows.Forms.Panel rpmGaugePanel;

		// Token: 0x04001512 RID: 5394
		private global::System.Windows.Forms.Panel tpsGaugePanel;
	}
}
