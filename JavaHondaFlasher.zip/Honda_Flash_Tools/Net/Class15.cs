﻿using System;
using System.Runtime.InteropServices;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000399 RID: 921
	public static class Class15
	{
		// Token: 0x06000C2B RID: 3115
		[DllImport("ftd2xx.dll")]
		public static extern uint FT_Open(uint uiPort, ref IntPtr ftHandle);

		// Token: 0x06000C2C RID: 3116
		[DllImport("ftd2xx.dll")]
		public static extern uint FT_Close(IntPtr ftHandle);

		// Token: 0x06000C2D RID: 3117
		[DllImport("ftd2xx.dll")]
		public static extern uint FT_Purge(IntPtr ftHandle, uint dwMask);

		// Token: 0x06000C2E RID: 3118
		[DllImport("ftd2xx.dll")]
		public static extern uint FT_SetBitMode(IntPtr ftHandle, byte ucMask, byte ucMode);

		// Token: 0x06000C2F RID: 3119
		[DllImport("ftd2xx.dll")]
		public static extern uint FT_SetDataCharacteristics(IntPtr ftHandle, byte uWordLength, byte uStopBits, byte uParity);

		// Token: 0x06000C30 RID: 3120
		[DllImport("ftd2xx.dll")]
		public static extern uint FT_SetBaudRate(IntPtr ftHandle, uint dwBaudRate);

		// Token: 0x06000C31 RID: 3121
		[DllImport("ftd2xx.dll")]
		public static extern uint FT_SetTimeouts(IntPtr ftHandle, uint dwReadTimeout, uint dwWriteTimeout);

		// Token: 0x06000C32 RID: 3122
		[DllImport("ftd2xx.dll")]
		public static extern uint FT_SetLatencyTimer(IntPtr ftHandle, byte ucTimer);

		// Token: 0x06000C33 RID: 3123
		[DllImport("ftd2xx.dll")]
		public static extern uint FT_Write(IntPtr ftHandle, byte[] lpBuffer, uint dwBytesToWrite, ref uint lpdwBytesWritten);

		// Token: 0x06000C34 RID: 3124
		[DllImport("ftd2xx.dll")]
		public static extern uint FT_Read(IntPtr ftHandle, byte[] lpBuffer, uint dwBytesToRead, ref uint lpdwBytesReturned);

		// Token: 0x06000C35 RID: 3125
		[DllImport("ftd2xx.dll")]
		public static extern uint FT_GetQueueStatus(IntPtr ftHandle, ref uint lpdwAmountInRxQueue);

		// Token: 0x06000C36 RID: 3126
		[DllImport("ftd2xx.dll")]
		public static extern uint FT_ResetDevice(IntPtr ftHandle);

		// Token: 0x06000C37 RID: 3127
		[DllImport("ftd2xx.dll")]
		public static extern uint FT_SetChars(IntPtr ftHandle, byte uEventCh, byte uEventChEn, byte uErrorCh, byte uErrorChEn);

		// Token: 0x06000C38 RID: 3128
		[DllImport("ftd2xx.dll")]
		public static extern uint FT_SetFlowControl(IntPtr ftHandle, ushort usFlowControl, byte uXon, byte uXoff);

		// Token: 0x0200039A RID: 922
		public enum Enum5
		{
			// Token: 0x04000E19 RID: 3609
			const_0
		}
	}
}
