﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000718 RID: 1816
	public partial class ActivationForm : global::System.Windows.Forms.Form
	{
	}
}
