﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020005E3 RID: 1507
	public class RoundedGroupBox : GroupBox
	{
		// Token: 0x17000035 RID: 53
		// (get) Token: 0x06000E5E RID: 3678 RVA: 0x00009E06 File Offset: 0x00009E06
		// (set) Token: 0x06000E5F RID: 3679 RVA: 0x00009E0E File Offset: 0x00009E0E
		public int CornerRadius
		{
			get
			{
				return this._cornerRadius;
			}
			set
			{
				this._cornerRadius = value;
				if (base.IsHandleCreated && base.Width > 0 && base.Height > 0)
				{
					this.UpdateRegion();
				}
				base.Invalidate();
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x06000E60 RID: 3680 RVA: 0x00009E3D File Offset: 0x00009E3D
		// (set) Token: 0x06000E61 RID: 3681 RVA: 0x00009E45 File Offset: 0x00009E45
		public Color BorderColor
		{
			get
			{
				return this._borderColor;
			}
			set
			{
				this._borderColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000E62 RID: 3682 RVA: 0x00009E54 File Offset: 0x00009E54
		// (set) Token: 0x06000E63 RID: 3683 RVA: 0x00009E5C File Offset: 0x00009E5C
		public float BorderWidth
		{
			get
			{
				return this._borderWidth;
			}
			set
			{
				this._borderWidth = value;
				base.Invalidate();
			}
		}

		// Token: 0x06000E64 RID: 3684 RVA: 0x00069FC4 File Offset: 0x00069FC4
		public RoundedGroupBox()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.BackColor = Color.Transparent;
		}

		// Token: 0x06000E65 RID: 3685 RVA: 0x0006A028 File Offset: 0x0006A028
		protected override void OnPaint(PaintEventArgs e)
		{
			if (base.Width <= 0 || base.Height <= 0 || base.IsDisposed)
			{
				return;
			}
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			e.Graphics.PixelOffsetMode = PixelOffsetMode.Half;
			Color color;
			try
			{
				Control parent = base.Parent;
				color = ((parent != null) ? parent.BackColor : this._innerBackColor);
				if (color == Color.Transparent || color.A == 0)
				{
					color = this._innerBackColor;
				}
			}
			catch
			{
				color = this._innerBackColor;
			}
			e.Graphics.Clear(color);
			int num = Math.Min(this._cornerRadius, Math.Min(base.Width, base.Height) / 2);
			if (num <= 0)
			{
				num = 1;
			}
			using (GraphicsPath graphicsPath = RoundedHelper.RoundedRect(new Rectangle(0, 0, base.Width - 1, base.Height - 1), num))
			{
				using (SolidBrush solidBrush = new SolidBrush(this._innerBackColor))
				{
					e.Graphics.FillPath(solidBrush, graphicsPath);
				}
				if (this._borderWidth > 0f && this._borderColor != Color.Empty && this._borderColor.A > 0)
				{
					using (Pen pen = new Pen(this._borderColor, this._borderWidth))
					{
						pen.Alignment = PenAlignment.Center;
						pen.LineJoin = LineJoin.Round;
						e.Graphics.DrawPath(pen, graphicsPath);
					}
				}
			}
			if (!string.IsNullOrEmpty(this.Text))
			{
				SizeF sizeF = e.Graphics.MeasureString(this.Text, this.Font);
				float num2 = 14f;
				float y = 2f;
				RectangleF rect = new RectangleF(num2 - 3f, y, sizeF.Width + 6f, sizeF.Height);
				using (SolidBrush solidBrush2 = new SolidBrush(this._innerBackColor))
				{
					e.Graphics.FillRectangle(solidBrush2, rect);
				}
				using (SolidBrush solidBrush3 = new SolidBrush(this.ForeColor))
				{
					e.Graphics.DrawString(this.Text, this.Font, solidBrush3, num2, y);
				}
			}
		}

		// Token: 0x06000E66 RID: 3686 RVA: 0x00009E6B File Offset: 0x00009E6B
		protected override void OnHandleCreated(EventArgs e)
		{
			base.OnHandleCreated(e);
			this.UpdateRegion();
		}

		// Token: 0x06000E67 RID: 3687 RVA: 0x00009E7A File Offset: 0x00009E7A
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.UpdateRegion();
		}

		// Token: 0x06000E68 RID: 3688 RVA: 0x0006A2A0 File Offset: 0x0006A2A0
		private void UpdateRegion()
		{
			if (base.IsDisposed)
			{
				return;
			}
			if (base.Width <= 0 || base.Height <= 0)
			{
				return;
			}
			if (this._cornerRadius <= 0)
			{
				return;
			}
			try
			{
				RoundedHelper.SetRegion(this, this._cornerRadius);
			}
			catch
			{
			}
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000E69 RID: 3689 RVA: 0x00009E89 File Offset: 0x00009E89
		// (set) Token: 0x06000E6A RID: 3690 RVA: 0x00009E91 File Offset: 0x00009E91
		public Color InnerBackColor
		{
			get
			{
				return this._innerBackColor;
			}
			set
			{
				this._innerBackColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x04001369 RID: 4969
		private int _cornerRadius = 10;

		// Token: 0x0400136A RID: 4970
		private Color _borderColor = Color.FromArgb(0, 255, 230);

		// Token: 0x0400136B RID: 4971
		private float _borderWidth = 1.2f;

		// Token: 0x0400136C RID: 4972
		private Color _innerBackColor = Color.FromArgb(18, 23, 29);
	}
}
