﻿using System;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000352 RID: 850
	public static class Interaction
	{
		// Token: 0x06000B63 RID: 2915 RVA: 0x00051498 File Offset: 0x00051498
		public static DialogResult MsgBox(string prompt, MsgBoxStyle buttons = MsgBoxStyle.OkOnly, string title = null)
		{
			MessageBoxButtons buttons2 = MessageBoxButtons.OK;
			switch (buttons)
			{
			case MsgBoxStyle.OkOnly:
				buttons2 = MessageBoxButtons.OK;
				break;
			case MsgBoxStyle.OkCancel:
				buttons2 = MessageBoxButtons.OKCancel;
				break;
			case MsgBoxStyle.YesNo:
				buttons2 = MessageBoxButtons.YesNo;
				break;
			case MsgBoxStyle.YesNoCancel:
				buttons2 = MessageBoxButtons.YesNoCancel;
				break;
			}
			return MessageBox.Show(prompt, title ?? string.Empty, buttons2);
		}
	}
}
