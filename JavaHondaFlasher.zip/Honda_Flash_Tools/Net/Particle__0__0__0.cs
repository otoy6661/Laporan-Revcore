﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200096A RID: 2410
	public class Particle__0__0__0
	{
		// Token: 0x1700019D RID: 413
		// (get) Token: 0x06001AA1 RID: 6817 RVA: 0x0000FEB8 File Offset: 0x0000FEB8
		// (set) Token: 0x06001AA2 RID: 6818 RVA: 0x0000FEC0 File Offset: 0x0000FEC0
		public float X { get; set; }

		// Token: 0x1700019E RID: 414
		// (get) Token: 0x06001AA3 RID: 6819 RVA: 0x0000FEC9 File Offset: 0x0000FEC9
		// (set) Token: 0x06001AA4 RID: 6820 RVA: 0x0000FED1 File Offset: 0x0000FED1
		public float Y { get; set; }

		// Token: 0x1700019F RID: 415
		// (get) Token: 0x06001AA5 RID: 6821 RVA: 0x0000FEDA File Offset: 0x0000FEDA
		// (set) Token: 0x06001AA6 RID: 6822 RVA: 0x0000FEE2 File Offset: 0x0000FEE2
		public float VX { get; set; }

		// Token: 0x170001A0 RID: 416
		// (get) Token: 0x06001AA7 RID: 6823 RVA: 0x0000FEEB File Offset: 0x0000FEEB
		// (set) Token: 0x06001AA8 RID: 6824 RVA: 0x0000FEF3 File Offset: 0x0000FEF3
		public float VY { get; set; }

		// Token: 0x170001A1 RID: 417
		// (get) Token: 0x06001AA9 RID: 6825 RVA: 0x0000FEFC File Offset: 0x0000FEFC
		// (set) Token: 0x06001AAA RID: 6826 RVA: 0x0000FF04 File Offset: 0x0000FF04
		public float Life { get; set; }

		// Token: 0x170001A2 RID: 418
		// (get) Token: 0x06001AAB RID: 6827 RVA: 0x0000FF0D File Offset: 0x0000FF0D
		// (set) Token: 0x06001AAC RID: 6828 RVA: 0x0000FF15 File Offset: 0x0000FF15
		public float MaxLife { get; set; }

		// Token: 0x170001A3 RID: 419
		// (get) Token: 0x06001AAD RID: 6829 RVA: 0x0000FF1E File Offset: 0x0000FF1E
		// (set) Token: 0x06001AAE RID: 6830 RVA: 0x0000FF26 File Offset: 0x0000FF26
		public float Size { get; set; }

		// Token: 0x170001A4 RID: 420
		// (get) Token: 0x06001AAF RID: 6831 RVA: 0x0000FF2F File Offset: 0x0000FF2F
		// (set) Token: 0x06001AB0 RID: 6832 RVA: 0x0000FF37 File Offset: 0x0000FF37
		public float Rotation { get; set; }
	}
}
