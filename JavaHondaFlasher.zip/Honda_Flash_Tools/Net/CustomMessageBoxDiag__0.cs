﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200063A RID: 1594
	public static class CustomMessageBoxDiag__0
	{
		// Token: 0x06000F64 RID: 3940 RVA: 0x0006E4C4 File Offset: 0x0006E4C4
		public static DialogResult Show(string text, string caption, MessageBoxButtons buttons = MessageBoxButtons.OK, MessageBoxIcon icon = MessageBoxIcon.None)
		{
			DialogResult result;
			using (Form form = new Form())
			{
				form.Text = caption;
				form.FormBorderStyle = FormBorderStyle.None;
				form.StartPosition = FormStartPosition.CenterParent;
				form.BackColor = Color.FromArgb(20, 25, 40);
				form.Size = new Size(400, 200);
				form.ShowInTaskbar = false;
				form.KeyPreview = true;
				Panel panel = new Panel
				{
					Dock = DockStyle.Fill,
					BackColor = Color.FromArgb(45, 50, 65),
					Padding = new Padding(3)
				};
				Button btnClose = new Button
				{
					Text = "✕",
					Size = new Size(28, 28),
					Location = new Point(form.Width - 38, 8),
					FlatStyle = FlatStyle.Flat,
					BackColor = Color.FromArgb(45, 50, 65),
					ForeColor = Color.Cyan,
					Font = new Font("Segoe UI", 10f, FontStyle.Bold),
					Cursor = Cursors.Hand,
					TabStop = false
				};
				btnClose.FlatAppearance.BorderSize = 0;
				btnClose.FlatAppearance.MouseOverBackColor = Color.FromArgb(220, 50, 50);
				btnClose.FlatAppearance.MouseDownBackColor = Color.FromArgb(180, 30, 30);
				btnClose.Click += delegate(object s, EventArgs e)
				{
					form.DialogResult = DialogResult.Cancel;
					form.Close();
				};
				btnClose.MouseEnter += delegate(object s, EventArgs e)
				{
					btnClose.ForeColor = Color.White;
				};
				btnClose.MouseLeave += delegate(object s, EventArgs e)
				{
					btnClose.ForeColor = Color.Cyan;
				};
				Label label = new Label
				{
					Text = caption,
					ForeColor = Color.Cyan,
					Font = new Font("Segoe UI", 9f, FontStyle.Bold),
					AutoSize = false,
					TextAlign = ContentAlignment.MiddleLeft,
					Location = new Point(15, 10),
					Size = new Size(form.Width - 60, 22)
				};
				Label value = new Label
				{
					Text = text,
					ForeColor = Color.Cyan,
					Font = new Font("Segoe UI", 9f),
					AutoSize = false,
					TextAlign = ContentAlignment.MiddleCenter,
					Location = new Point(15, 45),
					Size = new Size(form.Width - 30, 100)
				};
				FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
				{
					Location = new Point(0, form.Height - 55),
					Size = new Size(form.Width, 50),
					FlowDirection = FlowDirection.RightToLeft,
					BackColor = Color.Transparent,
					Padding = new Padding(0, 8, 15, 8)
				};
				Button btnOk = new Button
				{
					Text = "OK",
					Size = new Size(80, 28),
					FlatStyle = FlatStyle.Flat,
					BackColor = Color.FromArgb(0, 150, 200),
					ForeColor = Color.White,
					Font = new Font("Segoe UI", 8f, FontStyle.Bold),
					Cursor = Cursors.Hand
				};
				btnOk.FlatAppearance.BorderColor = Color.Cyan;
				btnOk.FlatAppearance.BorderSize = 2;
				btnOk.Click += delegate(object s, EventArgs e)
				{
					form.DialogResult = DialogResult.OK;
					form.Close();
				};
				btnOk.MouseEnter += delegate(object s, EventArgs e)
				{
					btnOk.BackColor = Color.FromArgb(0, 200, 255);
				};
				btnOk.MouseLeave += delegate(object s, EventArgs e)
				{
					btnOk.BackColor = Color.FromArgb(0, 150, 200);
				};
				flowLayoutPanel.Controls.Add(btnOk);
				panel.Controls.Add(label);
				panel.Controls.Add(btnClose);
				panel.Controls.Add(value);
				panel.Controls.Add(flowLayoutPanel);
				form.Controls.Add(panel);
				bool dragging = false;
				Point dragStart = Point.Empty;
				Action<object, MouseEventArgs> startDrag = delegate(object s, MouseEventArgs e)
				{
					dragging = true;
					dragStart = e.Location;
				};
				Action<object, MouseEventArgs> doDrag = delegate(object s, MouseEventArgs e)
				{
					if (dragging)
					{
						form.Location = new Point(form.Location.X + e.X - dragStart.X, form.Location.Y + e.Y - dragStart.Y);
					}
				};
				Action<object, MouseEventArgs> endDrag = delegate(object s, MouseEventArgs e)
				{
					dragging = false;
				};
				form.MouseDown += delegate(object s, MouseEventArgs e)
				{
					startDrag(s, e);
				};
				form.MouseMove += delegate(object s, MouseEventArgs e)
				{
					doDrag(s, e);
				};
				form.MouseUp += delegate(object s, MouseEventArgs e)
				{
					endDrag(s, e);
				};
				label.MouseDown += delegate(object s, MouseEventArgs e)
				{
					startDrag(s, e);
				};
				label.MouseMove += delegate(object s, MouseEventArgs e)
				{
					doDrag(s, e);
				};
				label.MouseUp += delegate(object s, MouseEventArgs e)
				{
					endDrag(s, e);
				};
				form.Paint += delegate(object s, PaintEventArgs e)
				{
					e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
					using (Pen pen = new Pen(Color.FromArgb(80, 0, 255, 255), 4f))
					{
						using (GraphicsPath roundedPath = CustomMessageBoxDiag__0.GetRoundedPath(new Rectangle(1, 1, form.Width - 2, form.Height - 2), 15))
						{
							e.Graphics.DrawPath(pen, roundedPath);
						}
					}
					using (Pen pen2 = new Pen(Color.Cyan, 2f))
					{
						using (GraphicsPath roundedPath2 = CustomMessageBoxDiag__0.GetRoundedPath(new Rectangle(1, 1, form.Width - 2, form.Height - 2), 15))
						{
							e.Graphics.DrawPath(pen2, roundedPath2);
						}
					}
				};
				form.Region = new Region(CustomMessageBoxDiag__0.GetRoundedPath(new Rectangle(0, 0, form.Width, form.Height), 15));
				form.KeyDown += delegate(object s, KeyEventArgs e)
				{
					if (e.KeyCode == Keys.Escape)
					{
						form.DialogResult = DialogResult.Cancel;
						form.Close();
					}
				};
				result = form.ShowDialog();
			}
			return result;
		}

		// Token: 0x06000F65 RID: 3941 RVA: 0x00068460 File Offset: 0x00068460
		private static GraphicsPath GetRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = radius * 2;
			graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}
	}
}
