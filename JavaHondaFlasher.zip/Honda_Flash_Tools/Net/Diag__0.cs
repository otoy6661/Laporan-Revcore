﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200071F RID: 1823
	public partial class Diag__0 : Form
	{
		// Token: 0x060010AB RID: 4267
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x060010AC RID: 4268
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		// Token: 0x060010AD RID: 4269 RVA: 0x000792C0 File Offset: 0x000792C0
		public Diag__0()
		{
			this.tek10 = true;
			this.tek11 = true;
			this.tek13 = true;
			this.tek16 = true;
			this.tek17 = true;
			this.combinedResult = "";
			this.errorMessages = new Dictionary<string, string>();
			this.Hasil = "-";
			this.Hasil2 = "-";
			this.Hasil3 = "-";
			this.Hasil4 = "-";
			this.hasilGabungan = "-";
			this.dtcCounter = 1;
			this.fiz = "-";
			this.bas = "-";
			this.sss = "-";
			this.ssw = "-";
			this.ggs = "-";
			this.pom = "-";
			this.fan = "-";
			this.ggv = "-";
			this.borderColor = Color.Cyan;
			this.InitializeComponent();
			base.KeyPreview = true;
			base.KeyDown += this.Diag_KeyDown;
			base.MinimizeBox = false;
			base.ControlBox = false;
			this.listBox1.Visible = false;
			this.listBox1.DrawMode = DrawMode.OwnerDrawFixed;
			this.listBox1.DrawItem += this.listBox1_DrawItem1;
		}

		// Token: 0x060010AE RID: 4270 RVA: 0x0000B40A File Offset: 0x0000B40A
		private void Diag_Load(object sender, EventArgs e)
		{
			this.InitFtdiIso();
			this.InitializeDataGridView();
			this.InitializeDataGridView2();
			base.FormClosing += this.SecondForm_FormClosing;
			this.InitializeCircularProgressBars();
			this.ChangeListBoxBackColor();
		}

		// Token: 0x060010AF RID: 4271 RVA: 0x0007940C File Offset: 0x0007940C
		private void InitializeDataGridView()
		{
			this.dgv1Container = new Panel
			{
				Location = new Point(0, 250),
				Size = new Size(444, 265),
				BackColor = Diag__0.SafeColor(Diag__0.WebBg, Color.FromArgb(13, 17, 23)),
				Dock = DockStyle.Fill,
				Padding = new Padding(6)
			};
			this.dgv1Container.Paint += this.DgvContainer_Paint;
			this.dataGridView = new DataGridView
			{
				Dock = DockStyle.Fill,
				Margin = new Padding(0),
				ColumnCount = 2,
				AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
				ReadOnly = true,
				Enabled = true,
				AllowUserToAddRows = false,
				AllowUserToDeleteRows = false,
				AllowUserToResizeColumns = false,
				AllowUserToResizeRows = false,
				SelectionMode = DataGridViewSelectionMode.FullRowSelect,
				MultiSelect = true,
				RowHeadersVisible = true,
				BorderStyle = BorderStyle.None,
				BackgroundColor = Diag__0.SafeColor(Diag__0.WebBg, Color.FromArgb(13, 17, 23)),
				GridColor = Diag__0.SafeColor(Diag__0.WebGrid, Color.FromArgb(33, 38, 45)),
				RowsDefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = Diag__0.SafeColor(Diag__0.WebSurface, Color.FromArgb(22, 27, 34)),
					ForeColor = Diag__0.SafeColor(Diag__0.WebText, Color.FromArgb(201, 209, 217)),
					SelectionBackColor = Diag__0.SafeColor(Diag__0.WebSelBack, Color.FromArgb(0, 90, 80)),
					SelectionForeColor = Diag__0.SafeColor(Diag__0.WebSelFore, Color.FromArgb(230, 255, 250)),
					Font = new Font("Segoe UI", 9.5f, FontStyle.Regular)
				},
				AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = Diag__0.SafeColor(Diag__0.WebSurface2, Color.FromArgb(28, 33, 40)),
					ForeColor = Diag__0.SafeColor(Diag__0.WebText, Color.FromArgb(201, 209, 217)),
					SelectionBackColor = Diag__0.SafeColor(Diag__0.WebSelBack, Color.FromArgb(0, 90, 80)),
					SelectionForeColor = Diag__0.SafeColor(Diag__0.WebSelFore, Color.FromArgb(230, 255, 250))
				}
			};
			this.dataGridView.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dataGridView.RowHeadersDefaultCellStyle.BackColor = Diag__0.SafeColor(Diag__0.WebHeaderBack, Color.FromArgb(18, 24, 31));
			this.dataGridView.RowHeadersDefaultCellStyle.ForeColor = Diag__0.SafeColor(Diag__0.WebTextMuted, Color.FromArgb(139, 148, 158));
			this.dataGridView.RowHeadersDefaultCellStyle.SelectionBackColor = Diag__0.SafeColor(Diag__0.WebAccentDim, Color.FromArgb(0, 140, 130));
			this.dataGridView.RowHeadersDefaultCellStyle.SelectionForeColor = Diag__0.SafeColor(Diag__0.WebSelFore, Color.FromArgb(230, 255, 250));
			this.dataGridView.RowHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
			this.dataGridView.RowHeadersWidth = 50;
			this.dataGridView.ClearSelection();
			this.dataGridView.SelectionChanged += delegate(object s, EventArgs e)
			{
				this.dataGridView.ClearSelection();
			};
			this.dataGridView.EnableHeadersVisualStyles = false;
			this.dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
			this.dataGridView.ColumnHeadersHeight = 40;
			this.dataGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dataGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 10f, FontStyle.Bold);
			this.dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Diag__0.SafeColor(Diag__0.WebHeaderBack, Color.FromArgb(18, 24, 31));
			this.dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Diag__0.SafeColor(Diag__0.WebHeaderFore, Color.FromArgb(0, 220, 200));
			this.dataGridView.ColumnHeadersDefaultCellStyle.SelectionBackColor = Diag__0.SafeColor(Diag__0.WebHeaderBack, Color.FromArgb(18, 24, 31));
			this.dataGridView.ColumnHeadersDefaultCellStyle.SelectionForeColor = Diag__0.SafeColor(Diag__0.WebHeaderFore, Color.FromArgb(0, 220, 200));
			this.dataGridView.Columns[0].HeaderText = "Parameter";
			this.dataGridView.Columns[1].HeaderText = "Value";
			foreach (string text in new string[]
			{
				"Engine RPM",
				"Throttle Position Volt",
				"Throttle Position",
				"Engine Temp Volt",
				"Engine Temp",
				"Intake Air Temperatur Volt",
				"Intake Air Temperatur",
				"Manifold Absolute Pressure Volt",
				"Manifold Absolute Pressure",
				"Voltage Battery",
				"Injection Duration",
				"MODE",
				"Ignition Timing",
				"Vehicle Speed Sensor",
				"TableType",
				"Handle grip position 1 Volt",
				"Handle grip position 2 Volt",
				"Handle grip position 1 °",
				"Handle grip position 2 °",
				"Throttle Position 1 Volt",
				"Throttle Position 2 Volt",
				"Throttle Position 1 °",
				"Throttle Position 2 °",
				"COR",
				"Intake Air Temperatur Volt",
				"Intake Air Temperatur",
				"Manifold Absolute Pressure Volt",
				"Manifold Absolute Pressure"
			})
			{
				this.dataGridView.Rows.Add(new object[]
				{
					text
				});
			}
			checked
			{
				for (int j = 0; j < this.dataGridView.Rows.Count; j++)
				{
					this.dataGridView.Rows[j].HeaderCell.Value = (j + 1).ToString();
				}
				this.dataGridView.CellFormatting += delegate(object s, DataGridViewCellFormattingEventArgs e)
				{
					if (e.ColumnIndex == 0)
					{
						e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
						e.CellStyle.Padding = new Padding(8, 0, 0, 0);
					}
					else
					{
						e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					}
					e.CellStyle.SelectionBackColor = Diag__0.SafeColor(Diag__0.WebSelBack, Color.FromArgb(0, 90, 80));
					e.CellStyle.SelectionForeColor = Diag__0.SafeColor(Diag__0.WebSelFore, Color.FromArgb(230, 255, 250));
					if (e.ColumnIndex == 1)
					{
						e.CellStyle.ForeColor = Diag__0.SafeColor(Diag__0.WebAccent, Color.FromArgb(0, 220, 200));
					}
				};
				int lastHoverRow = -1;
				this.dataGridView.CellMouseEnter += delegate(object s, DataGridViewCellEventArgs e)
				{
					if (e.RowIndex < 0 || e.RowIndex >= this.dataGridView.Rows.Count)
					{
						return;
					}
					if (e.RowIndex == lastHoverRow)
					{
						return;
					}
					if (lastHoverRow >= 0 && lastHoverRow < this.dataGridView.Rows.Count)
					{
						Color backColor = (lastHoverRow % 2 == 0) ? Diag__0.WebSurface : Diag__0.WebSurface2;
						this.dataGridView.Rows[lastHoverRow].DefaultCellStyle.BackColor = backColor;
					}
					this.dataGridView.Rows[e.RowIndex].DefaultCellStyle.BackColor = Diag__0.WebHover;
					lastHoverRow = e.RowIndex;
				};
				this.dataGridView.MouseLeave += delegate(object s, EventArgs e)
				{
					if (lastHoverRow >= 0 && lastHoverRow < this.dataGridView.Rows.Count)
					{
						Color backColor = (lastHoverRow % 2 == 0) ? Diag__0.WebSurface : Diag__0.WebSurface2;
						this.dataGridView.Rows[lastHoverRow].DefaultCellStyle.BackColor = backColor;
					}
					lastHoverRow = -1;
				};
				this.dgv1Container.Controls.Add(this.dataGridView);
				this.panel2.Controls.Add(this.dgv1Container);
			}
		}

		// Token: 0x060010B0 RID: 4272 RVA: 0x00079A9C File Offset: 0x00079A9C
		private void dtc()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				115,
				2,
				20
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			BitConverter.ToString(array2).Replace("-", "");
			byte b = array2[5];
			byte b2 = array2[6];
			byte b3 = array2[7];
			byte b4 = array2[8];
			byte b5 = array2[9];
			byte b6 = array2[10];
			this.Hasil = string.Format("{0}-{1}, {2}-{3}, {4}-{5}", new object[]
			{
				b,
				b2,
				b3,
				b4,
				b5,
				b6
			});
		}

		// Token: 0x060010B1 RID: 4273 RVA: 0x00079B60 File Offset: 0x00079B60
		private void dtc2()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				115,
				1,
				21
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			BitConverter.ToString(array2).Replace("-", "");
			byte b = array2[5];
			byte b2 = array2[6];
			byte b3 = array2[7];
			byte b4 = array2[8];
			byte b5 = array2[9];
			byte b6 = array2[10];
			this.Hasil2 = string.Format("{0}-{1}, {2}-{3}, {4}-{5}", new object[]
			{
				b,
				b2,
				b3,
				b4,
				b5,
				b6
			});
		}

		// Token: 0x060010B2 RID: 4274 RVA: 0x00079C24 File Offset: 0x00079C24
		private void dtc3()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				116,
				2,
				19
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			BitConverter.ToString(array2).Replace("-", "");
			byte b = array2[5];
			byte b2 = array2[6];
			byte b3 = array2[7];
			byte b4 = array2[8];
			byte b5 = array2[9];
			byte b6 = array2[10];
			this.Hasil3 = string.Format("{0}-{1}, {2}-{3}, {4}-{5}", new object[]
			{
				b,
				b2,
				b3,
				b4,
				b5,
				b6
			});
		}

		// Token: 0x060010B3 RID: 4275 RVA: 0x00079CE8 File Offset: 0x00079CE8
		private void dtc4()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				116,
				1,
				20
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			BitConverter.ToString(array2).Replace("-", "");
			byte b = array2[5];
			byte b2 = array2[6];
			byte b3 = array2[7];
			byte b4 = array2[8];
			byte b5 = array2[9];
			byte b6 = array2[10];
			this.Hasil4 = string.Format("{0}-{1}, {2}-{3}, {4}-{5}", new object[]
			{
				b,
				b2,
				b3,
				b4,
				b5,
				b6
			});
		}

		// Token: 0x060010B4 RID: 4276 RVA: 0x00008715 File Offset: 0x00008715
		private void Gabung(ref string gabung, string hasil1, string hasil2, string hasil3, string hasil4)
		{
			gabung = string.Concat(new string[]
			{
				hasil1,
				", ",
				hasil2,
				", ",
				hasil3,
				", ",
				hasil4
			});
		}

		// Token: 0x060010B5 RID: 4277 RVA: 0x00079DAC File Offset: 0x00079DAC
		private void ContohPemanggilanGabung()
		{
			this.Gabung(ref this.hasilGabungan, this.Hasil, this.Hasil2, this.Hasil3, this.Hasil4);
			Console.WriteLine(this.hasilGabungan);
			this.DisplayResponse(this.hasilGabungan);
			this.dtcCounter = 1;
			this.dtcTitleAdded = false;
		}

		// Token: 0x060010B6 RID: 4278 RVA: 0x00079E04 File Offset: 0x00079E04
		private void DisplayResponse(string hasilGabungan)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>
			{
				{
					"1-1",
					"MAP sensor circuit low voltage"
				},
				{
					"1-2",
					"MAP sensor circuit high voltage"
				},
				{
					"2-1",
					"MAP sensor performance problem"
				},
				{
					"7-1",
					"ECT sensor circuit low voltage"
				},
				{
					"7-2",
					"ECT sensor circuit high voltage"
				},
				{
					"8-1",
					"TP sensor circuit low voltage"
				},
				{
					"8-2",
					"TP sensor circuit high voltage"
				},
				{
					"9-1",
					"IAT sensor circuit low voltage"
				},
				{
					"9-2",
					"IAT sensor circuit high voltage"
				},
				{
					"11-1",
					"VS sensor no signal"
				},
				{
					"12-1",
					"No.1 primary injector circuit malfunction"
				},
				{
					"13-1",
					"No.2 primary injector circuit malfunction"
				},
				{
					"14-1",
					"No.3 primary injector circuit malfunction"
				},
				{
					"15-1",
					"No.4 primary injector circuit malfunction"
				},
				{
					"16-1",
					"No.1 secondary injector circuit malfunction"
				},
				{
					"17-1",
					"No.2 secondary injector circuit malfunction"
				},
				{
					"18-1",
					"CMP sensor no signal"
				},
				{
					"19-1",
					"CKP sensor no signal"
				},
				{
					"21-1",
					"0₂ sensor malfunction"
				},
				{
					"23-1",
					"0₂ sensor heater malfunction"
				},
				{
					"25-2",
					"Knock sensor circuit malfunction"
				},
				{
					"25-3",
					"Knock sensor circuit malfunction"
				},
				{
					"29-1",
					"IACV circuit malfunction"
				},
				{
					"33-2",
					"ECM EEPROM malfunction"
				},
				{
					"34-1",
					"ECV POT low voltage malfunction"
				},
				{
					"34-2",
					"ECV POT high voltage malfunction"
				},
				{
					"35-1",
					"EGCA malfunction"
				},
				{
					"48-1",
					"No.3 secondary injector circuit malfunction"
				},
				{
					"49-1",
					"No.4 secondary injector circuit malfunction"
				},
				{
					"51-1",
					"HESD linear solenoid malfunction"
				},
				{
					"54-1",
					"Bank angle sensor circuit low voltage"
				},
				{
					"54-2",
					"Bank angle sensor circuit high voltage"
				},
				{
					"56-1",
					"Knock sensor IC malfunction"
				},
				{
					"57-1",
					"Engine coolant over temperature"
				},
				{
					"57-2",
					"Engine coolant over temperature"
				},
				{
					"86-1",
					"Serial communication malfunction"
				},
				{
					"91-1",
					"Coil Ignition Primary Malfunction"
				},
				{
					"91-2",
					"Coil Ignition Primary Malfunction"
				}
			};
			foreach (string key in hasilGabungan.Split(new string[]
			{
				", "
			}, StringSplitOptions.None))
			{
				string message;
				if (dictionary.TryGetValue(key, out message))
				{
					this.ShowMessageInListBox(message);
				}
			}
		}

		// Token: 0x060010B7 RID: 4279 RVA: 0x0007A0B4 File Offset: 0x0007A0B4
		private void ShowMessageInListBox(string message)
		{
			string format = "{0}. {1}";
			int num = this.dtcCounter;
			this.dtcCounter = checked(num + 1);
			string item = string.Format(format, num, message);
			this.listBox1.Items.Add(item);
			this.listBox1.DrawMode = DrawMode.OwnerDrawFixed;
		}

		// Token: 0x060010B8 RID: 4280 RVA: 0x0007A104 File Offset: 0x0007A104
		private void listBox1_DrawItem1(object sender, DrawItemEventArgs e)
		{
			if (e.Index < 0)
			{
				return;
			}
			string s = this.listBox1.Items[e.Index].ToString();
			float num = 10f;
			float y = (float)e.Bounds.Top + num;
			e.Graphics.DrawString(s, this.listBox1.Font, Brushes.WhiteSmoke, (float)e.Bounds.Left, y);
			e.DrawFocusRectangle();
		}

		// Token: 0x060010B9 RID: 4281 RVA: 0x0000B43D File Offset: 0x0000B43D
		private void ClearAllMessages()
		{
			this.listBox1.Items.Clear();
			this.dtcTitleAdded = false;
			this.listBox1.Refresh();
		}

		// Token: 0x060010BA RID: 4282 RVA: 0x0007A184 File Offset: 0x0007A184
		private void rst()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				96,
				1,
				40
			};
			byte[] value = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref value, ref num, 0);
			BitConverter.ToString(value).Replace("-", "");
		}

		// Token: 0x060010BB RID: 4283 RVA: 0x0007A1D8 File Offset: 0x0007A1D8
		private void rst1()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				96,
				3,
				38
			};
			byte[] value = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref value, ref num, 0);
			BitConverter.ToString(value).Replace("-", "");
		}

		// Token: 0x060010BC RID: 4284 RVA: 0x0007A22C File Offset: 0x0007A22C
		private void rst2()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				0,
				240,
				153
			};
			byte[] value = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref value, ref num, 0);
			BitConverter.ToString(value).Replace("-", "");
		}

		// Token: 0x060010BD RID: 4285 RVA: 0x0007A184 File Offset: 0x0007A184
		private void rst3()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				96,
				1,
				40
			};
			byte[] value = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref value, ref num, 0);
			BitConverter.ToString(value).Replace("-", "");
		}

		// Token: 0x060010BE RID: 4286 RVA: 0x0007A280 File Offset: 0x0007A280
		private void rst4()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				116,
				3,
				18
			};
			byte[] value = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref value, ref num, 0);
			BitConverter.ToString(value).Replace("-", "");
		}

		// Token: 0x060010BF RID: 4287 RVA: 0x0007A2D4 File Offset: 0x0007A2D4
		private void InitializeDataGridView2()
		{
			this.dgv2Container = new Panel
			{
				Dock = DockStyle.Fill,
				BackColor = Diag__0.SafeColor(Diag__0.WebBg, Color.FromArgb(13, 17, 23)),
				Padding = new Padding(6),
				Margin = new Padding(0)
			};
			this.dgv2Container.Paint += this.DgvContainer_Paint;
			this.dataGridView2 = new DataGridView
			{
				Dock = DockStyle.Fill,
				Margin = new Padding(0),
				ColumnCount = 2,
				AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
				ReadOnly = true,
				Enabled = true,
				AllowUserToAddRows = false,
				AllowUserToDeleteRows = false,
				AllowUserToResizeColumns = false,
				AllowUserToResizeRows = false,
				SelectionMode = DataGridViewSelectionMode.FullRowSelect,
				MultiSelect = true,
				RowHeadersVisible = true,
				BorderStyle = BorderStyle.None,
				BackgroundColor = Diag__0.SafeColor(Diag__0.WebBg, Color.FromArgb(13, 17, 23)),
				GridColor = Diag__0.SafeColor(Diag__0.WebGrid, Color.FromArgb(33, 38, 45)),
				RowsDefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = Diag__0.SafeColor(Diag__0.WebSurface, Color.FromArgb(22, 27, 34)),
					ForeColor = Diag__0.SafeColor(Diag__0.WebText, Color.FromArgb(201, 209, 217)),
					SelectionBackColor = Diag__0.SafeColor(Diag__0.WebSelBack, Color.FromArgb(0, 90, 80)),
					SelectionForeColor = Diag__0.SafeColor(Diag__0.WebSelFore, Color.FromArgb(230, 255, 250)),
					Font = new Font("Segoe UI", 9.5f, FontStyle.Regular)
				},
				AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle
				{
					BackColor = Diag__0.SafeColor(Diag__0.WebSurface2, Color.FromArgb(28, 33, 40)),
					ForeColor = Diag__0.SafeColor(Diag__0.WebText, Color.FromArgb(201, 209, 217)),
					SelectionBackColor = Diag__0.SafeColor(Diag__0.WebSelBack, Color.FromArgb(0, 90, 80)),
					SelectionForeColor = Diag__0.SafeColor(Diag__0.WebSelFore, Color.FromArgb(230, 255, 250))
				}
			};
			this.dataGridView2.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dataGridView2.RowHeadersDefaultCellStyle.BackColor = Diag__0.SafeColor(Diag__0.WebHeaderBack, Color.FromArgb(18, 24, 31));
			this.dataGridView2.RowHeadersDefaultCellStyle.ForeColor = Diag__0.SafeColor(Diag__0.WebTextMuted, Color.FromArgb(139, 148, 158));
			this.dataGridView2.RowHeadersDefaultCellStyle.SelectionBackColor = Diag__0.SafeColor(Diag__0.WebAccentDim, Color.FromArgb(0, 140, 130));
			this.dataGridView2.RowHeadersDefaultCellStyle.SelectionForeColor = Diag__0.SafeColor(Diag__0.WebSelFore, Color.FromArgb(230, 255, 250));
			this.dataGridView2.RowHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
			this.dataGridView2.RowHeadersWidth = 50;
			this.dataGridView2.ClearSelection();
			this.dataGridView2.SelectionChanged += delegate(object s, EventArgs e)
			{
				this.dataGridView2.ClearSelection();
			};
			this.dataGridView2.EnableHeadersVisualStyles = false;
			this.dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
			this.dataGridView2.ColumnHeadersHeight = 40;
			this.dataGridView2.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dataGridView2.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 10f, FontStyle.Bold);
			this.dataGridView2.ColumnHeadersDefaultCellStyle.BackColor = Diag__0.SafeColor(Diag__0.WebHeaderBack, Color.FromArgb(18, 24, 31));
			this.dataGridView2.ColumnHeadersDefaultCellStyle.ForeColor = Diag__0.SafeColor(Diag__0.WebHeaderFore, Color.FromArgb(0, 220, 200));
			this.dataGridView2.ColumnHeadersDefaultCellStyle.SelectionBackColor = Diag__0.SafeColor(Diag__0.WebHeaderBack, Color.FromArgb(18, 24, 31));
			this.dataGridView2.ColumnHeadersDefaultCellStyle.SelectionForeColor = Diag__0.SafeColor(Diag__0.WebHeaderFore, Color.FromArgb(0, 220, 200));
			this.dataGridView2.Columns[0].HeaderText = "Parameter";
			this.dataGridView2.Columns[1].HeaderText = "Value";
			foreach (string text in new string[]
			{
				"Oxygen Sensor",
				"Oxygen Sensor Volt",
				"Short term Fuel Trim",
				"Air Fuel Ratio",
				"Fast Idle Step",
				"Bank Angle Sensor",
				"Switch Starter",
				"Side Stand Switch",
				"Gear Status",
				"Fuel Pump",
				"Cooling Fan",
				"Gear Position"
			})
			{
				this.dataGridView2.Rows.Add(new object[]
				{
					text
				});
			}
			checked
			{
				for (int j = 0; j < this.dataGridView2.Rows.Count; j++)
				{
					this.dataGridView2.Rows[j].HeaderCell.Value = (j + 1).ToString();
				}
				this.dataGridView2.CellFormatting += delegate(object s, DataGridViewCellFormattingEventArgs e)
				{
					if (e.ColumnIndex == 0)
					{
						e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
						e.CellStyle.Padding = new Padding(8, 0, 0, 0);
					}
					else
					{
						e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					}
					e.CellStyle.SelectionBackColor = Diag__0.SafeColor(Diag__0.WebSelBack, Color.FromArgb(0, 90, 80));
					e.CellStyle.SelectionForeColor = Diag__0.SafeColor(Diag__0.WebSelFore, Color.FromArgb(230, 255, 250));
					if (e.ColumnIndex == 1)
					{
						e.CellStyle.ForeColor = Diag__0.SafeColor(Diag__0.WebAccent, Color.FromArgb(0, 220, 200));
					}
				};
				int lastHoverRow = -1;
				this.dataGridView2.CellMouseEnter += delegate(object s, DataGridViewCellEventArgs e)
				{
					if (e.RowIndex < 0 || e.RowIndex >= this.dataGridView2.Rows.Count)
					{
						return;
					}
					if (e.RowIndex == lastHoverRow)
					{
						return;
					}
					if (lastHoverRow >= 0 && lastHoverRow < this.dataGridView2.Rows.Count)
					{
						Color backColor = (lastHoverRow % 2 == 0) ? Diag__0.WebSurface : Diag__0.WebSurface2;
						this.dataGridView2.Rows[lastHoverRow].DefaultCellStyle.BackColor = backColor;
					}
					this.dataGridView2.Rows[e.RowIndex].DefaultCellStyle.BackColor = Diag__0.WebHover;
					lastHoverRow = e.RowIndex;
				};
				this.dataGridView2.MouseLeave += delegate(object s, EventArgs e)
				{
					if (lastHoverRow >= 0 && lastHoverRow < this.dataGridView2.Rows.Count)
					{
						Color backColor = (lastHoverRow % 2 == 0) ? Diag__0.WebSurface : Diag__0.WebSurface2;
						this.dataGridView2.Rows[lastHoverRow].DefaultCellStyle.BackColor = backColor;
					}
					lastHoverRow = -1;
				};
				this.dgv2Container.Controls.Add(this.dataGridView2);
				this.panel3.Controls.Add(this.dgv2Container);
			}
		}

		// Token: 0x060010C0 RID: 4288 RVA: 0x0007A8BC File Offset: 0x0007A8BC
		private void LoopDat17(CancellationToken token)
		{
			while (!token.IsCancellationRequested)
			{
				if (this.tek11)
				{
					this.dat11();
					this.dat20();
				}
				if (this.tek10)
				{
					this.dat10();
					this.dat20();
				}
				if (this.tek13)
				{
					this.dat13();
					this.dat20();
				}
				if (this.tek16)
				{
					this.dat16();
					this.dat20();
				}
				if (this.tek17)
				{
					this.dat17();
					this.dat20();
				}
				Task.Delay(10, token);
			}
		}

		// Token: 0x060010C1 RID: 4289 RVA: 0x0007A944 File Offset: 0x0007A944
		private void dat10()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				16,
				8
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			string str = BitConverter.ToString(array2, 0, checked((int)num));
			Console.WriteLine("Response dat10: " + str);
			if (array2[1] == 5)
			{
				this.tek10 = false;
				return;
			}
			try
			{
				if (array2.Length >= 1)
				{
					int rpm = checked(((int)array2[4] << 8) + (int)array2[5]);
					float tps = (float)array2[6] * 5f / 256f;
					float tps2 = (float)array2[7] / 2f;
					float ect = (float)array2[8] * 5f / 256f;
					float ect2 = (float)(checked(array2[9] - 40));
					float iat = (float)array2[10] * 5f / 256f;
					float iat2 = (float)(checked(array2[11] - 40));
					float map = (float)array2[12] * 5f / 256f;
					int num2 = (int)array2[13];
					float bat = (float)array2[16] / 10f;
					int vss = (int)array2[17];
					float inj = (float)(checked(((int)array2[18] << 8) + (int)array2[19])) / 200f;
					float adv = (float)array2[20] / 2f - 64f;
					this.UpdateGridView(rpm, tps, tps2, ect, ect2, iat, iat2, map, (float)num2, bat, inj, 0, adv, vss, 16, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0, 0f, 0f, 0f, 0);
				}
				else
				{
					Console.WriteLine("Response array is too small to be parsed.");
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding data: " + ex.Message);
			}
		}

		// Token: 0x060010C2 RID: 4290 RVA: 0x0007AB08 File Offset: 0x0007AB08
		private void datD1()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				209,
				71
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			try
			{
				Console.WriteLine("array9 (Hex): " + BitConverter.ToString(array2));
				this.bas = (this.sss = (this.ssw = (this.ggs = (this.pom = (this.fan = (this.ggv = "OFF"))))));
				this.ggs = "Netral";
				switch (array2[4])
				{
				case 0:
					this.ggs = "OnGear";
					this.ssw = "OFF";
					this.sss = "OFF";
					break;
				case 1:
					this.bas = "ON";
					this.ggs = "Netral";
					this.ssw = "OFF";
					this.sss = "ON";
					break;
				case 2:
					this.ssw = "ON";
					break;
				default:
					this.ssw = "OFF";
					break;
				}
				switch (array2[8])
				{
				case 0:
					this.pom = "OFF";
					break;
				case 1:
				case 5:
					this.pom = "ON";
					break;
				case 4:
					this.pom = "OFF";
					break;
				}
				this.fan = ((array2[9] == 1) ? "ON" : "OFF");
				byte b = array2[10];
				if (b <= 16)
				{
					switch (b)
					{
					case 0:
						this.ggv = "-";
						goto IL_23E;
					case 1:
						this.ggv = "1";
						goto IL_23E;
					case 2:
						this.ggv = "2";
						goto IL_23E;
					case 3:
					case 5:
					case 6:
					case 7:
						break;
					case 4:
						this.ggv = "3";
						goto IL_23E;
					case 8:
						this.ggv = "4";
						goto IL_23E;
					default:
						if (b == 16)
						{
							this.ggv = "5";
							goto IL_23E;
						}
						break;
					}
				}
				else
				{
					if (b == 32)
					{
						this.ggv = "N";
						goto IL_23E;
					}
					if (b == 128)
					{
						this.ggv = "6";
						goto IL_23E;
					}
				}
				this.ggv = "-";
				IL_23E:
				this.UpdateGridView2(this.oxi, this.o2v, this.stf, this.afr, this.fiz, this.bas, this.sss, this.ssw, this.ggs, this.pom, this.fan, this.ggv);
				Console.WriteLine("Data updated in GridView.");
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding data: " + ex.Message);
			}
		}

		// Token: 0x060010C3 RID: 4291 RVA: 0x0007ADE4 File Offset: 0x0007ADE4
		private void dat20()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				32,
				248
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			try
			{
				this.o2 = (float)(BitConverter.ToUInt16(array2, 4) & ushort.MaxValue) / 13.142708f / 1000f;
				this.stf = (float)(array2[5] & byte.MaxValue) / 128.25652f;
				this.oxi = this.o2;
				this.o2v = (float)(array2[4] & byte.MaxValue) / 50.9937f;
				this.afr = (float)(-5.351 * (double)this.o2v + 17.700000762939453);
				this.UpdateGridView2(this.oxi, this.o2v, this.stf, this.afr, this.fiz, this.bas, this.sss, this.ssw, this.ggs, this.pom, this.fan, this.ggv);
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding data: " + ex.Message);
			}
			this.datD1();
		}

		// Token: 0x060010C4 RID: 4292 RVA: 0x0007AF18 File Offset: 0x0007AF18
		private void UpdateGridView2(float oxi, float o2v, float stf, float afr, string fiz, string bas, string sss, string ssw, string ggs, string pom, string fan, string ggv)
		{
			if (this.dataGridView2.InvokeRequired)
			{
				this.dataGridView2.Invoke(new Action(delegate()
				{
					this.UpdateRows2(oxi, o2v, stf, afr, fiz, bas, sss, ssw, ggs, pom, fan, ggv);
				}));
				return;
			}
			this.UpdateRows2(oxi, o2v, stf, afr, fiz, bas, sss, ssw, ggs, pom, fan, ggv);
		}

		// Token: 0x060010C5 RID: 4293 RVA: 0x0007B004 File Offset: 0x0007B004
		private void UpdateRows2(float oxi, float o2v, float stf, float afr, string fiz, string bas, string sss, string ssw, string ggs, string pom, string fan, string ggv)
		{
			Console.WriteLine(string.Concat(new string[]
			{
				"Updating GridView with bas: ",
				bas,
				", sss: ",
				sss,
				", ssw: ",
				ssw,
				", ggs: ",
				ggs,
				", pom: ",
				pom,
				", fan: ",
				fan,
				", ggv: ",
				ggv
			}));
			this.dataGridView2.Rows[0].Cells[1].Value = oxi.ToString("F4");
			this.dataGridView2.Rows[1].Cells[1].Value = o2v.ToString("F4") + " Volt";
			this.dataGridView2.Rows[2].Cells[1].Value = stf.ToString("F4");
			this.dataGridView2.Rows[3].Cells[1].Value = afr.ToString("F2") + " : 1";
			this.dataGridView2.Rows[4].Cells[1].Value = fiz;
			this.dataGridView2.Rows[5].Cells[1].Value = bas;
			this.dataGridView2.Rows[6].Cells[1].Value = sss;
			this.dataGridView2.Rows[7].Cells[1].Value = ssw;
			this.dataGridView2.Rows[8].Cells[1].Value = ggs;
			this.dataGridView2.Rows[9].Cells[1].Value = pom;
			this.dataGridView2.Rows[10].Cells[1].Value = fan;
			this.dataGridView2.Rows[11].Cells[1].Value = ggv;
			this.dataGridView2.InvalidateCell(this.dataGridView2.Rows[5].Cells[1]);
			this.dataGridView2.InvalidateCell(this.dataGridView2.Rows[6].Cells[1]);
			this.dataGridView2.InvalidateCell(this.dataGridView2.Rows[7].Cells[1]);
			this.dataGridView2.InvalidateCell(this.dataGridView2.Rows[8].Cells[1]);
			this.dataGridView2.InvalidateCell(this.dataGridView2.Rows[9].Cells[1]);
			this.dataGridView2.InvalidateCell(this.dataGridView2.Rows[10].Cells[1]);
			this.dataGridView2.InvalidateCell(this.dataGridView2.Rows[11].Cells[1]);
		}

		// Token: 0x060010C6 RID: 4294 RVA: 0x0007B37C File Offset: 0x0007B37C
		private void dat11()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				17,
				7
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			string str = BitConverter.ToString(array2, 0, checked((int)num));
			Console.WriteLine("Response 11: " + str);
			if (array2[1] == 5)
			{
				this.tek11 = false;
				return;
			}
			try
			{
				if (array2.Length >= 1)
				{
					int rpm = checked(((int)array2[4] << 8) + (int)array2[5]);
					float tps = (float)array2[6] * 5f / 256f;
					float tps2 = (float)array2[7] / 2f;
					float ect = (float)array2[8] * 5f / 256f;
					float ect2 = (float)(checked(array2[9] - 40));
					float iat = (float)array2[10] * 5f / 256f;
					float iat2 = (float)(checked(array2[11] - 40));
					float map = (float)array2[12] * 5f / 256f;
					int num2 = (int)array2[13];
					float bat = (float)array2[16] / 10f;
					int vss = (int)array2[17];
					float inj = (float)(checked(((int)array2[18] << 8) + (int)array2[19])) / 200f;
					float adv = (float)array2[20] / 2f - 64f;
					float num3 = (float)array2[22] / 10000f;
					this.UpdateGridView(rpm, tps, tps2, ect, ect2, iat, iat2, map, (float)num2, bat, inj, 0, adv, vss, 17, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0, 0f, 0f, 0f, 0);
				}
				else
				{
					Console.WriteLine("Response array is too small to be parsed.");
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding data: " + ex.Message);
			}
		}

		// Token: 0x060010C7 RID: 4295 RVA: 0x0007B54C File Offset: 0x0007B54C
		private void dat13()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				19,
				5
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			string str = BitConverter.ToString(array2, 0, checked((int)num));
			Console.WriteLine("Response 13: " + str);
			if (array2[1] == 5)
			{
				this.tek13 = false;
				return;
			}
			try
			{
				if (array2.Length >= 1)
				{
					int rpm = checked(((int)array2[4] << 8) + (int)array2[5]);
					float tps = (float)array2[6] * 5f / 256f;
					float tps2 = (float)array2[7] / 2f;
					float ect = (float)array2[8] * 5f / 256f;
					float ect2 = (float)(checked(array2[9] - 40));
					float iat = (float)array2[10] * 5f / 256f;
					float iat2 = (float)(checked(array2[11] - 40));
					float map = (float)array2[12] * 5f / 256f;
					int num2 = (int)array2[13];
					float bat = (float)array2[14] / 10f;
					float inj = (float)(checked(((int)array2[15] << 8) + (int)array2[16])) / 200f;
					float adv = (float)array2[17] / 2f - 64f;
					this.UpdateGridView(rpm, tps, tps2, ect, ect2, iat, iat2, map, (float)num2, bat, inj, 0, adv, 0, 19, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0, 0f, 0f, 0f, 0);
				}
				else
				{
					Console.WriteLine("Response array is too small to be parsed.");
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding data: " + ex.Message);
			}
		}

		// Token: 0x060010C8 RID: 4296 RVA: 0x0007B70C File Offset: 0x0007B70C
		private void dat16()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				22,
				2
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			checked
			{
				string str = BitConverter.ToString(array2, 0, (int)num);
				Console.WriteLine("Response 16: " + str);
				if (array2[1] == 5)
				{
					this.tek16 = false;
					return;
				}
				try
				{
					if (array2.Length >= 2)
					{
						int rpm = ((int)array2[4] << 8) + (int)array2[5];
						float num2;
						float num3;
						float num4;
						float num5;
						float num6;
						float num7;
						float num8;
						float num9;
						int num10;
						float num11;
						float num12;
						float num13;
						float num14;
						float num15;
						int num16;
						float num17;
						int num18;
						float num19;
						float num20;
						unchecked
						{
							num2 = (float)array2[6] * 5f / 256f;
							num3 = (float)array2[7] * 5f / 256f;
							num4 = (float)array2[8] / 2f;
							num5 = (float)array2[9] / 2f;
							num6 = (float)array2[10] * 5f / 256f;
							num7 = (float)array2[11] * 5f / 256f;
							num8 = (float)array2[12] / 2f;
							num9 = (float)array2[13] / 2f;
							num10 = (int)array2[14];
							num11 = (float)array2[15] * 5f / 256f;
							num12 = (float)array2[16] - 40f;
							num13 = (float)array2[17] * 5f / 256f;
							num14 = (float)array2[18] - 40f;
							num15 = (float)array2[19] * 5f / 256f;
							num16 = (int)array2[20];
							num17 = (float)array2[21] / 10f;
							num18 = (int)array2[22];
							num19 = (float)array2[23] / 200f;
							num20 = (float)array2[24] / 2f - 64f;
						}
						this.UpdateGridView(rpm, (float)((int)Math.Round((double)num2)), (float)((int)Math.Round((double)num3)), (float)((int)Math.Round((double)num4)), (float)((int)Math.Round((double)num5)), (float)((int)Math.Round((double)num6)), (float)((int)Math.Round((double)num7)), (float)((int)Math.Round((double)num8)), (float)((int)Math.Round((double)num9)), (float)num10, (float)((int)Math.Round((double)num11)), (int)Math.Round((double)num12), (float)((int)Math.Round((double)num13)), (int)Math.Round((double)num14), (int)Math.Round((double)num15), (float)num16, (float)((int)Math.Round((double)num17)), (float)num18, (float)((int)Math.Round((double)num19)), (float)((int)Math.Round((double)num20)), 0f, 0f, 0f, 0, 0f, 0f, 0f, 0);
					}
					else
					{
						Console.WriteLine("Response array is too small to be parsed.");
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine("Error decoding data: " + ex.Message);
				}
			}
		}

		// Token: 0x060010C9 RID: 4297 RVA: 0x0007B9A8 File Offset: 0x0007B9A8
		private void dat17()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				23,
				1
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			string str = BitConverter.ToString(array2, 0, checked((int)num));
			Console.WriteLine("Response 17: " + str);
			if (array2[1] == 5)
			{
				this.tek17 = false;
				return;
			}
			try
			{
				int rpm = checked(((int)array2[4] << 8) + (int)array2[5]);
				float tps = (float)array2[6] * 5f / 256f;
				float tps2 = (float)array2[7] / 2f;
				float ect = (array2[12] != byte.MaxValue) ? ((float)array2[12] * 5f / 256f) : ((float)array2[8] * 5f / 256f);
				float ect2;
				float bat;
				float inj;
				int mode;
				checked
				{
					ect2 = (float)((array2[13] != byte.MaxValue) ? (array2[13] - 40) : (array2[9] - 40));
					bat = (float)array2[14] / 10f;
					inj = (float)(((int)array2[15] << 8) + (int)array2[16]) / 200f;
					int num2 = (int)array2[18];
					if (num2 == 128 || num2 == 103)
					{
						mode = 1;
					}
					else if (num2 == 102)
					{
						mode = 2;
					}
					else if (num2 == 60)
					{
						mode = 3;
					}
					else if (num2 == 89)
					{
						mode = 4;
					}
					else if (num2 == 121)
					{
						mode = 0;
					}
					else
					{
						mode = 0;
					}
					if (num2 < 128)
					{
						this.fiz = "ON";
					}
					else
					{
						this.fiz = "OFF";
					}
				}
				float adv = (float)array2[17] / 2f - 64f;
				int vss = (int)array2[19];
				int tableType = (int)array2[2];
				this.UpdateGridView(rpm, tps, tps2, ect, ect2, 0f, 0f, 0f, 0f, bat, inj, mode, adv, vss, tableType, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0, 0f, 0f, 0f, 0);
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding data: " + ex.Message);
			}
		}

		// Token: 0x060010CA RID: 4298 RVA: 0x0007BBD0 File Offset: 0x0007BBD0
		private void UpdateGridView(int rpm, float tps1, float tps2, float ect1, float ect2, float iat1, float iat2, float map1, float map2, float bat, float inj, int MODE, float adv, int vss, int tableType, float ap1_0 = 0f, float ap2_0 = 0f, float ap1_1 = 0f, float ap2_1 = 0f, float tp1_0 = 0f, float tp2_0 = 0f, float tp1_1 = 0f, float tp2_1 = 0f, int cor = 0, float iat11 = 0f, float iat21 = 0f, float map11 = 0f, int map21 = 0)
		{
			if (this.dataGridView.InvokeRequired)
			{
				this.dataGridView.Invoke(new Action(delegate()
				{
					this.UpdateRows(rpm, tps1, tps2, ect1, ect2, iat1, iat2, map1, map2, bat, inj, MODE, adv, vss, tableType, ap1_0, ap2_0, ap1_1, ap2_1, tp1_0, tp2_0, tp1_1, tp2_1, cor, iat11, iat21, map11, map21);
				}));
				return;
			}
			this.UpdateRows(rpm, tps1, tps2, ect1, ect2, iat1, iat2, map1, map2, bat, inj, MODE, adv, vss, tableType, ap1_0, ap2_0, ap1_1, ap2_1, tp1_0, tp2_0, tp1_1, tp2_1, cor, iat11, iat21, map11, map21);
		}

		// Token: 0x060010CB RID: 4299 RVA: 0x0007BD9C File Offset: 0x0007BD9C
		private void UpdateRows(int rpm, float tps1, float tps2, float ect1, float ect2, float iat1, float iat2, float map1, float map2, float bat, float inj, int MODE, float adv, int vss, int tableType, float ap1_0, float ap2_0, float ap1_1, float ap2_1, float tp1_0, float tp2_0, float tp1_1, float tp2_1, int cor, float iat11, float iat21, float map11, int map21)
		{
			this.dataGridView.Rows[0].Cells[1].Value = rpm.ToString() + " RPM";
			this.dataGridView.Rows[1].Cells[1].Value = tps1.ToString() + " Volt";
			this.dataGridView.Rows[2].Cells[1].Value = tps2.ToString() + " °";
			this.dataGridView.Rows[3].Cells[1].Value = ect1.ToString() + " Volt";
			this.dataGridView.Rows[4].Cells[1].Value = ect2.ToString() + " °C";
			this.dataGridView.Rows[5].Cells[1].Value = iat1.ToString() + " Volt";
			this.dataGridView.Rows[6].Cells[1].Value = iat2.ToString() + " °C";
			this.dataGridView.Rows[7].Cells[1].Value = map1.ToString() + " Volt";
			this.dataGridView.Rows[8].Cells[1].Value = map2.ToString();
			this.dataGridView.Rows[9].Cells[1].Value = bat.ToString() + " Volt";
			this.dataGridView.Rows[10].Cells[1].Value = inj.ToString() + " ms";
			this.dataGridView.Rows[11].Cells[1].Value = MODE.ToString();
			this.dataGridView.Rows[12].Cells[1].Value = adv.ToString() + " °";
			this.dataGridView.Rows[13].Cells[1].Value = vss.ToString() + " km/h";
			this.dataGridView.Rows[14].Cells[1].Value = tableType.ToString();
			this.dataGridView.Rows[15].Cells[1].Value = ap1_0.ToString() + " Volt";
			this.dataGridView.Rows[16].Cells[1].Value = ap2_0.ToString() + " Volt";
			this.dataGridView.Rows[17].Cells[1].Value = ap1_1.ToString() + " °";
			this.dataGridView.Rows[18].Cells[1].Value = ap2_1.ToString() + " °";
			this.dataGridView.Rows[19].Cells[1].Value = tp1_0.ToString() + " Volt";
			this.dataGridView.Rows[20].Cells[1].Value = tp2_0.ToString() + " Volt";
			this.dataGridView.Rows[21].Cells[1].Value = tp1_1.ToString() + " °";
			this.dataGridView.Rows[22].Cells[1].Value = tp2_1.ToString() + " °";
			this.dataGridView.Rows[23].Cells[1].Value = cor.ToString();
			this.dataGridView.Rows[24].Cells[1].Value = iat11.ToString() + " Volt";
			this.dataGridView.Rows[25].Cells[1].Value = iat21.ToString() + " °C";
			this.dataGridView.Rows[26].Cells[1].Value = map11.ToString() + " Volt";
			this.dataGridView.Rows[27].Cells[1].Value = map21.ToString();
			this.UpdateCircularProgressBars(rpm, tps2);
		}

		// Token: 0x060010CC RID: 4300 RVA: 0x0007C30C File Offset: 0x0007C30C
		private async void button2_Click(object sender, EventArgs e)
		{
			try
			{
				if (this._cancellationTokenSource != null)
				{
					this._cancellationTokenSource.Cancel();
					this._cancellationTokenSource.Dispose();
				}
				this._cancellationTokenSource = new CancellationTokenSource();
				CancellationToken token = this._cancellationTokenSource.Token;
				this.tek10 = true;
				this.tek11 = true;
				this.tek13 = true;
				this.tek16 = true;
				this.tek17 = true;
				await Task.Run(delegate()
				{
					this.LoopDat17(token);
				}, token);
			}
			catch (OperationCanceledException)
			{
				Console.WriteLine("Operation canceled");
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x060010CD RID: 4301 RVA: 0x0007C348 File Offset: 0x0007C348
		private void button1_Click(object sender, EventArgs e)
		{
			CancellationTokenSource cancellationTokenSource = this._cancellationTokenSource;
			if (cancellationTokenSource != null)
			{
				cancellationTokenSource.Cancel();
			}
			this.CloseFtdiConnection();
			base.Close();
		}

		// Token: 0x060010CE RID: 4302 RVA: 0x0000B461 File Offset: 0x0000B461
		private void CloseFtdiConnection()
		{
			if (Diag__0.ftHandle != IntPtr.Zero)
			{
				FTDI.FT_Close(Diag__0.ftHandle);
				Diag__0.ftHandle = IntPtr.Zero;
			}
		}

		// Token: 0x060010CF RID: 4303 RVA: 0x0007C374 File Offset: 0x0007C374
		private bool InitFtdiIso()
		{
			byte[] array = new byte[1];
			byte[] array2 = new byte[]
			{
				1
			};
			uint num = 0U;
			checked
			{
				bool result;
				if (FTDI.FT_Open(0U, ref Diag__0.ftHandle) > FTDI.FT_STATUS.FT_OK)
				{
					FTDI.FT_Close(Diag__0.ftHandle);
					result = false;
				}
				else if (FTDI.FT_Purge(Diag__0.ftHandle, 3U) > FTDI.FT_STATUS.FT_OK)
				{
					FTDI.FT_Close(Diag__0.ftHandle);
					result = false;
				}
				else if (FTDI.FT_SetBitMode(Diag__0.ftHandle, 0, 0) > FTDI.FT_STATUS.FT_OK)
				{
					FTDI.FT_Close(Diag__0.ftHandle);
					result = false;
				}
				else if (FTDI.FT_SetDataCharacteristics(Diag__0.ftHandle, 8, 0, 0) > FTDI.FT_STATUS.FT_OK)
				{
					FTDI.FT_Close(Diag__0.ftHandle);
					result = false;
				}
				else if (FTDI.FT_SetBaudRate(Diag__0.ftHandle, 10400U) > FTDI.FT_STATUS.FT_OK)
				{
					FTDI.FT_Close(Diag__0.ftHandle);
					result = false;
				}
				else if (FTDI.FT_SetTimeouts(Diag__0.ftHandle, 50U, 0U) > FTDI.FT_STATUS.FT_OK)
				{
					FTDI.FT_Close(Diag__0.ftHandle);
					result = false;
				}
				else if (FTDI.FT_SetLatencyTimer(Diag__0.ftHandle, 8) > FTDI.FT_STATUS.FT_OK)
				{
					FTDI.FT_Close(Diag__0.ftHandle);
					result = false;
				}
				else if (FTDI.FT_SetBitMode(Diag__0.ftHandle, 1, 1) > FTDI.FT_STATUS.FT_OK)
				{
					FTDI.FT_Close(Diag__0.ftHandle);
					result = false;
				}
				else if (FTDI.FT_Write(Diag__0.ftHandle, array, (uint)array.Length, ref num) > FTDI.FT_STATUS.FT_OK)
				{
					FTDI.FT_Close(Diag__0.ftHandle);
					result = false;
				}
				else
				{
					Thread.Sleep(70);
					if (FTDI.FT_Write(Diag__0.ftHandle, array2, (uint)array2.Length, ref num) > FTDI.FT_STATUS.FT_OK)
					{
						FTDI.FT_Close(Diag__0.ftHandle);
						result = false;
					}
					else if (FTDI.FT_SetBitMode(Diag__0.ftHandle, 0, 0) > FTDI.FT_STATUS.FT_OK)
					{
						FTDI.FT_Close(Diag__0.ftHandle);
						result = false;
					}
					else if (FTDI.FT_SetBaudRate(Diag__0.ftHandle, 10400U) > FTDI.FT_STATUS.FT_OK)
					{
						FTDI.FT_Close(Diag__0.ftHandle);
						result = false;
					}
					else if (FTDI.FT_Purge(Diag__0.ftHandle, 3U) > FTDI.FT_STATUS.FT_OK)
					{
						FTDI.FT_Close(Diag__0.ftHandle);
						result = false;
					}
					else
					{
						Thread.Sleep(130);
						result = true;
					}
				}
				return result;
			}
		}

		// Token: 0x060010D0 RID: 4304 RVA: 0x0007C558 File Offset: 0x0007C558
		private bool SendCommand(byte[] command, int commandSize, ref byte[] reply, ref uint replySize, int sleepMs = 0)
		{
			byte[] array = new byte[256];
			byte[] array2 = new byte[256];
			uint num = 0U;
			uint num2 = 0U;
			uint num3 = 0U;
			uint num4 = 0U;
			uint num5 = 0U;
			long num6 = (long)(checked(50 + 2 * commandSize));
			checked
			{
				bool result;
				if (FTDI.FT_Write(Diag__0.ftHandle, command, (uint)commandSize, ref num) > FTDI.FT_STATUS.FT_OK)
				{
					result = false;
				}
				else if (FTDI.FT_SetLatencyTimer(Diag__0.ftHandle, 8) <= FTDI.FT_STATUS.FT_OK)
				{
					if (sleepMs > 0)
					{
						Thread.Sleep(sleepMs);
					}
					Stopwatch stopwatch = new Stopwatch();
					stopwatch.Start();
					do
					{
						if (FTDI.FT_GetQueueStatus(Diag__0.ftHandle, ref num2) == FTDI.FT_STATUS.FT_OK && num2 > 0U && unchecked((ulong)num2) < (ulong)(unchecked((long)array.Length)) && FTDI.FT_Read(Diag__0.ftHandle, array, num2, ref num3) == FTDI.FT_STATUS.FT_OK && num3 > 0U)
						{
							Array.Copy(array, 0L, array2, (long)(unchecked((ulong)num4)), (long)(unchecked((ulong)num3)));
							num4 += num3;
							if (unchecked((ulong)num4) >= (ulong)(unchecked((long)(checked(commandSize + 2)))))
							{
								if (num5 == 0U)
								{
									num5 = (uint)array2[commandSize + 1];
								}
								if (unchecked((ulong)num4) - (ulong)(unchecked((long)commandSize)) == unchecked((ulong)num5))
								{
									replySize = num5;
									Array.Copy(array2, (long)(unchecked((ulong)(checked(num4 - num5)))), reply, 0L, (long)(unchecked((ulong)num5)));
									if (this.ValidateChecksum(reply, (int)num5))
									{
										goto IL_127;
									}
								}
							}
						}
					}
					while (stopwatch.ElapsedMilliseconds < num6);
					stopwatch.Stop();
					FTDI.FT_Purge(Diag__0.ftHandle, 3U);
					return false;
					IL_127:
					stopwatch.Stop();
					FTDI.FT_Purge(Diag__0.ftHandle, 3U);
					result = true;
				}
				else
				{
					result = false;
				}
				return result;
			}
		}

		// Token: 0x060010D1 RID: 4305 RVA: 0x0000B489 File Offset: 0x0000B489
		private bool ValidateChecksum(byte[] data, int dataSize)
		{
			return checked(this.Checksum8BitHonda(data, dataSize - 1, 0) == data[dataSize - 1]);
		}

		// Token: 0x060010D2 RID: 4306 RVA: 0x0005358C File Offset: 0x0005358C
		private byte Checksum8BitHonda(byte[] data, int dataSize, int startPos = 0)
		{
			checked
			{
				int num = startPos + dataSize;
				int num2 = 0;
				while (startPos < num)
				{
					num2 += (int)data[startPos];
					startPos++;
				}
				return (byte)((num2 ^ 255) + 1 & 255);
			}
		}

		// Token: 0x060010D3 RID: 4307 RVA: 0x0007C6AC File Offset: 0x0007C6AC
		private void button3_Click(object sender, EventArgs e)
		{
			CancellationTokenSource cancellationTokenSource = this._cancellationTokenSource;
			if (cancellationTokenSource != null)
			{
				cancellationTokenSource.Cancel();
			}
			this.listBox1.Visible = true;
			this.ClearAllMessages();
			this.dtc();
			this.dtc2();
			this.dtc3();
			this.dtc4();
			this.ContohPemanggilanGabung();
		}

		// Token: 0x060010D4 RID: 4308 RVA: 0x0007C6FC File Offset: 0x0007C6FC
		private void button4_Click(object sender, EventArgs e)
		{
			CancellationTokenSource cancellationTokenSource = this._cancellationTokenSource;
			if (cancellationTokenSource != null)
			{
				cancellationTokenSource.Cancel();
			}
			this.rst();
			this.rst1();
			this.rst2();
			this.rst3();
			this.rst4();
			Thread.Sleep(1000);
			MessageBox.Show("Finish Reset ECM !", "Honda Flash Program (K-Line)", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1, (MessageBoxOptions)262144);
			this.ClearAllMessages();
			this.dtc();
			this.dtc2();
			this.dtc3();
			this.dtc4();
			this.ContohPemanggilanGabung();
		}

		// Token: 0x060010D5 RID: 4309 RVA: 0x0007C780 File Offset: 0x0007C780
		private void SecondForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			CancellationTokenSource cancellationTokenSource = this._cancellationTokenSource;
			if (cancellationTokenSource == null)
			{
				return;
			}
			cancellationTokenSource.Cancel();
		}

		// Token: 0x060010D6 RID: 4310 RVA: 0x0007C7A0 File Offset: 0x0007C7A0
		private void Diag_Paint(object sender, PaintEventArgs e)
		{
			int radius = 20;
			using (GraphicsPath roundedPath = Diag__0.GetRoundedPath(base.ClientRectangle, radius))
			{
				base.Region = new Region(roundedPath);
			}
			this.DrawNeonBorder(e.Graphics, Color.Cyan, radius, 2);
		}

		// Token: 0x060010D7 RID: 4311 RVA: 0x0000B49D File Offset: 0x0000B49D
		private void Diag_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				Diag__0.ReleaseCapture();
				Diag__0.SendMessage(base.Handle, 161, 2, 0);
			}
		}

		// Token: 0x060010D8 RID: 4312 RVA: 0x0007C7F8 File Offset: 0x0007C7F8
		private void Diag_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Control && e.KeyCode == Keys.E)
			{
				this.button1_Click(sender, e);
			}
			if (e.Control && e.KeyCode == Keys.D)
			{
				this.button3_Click(sender, e);
			}
			if (e.Control && e.KeyCode == Keys.R)
			{
				this.button4_Click(sender, e);
			}
			if (e.Control && e.KeyCode == Keys.S)
			{
				this.button2_Click(sender, e);
			}
		}

		// Token: 0x060010DC RID: 4316 RVA: 0x0007D308 File Offset: 0x0007D308
		private void InitializeCircularProgressBars()
		{
			this.circularRPM = new Diag__0.SpeedometerGauge();
			this.circularRPM.Location = new Point(45, 15);
			this.circularRPM.Size = new Size(250, 250);
			this.circularRPM.Minimum = 0f;
			this.circularRPM.Maximum = 12000f;
			this.circularRPM.Value = 0f;
			this.circularRPM.ProgressColor = Color.Lime;
			this.circularRPM.ProgressColor2 = Color.Red;
			this.circularRPM.InnerColor = Color.DimGray;
			this.circularRPM.OuterColor = Color.DarkGray;
			this.circularRPM.Font = new Font("ds-digital", 35f, FontStyle.Bold);
			this.circularRPM.Text = "0 RPM";
			this.circularRPM.TextColor = Color.Cyan;
			this.circularRPM.ProgressWidth = 25;
			this.circularRPM.Rotation = -90f;
			this.circularRPM.BackColor = Color.Black;
			this.lblRPMValue = new Label();
			this.lblRPMValue.Location = new Point(75, 275);
			this.lblRPMValue.Size = new Size(200, 25);
			this.lblRPMValue.Text = "RPM: 0";
			this.lblRPMValue.ForeColor = Color.Cyan;
			this.lblRPMValue.Font = new Font("ds-digital", 17f, FontStyle.Bold);
			this.lblRPMValue.TextAlign = ContentAlignment.MiddleCenter;
			this.circularTPS = new Diag__0.SpeedometerGauge();
			this.circularTPS.Location = new Point(340, 15);
			this.circularTPS.Size = new Size(250, 250);
			this.circularTPS.Minimum = 0f;
			this.circularTPS.Maximum = 100f;
			this.circularTPS.Value = 0f;
			this.circularTPS.ProgressColor = Color.Lime;
			this.circularTPS.ProgressColor2 = Color.Red;
			this.circularTPS.InnerColor = Color.DimGray;
			this.circularTPS.OuterColor = Color.DarkGray;
			this.circularTPS.Font = new Font("ds-digital", 35f, FontStyle.Bold);
			this.circularTPS.Text = "0%";
			this.circularTPS.TextColor = Color.Cyan;
			this.circularTPS.ProgressWidth = 25;
			this.circularTPS.Rotation = -90f;
			this.circularTPS.BackColor = Color.Black;
			this.lblTPSValue = new Label();
			this.lblTPSValue.Location = new Point(370, 275);
			this.lblTPSValue.Size = new Size(200, 25);
			this.lblTPSValue.Text = "TPS: 0°";
			this.lblTPSValue.ForeColor = Color.Cyan;
			this.lblTPSValue.Font = new Font("ds-digital", 17f, FontStyle.Bold);
			this.lblTPSValue.TextAlign = ContentAlignment.MiddleCenter;
			this.panel4.Controls.Add(this.circularRPM);
			this.panel4.Controls.Add(this.circularTPS);
			this.panel4.Controls.Add(this.lblRPMValue);
			this.panel4.Controls.Add(this.lblTPSValue);
			this.circularRPM.BringToFront();
			this.circularTPS.BringToFront();
			this.lblRPMValue.BringToFront();
			this.lblTPSValue.BringToFront();
		}

		// Token: 0x060010DD RID: 4317 RVA: 0x0007D6C4 File Offset: 0x0007D6C4
		private void UpdateCircularProgressBars(int rpm, float tpsDegree)
		{
			if (base.InvokeRequired)
			{
				base.Invoke(new Action(delegate()
				{
					this.UpdateCircularProgressBars(rpm, tpsDegree);
				}));
				return;
			}
			if (this.circularRPM != null)
			{
				int num = Math.Max(0, Math.Min(rpm, 12000));
				this.circularRPM.Value = (float)num;
				this.circularRPM.Text = num.ToString() + " RPM";
				this.lblRPMValue.Text = "RPM: " + num.ToString();
				if (num > 9000)
				{
					this.circularRPM.ProgressColor = Color.FromArgb(255, 0, 0);
				}
				else if (num > 7000)
				{
					this.circularRPM.ProgressColor = Color.FromArgb(255, 100, 0);
				}
				else
				{
					this.circularRPM.ProgressColor = Color.FromArgb(0, 200, 0);
				}
			}
			if (this.circularTPS != null)
			{
				int num2 = checked((int)Math.Round((double)Math.Max(0f, Math.Min(tpsDegree, 100f))));
				this.circularTPS.Value = (float)num2;
				this.circularTPS.Text = num2.ToString() + "%";
				this.lblTPSValue.Text = "TPS: " + num2.ToString() + "°";
				if (num2 > 80)
				{
					this.circularTPS.ProgressColor = Color.FromArgb(255, 0, 0);
					return;
				}
				if (num2 > 50)
				{
					this.circularTPS.ProgressColor = Color.FromArgb(255, 150, 0);
					return;
				}
				this.circularTPS.ProgressColor = Color.FromArgb(0, 200, 100);
			}
		}

		// Token: 0x060010DE RID: 4318 RVA: 0x0007D898 File Offset: 0x0007D898
		private void ChangeListBoxBackColor()
		{
			if (this.listBox1 != null)
			{
				this.listBox1.BackColor = Color.FromArgb(45, 50, 65);
				this.listBox1.ForeColor = Color.White;
			}
			if (this.panel4 != null)
			{
				this.panel4.BackColor = Color.Black;
			}
		}

		// Token: 0x060010E1 RID: 4321 RVA: 0x0007D8EC File Offset: 0x0007D8EC
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			using (GraphicsPath roundedPath = Diag__0.GetRoundedPath(base.ClientRectangle, 20))
			{
				base.Region = new Region(roundedPath);
			}
			using (GraphicsPath roundedPath2 = Diag__0.GetRoundedPath(new Rectangle(1, 1, base.ClientSize.Width - 2, base.ClientSize.Height - 2), 20))
			{
				using (Pen pen = new Pen(this.borderColor, 2f))
				{
					e.Graphics.DrawPath(pen, roundedPath2);
				}
			}
		}

		// Token: 0x060010E2 RID: 4322 RVA: 0x0007D9C0 File Offset: 0x0007D9C0
		private static GraphicsPath GetRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = radius * 2;
			if (num <= 0 || rect.Width <= num || rect.Height <= num)
			{
				graphicsPath.AddRectangle(rect);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
			graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x060010E3 RID: 4323 RVA: 0x0007DA90 File Offset: 0x0007DA90
		private void DrawGlow(Graphics g, GraphicsPath path, Color color)
		{
			foreach (ValueTuple<float, int> valueTuple in new ValueTuple<float, int>[]
			{
				new ValueTuple<float, int>(18f, 20),
				new ValueTuple<float, int>(14f, 40),
				new ValueTuple<float, int>(10f, 70),
				new ValueTuple<float, int>(7f, 110),
				new ValueTuple<float, int>(5f, 160)
			})
			{
				float item = valueTuple.Item1;
				using (Pen pen = new Pen(Color.FromArgb(valueTuple.Item2, color), item))
				{
					pen.LineJoin = LineJoin.Round;
					g.DrawPath(pen, path);
				}
			}
		}

		// Token: 0x060010E4 RID: 4324 RVA: 0x0007DB60 File Offset: 0x0007DB60
		private void DrawNeonBorder(Graphics g, Color color, int radius, int borderThickness = 2)
		{
			g.SmoothingMode = SmoothingMode.AntiAlias;
			using (GraphicsPath roundedPath = Diag__0.GetRoundedPath(new Rectangle(borderThickness / 2, borderThickness / 2, base.ClientSize.Width - borderThickness, base.ClientSize.Height - borderThickness), radius))
			{
				foreach (ValueTuple<float, int> valueTuple in new ValueTuple<float, int>[]
				{
					new ValueTuple<float, int>(18f, 20),
					new ValueTuple<float, int>(14f, 40),
					new ValueTuple<float, int>(10f, 70),
					new ValueTuple<float, int>(7f, 110),
					new ValueTuple<float, int>(5f, 160)
				})
				{
					float item = valueTuple.Item1;
					using (Pen pen = new Pen(Color.FromArgb(valueTuple.Item2, color), item))
					{
						pen.LineJoin = LineJoin.Round;
						g.DrawPath(pen, roundedPath);
					}
				}
				using (Pen pen2 = new Pen(Color.FromArgb(255, color), (float)borderThickness))
				{
					pen2.LineJoin = LineJoin.Round;
					g.DrawPath(pen2, roundedPath);
				}
				using (Pen pen3 = new Pen(Color.FromArgb(180, 255, 255, 255), 1f))
				{
					g.DrawPath(pen3, roundedPath);
				}
			}
		}

		// Token: 0x060010E5 RID: 4325 RVA: 0x0007DD44 File Offset: 0x0007DD44
		private void DgvContainer_Paint(object sender, PaintEventArgs e)
		{
			Panel panel = (Panel)sender;
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			int radius = 12;
			int num = 2;
			using (GraphicsPath roundedPath = Diag__0.GetRoundedPath(new Rectangle(0, 0, panel.ClientSize.Width, panel.ClientSize.Height), radius))
			{
				panel.Region = new Region(roundedPath);
			}
			using (GraphicsPath roundedPath2 = Diag__0.GetRoundedPath(new Rectangle(num / 2, num / 2, panel.ClientSize.Width - num, panel.ClientSize.Height - num), radius))
			{
				using (Pen pen = new Pen(Color.FromArgb(60, Color.Cyan), (float)(num + 4)))
				{
					pen.LineJoin = LineJoin.Round;
					e.Graphics.DrawPath(pen, roundedPath2);
				}
				using (Pen pen2 = new Pen(Color.Cyan, (float)num))
				{
					pen2.LineJoin = LineJoin.Round;
					e.Graphics.DrawPath(pen2, roundedPath2);
				}
			}
		}

		// Token: 0x060010E9 RID: 4329 RVA: 0x0007DE94 File Offset: 0x0007DE94
		private void Panel_Paint(object sender, PaintEventArgs e)
		{
			Panel panel = sender as Panel;
			if (panel == null)
			{
				return;
			}
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			int radius = 10;
			int num = 2;
			using (GraphicsPath roundedPath = Diag__0.GetRoundedPath(new Rectangle(0, 0, panel.ClientSize.Width, panel.ClientSize.Height), radius))
			{
				panel.Region = new Region(roundedPath);
			}
			using (GraphicsPath roundedPath2 = Diag__0.GetRoundedPath(new Rectangle(num / 2, num / 2, panel.ClientSize.Width - num, panel.ClientSize.Height - num), radius))
			{
				foreach (ValueTuple<float, int> valueTuple in new ValueTuple<float, int>[]
				{
					new ValueTuple<float, int>(12f, 25),
					new ValueTuple<float, int>(9f, 50),
					new ValueTuple<float, int>(6f, 90),
					new ValueTuple<float, int>(4f, 140)
				})
				{
					float item = valueTuple.Item1;
					using (Pen pen = new Pen(Color.FromArgb(valueTuple.Item2, Color.Cyan), item))
					{
						pen.LineJoin = LineJoin.Round;
						e.Graphics.DrawPath(pen, roundedPath2);
					}
				}
				using (Pen pen2 = new Pen(Color.Cyan, (float)num))
				{
					pen2.LineJoin = LineJoin.Round;
					e.Graphics.DrawPath(pen2, roundedPath2);
				}
				using (Pen pen3 = new Pen(Color.FromArgb(180, 255, 255, 255), 1f))
				{
					e.Graphics.DrawPath(pen3, roundedPath2);
				}
			}
		}

		// Token: 0x060010EA RID: 4330 RVA: 0x0007E0EC File Offset: 0x0007E0EC
		private void Button_Paint(object sender, PaintEventArgs e)
		{
			Button button = sender as Button;
			if (button == null)
			{
				return;
			}
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			int radius = 10;
			int num = 2;
			using (GraphicsPath roundedPath = Diag__0.GetRoundedPath(new Rectangle(0, 0, button.ClientSize.Width, button.ClientSize.Height), radius))
			{
				button.Region = new Region(roundedPath);
			}
			using (GraphicsPath roundedPath2 = Diag__0.GetRoundedPath(new Rectangle(0, 0, button.ClientSize.Width, button.ClientSize.Height), radius))
			{
				using (SolidBrush solidBrush = new SolidBrush(button.BackColor))
				{
					e.Graphics.FillPath(solidBrush, roundedPath2);
				}
			}
			using (GraphicsPath roundedPath3 = Diag__0.GetRoundedPath(new Rectangle(num / 2, num / 2, button.ClientSize.Width - num, button.ClientSize.Height - num), radius))
			{
				foreach (ValueTuple<float, int> valueTuple in new ValueTuple<float, int>[]
				{
					new ValueTuple<float, int>(10f, 40),
					new ValueTuple<float, int>(7f, 80),
					new ValueTuple<float, int>(5f, 130)
				})
				{
					float item = valueTuple.Item1;
					using (Pen pen = new Pen(Color.FromArgb(valueTuple.Item2, Color.Cyan), item))
					{
						pen.LineJoin = LineJoin.Round;
						e.Graphics.DrawPath(pen, roundedPath3);
					}
				}
				using (Pen pen2 = new Pen(Color.Cyan, (float)num))
				{
					pen2.LineJoin = LineJoin.Round;
					e.Graphics.DrawPath(pen2, roundedPath3);
				}
			}
			TextRenderer.DrawText(e.Graphics, button.Text, button.Font, button.ClientRectangle, button.ForeColor, TextFormatFlags.EndEllipsis | TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
		}

		// Token: 0x060010EB RID: 4331 RVA: 0x0007E34C File Offset: 0x0007E34C
		private void Button_Resize(object sender, EventArgs e)
		{
			Button button = sender as Button;
			if (button == null)
			{
				return;
			}
			int radius = 10;
			using (GraphicsPath roundedPath = Diag__0.GetRoundedPath(new Rectangle(0, 0, button.ClientSize.Width, button.ClientSize.Height), radius))
			{
				button.Region = new Region(roundedPath);
			}
			button.Invalidate();
		}

		// Token: 0x060010EC RID: 4332 RVA: 0x0007E3C0 File Offset: 0x0007E3C0
		private void Button_MouseEnter(object sender, EventArgs e)
		{
			Button button = sender as Button;
			if (button == null)
			{
				return;
			}
			button.BackColor = Color.FromArgb(60, 80, 110);
			button.Invalidate();
		}

		// Token: 0x060010ED RID: 4333 RVA: 0x0007E3F0 File Offset: 0x0007E3F0
		private void Button_MouseLeave(object sender, EventArgs e)
		{
			Button button = sender as Button;
			if (button == null)
			{
				return;
			}
			button.BackColor = Color.FromArgb(45, 50, 65);
			button.Invalidate();
		}

		// Token: 0x060010EE RID: 4334 RVA: 0x0000B50A File Offset: 0x0000B50A
		private static Color SafeColor(Color c, Color fallback)
		{
			if (c == Color.Empty)
			{
				return fallback;
			}
			return c;
		}

		// Token: 0x04001747 RID: 5959
		public const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x04001748 RID: 5960
		public const int HT_CAPTION = 2;

		// Token: 0x04001749 RID: 5961
		private static IntPtr ftHandle = IntPtr.Zero;

		// Token: 0x0400174A RID: 5962
		private bool tek10;

		// Token: 0x0400174B RID: 5963
		private bool tek11;

		// Token: 0x0400174C RID: 5964
		private bool tek13;

		// Token: 0x0400174D RID: 5965
		private bool tek16;

		// Token: 0x0400174E RID: 5966
		private bool tek17;

		// Token: 0x0400174F RID: 5967
		private CancellationTokenSource _cancellationTokenSource;

		// Token: 0x04001750 RID: 5968
		private DataGridView dataGridView;

		// Token: 0x04001751 RID: 5969
		private DataGridView dataGridView2;

		// Token: 0x04001752 RID: 5970
		private string combinedResult;

		// Token: 0x04001753 RID: 5971
		private Dictionary<string, string> errorMessages;

		// Token: 0x04001754 RID: 5972
		private string Hasil;

		// Token: 0x04001755 RID: 5973
		private string Hasil2;

		// Token: 0x04001756 RID: 5974
		private string Hasil3;

		// Token: 0x04001757 RID: 5975
		private string Hasil4;

		// Token: 0x04001758 RID: 5976
		private string hasilGabungan;

		// Token: 0x04001759 RID: 5977
		private int dtcCounter;

		// Token: 0x0400175A RID: 5978
		private bool dtcTitleAdded;

		// Token: 0x0400175B RID: 5979
		private float o2;

		// Token: 0x0400175C RID: 5980
		private float oxi;

		// Token: 0x0400175D RID: 5981
		private float o2v;

		// Token: 0x0400175E RID: 5982
		private float stf;

		// Token: 0x0400175F RID: 5983
		private float afr;

		// Token: 0x04001760 RID: 5984
		private string fiz;

		// Token: 0x04001761 RID: 5985
		private string bas;

		// Token: 0x04001762 RID: 5986
		private string sss;

		// Token: 0x04001763 RID: 5987
		private string ssw;

		// Token: 0x04001764 RID: 5988
		private string ggs;

		// Token: 0x04001765 RID: 5989
		private string pom;

		// Token: 0x04001766 RID: 5990
		private string fan;

		// Token: 0x04001767 RID: 5991
		private string ggv;

		// Token: 0x04001772 RID: 6002
		private Label lblRPMValue;

		// Token: 0x04001773 RID: 6003
		private Label lblTPSValue;

		// Token: 0x04001774 RID: 6004
		private Diag__0.SpeedometerGauge circularRPM;

		// Token: 0x04001775 RID: 6005
		private Diag__0.SpeedometerGauge circularTPS;

		// Token: 0x04001776 RID: 6006
		private const int CornerRadius = 20;

		// Token: 0x04001777 RID: 6007
		private const int BorderThickness = 2;

		// Token: 0x04001778 RID: 6008
		private readonly Color borderColor;

		// Token: 0x04001779 RID: 6009
		private Panel dgv1Container;

		// Token: 0x0400177A RID: 6010
		private Panel dgv2Container;

		// Token: 0x0400177B RID: 6011
		private static readonly Color WebBg;

		// Token: 0x0400177C RID: 6012
		private static readonly Color WebSurface;

		// Token: 0x0400177D RID: 6013
		private static readonly Color WebSurface2;

		// Token: 0x0400177E RID: 6014
		private static readonly Color WebBorder;

		// Token: 0x0400177F RID: 6015
		private static readonly Color WebGrid;

		// Token: 0x04001780 RID: 6016
		private static readonly Color WebText;

		// Token: 0x04001781 RID: 6017
		private static readonly Color WebTextMuted;

		// Token: 0x04001782 RID: 6018
		private static readonly Color WebAccent;

		// Token: 0x04001783 RID: 6019
		private static readonly Color WebAccentDim;

		// Token: 0x04001784 RID: 6020
		private static readonly Color WebSelBack;

		// Token: 0x04001785 RID: 6021
		private static readonly Color WebSelFore;

		// Token: 0x04001786 RID: 6022
		private static readonly Color WebHeaderBack;

		// Token: 0x04001787 RID: 6023
		private static readonly Color WebHeaderFore;

		// Token: 0x04001788 RID: 6024
		private static readonly Color WebHover;

		// Token: 0x02000720 RID: 1824
		public class SpeedometerGauge : Control
		{
			// Token: 0x17000092 RID: 146
			// (get) Token: 0x060010EF RID: 4335 RVA: 0x0000B51C File Offset: 0x0000B51C
			// (set) Token: 0x060010F0 RID: 4336 RVA: 0x0000B524 File Offset: 0x0000B524
			public Color ProgressColor { get; set; }

			// Token: 0x17000093 RID: 147
			// (get) Token: 0x060010F1 RID: 4337 RVA: 0x0000B52D File Offset: 0x0000B52D
			// (set) Token: 0x060010F2 RID: 4338 RVA: 0x0000B535 File Offset: 0x0000B535
			[Browsable(false)]
			public Color ProgressColor2 { get; set; } = Color.Empty;

			// Token: 0x17000094 RID: 148
			// (get) Token: 0x060010F3 RID: 4339 RVA: 0x0000B53E File Offset: 0x0000B53E
			// (set) Token: 0x060010F4 RID: 4340 RVA: 0x0000B546 File Offset: 0x0000B546
			[Browsable(false)]
			public Color InnerColor
			{
				get
				{
					return this._innerColor;
				}
				set
				{
					this._innerColor = value;
					base.Invalidate();
				}
			}

			// Token: 0x17000095 RID: 149
			// (get) Token: 0x060010F5 RID: 4341 RVA: 0x0000B555 File Offset: 0x0000B555
			// (set) Token: 0x060010F6 RID: 4342 RVA: 0x0000B55D File Offset: 0x0000B55D
			[Browsable(false)]
			public Color OuterColor
			{
				get
				{
					return this._outerColor;
				}
				set
				{
					this._outerColor = value;
					base.Invalidate();
				}
			}

			// Token: 0x17000096 RID: 150
			// (get) Token: 0x060010F7 RID: 4343 RVA: 0x0000B56C File Offset: 0x0000B56C
			// (set) Token: 0x060010F8 RID: 4344 RVA: 0x0000B574 File Offset: 0x0000B574
			[Browsable(false)]
			public Color TextColor
			{
				get
				{
					return this._textColor;
				}
				set
				{
					this._textColor = value;
					base.Invalidate();
				}
			}

			// Token: 0x17000097 RID: 151
			// (get) Token: 0x060010F9 RID: 4345 RVA: 0x0000B583 File Offset: 0x0000B583
			// (set) Token: 0x060010FA RID: 4346 RVA: 0x0000B58B File Offset: 0x0000B58B
			[Browsable(false)]
			public int ProgressWidth { get; set; }

			// Token: 0x17000098 RID: 152
			// (get) Token: 0x060010FB RID: 4347 RVA: 0x0000B594 File Offset: 0x0000B594
			// (set) Token: 0x060010FC RID: 4348 RVA: 0x0000B59C File Offset: 0x0000B59C
			[Browsable(false)]
			public float Rotation { get; set; }

			// Token: 0x060010FD RID: 4349 RVA: 0x0007E420 File Offset: 0x0007E420
			public SpeedometerGauge()
			{
				this._textColor = Color.Cyan;
				this.ProgressWidth = 25;
				this.Rotation = -90f;
				this._maxValue = 100f;
				this.lockObject = new object();
				this.ProgressColor = Color.Cyan;
				this.Title = "";
				this.Unit = "";
				this.AnimationSpeed = 0.1f;
				this._isActive = false;
				this._isRecording = false;
				this.animationTimer = new System.Windows.Forms.Timer
				{
					Interval = 16
				};
				this.animationTimer.Tick += this.AnimationTimer_Tick;
				this._blinkTimer = new System.Windows.Forms.Timer
				{
					Interval = 250
				};
				this._blinkTimer.Tick += delegate(object s, EventArgs e)
				{
					if (this.IsRecording)
					{
						this._blinkPhase = checked(this._blinkPhase + 1) % 2;
						base.Invalidate();
					}
				};
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer, true);
				base.Size = new Size(150, 150);
			}

			// Token: 0x060010FE RID: 4350 RVA: 0x0007E53C File Offset: 0x0007E53C
			protected override void OnPaint(PaintEventArgs e)
			{
				Graphics graphics = e.Graphics;
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
				Control parent = base.Parent;
				graphics.Clear((parent != null) ? parent.BackColor : Color.FromArgb(32, 32, 35));
				int num = base.Width / 2;
				int num2 = base.Height / 2;
				checked
				{
					int num3 = Math.Min(base.Width - 6, base.Height - 6) / 2;
					if (num3 <= 0)
					{
						num3 = 50;
					}
					if (this.IsActive)
					{
						using (GraphicsPath graphicsPath = new GraphicsPath())
						{
							graphicsPath.AddEllipse(num - num3 - 25, num2 - num3 - 25, (num3 + 25) * 2, (num3 + 25) * 2);
							using (PathGradientBrush pathGradientBrush = new PathGradientBrush(graphicsPath))
							{
								pathGradientBrush.CenterColor = Color.FromArgb(40, (int)this.ProgressColor.R, (int)this.ProgressColor.G, (int)this.ProgressColor.B);
								pathGradientBrush.SurroundColors = new Color[]
								{
									Color.Transparent
								};
								graphics.FillPath(pathGradientBrush, graphicsPath);
							}
						}
					}
					using (GraphicsPath graphicsPath2 = new GraphicsPath())
					{
						graphicsPath2.AddEllipse(num - num3, num2 - num3, num3 * 2, num3 * 2);
						Color color = this.IsActive ? Color.FromArgb(180, (int)this.ProgressColor.R, (int)this.ProgressColor.G, (int)this.ProgressColor.B) : Color.FromArgb(180, 185, 195);
						Color color2 = this.IsActive ? Color.FromArgb(100, (int)(this.ProgressColor.R / 2), (int)(this.ProgressColor.G / 2), (int)(this.ProgressColor.B / 2)) : Color.FromArgb(40, 45, 55);
						using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(new Rectangle(num - num3, num2 - num3, num3 * 2, num3 * 2), color, color2, LinearGradientMode.ForwardDiagonal))
						{
							graphics.FillPath(linearGradientBrush, graphicsPath2);
							graphics.DrawPath(new Pen(this.IsActive ? this.ProgressColor : Color.FromArgb(220, 225, 235), this.IsActive ? 3.5f : 2.5f), graphicsPath2);
						}
					}
					int num4 = num3 - 10;
					using (GraphicsPath graphicsPath3 = new GraphicsPath())
					{
						graphicsPath3.AddEllipse(num - num4, num2 - num4, num4 * 2, num4 * 2);
						Color color3 = this.IsActive ? Color.FromArgb(200, 60, 65, 75) : Color.FromArgb(60, 65, 75);
						Color color4 = this.IsActive ? Color.FromArgb(200, 20, 22, 28) : Color.FromArgb(20, 22, 28);
						using (LinearGradientBrush linearGradientBrush2 = new LinearGradientBrush(new Rectangle(num - num4, num2 - num4, num4 * 2, num4 * 2), color3, color4, LinearGradientMode.BackwardDiagonal))
						{
							graphics.FillPath(linearGradientBrush2, graphicsPath3);
						}
					}
					int num5 = num4 - 4;
					using (GraphicsPath graphicsPath4 = new GraphicsPath())
					{
						graphicsPath4.AddEllipse(num - num5, num2 - num5, num5 * 2, num5 * 2);
						Color color5 = this.IsActive ? Color.FromArgb(255, 255, 250) : Color.FromArgb(250, 250, 245);
						Color color6 = this.IsActive ? Color.FromArgb(240, 240, 235) : Color.FromArgb(230, 230, 220);
						using (LinearGradientBrush linearGradientBrush3 = new LinearGradientBrush(new Rectangle(num - num5, num2 - num5, num5 * 2, num5 * 2), color5, color6, LinearGradientMode.Vertical))
						{
							graphics.FillPath(linearGradientBrush3, graphicsPath4);
						}
					}
					float num6 = 135f;
					float num7 = 270f;
					float num8 = unchecked(this.MaxValue - this.MinValue) / 10f;
					for (int i = 0; i <= 50; i++)
					{
						float num9;
						float num10;
						bool flag;
						int num11;
						int num12;
						unchecked
						{
							num9 = this.MinValue + num8 * ((float)i / 5f);
							num10 = (num6 + num7 * (float)i / 50f) * 3.1415927f / 180f;
							flag = (i % 5 == 0);
							num11 = (flag ? 18 : ((i % 2 == 0) ? 10 : 5));
							num12 = (flag ? 2 : 1);
						}
						int x = num + (int)(unchecked((double)(checked(num5 - 5)) * Math.Cos((double)num10)));
						int y = num2 + (int)(unchecked((double)(checked(num5 - 5)) * Math.Sin((double)num10)));
						int x2 = num + (int)(unchecked((double)(checked(num5 - 5 - num11)) * Math.Cos((double)num10)));
						int y2 = num2 + (int)(unchecked((double)(checked(num5 - 5 - num11)) * Math.Sin((double)num10)));
						Color color7 = (this.Title == "RPM" && i >= 40) ? Color.FromArgb(200, 0, 0) : Color.FromArgb(40, 40, 40);
						if (this.IsActive && i >= 40 && this.Title == "RPM")
						{
							color7 = Color.FromArgb(255, 50, 0);
						}
						graphics.DrawLine(new Pen(color7, (float)num12), x, y, x2, y2);
						if (flag)
						{
							string text;
							if (this.Title == "AFR")
							{
								text = num9.ToString("F1");
							}
							else if (this.Title == "RPM")
							{
								text = ((num9 >= 1000f) ? string.Format("{0:F0}", num9 / 1000f) : num9.ToString("F0"));
							}
							else
							{
								text = num9.ToString("F0");
							}
							Font font = new Font("Arial", 8.5f, FontStyle.Bold);
							SizeF sizeF = graphics.MeasureString(text, font);
							int num13 = num + (int)(unchecked((double)(checked(num5 - 32)) * Math.Cos((double)num10)));
							int num14 = num2 + (int)(unchecked((double)(checked(num5 - 32)) * Math.Sin((double)num10)));
							Color color8 = this.IsActive ? Color.FromArgb(30, 30, 30) : Color.Black;
							unchecked
							{
								graphics.DrawString(text, font, new SolidBrush(color8), (float)num13 - sizeF.Width / 2f, (float)num14 - sizeF.Height / 2f);
							}
						}
					}
					float num15 = Diag__0.SpeedometerGauge.ClampValue(unchecked((this._value - this.MinValue) / (this.MaxValue - this.MinValue)), 0f, 1f);
					graphics.DrawArc(new Pen(Color.FromArgb(180, 180, 180), 5f), (float)(num - num5 + 8), (float)(num2 - num5 + 8), (float)((num5 - 8) * 2), (float)((num5 - 8) * 2), num6, num7);
					using (Pen pen = new Pen(this.ProgressColor, 5.5f)
					{
						StartCap = LineCap.Round,
						EndCap = LineCap.Round
					})
					{
						graphics.DrawArc(pen, (float)(num - num5 + 8), (float)(num2 - num5 + 8), (float)((num5 - 8) * 2), (float)((num5 - 8) * 2), num6, unchecked(num7 * num15));
					}
					if (this.IsActive && num15 > 0.01f)
					{
						using (Pen pen2 = new Pen(Color.FromArgb(60, this.ProgressColor), 12f)
						{
							StartCap = LineCap.Round,
							EndCap = LineCap.Round
						})
						{
							graphics.DrawArc(pen2, (float)(num - num5 + 8), (float)(num2 - num5 + 8), (float)((num5 - 8) * 2), (float)((num5 - 8) * 2), num6, unchecked(num7 * num15));
						}
					}
					float num16 = unchecked((num6 + num7 * num15) * 3.1415927f) / 180f;
					int num17 = num5 - 40;
					int num18 = num + (int)(unchecked((double)num17 * Math.Cos((double)num16)));
					int num19 = num2 + (int)(unchecked((double)num17 * Math.Sin((double)num16)));
					graphics.DrawLine(new Pen(Color.FromArgb(90, 0, 0, 0), 4.5f), num + 2, num2 + 2, num18 + 2, num19 + 2);
					graphics.DrawLine(new Pen(Color.Black, 2.2f)
					{
						StartCap = LineCap.Round
					}, num, num2, num18, num19);
					graphics.DrawLine(new Pen(Color.Red, 1.4f)
					{
						StartCap = LineCap.Round
					}, num, num2, num18, num19);
					using (GraphicsPath graphicsPath5 = new GraphicsPath())
					{
						graphicsPath5.AddEllipse(num - 11, num2 - 11, 22, 22);
						using (LinearGradientBrush linearGradientBrush4 = new LinearGradientBrush(new Rectangle(num - 11, num2 - 11, 22, 22), Color.FromArgb(240, 240, 240), Color.FromArgb(60, 60, 60), LinearGradientMode.Vertical))
						{
							graphics.FillPath(linearGradientBrush4, graphicsPath5);
							graphics.DrawPath(new Pen(Color.FromArgb(40, 40, 40), 1.2f), graphicsPath5);
						}
						graphics.FillEllipse(Brushes.Black, num - 5, num2 - 5, 10, 10);
						if (this.IsActive)
						{
							graphics.FillEllipse(new SolidBrush(Color.FromArgb(60, this.ProgressColor)), num - 3, num2 - 3, 6, 6);
						}
					}
					using (GraphicsPath graphicsPath6 = new GraphicsPath())
					{
						graphicsPath6.AddEllipse(num - num3 + 3, num2 - num3 + 3, (num3 - 3) * 2, (num3 - 3) * 2);
						using (PathGradientBrush pathGradientBrush2 = new PathGradientBrush(graphicsPath6))
						{
							pathGradientBrush2.CenterColor = Color.FromArgb(this.IsActive ? 35 : 25, 255, 255, 255);
							pathGradientBrush2.SurroundColors = new Color[]
							{
								Color.Transparent
							};
							graphics.FillPath(pathGradientBrush2, graphicsPath6);
						}
						graphics.FillEllipse(new SolidBrush(Color.FromArgb(18, 255, 255, 255)), num - num3 / 2 - 5, num2 - num3 / 2 - 5, num3 + 10, num3 / 2 + 10);
					}
					string text2 = (this.Title == "AFR") ? this._value.ToString("F1") : this._value.ToString("F0");
					Font font2 = new Font("ds-digital", 30f, FontStyle.Bold);
					SizeF sizeF2 = graphics.MeasureString(text2, font2);
					Color color9 = this.IsActive ? Color.FromArgb(20, 20, 20) : Color.Black;
					graphics.DrawString(text2, font2, new SolidBrush(color9), unchecked((float)num - sizeF2.Width / 2f), (float)(num2 + 22));
					Font font3 = new Font("Arial", 8.5f, FontStyle.Bold);
					SizeF sizeF3 = graphics.MeasureString(this.Title, font3);
					Color color10 = this.IsActive ? Color.FromArgb(40, 40, 40) : Color.Black;
					graphics.DrawString(this.Title, font3, new SolidBrush(color10), unchecked((float)num - sizeF3.Width / 2f), (float)(num2 - 40));
					graphics.DrawString(this.Unit, new Font("Arial", 7f), Brushes.Gray, (float)(num - 6), (float)(num2 + 38));
					if (this.IsActive)
					{
						int num20 = num + num5 - 22;
						int num21 = num2 + num5 - 22;
						int num22 = 10;
						bool flag2 = this.IsRecording && this._blinkPhase == 0;
						Color centerColor = flag2 ? Color.FromArgb(255, 255, 0, 0) : Color.FromArgb(96, 0, 255, 0);
						Color color11 = flag2 ? Color.FromArgb(255, 255, 50, 50) : Color.FromArgb(200, 0, 255, 100);
						Color color12 = flag2 ? Color.FromArgb(255, 170, 0, 0) : Color.FromArgb(0, 160, 40);
						using (GraphicsPath graphicsPath7 = new GraphicsPath())
						{
							int num23 = flag2 ? 16 : 10;
							graphicsPath7.AddEllipse(num20 - num23, num21 - num23, num22 + num23 * 2, num22 + num23 * 2);
							using (PathGradientBrush pathGradientBrush3 = new PathGradientBrush(graphicsPath7))
							{
								pathGradientBrush3.CenterColor = centerColor;
								pathGradientBrush3.SurroundColors = new Color[]
								{
									Color.Transparent
								};
								graphics.FillPath(pathGradientBrush3, graphicsPath7);
							}
						}
						using (GraphicsPath graphicsPath8 = new GraphicsPath())
						{
							graphicsPath8.AddEllipse(num20, num21, num22, num22);
							using (LinearGradientBrush linearGradientBrush5 = new LinearGradientBrush(new Rectangle(num20, num21, num22, num22), color11, Color.FromArgb(0, 96, 0), LinearGradientMode.Vertical))
							{
								graphics.FillPath(linearGradientBrush5, graphicsPath8);
								graphics.DrawPath(new Pen(color12, 1.5f), graphicsPath8);
							}
						}
						if (this.IsRecording)
						{
							Font font4 = new Font("Arial", 9f, FontStyle.Bold);
							graphics.DrawString("REC", font4, new SolidBrush(Color.FromArgb(255, 255, 50, 50)), (float)(num20 + 14), (float)(num21 - 1));
						}
					}
				}
			}

			// Token: 0x060010FF RID: 4351 RVA: 0x0007F400 File Offset: 0x0007F400
			protected override void Dispose(bool disposing)
			{
				if (disposing)
				{
					System.Windows.Forms.Timer timer = this.animationTimer;
					if (timer != null)
					{
						timer.Dispose();
					}
					System.Windows.Forms.Timer blinkTimer = this._blinkTimer;
					if (blinkTimer != null)
					{
						blinkTimer.Dispose();
					}
				}
				base.Dispose(disposing);
			}

			// Token: 0x17000099 RID: 153
			// (get) Token: 0x06001100 RID: 4352 RVA: 0x0000B5A5 File Offset: 0x0000B5A5
			// (set) Token: 0x06001101 RID: 4353 RVA: 0x0007F438 File Offset: 0x0007F438
			public float Value
			{
				get
				{
					return this._value;
				}
				set
				{
					object obj = this.lockObject;
					lock (obj)
					{
						this._targetValue = Diag__0.SpeedometerGauge.ClampValue(value, this.MinValue, this.MaxValue);
						this.StartAnimation();
						if (this._targetValue > this.MinValue)
						{
							this.IsActive = true;
						}
					}
				}
			}

			// Token: 0x1700009A RID: 154
			// (get) Token: 0x06001102 RID: 4354 RVA: 0x0000B5AD File Offset: 0x0000B5AD
			// (set) Token: 0x06001103 RID: 4355 RVA: 0x0000B5B5 File Offset: 0x0000B5B5
			[Browsable(false)]
			public float Minimum
			{
				get
				{
					return this.MinValue;
				}
				set
				{
					this.MinValue = value;
				}
			}

			// Token: 0x1700009B RID: 155
			// (get) Token: 0x06001104 RID: 4356 RVA: 0x0000B5BE File Offset: 0x0000B5BE
			// (set) Token: 0x06001105 RID: 4357 RVA: 0x0000B5C6 File Offset: 0x0000B5C6
			[Browsable(false)]
			public float Maximum
			{
				get
				{
					return this.MaxValue;
				}
				set
				{
					this.MaxValue = value;
				}
			}

			// Token: 0x06001106 RID: 4358 RVA: 0x0007F4A8 File Offset: 0x0007F4A8
			private void AnimationTimer_Tick(object sender, EventArgs e)
			{
				object obj = this.lockObject;
				lock (obj)
				{
					float num = this._targetValue - this._value;
					if (Math.Abs(num) < 0.03f)
					{
						this._value = this._targetValue;
						this.animationTimer.Stop();
					}
					else
					{
						this._value += num * this.AnimationSpeed;
					}
					base.Invalidate();
				}
			}

			// Token: 0x06001107 RID: 4359 RVA: 0x0000B5CF File Offset: 0x0000B5CF
			private void StartAnimation()
			{
				if (!this.animationTimer.Enabled)
				{
					this.animationTimer.Start();
				}
			}

			// Token: 0x1700009C RID: 156
			// (get) Token: 0x06001108 RID: 4360 RVA: 0x0000B5E9 File Offset: 0x0000B5E9
			// (set) Token: 0x06001109 RID: 4361 RVA: 0x0000B5F1 File Offset: 0x0000B5F1
			public string Title { get; set; }

			// Token: 0x1700009D RID: 157
			// (get) Token: 0x0600110A RID: 4362 RVA: 0x0000B5FA File Offset: 0x0000B5FA
			// (set) Token: 0x0600110B RID: 4363 RVA: 0x0000B602 File Offset: 0x0000B602
			public string Unit { get; set; }

			// Token: 0x1700009E RID: 158
			// (get) Token: 0x0600110C RID: 4364 RVA: 0x0000B60B File Offset: 0x0000B60B
			// (set) Token: 0x0600110D RID: 4365 RVA: 0x0000B613 File Offset: 0x0000B613
			public float AnimationSpeed { get; set; }

			// Token: 0x1700009F RID: 159
			// (get) Token: 0x0600110E RID: 4366 RVA: 0x0000B61C File Offset: 0x0000B61C
			// (set) Token: 0x0600110F RID: 4367 RVA: 0x0000B624 File Offset: 0x0000B624
			public bool IsActive
			{
				get
				{
					return this._isActive;
				}
				set
				{
					this._isActive = value;
					base.Invalidate();
				}
			}

			// Token: 0x170000A0 RID: 160
			// (get) Token: 0x06001110 RID: 4368 RVA: 0x0000B633 File Offset: 0x0000B633
			// (set) Token: 0x06001111 RID: 4369 RVA: 0x0000B63B File Offset: 0x0000B63B
			public bool IsRecording
			{
				get
				{
					return this._isRecording;
				}
				set
				{
					if (this._isRecording != value)
					{
						this._isRecording = value;
						if (this._isRecording)
						{
							this._blinkTimer.Start();
						}
						else
						{
							this._blinkTimer.Stop();
							this._blinkPhase = 0;
						}
						base.Invalidate();
					}
				}
			}

			// Token: 0x06001112 RID: 4370 RVA: 0x0000B67A File Offset: 0x0000B67A
			private static float ClampValue(float nilai, float min, float max)
			{
				if (nilai < min)
				{
					return min;
				}
				if (nilai > max)
				{
					return max;
				}
				return nilai;
			}

			// Token: 0x06001113 RID: 4371 RVA: 0x0000B689 File Offset: 0x0000B689
			protected override void OnResize(EventArgs e)
			{
				base.OnResize(e);
				base.Invalidate();
			}

			// Token: 0x170000A1 RID: 161
			// (get) Token: 0x06001114 RID: 4372 RVA: 0x0000B698 File Offset: 0x0000B698
			// (set) Token: 0x06001115 RID: 4373 RVA: 0x0000B6A0 File Offset: 0x0000B6A0
			public float MinValue
			{
				get
				{
					return this._minValue;
				}
				set
				{
					this._minValue = value;
					base.Invalidate();
				}
			}

			// Token: 0x170000A2 RID: 162
			// (get) Token: 0x06001116 RID: 4374 RVA: 0x0000B6AF File Offset: 0x0000B6AF
			// (set) Token: 0x06001117 RID: 4375 RVA: 0x0000B6B7 File Offset: 0x0000B6B7
			public float MaxValue
			{
				get
				{
					return this._maxValue;
				}
				set
				{
					this._maxValue = value;
					base.Invalidate();
				}
			}

			// Token: 0x04001790 RID: 6032
			private float _value;

			// Token: 0x04001791 RID: 6033
			private float _minValue;

			// Token: 0x04001792 RID: 6034
			private float _maxValue;

			// Token: 0x04001793 RID: 6035
			private float _targetValue;

			// Token: 0x04001794 RID: 6036
			private bool _isActive;

			// Token: 0x04001795 RID: 6037
			private bool _isRecording;

			// Token: 0x04001796 RID: 6038
			private int _blinkPhase;

			// Token: 0x04001797 RID: 6039
			private readonly System.Windows.Forms.Timer _blinkTimer;

			// Token: 0x04001798 RID: 6040
			private Color _textColor;

			// Token: 0x04001799 RID: 6041
			private Color _innerColor = Color.DimGray;

			// Token: 0x0400179A RID: 6042
			private Color _outerColor = Color.DarkGray;

			// Token: 0x0400179B RID: 6043
			private readonly System.Windows.Forms.Timer animationTimer;

			// Token: 0x0400179C RID: 6044
			private readonly object lockObject;
		}
	}
}
