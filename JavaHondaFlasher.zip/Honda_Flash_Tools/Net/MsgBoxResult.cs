﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200074D RID: 1869
	public enum MsgBoxResult
	{
		// Token: 0x04001835 RID: 6197
		OK = 1,
		// Token: 0x04001836 RID: 6198
		Cancel,
		// Token: 0x04001837 RID: 6199
		Yes = 6,
		// Token: 0x04001838 RID: 6200
		No
	}
}
