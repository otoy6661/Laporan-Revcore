﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000754 RID: 1876
	public partial class SplashScreenPopup__0 : global::System.Windows.Forms.Form
	{
		// Token: 0x060011AA RID: 4522 RVA: 0x000814F0 File Offset: 0x000814F0
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				global::System.Windows.Forms.Timer timer = this.progressTimer;
				if (timer != null)
				{
					timer.Stop();
				}
				global::System.Windows.Forms.Timer timer2 = this.progressTimer;
				if (timer2 != null)
				{
					timer2.Dispose();
				}
				global::System.Windows.Forms.Timer timer3 = this.animationTimer;
				if (timer3 != null)
				{
					timer3.Stop();
				}
				global::System.Windows.Forms.Timer timer4 = this.animationTimer;
				if (timer4 != null)
				{
					timer4.Dispose();
				}
				global::System.Windows.Forms.Timer timer5 = this.padlockTimer;
				if (timer5 != null)
				{
					timer5.Stop();
				}
				global::System.Windows.Forms.Timer timer6 = this.padlockTimer;
				if (timer6 != null)
				{
					timer6.Dispose();
				}
				global::System.Windows.Forms.Timer timer7 = this.teksAnimasiTimer;
				if (timer7 != null)
				{
					timer7.Stop();
				}
				global::System.Windows.Forms.Timer timer8 = this.teksAnimasiTimer;
				if (timer8 != null)
				{
					timer8.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		// Token: 0x04001851 RID: 6225
		private global::System.Windows.Forms.Timer progressTimer;

		// Token: 0x04001852 RID: 6226
		private global::System.Windows.Forms.Timer animationTimer;

		// Token: 0x04001853 RID: 6227
		private global::System.Windows.Forms.Timer padlockTimer;

		// Token: 0x04001854 RID: 6228
		private global::System.Windows.Forms.Timer teksAnimasiTimer;
	}
}
