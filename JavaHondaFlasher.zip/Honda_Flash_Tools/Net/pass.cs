﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000361 RID: 865
	public partial class pass : Form
	{
		// Token: 0x06000BC7 RID: 3015 RVA: 0x00008976 File Offset: 0x00008976
		public pass()
		{
			this.InitializeComponent();
			this.SetupForm();
		}

		// Token: 0x06000BC8 RID: 3016 RVA: 0x00008995 File Offset: 0x00008995
		private void pass_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (pass.ftHandle != IntPtr.Zero)
			{
				pass.FT_Close(pass.ftHandle);
				pass.ftHandle = IntPtr.Zero;
			}
		}

		// Token: 0x06000BC9 RID: 3017 RVA: 0x000558C8 File Offset: 0x000558C8
		private bool InitFtdiIso()
		{
			bool result;
			try
			{
				this.AddLog("Initializing FTDI...");
				uint num = pass.FT_Open(0U, ref pass.ftHandle);
				if (num != 0U)
				{
					this.AddLog(string.Format("Error: FT_Open failed (Code: {0})", num));
					result = false;
				}
				else
				{
					pass.FT_Purge(pass.ftHandle, 3U);
					pass.FT_SetBitMode(pass.ftHandle, 0, 0);
					pass.FT_SetDataCharacteristics(pass.ftHandle, 8, 0, 0);
					pass.FT_SetBaudRate(pass.ftHandle, 10400U);
					pass.FT_SetTimeouts(pass.ftHandle, 3000U, 3000U);
					pass.FT_SetLatencyTimer(pass.ftHandle, 2);
					pass.FT_SetBitMode(pass.ftHandle, 1, 1);
					byte[] array = new byte[1];
					uint num2 = 0U;
					pass.FT_Write(pass.ftHandle, array, 1U, ref num2);
					Thread.Sleep(50);
					array[0] = 1;
					pass.FT_Write(pass.ftHandle, array, 1U, ref num2);
					Thread.Sleep(100);
					pass.FT_SetBitMode(pass.ftHandle, 0, 0);
					pass.FT_SetBaudRate(pass.ftHandle, 10400U);
					pass.FT_Purge(pass.ftHandle, 3U);
					Thread.Sleep(100);
					this.AddLog("✓ FTDI initialized successfully");
					result = true;
				}
			}
			catch (Exception ex)
			{
				this.AddLog("✗ FTDI Init Error: " + ex.Message);
				result = false;
			}
			return result;
		}

		// Token: 0x06000BCC RID: 3020 RVA: 0x0005607C File Offset: 0x0005607C
		private byte CalcLRC(byte[] data, int length)
		{
			int num = 0;
			for (int i = 0; i < length; i++)
			{
				num += (int)data[i];
			}
			return (byte)(256 - (num & 255) & 255);
		}

		// Token: 0x06000BCD RID: 3021
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_Open(uint uiPort, ref IntPtr ftHandle);

		// Token: 0x06000BCE RID: 3022
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_Close(IntPtr ftHandle);

		// Token: 0x06000BCF RID: 3023
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_Read(IntPtr ftHandle, byte[] lpBuffer, uint dwBytesToRead, ref uint lpdwBytesReturned);

		// Token: 0x06000BD0 RID: 3024
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_Write(IntPtr ftHandle, byte[] lpBuffer, uint dwBytesToWrite, ref uint lpdwBytesWritten);

		// Token: 0x06000BD1 RID: 3025
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_SetBaudRate(IntPtr ftHandle, uint dwBaudRate);

		// Token: 0x06000BD2 RID: 3026
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_SetDataCharacteristics(IntPtr ftHandle, byte uWordLength, byte uStopBits, byte uParity);

		// Token: 0x06000BD3 RID: 3027
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_SetTimeouts(IntPtr ftHandle, uint dwReadTimeout, uint dwWriteTimeout);

		// Token: 0x06000BD4 RID: 3028
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_SetLatencyTimer(IntPtr ftHandle, byte ucTimer);

		// Token: 0x06000BD5 RID: 3029
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_SetBitMode(IntPtr ftHandle, byte ucMask, byte ucMode);

		// Token: 0x06000BD6 RID: 3030
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_GetQueueStatus(IntPtr ftHandle, ref uint lpdwAmountInRxQueue);

		// Token: 0x06000BD7 RID: 3031
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_Purge(IntPtr ftHandle, uint dwMask);

		// Token: 0x06000BD8 RID: 3032 RVA: 0x000560B4 File Offset: 0x000560B4
		private void SetupForm()
		{
			this.Text = "Keihin Flash Count Reset Tool";
			base.Size = new Size(395, 195);
			base.StartPosition = FormStartPosition.CenterScreen;
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			this.BackColor = Color.Black;
		}

		// Token: 0x06000BD9 RID: 3033 RVA: 0x0000282D File Offset: 0x0000282D
		private void btnExit_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		// Token: 0x06000BDA RID: 3034 RVA: 0x00056104 File Offset: 0x00056104
		private void UpdateStatus(string message, Color color)
		{
			this.UpdateUI(delegate
			{
				this.lblStatus.Text = message;
				this.lblStatus.ForeColor = color;
			});
		}

		// Token: 0x06000BDB RID: 3035 RVA: 0x00056140 File Offset: 0x00056140
		private bool SendAndLog(byte[] command)
		{
			bool result;
			try
			{
				string str = BitConverter.ToString(command);
				this.AddLog("TX: " + str);
				byte[] array = new byte[256];
				uint num = 0U;
				result = this.SendCommand(command, ref array, ref num);
			}
			catch (Exception ex)
			{
				this.AddLog("SendLog Error: " + ex.Message);
				result = false;
			}
			return result;
		}

		// Token: 0x06000BDC RID: 3036 RVA: 0x000561B0 File Offset: 0x000561B0
		private void AddLog(string message)
		{
			this.UpdateUI(delegate
			{
				string text = DateTime.Now.ToString("HH:mm:ss");
				this.txtLog.AppendText(string.Concat(new string[]
				{
					"[",
					text,
					"] ",
					message,
					"\r\n"
				}));
				this.txtLog.SelectionStart = this.txtLog.Text.Length;
				this.txtLog.ScrollToCaret();
			});
		}

		// Token: 0x06000BDD RID: 3037 RVA: 0x000089C9 File Offset: 0x000089C9
		private void ClearLog()
		{
			this.UpdateUI(delegate
			{
				this.txtLog.Clear();
			});
		}

		// Token: 0x06000BDE RID: 3038 RVA: 0x000089DD File Offset: 0x000089DD
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new pass());
		}

		// Token: 0x06000BDF RID: 3039 RVA: 0x000561E4 File Offset: 0x000561E4
		private async Task ResetFlashCount()
		{
			int successCount = 0;
			int totalAddresses = 128;
			try
			{
				this._sw.Restart();
				this.ClearLog();
				byte[][] securityCommands = new byte[][]
				{
					new byte[]
					{
						254,
						4,
						114,
						140
					},
					new byte[]
					{
						114,
						5,
						0,
						240,
						153
					},
					new byte[]
					{
						39,
						11,
						224,
						72,
						101,
						108,
						108,
						111,
						72,
						111,
						67
					},
					new byte[]
					{
						39,
						11,
						224,
						119,
						65,
						114,
						101,
						89,
						111,
						117,
						34
					},
					new byte[]
					{
						145,
						145,
						13,
						223,
						158,
						141,
						154,
						134,
						144,
						138,
						140,
						155,
						136
					},
					new byte[]
					{
						145,
						145,
						13,
						223,
						146,
						158,
						134,
						150,
						139,
						141,
						134,
						192,
						106
					},
					new byte[]
					{
						145,
						145,
						9,
						65,
						14,
						0,
						0,
						0,
						168
					}
				};
				this.UpdateStatus("INITIALIZING", Color.Yellow);
				this.AddLog("=== STARTING FLASH COUNT RESET ===");
				if (!this.InitFtdiIso())
				{
					this.UpdateStatus("FTDI FAILED", Color.Red);
					this.AddLog("✗ FTDI initialization failed");
					this.UpdateStatus("CHECK FTDI CABLE", Color.Red);
					this.AddLog("Please check: FTDI cable connection and drivers");
					System.Windows.Forms.Timer errorTimer = new System.Windows.Forms.Timer();
					errorTimer.Interval = 5000;
					errorTimer.Tick += delegate(object s, EventArgs e)
					{
						this.UpdateStatus("READY TO RESET", Color.Lime);
						errorTimer.Stop();
						errorTimer.Dispose();
					};
					errorTimer.Start();
				}
				else
				{
					this.UpdateUI(delegate
					{
						this.progressBar.Value = 0;
					});
					this.UpdateStatus("SECURITY ACCESS", Color.Orange);
					this.AddLog("Attempting security access...");
					bool securitySuccess = false;
					this.AddLog("Trying Method 1...");
					for (int i = 0; i < 4; i++)
					{
						if (this.SendAndLog(securityCommands[i]))
						{
							this.AddLog(string.Format("✓ Security command {0} OK", i + 1));
							await Task.Delay(150);
						}
						else
						{
							this.AddLog(string.Format("✗ Security command {0} failed", i + 1));
						}
					}
					byte[] testCmd = new byte[]
					{
						130,
						130,
						20,
						8,
						0,
						1,
						0,
						223
					};
					byte[] testReply = new byte[256];
					uint testReplySize = 0U;
					if (this.SendCommand(testCmd, ref testReply, ref testReplySize))
					{
						string text = BitConverter.ToString(testReply, 0, (int)testReplySize);
						this.AddLog("Test response: " + text);
						if (text.Contains("92-92") || text.Contains("82-82"))
						{
							securitySuccess = true;
							this.AddLog("✓ Security access successful");
						}
					}
					if (!securitySuccess)
					{
						this.AddLog("Method 1 failed, trying Method 2...");
						for (int i = 4; i < securityCommands.Length; i++)
						{
							if (this.SendAndLog(securityCommands[i]))
							{
								this.AddLog(string.Format("✓ Alt security command {0} OK", i - 3));
								await Task.Delay(150);
							}
						}
						if (this.SendCommand(testCmd, ref testReply, ref testReplySize))
						{
							string text2 = BitConverter.ToString(testReply, 0, (int)testReplySize);
							if (text2.Contains("92-92") || text2.Contains("82-82"))
							{
								securitySuccess = true;
								this.AddLog("✓ Alternative security successful");
							}
						}
					}
					if (!securitySuccess)
					{
						this.UpdateStatus("SECURITY FAILED", Color.Red);
						this.AddLog("✗ Security access failed");
						this.UpdateStatus("CHECK CONNECTION", Color.Red);
						this.AddLog("Security error: Check FTDI cable connection");
						this.AddLog("Make sure ignition is ON and ECU is ready");
						System.Windows.Forms.Timer securityTimer = new System.Windows.Forms.Timer();
						securityTimer.Interval = 5000;
						securityTimer.Tick += delegate(object s, EventArgs e)
						{
							this.UpdateStatus("READY - RETRY", Color.Yellow);
							securityTimer.Stop();
							securityTimer.Dispose();
						};
						securityTimer.Start();
					}
					else
					{
						this.UpdateStatus("RESETTING...", Color.Yellow);
						this.AddLog(string.Format("Starting reset for {0} addresses...", totalAddresses));
						for (int i = 0; i < totalAddresses; i++)
						{
							byte[] array = new byte[8];
							array[0] = 130;
							array[1] = 130;
							array[2] = 20;
							array[3] = 8;
							array[4] = (byte)i;
							array[5] = 0;
							array[6] = 0;
							array[7] = this.CalcLRC(array, 7);
							byte[] value = new byte[256];
							uint length = 0U;
							if (this.SendCommand(array, ref value, ref length))
							{
								string text3 = BitConverter.ToString(value, 0, (int)length);
								if (text3.Contains("92-92-14-05") || text3.Contains("82-82-14-08") || text3.Contains("7F-00-00-61"))
								{
									successCount++;
									this.AddLog(string.Format("✓ Addr 0x{0:X2}: Success", i));
								}
								else
								{
									this.AddLog(string.Format("Addr 0x{0:X2}: {1}", i, text3));
								}
							}
							else
							{
								this.AddLog(string.Format("✗ Addr 0x{0:X2}: No response", i));
							}
							int progress = i + 1;
							int percent = progress * 100 / totalAddresses;
							this.UpdateUI(delegate
							{
								this.progressBar.Value = progress;
								this.lblProgress.Text = string.Format("Progress: {0}/{1} ({2}%)", progress, totalAddresses, percent);
								this.lblTime.Text = string.Format("Time: {0:F1}s", this._sw.Elapsed.TotalSeconds);
							});
							await Task.Delay(10);
						}
						this.AddLog("Performing final verification...");
						byte[] command = new byte[]
						{
							130,
							130,
							20,
							8,
							127,
							0,
							0,
							97
						};
						byte[] value2 = new byte[256];
						uint length2 = 0U;
						bool flag = false;
						if (this.SendCommand(command, ref value2, ref length2))
						{
							string text4 = BitConverter.ToString(value2, 0, (int)length2);
							this.AddLog("Verification: " + text4);
							if (text4.Contains("92-92-14-05-C3"))
							{
								flag = true;
								this.AddLog("✓ Verification successful");
							}
						}
						if (pass.ftHandle != IntPtr.Zero)
						{
							pass.FT_Close(pass.ftHandle);
							pass.ftHandle = IntPtr.Zero;
							this.AddLog("FTDI connection closed");
						}
						double totalSeconds = this._sw.Elapsed.TotalSeconds;
						this.AddLog("=== PROCESS COMPLETE ===");
						this.AddLog(string.Format("Success: {0}/{1}", successCount, totalAddresses));
						this.AddLog(string.Format("Time: {0:F1} seconds", totalSeconds));
						if (successCount > 0 || flag)
						{
							this.UpdateStatus("RESET SUCCESSFUL", Color.Lime);
							this.AddLog("✓ Flash counter reset successful!");
							this.AddLog(string.Format("✓ Successfully reset {0}/{1} addresses", successCount, totalAddresses));
							this.AddLog(string.Format("✓ Time elapsed: {0:F1} seconds", totalSeconds));
							if (flag)
							{
								this.AddLog("✓ Verification passed");
							}
							else if (successCount >= 100)
							{
								this.AddLog("✓ Most addresses reset successfully");
							}
							this.UpdateStatus("SUCCESS - TURN KEY OFF/ON", Color.Lime);
							System.Windows.Forms.Timer successTimer = new System.Windows.Forms.Timer();
							successTimer.Interval = 10000;
							successTimer.Tick += delegate(object s, EventArgs e)
							{
								this.UpdateStatus("READY FOR NEXT", Color.Cyan);
								successTimer.Stop();
								successTimer.Dispose();
							};
							successTimer.Start();
						}
						else
						{
							this.UpdateStatus("RESET FAILED", Color.Red);
							this.AddLog("✗ Reset failed - no successful responses");
							this.AddLog(string.Format("Successful addresses: {0}/{1}", successCount, totalAddresses));
							this.AddLog("Please check:");
							this.AddLog("- FTDI driver installed");
							this.AddLog("- Cable connections");
							this.AddLog("- Ignition is ON");
							this.AddLog("- Correct baud rate (10400)");
							System.Windows.Forms.Timer failTimer = new System.Windows.Forms.Timer();
							failTimer.Interval = 8000;
							failTimer.Tick += delegate(object s, EventArgs e)
							{
								this.UpdateStatus("CHECK & RETRY", Color.Yellow);
								failTimer.Stop();
								failTimer.Dispose();
							};
							failTimer.Start();
						}
					}
					testCmd = null;
					testReply = null;
				}
				securityCommands = null;
			}
			catch (Exception ex)
			{
				this.UpdateStatus("ERROR", Color.Red);
				this.AddLog("✗ Unexpected error: " + ex.Message);
				this.AddLog("Process was interrupted");
				System.Windows.Forms.Timer exceptionTimer = new System.Windows.Forms.Timer();
				exceptionTimer.Interval = 5000;
				exceptionTimer.Tick += delegate(object s, EventArgs e)
				{
					this.UpdateStatus("ERROR OCCURRED", Color.Orange);
					exceptionTimer.Stop();
					exceptionTimer.Dispose();
				};
				exceptionTimer.Start();
			}
			finally
			{
				this.isProcessing = false;
				this.UpdateUI(delegate
				{
					this.btnReset.Enabled = true;
				});
				this.UpdateUI(delegate
				{
					this.btnReset.Text = "START RESET";
					this.btnReset.BackColor = Color.FromArgb(0, 100, 0);
				});
			}
		}

		// Token: 0x06000BE0 RID: 3040 RVA: 0x000089F4 File Offset: 0x000089F4
		private void UpdateUI(Action action)
		{
			if (base.InvokeRequired)
			{
				base.Invoke(new Action(action.Invoke));
				return;
			}
			action();
		}

		// Token: 0x06000BE1 RID: 3041 RVA: 0x0005622C File Offset: 0x0005622C
		private async void btnReset_Click(object sender, EventArgs e)
		{
			if (!this.isProcessing)
			{
				pass.<>c__DisplayClass0_0__3 CS$<>8__locals1 = new pass.<>c__DisplayClass0_0__3();
				CS$<>8__locals1.<>4__this = this;
				this.lblStatus.Text = "TURN KEY OFF, WAIT 3 SEC, THEN ON";
				this.lblStatus.ForeColor = Color.Yellow;
				this.AddLog("Instruction: Turn ignition KEY OFF, wait 3 seconds, then turn KEY ON");
				CS$<>8__locals1.resetTimer = new System.Windows.Forms.Timer();
				CS$<>8__locals1.resetTimer.Interval = 5000;
				CS$<>8__locals1.resetTimer.Tick += delegate(object s, EventArgs args)
				{
					CS$<>8__locals1.<>4__this.lblStatus.Text = "READY - CLICK START AGAIN";
					CS$<>8__locals1.<>4__this.lblStatus.ForeColor = Color.Cyan;
					CS$<>8__locals1.resetTimer.Stop();
					CS$<>8__locals1.resetTimer.Dispose();
				};
				CS$<>8__locals1.resetTimer.Start();
				this.btnReset.Text = "KEY IS ON - START RESET";
				this.btnReset.BackColor = Color.Orange;
				this.btnReset.Click -= this.btnReset_Click;
				CS$<>8__locals1.confirmHandler = null;
				CS$<>8__locals1.confirmHandler = delegate(object s, EventArgs args)
				{
					pass.<>c__DisplayClass0_0__3.<<btnReset_Click>b__1>d <<btnReset_Click>b__1>d;
					<<btnReset_Click>b__1>d.<>4__this = CS$<>8__locals1;
					<<btnReset_Click>b__1>d.<>t__builder = AsyncVoidMethodBuilder.Create();
					<<btnReset_Click>b__1>d.<>1__state = -1;
					AsyncVoidMethodBuilder <>t__builder = <<btnReset_Click>b__1>d.<>t__builder;
					<>t__builder.Start<pass.<>c__DisplayClass0_0__3.<<btnReset_Click>b__1>d>(ref <<btnReset_Click>b__1>d);
				};
				this.btnReset.Click += CS$<>8__locals1.confirmHandler;
			}
		}

		// Token: 0x06000BE2 RID: 3042 RVA: 0x00056268 File Offset: 0x00056268
		private bool SendCommand(byte[] command, ref byte[] reply, ref uint replySize)
		{
			bool result;
			try
			{
				if (pass.ftHandle == IntPtr.Zero)
				{
					this.AddLog("FTDI not connected");
					result = false;
				}
				else
				{
					uint num = 0U;
					uint num2 = pass.FT_Write(pass.ftHandle, command, (uint)command.Length, ref num);
					if (num2 != 0U || (ulong)num != (ulong)((long)command.Length))
					{
						this.AddLog(string.Format("Write failed (Status: {0}, Sent: {1}/{2})", num2, num, command.Length));
						result = false;
					}
					else
					{
						Thread.Sleep(100);
						uint num3 = 0U;
						pass.FT_GetQueueStatus(pass.ftHandle, ref num3);
						int num4 = 0;
						while (num3 == 0U && num4 < 10)
						{
							Thread.Sleep(50);
							pass.FT_GetQueueStatus(pass.ftHandle, ref num3);
							num4++;
						}
						if (num3 == 0U)
						{
							this.AddLog("No response from ECU");
							result = false;
						}
						else
						{
							byte[] array = new byte[num3];
							uint val = 0U;
							num2 = pass.FT_Read(pass.ftHandle, array, num3, ref val);
							if (num2 != 0U)
							{
								this.AddLog(string.Format("Read failed (Status: {0})", num2));
								result = false;
							}
							else
							{
								int num5 = Math.Min((int)val, reply.Length);
								Array.Copy(array, 0, reply, 0, num5);
								replySize = (uint)num5;
								string text = BitConverter.ToString(reply, 0, Math.Min((int)replySize, 16));
								if (replySize > 16U)
								{
									text += "...";
								}
								this.AddLog("RX: " + text);
								result = true;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				this.AddLog("Send Error: " + ex.Message);
				result = false;
			}
			return result;
		}

		// Token: 0x06000BE4 RID: 3044 RVA: 0x00008A25 File Offset: 0x00008A25
		private void CleanupResources(ref byte[][] securityCommands, ref byte[] testCmd, ref byte[] testReply)
		{
			securityCommands = null;
			testCmd = null;
			testReply = null;
		}

		// Token: 0x04000D59 RID: 3417
		private static IntPtr ftHandle = IntPtr.Zero;

		// Token: 0x04000D5A RID: 3418
		private Stopwatch _sw = new Stopwatch();

		// Token: 0x04000D5F RID: 3423
		private bool isProcessing;
	}
}
