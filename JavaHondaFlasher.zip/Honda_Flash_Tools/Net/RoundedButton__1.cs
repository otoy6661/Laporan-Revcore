﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200071A RID: 1818
	public class RoundedButton__1 : Button
	{
		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06001094 RID: 4244 RVA: 0x0000B33D File Offset: 0x0000B33D
		// (set) Token: 0x06001095 RID: 4245 RVA: 0x0000B345 File Offset: 0x0000B345
		public int BorderRadius
		{
			get
			{
				return this._borderRadius;
			}
			set
			{
				this._borderRadius = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x06001096 RID: 4246 RVA: 0x0000B354 File Offset: 0x0000B354
		// (set) Token: 0x06001097 RID: 4247 RVA: 0x0000B35C File Offset: 0x0000B35C
		public Color BorderColor
		{
			get
			{
				return this._borderColor;
			}
			set
			{
				this._borderColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x06001098 RID: 4248 RVA: 0x0000B36B File Offset: 0x0000B36B
		// (set) Token: 0x06001099 RID: 4249 RVA: 0x0000B373 File Offset: 0x0000B373
		public int BorderSize
		{
			get
			{
				return this._borderSize;
			}
			set
			{
				this._borderSize = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x0600109A RID: 4250 RVA: 0x0000B382 File Offset: 0x0000B382
		// (set) Token: 0x0600109B RID: 4251 RVA: 0x0000B38A File Offset: 0x0000B38A
		public Color NormalColor
		{
			get
			{
				return this._normalColor;
			}
			set
			{
				this._normalColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x0600109C RID: 4252 RVA: 0x0000B399 File Offset: 0x0000B399
		// (set) Token: 0x0600109D RID: 4253 RVA: 0x0000B3A1 File Offset: 0x0000B3A1
		public Color HoverColor
		{
			get
			{
				return this._hoverColor;
			}
			set
			{
				this._hoverColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x0600109E RID: 4254 RVA: 0x0000B3B0 File Offset: 0x0000B3B0
		// (set) Token: 0x0600109F RID: 4255 RVA: 0x0000B3B8 File Offset: 0x0000B3B8
		public Color DownColor
		{
			get
			{
				return this._downColor;
			}
			set
			{
				this._downColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x060010A0 RID: 4256 RVA: 0x00078FB4 File Offset: 0x00078FB4
		public RoundedButton__1()
		{
			this._borderRadius = 15;
			this._borderColor = Color.FromArgb(0, 240, 255);
			this._borderSize = 1;
			this._normalColor = Color.FromArgb(0, 160, 200);
			this._hoverColor = Color.FromArgb(0, 200, 240);
			this._downColor = Color.FromArgb(0, 130, 170);
			base.FlatStyle = FlatStyle.Flat;
			base.FlatAppearance.BorderSize = 0;
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.MouseEnter += delegate(object s, EventArgs e)
			{
				this._isHover = true;
				base.Invalidate();
			};
			base.MouseLeave += delegate(object s, EventArgs e)
			{
				this._isHover = false;
				this._isDown = false;
				base.Invalidate();
			};
			base.MouseDown += delegate(object s, MouseEventArgs e)
			{
				this._isDown = true;
				base.Invalidate();
			};
			base.MouseUp += delegate(object s, MouseEventArgs e)
			{
				this._isDown = false;
				base.Invalidate();
			};
		}

		// Token: 0x060010A1 RID: 4257 RVA: 0x00079098 File Offset: 0x00079098
		private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = radius * 2;
			if (num <= 0)
			{
				graphicsPath.AddRectangle(rect);
				return graphicsPath;
			}
			if (num > rect.Width)
			{
				num = rect.Width;
			}
			if (num > rect.Height)
			{
				num = rect.Height;
			}
			graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x060010A2 RID: 4258 RVA: 0x00079170 File Offset: 0x00079170
		protected override void OnPaint(PaintEventArgs e)
		{
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			e.Graphics.Clear((base.Parent != null) ? base.Parent.BackColor : this.BackColor);
			Rectangle rectangle = new Rectangle(0, 0, base.Width - 1, base.Height - 1);
			Color color;
			if (this._isDown)
			{
				color = this._downColor;
			}
			else if (this._isHover)
			{
				color = this._hoverColor;
			}
			else
			{
				color = this._normalColor;
			}
			using (GraphicsPath roundedPath = this.GetRoundedPath(rectangle, this._borderRadius))
			{
				using (SolidBrush solidBrush = new SolidBrush(color))
				{
					e.Graphics.FillPath(solidBrush, roundedPath);
				}
				if (this._borderSize > 0)
				{
					using (Pen pen = new Pen(this._borderColor, (float)this._borderSize))
					{
						pen.Alignment = PenAlignment.Inset;
						e.Graphics.DrawPath(pen, roundedPath);
					}
				}
			}
			TextRenderer.DrawText(e.Graphics, this.Text, this.Font, rectangle, this.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
		}

		// Token: 0x0400173A RID: 5946
		private int _borderRadius;

		// Token: 0x0400173B RID: 5947
		private Color _borderColor;

		// Token: 0x0400173C RID: 5948
		private int _borderSize;

		// Token: 0x0400173D RID: 5949
		private Color _normalColor;

		// Token: 0x0400173E RID: 5950
		private Color _hoverColor;

		// Token: 0x0400173F RID: 5951
		private Color _downColor;

		// Token: 0x04001740 RID: 5952
		private bool _isHover;

		// Token: 0x04001741 RID: 5953
		private bool _isDown;
	}
}
