﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200034F RID: 847
	public static class Class18
	{
		// Token: 0x06000B5D RID: 2909 RVA: 0x000512E8 File Offset: 0x000512E8
		public static double smethod_0(string hex)
		{
			double result;
			try
			{
				result = (double)Convert.ToInt32(hex, 16);
			}
			catch
			{
				result = 0.0;
			}
			return result;
		}
	}
}
