﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020005F6 RID: 1526
	public partial class ProgressPopupForm : Form
	{
		// Token: 0x06000EC1 RID: 3777 RVA: 0x0006ADEC File Offset: 0x0006ADEC
		public ProgressPopupForm(string title)
		{
			base.FormBorderStyle = FormBorderStyle.None;
			base.StartPosition = FormStartPosition.CenterScreen;
			this.BackColor = ProgressPopupForm.BgDark;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.ShowInTaskbar = false;
			this.Text = "Progress";
			base.Width = 460;
			base.Height = 220;
			base.TopMost = true;
			base.Padding = new Padding(6);
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.BuildUI(title);
		}

		// Token: 0x06000EC2 RID: 3778 RVA: 0x0006AE74 File Offset: 0x0006AE74
		private void BuildUI(string title)
		{
			this.contentPanel = new RoundedPanel
			{
				Dock = DockStyle.Fill,
				CornerRadius = 14,
				BorderColor = ProgressPopupForm.Cyan,
				BorderWidth = 1f,
				InnerBackColor = ProgressPopupForm.BgPanel,
				Padding = new Padding(20)
			};
			base.Controls.Add(this.contentPanel);
			this.lblTitle = new Label
			{
				Text = title,
				Font = new Font("Impact", 14f, FontStyle.Italic),
				ForeColor = ProgressPopupForm.TextTitle,
				BackColor = Color.Transparent,
				AutoSize = true,
				Location = new Point(20, 20)
			};
			this.contentPanel.Controls.Add(this.lblTitle);
			checked
			{
				Panel panel = new Panel
				{
					BackColor = ProgressPopupForm.CyanDark,
					Location = new Point(20, this.lblTitle.Bottom + 6),
					Size = new Size(this.contentPanel.Width - 40, 1),
					Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
				};
				this.contentPanel.Controls.Add(panel);
				this.lblStatus = new Label
				{
					Text = "Status: Ready",
					Font = new Font("Consolas", 9f, FontStyle.Bold),
					ForeColor = ProgressPopupForm.Cyan,
					BackColor = Color.Transparent,
					AutoSize = false,
					Location = new Point(20, panel.Bottom + 10),
					Size = new Size(this.contentPanel.Width - 40, 18),
					Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right),
					TextAlign = ContentAlignment.MiddleLeft
				};
				this.contentPanel.Controls.Add(this.lblStatus);
				this.progressWrapper = new Panel
				{
					BackColor = Color.Transparent,
					Location = new Point(20, this.lblStatus.Bottom + 10),
					Size = new Size(this.contentPanel.Width - 40, 17),
					Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
				};
				this.contentPanel.Controls.Add(this.progressWrapper);
				this.progressBack = new RoundedPanel
				{
					Dock = DockStyle.Fill,
					CornerRadius = 12,
					BorderColor = ProgressPopupForm.CyanDark,
					BorderWidth = 1f,
					InnerBackColor = ProgressPopupForm.BgProgressTrack,
					Padding = new Padding(3)
				};
				this.progressWrapper.Controls.Add(this.progressBack);
				this.progressBar = new RoundedProgressBar
				{
					Dock = DockStyle.Fill,
					CornerRadius = 9,
					BorderWidth = 0,
					BorderColor = ProgressPopupForm.CyanDark,
					TrackColor = ProgressPopupForm.BgProgressTrack,
					BarColor = ProgressPopupForm.Cyan,
					BarColor2 = new Color?(Color.FromArgb(0, 200, 255)),
					BackColor = Color.Transparent,
					ForeColor = ProgressPopupForm.Cyan,
					Minimum = 0,
					Maximum = 100,
					Value = 0,
					ShowPercentage = false
				};
				this.progressBack.Controls.Add(this.progressBar);
				this.btnClose = new RoundedButton
				{
					Text = "CLOSE",
					Font = new Font("Segoe UI", 9f, FontStyle.Bold),
					ForeColor = ProgressPopupForm.Cyan,
					BackColor = ProgressPopupForm.BgButton,
					CornerRadius = 8,
					BorderColor = ProgressPopupForm.Cyan,
					BorderWidth = 1f,
					HoverBackColor = ProgressPopupForm.BgButtonHover,
					Cursor = Cursors.Hand,
					Size = new Size(110, 32),
					Anchor = AnchorStyles.Bottom,
					Enabled = false
				};
				this.btnClose.Location = new Point((this.contentPanel.Width - this.btnClose.Width) / 2 - 10, this.contentPanel.Height - this.btnClose.Height - 20);
				this.btnClose.Click += delegate(object sender, EventArgs e)
				{
					base.Close();
				};
				this.contentPanel.Controls.Add(this.btnClose);
			}
		}

		// Token: 0x06000EC3 RID: 3779 RVA: 0x0006B2B4 File Offset: 0x0006B2B4
		public void SetProgress(int value)
		{
			if (base.IsDisposed)
			{
				return;
			}
			if (base.InvokeRequired)
			{
				try
				{
					base.Invoke(new Action(delegate()
					{
						this.SetProgress(value);
					}));
				}
				catch (ObjectDisposedException)
				{
				}
				catch (InvalidOperationException)
				{
				}
				return;
			}
			if (this.progressBar == null || this.progressBar.IsDisposed)
			{
				return;
			}
			this.progressBar.AnimateTo(value);
		}

		// Token: 0x06000EC4 RID: 3780 RVA: 0x0006B348 File Offset: 0x0006B348
		public void SetMaximum(int value)
		{
			if (base.IsDisposed)
			{
				return;
			}
			if (base.InvokeRequired)
			{
				try
				{
					base.Invoke(new Action(delegate()
					{
						this.SetMaximum(value);
					}));
				}
				catch (ObjectDisposedException)
				{
				}
				catch (InvalidOperationException)
				{
				}
				return;
			}
			if (this.progressBar == null || this.progressBar.IsDisposed)
			{
				return;
			}
			if (value <= 0)
			{
				value = 1;
			}
			this.progressBar.Maximum = value;
		}

		// Token: 0x06000EC5 RID: 3781 RVA: 0x0006B3EC File Offset: 0x0006B3EC
		public void SetStatus(string text)
		{
			if (base.IsDisposed)
			{
				return;
			}
			if (base.InvokeRequired)
			{
				try
				{
					base.Invoke(new Action(delegate()
					{
						this.SetStatus(text);
					}));
				}
				catch (ObjectDisposedException)
				{
				}
				catch (InvalidOperationException)
				{
				}
				return;
			}
			if (this.lblStatus == null || this.lblStatus.IsDisposed)
			{
				return;
			}
			this.lblStatus.Text = "Status: " + text;
		}

		// Token: 0x06000EC6 RID: 3782 RVA: 0x0006B488 File Offset: 0x0006B488
		public void FinishAndEnableClose()
		{
			if (base.IsDisposed)
			{
				return;
			}
			if (base.InvokeRequired)
			{
				try
				{
					base.Invoke(new Action(this.FinishAndEnableClose));
				}
				catch (ObjectDisposedException)
				{
				}
				catch (InvalidOperationException)
				{
				}
				return;
			}
			if (this.btnClose == null || this.btnClose.IsDisposed)
			{
				return;
			}
			this.btnClose.Enabled = true;
		}

		// Token: 0x06000EC7 RID: 3783 RVA: 0x0006B500 File Offset: 0x0006B500
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			if (base.Width <= 4 || base.Height <= 4)
			{
				return;
			}
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.Half;
			graphics.Clear(this.BackColor);
			using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(new RectangleF(2f, 2f, (float)base.Width - 4f, (float)base.Height - 4f), 14))
			{
				using (Pen pen = new Pen(Color.FromArgb(100, 0, 255, 230), 4f))
				{
					pen.Alignment = PenAlignment.Center;
					pen.LineJoin = LineJoin.Round;
					graphics.DrawPath(pen, graphicsPath);
				}
			}
			using (GraphicsPath graphicsPath2 = RoundedHelper.RoundedRectF(new RectangleF(6f, 6f, (float)base.Width - 12f, (float)base.Height - 12f), 12))
			{
				using (Pen pen2 = new Pen(ProgressPopupForm.Cyan, 1.5f))
				{
					pen2.Alignment = PenAlignment.Center;
					pen2.LineJoin = LineJoin.Round;
					graphics.DrawPath(pen2, graphicsPath2);
				}
			}
		}

		// Token: 0x06000EC8 RID: 3784 RVA: 0x0000A20E File Offset: 0x0000A20E
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			this.UpdateFormRegion();
		}

		// Token: 0x06000EC9 RID: 3785 RVA: 0x0000A21D File Offset: 0x0000A21D
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.UpdateFormRegion();
			base.Invalidate();
		}

		// Token: 0x06000ECA RID: 3786 RVA: 0x0000A232 File Offset: 0x0000A232
		private void UpdateFormRegion()
		{
			if (base.Width <= 0 || base.Height <= 0)
			{
				return;
			}
			RoundedHelper.SetRegion(this, 14);
		}

		// Token: 0x06000ECB RID: 3787 RVA: 0x0000A24F File Offset: 0x0000A24F
		protected override void OnMouseDown(MouseEventArgs e)
		{
			base.OnMouseDown(e);
			if (e.Button == MouseButtons.Left)
			{
				ProgressPopupForm.ReleaseCapture();
				ProgressPopupForm.SendMessage(base.Handle, 161, (IntPtr)2, IntPtr.Zero);
			}
		}

		// Token: 0x06000ECC RID: 3788
		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		public static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

		// Token: 0x06000ECD RID: 3789
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		// Token: 0x06000ECE RID: 3790 RVA: 0x0006B66C File Offset: 0x0006B66C
		static ProgressPopupForm()
		{
			ProgressPopupForm.TextTitle = Color.FromArgb(255, 215, 0);
			ProgressPopupForm.TextFore = Color.FromArgb(235, 240, 245);
		}

		// Token: 0x06000ECF RID: 3791 RVA: 0x0006B724 File Offset: 0x0006B724
		protected override void OnShown(EventArgs e)
		{
			base.OnShown(e);
			base.TopMost = true;
			base.BringToFront();
			base.Activate();
			Timer t = new Timer
			{
				Interval = 150
			};
			t.Tick += delegate(object <p0>, EventArgs <p1>)
			{
				t.Stop();
				t.Dispose();
				if (!this.IsDisposed)
				{
					this.TopMost = true;
					this.BringToFront();
				}
				EventHandler globalPopupShown = ProgressPopupForm.GlobalPopupShown;
				if (globalPopupShown != null)
				{
					globalPopupShown(this, EventArgs.Empty);
				}
				if (!this.IsDisposed)
				{
					this.TopMost = true;
					this.BringToFront();
					this.Activate();
				}
			};
			t.Start();
		}

		// Token: 0x06000ED0 RID: 3792 RVA: 0x0000A287 File Offset: 0x0000A287
		protected override void OnFormClosed(FormClosedEventArgs e)
		{
			base.OnFormClosed(e);
			EventHandler globalPopupClosed = ProgressPopupForm.GlobalPopupClosed;
			if (globalPopupClosed == null)
			{
				return;
			}
			globalPopupClosed(this, EventArgs.Empty);
		}

		// Token: 0x14000001 RID: 1
		// (add) Token: 0x06000ED1 RID: 3793 RVA: 0x0006B790 File Offset: 0x0006B790
		// (remove) Token: 0x06000ED2 RID: 3794 RVA: 0x0006B7C4 File Offset: 0x0006B7C4
		public static event EventHandler GlobalPopupShown;

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x06000ED3 RID: 3795 RVA: 0x0006B7F8 File Offset: 0x0006B7F8
		// (remove) Token: 0x06000ED4 RID: 3796 RVA: 0x0006B82C File Offset: 0x0006B82C
		public static event EventHandler GlobalPopupClosed;

		// Token: 0x0400139A RID: 5018
		private static readonly Color Cyan = Color.FromArgb(0, 255, 230);

		// Token: 0x0400139B RID: 5019
		private static readonly Color CyanDark = Color.FromArgb(0, 145, 135);

		// Token: 0x0400139C RID: 5020
		private static readonly Color BgDark = Color.FromArgb(18, 23, 29);

		// Token: 0x0400139D RID: 5021
		private static readonly Color BgPanel = Color.FromArgb(22, 28, 35);

		// Token: 0x0400139E RID: 5022
		private static readonly Color BgButton = Color.FromArgb(32, 40, 47);

		// Token: 0x0400139F RID: 5023
		private static readonly Color BgButtonHover = Color.FromArgb(45, 60, 70);

		// Token: 0x040013A0 RID: 5024
		private static readonly Color TextTitle;

		// Token: 0x040013A1 RID: 5025
		private static readonly Color TextFore;

		// Token: 0x040013A2 RID: 5026
		private const int CornerRadius = 14;

		// Token: 0x040013A3 RID: 5027
		private const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x040013A4 RID: 5028
		private const int HT_CAPTION = 2;

		// Token: 0x040013A5 RID: 5029
		private RoundedPanel contentPanel;

		// Token: 0x040013A6 RID: 5030
		private Label lblTitle;

		// Token: 0x040013A7 RID: 5031
		private Label lblStatus;

		// Token: 0x040013A8 RID: 5032
		private RoundedButton btnClose;

		// Token: 0x040013A9 RID: 5033
		private static readonly Color BgProgressTrack = Color.FromArgb(35, 40, 48);

		// Token: 0x040013AA RID: 5034
		private const int OuterPadding = 20;

		// Token: 0x040013AB RID: 5035
		private const int RowGap = 10;

		// Token: 0x040013AC RID: 5036
		private const int ProgressHeight = 24;

		// Token: 0x040013AD RID: 5037
		private const int ProgressPad = 3;

		// Token: 0x040013AE RID: 5038
		private Panel progressWrapper;

		// Token: 0x040013AF RID: 5039
		private RoundedPanel progressBack;
	}
}
