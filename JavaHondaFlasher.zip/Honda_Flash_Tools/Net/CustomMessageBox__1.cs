﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200034A RID: 842
	public partial class CustomMessageBox__1 : Form
	{
		// Token: 0x06000B49 RID: 2889 RVA: 0x00050B94 File Offset: 0x00050B94
		public CustomMessageBox__1()
		{
			base.FormBorderStyle = FormBorderStyle.None;
			base.StartPosition = FormStartPosition.CenterScreen;
			this.BackColor = CustomMessageBox__1.BgDark;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.ShowInTaskbar = false;
			base.Width = 440;
			base.Height = 240;
			base.TopMost = true;
			base.Padding = new Padding(2);
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		}

		// Token: 0x06000B4A RID: 2890 RVA: 0x00050C14 File Offset: 0x00050C14
		public static DialogResult Show(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
		{
			DialogResult dialogResult;
			using (CustomMessageBox__1 customMessageBox__ = new CustomMessageBox__1())
			{
				customMessageBox__.SetupDialog(message, title, buttons, icon);
				customMessageBox__.ShowDialog();
				dialogResult = CustomMessageBox__1._dialogResult;
			}
			return dialogResult;
		}

		// Token: 0x06000B4B RID: 2891 RVA: 0x00050C5C File Offset: 0x00050C5C
		private void SetupDialog(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
		{
			base.Controls.Clear();
			this.contentPanel = new RoundedPanel();
			this.contentPanel.Dock = DockStyle.Fill;
			this.contentPanel.CornerRadius = this._cornerRadius;
			this.contentPanel.BorderColor = CustomMessageBox__1.Cyan;
			this.contentPanel.BorderWidth = 1f;
			this.contentPanel.InnerBackColor = CustomMessageBox__1.BgPanel;
			this.contentPanel.Padding = new Padding(20);
			base.Controls.Add(this.contentPanel);
			PictureBox pictureBox = new PictureBox
			{
				Location = new Point(18, 22),
				Size = new Size(28, 28),
				SizeMode = PictureBoxSizeMode.StretchImage,
				BackColor = Color.Transparent
			};
			if (icon == MessageBoxIcon.Asterisk || icon == MessageBoxIcon.Asterisk)
			{
				pictureBox.Image = SystemIcons.Information.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Exclamation || icon == MessageBoxIcon.Exclamation)
			{
				pictureBox.Image = SystemIcons.Warning.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Hand || icon == MessageBoxIcon.Hand || icon == MessageBoxIcon.Hand)
			{
				pictureBox.Image = SystemIcons.Error.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Question)
			{
				pictureBox.Image = SystemIcons.Question.ToBitmap();
			}
			this.contentPanel.Controls.Add(pictureBox);
			this.titleLabel = new Label
			{
				Text = title,
				Font = new Font("Segoe UI", 12f, FontStyle.Bold),
				ForeColor = CustomMessageBox__1.TextTitle,
				BackColor = Color.Transparent,
				Location = new Point(56, 18),
				AutoSize = true
			};
			this.contentPanel.Controls.Add(this.titleLabel);
			Panel value = new Panel
			{
				BackColor = CustomMessageBox__1.CyanDark,
				Location = new Point(18, 50),
				Size = new Size(base.Width - 36, 1),
				Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
			};
			this.contentPanel.Controls.Add(value);
			Label value2 = new Label
			{
				Text = message,
				Font = new Font("Segoe UI", 9.5f),
				ForeColor = CustomMessageBox__1.TextFore,
				BackColor = Color.Transparent,
				Location = new Point(20, 64),
				Width = base.Width - 80,
				Height = 60,
				AutoSize = false,
				Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
			};
			this.contentPanel.Controls.Add(value2);
			int num = 90;
			int num2 = 34;
			int num3 = 10;
			int width = this.contentPanel.ClientSize.Width;
			int height = this.contentPanel.ClientSize.Height;
			int left = this.contentPanel.Padding.Left;
			int right = this.contentPanel.Padding.Right;
			int bottom = this.contentPanel.Padding.Bottom;
			int num4 = width - left - right;
			int num5 = 0;
			if (buttons == MessageBoxButtons.OK)
			{
				num5 = 1;
			}
			else if (buttons == MessageBoxButtons.OKCancel || buttons == MessageBoxButtons.YesNo)
			{
				num5 = 2;
			}
			else if (buttons == MessageBoxButtons.YesNoCancel)
			{
				num5 = 3;
			}
			int num6 = num5 * num + (num5 - 1) * num3;
			int num7 = left + (num4 - num6) / 2;
			int top = height - num2 - bottom;
			if (buttons == MessageBoxButtons.OK)
			{
				this.CreateButton("OK", num7, top, num, num2, DialogResult.OK);
				return;
			}
			if (buttons == MessageBoxButtons.OKCancel)
			{
				this.CreateButton("OK", num7, top, num, num2, DialogResult.OK);
				this.CreateButton("Cancel", num7 + num + num3, top, num, num2, DialogResult.Cancel);
				return;
			}
			if (buttons == MessageBoxButtons.YesNo)
			{
				this.CreateButton("Yes", num7, top, num, num2, DialogResult.Yes);
				this.CreateButton("No", num7 + num + num3, top, num, num2, DialogResult.No);
				return;
			}
			if (buttons == MessageBoxButtons.YesNoCancel)
			{
				this.CreateButton("Yes", num7, top, num, num2, DialogResult.Yes);
				this.CreateButton("No", num7 + num + num3, top, num, num2, DialogResult.No);
				this.CreateButton("Cancel", num7 + (num + num3) * 2, top, num, num2, DialogResult.Cancel);
			}
		}

		// Token: 0x06000B4C RID: 2892 RVA: 0x00051064 File Offset: 0x00051064
		private void CreateButton(string text, int left, int top, int width, int height, DialogResult result)
		{
			RoundedButton roundedButton = new RoundedButton
			{
				Text = text,
				Location = new Point(left, top),
				Size = new Size(width, height),
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				ForeColor = CustomMessageBox__1.Cyan,
				BackColor = CustomMessageBox__1.BgButton,
				CornerRadius = 8,
				BorderColor = CustomMessageBox__1.Cyan,
				BorderWidth = 1f,
				HoverBackColor = CustomMessageBox__1.BgButtonHover,
				Cursor = Cursors.Hand
			};
			roundedButton.Click += delegate(object sender, EventArgs e)
			{
				CustomMessageBox__1._dialogResult = result;
				this.Close();
			};
			this.contentPanel.Controls.Add(roundedButton);
		}

		// Token: 0x06000B4D RID: 2893 RVA: 0x00051134 File Offset: 0x00051134
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.Half;
			graphics.Clear(this.BackColor);
			using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(new RectangleF(1.5f, 1.5f, (float)base.Width - 3f, (float)base.Height - 3f), this._cornerRadius))
			{
				using (Pen pen = new Pen(CustomMessageBox__1.Cyan, 2f))
				{
					pen.Alignment = PenAlignment.Center;
					pen.LineJoin = LineJoin.Round;
					graphics.DrawPath(pen, graphicsPath);
				}
			}
		}

		// Token: 0x06000B4E RID: 2894 RVA: 0x00008608 File Offset: 0x00008608
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			this.UpdateFormRegion();
		}

		// Token: 0x06000B4F RID: 2895 RVA: 0x00008617 File Offset: 0x00008617
		protected override void OnMouseDown(MouseEventArgs e)
		{
			base.OnMouseDown(e);
			if (e.Button == MouseButtons.Left)
			{
				CustomMessageBox__1.ReleaseCapture();
				CustomMessageBox__1.SendMessage(base.Handle, 161, 2, 0);
			}
		}

		// Token: 0x06000B50 RID: 2896
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x06000B51 RID: 2897
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		// Token: 0x06000B53 RID: 2899 RVA: 0x00008646 File Offset: 0x00008646
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.UpdateFormRegion();
			base.Invalidate();
		}

		// Token: 0x06000B54 RID: 2900 RVA: 0x0000865B File Offset: 0x0000865B
		private void UpdateFormRegion()
		{
			if (base.Width <= 0 || base.Height <= 0)
			{
				return;
			}
			RoundedHelper.SetRegion(this, this._cornerRadius);
		}

		// Token: 0x04000CA1 RID: 3233
		private static DialogResult _dialogResult;

		// Token: 0x04000CA2 RID: 3234
		private const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x04000CA3 RID: 3235
		private const int HT_CAPTION = 2;

		// Token: 0x04000CA4 RID: 3236
		private Label titleLabel;

		// Token: 0x04000CA5 RID: 3237
		private static readonly Color Cyan = Color.FromArgb(0, 255, 230);

		// Token: 0x04000CA6 RID: 3238
		private static readonly Color CyanDark = Color.FromArgb(0, 145, 135);

		// Token: 0x04000CA7 RID: 3239
		private static readonly Color BgDark = Color.FromArgb(18, 23, 29);

		// Token: 0x04000CA8 RID: 3240
		private static readonly Color BgPanel = Color.FromArgb(22, 28, 35);

		// Token: 0x04000CA9 RID: 3241
		private static readonly Color BgButton = Color.FromArgb(32, 40, 47);

		// Token: 0x04000CAA RID: 3242
		private static readonly Color BgButtonHover = Color.FromArgb(45, 60, 70);

		// Token: 0x04000CAB RID: 3243
		private static readonly Color TextFore = Color.FromArgb(235, 240, 245);

		// Token: 0x04000CAC RID: 3244
		private static readonly Color TextTitle = Color.FromArgb(255, 215, 0);

		// Token: 0x04000CAD RID: 3245
		private RoundedPanel contentPanel;

		// Token: 0x04000CAE RID: 3246
		private int _cornerRadius = 14;
	}
}
