﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000651 RID: 1617
	public static class BlurHelper
	{
		// Token: 0x06000F96 RID: 3990 RVA: 0x0006F744 File Offset: 0x0006F744
		public static Bitmap CaptureForm(Form form)
		{
			Rectangle bounds = form.Bounds;
			Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height);
			using (Graphics graphics = Graphics.FromImage(bitmap))
			{
				IntPtr hdc = graphics.GetHdc();
				BlurHelper.PrintWindow(form.Handle, hdc, 2U);
				graphics.ReleaseHdc(hdc);
			}
			return bitmap;
		}

		// Token: 0x06000F97 RID: 3991 RVA: 0x0006F7AC File Offset: 0x0006F7AC
		public unsafe static Bitmap BoxBlur(Bitmap source, int radius)
		{
			if (radius < 1)
			{
				return source;
			}
			int width = source.Width;
			int height = source.Height;
			Bitmap bitmap = new Bitmap(width, height);
			BitmapData bitmapData = source.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
			BitmapData bitmapData2 = bitmap.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
			byte* ptr = (byte*)((void*)bitmapData.Scan0);
			byte* ptr2 = (byte*)((void*)bitmapData2.Scan0);
			for (int i = 0; i < height; i++)
			{
				for (int j = 0; j < width; j++)
				{
					int num = 0;
					int num2 = 0;
					int num3 = 0;
					int num4 = 0;
					for (int k = -radius; k <= radius; k++)
					{
						int num5 = i + k;
						if (num5 >= 0 && num5 < height)
						{
							for (int l = -radius; l <= radius; l++)
							{
								int num6 = j + l;
								if (num6 >= 0 && num6 < width)
								{
									int num7 = num5 * bitmapData.Stride + num6 * 4;
									num3 += (int)ptr[num7];
									num2 += (int)ptr[num7 + 1];
									num += (int)ptr[num7 + 2];
									num4++;
								}
							}
						}
					}
					int num8 = i * bitmapData2.Stride + j * 4;
					ptr2[num8] = (byte)(num3 / num4);
					ptr2[num8 + 1] = (byte)(num2 / num4);
					ptr2[num8 + 2] = (byte)(num / num4);
					ptr2[num8 + 3] = byte.MaxValue;
				}
			}
			source.UnlockBits(bitmapData);
			bitmap.UnlockBits(bitmapData2);
			return bitmap;
		}

		// Token: 0x06000F98 RID: 3992 RVA: 0x0006F92C File Offset: 0x0006F92C
		public static Bitmap SimpleBlur(Bitmap source, int radius)
		{
			if (radius < 1)
			{
				return source;
			}
			int width = source.Width;
			int height = source.Height;
			Bitmap bitmap = new Bitmap(width, height);
			int width2 = Math.Max(1, width / (radius * 2));
			int height2 = Math.Max(1, height / (radius * 2));
			using (Bitmap bitmap2 = new Bitmap(width2, height2))
			{
				using (Graphics graphics = Graphics.FromImage(bitmap2))
				{
					graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
					graphics.DrawImage(source, 0, 0, width2, height2);
				}
				using (Graphics graphics2 = Graphics.FromImage(bitmap))
				{
					graphics2.InterpolationMode = InterpolationMode.HighQualityBicubic;
					graphics2.DrawImage(bitmap2, 0, 0, width, height);
				}
			}
			return bitmap;
		}

		// Token: 0x06000F99 RID: 3993
		[DllImport("user32.dll")]
		private static extern bool PrintWindow(IntPtr hWnd, IntPtr hdcBlt, uint nFlags);
	}
}
