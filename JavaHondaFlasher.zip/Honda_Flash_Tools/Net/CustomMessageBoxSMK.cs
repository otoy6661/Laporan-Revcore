﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200063D RID: 1597
	public static class CustomMessageBoxSMK
	{
		// Token: 0x06000F79 RID: 3961 RVA: 0x0006EC7C File Offset: 0x0006EC7C
		public static DialogResult Show(string text, string caption, MessageBoxButtons buttons = MessageBoxButtons.OK, MessageBoxIcon icon = MessageBoxIcon.None)
		{
			DialogResult result;
			using (Form form = new Form())
			{
				form.Text = caption;
				form.FormBorderStyle = FormBorderStyle.None;
				form.StartPosition = FormStartPosition.CenterParent;
				form.BackColor = Color.FromArgb(20, 25, 40);
				form.Size = new Size(400, 200);
				form.ShowInTaskbar = false;
				form.KeyPreview = true;
				Panel panel = new Panel
				{
					Dock = DockStyle.Fill,
					BackColor = Color.FromArgb(45, 50, 65),
					Padding = new Padding(3)
				};
				Button button = new Button
				{
					Text = "✕",
					Size = new Size(28, 28),
					Location = new Point(form.Width - 38, 8),
					FlatStyle = FlatStyle.Flat,
					BackColor = Color.FromArgb(45, 50, 65),
					ForeColor = Color.Cyan,
					Font = new Font("Segoe UI", 10f, FontStyle.Bold),
					Cursor = Cursors.Hand,
					TabStop = false
				};
				button.FlatAppearance.BorderSize = 0;
				button.FlatAppearance.MouseOverBackColor = Color.FromArgb(220, 50, 50);
				button.Click += delegate(object s, EventArgs e)
				{
					form.DialogResult = DialogResult.Cancel;
					form.Close();
				};
				Label value = new Label
				{
					Text = caption,
					ForeColor = Color.Cyan,
					Font = new Font("Segoe UI", 9f, FontStyle.Bold),
					Location = new Point(15, 10),
					Size = new Size(form.Width - 60, 22)
				};
				Label value2 = new Label
				{
					Text = text,
					ForeColor = Color.Cyan,
					Font = new Font("Segoe UI", 9f),
					TextAlign = ContentAlignment.MiddleCenter,
					Location = new Point(15, 45),
					Size = new Size(form.Width - 30, 100)
				};
				FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
				{
					Location = new Point(0, form.Height - 55),
					Size = new Size(form.Width, 50),
					FlowDirection = FlowDirection.RightToLeft,
					BackColor = Color.Transparent,
					Padding = new Padding(0, 8, 15, 8)
				};
				Button button2 = new Button
				{
					Text = "OK",
					Size = new Size(80, 28),
					FlatStyle = FlatStyle.Flat,
					BackColor = Color.FromArgb(0, 150, 200),
					ForeColor = Color.White,
					Font = new Font("Segoe UI", 8f, FontStyle.Bold),
					Cursor = Cursors.Hand
				};
				button2.FlatAppearance.BorderColor = Color.Cyan;
				button2.FlatAppearance.BorderSize = 2;
				button2.Click += delegate(object s, EventArgs e)
				{
					form.DialogResult = DialogResult.OK;
					form.Close();
				};
				flowLayoutPanel.Controls.Add(button2);
				panel.Controls.Add(value);
				panel.Controls.Add(button);
				panel.Controls.Add(value2);
				panel.Controls.Add(flowLayoutPanel);
				form.Controls.Add(panel);
				form.Paint += delegate(object s, PaintEventArgs e)
				{
					e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
					using (Pen pen = new Pen(Color.FromArgb(120, 0, 255, 255), 6f))
					{
						using (GraphicsPath roundedPath = CustomMessageBoxSMK.GetRoundedPath(new Rectangle(1, 1, form.Width - 2, form.Height - 2), 15))
						{
							e.Graphics.DrawPath(pen, roundedPath);
						}
					}
					using (Pen pen2 = new Pen(Color.Cyan, 2f))
					{
						using (GraphicsPath roundedPath2 = CustomMessageBoxSMK.GetRoundedPath(new Rectangle(1, 1, form.Width - 2, form.Height - 2), 15))
						{
							e.Graphics.DrawPath(pen2, roundedPath2);
						}
					}
				};
				form.Region = new Region(CustomMessageBoxSMK.GetRoundedPath(new Rectangle(0, 0, form.Width, form.Height), 15));
				form.KeyDown += delegate(object s, KeyEventArgs e)
				{
					if (e.KeyCode == Keys.Escape)
					{
						form.DialogResult = DialogResult.Cancel;
						form.Close();
					}
				};
				result = form.ShowDialog();
			}
			return result;
		}

		// Token: 0x06000F7A RID: 3962 RVA: 0x00068460 File Offset: 0x00068460
		private static GraphicsPath GetRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = radius * 2;
			graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}
	}
}
