﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000650 RID: 1616
	public partial class OverlayBlur : Form
	{
		// Token: 0x06000F8B RID: 3979 RVA: 0x0006F1A4 File Offset: 0x0006F1A4
		private void Parent_Move(object sender, EventArgs e)
		{
			try
			{
				if (!this._closing && !base.IsDisposed)
				{
					if (this._parent != null && !this._parent.IsDisposed)
					{
						base.Bounds = this._parent.Bounds;
						base.Invalidate();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000F8C RID: 3980 RVA: 0x0006F208 File Offset: 0x0006F208
		private void Parent_Resize(object sender, EventArgs e)
		{
			try
			{
				if (!this._closing && !base.IsDisposed)
				{
					if (this._parent != null && !this._parent.IsDisposed)
					{
						base.Bounds = this._parent.Bounds;
						this.RefreshBlur();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000F8D RID: 3981 RVA: 0x0006F26C File Offset: 0x0006F26C
		protected override void OnFormClosed(FormClosedEventArgs e)
		{
			this._closing = true;
			try
			{
				if (this._parent != null && !this._parent.IsDisposed)
				{
					this._parent.Move -= this.Parent_Move;
					this._parent.Resize -= this.Parent_Resize;
				}
			}
			catch
			{
			}
			if (this._blurred != null)
			{
				try
				{
					this._blurred.Dispose();
				}
				catch
				{
				}
				this._blurred = null;
			}
			base.OnFormClosed(e);
		}

		// Token: 0x06000F8E RID: 3982 RVA: 0x0006F30C File Offset: 0x0006F30C
		public OverlayBlur(Form parent, int blurRadius, bool useUnsafeBlur)
		{
			this._parent = parent;
			this._blurRadius = blurRadius;
			if (this._blurRadius < 1)
			{
				this._blurRadius = 1;
			}
			this._useUnsafeBlur = useUnsafeBlur;
			if (this._parent == null || this._parent.IsDisposed)
			{
				return;
			}
			base.FormBorderStyle = FormBorderStyle.None;
			base.StartPosition = FormStartPosition.Manual;
			base.ShowInTaskbar = false;
			base.TopMost = false;
			base.ControlBox = false;
			base.MinimizeBox = false;
			base.MaximizeBox = false;
			this.DoubleBuffered = true;
			this.BackColor = Color.Black;
			base.Bounds = this._parent.Bounds;
			try
			{
				this.RefreshBlur();
			}
			catch
			{
				this._blurred = null;
			}
			this._parent.Move -= this.Parent_Move;
			this._parent.Resize -= this.Parent_Resize;
			this._parent.Move += this.Parent_Move;
			this._parent.Resize += this.Parent_Resize;
		}

		// Token: 0x06000F8F RID: 3983 RVA: 0x0006F42C File Offset: 0x0006F42C
		private void RefreshBlur()
		{
			if (this._closing)
			{
				return;
			}
			if (this._parent == null || this._parent.IsDisposed)
			{
				return;
			}
			Bitmap blurred = this._blurred;
			this._blurred = null;
			if (blurred != null)
			{
				try
				{
					blurred.Dispose();
				}
				catch
				{
				}
			}
			Bitmap bitmap = null;
			try
			{
				bitmap = BlurHelper.CaptureForm(this._parent);
				if (bitmap == null)
				{
					return;
				}
				if (this._useUnsafeBlur)
				{
					this._blurred = BlurHelper.BoxBlur(bitmap, this._blurRadius);
				}
				else
				{
					this._blurred = BlurHelper.SimpleBlur(bitmap, this._blurRadius);
				}
			}
			catch
			{
				this._blurred = null;
			}
			finally
			{
				if (bitmap != null)
				{
					try
					{
						bitmap.Dispose();
					}
					catch
					{
					}
				}
			}
			if (!base.IsDisposed)
			{
				try
				{
					base.Invalidate();
					base.Update();
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000F90 RID: 3984 RVA: 0x0006F52C File Offset: 0x0006F52C
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			try
			{
				if (this._blurred != null && !this._blurred.Size.IsEmpty)
				{
					e.Graphics.DrawImage(this._blurred, base.ClientRectangle);
				}
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(60, 0, 0, 0)))
				{
					e.Graphics.FillRectangle(solidBrush, base.ClientRectangle);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000F91 RID: 3985 RVA: 0x0006F5C4 File Offset: 0x0006F5C4
		public void SetTopMost(bool topMost)
		{
			try
			{
				if (!base.IsDisposed)
				{
					base.TopMost = topMost;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000F92 RID: 3986 RVA: 0x0000A9E6 File Offset: 0x0000A9E6
		public OverlayBlur(Form parent) : this(parent, 8, true)
		{
		}

		// Token: 0x06000F93 RID: 3987 RVA: 0x0006F5F8 File Offset: 0x0006F5F8
		public void ShowOverlay()
		{
			try
			{
				if (!base.IsDisposed)
				{
					if (this._parent != null && !this._parent.IsDisposed)
					{
						base.Bounds = this._parent.Bounds;
						base.Show(this._parent);
						base.BringToFront();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000F94 RID: 3988 RVA: 0x0006F660 File Offset: 0x0006F660
		public void CloseOverlay()
		{
			try
			{
				if (!base.IsDisposed)
				{
					this._closing = true;
					base.Hide();
					base.Close();
				}
			}
			catch
			{
			}
		}

		// Token: 0x04001482 RID: 5250
		private int _blurRadius;

		// Token: 0x04001483 RID: 5251
		private bool _useUnsafeBlur;
	}
}
