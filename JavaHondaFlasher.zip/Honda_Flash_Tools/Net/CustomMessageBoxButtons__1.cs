﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200034C RID: 844
	public enum CustomMessageBoxButtons__1
	{
		// Token: 0x04000CB2 RID: 3250
		OK,
		// Token: 0x04000CB3 RID: 3251
		OKCancel,
		// Token: 0x04000CB4 RID: 3252
		YesNo = 4,
		// Token: 0x04000CB5 RID: 3253
		YesNoCancel = 3
	}
}
