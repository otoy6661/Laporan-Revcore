﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020005FE RID: 1534
	public partial class FormMain__0 : Form
	{
		// Token: 0x020005FF RID: 1535
		public class RoundedProgressBar : Control
		{
			// Token: 0x1700005E RID: 94
			// (get) Token: 0x06000EE1 RID: 3809 RVA: 0x0000A304 File Offset: 0x0000A304
			// (set) Token: 0x06000EE2 RID: 3810 RVA: 0x0000A30C File Offset: 0x0000A30C
			public int Value
			{
				get
				{
					return this._value;
				}
				set
				{
					this._value = Math.Max(0, Math.Min(this._maximum, value));
					base.Invalidate();
				}
			}

			// Token: 0x1700005F RID: 95
			// (get) Token: 0x06000EE3 RID: 3811 RVA: 0x0000A32C File Offset: 0x0000A32C
			// (set) Token: 0x06000EE4 RID: 3812 RVA: 0x0000A334 File Offset: 0x0000A334
			public int Maximum
			{
				get
				{
					return this._maximum;
				}
				set
				{
					this._maximum = Math.Max(1, value);
					base.Invalidate();
				}
			}

			// Token: 0x17000060 RID: 96
			// (get) Token: 0x06000EE5 RID: 3813 RVA: 0x0000A349 File Offset: 0x0000A349
			// (set) Token: 0x06000EE6 RID: 3814 RVA: 0x0000A351 File Offset: 0x0000A351
			public int CornerRadius
			{
				get
				{
					return this._cornerRadius;
				}
				set
				{
					this._cornerRadius = value;
					base.Invalidate();
				}
			}

			// Token: 0x17000061 RID: 97
			// (get) Token: 0x06000EE7 RID: 3815 RVA: 0x0000A360 File Offset: 0x0000A360
			// (set) Token: 0x06000EE8 RID: 3816 RVA: 0x0000A368 File Offset: 0x0000A368
			public Color FillColor
			{
				get
				{
					return this._fillColor;
				}
				set
				{
					this._fillColor = value;
					base.Invalidate();
				}
			}

			// Token: 0x06000EE9 RID: 3817 RVA: 0x0006B8F4 File Offset: 0x0006B8F4
			public RoundedProgressBar()
			{
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			}

			// Token: 0x06000EEA RID: 3818 RVA: 0x0006B94C File Offset: 0x0006B94C
			protected override void OnPaint(PaintEventArgs e)
			{
				if (base.Width <= 0 || base.Height <= 0)
				{
					return;
				}
				e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				using (GraphicsPath graphicsPath = RoundedHelper.RoundedRect(new Rectangle(0, 0, base.Width - 1, base.Height - 1), this._cornerRadius))
				{
					using (SolidBrush solidBrush = new SolidBrush(this._backColor))
					{
						e.Graphics.FillPath(solidBrush, graphicsPath);
					}
				}
				int num = (int)((float)base.Width * (float)this._value / (float)this._maximum);
				if (num > 0)
				{
					using (GraphicsPath graphicsPath2 = RoundedHelper.RoundedRect(new Rectangle(0, 0, num, base.Height - 1), this._cornerRadius))
					{
						using (SolidBrush solidBrush2 = new SolidBrush(this._fillColor))
						{
							e.Graphics.FillPath(solidBrush2, graphicsPath2);
						}
					}
				}
			}

			// Token: 0x040013BE RID: 5054
			private int _value;

			// Token: 0x040013BF RID: 5055
			private int _maximum = 100;

			// Token: 0x040013C0 RID: 5056
			private int _cornerRadius = 6;

			// Token: 0x040013C1 RID: 5057
			private Color _fillColor = Color.FromArgb(0, 255, 230);

			// Token: 0x040013C2 RID: 5058
			private Color _backColor = Color.FromArgb(35, 40, 48);
		}
	}
}
