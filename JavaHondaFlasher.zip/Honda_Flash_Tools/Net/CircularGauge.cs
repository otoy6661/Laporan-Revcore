﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200067E RID: 1662
	public class CircularGauge : UserControl
	{
		// Token: 0x1700006B RID: 107
		// (get) Token: 0x06000FF5 RID: 4085 RVA: 0x0000AD4C File Offset: 0x0000AD4C
		// (set) Token: 0x06000FF6 RID: 4086 RVA: 0x0000AD54 File Offset: 0x0000AD54
		public double Value
		{
			get
			{
				return this._value;
			}
			set
			{
				this._value = Math.Max(this._minValue, Math.Min(this._maxValue, value));
				base.Invalidate();
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x06000FF7 RID: 4087 RVA: 0x0000AD79 File Offset: 0x0000AD79
		// (set) Token: 0x06000FF8 RID: 4088 RVA: 0x0000AD81 File Offset: 0x0000AD81
		public double MinValue
		{
			get
			{
				return this._minValue;
			}
			set
			{
				this._minValue = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x06000FF9 RID: 4089 RVA: 0x0000AD90 File Offset: 0x0000AD90
		// (set) Token: 0x06000FFA RID: 4090 RVA: 0x0000AD98 File Offset: 0x0000AD98
		public double MaxValue
		{
			get
			{
				return this._maxValue;
			}
			set
			{
				this._maxValue = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06000FFB RID: 4091 RVA: 0x0000ADA7 File Offset: 0x0000ADA7
		// (set) Token: 0x06000FFC RID: 4092 RVA: 0x0000ADAF File Offset: 0x0000ADAF
		public string Unit
		{
			get
			{
				return this._unit;
			}
			set
			{
				this._unit = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06000FFD RID: 4093 RVA: 0x0000ADBE File Offset: 0x0000ADBE
		// (set) Token: 0x06000FFE RID: 4094 RVA: 0x0000ADC6 File Offset: 0x0000ADC6
		public Color BarColor
		{
			get
			{
				return this._barColor;
			}
			set
			{
				this._barColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x06000FFF RID: 4095 RVA: 0x0007468C File Offset: 0x0007468C
		public CircularGauge()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer, true);
			base.Size = new Size(400, 400);
			this.BackColor = Color.Transparent;
		}

		// Token: 0x06001000 RID: 4096 RVA: 0x000746FC File Offset: 0x000746FC
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
			int num = base.Width / 2;
			int num2 = base.Height / 2;
			int num3 = Math.Min(base.Width, base.Height) / 2 - 28;
			int num4 = 24;
			Rectangle rect = new Rectangle(num - num3, num2 - num3, num3 * 2, num3 * 2);
			using (Pen pen = new Pen(this._backColor, (float)num4)
			{
				StartCap = LineCap.Round,
				EndCap = LineCap.Round
			})
			{
				graphics.DrawArc(pen, rect, 140f, 360f);
			}
			double num5 = 360.0 * (this.Value - this.MinValue) / (this.MaxValue - this.MinValue);
			using (Pen pen2 = new Pen(this.BarColor, (float)num4)
			{
				StartCap = LineCap.Round,
				EndCap = LineCap.Round
			})
			{
				graphics.DrawArc(pen2, rect, 140f, (float)num5);
			}
			int num6 = 210;
			using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(64, 64, 64)))
			{
				graphics.FillEllipse(solidBrush, num - num6 / 2, num2 - num6 / 2, num6, num6);
			}
			using (Pen pen3 = new Pen(Color.Cyan, 3f))
			{
				graphics.DrawEllipse(pen3, num - num6 / 2, num2 - num6 / 2, num6, num6);
			}
			string text = this.Value.ToString("F0");
			int num7 = 42;
			using (Font font = new Font("DS-DIGITAL", (float)num7, FontStyle.Bold))
			{
				using (SolidBrush solidBrush2 = new SolidBrush(Color.Cyan))
				{
					SizeF sizeF = graphics.MeasureString(text, font);
					graphics.DrawString(text, font, solidBrush2, (float)num - sizeF.Width / 2f, (float)num2 - sizeF.Height / 2f - 5f);
				}
			}
			if (!string.IsNullOrEmpty(this.Unit))
			{
				int num8 = 16;
				using (Font font2 = new Font("Arial", (float)num8, FontStyle.Bold))
				{
					using (SolidBrush solidBrush3 = new SolidBrush(Color.Cyan))
					{
						SizeF sizeF2 = graphics.MeasureString(this.Unit, font2);
						graphics.DrawString(this.Unit, font2, solidBrush3, (float)num - sizeF2.Width / 2f, (float)(num2 + 35));
					}
				}
			}
		}

		// Token: 0x04001520 RID: 5408
		private double _value;

		// Token: 0x04001521 RID: 5409
		private double _minValue;

		// Token: 0x04001522 RID: 5410
		private double _maxValue = 100.0;

		// Token: 0x04001523 RID: 5411
		private string _unit = "";

		// Token: 0x04001524 RID: 5412
		private Color _barColor = Color.Cyan;

		// Token: 0x04001525 RID: 5413
		private Color _backColor = SystemColors.ButtonShadow;
	}
}
