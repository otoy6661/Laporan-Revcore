﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000756 RID: 1878
	public partial class FM_diag : global::System.Windows.Forms.Form
	{
		// Token: 0x060011B4 RID: 4532 RVA: 0x00081CAC File Offset: 0x00081CAC
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			this.dataviewLiveData = new global::System.Windows.Forms.DataGridView();
			this.panelHeader = new global::System.Windows.Forms.Panel();
			this.label1 = new global::System.Windows.Forms.Label();
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.button1 = new global::System.Windows.Forms.Button();
			this.button2 = new global::System.Windows.Forms.Button();
			this.button3 = new global::System.Windows.Forms.Button();
			this.button4 = new global::System.Windows.Forms.Button();
			this.button5 = new global::System.Windows.Forms.Button();
			this.button6 = new global::System.Windows.Forms.Button();
			this.button7 = new global::System.Windows.Forms.Button();
			this.txtCOMName = new global::System.Windows.Forms.Label();
			this.stsSNCable = new global::System.Windows.Forms.Label();
			this.SerialPort_0 = new global::System.IO.Ports.SerialPort(this.components);
			this.Timer_0 = new global::System.Windows.Forms.Timer(this.components);
			this.Timer_2 = new global::System.Windows.Forms.Timer(this.components);
			this.dragControl2 = new global::Honda_Flash_Tools.Net.DragControl__0();
			this.lblGrapTPS = new global::System.Windows.Forms.GroupBox();
			this.txtMinTPS = new global::System.Windows.Forms.TextBox();
			this.txtMaxTPS = new global::System.Windows.Forms.TextBox();
			this.txtCurrentTPS = new global::System.Windows.Forms.TextBox();
			this.comGraphTPS = new global::System.Windows.Forms.ComboBox();
			this.comboSensor = new global::System.Windows.Forms.ComboBox();
			this.comboVoltage = new global::System.Windows.Forms.ComboBox();
			this.txtValue1 = new global::System.Windows.Forms.TextBox();
			this.txtValue1_Min = new global::System.Windows.Forms.TextBox();
			this.txtValue1_Max = new global::System.Windows.Forms.TextBox();
			this.txtValue2 = new global::System.Windows.Forms.TextBox();
			this.txtValue2_Min = new global::System.Windows.Forms.TextBox();
			this.txtValue2_Max = new global::System.Windows.Forms.TextBox();
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.Column1 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column2 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column3 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column4 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column5 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			((global::System.ComponentModel.ISupportInitialize)this.dataviewLiveData).BeginInit();
			this.panelHeader.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			this.lblGrapTPS.SuspendLayout();
			base.SuspendLayout();
			this.dataviewLiveData.AllowUserToDeleteRows = false;
			this.dataviewLiveData.AllowUserToOrderColumns = false;
			this.dataviewLiveData.AllowUserToResizeColumns = false;
			this.dataviewLiveData.AllowUserToResizeRows = false;
			this.dataviewLiveData.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.dataviewLiveData.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.dataviewLiveData.BackgroundColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark;
			this.dataviewLiveData.GridColor = global::System.Drawing.Color.FromArgb(40, 50, 60);
			this.dataviewLiveData.EnableHeadersVisualStyles = false;
			this.dataviewLiveData.ColumnHeadersDefaultCellStyle.BackColor = global::System.Drawing.Color.FromArgb(30, 40, 50);
			this.dataviewLiveData.ColumnHeadersDefaultCellStyle.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonCyan;
			this.dataviewLiveData.ColumnHeadersDefaultCellStyle.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Bold);
			this.dataviewLiveData.DefaultCellStyle.BackColor = global::Honda_Flash_Tools.Net.FM_diag.RowAlt1;
			this.dataviewLiveData.DefaultCellStyle.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.TextSoft;
			this.dataviewLiveData.DefaultCellStyle.SelectionBackColor = global::System.Drawing.Color.FromArgb(0, 100, 90);
			this.dataviewLiveData.DefaultCellStyle.SelectionForeColor = global::System.Drawing.Color.White;
			this.dataviewLiveData.ColumnHeadersHeight = 30;
			this.dataviewLiveData.ColumnHeadersHeightSizeMode = global::System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataviewLiveData.Columns.AddRange(new global::System.Windows.Forms.DataGridViewColumn[]
			{
				this.Column1,
				this.Column2,
				this.Column3,
				this.Column4,
				this.Column5
			});
			this.dataviewLiveData.Location = new global::System.Drawing.Point(12, 40);
			this.dataviewLiveData.Name = "dataviewLiveData";
			this.dataviewLiveData.ReadOnly = true;
			this.dataviewLiveData.RowHeadersVisible = false;
			this.dataviewLiveData.SelectionMode = global::System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dataviewLiveData.Size = new global::System.Drawing.Size(450, 500);
			this.dataviewLiveData.TabIndex = 0;
			foreach (object obj in this.dataviewLiveData.Columns)
			{
				((global::System.Windows.Forms.DataGridViewColumn)obj).SortMode = global::System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			}
			this.Column1.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.Column1.HeaderText = "No";
			this.Column1.Name = "Column1";
			this.Column1.ReadOnly = true;
			this.Column1.Width = 50;
			this.Column2.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
			this.Column2.HeaderText = "Parameter";
			this.Column2.Name = "Column2";
			this.Column2.ReadOnly = true;
			this.Column2.Width = 150;
			this.Column3.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.Column3.HeaderText = "Value";
			this.Column3.Name = "Column3";
			this.Column3.ReadOnly = true;
			this.Column3.Width = 80;
			this.Column4.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.Column4.HeaderText = "Unit";
			this.Column4.Name = "Column4";
			this.Column4.ReadOnly = true;
			this.Column4.Width = 80;
			this.Column5.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.Column5.HeaderText = "Typical(*)";
			this.Column5.Name = "Column5";
			this.Column5.ReadOnly = true;
			this.panelHeader.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark;
			this.panelHeader.Controls.Add(this.label1);
			this.panelHeader.Controls.Add(this.pictureBox1);
			this.panelHeader.Controls.Add(this.button1);
			this.panelHeader.Controls.Add(this.button5);
			this.panelHeader.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.panelHeader.Location = new global::System.Drawing.Point(0, 0);
			this.panelHeader.Size = new global::System.Drawing.Size(900, 30);
			this.panelHeader.TabIndex = 1;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Segoe UI", 12f, global::System.Drawing.FontStyle.Bold);
			this.label1.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonCyan;
			this.label1.Location = new global::System.Drawing.Point(339, 4);
			this.label1.Text = "DEPPLOY MAP TUNING DIAGNOSTIC";
			this.label1.BackColor = global::System.Drawing.Color.Transparent;
			this.pictureBox1.BackColor = global::System.Drawing.Color.Transparent;
			this.pictureBox1.Location = new global::System.Drawing.Point(0, 0);
			this.pictureBox1.Size = new global::System.Drawing.Size(83, 50);
			this.pictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button1.AutoSize = false;
			this.button1.Size = new global::System.Drawing.Size(24, 24);
			this.button1.Location = new global::System.Drawing.Point(866, 3);
			this.button1.Text = "✕";
			this.button1.Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Bold);
			this.button1.BackColor = global::System.Drawing.Color.FromArgb(220, 60, 60);
			this.button1.ForeColor = global::System.Drawing.Color.White;
			this.button1.FlatAppearance.BorderSize = 0;
			this.button1.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(220, 60, 60);
			this.button1.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.FromArgb(255, 90, 90);
			this.button1.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(180, 40, 40);
			this.button1.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button1.TabStop = false;
			this.button1.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.button1.Padding = new global::System.Windows.Forms.Padding(-2, 0, 0, 0);
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.SetRoundedButton(this.button1, 12);
			this.button5.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button5.AutoSize = false;
			this.button5.Size = new global::System.Drawing.Size(24, 24);
			this.button5.Location = new global::System.Drawing.Point(836, 3);
			this.button5.Text = "–";
			this.button5.Font = new global::System.Drawing.Font("Segoe UI", 10f, global::System.Drawing.FontStyle.Bold);
			this.button5.BackColor = global::System.Drawing.Color.FromArgb(90, 95, 110);
			this.button5.ForeColor = global::System.Drawing.Color.White;
			this.button5.FlatAppearance.BorderSize = 0;
			this.button5.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(90, 95, 110);
			this.button5.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.FromArgb(130, 135, 150);
			this.button5.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(60, 65, 80);
			this.button5.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button5.TabStop = false;
			this.button5.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.button5.UseVisualStyleBackColor = false;
			this.button5.Click += new global::System.EventHandler(this.button5_Click);
			this.SetRoundedButton(this.button5, 12);
			this.txtMinTPS.Location = new global::System.Drawing.Point(476, 550);
			this.txtMinTPS.Size = new global::System.Drawing.Size(69, 23);
			this.txtMinTPS.Text = "Min";
			this.txtMinTPS.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonRed;
			this.txtMinTPS.Font = new global::System.Drawing.Font("DS-DIGITAL", 12f, global::System.Drawing.FontStyle.Bold);
			this.txtMinTPS.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.txtMinTPS.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
			this.txtMinTPS.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.txtCurrentTPS.Location = new global::System.Drawing.Point(563, 550);
			this.txtCurrentTPS.Size = new global::System.Drawing.Size(69, 23);
			this.txtCurrentTPS.Text = "Current";
			this.txtCurrentTPS.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonCyan;
			this.txtCurrentTPS.Font = new global::System.Drawing.Font("DS-DIGITAL", 12f, global::System.Drawing.FontStyle.Bold);
			this.txtCurrentTPS.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.txtCurrentTPS.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
			this.txtCurrentTPS.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.txtMaxTPS.Location = new global::System.Drawing.Point(647, 550);
			this.txtMaxTPS.Size = new global::System.Drawing.Size(69, 23);
			this.txtMaxTPS.Text = "Max";
			this.txtMaxTPS.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonRed;
			this.txtMaxTPS.Font = new global::System.Drawing.Font("DS-DIGITAL", 12f, global::System.Drawing.FontStyle.Bold);
			this.txtMaxTPS.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.txtMaxTPS.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
			this.txtMaxTPS.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.comGraphTPS.Location = new global::System.Drawing.Point(738, 550);
			this.comGraphTPS.Size = new global::System.Drawing.Size(150, 23);
			this.comGraphTPS.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
			this.comGraphTPS.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonCyan;
			this.comGraphTPS.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.comGraphTPS.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comGraphTPS.SelectedIndexChanged += new global::System.EventHandler(this.comGraphTPS_SelectedIndexChanged);
			this.comboSensor.Location = new global::System.Drawing.Point(476, 585);
			this.comboSensor.Size = new global::System.Drawing.Size(200, 23);
			this.comboSensor.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
			this.comboSensor.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonCyan;
			this.comboSensor.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.comboSensor.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboSensor.SelectedIndexChanged += new global::System.EventHandler(this.comboSensor_SelectedIndexChanged);
			this.comboVoltage.Location = new global::System.Drawing.Point(688, 585);
			this.comboVoltage.Size = new global::System.Drawing.Size(200, 23);
			this.comboVoltage.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
			this.comboVoltage.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonCyan;
			this.comboVoltage.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.comboVoltage.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			int num = 476;
			int y = 625;
			int num2 = 72;
			int height = 32;
			int num3 = 8;
			this.button3.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button3.Location = new global::System.Drawing.Point(num, y);
			this.button3.Size = new global::System.Drawing.Size(num2, height);
			this.button3.Text = "Start";
			this.button3.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
			this.button3.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonGreen;
			this.button3.Font = new global::System.Drawing.Font("Segoe UI Semibold", 7.5f, global::System.Drawing.FontStyle.Bold);
			this.button3.FlatAppearance.BorderColor = global::Honda_Flash_Tools.Net.FM_diag.NeonGreen;
			this.button3.FlatAppearance.BorderSize = 1;
			this.button3.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.FromArgb(20, 60, 40);
			this.button3.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(10, 35, 25);
			this.button3.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button3.UseVisualStyleBackColor = false;
			this.button3.AutoEllipsis = true;
			this.button3.Click += new global::System.EventHandler(this.button3_Click);
			this.SetRoundedButton(this.button3, 8);
			this.button2.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			checked
			{
				this.button2.Location = new global::System.Drawing.Point(num + (num2 + num3), y);
				this.button2.Size = new global::System.Drawing.Size(num2, height);
				this.button2.Text = "Exit";
				this.button2.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
				this.button2.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonRed;
				this.button2.Font = new global::System.Drawing.Font("Segoe UI Semibold", 7.5f, global::System.Drawing.FontStyle.Bold);
				this.button2.FlatAppearance.BorderColor = global::Honda_Flash_Tools.Net.FM_diag.NeonRed;
				this.button2.FlatAppearance.BorderSize = 1;
				this.button2.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.FromArgb(60, 20, 25);
				this.button2.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(35, 10, 12);
				this.button2.Cursor = global::System.Windows.Forms.Cursors.Hand;
				this.button2.UseVisualStyleBackColor = false;
				this.button2.AutoEllipsis = true;
				this.button2.Click += new global::System.EventHandler(this.button2_Click);
				this.SetRoundedButton(this.button2, 8);
				this.button4.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
				this.button4.Location = new global::System.Drawing.Point(num + (num2 + num3) * 2, y);
				this.button4.Size = new global::System.Drawing.Size(num2, height);
				this.button4.Text = "Reset ECM";
				this.button4.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
				this.button4.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonAmber;
				this.button4.Font = new global::System.Drawing.Font("Segoe UI Semibold", 7.5f, global::System.Drawing.FontStyle.Bold);
				this.button4.FlatAppearance.BorderColor = global::Honda_Flash_Tools.Net.FM_diag.NeonAmber;
				this.button4.FlatAppearance.BorderSize = 1;
				this.button4.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.FromArgb(60, 50, 10);
				this.button4.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(35, 28, 5);
				this.button4.Cursor = global::System.Windows.Forms.Cursors.Hand;
				this.button4.UseVisualStyleBackColor = false;
				this.button4.AutoEllipsis = true;
				this.button4.Click += new global::System.EventHandler(this.button4_Click);
				this.SetRoundedButton(this.button4, 8);
				this.button6.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
				this.button6.Location = new global::System.Drawing.Point(num + (num2 + num3) * 3, y);
				this.button6.Size = new global::System.Drawing.Size(num2, height);
				this.button6.Text = "Start Graph";
				this.button6.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
				this.button6.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonCyan;
				this.button6.Font = new global::System.Drawing.Font("Segoe UI Semibold", 7.5f, global::System.Drawing.FontStyle.Bold);
				this.button6.FlatAppearance.BorderColor = global::Honda_Flash_Tools.Net.FM_diag.NeonCyan;
				this.button6.FlatAppearance.BorderSize = 1;
				this.button6.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.FromArgb(20, 50, 60);
				this.button6.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(10, 28, 34);
				this.button6.Cursor = global::System.Windows.Forms.Cursors.Hand;
				this.button6.UseVisualStyleBackColor = false;
				this.button6.AutoEllipsis = true;
				this.button6.Click += new global::System.EventHandler(this.button6_Click);
				this.SetRoundedButton(this.button6, 8);
				this.button7.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
				this.button7.Location = new global::System.Drawing.Point(num + (num2 + num3) * 4, y);
				this.button7.Size = new global::System.Drawing.Size(num2, height);
				this.button7.Text = "Stop Graph";
				this.button7.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
				this.button7.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonAmber;
				this.button7.Font = new global::System.Drawing.Font("Segoe UI Semibold", 7.5f, global::System.Drawing.FontStyle.Bold);
				this.button7.FlatAppearance.BorderColor = global::Honda_Flash_Tools.Net.FM_diag.NeonAmber;
				this.button7.FlatAppearance.BorderSize = 1;
				this.button7.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.FromArgb(60, 50, 10);
				this.button7.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(35, 28, 5);
				this.button7.Cursor = global::System.Windows.Forms.Cursors.Hand;
				this.button7.UseVisualStyleBackColor = false;
				this.button7.AutoEllipsis = true;
				this.button7.Click += new global::System.EventHandler(this.button7_Click);
				this.SetRoundedButton(this.button7, 8);
				this.txtValue1.Location = new global::System.Drawing.Point(12, 580);
				this.txtValue1.Size = new global::System.Drawing.Size(48, 23);
				this.txtValue1.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
				this.txtValue1.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonCyan;
				this.txtValue1.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
				this.txtValue1_Min.Location = new global::System.Drawing.Point(66, 580);
				this.txtValue1_Min.Size = new global::System.Drawing.Size(48, 23);
				this.txtValue1_Min.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
				this.txtValue1_Min.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonRed;
				this.txtValue1_Min.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
				this.txtValue1_Max.Location = new global::System.Drawing.Point(120, 580);
				this.txtValue1_Max.Size = new global::System.Drawing.Size(48, 23);
				this.txtValue1_Max.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
				this.txtValue1_Max.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonRed;
				this.txtValue1_Max.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
				this.txtValue2.Location = new global::System.Drawing.Point(180, 580);
				this.txtValue2.Size = new global::System.Drawing.Size(80, 23);
				this.txtValue2.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
				this.txtValue2.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonCyan;
				this.txtValue2.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
				this.txtValue2_Min.Location = new global::System.Drawing.Point(266, 580);
				this.txtValue2_Min.Size = new global::System.Drawing.Size(80, 23);
				this.txtValue2_Min.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
				this.txtValue2_Min.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonRed;
				this.txtValue2_Min.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
				this.txtValue2_Max.Location = new global::System.Drawing.Point(352, 580);
				this.txtValue2_Max.Size = new global::System.Drawing.Size(80, 23);
				this.txtValue2_Max.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
				this.txtValue2_Max.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonRed;
				this.txtValue2_Max.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
				this.txtCOMName.AutoSize = true;
				this.txtCOMName.Location = new global::System.Drawing.Point(12, 620);
				this.txtCOMName.Text = "-";
				this.txtCOMName.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonAmber;
				this.txtCOMName.Font = new global::System.Drawing.Font("Segoe UI", 8f);
				this.txtCOMName.BackColor = global::System.Drawing.Color.Transparent;
				this.stsSNCable.AutoSize = true;
				this.stsSNCable.Location = new global::System.Drawing.Point(12, 640);
				this.stsSNCable.Text = "-";
				this.stsSNCable.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.TextSoft;
				this.stsSNCable.Font = new global::System.Drawing.Font("Segoe UI", 8f);
				this.stsSNCable.BackColor = global::System.Drawing.Color.Transparent;
				this.ChartTPS.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
				this.ChartTPS.Dock = global::System.Windows.Forms.DockStyle.Fill;
				this.ChartTPS.Location = new global::System.Drawing.Point(3, 19);
				this.ChartTPS.Name = "ChartTPS";
				this.ChartTPS.Size = new global::System.Drawing.Size(413, 485);
				this.ChartTPS.TabIndex = 7;
				this.ChartTPS.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.TextSoft;
				this.lblGrapTPS.Controls.Add(this.ChartTPS);
				this.lblGrapTPS.Location = new global::System.Drawing.Point(470, 40);
				this.lblGrapTPS.Name = "lblGrapTPS";
				this.lblGrapTPS.Size = new global::System.Drawing.Size(419, 507);
				this.lblGrapTPS.TabIndex = 8;
				this.lblGrapTPS.TabStop = false;
				this.lblGrapTPS.Text = "TPS Sensor";
				this.lblGrapTPS.ForeColor = global::Honda_Flash_Tools.Net.FM_diag.NeonCyan;
				this.lblGrapTPS.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark;
				this.lblGrapTPS.Font = new global::System.Drawing.Font("Segoe UI Semibold", 9f, global::System.Drawing.FontStyle.Bold);
				this.ChartSensor.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
				this.ChartSensor.Location = new global::System.Drawing.Point(12, 670);
				this.ChartSensor.Size = new global::System.Drawing.Size(400, 150);
				this.ChartSensor.Visible = false;
				this.ChartVoltage.BackColor = global::Honda_Flash_Tools.Net.FM_diag.CardDark2;
				this.ChartVoltage.Location = new global::System.Drawing.Point(420, 670);
				this.ChartVoltage.Size = new global::System.Drawing.Size(400, 150);
				this.ChartVoltage.Visible = false;
				this.panel1.Location = new global::System.Drawing.Point(898, 49);
				this.dragControl2.SelecControl = this.panelHeader;
				this.Timer_0.Tick += new global::System.EventHandler(this.Timer_0_Tick);
				this.Timer_2.Tick += new global::System.EventHandler(this.Timer_2_Tick);
				base.SetStyle(global::System.Windows.Forms.ControlStyles.UserPaint | global::System.Windows.Forms.ControlStyles.ResizeRedraw | global::System.Windows.Forms.ControlStyles.AllPaintingInWmPaint | global::System.Windows.Forms.ControlStyles.OptimizedDoubleBuffer, true);
				base.UpdateStyles();
				base.Padding = new global::System.Windows.Forms.Padding(5);
				this.borderTimer = new global::System.Windows.Forms.Timer();
				this.borderTimer.Interval = 30;
				this.borderTimer.Tick += new global::System.EventHandler(this.BorderTimer_Tick);
				this.borderTimer.Start();
				base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
				base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
				base.AutoScaleDimensions = new global::System.Drawing.SizeF(4f, 12f);
				base.TopMost = true;
				this.BackColor = global::Honda_Flash_Tools.Net.FM_diag.BgDark;
				base.ClientSize = new global::System.Drawing.Size(910, 670);
				base.Controls.Add(this.dataviewLiveData);
				base.Controls.Add(this.lblGrapTPS);
				base.Controls.Add(this.button3);
				base.Controls.Add(this.button2);
				base.Controls.Add(this.button4);
				base.Controls.Add(this.button6);
				base.Controls.Add(this.button7);
				base.Controls.Add(this.comGraphTPS);
				base.Controls.Add(this.txtMinTPS);
				base.Controls.Add(this.txtMaxTPS);
				base.Controls.Add(this.txtCurrentTPS);
				base.Controls.Add(this.comboSensor);
				base.Controls.Add(this.comboVoltage);
				base.Controls.Add(this.txtValue1);
				base.Controls.Add(this.txtValue1_Min);
				base.Controls.Add(this.txtValue1_Max);
				base.Controls.Add(this.txtValue2);
				base.Controls.Add(this.txtValue2_Min);
				base.Controls.Add(this.txtValue2_Max);
				base.Controls.Add(this.txtCOMName);
				base.Controls.Add(this.stsSNCable);
				base.Controls.Add(this.ChartSensor);
				base.Controls.Add(this.ChartVoltage);
				base.Controls.Add(this.panelHeader);
				base.Name = "FM_diag";
				base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
				this.Text = "Honda Program Kline";
				base.Load += new global::System.EventHandler(this.FM_diag_Load);
				base.Paint += new global::System.Windows.Forms.PaintEventHandler(this.FM_diag_Paint);
				base.Resize += new global::System.EventHandler(this.FM_diag_Resize);
				((global::System.ComponentModel.ISupportInitialize)this.dataviewLiveData).EndInit();
				this.panelHeader.ResumeLayout(false);
				this.panelHeader.PerformLayout();
				((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
				this.lblGrapTPS.ResumeLayout(false);
				base.ResumeLayout(false);
				base.PerformLayout();
				global::System.Drawing.Drawing2D.GraphicsPath graphicsPath = new global::System.Drawing.Drawing2D.GraphicsPath();
				int num4 = 16;
				graphicsPath.AddArc(0, 0, num4, num4, 180f, 90f);
				graphicsPath.AddArc(base.Width - num4, 0, num4, num4, 270f, 90f);
				graphicsPath.AddArc(base.Width - num4, base.Height - num4, num4, num4, 0f, 90f);
				graphicsPath.AddArc(0, base.Height - num4, num4, num4, 90f, 90f);
				graphicsPath.CloseAllFigures();
				base.Region = new global::System.Drawing.Region(graphicsPath);
			}
		}

		// Token: 0x060011BF RID: 4543 RVA: 0x0000BA21 File Offset: 0x0000BA21
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (this.borderTimer != null)
				{
					this.borderTimer.Stop();
					this.borderTimer.Dispose();
				}
				if (this.components != null)
				{
					this.components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		// Token: 0x0400186E RID: 6254
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400186F RID: 6255
		private global::System.Windows.Forms.DataGridView dataviewLiveData;

		// Token: 0x04001870 RID: 6256
		private global::System.Windows.Forms.Panel panelHeader;

		// Token: 0x04001871 RID: 6257
		private global::System.Windows.Forms.PictureBox pictureBox1;

		// Token: 0x04001872 RID: 6258
		private global::System.Windows.Forms.Button button1;

		// Token: 0x04001873 RID: 6259
		private global::System.Windows.Forms.Button button2;

		// Token: 0x04001874 RID: 6260
		private global::System.Windows.Forms.Button button3;

		// Token: 0x04001875 RID: 6261
		private global::System.Windows.Forms.Button button4;

		// Token: 0x04001876 RID: 6262
		private global::System.Windows.Forms.Button button5;

		// Token: 0x04001877 RID: 6263
		private global::System.Windows.Forms.Button button6;

		// Token: 0x04001878 RID: 6264
		private global::System.Windows.Forms.Button button7;

		// Token: 0x04001879 RID: 6265
		private global::System.Windows.Forms.Label label1;

		// Token: 0x0400187A RID: 6266
		private global::System.Windows.Forms.Label txtCOMName;

		// Token: 0x0400187B RID: 6267
		private global::System.Windows.Forms.Label stsSNCable;

		// Token: 0x0400187C RID: 6268
		private global::System.Windows.Forms.TextBox txtMinTPS;

		// Token: 0x0400187D RID: 6269
		private global::System.Windows.Forms.TextBox txtMaxTPS;

		// Token: 0x0400187E RID: 6270
		private global::System.Windows.Forms.TextBox txtCurrentTPS;

		// Token: 0x0400187F RID: 6271
		private global::System.Windows.Forms.TextBox txtValue1;

		// Token: 0x04001880 RID: 6272
		private global::System.Windows.Forms.TextBox txtValue1_Min;

		// Token: 0x04001881 RID: 6273
		private global::System.Windows.Forms.TextBox txtValue1_Max;

		// Token: 0x04001882 RID: 6274
		private global::System.Windows.Forms.TextBox txtValue2;

		// Token: 0x04001883 RID: 6275
		private global::System.Windows.Forms.TextBox txtValue2_Min;

		// Token: 0x04001884 RID: 6276
		private global::System.Windows.Forms.TextBox txtValue2_Max;

		// Token: 0x04001885 RID: 6277
		private global::System.Windows.Forms.ComboBox comGraphTPS;

		// Token: 0x04001886 RID: 6278
		private global::System.Windows.Forms.ComboBox comboSensor;

		// Token: 0x04001887 RID: 6279
		private global::System.Windows.Forms.ComboBox comboVoltage;

		// Token: 0x04001888 RID: 6280
		private global::System.IO.Ports.SerialPort SerialPort_0;

		// Token: 0x04001889 RID: 6281
		private global::System.Windows.Forms.Timer Timer_0;

		// Token: 0x0400188A RID: 6282
		private global::System.Windows.Forms.Timer Timer_2;

		// Token: 0x0400188B RID: 6283
		private global::Honda_Flash_Tools.Net.DragControl__0 dragControl2;

		// Token: 0x0400188C RID: 6284
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x0400188D RID: 6285
		private global::Honda_Flash_Tools.Net.CustomChart__0 ChartTPS;

		// Token: 0x0400188E RID: 6286
		private global::Honda_Flash_Tools.Net.CustomChart__0 ChartSensor;

		// Token: 0x0400188F RID: 6287
		private global::Honda_Flash_Tools.Net.CustomChart__0 ChartVoltage;

		// Token: 0x040018B1 RID: 6321
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Column1;

		// Token: 0x040018B2 RID: 6322
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Column2;

		// Token: 0x040018B3 RID: 6323
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Column3;

		// Token: 0x040018B4 RID: 6324
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Column4;

		// Token: 0x040018B5 RID: 6325
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Column5;

		// Token: 0x040018B6 RID: 6326
		private global::System.Windows.Forms.GroupBox lblGrapTPS;

		// Token: 0x040018B7 RID: 6327
		private global::System.Windows.Forms.Timer borderTimer;

		// Token: 0x040018BB RID: 6331
		private static readonly global::System.Drawing.Color BgDark = global::System.Drawing.Color.FromArgb(10, 14, 22);

		// Token: 0x040018BC RID: 6332
		private static readonly global::System.Drawing.Color CardDark = global::System.Drawing.Color.FromArgb(18, 24, 34);

		// Token: 0x040018BD RID: 6333
		private static readonly global::System.Drawing.Color CardDark2 = global::System.Drawing.Color.FromArgb(22, 30, 42);

		// Token: 0x040018BE RID: 6334
		private static readonly global::System.Drawing.Color NeonCyan = global::System.Drawing.Color.FromArgb(0, 255, 220);

		// Token: 0x040018BF RID: 6335
		private static readonly global::System.Drawing.Color NeonAmber = global::System.Drawing.Color.FromArgb(255, 180, 0);

		// Token: 0x040018C0 RID: 6336
		private static readonly global::System.Drawing.Color NeonRed = global::System.Drawing.Color.FromArgb(255, 80, 100);

		// Token: 0x040018C1 RID: 6337
		private static readonly global::System.Drawing.Color NeonGreen = global::System.Drawing.Color.FromArgb(0, 255, 140);

		// Token: 0x040018C2 RID: 6338
		private static readonly global::System.Drawing.Color TextSoft = global::System.Drawing.Color.FromArgb(150, 170, 190);

		// Token: 0x040018C3 RID: 6339
		private static readonly global::System.Drawing.Color RowAlt1 = global::System.Drawing.Color.FromArgb(22, 30, 42);
	}
}
