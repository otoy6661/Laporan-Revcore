﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000714 RID: 1812
	public partial class SplashScreenPopup : Form
	{
		// Token: 0x06001062 RID: 4194
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x06001063 RID: 4195
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		// Token: 0x06001064 RID: 4196 RVA: 0x000765B0 File Offset: 0x000765B0
		public SplashScreenPopup()
		{
			this._cyberpunkColors = new Color[]
			{
				Color.FromArgb(0, 255, 255),
				Color.FromArgb(255, 0, 255),
				Color.FromArgb(0, 255, 128),
				Color.FromArgb(255, 0, 128),
				Color.FromArgb(255, 255, 0)
			};
			this._particleRandom = new Random();
			this._simRandom = new Random();
			this._isClosing = false;
			this._spinnerAngle = 0f;
			this._spinnerPulse = 0f;
			this._spinnerRandom = new Random();
			this._spinnerTrailPoints = new PointF[20];
			this._spinnerTrailIndex = 0;
			checked
			{
				for (int i = 0; i < 20; i++)
				{
					this._spinnerTrailPoints[i] = new PointF(-1000f, -1000f);
				}
				this._fontDepploy = new Font("Segoe UI", 24f, FontStyle.Bold);
				this._fontMapTuning = new Font("Segoe UI", 20f, FontStyle.Bold);
				this._loadingFormat = new StringFormat
				{
					Alignment = StringAlignment.Center,
					LineAlignment = StringAlignment.Center
				};
				this._spinnerOffsetX = 0f;
				this._spinnerOffsetY = 0f;
				this._spinnerTargetOffsetX = 0f;
				this._spinnerTargetOffsetY = 0f;
				this._driftTimer = 0;
				this._driftDuration = 30;
				this._driftRange = 690f;
				this._returnToCenter = true;
				this.InitializeComponent();
				base.FormBorderStyle = FormBorderStyle.None;
				base.AutoScaleMode = AutoScaleMode.Dpi;
				base.StartPosition = FormStartPosition.CenterScreen;
				base.ClientSize = new Size(600, 350);
				base.TopMost = true;
				base.ControlBox = false;
				base.ShowInTaskbar = false;
				base.BackColor = Color.Black;
				base.TransparencyKey = Color.Black;
				this.DoubleBuffered = true;
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
				this.InitializeTimers();
				base.MouseDown += this.SplashScreen_MouseDown;
				base.FormClosing += this.SplashScreen_FormClosing;
			}
		}

		// Token: 0x06001065 RID: 4197 RVA: 0x000767E8 File Offset: 0x000767E8
		private void ProgressTimer_Tick(object sender, EventArgs e)
		{
			if (!this._isClosing && this._progressPercent < 100f)
			{
				this._progressPercent += 1.5f + (float)this._simRandom.NextDouble() * 0.5f;
				if (this._progressPercent >= 100f)
				{
					this._progressPercent = 100f;
					this._hasReached100 = true;
					this._progressTimer.Stop();
					this.OnLoadingComplete();
				}
			}
		}

		// Token: 0x06001068 RID: 4200 RVA: 0x0000B1DC File Offset: 0x0000B1DC
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			SplashScreenPopup.AnimateWindow(base.Handle, 500, 393217);
		}

		// Token: 0x06001069 RID: 4201 RVA: 0x00076900 File Offset: 0x00076900
		private void InitializeTimers()
		{
			this._progressTimer = new Timer
			{
				Interval = 50
			};
			this._progressTimer.Tick += this.ProgressTimer_Tick;
			this._progressTimer.Start();
			this._animationTimer = new Timer
			{
				Interval = 10
			};
			this._animationTimer.Tick += delegate(object <p0>, EventArgs <p1>)
			{
				if (!this._isClosing)
				{
					this.UpdateSimulationData();
				}
				base.Invalidate();
			};
			this._animationTimer.Start();
		}

		// Token: 0x0600106A RID: 4202
		[DllImport("user32.dll")]
		private static extern bool AnimateWindow(IntPtr hWnd, int dwTime, int dwFlags);

		// Token: 0x0600106B RID: 4203 RVA: 0x0000B1FB File Offset: 0x0000B1FB
		private void OnLoadingComplete()
		{
			this._isReady = true;
			base.Close();
		}

		// Token: 0x0600106C RID: 4204 RVA: 0x00076978 File Offset: 0x00076978
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.CompositingQuality = CompositingQuality.HighQuality;
			graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
			graphics.Clear(Color.Black);
			this.DrawDotSpinner(graphics, base.Width, base.Height);
			this.DrawLogoText(graphics, base.Width, base.Height);
		}

		// Token: 0x0600106D RID: 4205 RVA: 0x0000B20A File Offset: 0x0000B20A
		private void SplashScreen_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				SplashScreenPopup.ReleaseCapture();
				SplashScreenPopup.SendMessage(base.Handle, 161, 2, 0);
			}
		}

		// Token: 0x0600106E RID: 4206 RVA: 0x000769E0 File Offset: 0x000769E0
		private void UpdateSimulationData()
		{
			checked
			{
				this._frameCounter++;
			}
			this._spinnerAngle += 4f;
			if (this._spinnerAngle >= 360f)
			{
				this._spinnerAngle -= 360f;
			}
			this._spinnerPulse += 0.05f;
			if ((double)this._spinnerPulse > 6.283185307179586)
			{
				this._spinnerPulse = 0f;
			}
			checked
			{
				this._driftTimer++;
			}
			if (this._driftTimer >= this._driftDuration)
			{
				this._driftTimer = 0;
				if (this._returnToCenter)
				{
					double num = this._spinnerRandom.NextDouble() * 3.141592653589793 * 2.0;
					double num2 = this._spinnerRandom.NextDouble() * (double)this._driftRange;
					this._spinnerTargetOffsetX = (float)(Math.Cos(num) * num2);
					this._spinnerTargetOffsetY = (float)(Math.Sin(num) * num2);
					this._returnToCenter = false;
				}
				else
				{
					this._spinnerTargetOffsetX = 0f;
					this._spinnerTargetOffsetY = 0f;
					this._returnToCenter = true;
				}
			}
			this._spinnerOffsetX += (this._spinnerTargetOffsetX - this._spinnerOffsetX) * 0.06f;
			this._spinnerOffsetY += (this._spinnerTargetOffsetY - this._spinnerOffsetY) * 0.06f;
		}

		// Token: 0x0600106F RID: 4207 RVA: 0x0000B232 File Offset: 0x0000B232
		private void SplashScreen_FormClosing(object sender, FormClosingEventArgs e)
		{
			this._isClosing = true;
			if (this._animationTimer != null)
			{
				this._animationTimer.Stop();
			}
			if (this._progressTimer != null)
			{
				this._progressTimer.Stop();
			}
		}

		// Token: 0x06001070 RID: 4208 RVA: 0x00076B44 File Offset: 0x00076B44
		private void DrawDotSpinner(Graphics g, int w, int h)
		{
			float num = (float)w / 2f + this._spinnerOffsetX;
			float num2 = (float)h / 2f + this._spinnerOffsetY;
			float num3 = 110f;
			float num4 = 22.5f;
			float spinnerAngle = this._spinnerAngle;
			for (int i = 0; i < 16; i = checked(i + 1))
			{
				float num5 = ((float)i * num4 + spinnerAngle) * 3.1415927f / 180f;
				float num6 = num + (float)((double)num3 * Math.Cos((double)num5));
				float num7 = num2 + (float)((double)num3 * Math.Sin((double)num5));
				float num8 = (float)((Math.Sin((double)this._spinnerPulse * 2.0 + (double)i * 0.5) + 1.0) / 2.0);
				float num9 = 3f + num8 * 10f;
				int num10 = checked(40 + (int)(unchecked(215f * num8)));
				Color color = Color.FromArgb(Math.Min(255, num10), 0, 255, 255);
				float num11 = num9 * 3f;
				Color centerColor = Color.FromArgb(Math.Max(0, Math.Min(255, num10 / 3)), 0, 255, 255);
				using (GraphicsPath graphicsPath = new GraphicsPath())
				{
					graphicsPath.AddEllipse(num6 - num11 / 2f, num7 - num11 / 2f, num11, num11);
					using (PathGradientBrush pathGradientBrush = new PathGradientBrush(graphicsPath))
					{
						pathGradientBrush.CenterColor = centerColor;
						pathGradientBrush.SurroundColors = new Color[]
						{
							Color.Black
						};
						g.FillPath(pathGradientBrush, graphicsPath);
					}
				}
				using (SolidBrush solidBrush = new SolidBrush(color))
				{
					g.FillEllipse(solidBrush, num6 - num9 / 2f, num7 - num9 / 2f, num9, num9);
				}
			}
		}

		// Token: 0x06001071 RID: 4209 RVA: 0x00076D54 File Offset: 0x00076D54
		private void DrawLogoText(Graphics g, int w, int h)
		{
			float num = (float)w / 2f + this._spinnerOffsetX;
			float num2 = (float)h / 2f + this._spinnerOffsetY;
			float num3 = (float)((Math.Sin((double)this._spinnerPulse) + 1.0) / 2.0);
			int num4 = checked(150 + (int)(unchecked(105.0 * (double)num3)));
			Color color = Color.FromArgb(0, 255, 255);
			Color color2 = Color.FromArgb(255, 140, 0);
			SizeF sizeF = g.MeasureString("depploy", this._fontDepploy);
			RectangleF layoutRectangle = new RectangleF(num - sizeF.Width / 2f, num2 - sizeF.Height, sizeF.Width, sizeF.Height);
			checked
			{
				for (int i = 3; i >= 1; i--)
				{
					using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(Math.Max(0, num4 / (i * 2)), color)))
					{
						unchecked
						{
							g.DrawString("depploy", this._fontDepploy, solidBrush, new RectangleF(layoutRectangle.X - (float)i, layoutRectangle.Y, layoutRectangle.Width, layoutRectangle.Height), this._loadingFormat);
							g.DrawString("depploy", this._fontDepploy, solidBrush, new RectangleF(layoutRectangle.X + (float)i, layoutRectangle.Y, layoutRectangle.Width, layoutRectangle.Height), this._loadingFormat);
							g.DrawString("depploy", this._fontDepploy, solidBrush, new RectangleF(layoutRectangle.X, layoutRectangle.Y - (float)i, layoutRectangle.Width, layoutRectangle.Height), this._loadingFormat);
							g.DrawString("depploy", this._fontDepploy, solidBrush, new RectangleF(layoutRectangle.X, layoutRectangle.Y + (float)i, layoutRectangle.Width, layoutRectangle.Height), this._loadingFormat);
						}
					}
				}
				using (SolidBrush solidBrush2 = new SolidBrush(color))
				{
					g.DrawString("depploy", this._fontDepploy, solidBrush2, layoutRectangle, this._loadingFormat);
				}
				SizeF sizeF2 = g.MeasureString("map tuning", this._fontMapTuning);
				RectangleF layoutRectangle2 = new RectangleF(unchecked(num - sizeF2.Width / 2f), num2, sizeF2.Width, sizeF2.Height);
				for (int j = 3; j >= 1; j--)
				{
					using (SolidBrush solidBrush3 = new SolidBrush(Color.FromArgb(Math.Max(0, num4 / (j * 2)), color2)))
					{
						unchecked
						{
							g.DrawString("map tuning", this._fontMapTuning, solidBrush3, new RectangleF(layoutRectangle2.X - (float)j, layoutRectangle2.Y, layoutRectangle2.Width, layoutRectangle2.Height), this._loadingFormat);
							g.DrawString("map tuning", this._fontMapTuning, solidBrush3, new RectangleF(layoutRectangle2.X + (float)j, layoutRectangle2.Y, layoutRectangle2.Width, layoutRectangle2.Height), this._loadingFormat);
							g.DrawString("map tuning", this._fontMapTuning, solidBrush3, new RectangleF(layoutRectangle2.X, layoutRectangle2.Y - (float)j, layoutRectangle2.Width, layoutRectangle2.Height), this._loadingFormat);
							g.DrawString("map tuning", this._fontMapTuning, solidBrush3, new RectangleF(layoutRectangle2.X, layoutRectangle2.Y + (float)j, layoutRectangle2.Width, layoutRectangle2.Height), this._loadingFormat);
						}
					}
				}
				using (SolidBrush solidBrush4 = new SolidBrush(color2))
				{
					g.DrawString("map tuning", this._fontMapTuning, solidBrush4, layoutRectangle2, this._loadingFormat);
				}
			}
		}

		// Token: 0x040016F7 RID: 5879
		private float _progressPercent;

		// Token: 0x040016F8 RID: 5880
		private bool _hasReached100;

		// Token: 0x040016F9 RID: 5881
		private int _frameCounter;

		// Token: 0x040016FA RID: 5882
		private bool _isClosing;

		// Token: 0x040016FB RID: 5883
		private bool _isReady;

		// Token: 0x040016FC RID: 5884
		private readonly Random _particleRandom;

		// Token: 0x040016FD RID: 5885
		private Random _simRandom;

		// Token: 0x04001700 RID: 5888
		private Color[] _cyberpunkColors;

		// Token: 0x04001701 RID: 5889
		private float _spinnerAngle;

		// Token: 0x04001702 RID: 5890
		private float _spinnerPulse;

		// Token: 0x04001703 RID: 5891
		private readonly Random _spinnerRandom;

		// Token: 0x04001704 RID: 5892
		private PointF[] _spinnerTrailPoints;

		// Token: 0x04001705 RID: 5893
		private int _spinnerTrailIndex;

		// Token: 0x04001706 RID: 5894
		private const int SPINNER_TRAIL_LENGTH = 20;

		// Token: 0x04001708 RID: 5896
		private float _spinnerOffsetX;

		// Token: 0x04001709 RID: 5897
		private float _spinnerOffsetY;

		// Token: 0x0400170A RID: 5898
		private float _spinnerTargetOffsetX;

		// Token: 0x0400170B RID: 5899
		private float _spinnerTargetOffsetY;

		// Token: 0x0400170C RID: 5900
		private int _driftTimer;

		// Token: 0x0400170D RID: 5901
		private int _driftDuration;

		// Token: 0x0400170E RID: 5902
		private float _driftRange;

		// Token: 0x0400170F RID: 5903
		private bool _returnToCenter;
	}
}
