﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000783 RID: 1923
	public partial class UpdatePopupForm : global::System.Windows.Forms.Form
	{
		// Token: 0x06001282 RID: 4738 RVA: 0x0008B740 File Offset: 0x0008B740
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				this.UnwireAutoUpdateEvents();
				if (this._cts != null)
				{
					try
					{
						this._cts.Cancel();
					}
					catch
					{
					}
					try
					{
						this._cts.Dispose();
					}
					catch
					{
					}
					this._cts = null;
				}
			}
			base.Dispose(disposing);
		}

		// Token: 0x04001956 RID: 6486
		private global::System.Threading.CancellationTokenSource _cts;
	}
}
