﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200070F RID: 1807
	public enum PopupType
	{
		// Token: 0x040016DB RID: 5851
		Info,
		// Token: 0x040016DC RID: 5852
		Success,
		// Token: 0x040016DD RID: 5853
		Warning,
		// Token: 0x040016DE RID: 5854
		Error,
		// Token: 0x040016DF RID: 5855
		Loading
	}
}
