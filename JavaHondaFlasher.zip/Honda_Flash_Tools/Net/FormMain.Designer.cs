﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000002 RID: 2
	public partial class FormMain : global::System.Windows.Forms.Form
	{
		// Token: 0x06000022 RID: 34 RVA: 0x00002715 File Offset: 0x00002715
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000023 RID: 35 RVA: 0x00013538 File Offset: 0x00013538
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Honda_Flash_Tools.Net.FormMain));
			this.GbEcuInfo = new global::System.Windows.Forms.GroupBox();
			this.TxtFlashCount = new global::System.Windows.Forms.Label();
			this.TxtPartCode = new global::System.Windows.Forms.Label();
			this.TxtEcmId = new global::System.Windows.Forms.Label();
			this.TxtConnStat = new global::System.Windows.Forms.Label();
			this.LblFlashCount = new global::System.Windows.Forms.Label();
			this.LblPartCode = new global::System.Windows.Forms.Label();
			this.LblEcmId = new global::System.Windows.Forms.Label();
			this.LblConnection = new global::System.Windows.Forms.Label();
			this.LblChecksumOffset = new global::System.Windows.Forms.Label();
			this.LblStartOffset = new global::System.Windows.Forms.Label();
			this.TbChecksumOffset = new global::System.Windows.Forms.TextBox();
			this.TbStartOffset = new global::System.Windows.Forms.TextBox();
			this.TxtPb = new global::System.Windows.Forms.Label();
			this.PbProgress = new global::System.Windows.Forms.ProgressBar();
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.RtbLog = new global::System.Windows.Forms.RichTextBox();
			base.SuspendLayout();
			this.BackColor = global::System.Drawing.Color.FromArgb(9, 9, 11);
			base.ClientSize = new global::System.Drawing.Size(1360, 730);
			this.Text = "DIAGNOSTIC TOOL - REMAPPING MODE";
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = true;
			base.TopMost = false;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Name = "FormMain";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			base.ShowInTaskbar = true;
			base.Padding = new global::System.Windows.Forms.Padding(30);
			this.DoubleBuffered = true;
			base.SetStyle(global::System.Windows.Forms.ControlStyles.UserPaint | global::System.Windows.Forms.ControlStyles.AllPaintingInWmPaint | global::System.Windows.Forms.ControlStyles.OptimizedDoubleBuffer, true);
			global::System.Drawing.Color color = global::System.Drawing.Color.FromArgb(17, 17, 20);
			global::System.Drawing.Color bgSurface2 = global::System.Drawing.Color.FromArgb(24, 24, 27);
			global::System.Drawing.Color color2 = global::System.Drawing.Color.FromArgb(13, 13, 16);
			global::System.Drawing.Color bgHover = global::System.Drawing.Color.FromArgb(0, 50, 55);
			global::System.Drawing.Color color3 = global::System.Drawing.Color.FromArgb(0, 255, 255);
			global::System.Drawing.Color aquaSoft = global::System.Drawing.Color.FromArgb(64, 224, 208);
			global::System.Drawing.Color color4 = global::System.Drawing.Color.FromArgb(0, 180, 180);
			global::System.Drawing.Color aquaDark = global::System.Drawing.Color.FromArgb(0, 140, 140);
			global::System.Drawing.Color hoverBackColor = global::System.Drawing.Color.FromArgb(0, 220, 220);
			global::System.Drawing.Color hoverBackColor2 = global::System.Drawing.Color.FromArgb(239, 68, 68);
			global::System.Windows.Forms.Panel panel = new global::System.Windows.Forms.Panel();
			panel.Name = "CustomTitleBar";
			panel.BackColor = color;
			panel.Location = new global::System.Drawing.Point(60, 60);
			panel.Size = new global::System.Drawing.Size(1240, 60);
			panel.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			base.Controls.Add(panel);
			global::System.Windows.Forms.PictureBox pictureBox = new global::System.Windows.Forms.PictureBox();
			pictureBox.Name = "pictureBox1";
			pictureBox.BackColor = global::System.Drawing.Color.Transparent;
			pictureBox.Location = new global::System.Drawing.Point(20, 0);
			pictureBox.Size = new global::System.Drawing.Size(182, 60);
			pictureBox.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			pictureBox.TabStop = false;
			pictureBox.Cursor = global::System.Windows.Forms.Cursors.Default;
			try
			{
				if (base.Icon != null)
				{
					pictureBox.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
				}
			}
			catch
			{
				pictureBox.Image = null;
			}
			panel.Controls.Add(pictureBox);
			pictureBox.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.TitleBar_MouseDown);
			global::System.Windows.Forms.Label label = new global::System.Windows.Forms.Label();
			label.Text = "DEPPLOY MAP TUNING\nProfessional Diagnostic-Remapping Suite";
			label.Font = new global::System.Drawing.Font("Segoe UI", 12f, global::System.Drawing.FontStyle.Bold);
			label.ForeColor = color3;
			label.BackColor = global::System.Drawing.Color.Transparent;
			label.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			label.Location = new global::System.Drawing.Point(234, 0);
			label.Size = new global::System.Drawing.Size(500, 48);
			panel.Controls.Add(label);
			global::System.Windows.Forms.Label label2 = new global::System.Windows.Forms.Label();
			label2.Text = "  K-LINE  ";
			label2.Font = new global::System.Drawing.Font("Segoe UI", 7.5f, global::System.Drawing.FontStyle.Bold);
			label2.ForeColor = color3;
			label2.BackColor = global::System.Drawing.Color.FromArgb(0, 40, 45);
			label2.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			label2.Location = new global::System.Drawing.Point(220, 14);
			label2.Size = new global::System.Drawing.Size(60, 20);
			panel.Controls.Add(label2);
			global::Honda_Flash_Tools.Net.AquaSpinner aquaSpinner = new global::Honda_Flash_Tools.Net.AquaSpinner();
			aquaSpinner.Name = "TitleSpinner";
			aquaSpinner.Size = new global::System.Drawing.Size(16, 16);
			checked
			{
				aquaSpinner.Location = new global::System.Drawing.Point(panel.Width - 130, 14);
				aquaSpinner.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
				aquaSpinner.SpinnerColor = color3;
				aquaSpinner.DotCount = 8;
				aquaSpinner.BackColor = global::System.Drawing.Color.Transparent;
				aquaSpinner.Enabled = true;
				panel.Controls.Add(aquaSpinner);
				aquaSpinner.BringToFront();
				global::System.Windows.Forms.Label label3 = new global::System.Windows.Forms.Label();
				label3.Name = "LblSpinnerStat";
				label3.Text = "READY";
				label3.Font = new global::System.Drawing.Font("Segoe UI", 7f, global::System.Drawing.FontStyle.Bold);
				label3.ForeColor = aquaSoft;
				label3.BackColor = global::System.Drawing.Color.Transparent;
				label3.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
				label3.Location = new global::System.Drawing.Point(panel.Width - 240, 14);
				label3.Size = new global::System.Drawing.Size(105, 16);
				label3.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
				panel.Controls.Add(label3);
				global::Honda_Flash_Tools.Net.RoundedButton btnMinimize = new global::Honda_Flash_Tools.Net.RoundedButton();
				btnMinimize.Name = "btnMinimize";
				btnMinimize.Text = "—";
				btnMinimize.Font = new global::System.Drawing.Font("Segoe UI", 12f, global::System.Drawing.FontStyle.Bold);
				btnMinimize.ForeColor = aquaSoft;
				btnMinimize.BackColor = global::System.Drawing.Color.Transparent;
				btnMinimize.CornerRadius = 6;
				btnMinimize.BorderColor = global::System.Drawing.Color.Transparent;
				btnMinimize.BorderWidth = 0f;
				btnMinimize.HoverBackColor = bgHover;
				btnMinimize.Cursor = global::System.Windows.Forms.Cursors.Hand;
				btnMinimize.Size = new global::System.Drawing.Size(36, 32);
				btnMinimize.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
				btnMinimize.Location = new global::System.Drawing.Point(panel.Width - 90, 8);
				btnMinimize.Click += delegate(object sender, global::System.EventArgs e)
				{
					if (this.IsDisposed || this.WindowState == global::System.Windows.Forms.FormWindowState.Minimized)
					{
						return;
					}
					this.WindowState = global::System.Windows.Forms.FormWindowState.Minimized;
				};
				panel.Controls.Add(btnMinimize);
				global::Honda_Flash_Tools.Net.RoundedButton btnClose = new global::Honda_Flash_Tools.Net.RoundedButton();
				btnClose.Name = "btnClose";
				btnClose.Text = "❌";
				btnClose.Font = new global::System.Drawing.Font("Segoe UI", 10f, global::System.Drawing.FontStyle.Bold);
				btnClose.ForeColor = aquaSoft;
				btnClose.BackColor = global::System.Drawing.Color.Transparent;
				btnClose.CornerRadius = 6;
				btnClose.BorderColor = global::System.Drawing.Color.Transparent;
				btnClose.BorderWidth = 0f;
				btnClose.HoverBackColor = hoverBackColor2;
				btnClose.Cursor = global::System.Windows.Forms.Cursors.Hand;
				btnClose.Size = new global::System.Drawing.Size(36, 32);
				btnClose.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
				btnClose.Location = new global::System.Drawing.Point(panel.Width - 46, 8);
				btnClose.Click += delegate(object sender, global::System.EventArgs e)
				{
					this.Close();
				};
				panel.Controls.Add(btnClose);
				panel.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.TitleBar_MouseDown);
				label.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.TitleBar_MouseDown);
				global::Honda_Flash_Tools.Net.RoundedPanel sidebar = new global::Honda_Flash_Tools.Net.RoundedPanel();
				sidebar.Name = "MenuSidebar";
				sidebar.CornerRadius = 12;
				sidebar.BorderColor = aquaDark;
				sidebar.BorderWidth = 1f;
				sidebar.InnerBackColor = color;
				sidebar.Location = new global::System.Drawing.Point(60, 135);
				sidebar.Size = new global::System.Drawing.Size(220, 560);
				sidebar.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
				sidebar.Padding = new global::System.Windows.Forms.Padding(8);
				base.Controls.Add(sidebar);
				global::System.Windows.Forms.Label label4 = new global::System.Windows.Forms.Label();
				label4.Text = "MENU";
				label4.Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Bold);
				label4.ForeColor = color3;
				label4.BackColor = global::System.Drawing.Color.Transparent;
				label4.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
				label4.Location = new global::System.Drawing.Point(14, 12);
				label4.Size = new global::System.Drawing.Size(192, 20);
				sidebar.Controls.Add(label4);
				global::System.Windows.Forms.Label label5 = new global::System.Windows.Forms.Label();
				label5.Text = "DATA LIVE";
				label5.Font = new global::System.Drawing.Font("Segoe UI", 7.5f, global::System.Drawing.FontStyle.Bold);
				label5.ForeColor = color4;
				label5.BackColor = global::System.Drawing.Color.Transparent;
				label5.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
				label5.Location = new global::System.Drawing.Point(14, 44);
				label5.Size = new global::System.Drawing.Size(192, 16);
				sidebar.Controls.Add(label5);
				global::System.Func<string, string, global::System.EventHandler, int, global::Honda_Flash_Tools.Net.RoundedButton> func = delegate(string name, string text, global::System.EventHandler handler, int yPos)
				{
					global::Honda_Flash_Tools.Net.RoundedButton roundedButton = new global::Honda_Flash_Tools.Net.RoundedButton();
					roundedButton.Name = name;
					roundedButton.Text = "  " + text;
					roundedButton.Font = new global::System.Drawing.Font("Segoe UI", 9f);
					roundedButton.ForeColor = aquaSoft;
					roundedButton.BackColor = global::System.Drawing.Color.Transparent;
					roundedButton.BorderColor = global::System.Drawing.Color.Transparent;
					roundedButton.BorderWidth = 0f;
					roundedButton.CornerRadius = 6;
					roundedButton.HoverBackColor = bgHover;
					roundedButton.Cursor = global::System.Windows.Forms.Cursors.Hand;
					roundedButton.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
					roundedButton.Location = new global::System.Drawing.Point(8, yPos);
					roundedButton.Size = new global::System.Drawing.Size(204, 30);
					roundedButton.Click += handler;
					sidebar.Controls.Add(roundedButton);
					return roundedButton;
				};
				func("MenuExit", "Dashboard", new global::System.EventHandler(this.MenuExit_Click), 64).ForeColor = color3;
				global::System.Windows.Forms.Label label6 = new global::System.Windows.Forms.Label();
				label6.Text = "TOOLS";
				label6.Font = new global::System.Drawing.Font("Segoe UI", 7.5f, global::System.Drawing.FontStyle.Bold);
				label6.ForeColor = color4;
				label6.BackColor = global::System.Drawing.Color.Transparent;
				label6.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
				label6.Location = new global::System.Drawing.Point(14, 105);
				label6.Size = new global::System.Drawing.Size(192, 16);
				sidebar.Controls.Add(label6);
				func("MenuUnlockXdf", "Unlock XDF", new global::System.EventHandler(this.UnlockXdfItem_Click), 126);
				func("MenuChecksumKZR", "Checksum KZR", new global::System.EventHandler(this.ChecksumKZR_Click), 160);
				func("MenuTunerPro", "Map Editor Pro", new global::System.EventHandler(this.TunerProItem_Click), 194);
				func("MenuKeyless", "Read ID Keyless", new global::System.EventHandler(this.ReadIdKeylessItem_Click), 228);
				func("MenuResetShindengen", "Reset Shindengen", new global::System.EventHandler(this.ResetShindengenItem_Click), 262);
				func("MenuResetKeihin", "Reset Keihin", new global::System.EventHandler(this.ResetKeihinItem_Click), 296);
				func("MenuLiveData", "Live Data", new global::System.EventHandler(this.LiveDataItem_Click), 330);
				func("MenuReadDTC", "Read DTC", new global::System.EventHandler(this.ReadDTCItem_Click), 364);
				global::System.Windows.Forms.Label label7 = new global::System.Windows.Forms.Label();
				label7.Text = "HELP";
				label7.Font = new global::System.Drawing.Font("Segoe UI", 7.5f, global::System.Drawing.FontStyle.Bold);
				label7.ForeColor = color4;
				label7.BackColor = global::System.Drawing.Color.Transparent;
				label7.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
				label7.Location = new global::System.Drawing.Point(14, 405);
				label7.Size = new global::System.Drawing.Size(192, 16);
				sidebar.Controls.Add(label7);
				func("MenuAbout", "About", new global::System.EventHandler(this.AboutItem_Click), 426);
				global::Honda_Flash_Tools.Net.RoundedPanel roundedPanel = new global::Honda_Flash_Tools.Net.RoundedPanel();
				roundedPanel.Name = "LogoCardSidebar";
				roundedPanel.CornerRadius = 8;
				roundedPanel.BorderColor = aquaDark;
				roundedPanel.BorderWidth = 1f;
				roundedPanel.InnerBackColor = color2;
				roundedPanel.Location = new global::System.Drawing.Point(8, 462);
				roundedPanel.Size = new global::System.Drawing.Size(204, 98);
				roundedPanel.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
				sidebar.Controls.Add(roundedPanel);
				global::System.Windows.Forms.PictureBox pictureBox2 = new global::System.Windows.Forms.PictureBox();
				pictureBox2.Name = "pictureBoxSidebar";
				pictureBox2.BackColor = global::System.Drawing.Color.Transparent;
				pictureBox2.Location = new global::System.Drawing.Point(10, 4);
				pictureBox2.Size = new global::System.Drawing.Size(184, 62);
				pictureBox2.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.Zoom;
				pictureBox2.TabStop = false;
				pictureBox2.Cursor = global::System.Windows.Forms.Cursors.Default;
				try
				{
					pictureBox2.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
				}
				catch
				{
					pictureBox2.Image = null;
				}
				roundedPanel.Controls.Add(pictureBox2);
				global::System.Windows.Forms.Label label8 = new global::System.Windows.Forms.Label();
				label8.Text = "DEPPLOY MAP TUNING";
				label8.Font = new global::System.Drawing.Font("Tahoma", 8f, global::System.Drawing.FontStyle.Bold);
				label8.ForeColor = color3;
				label8.BackColor = global::System.Drawing.Color.Transparent;
				label8.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
				label8.Location = new global::System.Drawing.Point(4, 68);
				label8.Size = new global::System.Drawing.Size(196, 12);
				roundedPanel.Controls.Add(label8);
				global::System.Windows.Forms.Label label9 = new global::System.Windows.Forms.Label();
				label9.Text = "v1.0  •  K-LINE READY";
				label9.Font = new global::System.Drawing.Font("Segoe UI", 6.5f);
				label9.ForeColor = aquaSoft;
				label9.BackColor = global::System.Drawing.Color.Transparent;
				label9.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
				label9.Location = new global::System.Drawing.Point(4, 80);
				label9.Size = new global::System.Drawing.Size(196, 10);
				roundedPanel.Controls.Add(label9);
				roundedPanel.BringToFront();
				global::Honda_Flash_Tools.Net.RoundedPanel headerPanel = new global::Honda_Flash_Tools.Net.RoundedPanel();
				headerPanel.Name = "HeaderPanel";
				headerPanel.CornerRadius = 12;
				headerPanel.BorderColor = aquaDark;
				headerPanel.BorderWidth = 1f;
				headerPanel.InnerBackColor = color;
				headerPanel.Location = new global::System.Drawing.Point(290, 135);
				headerPanel.Size = new global::System.Drawing.Size(1010, 60);
				headerPanel.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
				base.Controls.Add(headerPanel);
				global::System.Windows.Forms.Label label10 = new global::System.Windows.Forms.Label();
				label10.Text = "Honda ECU Flash Tools";
				label10.Font = new global::System.Drawing.Font("TAHOMA", 16f, global::System.Drawing.FontStyle.Bold | global::System.Drawing.FontStyle.Italic);
				label10.ForeColor = color3;
				label10.BackColor = global::System.Drawing.Color.Transparent;
				label10.AutoSize = true;
				label10.Location = new global::System.Drawing.Point(20, 4);
				headerPanel.Controls.Add(label10);
				global::System.Windows.Forms.Label label11 = new global::System.Windows.Forms.Label();
				label11.Text = "Professional ECU diagnostic & remapping suite";
				label11.Font = new global::System.Drawing.Font("Segoe UI", 8.5f);
				label11.ForeColor = aquaSoft;
				label11.BackColor = global::System.Drawing.Color.Transparent;
				label11.AutoSize = true;
				label11.Location = new global::System.Drawing.Point(22, 34);
				headerPanel.Controls.Add(label11);
				global::Honda_Flash_Tools.Net.RoundedPanel leftPanel = new global::Honda_Flash_Tools.Net.RoundedPanel();
				leftPanel.Name = "LeftPanel";
				leftPanel.CornerRadius = 12;
				leftPanel.BorderColor = aquaDark;
				leftPanel.BorderWidth = 1f;
				leftPanel.InnerBackColor = color;
				leftPanel.Location = new global::System.Drawing.Point(290, 210);
				leftPanel.Size = new global::System.Drawing.Size(320, 340);
				leftPanel.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
				base.Controls.Add(leftPanel);
				global::System.Windows.Forms.Label label12 = new global::System.Windows.Forms.Label();
				label12.Text = "TOOLS";
				label12.Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Bold);
				label12.ForeColor = color3;
				label12.BackColor = global::System.Drawing.Color.Transparent;
				label12.AutoSize = true;
				label12.Location = new global::System.Drawing.Point(20, 16);
				leftPanel.Controls.Add(label12);
				global::System.Windows.Forms.Label label13 = new global::System.Windows.Forms.Label();
				label13.Text = "Quick actions";
				label13.Font = new global::System.Drawing.Font("Segoe UI Semibold", 12f, global::System.Drawing.FontStyle.Bold);
				label13.ForeColor = aquaSoft;
				label13.BackColor = global::System.Drawing.Color.Transparent;
				label13.AutoSize = true;
				label13.Location = new global::System.Drawing.Point(20, 34);
				leftPanel.Controls.Add(label13);
				global::System.Func<string, string, int, int, global::System.EventHandler, global::Honda_Flash_Tools.Net.RoundedButton> func2 = delegate(string text, string name, int yPos, int height, global::System.EventHandler handler)
				{
					global::Honda_Flash_Tools.Net.RoundedButton roundedButton = new global::Honda_Flash_Tools.Net.RoundedButton();
					roundedButton.Name = name;
					roundedButton.Text = text;
					roundedButton.Font = new global::System.Drawing.Font("Segoe UI", 9.5f);
					roundedButton.Location = new global::System.Drawing.Point(20, yPos);
					roundedButton.Size = new global::System.Drawing.Size(280, height);
					roundedButton.BackColor = bgSurface2;
					roundedButton.ForeColor = aquaSoft;
					roundedButton.BorderColor = aquaDark;
					roundedButton.BorderWidth = 1f;
					roundedButton.CornerRadius = 8;
					roundedButton.HoverBackColor = bgHover;
					roundedButton.Cursor = global::System.Windows.Forms.Cursors.Hand;
					roundedButton.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
					roundedButton.Click += handler;
					leftPanel.Controls.Add(roundedButton);
					return roundedButton;
				};
				this.button = func2("  HEX Editor", "BtnRestore", 62, 36, new global::System.EventHandler(this.RestoreBackup_Click));
				this.button2 = func2("  Data Graph Live", "BtnFactoryReset", 104, 36, new global::System.EventHandler(this.FactoryReset_Click));
				this.button3 = func2("  Auto Update", "BtnRepair", 146, 36, new global::System.EventHandler(this.RepairInstallation_Click));
				this.button4 = new global::Honda_Flash_Tools.Net.RoundedButton();
				this.button4.Text = "▶️  RUN DIAGNOSTIC";
				this.button4.Font = new global::System.Drawing.Font("Segoe UI Semibold", 10f, global::System.Drawing.FontStyle.Bold);
				this.button4.Location = new global::System.Drawing.Point(20, 185);
				this.button4.Size = new global::System.Drawing.Size(280, 40);
				this.button4.BackColor = aquaDark;
				this.button4.ForeColor = color3;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.button4).BorderColor = color3;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.button4).BorderWidth = 1f;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.button4).CornerRadius = 8;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.button4).HoverBackColor = hoverBackColor;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.button4).Cursor = global::System.Windows.Forms.Cursors.Hand;
				this.button4.Click += new global::System.EventHandler(this.RunDiagnosticTests_Click);
				leftPanel.Controls.Add(this.button4);
				global::System.Windows.Forms.Panel panel2 = new global::System.Windows.Forms.Panel();
				panel2.BackColor = aquaDark;
				panel2.Location = new global::System.Drawing.Point(20, 235);
				panel2.Size = new global::System.Drawing.Size(280, 1);
				leftPanel.Controls.Add(panel2);
				this.button1 = new global::Honda_Flash_Tools.Net.RoundedButton();
				this.button1.Text = "\ud83d\udcc1  File BIN";
				this.button1.Font = new global::System.Drawing.Font("Segoe UI", 9.5f);
				this.button1.Location = new global::System.Drawing.Point(20, 240);
				this.button1.Size = new global::System.Drawing.Size(135, 36);
				this.button1.BackColor = bgSurface2;
				this.button1.ForeColor = color3;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.button1).BorderColor = aquaDark;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.button1).BorderWidth = 1f;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.button1).CornerRadius = 8;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.button1).HoverBackColor = bgHover;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.button1).Cursor = global::System.Windows.Forms.Cursors.Hand;
				leftPanel.Controls.Add(this.button1);
				this.BtnWrite = new global::Honda_Flash_Tools.Net.RoundedButton();
				this.BtnWrite.Text = "\ud83d\udcdd  WRITE";
				this.BtnWrite.Font = new global::System.Drawing.Font("Segoe UI Semibold", 9.5f, global::System.Drawing.FontStyle.Bold);
				this.BtnWrite.Location = new global::System.Drawing.Point(this.button1.Right + 10, 240);
				this.BtnWrite.Size = new global::System.Drawing.Size(135, 36);
				this.BtnWrite.BackColor = color3;
				this.BtnWrite.ForeColor = global::System.Drawing.Color.Black;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.BtnWrite).BorderColor = color3;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.BtnWrite).BorderWidth = 0f;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.BtnWrite).CornerRadius = 8;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.BtnWrite).HoverBackColor = hoverBackColor;
				((global::Honda_Flash_Tools.Net.RoundedButton)this.BtnWrite).Cursor = global::System.Windows.Forms.Cursors.Hand;
				this.BtnWrite.Enabled = true;
				leftPanel.Controls.Add(this.BtnWrite);
				global::Honda_Flash_Tools.Net.RoundedPanel roundedPanel2 = new global::Honda_Flash_Tools.Net.RoundedPanel();
				roundedPanel2.Name = "TbFileWrapper";
				roundedPanel2.CornerRadius = 6;
				roundedPanel2.BorderColor = aquaDark;
				roundedPanel2.BorderWidth = 1f;
				roundedPanel2.InnerBackColor = color2;
				roundedPanel2.Location = new global::System.Drawing.Point(20, 280);
				roundedPanel2.Size = new global::System.Drawing.Size(280, 28);
				roundedPanel2.Padding = new global::System.Windows.Forms.Padding(8, 4, 8, 4);
				leftPanel.Controls.Add(roundedPanel2);
				this.TbFileName = new global::System.Windows.Forms.TextBox();
				this.TbFileName.Font = new global::System.Drawing.Font("Consolas", 8.5f);
				this.TbFileName.Location = new global::System.Drawing.Point(8, 4);
				this.TbFileName.Size = new global::System.Drawing.Size(roundedPanel2.Width - 16, 20);
				this.TbFileName.BackColor = color2;
				this.TbFileName.ForeColor = aquaSoft;
				this.TbFileName.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
				this.TbFileName.ReadOnly = true;
				this.TbFileName.Text = "No file selected...";
				this.TbFileName.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
				roundedPanel2.Controls.Add(this.TbFileName);
				this.CbFastWrite = new global::Honda_Flash_Tools.Net.RoundedCheckBox();
				this.CbFastWrite.Text = "Fast Write Mode";
				this.CbFastWrite.Font = new global::System.Drawing.Font("Segoe UI", 9f);
				this.CbFastWrite.Location = new global::System.Drawing.Point(20, 315);
				this.CbFastWrite.Size = new global::System.Drawing.Size(120, 20);
				this.CbFastWrite.ForeColor = aquaSoft;
				this.CbFastWrite.BackColor = color2;
				this.CbFastWrite.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
				leftPanel.Controls.Add(this.CbFastWrite);
				global::Honda_Flash_Tools.Net.RoundedPanel roundedPanel3 = new global::Honda_Flash_Tools.Net.RoundedPanel();
				roundedPanel3.Name = "CenterPanel";
				roundedPanel3.CornerRadius = 12;
				roundedPanel3.BorderColor = aquaDark;
				roundedPanel3.BorderWidth = 1f;
				roundedPanel3.InnerBackColor = color;
				roundedPanel3.Location = new global::System.Drawing.Point(625, 210);
				roundedPanel3.Size = new global::System.Drawing.Size(320, 340);
				roundedPanel3.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom);
				base.Controls.Add(roundedPanel3);
				global::System.Windows.Forms.Label label14 = new global::System.Windows.Forms.Label();
				label14.Text = "ECU CONTROL";
				label14.Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Bold);
				label14.ForeColor = color3;
				label14.BackColor = global::System.Drawing.Color.Transparent;
				label14.AutoSize = true;
				label14.Location = new global::System.Drawing.Point(20, 16);
				roundedPanel3.Controls.Add(label14);
				global::System.Windows.Forms.Label label15 = new global::System.Windows.Forms.Label();
				label15.Text = "Flash configuration";
				label15.Font = new global::System.Drawing.Font("Segoe UI Semibold", 12f, global::System.Drawing.FontStyle.Bold);
				label15.ForeColor = aquaSoft;
				label15.BackColor = global::System.Drawing.Color.Transparent;
				label15.AutoSize = true;
				label15.Location = new global::System.Drawing.Point(20, 34);
				roundedPanel3.Controls.Add(label15);
				global::Honda_Flash_Tools.Net.RoundedGroupBox grpEcu = new global::Honda_Flash_Tools.Net.RoundedGroupBox();
				grpEcu.Text = " ECU INFORMATION ";
				grpEcu.Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Bold);
				grpEcu.ForeColor = color3;
				grpEcu.CornerRadius = 10;
				grpEcu.BorderColor = aquaDark;
				grpEcu.BorderWidth = 1f;
				grpEcu.InnerBackColor = bgSurface2;
				grpEcu.Location = new global::System.Drawing.Point(20, 62);
				grpEcu.Size = new global::System.Drawing.Size(280, 150);
				roundedPanel3.Controls.Add(grpEcu);
				global::System.Func<string, string, global::System.Drawing.Color, int, global::System.Windows.Forms.Label> func3 = delegate(string labelText, string valueText, global::System.Drawing.Color valueColor, int yPos)
				{
					global::System.Windows.Forms.Label label18 = new global::System.Windows.Forms.Label();
					label18.Text = labelText;
					label18.Font = new global::System.Drawing.Font("Segoe UI", 9f);
					label18.ForeColor = aquaSoft;
					label18.BackColor = global::System.Drawing.Color.Transparent;
					label18.AutoSize = true;
					label18.Location = new global::System.Drawing.Point(18, yPos);
					grpEcu.Controls.Add(label18);
					global::System.Windows.Forms.Label label19 = new global::System.Windows.Forms.Label();
					label19.Text = valueText;
					label19.Font = new global::System.Drawing.Font("Consolas", 9f, global::System.Drawing.FontStyle.Bold);
					label19.ForeColor = valueColor;
					label19.BackColor = global::System.Drawing.Color.Transparent;
					label19.AutoSize = true;
					label19.Location = new global::System.Drawing.Point(135, yPos);
					grpEcu.Controls.Add(label19);
					return label19;
				};
				this.TxtEcmId = func3("ECM ID", "N/A", color3, 30);
				this.TxtPartCode = func3("PART CODE", "N/A", color3, 58);
				this.TxtFlashCount = func3("FLASH COUNT", "0", color3, 86);
				this.TxtConnStat = func3("STATUS", "Disconnected", color4, 114);
				global::Honda_Flash_Tools.Net.RoundedGroupBox roundedGroupBox = new global::Honda_Flash_Tools.Net.RoundedGroupBox();
				roundedGroupBox.Text = " FLASH PARAMETERS ";
				roundedGroupBox.Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Bold);
				roundedGroupBox.ForeColor = color3;
				roundedGroupBox.CornerRadius = 10;
				roundedGroupBox.BorderColor = aquaDark;
				roundedGroupBox.BorderWidth = 1f;
				roundedGroupBox.InnerBackColor = bgSurface2;
				roundedGroupBox.Location = new global::System.Drawing.Point(20, 220);
				roundedGroupBox.Size = new global::System.Drawing.Size(280, 95);
				roundedPanel3.Controls.Add(roundedGroupBox);
				this.LblStartOffset.Text = "Start Offset";
				this.LblStartOffset.Font = new global::System.Drawing.Font("Segoe UI", 8.5f);
				this.LblStartOffset.ForeColor = aquaSoft;
				this.LblStartOffset.BackColor = global::System.Drawing.Color.Transparent;
				this.LblStartOffset.AutoSize = true;
				this.LblStartOffset.Location = new global::System.Drawing.Point(14, 30);
				roundedGroupBox.Controls.Add(this.LblStartOffset);
				this.TbStartOffset.Location = new global::System.Drawing.Point(14, 50);
				this.TbStartOffset.Size = new global::System.Drawing.Size(120, 24);
				this.TbStartOffset.BackColor = color2;
				this.TbStartOffset.ForeColor = color3;
				this.TbStartOffset.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
				this.TbStartOffset.Font = new global::System.Drawing.Font("Consolas", 9f, global::System.Drawing.FontStyle.Bold);
				this.TbStartOffset.ReadOnly = true;
				this.TbStartOffset.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
				roundedGroupBox.Controls.Add(this.TbStartOffset);
				this.LblChecksumOffset.Text = "Checksum";
				this.LblChecksumOffset.Font = new global::System.Drawing.Font("Segoe UI", 8.5f);
				this.LblChecksumOffset.ForeColor = aquaSoft;
				this.LblChecksumOffset.BackColor = global::System.Drawing.Color.Transparent;
				this.LblChecksumOffset.AutoSize = true;
				this.LblChecksumOffset.Location = new global::System.Drawing.Point(150, 30);
				roundedGroupBox.Controls.Add(this.LblChecksumOffset);
				this.TbChecksumOffset.Location = new global::System.Drawing.Point(150, 50);
				this.TbChecksumOffset.Size = new global::System.Drawing.Size(120, 24);
				this.TbChecksumOffset.BackColor = color2;
				this.TbChecksumOffset.ForeColor = color3;
				this.TbChecksumOffset.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
				this.TbChecksumOffset.Font = new global::System.Drawing.Font("Consolas", 9f, global::System.Drawing.FontStyle.Bold);
				this.TbChecksumOffset.ReadOnly = true;
				this.TbChecksumOffset.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
				roundedGroupBox.Controls.Add(this.TbChecksumOffset);
				global::Honda_Flash_Tools.Net.RoundedPanel roundedPanel4 = new global::Honda_Flash_Tools.Net.RoundedPanel();
				roundedPanel4.Name = "RightPanel";
				roundedPanel4.CornerRadius = 12;
				roundedPanel4.BorderColor = aquaDark;
				roundedPanel4.BorderWidth = 1f;
				roundedPanel4.InnerBackColor = color;
				roundedPanel4.Location = new global::System.Drawing.Point(960, 210);
				roundedPanel4.Size = new global::System.Drawing.Size(340, 340);
				roundedPanel4.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Right);
				base.Controls.Add(roundedPanel4);
				global::System.Windows.Forms.Label label16 = new global::System.Windows.Forms.Label();
				label16.Text = "ACTIVITY LOG";
				label16.Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Bold);
				label16.ForeColor = color3;
				label16.BackColor = global::System.Drawing.Color.Transparent;
				label16.AutoSize = true;
				label16.Location = new global::System.Drawing.Point(20, 16);
				roundedPanel4.Controls.Add(label16);
				global::System.Windows.Forms.Label label17 = new global::System.Windows.Forms.Label();
				label17.Text = "Real-time output";
				label17.Font = new global::System.Drawing.Font("Segoe UI Semibold", 12f, global::System.Drawing.FontStyle.Bold);
				label17.ForeColor = aquaSoft;
				label17.BackColor = global::System.Drawing.Color.Transparent;
				label17.AutoSize = true;
				label17.Location = new global::System.Drawing.Point(20, 34);
				roundedPanel4.Controls.Add(label17);
				global::Honda_Flash_Tools.Net.RoundedPanel roundedPanel5 = new global::Honda_Flash_Tools.Net.RoundedPanel();
				roundedPanel5.Name = "LogWrapper";
				roundedPanel5.CornerRadius = 8;
				roundedPanel5.BorderColor = aquaDark;
				roundedPanel5.BorderWidth = 1f;
				roundedPanel5.InnerBackColor = color2;
				roundedPanel5.Location = new global::System.Drawing.Point(20, 62);
				roundedPanel5.Size = new global::System.Drawing.Size(300, 258);
				roundedPanel5.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
				roundedPanel5.Padding = new global::System.Windows.Forms.Padding(10);
				roundedPanel4.Controls.Add(roundedPanel5);
				this.RtbLog.Location = new global::System.Drawing.Point(10, 10);
				this.RtbLog.Size = new global::System.Drawing.Size(roundedPanel5.Width - 20, roundedPanel5.Height - 20);
				this.RtbLog.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
				this.RtbLog.BackColor = color2;
				this.RtbLog.ForeColor = aquaSoft;
				this.RtbLog.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
				this.RtbLog.Font = new global::System.Drawing.Font("Consolas", 8.5f);
				this.RtbLog.ReadOnly = true;
				this.RtbLog.Multiline = true;
				this.RtbLog.ScrollBars = global::System.Windows.Forms.RichTextBoxScrollBars.Vertical;
				this.RtbLog.Text = "> System ready...\n> Waiting for connection...\n";
				roundedPanel5.Controls.Add(this.RtbLog);
				global::Honda_Flash_Tools.Net.RoundedPanel progressPanel = new global::Honda_Flash_Tools.Net.RoundedPanel();
				progressPanel.Name = "ProgressPanel";
				progressPanel.CornerRadius = 12;
				progressPanel.BorderColor = aquaDark;
				progressPanel.BorderWidth = 1f;
				progressPanel.InnerBackColor = color;
				progressPanel.Location = new global::System.Drawing.Point(290, 570);
				progressPanel.Size = new global::System.Drawing.Size(1010, 120);
				progressPanel.Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
				base.Controls.Add(progressPanel);
				global::System.Windows.Forms.Label lblProgressTitle = new global::System.Windows.Forms.Label();
				lblProgressTitle.Text = "PROGRESS DEPPLOY MAP TUNING";
				lblProgressTitle.Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Bold);
				lblProgressTitle.ForeColor = color3;
				lblProgressTitle.BackColor = global::System.Drawing.Color.Transparent;
				lblProgressTitle.AutoSize = true;
				lblProgressTitle.Location = new global::System.Drawing.Point(20, 14);
				progressPanel.Controls.Add(lblProgressTitle);
				this.PbProgress = new global::Honda_Flash_Tools.Net.AquaProgressBar();
				this.PbProgress.Location = new global::System.Drawing.Point(20, 38);
				this.PbProgress.Size = new global::System.Drawing.Size(970, 10);
				this.PbProgress.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
				this.PbProgress.BackColor = bgSurface2;
				this.PbProgress.Minimum = 0;
				this.PbProgress.Maximum = 10000;
				this.PbProgress.Value = 0;
				this.PbProgress.Step = 1;
				progressPanel.Controls.Add(this.PbProgress);
				this.TxtPb.Text = "Status: Ready";
				this.TxtPb.Font = new global::System.Drawing.Font("Consolas", 9f, global::System.Drawing.FontStyle.Bold);
				this.TxtPb.ForeColor = color3;
				this.TxtPb.BackColor = global::System.Drawing.Color.Transparent;
				this.TxtPb.Location = new global::System.Drawing.Point(20, 58);
				this.TxtPb.Size = new global::System.Drawing.Size(970, 20);
				this.TxtPb.Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
				this.TxtPb.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
				progressPanel.Controls.Add(this.TxtPb);
				global::Honda_Flash_Tools.Net.AquaSpinner aquaSpinner2 = new global::Honda_Flash_Tools.Net.AquaSpinner();
				aquaSpinner2.Name = "ProgressSpinner";
				aquaSpinner2.Size = new global::System.Drawing.Size(18, 18);
				aquaSpinner2.SpinnerColor = color3;
				aquaSpinner2.DotCount = 8;
				aquaSpinner2.BackColor = global::System.Drawing.Color.Transparent;
				aquaSpinner2.Enabled = true;
				aquaSpinner2.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left);
				aquaSpinner2.Location = new global::System.Drawing.Point(lblProgressTitle.Right + 10, lblProgressTitle.Top + global::System.Math.Max(0, (lblProgressTitle.Height - aquaSpinner2.Height) / 2));
				progressPanel.Controls.Add(aquaSpinner2);
				aquaSpinner2.BringToFront();
				this.GbEcuInfo.Visible = false;
				this.groupBox1.Visible = false;
				this.button1.Click += new global::System.EventHandler(this.button1_Click);
				this.BtnWrite.Click += new global::System.EventHandler(this.Write_Clicked);
				this.TbFileName.TextChanged += new global::System.EventHandler(this.FileName_Changed);
				this.CbFastWrite.CheckedChanged += new global::System.EventHandler(this.CbFastWrite_CheckedChanged);
				this.TbStartOffset.TextChanged += new global::System.EventHandler(this.StartOffset_Changed);
				this.TbChecksumOffset.TextChanged += new global::System.EventHandler(this.ChecksumOffset_Changed);
				this.PbProgress.Click += new global::System.EventHandler(this.PbProgress_Click);
				base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.MainForm_Closing);
				base.Load += new global::System.EventHandler(this.MainForm_Load);
				this.GbEcuInfo.Paint += new global::System.Windows.Forms.PaintEventHandler(this.GbEcuInfo_Paint);
				this.groupBox1.Paint += new global::System.Windows.Forms.PaintEventHandler(this.GroupBox1_Paint);
				base.Paint -= new global::System.Windows.Forms.PaintEventHandler(this.DrawNeonBorder);
				base.Paint += new global::System.Windows.Forms.PaintEventHandler(this.FormMain_Paint);
				base.Resize += delegate(object sender, global::System.EventArgs e)
				{
					if (panel != null && !panel.IsDisposed)
					{
						btnMinimize.Location = new global::System.Drawing.Point(panel.ClientSize.Width - 90, 8);
						btnClose.Location = new global::System.Drawing.Point(panel.ClientSize.Width - 46, 8);
						global::System.Windows.Forms.Control[] array4 = panel.Controls.Find("TitleSpinner", false);
						if (array4.Length != 0 && !array4[0].IsDisposed)
						{
							array4[0].Location = new global::System.Drawing.Point(panel.ClientSize.Width - 130, 14);
						}
						global::System.Windows.Forms.Control[] array5 = panel.Controls.Find("LblSpinnerStat", false);
						if (array5.Length != 0 && !array5[0].IsDisposed)
						{
							array5[0].Location = new global::System.Drawing.Point(panel.ClientSize.Width - 240, 14);
						}
					}
					if (sidebar != null && !sidebar.IsDisposed)
					{
						int val = 560;
						int val2 = this.ClientSize.Height - 135 - 30;
						sidebar.Height = global::System.Math.Max(val, val2);
					}
					if (headerPanel != null && !headerPanel.IsDisposed)
					{
						headerPanel.Width = global::System.Math.Max(650, this.ClientSize.Width - 350);
					}
					if (progressPanel != null && !progressPanel.IsDisposed)
					{
						progressPanel.Width = global::System.Math.Max(650, this.ClientSize.Width - 350);
						global::System.Windows.Forms.Control[] array6 = progressPanel.Controls.Find("ProgressSpinner", false);
						if (array6.Length != 0 && !array6[0].IsDisposed)
						{
							array6[0].Location = new global::System.Drawing.Point(lblProgressTitle.Right + 10, lblProgressTitle.Top + global::System.Math.Max(0, (lblProgressTitle.Height - array6[0].Height) / 2));
							array6[0].BringToFront();
						}
					}
					this.ApplyRoundedForm();
					this.Invalidate();
				};
				sidebar.BringToFront();
				headerPanel.BringToFront();
				leftPanel.BringToFront();
				roundedPanel3.BringToFront();
				roundedPanel4.BringToFront();
				progressPanel.BringToFront();
				panel.BringToFront();
				pictureBox.BringToFront();
				label.BringToFront();
				btnMinimize.BringToFront();
				btnClose.BringToFront();
				global::System.Windows.Forms.Control[] array = progressPanel.Controls.Find("ProgressSpinner", false);
				if (array.Length != 0 && !array[0].IsDisposed)
				{
					array[0].Location = new global::System.Drawing.Point(lblProgressTitle.Right + 10, lblProgressTitle.Top + global::System.Math.Max(0, lblProgressTitle.Height - array[0].Height - 2));
					array[0].BringToFront();
				}
				global::System.Windows.Forms.Control[] array2 = panel.Controls.Find("TitleSpinner", false);
				if (array2.Length != 0 && !array2[0].IsDisposed)
				{
					array2[0].BringToFront();
				}
				global::System.Windows.Forms.Control[] array3 = panel.Controls.Find("LblSpinnerStat", false);
				if (array3.Length != 0 && !array3[0].IsDisposed)
				{
					array3[0].BringToFront();
				}
				this.ApplyRoundedForm();
				this.GbEcuInfo.ResumeLayout(false);
				this.GbEcuInfo.PerformLayout();
				this.groupBox1.ResumeLayout(false);
				base.ResumeLayout(false);
				base.PerformLayout();
			}
		}

		// Token: 0x0400001F RID: 31
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000020 RID: 32
		private global::System.Windows.Forms.GroupBox GbEcuInfo;

		// Token: 0x04000021 RID: 33
		private global::System.Windows.Forms.Label LblFlashCount;

		// Token: 0x04000022 RID: 34
		private global::System.Windows.Forms.Label LblPartCode;

		// Token: 0x04000023 RID: 35
		private global::System.Windows.Forms.Label LblEcmId;

		// Token: 0x04000024 RID: 36
		private global::System.Windows.Forms.Label LblConnection;

		// Token: 0x04000025 RID: 37
		private global::System.Windows.Forms.Label LblChecksumOffset;

		// Token: 0x04000026 RID: 38
		private global::System.Windows.Forms.Label LblStartOffset;

		// Token: 0x04000027 RID: 39
		private global::System.Windows.Forms.TextBox TbChecksumOffset;

		// Token: 0x04000028 RID: 40
		private global::System.Windows.Forms.TextBox TbStartOffset;

		// Token: 0x04000029 RID: 41
		private global::System.Windows.Forms.Button BtnWrite;

		// Token: 0x0400002A RID: 42
		private global::System.Windows.Forms.ProgressBar PbProgress;

		// Token: 0x0400002B RID: 43
		private global::System.Windows.Forms.Label TxtPb;

		// Token: 0x0400002C RID: 44
		private global::System.Windows.Forms.Label TxtConnStat;

		// Token: 0x0400002D RID: 45
		private global::System.Windows.Forms.Label TxtFlashCount;

		// Token: 0x0400002E RID: 46
		private global::System.Windows.Forms.Label TxtPartCode;

		// Token: 0x0400002F RID: 47
		private global::System.Windows.Forms.Label TxtEcmId;

		// Token: 0x04000030 RID: 48
		private global::System.Windows.Forms.GroupBox groupBox1;

		// Token: 0x04000031 RID: 49
		private global::System.Windows.Forms.Label label2;

		// Token: 0x04000032 RID: 50
		private global::System.Windows.Forms.TextBox TbFileName;

		// Token: 0x04000033 RID: 51
		private global::System.Windows.Forms.CheckBox CbFastWrite;

		// Token: 0x04000034 RID: 52
		private global::System.Windows.Forms.Button button1;

		// Token: 0x0400003F RID: 63
		private global::System.Windows.Forms.RichTextBox RtbLog;

		// Token: 0x04000040 RID: 64
		private global::System.Windows.Forms.Button button;

		// Token: 0x04000041 RID: 65
		private global::System.Windows.Forms.Button button2;

		// Token: 0x04000042 RID: 66
		private global::System.Windows.Forms.Button button3;

		// Token: 0x04000043 RID: 67
		private global::System.Windows.Forms.Button button4;
	}
}
