﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000426 RID: 1062
	public class KeihinFlashReset
	{
		// Token: 0x06000CE9 RID: 3305 RVA: 0x0005FA44 File Offset: 0x0005FA44
		private static bool InitFtdiIso()
		{
			bool result;
			try
			{
				KeihinFlashReset.LogText("==================================================");
				KeihinFlashReset.LogText("[KEIHIN] FTDI INITIALIZATION");
				KeihinFlashReset.LogText("[KEIHIN] Baud : " + 10400U.ToString());
				KeihinFlashReset.LogText(string.Concat(new string[]
				{
					"[KEIHIN] Fast Init : LOW ",
					70.ToString(),
					" ms / HIGH ",
					120.ToString(),
					" ms"
				}));
				if (KeihinFlashReset.FT_Open(0U, ref KeihinFlashReset.ftHandle) != 0U)
				{
					KeihinFlashReset.LogText("[KEIHIN] FT_Open FAILED");
					result = false;
				}
				else
				{
					KeihinFlashReset.LogText("[KEIHIN] FT_Open OK");
					KeihinFlashReset.LogText("[KEIHIN] FT_Purge : " + KeihinFlashReset.FT_Purge(KeihinFlashReset.ftHandle, 3U).ToString());
					KeihinFlashReset.LogText("[KEIHIN] FT_SetBitMode UART : " + KeihinFlashReset.FT_SetBitMode(KeihinFlashReset.ftHandle, 0, 0).ToString());
					KeihinFlashReset.LogText("[KEIHIN] FT_SetDataCharacteristics : " + KeihinFlashReset.FT_SetDataCharacteristics(KeihinFlashReset.ftHandle, 8, 0, 0).ToString());
					KeihinFlashReset.LogText("[KEIHIN] FT_SetBaudRate : " + KeihinFlashReset.FT_SetBaudRate(KeihinFlashReset.ftHandle, 10400U).ToString());
					KeihinFlashReset.LogText("[KEIHIN] FT_SetTimeouts : " + KeihinFlashReset.FT_SetTimeouts(KeihinFlashReset.ftHandle, 1000U, 1000U).ToString());
					KeihinFlashReset.LogText("[KEIHIN] FT_SetLatencyTimer : " + KeihinFlashReset.FT_SetLatencyTimer(KeihinFlashReset.ftHandle, 2).ToString());
					KeihinFlashReset.LogText("[KEIHIN] BitBang ON : " + KeihinFlashReset.FT_SetBitMode(KeihinFlashReset.ftHandle, 1, 1).ToString());
					byte[] array = new byte[1];
					uint num = 0U;
					array[0] = 0;
					KeihinFlashReset.LogText("[KEIHIN] FAST INIT LOW : " + KeihinFlashReset.FT_Write(KeihinFlashReset.ftHandle, array, 1U, ref num).ToString() + " / written=" + num.ToString());
					Thread.Sleep(70);
					array[0] = 1;
					num = 0U;
					KeihinFlashReset.LogText("[KEIHIN] FAST INIT HIGH : " + KeihinFlashReset.FT_Write(KeihinFlashReset.ftHandle, array, 1U, ref num).ToString() + " / written=" + num.ToString());
					Thread.Sleep(120);
					KeihinFlashReset.LogText("[KEIHIN] UART MODE : " + KeihinFlashReset.FT_SetBitMode(KeihinFlashReset.ftHandle, 0, 0).ToString());
					KeihinFlashReset.LogText("[KEIHIN] UART BAUD : " + KeihinFlashReset.FT_SetBaudRate(KeihinFlashReset.ftHandle, 10400U).ToString());
					KeihinFlashReset.LogText("[KEIHIN] UART 8N1 : " + KeihinFlashReset.FT_SetDataCharacteristics(KeihinFlashReset.ftHandle, 8, 0, 0).ToString());
					KeihinFlashReset.LogText("[KEIHIN] UART PURGE : " + KeihinFlashReset.FT_Purge(KeihinFlashReset.ftHandle, 3U).ToString());
					Thread.Sleep(50);
					KeihinFlashReset.LogText("[KEIHIN] FTDI INIT READY");
					KeihinFlashReset.LogText("==================================================");
					result = true;
				}
			}
			catch (Exception ex)
			{
				KeihinFlashReset.LogText("[KEIHIN] INIT EXCEPTION : " + ex.Message);
				result = false;
			}
			return result;
		}

		// Token: 0x06000CEA RID: 3306
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_Open(uint uiPort, ref IntPtr ftHandle);

		// Token: 0x06000CEB RID: 3307
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_Close(IntPtr ftHandle);

		// Token: 0x06000CEC RID: 3308
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_Read(IntPtr ftHandle, byte[] lpBuffer, uint dwBytesToRead, ref uint lpdwBytesReturned);

		// Token: 0x06000CED RID: 3309
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_Write(IntPtr ftHandle, byte[] lpBuffer, uint dwBytesToWrite, ref uint lpdwBytesWritten);

		// Token: 0x06000CEE RID: 3310
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_SetBaudRate(IntPtr ftHandle, uint dwBaudRate);

		// Token: 0x06000CEF RID: 3311
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_SetDataCharacteristics(IntPtr ftHandle, byte uWordLength, byte uStopBits, byte uParity);

		// Token: 0x06000CF0 RID: 3312
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_SetTimeouts(IntPtr ftHandle, uint dwReadTimeout, uint dwWriteTimeout);

		// Token: 0x06000CF1 RID: 3313
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_SetLatencyTimer(IntPtr ftHandle, byte ucTimer);

		// Token: 0x06000CF2 RID: 3314
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_SetBitMode(IntPtr ftHandle, byte ucMask, byte ucMode);

		// Token: 0x06000CF3 RID: 3315
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_GetQueueStatus(IntPtr ftHandle, ref uint lpdwAmountInRxQueue);

		// Token: 0x06000CF4 RID: 3316
		[DllImport("ftd2xx.dll")]
		private static extern uint FT_Purge(IntPtr ftHandle, uint dwMask);

		// Token: 0x06000CF7 RID: 3319 RVA: 0x0005FD58 File Offset: 0x0005FD58
		private static void CleanupFTDI()
		{
			try
			{
				if (KeihinFlashReset.ftHandle != IntPtr.Zero)
				{
					KeihinFlashReset.LogText("[KEIHIN] Closing FTDI...");
					try
					{
						KeihinFlashReset.FT_Close(KeihinFlashReset.ftHandle);
					}
					catch
					{
					}
					KeihinFlashReset.ftHandle = IntPtr.Zero;
					KeihinFlashReset.LogText("[KEIHIN] FTDI CLOSED");
				}
			}
			catch
			{
				KeihinFlashReset.ftHandle = IntPtr.Zero;
			}
		}

		// Token: 0x06000CF8 RID: 3320 RVA: 0x0005FDD0 File Offset: 0x0005FDD0
		public static async Task StartResetProcess()
		{
			object obj = KeihinFlashReset.lockObject;
			lock (obj)
			{
				if (KeihinFlashReset.isProcessing)
				{
					CustomMessageBox__1.Show("Reset sedang berjalan.", "INFO", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					return;
				}
				KeihinFlashReset.isProcessing = true;
			}
			FormMain mainForm = null;
			try
			{
				int num = 0;
				try
				{
					try
					{
						foreach (object obj2 in Application.OpenForms)
						{
							FormMain formMain = ((Form)obj2) as FormMain;
							if (formMain != null && !formMain.IsDisposed && !formMain.Disposing)
							{
								mainForm = formMain;
								break;
							}
						}
					}
					catch
					{
						mainForm = null;
					}
					if (mainForm != null)
					{
						try
						{
							mainForm.BeginInvoke(new Action(delegate()
							{
								try
								{
									FieldInfo field = mainForm.GetType().GetField("_keihinResetRunning", BindingFlags.Instance | BindingFlags.NonPublic);
									if (field != null)
									{
										field.SetValue(mainForm, true);
									}
									MethodInfo method = mainForm.GetType().GetMethod("PrepareKeihinResetBlur", BindingFlags.Instance | BindingFlags.NonPublic);
									if (method != null)
									{
										method.Invoke(mainForm, null);
									}
								}
								catch
								{
								}
							}));
						}
						catch
						{
						}
						await Task.Delay(20);
					}
					if (CustomMessageBox__1.Show("Reset Flash Counter Keihin?\n\nIgnition harus OFF/ON.", "RESET COUNT", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK)
					{
						CustomMessageBox__1.Show("Reset dibatalkan.", "CANCEL", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						return;
					}
					try
					{
						KeihinFlashReset._popup = new ProgressPopupForm("RESET COUNT KEIHIN");
						KeihinFlashReset._popup.SetMaximum(100);
						KeihinFlashReset._popup.SetProgress(0);
						KeihinFlashReset._popup.SetStatus("Connecting ECU...");
						KeihinFlashReset._popup.Show();
						KeihinFlashReset._popup.TopMost = false;
						KeihinFlashReset._popup.BringToFront();
					}
					catch
					{
						KeihinFlashReset._popup = null;
					}
					await KeihinFlashReset.ResetFlashCount();
				}
				catch (Exception obj3)
				{
					num = 1;
				}
				object obj3;
				if (num == 1)
				{
					Exception ex = (Exception)obj3;
					try
					{
						KeihinFlashReset.CloseProgressPopup();
					}
					catch
					{
					}
					await Task.Delay(50);
					CustomMessageBox__1.Show("Proses gagal.\n\n" + ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					ex = null;
				}
				obj3 = null;
			}
			finally
			{
				obj = KeihinFlashReset.lockObject;
				bool flag = false;
				try
				{
					Monitor.Enter(obj, ref flag);
					KeihinFlashReset.isProcessing = false;
				}
				finally
				{
					int num2;
					if (num2 < 0 && flag)
					{
						Monitor.Exit(obj);
					}
				}
				if (mainForm != null && !mainForm.IsDisposed && !mainForm.Disposing)
				{
					try
					{
						mainForm.BeginInvoke(new Action(delegate()
						{
							try
							{
								FieldInfo field = mainForm.GetType().GetField("_keihinResetRunning", BindingFlags.Instance | BindingFlags.NonPublic);
								if (field != null)
								{
									field.SetValue(mainForm, false);
								}
								FieldInfo field2 = mainForm.GetType().GetField("_keihinResetBlurReady", BindingFlags.Instance | BindingFlags.NonPublic);
								if (field2 != null)
								{
									field2.SetValue(mainForm, false);
								}
								MethodInfo method = mainForm.GetType().GetMethod("RemoveBlurOverlay", BindingFlags.Instance | BindingFlags.NonPublic);
								if (method != null)
								{
									method.Invoke(mainForm, null);
								}
							}
							catch
							{
							}
						}));
					}
					catch
					{
					}
				}
				try
				{
					if (KeihinFlashReset._popup != null && KeihinFlashReset._popup.IsDisposed)
					{
						KeihinFlashReset._popup = null;
					}
				}
				catch
				{
					KeihinFlashReset._popup = null;
				}
			}
		}

		// Token: 0x06000CF9 RID: 3321 RVA: 0x000091F3 File Offset: 0x000091F3
		public static void SetProgressBar(ProgressBar progressBar)
		{
			KeihinFlashReset._progressBar = progressBar;
		}

		// Token: 0x06000CFA RID: 3322 RVA: 0x0005FE10 File Offset: 0x0005FE10
		private static void UpdateProgress(int currentStep, int totalSteps)
		{
			try
			{
				int num = (totalSteps > 0) ? Math.Min(100, Math.Max(0, checked(currentStep * 100) / totalSteps)) : 0;
				if (KeihinFlashReset._progressBar != null)
				{
					if (KeihinFlashReset._progressBar.InvokeRequired)
					{
						KeihinFlashReset._progressBar.Invoke(new Action<int>(KeihinFlashReset.UpdateProgressBarOnUIThread), new object[]
						{
							num
						});
					}
					else
					{
						KeihinFlashReset.UpdateProgressBarOnUIThread(num);
					}
				}
				if (KeihinFlashReset._statusLabel != null)
				{
					string text = string.Format("Reset : {0}% ({1}/{2})", num, currentStep, totalSteps);
					if (KeihinFlashReset._statusLabel.InvokeRequired)
					{
						KeihinFlashReset._statusLabel.Invoke(new Action<string>(KeihinFlashReset.UpdateStatusLabelOnUIThread), new object[]
						{
							text
						});
					}
					else
					{
						KeihinFlashReset.UpdateStatusLabelOnUIThread(text);
					}
				}
				if (KeihinFlashReset._popup != null && !KeihinFlashReset._popup.IsDisposed)
				{
					try
					{
						KeihinFlashReset._popup.SetProgress(num);
					}
					catch
					{
					}
					try
					{
						KeihinFlashReset._popup.SetStatus(string.Format("Step {0}/{1} ({2}%)", currentStep, totalSteps, num));
					}
					catch
					{
					}
					try
					{
						KeihinFlashReset._popup.Refresh();
					}
					catch
					{
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000CFB RID: 3323 RVA: 0x0005FF9C File Offset: 0x0005FF9C
		public static void InitializeUI(ProgressBar progressBar, Label statusLabel = null)
		{
			KeihinFlashReset._progressBar = progressBar;
			KeihinFlashReset._statusLabel = statusLabel;
			if (KeihinFlashReset._progressBar != null)
			{
				try
				{
					KeihinFlashReset._progressBar.Minimum = 0;
					KeihinFlashReset._progressBar.Maximum = 100;
					KeihinFlashReset._progressBar.Value = 0;
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000CFC RID: 3324 RVA: 0x0005FFF4 File Offset: 0x0005FFF4
		private static void CloseProgressPopup()
		{
			try
			{
				if (KeihinFlashReset._popup != null)
				{
					ProgressPopupForm popup = KeihinFlashReset._popup;
					if (popup.IsDisposed)
					{
						KeihinFlashReset._popup = null;
					}
					else
					{
						if (popup.InvokeRequired)
						{
							try
							{
								popup.Invoke(new MethodInvoker(KeihinFlashReset.CloseProgressPopupOnUIThread));
								goto IL_48;
							}
							catch
							{
								KeihinFlashReset._popup = null;
								goto IL_48;
							}
						}
						KeihinFlashReset.CloseProgressPopupOnUIThread();
					}
				}
				IL_48:;
			}
			catch
			{
				KeihinFlashReset._popup = null;
			}
		}

		// Token: 0x06000CFD RID: 3325 RVA: 0x00060070 File Offset: 0x00060070
		private static void UpdateProgressBarOnUIThread(int percentage)
		{
			if (KeihinFlashReset._progressBar == null)
			{
				return;
			}
			try
			{
				if (!KeihinFlashReset._progressBar.IsDisposed)
				{
					if (KeihinFlashReset._progressBar.Maximum != 100)
					{
						KeihinFlashReset._progressBar.Maximum = 100;
					}
					if (percentage < 0)
					{
						percentage = 0;
					}
					if (percentage > 100)
					{
						percentage = 100;
					}
					KeihinFlashReset._progressBar.Value = percentage;
					KeihinFlashReset._progressBar.Refresh();
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000CFE RID: 3326 RVA: 0x000600E8 File Offset: 0x000600E8
		private static void UpdateStatusLabelOnUIThread(string statusText)
		{
			if (KeihinFlashReset._statusLabel == null)
			{
				return;
			}
			try
			{
				if (!KeihinFlashReset._statusLabel.IsDisposed)
				{
					KeihinFlashReset._statusLabel.Text = statusText;
					KeihinFlashReset._statusLabel.Refresh();
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000CFF RID: 3327 RVA: 0x00060134 File Offset: 0x00060134
		private static byte CalcLRC(byte[] data, int length)
		{
			int num = 0;
			if (data == null)
			{
				return 0;
			}
			if (length > data.Length)
			{
				length = data.Length;
			}
			checked
			{
				for (int i = 0; i < length; i++)
				{
					num += (int)data[i];
				}
				return (byte)(256 - (num & 255) & 255);
			}
		}

		// Token: 0x06000D00 RID: 3328 RVA: 0x000091FB File Offset: 0x000091FB
		private static void LogHex(string direction, byte[] data, uint length)
		{
			KeihinFlashReset.LogHex(direction, data, checked((int)length));
		}

		// Token: 0x06000D01 RID: 3329 RVA: 0x0006017C File Offset: 0x0006017C
		private static bool SendCommand(byte[] command, ref byte[] reply, ref uint replySize)
		{
			checked
			{
				bool result;
				try
				{
					replySize = 0U;
					if (KeihinFlashReset.ftHandle == IntPtr.Zero)
					{
						KeihinFlashReset.LogText("[KEIHIN] SendCommand : FTDI HANDLE INVALID");
						result = false;
					}
					else if (command == null || command.Length == 0)
					{
						KeihinFlashReset.LogText("[KEIHIN] SendCommand : COMMAND EMPTY");
						result = false;
					}
					else if (reply == null || reply.Length == 0)
					{
						KeihinFlashReset.LogText("[KEIHIN] SendCommand : REPLY BUFFER EMPTY");
						result = false;
					}
					else
					{
						KeihinFlashReset.LogHex("TX", command, command.Length);
						uint num = 0U;
						uint num2 = KeihinFlashReset.FT_Write(KeihinFlashReset.ftHandle, command, (uint)command.Length, ref num);
						KeihinFlashReset.LogText(string.Concat(new string[]
						{
							"[KEIHIN] FT_Write Status=",
							num2.ToString(),
							" Written=",
							num.ToString(),
							"/",
							command.Length.ToString()
						}));
						if (num2 != 0U)
						{
							KeihinFlashReset.LogText("[KEIHIN] TX FAILED");
							result = false;
						}
						else if (num != (uint)command.Length)
						{
							KeihinFlashReset.LogText("[KEIHIN] TX INCOMPLETE");
							result = false;
						}
						else
						{
							Thread.Sleep(30);
							uint num3 = 0U;
							KeihinFlashReset.LogText("[KEIHIN] FT_GetQueueStatus Status=" + KeihinFlashReset.FT_GetQueueStatus(KeihinFlashReset.ftHandle, ref num3).ToString() + " Queue=" + num3.ToString());
							int num4 = 0;
							while (num3 == 0U && num4 < 8)
							{
								Thread.Sleep(15);
								num3 = 0U;
								uint num5 = KeihinFlashReset.FT_GetQueueStatus(KeihinFlashReset.ftHandle, ref num3);
								num4++;
								KeihinFlashReset.LogText(string.Concat(new string[]
								{
									"[KEIHIN] Queue Retry ",
									num4.ToString(),
									"/",
									8.ToString(),
									" Status=",
									num5.ToString(),
									" Queue=",
									num3.ToString()
								}));
							}
							if (num3 == 0U)
							{
								KeihinFlashReset.LogText("[KEIHIN] RX TIMEOUT - NO DATA");
								result = false;
							}
							else
							{
								byte[] array = new byte[num3];
								uint num6 = 0U;
								uint num7 = KeihinFlashReset.FT_Read(KeihinFlashReset.ftHandle, array, num3, ref num6);
								KeihinFlashReset.LogText(string.Concat(new string[]
								{
									"[KEIHIN] FT_Read Status=",
									num7.ToString(),
									" Read=",
									num6.ToString(),
									"/",
									num3.ToString()
								}));
								if (num7 != 0U)
								{
									KeihinFlashReset.LogText("[KEIHIN] RX FAILED");
									result = false;
								}
								else if (num6 == 0U)
								{
									KeihinFlashReset.LogText("[KEIHIN] RX EMPTY");
									result = false;
								}
								else
								{
									int num8 = Math.Min((int)num6, reply.Length);
									Array.Copy(array, 0, reply, 0, num8);
									replySize = (uint)num8;
									KeihinFlashReset.LogHex("RX", reply, num8);
									KeihinFlashReset.LogText("[KEIHIN] COMMAND COMPLETE");
									KeihinFlashReset.LogText("--------------------------------------------------");
									result = true;
								}
							}
						}
					}
				}
				catch (Exception ex)
				{
					replySize = 0U;
					KeihinFlashReset.LogText("[KEIHIN] SendCommand EXCEPTION : " + ex.Message);
					result = false;
				}
				return result;
			}
		}

		// Token: 0x06000D02 RID: 3330 RVA: 0x0006045C File Offset: 0x0006045C
		private static bool SendAndLog(byte[] command)
		{
			bool result;
			try
			{
				byte[] array = new byte[256];
				uint num = 0U;
				result = KeihinFlashReset.SendCommand(command, ref array, ref num);
			}
			catch (Exception ex)
			{
				KeihinFlashReset.LogText("[KEIHIN] SendAndLog EXCEPTION : " + ex.Message);
				result = false;
			}
			return result;
		}

		// Token: 0x06000D03 RID: 3331 RVA: 0x000604B0 File Offset: 0x000604B0
		private static void CloseProgressPopupOnUIThread()
		{
			ProgressPopupForm popup = KeihinFlashReset._popup;
			if (popup == null)
			{
				return;
			}
			try
			{
				if (!popup.IsDisposed)
				{
					try
					{
						popup.SetProgress(100);
					}
					catch
					{
					}
					try
					{
						popup.SetStatus("Finished.");
					}
					catch
					{
					}
					Application.DoEvents();
					try
					{
						popup.FinishAndEnableClose();
					}
					catch
					{
					}
					Application.DoEvents();
					try
					{
						popup.Close();
					}
					catch
					{
					}
					try
					{
						popup.Dispose();
					}
					catch
					{
					}
				}
			}
			catch
			{
			}
			finally
			{
				if (KeihinFlashReset._popup == popup)
				{
					KeihinFlashReset._popup = null;
				}
			}
		}

		// Token: 0x06000D04 RID: 3332 RVA: 0x00009206 File Offset: 0x00009206
		private static Task ResetFlashCount()
		{
			return Task.Run(delegate()
			{
				KeihinFlashReset.ResetFlashCountCore();
			});
		}

		// Token: 0x06000D05 RID: 3333 RVA: 0x00060588 File Offset: 0x00060588
		private static void LogText(string text)
		{
			try
			{
				Console.WriteLine(text);
			}
			catch
			{
			}
		}

		// Token: 0x06000D06 RID: 3334 RVA: 0x000605B0 File Offset: 0x000605B0
		private static string BytesToHex(byte[] data, int length)
		{
			string result;
			try
			{
				if (data == null)
				{
					result = "<NULL>";
				}
				else if (length <= 0)
				{
					result = "<EMPTY>";
				}
				else
				{
					if (length > data.Length)
					{
						length = data.Length;
					}
					result = BitConverter.ToString(data, 0, length);
				}
			}
			catch
			{
				result = "<HEX ERROR>";
			}
			return result;
		}

		// Token: 0x06000D07 RID: 3335 RVA: 0x00060604 File Offset: 0x00060604
		private static void LogHex(string direction, byte[] data, int length)
		{
			try
			{
				string text = KeihinFlashReset.BytesToHex(data, length);
				KeihinFlashReset.LogText(string.Concat(new string[]
				{
					"[KEIHIN] ",
					direction,
					" [",
					length.ToString(),
					" bytes] : ",
					text
				}));
			}
			catch
			{
			}
		}

		// Token: 0x06000D08 RID: 3336 RVA: 0x00060668 File Offset: 0x00060668
		private static bool ContainsBytes(byte[] data, uint size, byte[] pattern)
		{
			if (data == null || pattern == null)
			{
				return false;
			}
			if ((ulong)size < checked((ulong)(unchecked((long)pattern.Length))))
			{
				return false;
			}
			checked
			{
				if (unchecked((ulong)size) > (ulong)(unchecked((long)data.Length)))
				{
					size = (uint)data.Length;
				}
				for (int i = 0; i <= (int)(size - (uint)pattern.Length); i++)
				{
					bool flag = true;
					for (int j = 0; j < pattern.Length; j++)
					{
						if (data[i + j] != pattern[j])
						{
							flag = false;
							break;
						}
					}
					if (flag)
					{
						return true;
					}
				}
				return false;
			}
		}

		// Token: 0x06000D09 RID: 3337 RVA: 0x000606D0 File Offset: 0x000606D0
		private static void ResetFlashCountCore()
		{
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			int num4 = 0;
			bool flag = false;
			bool flag2 = false;
			checked
			{
				try
				{
					KeihinFlashReset.HoldConnection = true;
					KeihinFlashReset._sw.Restart();
					KeihinFlashReset.UpdateProgress(num, 135);
					if (!KeihinFlashReset.InitFtdiIso())
					{
						KeihinFlashReset._sw.Stop();
						KeihinFlashReset.CloseProgressPopup();
						Application.DoEvents();
						CustomMessageBox__1.Show("FTDI tidak terhubung.\nPeriksa kabel dan koneksi ECU.", "FTDI ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						byte[][] array = new byte[][]
						{
							new byte[]
							{
								254,
								4,
								114,
								140
							},
							new byte[]
							{
								114,
								5,
								0,
								240,
								153
							},
							new byte[]
							{
								39,
								11,
								224,
								72,
								101,
								108,
								108,
								111,
								72,
								111,
								67
							},
							new byte[]
							{
								39,
								11,
								224,
								119,
								65,
								114,
								101,
								89,
								111,
								117,
								34
							},
							new byte[]
							{
								145,
								145,
								13,
								223,
								158,
								141,
								154,
								134,
								144,
								138,
								140,
								155,
								136
							},
							new byte[]
							{
								145,
								145,
								13,
								223,
								146,
								158,
								134,
								150,
								139,
								141,
								134,
								192,
								106
							},
							new byte[]
							{
								145,
								145,
								9,
								65,
								14,
								0,
								0,
								0,
								168
							}
						};
						bool flag3 = false;
						for (int i = 0; i < 4; i++)
						{
							try
							{
								bool flag4 = KeihinFlashReset.SendAndLog(array[i]);
								KeihinFlashReset.LogText("[SECURITY] CMD " + i.ToString() + " : " + (flag4 ? "SENT" : "FAILED"));
							}
							catch (Exception ex)
							{
								KeihinFlashReset.LogText("[SECURITY] CMD " + i.ToString() + " ERROR : " + ex.Message);
							}
							Thread.Sleep(50);
							num++;
							if (num > 135)
							{
								num = 135;
							}
							KeihinFlashReset.UpdateProgress(num, 135);
						}
						byte[] command = new byte[]
						{
							130,
							130,
							20,
							8,
							0,
							1,
							0,
							223
						};
						byte[] value = new byte[256];
						uint num5 = 0U;
						try
						{
							if (KeihinFlashReset.SendCommand(command, ref value, ref num5) && num5 > 0U)
							{
								string text = BitConverter.ToString(value, 0, (int)num5);
								KeihinFlashReset.LogText("[SECURITY] TEST RESPONSE : " + text);
								if (text.Contains("92-92") || text.Contains("82-82"))
								{
									flag3 = true;
									KeihinFlashReset.LogText("[SECURITY] ACCESS OK");
								}
								else
								{
									KeihinFlashReset.LogText("[SECURITY] ACCESS NOT ACCEPTED");
								}
							}
							else
							{
								KeihinFlashReset.LogText("[SECURITY] TEST NO RESPONSE");
							}
						}
						catch (Exception ex2)
						{
							KeihinFlashReset.LogText("[SECURITY] TEST ERROR : " + ex2.Message);
						}
						if (!flag3)
						{
							KeihinFlashReset.LogText("[SECURITY] FIRST TEST FAILED - TRY SECOND SEQUENCE");
							for (int j = 4; j < array.Length; j++)
							{
								try
								{
									bool flag5 = KeihinFlashReset.SendAndLog(array[j]);
									KeihinFlashReset.LogText("[SECURITY] CMD " + j.ToString() + " : " + (flag5 ? "SENT" : "FAILED"));
								}
								catch (Exception ex3)
								{
									KeihinFlashReset.LogText("[SECURITY] CMD " + j.ToString() + " ERROR : " + ex3.Message);
								}
								Thread.Sleep(50);
								num++;
								if (num > 135)
								{
									num = 135;
								}
								KeihinFlashReset.UpdateProgress(num, 135);
							}
							num5 = 0U;
							try
							{
								if (KeihinFlashReset.SendCommand(command, ref value, ref num5) && num5 > 0U)
								{
									string text2 = BitConverter.ToString(value, 0, (int)num5);
									KeihinFlashReset.LogText("[SECURITY] TEST 2 RESPONSE : " + text2);
									if (text2.Contains("92-92") || text2.Contains("82-82"))
									{
										flag3 = true;
										KeihinFlashReset.LogText("[SECURITY] ACCESS OK");
									}
									else
									{
										KeihinFlashReset.LogText("[SECURITY] TEST 2 ACCESS NOT ACCEPTED");
									}
								}
								else
								{
									KeihinFlashReset.LogText("[SECURITY] TEST 2 NO RESPONSE");
								}
							}
							catch (Exception ex4)
							{
								KeihinFlashReset.LogText("[SECURITY] TEST 2 ERROR : " + ex4.Message);
							}
						}
						if (!flag3)
						{
							KeihinFlashReset._sw.Stop();
							KeihinFlashReset.CloseProgressPopup();
							Application.DoEvents();
							CustomMessageBox__1.Show("Security access gagal.\nPastikan ignition ON.", "SECURITY ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						else
						{
							KeihinFlashReset.LogText("================================================");
							KeihinFlashReset.LogText("[RESET] START 128 BLOCK");
							for (int k = 0; k < 128; k++)
							{
								byte[] array2 = new byte[8];
								array2[0] = 130;
								array2[1] = 130;
								array2[2] = 20;
								array2[3] = 8;
								array2[4] = (byte)k;
								array2[5] = 0;
								array2[6] = 0;
								array2[7] = KeihinFlashReset.CalcLRC(array2, 7);
								byte[] value2 = new byte[256];
								uint num6 = 0U;
								bool flag6 = false;
								try
								{
									flag6 = KeihinFlashReset.SendCommand(array2, ref value2, ref num6);
								}
								catch (Exception ex5)
								{
									flag6 = false;
									KeihinFlashReset.LogText("[RESET] BLOCK " + k.ToString() + " ERROR : " + ex5.Message);
								}
								if (flag6)
								{
									num3++;
									if (num6 > 0U)
									{
										string text3 = BitConverter.ToString(value2, 0, (int)num6);
										if (text3.StartsWith("62-62-2E"))
										{
											num2++;
											KeihinFlashReset.LogText("[RESET] BLOCK " + k.ToString() + " OK : " + text3);
										}
										else
										{
											KeihinFlashReset.LogText("[RESET] BLOCK " + k.ToString() + " RESPONSE : " + text3);
										}
									}
									else
									{
										KeihinFlashReset.LogText("[RESET] BLOCK " + k.ToString() + " COMMAND OK - EMPTY RESPONSE");
									}
								}
								else
								{
									num4++;
									KeihinFlashReset.LogText("[RESET] BLOCK " + k.ToString() + " NO RESPONSE / COMMAND FAILED");
								}
								Thread.Sleep(5);
								num++;
								if (num > 135)
								{
									num = 135;
								}
								KeihinFlashReset.UpdateProgress(num, 135);
							}
							byte[] command2 = new byte[]
							{
								130,
								130,
								20,
								8,
								127,
								0,
								0,
								97
							};
							byte[] value3 = new byte[256];
							uint num7 = 0U;
							try
							{
								flag = KeihinFlashReset.SendCommand(command2, ref value3, ref num7);
								if (flag)
								{
									KeihinFlashReset.LogText("[FINAL] COMMAND SENT / PROCESSED");
									if (num7 > 0U)
									{
										flag2 = true;
										string text4 = BitConverter.ToString(value3, 0, (int)num7);
										KeihinFlashReset.LogText("[FINAL] RESPONSE : " + text4);
										if (text4.Contains("92-92-14-05-C3"))
										{
											KeihinFlashReset.LogText("[FINAL] RESPONSE PATTERN OK");
										}
										else
										{
											KeihinFlashReset.LogText("[FINAL] RESPONSE RECEIVED");
										}
									}
									else
									{
										KeihinFlashReset.LogText("[FINAL] COMMAND OK - NO RESPONSE DATA");
									}
								}
								else
								{
									KeihinFlashReset.LogText("[FINAL] COMMAND FAILED / NO RESPONSE");
								}
							}
							catch (Exception ex6)
							{
								flag = false;
								KeihinFlashReset.LogText("[FINAL] ERROR : " + ex6.Message);
							}
							num = 135;
							KeihinFlashReset.UpdateProgress(num, 135);
							KeihinFlashReset._sw.Stop();
							if (num3 + num4 >= 128 && flag)
							{
								KeihinFlashReset.CloseProgressPopup();
								Application.DoEvents();
								Thread.Sleep(50);
								CustomMessageBox__1.Show("Flash Counter berhasil di-reset.\nBlocks : " + num2.ToString() + "/128\nIgnition OFF → OK,Click ON", "RESET COUNT", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								try
								{
									Form form = null;
									foreach (object obj in Application.OpenForms)
									{
										if (obj is FormMain)
										{
											form = (Form)obj;
											break;
										}
									}
									if (form == null && Application.OpenForms.Count > 0)
									{
										form = Application.OpenForms[0];
									}
									if (form != null && form.IsHandleCreated)
									{
										form.BeginInvoke(new Action(delegate()
										{
											try
											{
												Application.Restart();
											}
											catch
											{
											}
										}));
									}
									else
									{
										try
										{
											Process.Start(Application.ExecutablePath);
											Application.Exit();
										}
										catch
										{
										}
									}
									goto IL_776;
								}
								catch
								{
									goto IL_776;
								}
							}
							KeihinFlashReset.CloseProgressPopup();
							Application.DoEvents();
							Thread.Sleep(50);
							string str;
							if (flag)
							{
								if (flag2)
								{
									str = "RECEIVED";
								}
								else
								{
									str = "COMMAND OK";
								}
							}
							else
							{
								str = "FAILED";
							}
							CustomMessageBox__1.Show("Reset selesai dengan komunikasi parsial.\nCommand OK : " + num3.ToString() + "/128\nFinal : " + str, "RESET STATUS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
							array = null;
							command = null;
							value = null;
						}
					}
					IL_776:;
				}
				catch (Exception ex7)
				{
					KeihinFlashReset._sw.Stop();
					KeihinFlashReset.CloseProgressPopup();
					Application.DoEvents();
					Thread.Sleep(50);
					CustomMessageBox__1.Show("Proses reset gagal.\n" + ex7.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				finally
				{
					KeihinFlashReset.HoldConnection = false;
					object obj2 = KeihinFlashReset.lockObject;
					lock (obj2)
					{
						KeihinFlashReset.isProcessing = false;
					}
					KeihinFlashReset.CleanupFTDI();
				}
			}
		}

		// Token: 0x04000F67 RID: 3943
		private static IntPtr ftHandle = IntPtr.Zero;

		// Token: 0x04000F68 RID: 3944
		private static readonly Stopwatch _sw = new Stopwatch();

		// Token: 0x04000F69 RID: 3945
		private static volatile bool isProcessing = false;

		// Token: 0x04000F6A RID: 3946
		private static readonly object lockObject = new object();

		// Token: 0x04000F6B RID: 3947
		public static bool HoldConnection;

		// Token: 0x04000F6C RID: 3948
		private static ProgressPopupForm _popup;

		// Token: 0x04000F6D RID: 3949
		private static ProgressBar _progressBar;

		// Token: 0x04000F6E RID: 3950
		private static Label _statusLabel;

		// Token: 0x04000F6F RID: 3951
		private const int FAST_INIT_LOW_MS = 70;

		// Token: 0x04000F70 RID: 3952
		private const int FAST_INIT_HIGH_MS = 120;

		// Token: 0x04000F71 RID: 3953
		private const uint KEIHIN_BAUD_RATE = 10400U;

		// Token: 0x04000F72 RID: 3954
		private const int READ_TIMEOUT_MS = 100;

		// Token: 0x04000F73 RID: 3955
		private const int QUEUE_POLL_INTERVAL_MS = 50;

		// Token: 0x04000F74 RID: 3956
		private const int QUEUE_POLL_MAX_RETRY = 10;

		// Token: 0x04000F75 RID: 3957
		private const int WAKEUP_DELAY_MS = 150;

		// Token: 0x04000F76 RID: 3958
		private const int CMD_DELAY_MS = 10;
	}
}
