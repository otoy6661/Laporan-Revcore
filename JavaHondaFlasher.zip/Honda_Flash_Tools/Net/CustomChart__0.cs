﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000759 RID: 1881
	public class CustomChart__0 : Control
	{
		// Token: 0x170000AF RID: 175
		// (get) Token: 0x06001205 RID: 4613 RVA: 0x0000BBEE File Offset: 0x0000BBEE
		// (set) Token: 0x06001206 RID: 4614 RVA: 0x0000BBF6 File Offset: 0x0000BBF6
		public CustomChart__0.SeriesCollection Series { get; private set; }

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x06001207 RID: 4615 RVA: 0x0000BBFF File Offset: 0x0000BBFF
		// (set) Token: 0x06001208 RID: 4616 RVA: 0x0000BC07 File Offset: 0x0000BC07
		public CustomChart__0.ChartAreaCollection ChartAreas { get; private set; }

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x06001209 RID: 4617 RVA: 0x0000BC10 File Offset: 0x0000BC10
		// (set) Token: 0x0600120A RID: 4618 RVA: 0x0000BC18 File Offset: 0x0000BC18
		public CustomChart__0.LegendsCollection Legends { get; private set; }

		// Token: 0x0600120B RID: 4619 RVA: 0x00088C68 File Offset: 0x00088C68
		public CustomChart__0()
		{
			this.dataPoints = new List<double>();
			this.maxY = 100.0;
			this.intervalY = 10.0;
			this.maxX = 50.0;
			this.intervalX = 5.0;
			this.seriesColor = Color.Red;
			this.gridColor = Color.FromArgb(180, 180, 180);
			this.borderColor = Color.WhiteSmoke;
			this.DoubleBuffered = true;
			this.BackColor = Color.Gainsboro;
			base.Size = new Size(400, 300);
			this.Series = new CustomChart__0.SeriesCollection(this);
			this.ChartAreas = new CustomChart__0.ChartAreaCollection(this);
			this.Legends = new CustomChart__0.LegendsCollection();
		}

		// Token: 0x0600120C RID: 4620 RVA: 0x0000BC21 File Offset: 0x0000BC21
		public void AddPoint(double value)
		{
			this.dataPoints.Add(value);
			while (this.dataPoints.Count > 50)
			{
				this.dataPoints.RemoveAt(0);
			}
			base.Invalidate();
		}

		// Token: 0x0600120D RID: 4621 RVA: 0x0000BC52 File Offset: 0x0000BC52
		public void ClearPoints()
		{
			this.dataPoints.Clear();
			base.Invalidate();
		}

		// Token: 0x0600120E RID: 4622 RVA: 0x0000BC65 File Offset: 0x0000BC65
		public void SetAxisY(double min, double max, double interval)
		{
			this.minY = min;
			this.maxY = max;
			this.intervalY = interval;
			base.Invalidate();
		}

		// Token: 0x0600120F RID: 4623 RVA: 0x0000BC82 File Offset: 0x0000BC82
		public void SetAxisX(double min, double max, double interval)
		{
			this.minX = min;
			this.maxX = max;
			this.intervalX = interval;
			base.Invalidate();
		}

		// Token: 0x06001210 RID: 4624 RVA: 0x0000BC9F File Offset: 0x0000BC9F
		public void SetXAxisEnabled(bool enabled)
		{
			this.showXAxis = enabled;
			base.Invalidate();
		}

		// Token: 0x06001211 RID: 4625 RVA: 0x00088D3C File Offset: 0x00088D3C
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			Rectangle clientRectangle = base.ClientRectangle;
			clientRectangle.Inflate(-40, -30);
			if (clientRectangle.Width <= 0 || clientRectangle.Height <= 0)
			{
				return;
			}
			using (SolidBrush solidBrush = new SolidBrush(this.BackColor))
			{
				using (Pen pen = new Pen(this.gridColor, 1f))
				{
					using (Pen pen2 = new Pen(this.borderColor, 2f))
					{
						using (Font font = new Font("Arial", 8f))
						{
							using (Brush brush = new SolidBrush(Color.Cyan))
							{
								graphics.FillRectangle(solidBrush, base.ClientRectangle);
								double num = this.maxY - this.minY;
								if (num > 0.0)
								{
									int num2 = (int)(num / this.intervalY) + 1;
									for (int i = 0; i <= num2; i++)
									{
										double num3 = this.minY + (double)i * this.intervalY;
										int num4 = clientRectangle.Bottom - (int)((num3 - this.minY) / num * (double)clientRectangle.Height);
										if (num4 >= clientRectangle.Top && num4 <= clientRectangle.Bottom)
										{
											graphics.DrawLine(pen, clientRectangle.Left, num4, clientRectangle.Right, num4);
											string text = num3.ToString("F0");
											SizeF sizeF = graphics.MeasureString(text, font);
											graphics.DrawString(text, font, brush, (float)clientRectangle.Left - sizeF.Width - 5f, (float)num4 - sizeF.Height / 2f);
										}
									}
								}
								if (this.showXAxis)
								{
									double num5 = this.maxX - this.minX;
									if (num5 > 0.0)
									{
										int num6 = (int)(num5 / this.intervalX) + 1;
										for (int j = 0; j <= num6; j++)
										{
											double num7 = this.minX + (double)j * this.intervalX;
											int num8 = clientRectangle.Left + (int)((num7 - this.minX) / num5 * (double)clientRectangle.Width);
											if (num8 >= clientRectangle.Left && num8 <= clientRectangle.Right)
											{
												graphics.DrawLine(pen, num8, clientRectangle.Top, num8, clientRectangle.Bottom);
												string text2 = num7.ToString("F0");
												SizeF sizeF2 = graphics.MeasureString(text2, font);
												graphics.DrawString(text2, font, brush, (float)num8 - sizeF2.Width / 2f, (float)(clientRectangle.Bottom + 2));
											}
										}
									}
								}
								graphics.DrawRectangle(pen2, clientRectangle);
								if (this.dataPoints.Count > 1)
								{
									using (Pen pen3 = new Pen(this.seriesColor, 2f))
									{
										int num9 = clientRectangle.Width / Math.Max(1, 49);
										double num10 = this.maxY - this.minY;
										for (int k = 0; k < this.dataPoints.Count - 1; k++)
										{
											double num11 = Math.Max(this.minY, Math.Min(this.maxY, this.dataPoints[k]));
											double num12 = Math.Max(this.minY, Math.Min(this.maxY, this.dataPoints[k + 1]));
											int x = clientRectangle.Left + k * num9;
											int x2 = clientRectangle.Left + (k + 1) * num9;
											int num13 = clientRectangle.Bottom - (int)((num11 - this.minY) / num10 * (double)clientRectangle.Height);
											int num14 = clientRectangle.Bottom - (int)((num12 - this.minY) / num10 * (double)clientRectangle.Height);
											if (num13 >= clientRectangle.Top && num13 <= clientRectangle.Bottom && num14 >= clientRectangle.Top && num14 <= clientRectangle.Bottom)
											{
												graphics.DrawLine(pen3, x, num13, x2, num14);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x040018D8 RID: 6360
		private List<double> dataPoints;

		// Token: 0x040018D9 RID: 6361
		private double minY;

		// Token: 0x040018DA RID: 6362
		private double maxY;

		// Token: 0x040018DB RID: 6363
		private double intervalY;

		// Token: 0x040018DC RID: 6364
		private double minX;

		// Token: 0x040018DD RID: 6365
		private double maxX;

		// Token: 0x040018DE RID: 6366
		private double intervalX;

		// Token: 0x040018DF RID: 6367
		private Color seriesColor;

		// Token: 0x040018E0 RID: 6368
		private Color gridColor;

		// Token: 0x040018E1 RID: 6369
		private Color borderColor;

		// Token: 0x040018E2 RID: 6370
		private bool showXAxis;

		// Token: 0x0200075A RID: 1882
		public class SeriesCollection
		{
			// Token: 0x06001212 RID: 4626 RVA: 0x0000BCAE File Offset: 0x0000BCAE
			public SeriesCollection(CustomChart__0 parent)
			{
				this.parent = parent;
				this.series.Add(new CustomChart__0.CustomSeries(parent));
			}

			// Token: 0x170000B2 RID: 178
			public CustomChart__0.CustomSeries this[int index]
			{
				get
				{
					return this.series[index];
				}
			}

			// Token: 0x06001214 RID: 4628 RVA: 0x0000BCE7 File Offset: 0x0000BCE7
			public void Add(CustomChart__0.CustomSeries seriesItem)
			{
				this.series.Add(seriesItem);
			}

			// Token: 0x040018E3 RID: 6371
			private CustomChart__0 parent;

			// Token: 0x040018E4 RID: 6372
			private List<CustomChart__0.CustomSeries> series = new List<CustomChart__0.CustomSeries>();
		}

		// Token: 0x0200075B RID: 1883
		public class CustomSeries
		{
			// Token: 0x170000B3 RID: 179
			// (get) Token: 0x06001215 RID: 4629 RVA: 0x0000BCF5 File Offset: 0x0000BCF5
			// (set) Token: 0x06001216 RID: 4630 RVA: 0x0000BCFD File Offset: 0x0000BCFD
			public CustomChart__0.SeriesPoints Points { get; private set; }

			// Token: 0x170000B4 RID: 180
			// (get) Token: 0x06001217 RID: 4631 RVA: 0x0000BD06 File Offset: 0x0000BD06
			// (set) Token: 0x06001218 RID: 4632 RVA: 0x0000BD0E File Offset: 0x0000BD0E
			public bool IsValueShownAsLabel { get; set; }

			// Token: 0x170000B5 RID: 181
			// (get) Token: 0x06001219 RID: 4633 RVA: 0x0000BD17 File Offset: 0x0000BD17
			// (set) Token: 0x0600121A RID: 4634 RVA: 0x0000BD1F File Offset: 0x0000BD1F
			public bool IsVisibleInLegend { get; set; }

			// Token: 0x170000B6 RID: 182
			// (get) Token: 0x0600121B RID: 4635 RVA: 0x0000BD28 File Offset: 0x0000BD28
			// (set) Token: 0x0600121C RID: 4636 RVA: 0x0000BD30 File Offset: 0x0000BD30
			public int ChartType { get; set; }

			// Token: 0x0600121D RID: 4637 RVA: 0x0000BD39 File Offset: 0x0000BD39
			public CustomSeries(CustomChart__0 parent)
			{
				this.parent = parent;
				this.Points = new CustomChart__0.SeriesPoints(parent);
			}

			// Token: 0x040018E9 RID: 6377
			private CustomChart__0 parent;
		}

		// Token: 0x0200075C RID: 1884
		public class SeriesPoints
		{
			// Token: 0x0600121E RID: 4638 RVA: 0x0000BD54 File Offset: 0x0000BD54
			public SeriesPoints(CustomChart__0 parent)
			{
				this.parent = parent;
			}

			// Token: 0x170000B7 RID: 183
			// (get) Token: 0x0600121F RID: 4639 RVA: 0x0000BD6E File Offset: 0x0000BD6E
			public int Count
			{
				get
				{
					return this.points.Count;
				}
			}

			// Token: 0x06001220 RID: 4640 RVA: 0x0000BD7B File Offset: 0x0000BD7B
			public void AddY(double value)
			{
				this.points.Add(value);
				this.parent.AddPoint(value);
			}

			// Token: 0x06001221 RID: 4641 RVA: 0x000891F8 File Offset: 0x000891F8
			public void AddY(object[] values)
			{
				double value;
				if (values.Length != 0 && double.TryParse(values[0].ToString(), out value))
				{
					this.AddY(value);
				}
			}

			// Token: 0x06001222 RID: 4642 RVA: 0x0000BD95 File Offset: 0x0000BD95
			public void AddXY(double x, double y)
			{
				this.AddY(y);
			}

			// Token: 0x06001223 RID: 4643 RVA: 0x0000BD9E File Offset: 0x0000BD9E
			public void Clear()
			{
				this.points.Clear();
				this.parent.ClearPoints();
			}

			// Token: 0x06001224 RID: 4644 RVA: 0x00089224 File Offset: 0x00089224
			public void RemoveAt(int index)
			{
				if (index >= 0 && index < this.points.Count)
				{
					this.points.RemoveAt(index);
					this.parent.ClearPoints();
					foreach (double value in this.points)
					{
						this.parent.AddPoint(value);
					}
				}
			}

			// Token: 0x040018EA RID: 6378
			private CustomChart__0 parent;

			// Token: 0x040018EB RID: 6379
			private List<double> points = new List<double>();
		}

		// Token: 0x0200075D RID: 1885
		public class ChartAreaCollection
		{
			// Token: 0x06001225 RID: 4645 RVA: 0x0000BDB6 File Offset: 0x0000BDB6
			public ChartAreaCollection(CustomChart__0 parent)
			{
				this.parent = parent;
				this.areas.Add(new CustomChart__0.ChartArea(parent));
			}

			// Token: 0x170000B8 RID: 184
			public CustomChart__0.ChartArea this[int index]
			{
				get
				{
					return this.areas[index];
				}
			}

			// Token: 0x170000B9 RID: 185
			public CustomChart__0.ChartArea this[string name]
			{
				get
				{
					return this.areas[0];
				}
			}

			// Token: 0x040018EC RID: 6380
			private CustomChart__0 parent;

			// Token: 0x040018ED RID: 6381
			private List<CustomChart__0.ChartArea> areas = new List<CustomChart__0.ChartArea>();
		}

		// Token: 0x0200075E RID: 1886
		public class ChartArea
		{
			// Token: 0x170000BA RID: 186
			// (get) Token: 0x06001228 RID: 4648 RVA: 0x0000BDFD File Offset: 0x0000BDFD
			// (set) Token: 0x06001229 RID: 4649 RVA: 0x0000BE05 File Offset: 0x0000BE05
			public CustomChart__0.Axis AxisX { get; private set; }

			// Token: 0x170000BB RID: 187
			// (get) Token: 0x0600122A RID: 4650 RVA: 0x0000BE0E File Offset: 0x0000BE0E
			// (set) Token: 0x0600122B RID: 4651 RVA: 0x0000BE16 File Offset: 0x0000BE16
			public CustomChart__0.Axis AxisY { get; private set; }

			// Token: 0x0600122C RID: 4652 RVA: 0x0000BE1F File Offset: 0x0000BE1F
			public ChartArea(CustomChart__0 parent)
			{
				this.parent = parent;
				this.AxisX = new CustomChart__0.Axis(parent, true);
				this.AxisY = new CustomChart__0.Axis(parent, false);
			}

			// Token: 0x040018F0 RID: 6384
			private CustomChart__0 parent;
		}

		// Token: 0x0200075F RID: 1887
		public class Axis
		{
			// Token: 0x170000BC RID: 188
			// (get) Token: 0x0600122D RID: 4653 RVA: 0x0000BE48 File Offset: 0x0000BE48
			// (set) Token: 0x0600122E RID: 4654 RVA: 0x000892A8 File Offset: 0x000892A8
			public double Minimum
			{
				get
				{
					return this.minimum;
				}
				set
				{
					this.minimum = value;
					if (this.isX)
					{
						this.parent.SetAxisX(this.minimum, this.parent.maxX, this.parent.intervalX);
						return;
					}
					this.parent.SetAxisY(this.minimum, this.parent.maxY, this.parent.intervalY);
				}
			}

			// Token: 0x170000BD RID: 189
			// (get) Token: 0x0600122F RID: 4655 RVA: 0x0000BE50 File Offset: 0x0000BE50
			// (set) Token: 0x06001230 RID: 4656 RVA: 0x00089314 File Offset: 0x00089314
			public double Maximum
			{
				get
				{
					return this.maximum;
				}
				set
				{
					this.maximum = value;
					if (this.isX)
					{
						this.parent.SetAxisX(this.parent.minX, this.maximum, this.parent.intervalX);
						return;
					}
					this.parent.SetAxisY(this.parent.minY, this.maximum, this.parent.intervalY);
				}
			}

			// Token: 0x170000BE RID: 190
			// (get) Token: 0x06001231 RID: 4657 RVA: 0x0000BE58 File Offset: 0x0000BE58
			// (set) Token: 0x06001232 RID: 4658 RVA: 0x00089380 File Offset: 0x00089380
			public double Interval
			{
				get
				{
					return this.interval;
				}
				set
				{
					this.interval = value;
					if (this.isX)
					{
						this.parent.SetAxisX(this.parent.minX, this.parent.maxX, this.interval);
						return;
					}
					this.parent.SetAxisY(this.parent.minY, this.parent.maxY, this.interval);
				}
			}

			// Token: 0x170000BF RID: 191
			// (get) Token: 0x06001233 RID: 4659 RVA: 0x0000BE60 File Offset: 0x0000BE60
			// (set) Token: 0x06001234 RID: 4660 RVA: 0x0000BE68 File Offset: 0x0000BE68
			public bool Enabled
			{
				get
				{
					return this.enabled;
				}
				set
				{
					this.enabled = value;
					if (this.isX)
					{
						this.parent.SetXAxisEnabled(this.enabled);
					}
				}
			}

			// Token: 0x06001235 RID: 4661 RVA: 0x0000BE8A File Offset: 0x0000BE8A
			public Axis(CustomChart__0 parent, bool isX)
			{
				this.parent = parent;
				this.isX = isX;
			}

			// Token: 0x040018F1 RID: 6385
			private CustomChart__0 parent;

			// Token: 0x040018F2 RID: 6386
			private bool isX;

			// Token: 0x040018F3 RID: 6387
			private double minimum;

			// Token: 0x040018F4 RID: 6388
			private double maximum = 100.0;

			// Token: 0x040018F5 RID: 6389
			private double interval = 10.0;

			// Token: 0x040018F6 RID: 6390
			private bool enabled = true;
		}

		// Token: 0x02000760 RID: 1888
		public class LegendsCollection
		{
			// Token: 0x06001236 RID: 4662 RVA: 0x0000BEC5 File Offset: 0x0000BEC5
			public void Add(CustomChart__0.Legend legend)
			{
				this.legends.Add(legend);
			}

			// Token: 0x040018F7 RID: 6391
			private List<CustomChart__0.Legend> legends = new List<CustomChart__0.Legend>();
		}

		// Token: 0x02000761 RID: 1889
		public class Legend
		{
			// Token: 0x170000C0 RID: 192
			// (get) Token: 0x06001238 RID: 4664 RVA: 0x0000BEE6 File Offset: 0x0000BEE6
			// (set) Token: 0x06001239 RID: 4665 RVA: 0x0000BEEE File Offset: 0x0000BEEE
			public Color BackColor { get; set; }

			// Token: 0x170000C1 RID: 193
			// (get) Token: 0x0600123A RID: 4666 RVA: 0x0000BEF7 File Offset: 0x0000BEF7
			// (set) Token: 0x0600123B RID: 4667 RVA: 0x0000BEFF File Offset: 0x0000BEFF
			public Color ForeColor { get; set; }
		}
	}
}
