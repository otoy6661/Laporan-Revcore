﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200074B RID: 1867
	public static class Operators__0
	{
		// Token: 0x06001175 RID: 4469 RVA: 0x0000B8B8 File Offset: 0x0000B8B8
		public static int CompareString(string left, string right, bool textCompare)
		{
			if (left == null && right == null)
			{
				return 0;
			}
			if (left == null)
			{
				return -1;
			}
			if (right == null)
			{
				return 1;
			}
			if (textCompare)
			{
				return string.Compare(left, right, StringComparison.OrdinalIgnoreCase);
			}
			return string.Compare(left, right, StringComparison.Ordinal);
		}

		// Token: 0x06001176 RID: 4470 RVA: 0x00080188 File Offset: 0x00080188
		public static object SubtractObject(object left, object right)
		{
			double num = Conversions__0.ToDouble(left);
			double num2 = Conversions__0.ToDouble(right);
			double num3 = num - num2;
			if (num3 == Math.Floor(num3) && !double.IsInfinity(num3))
			{
				return (int)num3;
			}
			return num3;
		}

		// Token: 0x06001177 RID: 4471 RVA: 0x000801C4 File Offset: 0x000801C4
		public static object AddObject(object left, object right)
		{
			double num = Conversions__0.ToDouble(left);
			double num2 = Conversions__0.ToDouble(right);
			double num3 = num + num2;
			if (num3 == Math.Floor(num3) && !double.IsInfinity(num3))
			{
				return (int)num3;
			}
			return num3;
		}
	}
}
