﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200070E RID: 1806
	public class RoundedPanel__0 : Panel
	{
		// Token: 0x17000087 RID: 135
		// (get) Token: 0x06001041 RID: 4161 RVA: 0x0000B069 File Offset: 0x0000B069
		// (set) Token: 0x06001042 RID: 4162 RVA: 0x0000B071 File Offset: 0x0000B071
		public int CornerRadius { get; set; } = 10;

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x06001043 RID: 4163 RVA: 0x0000B07A File Offset: 0x0000B07A
		// (set) Token: 0x06001044 RID: 4164 RVA: 0x0000B082 File Offset: 0x0000B082
		public Color BorderColor { get; set; } = Color.FromArgb(0, 255, 220);

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x06001045 RID: 4165 RVA: 0x0000B08B File Offset: 0x0000B08B
		// (set) Token: 0x06001046 RID: 4166 RVA: 0x0000B093 File Offset: 0x0000B093
		public float BorderWidth { get; set; } = 1f;

		// Token: 0x06001047 RID: 4167 RVA: 0x000758F8 File Offset: 0x000758F8
		public RoundedPanel__0()
		{
			this.DoubleBuffered = true;
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.UpdateStyles();
		}

		// Token: 0x06001048 RID: 4168 RVA: 0x00075950 File Offset: 0x00075950
		protected override void OnPaint(PaintEventArgs e)
		{
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			int width = base.ClientSize.Width;
			int height = base.ClientSize.Height;
			using (GraphicsPath roundedPath = this.GetRoundedPath(new Rectangle(0, 0, width - 1, height - 1), this.CornerRadius))
			{
				using (SolidBrush solidBrush = new SolidBrush(this.BackColor))
				{
					e.Graphics.FillPath(solidBrush, roundedPath);
				}
			}
			using (GraphicsPath roundedPath2 = this.GetRoundedPath(new Rectangle(0, 0, width - 2, height - 2), this.CornerRadius))
			{
				using (Pen pen = new Pen(this.BorderColor, this.BorderWidth))
				{
					e.Graphics.DrawPath(pen, roundedPath2);
				}
			}
			base.OnPaint(e);
		}

		// Token: 0x06001049 RID: 4169 RVA: 0x0004D38C File Offset: 0x0004D38C
		private GraphicsPath GetRoundedPath(Rectangle r, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = radius * 2;
			graphicsPath.AddArc(r.X, r.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(r.Right - num, r.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(r.Right - num, r.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(r.X, r.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}
	}
}
