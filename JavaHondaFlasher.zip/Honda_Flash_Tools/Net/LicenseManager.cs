﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using LicenseShared;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000716 RID: 1814
	public static class LicenseManager
	{
		// Token: 0x06001073 RID: 4211 RVA: 0x0000B277 File Offset: 0x0000B277
		public static string GetHardwareId()
		{
			return LicenseShared.HardwareIdProvider.GetHardwareId();
		}

		// Token: 0x06001074 RID: 4212 RVA: 0x00077158 File Offset: 0x00077158
		public static string GetLicenseFolderPath()
		{
			string text = Path.Combine(Application.StartupPath, "licenses");
			try
			{
				if (!Directory.Exists(text))
				{
					Directory.CreateDirectory(text);
				}
			}
			catch
			{
			}
			return text;
		}

		// Token: 0x06001075 RID: 4213 RVA: 0x0000B27E File Offset: 0x0000B27E
		public static string GetActivationFlagPath()
		{
			return Path.Combine(LicenseManager.GetLicenseFolderPath(), "activated.dat");
		}

		// Token: 0x06001076 RID: 4214 RVA: 0x0000B28F File Offset: 0x0000B28F
		public static string GetLicenseFilePath()
		{
			return Path.Combine(LicenseManager.GetLicenseFolderPath(), "honda_flash.lic");
		}

		// Token: 0x06001077 RID: 4215 RVA: 0x0007719C File Offset: 0x0007719C
		public static LicenseManager.LicenseInfo ParseLicenseFile(string path)
		{
			LicenseManager.LicenseInfo result;
			try
			{
				if (string.IsNullOrEmpty(path))
				{
					result = null;
				}
				else if (!File.Exists(path))
				{
					result = null;
				}
				else
				{
					LicenseManager.LicenseInfo licenseInfo = new LicenseManager.LicenseInfo();
					string[] array = File.ReadAllLines(path);
					for (int i = 0; i < array.Length; i++)
					{
						string text = array[i].Trim();
						if (text.Length != 0 && !text.StartsWith(";") && !text.StartsWith("["))
						{
							int num = text.IndexOf('=');
							if (num > 0)
							{
								string a = text.Substring(0, num).Trim();
								string text2 = text.Substring(num + 1).Trim();
								if (!(a == "Key"))
								{
									if (!(a == "Customer"))
									{
										if (!(a == "HardwareID"))
										{
											if (!(a == "Type"))
											{
												bool permanent;
												if (!(a == "Permanent"))
												{
													if (a == "ExpiryDate")
													{
														DateTime expiryDate;
														if (DateTime.TryParse(text2, out expiryDate))
														{
															licenseInfo.ExpiryDate = expiryDate;
														}
													}
												}
												else if (bool.TryParse(text2, out permanent))
												{
													licenseInfo.Permanent = permanent;
												}
											}
											else
											{
												licenseInfo.Type = text2;
											}
										}
										else
										{
											licenseInfo.HardwareID = text2;
										}
									}
									else
									{
										licenseInfo.Customer = text2;
									}
								}
								else
								{
									licenseInfo.Key = text2;
								}
							}
						}
					}
					if (string.IsNullOrEmpty(licenseInfo.Key))
					{
						result = null;
					}
					else
					{
						result = licenseInfo;
					}
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06001078 RID: 4216 RVA: 0x00077334 File Offset: 0x00077334
		public static void WriteLicenseFile(string path, LicenseManager.LicenseInfo info)
		{
			if (string.IsNullOrEmpty(path))
			{
				return;
			}
			if (info == null)
			{
				return;
			}
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("; Honda Flash Tools License File");
			stringBuilder.AppendLine("; Generated: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
			stringBuilder.AppendLine("; ========================================");
			stringBuilder.AppendLine("[License]");
			stringBuilder.AppendLine("Key=" + info.Key);
			stringBuilder.AppendLine("Customer=" + info.Customer);
			stringBuilder.AppendLine("HardwareID=" + info.HardwareID);
			stringBuilder.AppendLine("Type=" + info.Type);
			stringBuilder.AppendLine("Permanent=" + info.Permanent.ToString());
			stringBuilder.AppendLine("ExpiryDate=" + info.ExpiryDate.ToString("yyyy-MM-dd"));
			stringBuilder.AppendLine("; ========================================");
			File.WriteAllText(path, stringBuilder.ToString());
		}

		// Token: 0x06001079 RID: 4217 RVA: 0x0007744C File Offset: 0x0007744C
		public static bool ValidateKeyFormat(string key)
		{
			if (string.IsNullOrEmpty(key))
			{
				return false;
			}
			key = key.Trim();
			string[] array = key.Split(new char[]
			{
				'-'
			});
			if (array.Length != 5)
			{
				return false;
			}
			string a = array[0].ToUpperInvariant();
			if (!(a == "STD") && !(a == "PRM") && !(a == "PRO") && !(a == "LIF"))
			{
				return false;
			}
			for (int i = 1; i < 5; i++)
			{
				if (array[i].Length != 4)
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x0600107A RID: 4218 RVA: 0x000774E4 File Offset: 0x000774E4
		public static bool IsActivated(out LicenseManager.LicenseInfo info, out string errorMessage)
		{
			info = null;
			errorMessage = "";
			bool result;
			try
			{
				if (!File.Exists(LicenseManager.GetActivationFlagPath()))
				{
					errorMessage = "Aplikasi belum diaktivasi.";
					result = false;
				}
				else
				{
					string licenseFilePath = LicenseManager.GetLicenseFilePath();
					if (!File.Exists(licenseFilePath))
					{
						errorMessage = "File license tidak ditemukan.";
						result = false;
					}
					else
					{
						LicenseManager.LicenseInfo licenseInfo = LicenseManager.ParseLicenseFile(licenseFilePath);
						if (licenseInfo == null)
						{
							errorMessage = "File license rusak atau tidak valid.";
							result = false;
						}
						else
						{
							string hardwareId = LicenseManager.GetHardwareId();
							if (!licenseInfo.IsValid(hardwareId))
							{
								if (!string.IsNullOrEmpty(licenseInfo.HardwareID) && !string.Equals(licenseInfo.HardwareID, hardwareId, StringComparison.OrdinalIgnoreCase))
								{
									errorMessage = "License tidak cocok dengan PC ini (Hardware ID berbeda).";
								}
								else if (!licenseInfo.Permanent && licenseInfo.ExpiryDate < DateTime.Now.Date)
								{
									errorMessage = "License sudah expired pada " + licenseInfo.ExpiryDate.ToString("dd MMM yyyy") + ".";
								}
								else
								{
									errorMessage = "License tidak valid.";
								}
								result = false;
							}
							else if (!LicenseManager.ValidateKeyFormat(licenseInfo.Key))
							{
								errorMessage = "Format key tidak valid.";
								result = false;
							}
							else
							{
								info = licenseInfo;
								result = true;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				errorMessage = "Error cek license: " + ex.Message;
				result = false;
			}
			return result;
		}

		// Token: 0x0600107B RID: 4219 RVA: 0x00077618 File Offset: 0x00077618
		public static bool Activate(string sourceLicPath, out string errorMessage)
		{
			errorMessage = "";
			bool result;
			try
			{
				if (string.IsNullOrEmpty(sourceLicPath))
				{
					errorMessage = "Path license kosong.";
					result = false;
				}
				else if (!File.Exists(sourceLicPath))
				{
					errorMessage = "File license tidak ditemukan.";
					result = false;
				}
				else
				{
					LicenseManager.LicenseInfo licenseInfo = LicenseManager.ParseLicenseFile(sourceLicPath);
					if (licenseInfo == null)
					{
						errorMessage = "File license rusak atau format tidak dikenali.";
						result = false;
					}
					else if (!LicenseManager.ValidateKeyFormat(licenseInfo.Key))
					{
						errorMessage = "Format key tidak valid (harus TYP-XXXX-XXXX-XXXX-XXXX).";
						result = false;
					}
					else
					{
						string hardwareId = LicenseManager.GetHardwareId();
						if (!licenseInfo.IsValid(hardwareId))
						{
							if (!string.IsNullOrEmpty(licenseInfo.HardwareID) && !string.Equals(licenseInfo.HardwareID, hardwareId, StringComparison.OrdinalIgnoreCase))
							{
								errorMessage = "License ini terikat ke PC lain (Hardware ID berbeda).";
							}
							else if (!licenseInfo.Permanent && licenseInfo.ExpiryDate < DateTime.Now.Date)
							{
								errorMessage = "License sudah expired.";
							}
							else
							{
								errorMessage = "License tidak valid.";
							}
							result = false;
						}
						else
						{
							string licenseFilePath = LicenseManager.GetLicenseFilePath();
							string licenseFolderPath = LicenseManager.GetLicenseFolderPath();
							if (!Directory.Exists(licenseFolderPath))
							{
								Directory.CreateDirectory(licenseFolderPath);
							}
							File.Copy(sourceLicPath, licenseFilePath, true);
							StringBuilder stringBuilder = new StringBuilder();
							stringBuilder.AppendLine("Activated at " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
							stringBuilder.AppendLine("HardwareID=" + hardwareId);
							stringBuilder.AppendLine("Key=" + licenseInfo.Key);
							stringBuilder.AppendLine();
							File.WriteAllText(LicenseManager.GetActivationFlagPath(), stringBuilder.ToString());
							result = true;
						}
					}
				}
			}
			catch (Exception ex)
			{
				errorMessage = "Error aktivasi: " + ex.Message;
				result = false;
			}
			return result;
		}

		// Token: 0x0600107C RID: 4220 RVA: 0x000777CC File Offset: 0x000777CC
		public static void Deactivate()
		{
			try
			{
				string activationFlagPath = LicenseManager.GetActivationFlagPath();
				if (File.Exists(activationFlagPath))
				{
					File.Delete(activationFlagPath);
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600107D RID: 4221 RVA: 0x00077804 File Offset: 0x00077804
		public static string GetLicenseSummary()
		{
			LicenseManager.LicenseInfo licenseInfo;
			string text;
			if (!LicenseManager.IsActivated(out licenseInfo, out text))
			{
				return "NOT ACTIVATED";
			}
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("Licensed to : " + licenseInfo.Customer);
			stringBuilder.AppendLine("Type        : " + licenseInfo.Type);
			stringBuilder.AppendLine("Key         : " + licenseInfo.Key);
			stringBuilder.AppendLine("Expiry      : " + (licenseInfo.Permanent ? "PERMANENT" : licenseInfo.ExpiryDate.ToString("dd MMM yyyy")));
			stringBuilder.AppendLine("Hardware ID : " + licenseInfo.HardwareID);
			return stringBuilder.ToString();
		}

		// Token: 0x0600107F RID: 4223 RVA: 0x000778B8 File Offset: 0x000778B8
		public static string GenerateLicenseKey(string customer, string hwId, string expiry, string type)
		{
			if (customer == null)
			{
				customer = "";
			}
			if (hwId == null)
			{
				hwId = "";
			}
			if (expiry == null)
			{
				expiry = "";
			}
			if (type == null)
			{
				type = "";
			}
			string s = string.Format("{0}|{1}|{2}|{3}|{4}", new object[]
			{
				customer,
				hwId,
				expiry,
				type,
				DateTime.Now.Ticks
			});
			string text;
			using (SHA256 sha = SHA256.Create())
			{
				byte[] bytes = Encoding.UTF8.GetBytes(s);
				text = Convert.ToBase64String(sha.ComputeHash(bytes)).Replace("/", "").Replace("+", "").Replace("=", "");
				if (text.Length < 24)
				{
					text = text.PadRight(24, '0');
				}
				text = text.Substring(0, 24);
			}
			string text2;
			if (type == "Standard")
			{
				text2 = "STD";
			}
			else if (type == "Premium")
			{
				text2 = "PRM";
			}
			else if (type == "Professional")
			{
				text2 = "PRO";
			}
			else if (type == "Lifetime")
			{
				text2 = "LIF";
			}
			else
			{
				text2 = "STD";
			}
			return string.Format("{0}-{1}-{2}-{3}-{4}", new object[]
			{
				text2,
				text.Substring(0, 4),
				text.Substring(4, 4),
				text.Substring(8, 4),
				text.Substring(12, 4)
			}).ToUpperInvariant();
		}

		// Token: 0x0400171A RID: 5914
		public const string LICENSE_FOLDER = "licenses";

		// Token: 0x0400171B RID: 5915
		public const string LICENSE_FILE = "honda_flash.lic";

		// Token: 0x0400171C RID: 5916
		public const string ACTIVATION_FLAG = "activated.dat";

		// Token: 0x0400171D RID: 5917
		private static readonly string[] VALID_PREFIX = new string[]
		{
			"STD",
			"PRM",
			"PRO",
			"LIF"
		};

		// Token: 0x02000717 RID: 1815
		public class LicenseInfo
		{
			// Token: 0x06001080 RID: 4224 RVA: 0x00077A50 File Offset: 0x00077A50
			public bool IsValid(string currentHW)
			{
				return !string.IsNullOrEmpty(this.Key) && LicenseManager.ValidateKeyFormat(this.Key) && (string.IsNullOrEmpty(this.HardwareID) || string.IsNullOrEmpty(currentHW) || string.Equals(this.HardwareID, currentHW, StringComparison.OrdinalIgnoreCase)) && (this.Permanent || !(this.ExpiryDate < DateTime.Now.Date));
			}

			// Token: 0x06001081 RID: 4225 RVA: 0x00077AC8 File Offset: 0x00077AC8
			public LicenseInfo()
			{
				this.Key = "";
				this.Customer = "";
				this.HardwareID = "";
				this.Type = "Standard";
				this.Permanent = false;
				this.ExpiryDate = DateTime.Now;
				this.GeneratedAt = DateTime.Now;
			}

			// Token: 0x0400171E RID: 5918
			public string Key = "";

			// Token: 0x0400171F RID: 5919
			public string Customer = "";

			// Token: 0x04001720 RID: 5920
			public string HardwareID = "";

			// Token: 0x04001721 RID: 5921
			public string Type = "Standard";

			// Token: 0x04001722 RID: 5922
			public bool Permanent;

			// Token: 0x04001723 RID: 5923
			public DateTime ExpiryDate = DateTime.Now;

			// Token: 0x04001724 RID: 5924
			public DateTime GeneratedAt = DateTime.Now;
		}
	}
}
