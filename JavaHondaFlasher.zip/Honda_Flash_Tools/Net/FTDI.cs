﻿using System;
using System.Runtime.InteropServices;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000354 RID: 852
	public class FTDI
	{
		// Token: 0x06000B64 RID: 2916
		[DllImport("ftd2xx.dll")]
		public static extern FTDI.FT_STATUS FT_Open(uint deviceNumber, ref IntPtr handle);

		// Token: 0x06000B65 RID: 2917
		[DllImport("ftd2xx.dll")]
		public static extern FTDI.FT_STATUS FT_Close(IntPtr handle);

		// Token: 0x06000B66 RID: 2918
		[DllImport("ftd2xx.dll")]
		public static extern FTDI.FT_STATUS FT_Write(IntPtr handle, byte[] buffer, uint bytesToWrite, ref uint bytesWritten);

		// Token: 0x06000B67 RID: 2919
		[DllImport("ftd2xx.dll")]
		public static extern FTDI.FT_STATUS FT_Read(IntPtr handle, byte[] buffer, uint bytesToRead, ref uint bytesRead);

		// Token: 0x06000B68 RID: 2920
		[DllImport("ftd2xx.dll")]
		public static extern FTDI.FT_STATUS FT_SetBaudRate(IntPtr handle, uint baudRate);

		// Token: 0x06000B69 RID: 2921
		[DllImport("ftd2xx.dll")]
		public static extern FTDI.FT_STATUS FT_SetDataCharacteristics(IntPtr handle, byte wordLength, byte stopBits, byte parity);

		// Token: 0x06000B6A RID: 2922
		[DllImport("ftd2xx.dll")]
		public static extern FTDI.FT_STATUS FT_SetTimeouts(IntPtr handle, uint readTimeout, uint writeTimeout);

		// Token: 0x06000B6B RID: 2923
		[DllImport("ftd2xx.dll")]
		public static extern FTDI.FT_STATUS FT_SetLatencyTimer(IntPtr handle, byte timer);

		// Token: 0x06000B6C RID: 2924
		[DllImport("ftd2xx.dll")]
		public static extern FTDI.FT_STATUS FT_SetBitMode(IntPtr handle, byte mask, byte mode);

		// Token: 0x06000B6D RID: 2925
		[DllImport("ftd2xx.dll")]
		public static extern FTDI.FT_STATUS FT_Purge(IntPtr handle, uint mask);

		// Token: 0x06000B6E RID: 2926
		[DllImport("ftd2xx.dll")]
		public static extern FTDI.FT_STATUS FT_GetQueueStatus(IntPtr handle, ref uint bytesInQueue);

		// Token: 0x02000355 RID: 853
		public enum FT_STATUS
		{
			// Token: 0x04000CC5 RID: 3269
			FT_OK,
			// Token: 0x04000CC6 RID: 3270
			FT_INVALID_HANDLE,
			// Token: 0x04000CC7 RID: 3271
			FT_DEVICE_NOT_FOUND,
			// Token: 0x04000CC8 RID: 3272
			FT_DEVICE_NOT_OPENED,
			// Token: 0x04000CC9 RID: 3273
			FT_IO_ERROR,
			// Token: 0x04000CCA RID: 3274
			FT_INSUFFICIENT_RESOURCES,
			// Token: 0x04000CCB RID: 3275
			FT_INVALID_PARAMETER,
			// Token: 0x04000CCC RID: 3276
			FT_INVALID_BAUD_RATE,
			// Token: 0x04000CCD RID: 3277
			FT_DEVICE_NOT_OPENED_FOR_ERASE,
			// Token: 0x04000CCE RID: 3278
			FT_DEVICE_NOT_OPENED_FOR_WRITE,
			// Token: 0x04000CCF RID: 3279
			FT_FAILED_TO_WRITE_DEVICE,
			// Token: 0x04000CD0 RID: 3280
			FT_EEPROM_READ_FAILED,
			// Token: 0x04000CD1 RID: 3281
			FT_EEPROM_WRITE_FAILED,
			// Token: 0x04000CD2 RID: 3282
			FT_EEPROM_ERASE_FAILED,
			// Token: 0x04000CD3 RID: 3283
			FT_EEPROM_NOT_PRESENT,
			// Token: 0x04000CD4 RID: 3284
			FT_EEPROM_NOT_PROGRAMMED,
			// Token: 0x04000CD5 RID: 3285
			FT_INVALID_ARGS,
			// Token: 0x04000CD6 RID: 3286
			FT_NOT_SUPPORTED,
			// Token: 0x04000CD7 RID: 3287
			FT_OTHER_ERROR
		}
	}
}
