﻿using System;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020009D5 RID: 2517
	public class NeonRoundedRichTextBox : RichTextBox
	{
		// Token: 0x170001F2 RID: 498
		// (get) Token: 0x06001B6A RID: 7018 RVA: 0x0001055D File Offset: 0x0001055D
		// (set) Token: 0x06001B6B RID: 7019 RVA: 0x00010565 File Offset: 0x00010565
		public bool AutoScrollToEnd { get; set; } = true;

		// Token: 0x06001B6C RID: 7020 RVA: 0x0001056E File Offset: 0x0001056E
		public NeonRoundedRichTextBox()
		{
			base.BorderStyle = BorderStyle.None;
			base.ScrollBars = RichTextBoxScrollBars.Vertical;
			this.DoubleBuffered = true;
			base.TextChanged += delegate(object s, EventArgs e)
			{
				if (this.AutoScrollToEnd && !base.IsDisposed)
				{
					base.SelectionStart = this.TextLength;
					base.ScrollToCaret();
				}
			};
		}
	}
}
