﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000538 RID: 1336
	public partial class MainForm : Form
	{
		// Token: 0x06000D3F RID: 3391 RVA: 0x0000948E File Offset: 0x0000948E
		public MainForm()
		{
			this.components = new Container();
			this.InitializeComponent();
			this.ApplyRoundedFormRegion();
			this.ApplyHeaderAndDrag();
		}

		// Token: 0x06000D40 RID: 3392 RVA: 0x00063D24 File Offset: 0x00063D24
		public static int Decrypt(string xdfPath, ref string openPassword, ref string modifiyPassword, ref string unlocked)
		{
			UIntPtr zero = UIntPtr.Zero;
			UIntPtr zero2 = UIntPtr.Zero;
			UIntPtr zero3 = UIntPtr.Zero;
			string s = "$9Ad0$!#*)1QqPow^";
			byte[] bytes = Encoding.ASCII.GetBytes(s);
			checked
			{
				int result;
				try
				{
					byte[] array = File.ReadAllBytes(xdfPath);
					if (array[0] == 5 && array[1] == 34 && array[2] == 151)
					{
						byte[] array2 = new byte[array.Length - 264];
						Array.Copy(array, 264, array2, 0, array.Length - 264);
						uint num = (uint)(array.Length - 264);
						if (!MainForm.Crypto.CryptAcquireContext(ref zero, "TunerPro", "Microsoft Enhanced Cryptographic Provider v1.0", 1U, 0U))
						{
							return -1;
						}
						if (!MainForm.Crypto.CryptCreateHash(zero, 32771U, UIntPtr.Zero, 0U, ref zero2) || !MainForm.Crypto.CryptHashData(zero2, bytes, (uint)bytes.Length, 0U) || !MainForm.Crypto.CryptDeriveKey(zero, 26625U, zero2, 1U, ref zero3))
						{
							return -1;
						}
						if (!MainForm.Crypto.CryptDecrypt(zero3, UIntPtr.Zero, true, 0U, array2, ref num))
						{
							return -1;
						}
						foreach (string text in Encoding.GetEncoding(1252).GetString(array2, 0, (int)num).Replace("\r", "").Split(new char[]
						{
							'\n'
						}))
						{
							if (text.Contains("<openpassword>") && text.Contains("</openpassword>"))
							{
								int num2 = text.IndexOf("<openpassword>") + 14;
								int num3 = text.IndexOf("</openpassword>");
								if (num2 >= 0 && num3 > num2)
								{
									openPassword = text.Substring(num2, num3 - num2);
								}
							}
							else if (text.Contains("<modifypassword>") && text.Contains("</modifypassword>"))
							{
								int num4 = text.IndexOf("<modifypassword>") + 16;
								int num5 = text.IndexOf("</modifypassword>");
								if (num4 >= 0 && num5 > num4)
								{
									modifiyPassword = text.Substring(num4, num5 - num4);
								}
							}
							else
							{
								string text2 = text;
								if (!string.IsNullOrEmpty(text2))
								{
									if (text2.Contains("<flags>0x"))
									{
										text2 = "    <flags>0x1</flags>";
									}
									unlocked = unlocked + text2 + "\r\n";
								}
							}
						}
						result = 1;
					}
					else
					{
						result = 0;
					}
				}
				catch (SystemException)
				{
					return -1;
				}
				return result;
			}
		}

		// Token: 0x06000D41 RID: 3393 RVA: 0x00063FA0 File Offset: 0x00063FA0
		private void BtnSelectXdf_Click(object sender, EventArgs e)
		{
			this.TbXdfPath.Text = string.Empty;
			this.TbOpenPassword.Text = string.Empty;
			this.TbModifyPassword.Text = string.Empty;
			this.TbUnlockedXDF.Text = string.Empty;
			this.BtnDecrypt.Enabled = true;
			this.BtnSaveUnlockedXdf.Enabled = true;
			this.BtnRemovePassword.Enabled = false;
			this.BtnChangePassword.Enabled = false;
			OpenFileDialog openFileDialog = new OpenFileDialog
			{
				Title = "Select file XDF ADX",
				Multiselect = false,
				Filter = "XDF file |*.xdf|ADX file|*.adx"
			};
			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
				try
				{
					byte[] array = File.ReadAllBytes(openFileDialog.FileName);
					if (array[0] == 5 && array[1] == 34 && array[2] == 151)
					{
						this.TbXdfPath.Text = openFileDialog.FileName;
						this.BtnDecrypt.Enabled = true;
					}
					else
					{
						CustomMessageBox__0.Show("File " + Path.GetFileName(openFileDialog.FileName) + " tidak berpassword\r\nMohon pilih file XDF berpassword untuk di Dekripsi", "Info", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
				catch (SystemException ex)
				{
					CustomMessageBox__0.Show("Gagal membuka file " + Path.GetFileName(openFileDialog.FileName) + "\r\nDetail error:\r\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
				}
			}
		}

		// Token: 0x06000D42 RID: 3394 RVA: 0x000640F8 File Offset: 0x000640F8
		private void BtnDecrypt_Click(object sender, EventArgs e)
		{
			string empty = string.Empty;
			string empty2 = string.Empty;
			string empty3 = string.Empty;
			this.TbOpenPassword.Text = empty;
			this.TbModifyPassword.Text = empty2;
			this.TbUnlockedXDF.Text = empty3;
			this.BtnSaveUnlockedXdf.Enabled = false;
			this.BtnRemovePassword.Enabled = false;
			this.BtnChangePassword.Enabled = false;
			if (this.TbXdfPath.Text.Equals(string.Empty))
			{
				return;
			}
			switch (MainForm.Decrypt(this.TbXdfPath.Text, ref empty, ref empty2, ref empty3))
			{
			case -1:
				CustomMessageBox__0.Show("File " + Path.GetFileName(this.TbXdfPath.Text) + " gagal di Dekripsi", "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
				return;
			case 0:
				CustomMessageBox__0.Show("File " + Path.GetFileName(this.TbXdfPath.Text) + " tidak berpassword\r\nMohon pilih file XDF berpassword untuk di Dekripsi", "Info", MessageBoxButtons.OK, MessageBoxIcon.None);
				return;
			case 1:
				this.TbOpenPassword.Text = empty;
				this.TbModifyPassword.Text = empty2;
				this.TbUnlockedXDF.Text = empty3;
				this.BtnSaveUnlockedXdf.Enabled = true;
				this.BtnRemovePassword.Enabled = true;
				this.BtnChangePassword.Enabled = true;
				CustomMessageBox__0.Show("File " + Path.GetFileName(this.TbXdfPath.Text) + " berhasil di Dekripsi", "Info", MessageBoxButtons.OK, MessageBoxIcon.None);
				return;
			default:
				return;
			}
		}

		// Token: 0x06000D43 RID: 3395 RVA: 0x00064274 File Offset: 0x00064274
		private void BtnRemovePassword_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(this.TbUnlockedXDF.Text))
			{
				CustomMessageBox__0.Show("Tidak ada konten XDF untuk diproses. Dekripsi file terlebih dahulu.", "Info", MessageBoxButtons.OK, MessageBoxIcon.None);
				return;
			}
			try
			{
				string contents = this.ProcessPasswordRemoval(this.TbUnlockedXDF.Text);
				SaveFileDialog saveFileDialog = new SaveFileDialog
				{
					Title = "Simpan file XDF tanpa Password",
					Filter = "XDF file |*.xdf|ADX file|*.adx",
					FileName = Path.GetFileNameWithoutExtension(this.TbXdfPath.Text) + "_no_password.xdf"
				};
				if (saveFileDialog.ShowDialog() == DialogResult.OK)
				{
					File.WriteAllText(saveFileDialog.FileName, contents, Encoding.GetEncoding(1252));
					CustomMessageBox__0.Show("File berhasil disimpan tanpa password.", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.None);
				}
			}
			catch (Exception ex)
			{
				CustomMessageBox__0.Show("Gagal menghapus password: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
			}
		}

		// Token: 0x06000D44 RID: 3396 RVA: 0x00064358 File Offset: 0x00064358
		private void BtnChangePassword_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(this.TbUnlockedXDF.Text))
			{
				CustomMessageBox__0.Show("Tidak ada konten XDF untuk diproses. Dekripsi file terlebih dahulu.", "Info", MessageBoxButtons.OK, MessageBoxIcon.None);
				return;
			}
			using (MainForm.PasswordDialog passwordDialog = new MainForm.PasswordDialog())
			{
				if (passwordDialog.ShowDialog() == DialogResult.OK)
				{
					try
					{
						string openPassword = passwordDialog.OpenPassword;
						string modifyPassword = passwordDialog.ModifyPassword;
						string contents = this.ProcessPasswordChange(this.TbUnlockedXDF.Text, openPassword, modifyPassword);
						SaveFileDialog saveFileDialog = new SaveFileDialog
						{
							Title = "Simpan file XDF dengan Password Baru",
							Filter = "XDF file |*.xdf|ADX file|*.adx",
							FileName = Path.GetFileNameWithoutExtension(this.TbXdfPath.Text) + "_new_password.xdf"
						};
						if (saveFileDialog.ShowDialog() == DialogResult.OK)
						{
							File.WriteAllText(saveFileDialog.FileName, contents, Encoding.GetEncoding(1252));
							CustomMessageBox__0.Show("File berhasil disimpan dengan password baru.", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.None);
						}
					}
					catch (Exception ex)
					{
						CustomMessageBox__0.Show("Gagal mengganti password: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
			}
		}

		// Token: 0x06000D45 RID: 3397 RVA: 0x0006447C File Offset: 0x0006447C
		private string ProcessPasswordRemoval(string content)
		{
			StringBuilder stringBuilder = new StringBuilder();
			bool flag = false;
			bool flag2 = false;
			foreach (string text in content.Split(new string[]
			{
				"\r\n",
				"\r",
				"\n"
			}, StringSplitOptions.None))
			{
				string text2 = text.Trim();
				if (text2.StartsWith("<openpassword>"))
				{
					flag = true;
				}
				else if (text2.EndsWith("</openpassword>"))
				{
					flag = false;
				}
				else if (text2.StartsWith("<modifypassword>"))
				{
					flag2 = true;
				}
				else if (text2.EndsWith("</modifypassword>"))
				{
					flag2 = false;
				}
				if (!flag && !flag2)
				{
					if (text2.Contains("<flags>0x"))
					{
						stringBuilder.AppendLine("    <flags>0x0</flags>");
					}
					else
					{
						stringBuilder.AppendLine(text);
					}
				}
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06000D46 RID: 3398 RVA: 0x00064558 File Offset: 0x00064558
		private string ProcessPasswordChange(string content, string newOpenPass, string newModifyPass)
		{
			string text = this.ProcessPasswordRemoval(content);
			StringBuilder stringBuilder = new StringBuilder();
			bool flag = false;
			checked
			{
				foreach (string text2 in text.Split(new string[]
				{
					"\r\n",
					"\r",
					"\n"
				}, StringSplitOptions.None))
				{
					string text3 = text2.Trim();
					stringBuilder.AppendLine(text2);
					if (text3 == "<XDFHEADER>")
					{
						flag = true;
					}
					else if (text3.Contains("<flags>0x") && flag)
					{
						stringBuilder.Remove(stringBuilder.Length - text2.Length - 2, text2.Length + 2);
						stringBuilder.AppendLine("    <flags>0x1</flags>");
					}
					else if (text3 == "</XDFHEADER>" && flag)
					{
						stringBuilder.Remove(stringBuilder.Length - text2.Length - 2, text2.Length + 2);
						if (!string.IsNullOrEmpty(newOpenPass))
						{
							stringBuilder.AppendLine("    <openpassword>" + newOpenPass + "</openpassword>");
						}
						if (!string.IsNullOrEmpty(newModifyPass))
						{
							stringBuilder.AppendLine("    <modifypassword>" + newModifyPass + "</modifypassword>");
						}
						stringBuilder.AppendLine(text2);
						flag = false;
					}
				}
				return stringBuilder.ToString();
			}
		}

		// Token: 0x06000D47 RID: 3399 RVA: 0x00064698 File Offset: 0x00064698
		private void MainForm_Load(object sender, EventArgs e)
		{
			this.TbXdfPath.Text = string.Empty;
			this.TbUnlockedXDF.Text = string.Empty;
			this.BtnDecrypt.Enabled = true;
			this.BtnSaveUnlockedXdf.Enabled = true;
			this.BtnRemovePassword.Enabled = false;
			this.BtnChangePassword.Enabled = false;
		}

		// Token: 0x06000D48 RID: 3400 RVA: 0x000646F8 File Offset: 0x000646F8
		private void BtnSaveUnlockedXdf_Click(object sender, EventArgs e)
		{
			if (!string.IsNullOrEmpty(this.TbUnlockedXDF.Text))
			{
				SaveFileDialog saveFileDialog = new SaveFileDialog
				{
					Title = "Simpan file XDF ADX",
					Filter = "XDF file |*.xdf|ADX file|*.adx"
				};
				if (saveFileDialog.ShowDialog() == DialogResult.OK)
				{
					try
					{
						File.WriteAllText(saveFileDialog.FileName, this.TbUnlockedXDF.Text, Encoding.GetEncoding(1252));
						CustomMessageBox__0.Show("File " + Path.GetFileName(saveFileDialog.FileName) + " berhasil disimpan\r\n", "Info", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
					catch (SystemException ex)
					{
						CustomMessageBox__0.Show("Gagal menyimpan file " + Path.GetFileName(saveFileDialog.FileName) + "\r\nDetail error:\r\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.None);
					}
				}
			}
		}

		// Token: 0x06000D4B RID: 3403 RVA: 0x0004D38C File Offset: 0x0004D38C
		private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = radius * 2;
			graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x06000D4C RID: 3404 RVA: 0x000656AC File Offset: 0x000656AC
		private void ApplyRoundedFormRegion()
		{
			using (GraphicsPath roundedPath = this.GetRoundedPath(new Rectangle(0, 0, base.Width, base.Height), 14))
			{
				base.Region = new Region(roundedPath);
			}
		}

		// Token: 0x06000D4D RID: 3405 RVA: 0x00065700 File Offset: 0x00065700
		private void ApplyHeaderAndDrag()
		{
			RoundedButton roundedButton = new RoundedButton
			{
				Text = "✕",
				Size = new Size(28, 28),
				Location = new Point(base.Width - 44, 28),
				BackColor = MainForm.BgSurface,
				ForeColor = MainForm.AccentSoft,
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				Cursor = Cursors.Hand,
				TabStop = false,
				Anchor = (AnchorStyles.Top | AnchorStyles.Right),
				CornerRadius = 14,
				BorderColor = MainForm.BorderSoft,
				BorderWidth = 1f,
				HoverBackColor = Color.FromArgb(220, 50, 50)
			};
			roundedButton.Click += delegate(object s, EventArgs e)
			{
				this.Close();
			};
			base.Controls.Add(roundedButton);
			roundedButton.BringToFront();
			bool dragging = false;
			Point dragStart = Point.Empty;
			base.MouseDown += delegate(object s, MouseEventArgs e)
			{
				if (e.Button == MouseButtons.Left && e.Y <= 70)
				{
					dragging = true;
					dragStart = e.Location;
				}
			};
			base.MouseMove += delegate(object s, MouseEventArgs e)
			{
				if (dragging)
				{
					this.Location = new Point(this.Location.X + e.X - dragStart.X, this.Location.Y + e.Y - dragStart.Y);
				}
			};
			base.MouseUp += delegate(object s, MouseEventArgs e)
			{
				dragging = false;
			};
			base.KeyPreview = true;
			base.KeyDown += delegate(object s, KeyEventArgs e)
			{
				if (e.KeyCode == Keys.Escape)
				{
					this.Close();
				}
			};
			base.Paint += delegate(object s, PaintEventArgs e)
			{
				Graphics graphics = e.Graphics;
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				graphics.PixelOffsetMode = PixelOffsetMode.Half;
				int width = this.ClientSize.Width;
				int height = this.ClientSize.Height;
				using (Pen pen = new Pen(Color.FromArgb(80, MainForm.Accent), 3f))
				{
					using (GraphicsPath roundedPath = this.GetRoundedPath(new Rectangle(2, 2, width - 4, height - 4), 12))
					{
						graphics.DrawPath(pen, roundedPath);
					}
				}
				using (Pen pen2 = new Pen(MainForm.Accent, 1.5f))
				{
					using (GraphicsPath roundedPath2 = this.GetRoundedPath(new Rectangle(2, 2, width - 4, height - 4), 12))
					{
						graphics.DrawPath(pen2, roundedPath2);
					}
				}
				using (Pen pen3 = new Pen(MainForm.BorderSoft, 1f))
				{
					using (GraphicsPath roundedPath3 = this.GetRoundedPath(new Rectangle(4, 4, width - 8, height - 8), 10))
					{
						graphics.DrawPath(pen3, roundedPath3);
					}
				}
			};
			base.Resize += delegate(object s, EventArgs e)
			{
				this.ApplyRoundedFormRegion();
				this.Invalidate();
			};
		}

		// Token: 0x040011A3 RID: 4515
		private static readonly Color PlaceholderColor = Color.FromArgb(110, 120, 140);

		// Token: 0x040011A4 RID: 4516
		private static readonly Color Success = Color.FromArgb(74, 222, 128);

		// Token: 0x040011A5 RID: 4517
		private static readonly Color Warning = Color.FromArgb(250, 204, 21);

		// Token: 0x040011A6 RID: 4518
		private static readonly Color Danger = Color.FromArgb(248, 113, 113);

		// Token: 0x02000539 RID: 1337
		public static class Crypto
		{
			// Token: 0x06000D4F RID: 3407
			[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
			public static extern bool CryptAcquireContext(ref UIntPtr hProv, string pszContainer, string pszProvider, uint dwProvType, uint dwFlags);

			// Token: 0x06000D50 RID: 3408
			[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
			public static extern bool CryptCreateHash(UIntPtr hProv, uint Algid, UIntPtr hKey, uint dwFlags, ref UIntPtr phHash);

			// Token: 0x06000D51 RID: 3409
			[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
			public static extern bool CryptHashData(UIntPtr hHash, byte[] pbData, uint dwDataLen, uint dwFlags);

			// Token: 0x06000D52 RID: 3410
			[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
			public static extern bool CryptDeriveKey(UIntPtr hProv, uint Algid, UIntPtr hBaseData, uint dwFlags, ref UIntPtr phKey);

			// Token: 0x06000D53 RID: 3411
			[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
			public static extern bool CryptDecrypt(UIntPtr hKey, UIntPtr hHash, bool Final, uint dwFlags, byte[] pbData, ref uint pdwDataLen);
		}

		// Token: 0x0200053A RID: 1338
		public class PasswordDialog : Form
		{
			// Token: 0x1700002F RID: 47
			// (get) Token: 0x06000D54 RID: 3412 RVA: 0x000094D2 File Offset: 0x000094D2
			// (set) Token: 0x06000D55 RID: 3413 RVA: 0x000094DA File Offset: 0x000094DA
			public string OpenPassword { get; private set; }

			// Token: 0x17000030 RID: 48
			// (get) Token: 0x06000D56 RID: 3414 RVA: 0x000094E3 File Offset: 0x000094E3
			// (set) Token: 0x06000D57 RID: 3415 RVA: 0x000094EB File Offset: 0x000094EB
			public string ModifyPassword { get; private set; }

			// Token: 0x06000D58 RID: 3416 RVA: 0x000094F4 File Offset: 0x000094F4
			public PasswordDialog()
			{
				this.InitializeComponent();
				this.ApplyRoundedRegion();
				this.ApplyDragAndEsc();
			}

			// Token: 0x06000D59 RID: 3417 RVA: 0x00065970 File Offset: 0x00065970
			private void InitializeComponent()
			{
				this.lblOpenPassword = new Label();
				this.lblModifyPassword = new Label();
				this.tbOpenPassword = new TextBox();
				this.tbModifyPassword = new TextBox();
				this.btnOK = new RoundedButton();
				this.btnCancel = new RoundedButton();
				this.btnCloseX = new RoundedButton();
				base.SuspendLayout();
				this.Text = "Change Password";
				base.ClientSize = new Size(440, 260);
				base.FormBorderStyle = FormBorderStyle.None;
				base.StartPosition = FormStartPosition.CenterParent;
				this.BackColor = MainForm.BgBase;
				this.ForeColor = MainForm.TextPrimary;
				base.KeyPreview = true;
				base.Padding = new Padding(4);
				this.btnCloseX.Text = "✕";
				this.btnCloseX.Size = new Size(28, 28);
				this.btnCloseX.Location = new Point(base.ClientSize.Width - 44, 24);
				this.btnCloseX.BackColor = MainForm.BgSurface;
				this.btnCloseX.ForeColor = MainForm.AccentSoft;
				this.btnCloseX.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
				this.btnCloseX.Cursor = Cursors.Hand;
				this.btnCloseX.TabStop = false;
				this.btnCloseX.CornerRadius = 14;
				this.btnCloseX.BorderColor = MainForm.BorderSoft;
				this.btnCloseX.BorderWidth = 1f;
				this.btnCloseX.HoverBackColor = Color.FromArgb(220, 50, 50);
				this.btnCloseX.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
				this.btnCloseX.Click += delegate(object s, EventArgs e)
				{
					base.DialogResult = DialogResult.Cancel;
					base.Close();
				};
				Label label = new Label();
				label.Text = "\ud83d\udd11  CHANGE PASSWORD";
				label.Font = new Font("Segoe UI", 13f, FontStyle.Bold);
				label.ForeColor = MainForm.Accent;
				label.BackColor = Color.Transparent;
				label.AutoSize = true;
				label.Location = new Point(24, 22);
				Label label2 = new Label();
				label2.Text = "Set new open & modify password";
				label2.Font = new Font("Segoe UI", 8f, FontStyle.Italic);
				label2.ForeColor = MainForm.TextMuted;
				label2.BackColor = Color.Transparent;
				label2.AutoSize = true;
				label2.Location = new Point(26, 50);
				Panel panel = new Panel();
				panel.BackColor = MainForm.BorderSoft;
				panel.Location = new Point(24, 74);
				panel.Size = new Size(392, 1);
				this.lblOpenPassword.Text = "OPEN PASSWORD";
				this.lblOpenPassword.Location = new Point(24, 90);
				this.lblOpenPassword.AutoSize = false;
				this.lblOpenPassword.Size = new Size(200, 14);
				this.lblOpenPassword.ForeColor = MainForm.TextMuted;
				this.lblOpenPassword.Font = new Font("Segoe UI", 7.5f, FontStyle.Bold);
				this.tbOpenPassword.Location = new Point(24, 108);
				this.tbOpenPassword.Size = new Size(392, 22);
				this.tbOpenPassword.BackColor = MainForm.BgInput;
				this.tbOpenPassword.ForeColor = MainForm.TextPrimary;
				this.tbOpenPassword.Font = new Font("Consolas", 9f);
				this.tbOpenPassword.BorderStyle = BorderStyle.FixedSingle;
				this.lblModifyPassword.Text = "MODIFY PASSWORD";
				this.lblModifyPassword.Location = new Point(24, 140);
				this.lblModifyPassword.AutoSize = false;
				this.lblModifyPassword.Size = new Size(200, 14);
				this.lblModifyPassword.ForeColor = MainForm.TextMuted;
				this.lblModifyPassword.Font = new Font("Segoe UI", 7.5f, FontStyle.Bold);
				this.tbModifyPassword.Location = new Point(24, 158);
				this.tbModifyPassword.Size = new Size(392, 22);
				this.tbModifyPassword.BackColor = MainForm.BgInput;
				this.tbModifyPassword.ForeColor = MainForm.TextPrimary;
				this.tbModifyPassword.Font = new Font("Consolas", 9f);
				this.tbModifyPassword.BorderStyle = BorderStyle.FixedSingle;
				this.btnOK.Text = "✔  OK";
				this.btnOK.Location = new Point(216, 200);
				this.btnOK.Size = new Size(96, 34);
				this.btnOK.BackColor = MainForm.Accent;
				this.btnOK.ForeColor = Color.FromArgb(10, 15, 25);
				this.btnOK.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
				this.btnOK.CornerRadius = 10;
				this.btnOK.BorderColor = Color.Transparent;
				this.btnOK.BorderWidth = 0f;
				this.btnOK.HoverBackColor = Color.FromArgb(0, 200, 230);
				this.btnOK.Cursor = Cursors.Hand;
				this.btnOK.Click += this.btnOK_Click;
				this.btnCancel.Text = "✕  CANCEL";
				this.btnCancel.Location = new Point(320, 200);
				this.btnCancel.Size = new Size(96, 34);
				this.btnCancel.BackColor = MainForm.BgSurface;
				this.btnCancel.ForeColor = MainForm.AccentSoft;
				this.btnCancel.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
				this.btnCancel.CornerRadius = 10;
				this.btnCancel.BorderColor = MainForm.BorderSoft;
				this.btnCancel.BorderWidth = 1f;
				this.btnCancel.HoverBackColor = Color.FromArgb(0, 60, 70);
				this.btnCancel.Cursor = Cursors.Hand;
				this.btnCancel.Click += this.btnCancel_Click;
				base.Controls.Add(this.btnCloseX);
				base.Controls.Add(label);
				base.Controls.Add(label2);
				base.Controls.Add(panel);
				base.Controls.Add(this.lblOpenPassword);
				base.Controls.Add(this.tbOpenPassword);
				base.Controls.Add(this.lblModifyPassword);
				base.Controls.Add(this.tbModifyPassword);
				base.Controls.Add(this.btnOK);
				base.Controls.Add(this.btnCancel);
				base.ResumeLayout(false);
				base.PerformLayout();
			}

			// Token: 0x06000D5A RID: 3418 RVA: 0x0000950E File Offset: 0x0000950E
			private void btnOK_Click(object sender, EventArgs e)
			{
				this.OpenPassword = this.tbOpenPassword.Text;
				this.ModifyPassword = this.tbModifyPassword.Text;
				base.DialogResult = DialogResult.OK;
				base.Close();
			}

			// Token: 0x06000D5B RID: 3419 RVA: 0x0000953F File Offset: 0x0000953F
			private void btnCancel_Click(object sender, EventArgs e)
			{
				base.DialogResult = DialogResult.Cancel;
				base.Close();
			}

			// Token: 0x06000D5C RID: 3420 RVA: 0x0004D38C File Offset: 0x0004D38C
			private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
			{
				GraphicsPath graphicsPath = new GraphicsPath();
				int num = radius * 2;
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}

			// Token: 0x06000D5D RID: 3421 RVA: 0x0006604C File Offset: 0x0006604C
			private void ApplyRoundedRegion()
			{
				using (GraphicsPath roundedPath = this.GetRoundedPath(new Rectangle(0, 0, base.Width, base.Height), 12))
				{
					base.Region = new Region(roundedPath);
				}
			}

			// Token: 0x06000D5E RID: 3422 RVA: 0x000660A0 File Offset: 0x000660A0
			private void ApplyDragAndEsc()
			{
				bool dragging = false;
				Point dragStart = Point.Empty;
				base.MouseDown += delegate(object s, MouseEventArgs e)
				{
					if (e.Button == MouseButtons.Left && e.Y <= 70)
					{
						dragging = true;
						dragStart = e.Location;
					}
				};
				base.MouseMove += delegate(object s, MouseEventArgs e)
				{
					if (dragging)
					{
						this.Location = new Point(this.Location.X + e.X - dragStart.X, this.Location.Y + e.Y - dragStart.Y);
					}
				};
				base.MouseUp += delegate(object s, MouseEventArgs e)
				{
					dragging = false;
				};
				base.KeyDown += delegate(object s, KeyEventArgs e)
				{
					if (e.KeyCode == Keys.Escape)
					{
						this.DialogResult = DialogResult.Cancel;
						this.Close();
					}
				};
				base.Paint += delegate(object s, PaintEventArgs e)
				{
					Graphics graphics = e.Graphics;
					graphics.SmoothingMode = SmoothingMode.AntiAlias;
					graphics.PixelOffsetMode = PixelOffsetMode.Half;
					int width = this.ClientSize.Width;
					int height = this.ClientSize.Height;
					using (Pen pen = new Pen(Color.FromArgb(80, MainForm.Accent), 3f))
					{
						using (GraphicsPath roundedPath = this.GetRoundedPath(new Rectangle(2, 2, width - 4, height - 4), 12))
						{
							graphics.DrawPath(pen, roundedPath);
						}
					}
					using (Pen pen2 = new Pen(MainForm.Accent, 1.5f))
					{
						using (GraphicsPath roundedPath2 = this.GetRoundedPath(new Rectangle(2, 2, width - 4, height - 4), 12))
						{
							graphics.DrawPath(pen2, roundedPath2);
						}
					}
				};
				base.Resize += delegate(object s, EventArgs e)
				{
					this.ApplyRoundedRegion();
					this.Invalidate();
				};
			}

			// Token: 0x040011AE RID: 4526
			private TextBox tbOpenPassword;

			// Token: 0x040011AF RID: 4527
			private TextBox tbModifyPassword;

			// Token: 0x040011B0 RID: 4528
			private Label lblOpenPassword;

			// Token: 0x040011B1 RID: 4529
			private Label lblModifyPassword;

			// Token: 0x040011B4 RID: 4532
			private RoundedButton btnOK;

			// Token: 0x040011B5 RID: 4533
			private RoundedButton btnCancel;

			// Token: 0x040011B6 RID: 4534
			private RoundedButton btnCloseX;
		}
	}
}
