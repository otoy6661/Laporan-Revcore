﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000357 RID: 855
	public partial class Diag : Form
	{
		// Token: 0x06000B72 RID: 2930 RVA: 0x000514E0 File Offset: 0x000514E0
		public Diag()
		{
			this.InitializeComponent();
			base.MinimizeBox = false;
			base.ControlBox = true;
			this.timer1.Interval = 500;
			this.timer1.Enabled = true;
		}

		// Token: 0x06000B73 RID: 2931 RVA: 0x000086EE File Offset: 0x000086EE
		private void Diag_Load(object sender, EventArgs e)
		{
			this.InitFtdiIso();
			this.InitializeDashboard();
			this.BuildChartPanel();
			base.FormClosing += this.SecondForm_FormClosing;
		}

		// Token: 0x06000B74 RID: 2932 RVA: 0x00051670 File Offset: 0x00051670
		private void dtc()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				115,
				2,
				20
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			byte b = array2[5];
			byte b2 = array2[6];
			byte b3 = array2[7];
			byte b4 = array2[8];
			byte b5 = array2[9];
			byte b6 = array2[10];
			this.Hasil = string.Format("{0}-{1}, {2}-{3}, {4}-{5}", new object[]
			{
				b,
				b2,
				b3,
				b4,
				b5,
				b6
			});
		}

		// Token: 0x06000B75 RID: 2933 RVA: 0x0005171C File Offset: 0x0005171C
		private void dtc2()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				115,
				1,
				21
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			byte b = array2[5];
			byte b2 = array2[6];
			byte b3 = array2[7];
			byte b4 = array2[8];
			byte b5 = array2[9];
			byte b6 = array2[10];
			this.Hasil2 = string.Format("{0}-{1}, {2}-{3}, {4}-{5}", new object[]
			{
				b,
				b2,
				b3,
				b4,
				b5,
				b6
			});
		}

		// Token: 0x06000B76 RID: 2934 RVA: 0x000517C8 File Offset: 0x000517C8
		private void dtc3()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				116,
				2,
				19
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			byte b = array2[5];
			byte b2 = array2[6];
			byte b3 = array2[7];
			byte b4 = array2[8];
			byte b5 = array2[9];
			byte b6 = array2[10];
			this.Hasil3 = string.Format("{0}-{1}, {2}-{3}, {4}-{5}", new object[]
			{
				b,
				b2,
				b3,
				b4,
				b5,
				b6
			});
		}

		// Token: 0x06000B77 RID: 2935 RVA: 0x00051874 File Offset: 0x00051874
		private void dtc4()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				116,
				1,
				20
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			byte b = array2[5];
			byte b2 = array2[6];
			byte b3 = array2[7];
			byte b4 = array2[8];
			byte b5 = array2[9];
			byte b6 = array2[10];
			this.Hasil4 = string.Format("{0}-{1}, {2}-{3}, {4}-{5}", new object[]
			{
				b,
				b2,
				b3,
				b4,
				b5,
				b6
			});
		}

		// Token: 0x06000B78 RID: 2936 RVA: 0x00008715 File Offset: 0x00008715
		private void Gabung(ref string gabung, string hasil1, string hasil2, string hasil3, string hasil4)
		{
			gabung = string.Concat(new string[]
			{
				hasil1,
				", ",
				hasil2,
				", ",
				hasil3,
				", ",
				hasil4
			});
		}

		// Token: 0x06000B79 RID: 2937 RVA: 0x0000874E File Offset: 0x0000874E
		private void ContohPemanggilanGabung()
		{
			this.Gabung(ref this.hasilGabungan, this.Hasil, this.Hasil2, this.Hasil3, this.Hasil4);
			this.DisplayResponse(this.hasilGabungan);
			this.dtcCounter = 1;
			this.dtcTitleAdded = false;
		}

		// Token: 0x06000B7A RID: 2938 RVA: 0x00051920 File Offset: 0x00051920
		private void DisplayResponse(string hasilGabungan)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>
			{
				{
					"1-1",
					"MAP sensor circuit low voltage"
				},
				{
					"1-2",
					"MAP sensor circuit high voltage"
				},
				{
					"2-1",
					"MAP sensor performance problem"
				},
				{
					"7-1",
					"ECT sensor circuit low voltage"
				},
				{
					"7-2",
					"ECT sensor circuit high voltage"
				},
				{
					"8-1",
					"TP sensor circuit low voltage"
				},
				{
					"8-2",
					"TP sensor circuit high voltage"
				},
				{
					"9-1",
					"IAT sensor circuit low voltage"
				},
				{
					"9-2",
					"IAT sensor circuit high voltage"
				},
				{
					"11-1",
					"VS sensor no signal"
				},
				{
					"12-1",
					"No.1 primary injector circuit malfunction"
				},
				{
					"13-1",
					"No.2 primary injector circuit malfunction"
				},
				{
					"14-1",
					"No.3 primary injector circuit malfunction"
				},
				{
					"15-1",
					"No.4 primary injector circuit malfunction"
				},
				{
					"16-1",
					"No.1 secondary injector circuit malfunction"
				},
				{
					"17-1",
					"No.2 secondary injector circuit malfunction"
				},
				{
					"18-1",
					"CMP sensor no signal"
				},
				{
					"19-1",
					"CKP sensor no signal"
				},
				{
					"21-1",
					"O₂ sensor malfunction"
				},
				{
					"23-1",
					"O₂ sensor heater malfunction"
				},
				{
					"25-2",
					"Knock sensor circuit malfunction"
				},
				{
					"25-3",
					"Knock sensor circuit malfunction"
				},
				{
					"29-1",
					"IACV circuit malfunction"
				},
				{
					"33-2",
					"ECM EEPROM malfunction"
				},
				{
					"34-1",
					"ECV POT low voltage malfunction"
				},
				{
					"34-2",
					"ECV POT high voltage malfunction"
				},
				{
					"35-1",
					"EGCA malfunction"
				},
				{
					"48-1",
					"No.3 secondary injector circuit malfunction"
				},
				{
					"49-1",
					"No.4 secondary injector circuit malfunction"
				},
				{
					"51-1",
					"HESD linear solenoid malfunction"
				},
				{
					"54-1",
					"Bank angle sensor circuit low voltage"
				},
				{
					"54-2",
					"Bank angle sensor circuit high voltage"
				},
				{
					"56-1",
					"Knock sensor IC malfunction"
				},
				{
					"57-1",
					"Engine coolant over temperature"
				},
				{
					"57-2",
					"Engine coolant over temperature"
				},
				{
					"86-1",
					"Serial communication malfunction"
				},
				{
					"91-1",
					"Coil Ignition Primary Malfunction"
				},
				{
					"91-2",
					"Coil Ignition Primary Malfunction"
				}
			};
			foreach (string key in hasilGabungan.Split(new string[]
			{
				", "
			}, StringSplitOptions.None))
			{
				string str;
				if (dictionary.TryGetValue(key, out str))
				{
					Console.WriteLine("DTC: " + str);
				}
			}
		}

		// Token: 0x06000B7B RID: 2939 RVA: 0x000026F4 File Offset: 0x000026F4
		private void ShowMessageInListBox(string message)
		{
		}

		// Token: 0x06000B7C RID: 2940 RVA: 0x000026F4 File Offset: 0x000026F4
		private void ClearAllMessages()
		{
		}

		// Token: 0x06000B7D RID: 2941 RVA: 0x000026F4 File Offset: 0x000026F4
		private void rst()
		{
		}

		// Token: 0x06000B7E RID: 2942 RVA: 0x000026F4 File Offset: 0x000026F4
		private void rst1()
		{
		}

		// Token: 0x06000B7F RID: 2943 RVA: 0x000026F4 File Offset: 0x000026F4
		private void rst2()
		{
		}

		// Token: 0x06000B80 RID: 2944 RVA: 0x000026F4 File Offset: 0x000026F4
		private void rst3()
		{
		}

		// Token: 0x06000B81 RID: 2945 RVA: 0x000026F4 File Offset: 0x000026F4
		private void rst4()
		{
		}

		// Token: 0x06000B82 RID: 2946 RVA: 0x00051BD8 File Offset: 0x00051BD8
		private void LoopDat17(CancellationToken token)
		{
			while (!token.IsCancellationRequested)
			{
				if (this.tek11)
				{
					this.dat11();
					this.dat20();
				}
				if (this.tek10)
				{
					this.dat10();
					this.dat20();
				}
				if (this.tek13)
				{
					this.dat13();
					this.dat20();
				}
				if (this.tek16)
				{
					this.dat16();
					this.dat20();
				}
				if (this.tek17)
				{
					this.dat17();
					this.dat20();
				}
				Task.Delay(10, token);
			}
		}

		// Token: 0x06000B83 RID: 2947 RVA: 0x00051C60 File Offset: 0x00051C60
		private void dat10()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				16,
				8
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			if (array2[1] == 5)
			{
				this.tek10 = false;
				return;
			}
			try
			{
				if (array2.Length >= 1)
				{
					int rpm = checked(((int)array2[4] << 8) + (int)array2[5]);
					float tps = (float)array2[6] * 5f / 256f;
					float tps2 = (float)array2[7] / 2f;
					float ect = (float)array2[8] * 5f / 256f;
					float ect2 = (float)(checked(array2[9] - 40));
					float iat = (float)array2[10] * 5f / 256f;
					float iat2 = (float)(checked(array2[11] - 40));
					float map = (float)array2[12] * 5f / 256f;
					int num2 = (int)array2[13];
					float bat = (float)array2[16] / 10f;
					int vss = (int)array2[17];
					float inj = (float)(checked(((int)array2[18] << 8) + (int)array2[19])) / 200f;
					float adv = (float)array2[20] / 2f - 64f;
					this.UpdateGridView(rpm, tps, tps2, ect, ect2, iat, iat2, map, (float)num2, bat, inj, 0, adv, vss, 16, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0, 0f, 0f, 0f, 0);
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding data: " + ex.Message);
			}
		}

		// Token: 0x06000B84 RID: 2948 RVA: 0x00051DFC File Offset: 0x00051DFC
		private void datD1()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				209,
				71
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			try
			{
				this.bas = (this.sss = (this.ssw = (this.ggs = (this.pom = (this.fan = (this.ggv = "OFF"))))));
				this.ggs = "Netral";
				if (array2.Length > 4)
				{
					switch (array2[4])
					{
					case 0:
						this.ggs = "OnGear";
						this.ssw = "OFF";
						this.sss = "OFF";
						break;
					case 1:
						this.bas = "ON";
						this.ggs = "Netral";
						this.ssw = "OFF";
						this.sss = "ON";
						break;
					case 2:
						this.ssw = "ON";
						break;
					default:
						this.ssw = "OFF";
						break;
					}
				}
				if (array2.Length > 8)
				{
					switch (array2[8])
					{
					case 0:
						this.pom = "OFF";
						break;
					case 1:
					case 5:
						this.pom = "ON";
						break;
					case 4:
						this.pom = "OFF";
						break;
					}
					this.fan = (((int)array2[9] < array2.Length) ? ((array2[9] == 1) ? "ON" : "OFF") : "OFF");
					byte b = array2[10];
					if (b <= 16)
					{
						switch (b)
						{
						case 0:
							this.ggv = "-";
							goto IL_248;
						case 1:
							this.ggv = "1";
							goto IL_248;
						case 2:
							this.ggv = "2";
							goto IL_248;
						case 4:
							this.ggv = "3";
							goto IL_248;
						case 8:
							this.ggv = "4";
							goto IL_248;
						}
						if (b == 16)
						{
							this.ggv = "5";
							goto IL_248;
						}
					}
					else
					{
						if (b == 32)
						{
							this.ggv = "N";
							goto IL_248;
						}
						if (b == 128)
						{
							this.ggv = "6";
							goto IL_248;
						}
					}
					this.ggv = "-";
				}
				IL_248:
				this.UpdateGridView2(this.oxi, this.o2v, this.stf, this.afr, this.fiz, this.bas, this.sss, this.ssw, this.ggs, this.pom, this.fan, this.ggv);
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding data: " + ex.Message);
			}
		}

		// Token: 0x06000B85 RID: 2949 RVA: 0x000520D8 File Offset: 0x000520D8
		private void dat20()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				32,
				248
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			try
			{
				this.o2 = (float)(BitConverter.ToUInt16(array2, 4) & ushort.MaxValue) / 13.142708f / 1000f;
				this.stf = (float)(array2[5] & byte.MaxValue) / 128.25652f;
				this.oxi = this.o2;
				this.o2v = (float)(array2[4] & byte.MaxValue) / 50.9937f;
				this.afr = (float)(-5.351 * (double)this.o2v + 17.7);
				this.UpdateGridView2(this.oxi, this.o2v, this.stf, this.afr, this.fiz, this.bas, this.sss, this.ssw, this.ggs, this.pom, this.fan, this.ggv);
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding data: " + ex.Message);
			}
			this.datD1();
		}

		// Token: 0x06000B86 RID: 2950 RVA: 0x0005220C File Offset: 0x0005220C
		private void UpdateGridView2(float oxi, float o2v, float stf, float afr, string fiz, string bas, string sss, string ssw, string ggs, string pom, string fan, string ggv)
		{
			if (base.InvokeRequired)
			{
				base.BeginInvoke(new Action(delegate()
				{
					this.UpdateGridView2(oxi, o2v, stf, afr, fiz, bas, sss, ssw, ggs, pom, fan, ggv);
				}));
				return;
			}
			this.UpdateRows2(oxi, o2v, stf, afr, fiz, bas, sss, ssw, ggs, pom, fan, ggv);
		}

		// Token: 0x06000B87 RID: 2951 RVA: 0x000522F0 File Offset: 0x000522F0
		private void dat11()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				17,
				7
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			if (array2[1] == 5)
			{
				this.tek11 = false;
				return;
			}
			try
			{
				if (array2.Length >= 1)
				{
					int rpm = checked(((int)array2[4] << 8) + (int)array2[5]);
					float tps = (float)array2[6] * 5f / 256f;
					float tps2 = (float)array2[7] / 2f;
					float ect = (float)array2[8] * 5f / 256f;
					float ect2 = (float)(checked(array2[9] - 40));
					float iat = (float)array2[10] * 5f / 256f;
					float iat2 = (float)(checked(array2[11] - 40));
					float map = (float)array2[12] * 5f / 256f;
					int num2 = (int)array2[13];
					float bat = (float)array2[16] / 10f;
					int vss = (int)array2[17];
					float inj = (float)(checked(((int)array2[18] << 8) + (int)array2[19])) / 200f;
					float adv = (float)array2[20] / 2f - 64f;
					this.UpdateGridView(rpm, tps, tps2, ect, ect2, iat, iat2, map, (float)num2, bat, inj, 0, adv, vss, 17, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0, 0f, 0f, 0f, 0);
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding data: " + ex.Message);
			}
		}

		// Token: 0x06000B88 RID: 2952 RVA: 0x0005248C File Offset: 0x0005248C
		private void dat13()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				19,
				5
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			if (array2[1] == 5)
			{
				this.tek13 = false;
				return;
			}
			try
			{
				if (array2.Length >= 1)
				{
					int rpm = checked(((int)array2[4] << 8) + (int)array2[5]);
					float tps = (float)array2[6] * 5f / 256f;
					float tps2 = (float)array2[7] / 2f;
					float ect = (float)array2[8] * 5f / 256f;
					float ect2 = (float)(checked(array2[9] - 40));
					float iat = (float)array2[10] * 5f / 256f;
					float iat2 = (float)(checked(array2[11] - 40));
					float map = (float)array2[12] * 5f / 256f;
					int num2 = (int)array2[13];
					float bat = (float)array2[14] / 10f;
					float inj = (float)(checked(((int)array2[15] << 8) + (int)array2[16])) / 200f;
					float adv = (float)array2[17] / 2f - 64f;
					this.UpdateGridView(rpm, tps, tps2, ect, ect2, iat, iat2, map, (float)num2, bat, inj, 0, adv, 0, 19, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0, 0f, 0f, 0f, 0);
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding data: " + ex.Message);
			}
		}

		// Token: 0x06000B89 RID: 2953 RVA: 0x00052624 File Offset: 0x00052624
		private void dat16()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				22,
				2
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			if (array2[1] == 5)
			{
				this.tek16 = false;
				return;
			}
		}

		// Token: 0x06000B8A RID: 2954 RVA: 0x00052670 File Offset: 0x00052670
		private void dat17()
		{
			byte[] array = new byte[]
			{
				114,
				5,
				113,
				23,
				1
			};
			byte[] array2 = new byte[256];
			uint num = 0U;
			this.SendCommand(array, array.Length, ref array2, ref num, 0);
			if (array2[1] == 5)
			{
				this.tek17 = false;
				return;
			}
			try
			{
				int rpm = checked(((int)array2[4] << 8) + (int)array2[5]);
				float tps = (float)array2[6] * 5f / 256f;
				float tps2 = (float)array2[7] / 2f;
				float ect = (array2[12] != byte.MaxValue) ? ((float)array2[12] * 5f / 256f) : ((float)array2[8] * 5f / 256f);
				float ect2;
				float bat;
				float inj;
				int mode;
				checked
				{
					ect2 = (float)((array2[13] != byte.MaxValue) ? (array2[13] - 40) : (array2[9] - 40));
					bat = (float)array2[14] / 10f;
					inj = (float)(((int)array2[15] << 8) + (int)array2[16]) / 200f;
					int num2 = (int)array2[18];
					if (num2 == 128 || num2 == 103)
					{
						mode = 1;
					}
					else if (num2 == 102)
					{
						mode = 2;
					}
					else if (num2 == 60)
					{
						mode = 3;
					}
					else if (num2 == 89)
					{
						mode = 4;
					}
					else if (num2 == 121)
					{
						mode = 0;
					}
					else
					{
						mode = 0;
					}
					this.fiz = ((num2 < 128) ? "ON" : "OFF");
				}
				float adv = (float)array2[17] / 2f - 64f;
				int vss = (int)array2[19];
				int tableType = (int)array2[2];
				this.UpdateGridView(rpm, tps, tps2, ect, ect2, 0f, 0f, 0f, 0f, bat, inj, mode, adv, vss, tableType, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0, 0f, 0f, 0f, 0);
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error decoding data: " + ex.Message);
			}
		}

		// Token: 0x06000B8B RID: 2955 RVA: 0x00052874 File Offset: 0x00052874
		private void UpdateGridView(int rpm, float tps1, float tps2, float ect1, float ect2, float iat1, float iat2, float map1, float map2, float bat, float inj, int MODE, float adv, int vss, int tableType, float ap1_0 = 0f, float ap2_0 = 0f, float ap1_1 = 0f, float ap2_1 = 0f, float tp1_0 = 0f, float tp2_0 = 0f, float tp1_1 = 0f, float tp2_1 = 0f, int cor = 0, float iat11 = 0f, float iat21 = 0f, float map11 = 0f, int map21 = 0)
		{
			if (base.InvokeRequired)
			{
				base.BeginInvoke(new Action(delegate()
				{
					this.UpdateGridView(rpm, tps1, tps2, ect1, ect2, iat1, iat2, map1, map2, bat, inj, MODE, adv, vss, tableType, ap1_0, ap2_0, ap1_1, ap2_1, tp1_0, tp2_0, tp1_1, tp2_1, cor, iat11, iat21, map11, map21);
				}));
				return;
			}
			this.chartBuffer.Add(new Diag.ChartSample
			{
				Time = DateTime.Now,
				Rpm = (double)rpm,
				Tps = (double)tps2,
				Map = (double)map2,
				Ect = (double)ect2,
				Afr = (double)this.afr
			});
			if (this.chartBuffer.Count > 600)
			{
				this.chartBuffer.RemoveRange(0, checked(this.chartBuffer.Count - 600));
			}
			this.UpdateRows(rpm, tps1, tps2, ect1, ect2, iat1, iat2, map1, map2, bat, inj, MODE, adv, vss, tableType, ap1_0, ap2_0, ap1_1, ap2_1, tp1_0, tp2_0, tp1_1, tp2_1, cor, iat11, iat21, map11, map21);
		}

		// Token: 0x06000B8C RID: 2956 RVA: 0x00052AC0 File Offset: 0x00052AC0
		private void UpdateRows(int rpm, float tps1, float tps2, float ect1, float ect2, float iat1, float iat2, float map1, float map2, float bat, float inj, int MODE, float adv, int vss, int tableType, float ap1_0, float ap2_0, float ap1_1, float ap2_1, float tp1_0, float tp2_0, float tp1_1, float tp2_1, int cor, float iat11, float iat21, float map11, int map21)
		{
			if (this.liveLabels.ContainsKey("Engine RPM"))
			{
				this.liveLabels["Engine RPM"].Text = rpm + " RPM";
			}
			if (this.liveLabels.ContainsKey("Throttle Position Volt"))
			{
				this.liveLabels["Throttle Position Volt"].Text = tps1.ToString("F2") + " V";
			}
			if (this.liveLabels.ContainsKey("Throttle Position"))
			{
				this.liveLabels["Throttle Position"].Text = tps2.ToString("F1") + " °";
			}
			if (this.liveLabels.ContainsKey("Engine Temp Volt"))
			{
				this.liveLabels["Engine Temp Volt"].Text = ect1.ToString("F2") + " V";
			}
			if (this.liveLabels.ContainsKey("Engine Temp"))
			{
				this.liveLabels["Engine Temp"].Text = ect2.ToString() + " °C";
			}
			if (this.liveLabels.ContainsKey("Intake Air Temperature Volt"))
			{
				this.liveLabels["Intake Air Temperature Volt"].Text = iat1.ToString("F2") + " V";
			}
			if (this.liveLabels.ContainsKey("Intake Air Temperature"))
			{
				this.liveLabels["Intake Air Temperature"].Text = iat2.ToString() + " °C";
			}
			if (this.liveLabels.ContainsKey("Manifold Absolute Pressure Volt"))
			{
				this.liveLabels["Manifold Absolute Pressure Volt"].Text = map1.ToString("F2") + " V";
			}
			if (this.liveLabels.ContainsKey("Manifold Absolute Pressure"))
			{
				this.liveLabels["Manifold Absolute Pressure"].Text = map2.ToString();
			}
			if (this.liveLabels.ContainsKey("Voltage Battery"))
			{
				this.liveLabels["Voltage Battery"].Text = bat.ToString("F1") + " V";
			}
			if (this.liveLabels.ContainsKey("Injection Duration"))
			{
				this.liveLabels["Injection Duration"].Text = inj.ToString("F2") + " ms";
			}
			if (this.liveLabels.ContainsKey("MODE"))
			{
				this.liveLabels["MODE"].Text = MODE.ToString();
			}
			if (this.liveLabels.ContainsKey("Ignition Timing"))
			{
				this.liveLabels["Ignition Timing"].Text = adv.ToString("F1") + " °";
			}
			if (this.liveLabels.ContainsKey("Vehicle Speed Sensor"))
			{
				this.liveLabels["Vehicle Speed Sensor"].Text = vss + " km/h";
			}
			if (this.liveLabels.ContainsKey("TableType"))
			{
				this.liveLabels["TableType"].Text = tableType.ToString();
			}
			if (this.liveLabels.ContainsKey("Handle grip position 1 Volt"))
			{
				this.liveLabels["Handle grip position 1 Volt"].Text = ap1_0.ToString("F2") + " V";
			}
			if (this.liveLabels.ContainsKey("Handle grip position 2 Volt"))
			{
				this.liveLabels["Handle grip position 2 Volt"].Text = ap2_0.ToString("F2") + " V";
			}
			if (this.liveLabels.ContainsKey("Handle grip position 1 °"))
			{
				this.liveLabels["Handle grip position 1 °"].Text = ap1_1.ToString("F1") + " °";
			}
			if (this.liveLabels.ContainsKey("Handle grip position 2 °"))
			{
				this.liveLabels["Handle grip position 2 °"].Text = ap2_1.ToString("F1") + " °";
			}
			if (this.liveLabels.ContainsKey("Throttle Position 1 Volt"))
			{
				this.liveLabels["Throttle Position 1 Volt"].Text = tp1_0.ToString("F2") + " V";
			}
			if (this.liveLabels.ContainsKey("Throttle Position 2 Volt"))
			{
				this.liveLabels["Throttle Position 2 Volt"].Text = tp2_0.ToString("F2") + " V";
			}
			if (this.liveLabels.ContainsKey("Throttle Position 1 °"))
			{
				this.liveLabels["Throttle Position 1 °"].Text = tp1_1.ToString("F1") + " °";
			}
			if (this.liveLabels.ContainsKey("Throttle Position 2 °"))
			{
				this.liveLabels["Throttle Position 2 °"].Text = tp2_1.ToString("F1") + " °";
			}
			if (this.liveLabels.ContainsKey("COR"))
			{
				this.liveLabels["COR"].Text = cor.ToString();
			}
		}

		// Token: 0x06000B8D RID: 2957 RVA: 0x00053034 File Offset: 0x00053034
		private void UpdateRows2(float oxi, float o2v, float stf, float afr, string fiz, string bas, string sss, string ssw, string ggs, string pom, string fan, string ggv)
		{
			if (this.liveLabels.ContainsKey("Oxygen Sensor"))
			{
				this.liveLabels["Oxygen Sensor"].Text = oxi.ToString("F4");
			}
			if (this.liveLabels.ContainsKey("Oxygen Sensor Volt"))
			{
				this.liveLabels["Oxygen Sensor Volt"].Text = o2v.ToString("F4") + " V";
			}
			if (this.liveLabels.ContainsKey("Short term Fuel Trim"))
			{
				this.liveLabels["Short term Fuel Trim"].Text = stf.ToString("F4");
			}
			if (this.liveLabels.ContainsKey("Air Fuel Ratio"))
			{
				this.liveLabels["Air Fuel Ratio"].Text = afr.ToString("F2") + " : 1";
			}
			if (this.liveLabels.ContainsKey("Fast Idle Step"))
			{
				this.liveLabels["Fast Idle Step"].Text = fiz;
			}
			if (this.liveLabels.ContainsKey("Bank Angle Sensor"))
			{
				this.liveLabels["Bank Angle Sensor"].Text = bas;
			}
			if (this.liveLabels.ContainsKey("Switch Starter"))
			{
				this.liveLabels["Switch Starter"].Text = sss;
			}
			if (this.liveLabels.ContainsKey("Side Stand Switch"))
			{
				this.liveLabels["Side Stand Switch"].Text = ssw;
			}
			if (this.liveLabels.ContainsKey("Gear Status"))
			{
				this.liveLabels["Gear Status"].Text = ggs;
			}
			if (this.liveLabels.ContainsKey("Fuel Pump"))
			{
				this.liveLabels["Fuel Pump"].Text = pom;
			}
			if (this.liveLabels.ContainsKey("Cooling Fan"))
			{
				this.liveLabels["Cooling Fan"].Text = fan;
			}
			if (this.liveLabels.ContainsKey("Gear Position"))
			{
				this.liveLabels["Gear Position"].Text = ggv;
			}
		}

		// Token: 0x06000B8E RID: 2958 RVA: 0x0000878E File Offset: 0x0000878E
		private void start()
		{
			this._cancellationTokenSource = new CancellationTokenSource();
			new Thread(delegate()
			{
				this.LoopDat17(this._cancellationTokenSource.Token);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000B8F RID: 2959 RVA: 0x000087B8 File Offset: 0x000087B8
		private void button2_Click(object sender, EventArgs e)
		{
			if (this._cancellationTokenSource == null || this._cancellationTokenSource.IsCancellationRequested)
			{
				this.start();
			}
		}

		// Token: 0x06000B90 RID: 2960 RVA: 0x0005326C File Offset: 0x0005326C
		private void button1_Click(object sender, EventArgs e)
		{
			CancellationTokenSource cancellationTokenSource = this._cancellationTokenSource;
			if (cancellationTokenSource != null)
			{
				cancellationTokenSource.Cancel();
			}
			this.CloseFtdiConnection();
			base.Close();
		}

		// Token: 0x06000B91 RID: 2961 RVA: 0x000087D5 File Offset: 0x000087D5
		private void CloseFtdiConnection()
		{
			if (Diag.ftHandle != IntPtr.Zero)
			{
				FTDI.FT_Close(Diag.ftHandle);
				Diag.ftHandle = IntPtr.Zero;
			}
		}

		// Token: 0x06000B92 RID: 2962 RVA: 0x00053298 File Offset: 0x00053298
		private bool InitFtdiIso()
		{
			byte[] array = new byte[1];
			byte[] array2 = new byte[]
			{
				1
			};
			uint num = 0U;
			if (FTDI.FT_Open(0U, ref Diag.ftHandle) > FTDI.FT_STATUS.FT_OK)
			{
				FTDI.FT_Close(Diag.ftHandle);
				return false;
			}
			if (FTDI.FT_Purge(Diag.ftHandle, 3U) > FTDI.FT_STATUS.FT_OK)
			{
				FTDI.FT_Close(Diag.ftHandle);
				return false;
			}
			if (FTDI.FT_SetBitMode(Diag.ftHandle, 0, 0) > FTDI.FT_STATUS.FT_OK)
			{
				FTDI.FT_Close(Diag.ftHandle);
				return false;
			}
			if (FTDI.FT_SetDataCharacteristics(Diag.ftHandle, 8, 0, 0) > FTDI.FT_STATUS.FT_OK)
			{
				FTDI.FT_Close(Diag.ftHandle);
				return false;
			}
			if (FTDI.FT_SetBaudRate(Diag.ftHandle, 10400U) > FTDI.FT_STATUS.FT_OK)
			{
				FTDI.FT_Close(Diag.ftHandle);
				return false;
			}
			if (FTDI.FT_SetTimeouts(Diag.ftHandle, 50U, 0U) > FTDI.FT_STATUS.FT_OK)
			{
				FTDI.FT_Close(Diag.ftHandle);
				return false;
			}
			if (FTDI.FT_SetLatencyTimer(Diag.ftHandle, 8) > FTDI.FT_STATUS.FT_OK)
			{
				FTDI.FT_Close(Diag.ftHandle);
				return false;
			}
			if (FTDI.FT_SetBitMode(Diag.ftHandle, 1, 1) > FTDI.FT_STATUS.FT_OK)
			{
				FTDI.FT_Close(Diag.ftHandle);
				return false;
			}
			checked
			{
				if (FTDI.FT_Write(Diag.ftHandle, array, (uint)array.Length, ref num) > FTDI.FT_STATUS.FT_OK)
				{
					FTDI.FT_Close(Diag.ftHandle);
					return false;
				}
				Thread.Sleep(70);
				if (FTDI.FT_Write(Diag.ftHandle, array2, (uint)array2.Length, ref num) > FTDI.FT_STATUS.FT_OK)
				{
					FTDI.FT_Close(Diag.ftHandle);
					return false;
				}
				if (FTDI.FT_SetBitMode(Diag.ftHandle, 0, 0) > FTDI.FT_STATUS.FT_OK)
				{
					FTDI.FT_Close(Diag.ftHandle);
					return false;
				}
				if (FTDI.FT_SetBaudRate(Diag.ftHandle, 10400U) > FTDI.FT_STATUS.FT_OK)
				{
					FTDI.FT_Close(Diag.ftHandle);
					return false;
				}
				if (FTDI.FT_Purge(Diag.ftHandle, 3U) > FTDI.FT_STATUS.FT_OK)
				{
					FTDI.FT_Close(Diag.ftHandle);
					return false;
				}
				Thread.Sleep(130);
				return true;
			}
		}

		// Token: 0x06000B93 RID: 2963 RVA: 0x00053448 File Offset: 0x00053448
		private bool SendCommand(byte[] command, int commandSize, ref byte[] reply, ref uint replySize, int sleepMs = 0)
		{
			byte[] array = new byte[256];
			byte[] array2 = new byte[256];
			uint num = 0U;
			uint num2 = 0U;
			uint num3 = 0U;
			uint num4 = 0U;
			uint num5 = 0U;
			long num6 = (long)(checked(50 + 2 * commandSize));
			checked
			{
				if (FTDI.FT_Write(Diag.ftHandle, command, (uint)commandSize, ref num) > FTDI.FT_STATUS.FT_OK)
				{
					return false;
				}
				if (FTDI.FT_SetLatencyTimer(Diag.ftHandle, 8) > FTDI.FT_STATUS.FT_OK)
				{
					return false;
				}
				if (sleepMs > 0)
				{
					Thread.Sleep(sleepMs);
				}
				Stopwatch stopwatch = new Stopwatch();
				stopwatch.Start();
				while (stopwatch.ElapsedMilliseconds < num6)
				{
					if (FTDI.FT_GetQueueStatus(Diag.ftHandle, ref num2) == FTDI.FT_STATUS.FT_OK && num2 > 0U && num2 < (uint)array.Length && FTDI.FT_Read(Diag.ftHandle, array, num2, ref num3) == FTDI.FT_STATUS.FT_OK && num3 > 0U)
					{
						unchecked
						{
							Array.Copy(array, 0L, array2, (long)((ulong)num4), (long)((ulong)num3));
						}
						num4 += num3;
						if (num4 >= (uint)(commandSize + 2))
						{
							if (num5 == 0U)
							{
								num5 = (uint)array2[commandSize + 1];
							}
							if (unchecked((ulong)num4) - (ulong)commandSize == unchecked((ulong)num5))
							{
								replySize = num5;
								unchecked
								{
									Array.Copy(array2, (long)((ulong)(checked(num4 - num5))), reply, 0L, (long)((ulong)num5));
								}
								if (this.ValidateChecksum(reply, (int)num5))
								{
									stopwatch.Stop();
									FTDI.FT_Purge(Diag.ftHandle, 3U);
									return true;
								}
							}
						}
					}
				}
				stopwatch.Stop();
				FTDI.FT_Purge(Diag.ftHandle, 3U);
				return false;
			}
		}

		// Token: 0x06000B94 RID: 2964 RVA: 0x000087FD File Offset: 0x000087FD
		private bool ValidateChecksum(byte[] data, int dataSize)
		{
			return checked(this.Checksum8BitHonda(data, dataSize - 1, 0) == data[dataSize - 1]);
		}

		// Token: 0x06000B95 RID: 2965 RVA: 0x0005358C File Offset: 0x0005358C
		private byte Checksum8BitHonda(byte[] data, int dataSize, int startPos = 0)
		{
			checked
			{
				int num = startPos + dataSize;
				int num2 = 0;
				while (startPos < num)
				{
					num2 += (int)data[startPos];
					startPos++;
				}
				return (byte)((num2 ^ 255) + 1 & 255);
			}
		}

		// Token: 0x06000B96 RID: 2966 RVA: 0x000535C0 File Offset: 0x000535C0
		private void SecondForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			CancellationTokenSource cancellationTokenSource = this._cancellationTokenSource;
			if (cancellationTokenSource != null)
			{
				cancellationTokenSource.Cancel();
			}
		}

		// Token: 0x06000B97 RID: 2967 RVA: 0x00008811 File Offset: 0x00008811
		private void Diag_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (this.chartTimer != null)
			{
				this.chartTimer.Stop();
				this.chartTimer.Dispose();
				this.chartTimer = null;
			}
			this.CloseFtdiConnection();
		}

		// Token: 0x06000B98 RID: 2968 RVA: 0x000535E0 File Offset: 0x000535E0
		private void timer1_Tick(object sender, EventArgs e)
		{
			this.teks = this.teks.Substring(1) + this.teks[0].ToString();
			this.Text = this.teks;
		}

		// Token: 0x06000B9C RID: 2972 RVA: 0x00053E1C File Offset: 0x00053E1C
		private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			checked
			{
				int num = radius * 2;
				if (num > rect.Width)
				{
					num = rect.Width;
				}
				if (num > rect.Height)
				{
					num = rect.Height;
				}
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x06000B9D RID: 2973 RVA: 0x00053EE4 File Offset: 0x00053EE4
		private void Diag_Paint(object sender, PaintEventArgs e)
		{
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			int width = base.ClientSize.Width;
			int height = base.ClientSize.Height;
			checked
			{
				using (Pen pen = new Pen(Color.FromArgb(60, 0, 255, 220), 3f))
				{
					using (GraphicsPath roundedPath = this.GetRoundedPath(new Rectangle(4, 4, width - 9, height - 9), 14))
					{
						e.Graphics.DrawPath(pen, roundedPath);
					}
				}
				using (Pen pen2 = new Pen(Color.FromArgb(255, 0, 255, 220), 1.5f))
				{
					using (GraphicsPath roundedPath2 = this.GetRoundedPath(new Rectangle(3, 3, width - 7, height - 7), 13))
					{
						e.Graphics.DrawPath(pen2, roundedPath2);
					}
				}
			}
		}

		// Token: 0x06000B9E RID: 2974 RVA: 0x00054018 File Offset: 0x00054018
		private void SetupButton(Button b, string text, TableLayoutPanel parent, int col)
		{
			b.Dock = DockStyle.Fill;
			b.Margin = new Padding(10, 5, 10, 5);
			b.Text = text;
			Diag.RoundedButton roundedButton = b as Diag.RoundedButton;
			if (roundedButton != null)
			{
				roundedButton.CornerRadius = 12;
				roundedButton.BorderColor = this.colCyan;
				roundedButton.BorderWidth = 1.5f;
				roundedButton.Font = new Font("Segoe UI Semibold", 12f, FontStyle.Bold);
			}
			parent.Controls.Add(b, col, 0);
		}

		// Token: 0x06000B9F RID: 2975 RVA: 0x00054094 File Offset: 0x00054094
		private void InitializeDashboard()
		{
			string[] array = new string[]
			{
				"Engine RPM",
				"Throttle Position Volt",
				"Throttle Position",
				"Engine Temp Volt",
				"Engine Temp",
				"Intake Air Temperature Volt",
				"Intake Air Temperature",
				"Manifold Absolute Pressure Volt",
				"Manifold Absolute Pressure",
				"Voltage Battery",
				"Injection Duration",
				"Ignition Timing",
				"Vehicle Speed Sensor",
				"Oxygen Sensor Volt",
				"Air Fuel Ratio",
				"Gear Position"
			};
			this.tlpGrid.Controls.Clear();
			this.tlpGrid.ColumnStyles.Clear();
			this.tlpGrid.RowStyles.Clear();
			int num = 4;
			this.tlpGrid.ColumnCount = num;
			checked
			{
				for (int i = 0; i < num; i++)
				{
					this.tlpGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / (float)num));
				}
				int num2 = (int)Math.Ceiling((double)array.Length / (double)num);
				this.tlpGrid.RowCount = num2;
				for (int j = 0; j < num2; j++)
				{
					this.tlpGrid.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / (float)num2));
				}
				for (int k = 0; k < array.Length; k++)
				{
					string text = array[k];
					Diag.RoundedPanel roundedPanel = new Diag.RoundedPanel
					{
						Dock = DockStyle.Fill,
						BackColor = this.colCard,
						BorderColor = this.colBorder,
						BorderWidth = 1.5f,
						CornerRadius = 12,
						Margin = new Padding(6)
					};
					Label value = new Label
					{
						Text = text,
						Font = new Font("Segoe UI", 8f, FontStyle.Bold),
						ForeColor = Color.FromArgb(135, 158, 174),
						Dock = DockStyle.Top,
						Height = 22,
						TextAlign = ContentAlignment.MiddleCenter,
						BackColor = Color.Transparent
					};
					Label value2 = new Label
					{
						Text = "—",
						Font = new Font("Segoe UI", 14f, FontStyle.Bold),
						ForeColor = this.colCyan,
						Dock = DockStyle.Fill,
						TextAlign = ContentAlignment.MiddleCenter,
						BackColor = Color.Transparent
					};
					roundedPanel.Controls.Add(value2);
					roundedPanel.Controls.Add(value);
					this.tlpGrid.Controls.Add(roundedPanel, k % num, k / num);
					this.liveLabels[text] = value2;
				}
			}
		}

		// Token: 0x06000BA0 RID: 2976 RVA: 0x0005433C File Offset: 0x0005433C
		private void BuildChartPanel()
		{
			if (this.panelChart == null)
			{
				return;
			}
			this.panelChart.Controls.Clear();
			Label value = new Label
			{
				Text = "\ud83c\udfce️  LIVE GAUGES",
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				ForeColor = this.colCyan,
				Dock = DockStyle.Top,
				Height = 24,
				TextAlign = ContentAlignment.MiddleLeft,
				BackColor = Color.Transparent,
				Padding = new Padding(4, 0, 0, 0)
			};
			this.panelChart.Controls.Add(value);
			this.chartCanvas = new Diag.DoubleBufferedPanel
			{
				Dock = DockStyle.Fill,
				BackColor = Color.FromArgb(8, 12, 16)
			};
			this.chartCanvas.Paint += this.ChartCanvas_Paint;
			this.panelChart.Controls.Add(this.chartCanvas);
			if (this.chartTimer != null)
			{
				this.chartTimer.Stop();
				this.chartTimer.Dispose();
			}
			this.chartTimer = new System.Windows.Forms.Timer
			{
				Interval = 200
			};
			this.chartTimer.Tick += delegate(object s, EventArgs ev)
			{
				if (this.chartCanvas != null && !this.chartCanvas.IsDisposed)
				{
					this.chartCanvas.Invalidate();
				}
			};
			this.chartTimer.Start();
		}

		// Token: 0x06000BA1 RID: 2977 RVA: 0x0005447C File Offset: 0x0005447C
		private void ChartCanvas_Paint(object sender, PaintEventArgs e)
		{
			Panel panel = (Panel)sender;
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
			graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			int width = panel.Width;
			int height = panel.Height;
			if (width < 100 || height < 60)
			{
				return;
			}
			double value = 0.0;
			double value2 = 0.0;
			double value3 = 0.0;
			double value4 = 0.0;
			if (this.chartBuffer.Count > 0)
			{
				Diag.ChartSample chartSample = this.chartBuffer[checked(this.chartBuffer.Count - 1)];
				value = chartSample.Rpm;
				value2 = chartSample.Tps;
				double map = chartSample.Map;
				value3 = chartSample.Ect;
				value4 = chartSample.Afr;
			}
			Diag.GaugeDef[] array = new Diag.GaugeDef[]
			{
				new Diag.GaugeDef
				{
					Label = "ENGINE RPM",
					Value = value,
					Max = 14000.0,
					Unit = "RPM",
					Color = Color.FromArgb(0, 255, 220),
					Dim = Color.FromArgb(0, 80, 70)
				},
				new Diag.GaugeDef
				{
					Label = "THROTTLE POSITION",
					Value = value2,
					Max = 100.0,
					Unit = "TPS %",
					Color = Color.FromArgb(0, 255, 120),
					Dim = Color.FromArgb(0, 80, 40)
				},
				new Diag.GaugeDef
				{
					Label = "AIR FUEL RATIO",
					Value = value4,
					Max = 20.0,
					Unit = "AFR",
					Color = Color.FromArgb(255, 180, 0),
					Dim = Color.FromArgb(100, 60, 0)
				},
				new Diag.GaugeDef
				{
					Label = "ENGINE TEMP",
					Value = value3,
					Max = 150.0,
					Unit = "°C",
					Color = Color.FromArgb(200, 140, 255),
					Dim = Color.FromArgb(70, 40, 100)
				}
			};
			int num = array.Length;
			int num2 = ((double)width > (double)height * 1.5) ? 4 : 2;
			int num3 = checked((int)Math.Ceiling((double)num / (double)num2));
			float num4 = 20f;
			float num5 = ((float)width - num4 * (float)(checked(num2 + 1))) / (float)num2;
			float num6 = ((float)height - num4 * (float)(checked(num3 + 1))) / (float)num3;
			float num7 = Math.Min(num5, num6);
			if (num7 < 50f)
			{
				num7 = 50f;
			}
			if (num7 > 280f)
			{
				num7 = 280f;
			}
			float num8 = num7 / 2f;
			float num9 = 135f;
			float num10 = 270f;
			for (int i = 0; i < num; i = checked(i + 1))
			{
				Diag.GaugeDef gaugeDef = array[i];
				int num11 = i / num2;
				int num12 = i % num2;
				float num13 = num4 + (float)num12 * (num5 + num4) + num5 / 2f;
				float num14 = num4 + (float)num11 * (num6 + num4) + num6 / 2f + 20f;
				RectangleF rect = new RectangleF(num13 - num8, num14 - num8, num7, num7);
				using (Pen pen = new Pen(Color.FromArgb(100, 0, 255, 220), 4f))
				{
					graphics.DrawEllipse(pen, rect);
				}
				using (Pen pen2 = new Pen(Color.FromArgb(0, 255, 220), 1.5f))
				{
					graphics.DrawEllipse(pen2, rect);
				}
				RectangleF rect2 = new RectangleF(rect.X + 5f, rect.Y + 5f, rect.Width - 10f, rect.Height - 10f);
				using (Pen pen3 = new Pen(Color.FromArgb(60, 0, 255, 220), 1f))
				{
					graphics.DrawEllipse(pen3, rect2);
				}
				RectangleF rect3 = new RectangleF(rect.X + 15f, rect.Y + 15f, rect.Width - 30f, rect.Height - 30f);
				using (Pen pen4 = new Pen(Color.FromArgb(22, 27, 34), 8f))
				{
					pen4.StartCap = LineCap.Round;
					pen4.EndCap = LineCap.Round;
					graphics.DrawArc(pen4, rect3, num9, num10);
				}
				double num15 = Math.Max(0.0, Math.Min(1.0, gaugeDef.Value / gaugeDef.Max));
				float num16 = (float)((double)num10 * num15);
				if (num16 > 0f)
				{
					using (Pen pen5 = new Pen(gaugeDef.Color, 8f))
					{
						pen5.StartCap = LineCap.Round;
						pen5.EndCap = LineCap.Round;
						graphics.DrawArc(pen5, rect3, num9, num16);
					}
				}
				int num17 = 14;
				if (gaugeDef.Label == "THROTTLE POSITION")
				{
					num17 = 10;
				}
				else if (gaugeDef.Label == "AIR FUEL RATIO")
				{
					num17 = 10;
				}
				else if (gaugeDef.Label == "ENGINE TEMP")
				{
					num17 = 15;
				}
				for (int j = 0; j <= num17; j = checked(j + 1))
				{
					float num18 = (float)j / (float)num17;
					double num19 = (double)(num9 + num10 * num18) * 3.141592653589793 / 180.0;
					float num20 = num8 - 18f;
					float num21 = num8 - 28f;
					float x = num13 + (float)(Math.Cos(num19) * (double)num20);
					float y = num14 + (float)(Math.Sin(num19) * (double)num20);
					float x2 = num13 + (float)(Math.Cos(num19) * (double)num21);
					float y2 = num14 + (float)(Math.Sin(num19) * (double)num21);
					bool flag = gaugeDef.Label == "ENGINE RPM" && j >= 10;
					Color color = flag ? Color.FromArgb(255, 50, 50) : Color.FromArgb(200, 210, 220);
					using (Pen pen6 = new Pen(color, flag ? 2f : 1.5f))
					{
						graphics.DrawLine(pen6, x, y, x2, y2);
					}
					if (num7 > 120f && (j % 2 == 0 || num17 <= 10))
					{
						string text = (gaugeDef.Label == "ENGINE RPM") ? j.ToString() : Math.Round(gaugeDef.Max / (double)num17 * (double)j).ToString();
						using (Font font = new Font("Segoe UI", 7f, FontStyle.Bold))
						{
							SizeF sizeF = graphics.MeasureString(text, font);
							float x3 = num13 + (float)(Math.Cos(num19) * (double)(num21 - 12f)) - sizeF.Width / 2f;
							float y3 = num14 + (float)(Math.Sin(num19) * (double)(num21 - 12f)) - sizeF.Height / 2f;
							using (SolidBrush solidBrush = new SolidBrush(color))
							{
								graphics.DrawString(text, font, solidBrush, x3, y3);
							}
						}
					}
				}
				double num22 = (double)(num9 + num16) * 3.141592653589793 / 180.0;
				float num23 = num8 - 35f;
				float x4 = num13 + (float)(Math.Cos(num22) * (double)num23);
				float y4 = num14 + (float)(Math.Sin(num22) * (double)num23);
				using (Pen pen7 = new Pen(gaugeDef.Color, 3f))
				{
					pen7.StartCap = LineCap.Round;
					pen7.EndCap = LineCap.Round;
					graphics.DrawLine(pen7, num13, num14, x4, y4);
				}
				using (SolidBrush solidBrush2 = new SolidBrush(Color.FromArgb(30, 35, 40)))
				{
					graphics.FillEllipse(solidBrush2, num13 - 8f, num14 - 8f, 16f, 16f);
				}
				using (Pen pen8 = new Pen(gaugeDef.Color, 1.5f))
				{
					graphics.DrawEllipse(pen8, num13 - 8f, num14 - 8f, 16f, 16f);
				}
				using (SolidBrush solidBrush3 = new SolidBrush(gaugeDef.Color))
				{
					graphics.FillEllipse(solidBrush3, num13 - 3f, num14 - 3f, 6f, 6f);
				}
				if (num7 > 100f)
				{
					string text2 = (gaugeDef.Label == "ENGINE RPM") ? (checked((int)gaugeDef.Value)).ToString() : gaugeDef.Value.ToString("F1");
					using (Font font2 = new Font("Segoe UI", 14f, FontStyle.Bold))
					{
						SizeF sizeF2 = graphics.MeasureString(text2, font2);
						using (SolidBrush solidBrush4 = new SolidBrush(Color.White))
						{
							graphics.DrawString(text2, font2, solidBrush4, num13 - sizeF2.Width / 2f, num14 + 15f);
						}
					}
					using (Font font3 = new Font("Segoe UI", 7f, FontStyle.Bold))
					{
						SizeF sizeF3 = graphics.MeasureString(gaugeDef.Label, font3);
						using (SolidBrush solidBrush5 = new SolidBrush(gaugeDef.Color))
						{
							graphics.DrawString(gaugeDef.Label, font3, solidBrush5, num13 - sizeF3.Width / 2f, num14 + 35f);
						}
					}
				}
				if (num7 > 150f)
				{
					float num24 = num7 * 0.4f;
					float height2 = 20f;
					RectangleF bounds = new RectangleF(num13 - num24 / 2f, num14 + num8 - 20f, num24, height2);
					using (GraphicsPath roundedRect = this.GetRoundedRect(bounds, 6f))
					{
						using (SolidBrush solidBrush6 = new SolidBrush(Color.FromArgb(30, 35, 40)))
						{
							graphics.FillPath(solidBrush6, roundedRect);
						}
						using (Pen pen9 = new Pen(Color.FromArgb(60, 70, 80), 1f))
						{
							graphics.DrawPath(pen9, roundedRect);
						}
					}
					using (Font font4 = new Font("Segoe UI", 8f, FontStyle.Bold))
					{
						SizeF sizeF4 = graphics.MeasureString(gaugeDef.Unit, font4);
						using (SolidBrush solidBrush7 = new SolidBrush(gaugeDef.Color))
						{
							graphics.DrawString(gaugeDef.Unit, font4, solidBrush7, bounds.X + (bounds.Width - sizeF4.Width) / 2f, bounds.Y + (bounds.Height - sizeF4.Height) / 2f);
						}
					}
				}
			}
		}

		// Token: 0x06000BA7 RID: 2983 RVA: 0x00055214 File Offset: 0x00055214
		private void DrawInfoBox(Graphics g, RectangleF rect, string value, string label, Color accentColor, Color bgColor)
		{
			using (GraphicsPath roundedRect = this.GetRoundedRect(rect, 8f))
			{
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(30, 35, 40)))
				{
					g.FillPath(solidBrush, roundedRect);
				}
				using (Pen pen = new Pen(Color.FromArgb(60, 70, 80), 1f))
				{
					g.DrawPath(pen, roundedRect);
				}
			}
			using (Font font = new Font("Segoe UI", 10f, FontStyle.Bold))
			{
				SizeF sizeF = g.MeasureString(value, font);
				using (SolidBrush solidBrush2 = new SolidBrush(accentColor))
				{
					g.DrawString(value, font, solidBrush2, rect.X + 10f, rect.Y + (rect.Height - sizeF.Height) / 2f);
				}
			}
			using (Font font2 = new Font("Segoe UI", 7f, FontStyle.Bold))
			{
				SizeF sizeF2 = g.MeasureString(label, font2);
				using (SolidBrush solidBrush3 = new SolidBrush(Color.FromArgb(150, 160, 170)))
				{
					g.DrawString(label, font2, solidBrush3, rect.Right - sizeF2.Width - 10f, rect.Y + (rect.Height - sizeF2.Height) / 2f);
				}
			}
		}

		// Token: 0x06000BA8 RID: 2984 RVA: 0x000553E0 File Offset: 0x000553E0
		private GraphicsPath GetRoundedRect(RectangleF bounds, float radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			float num = radius * 2f;
			graphicsPath.AddArc(bounds.X, bounds.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(bounds.Right - num, bounds.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(bounds.Right - num, bounds.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(bounds.X, bounds.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x04000CD8 RID: 3288
		private string teks = "⟶ (\ud83d\udcbb Scan - \ud83d\udd0d Diag ) ⟵  \ud83d\udcbb Scanner Pc - \ud83d\udd0d Diagnosa Kerusakan (DTC) ";

		// Token: 0x04000CD9 RID: 3289
		private static IntPtr ftHandle = IntPtr.Zero;

		// Token: 0x04000CDA RID: 3290
		private bool tek10 = true;

		// Token: 0x04000CDB RID: 3291
		private bool tek11 = true;

		// Token: 0x04000CDC RID: 3292
		private bool tek13 = true;

		// Token: 0x04000CDD RID: 3293
		private bool tek16 = true;

		// Token: 0x04000CDE RID: 3294
		private bool tek17 = true;

		// Token: 0x04000CDF RID: 3295
		private CancellationTokenSource _cancellationTokenSource;

		// Token: 0x04000CE0 RID: 3296
		private string combinedResult;

		// Token: 0x04000CE1 RID: 3297
		private Dictionary<string, string> errorMessages;

		// Token: 0x04000CE2 RID: 3298
		private string Hasil = "-";

		// Token: 0x04000CE3 RID: 3299
		private string Hasil2 = "-";

		// Token: 0x04000CE4 RID: 3300
		private string Hasil3 = "-";

		// Token: 0x04000CE5 RID: 3301
		private string Hasil4 = "-";

		// Token: 0x04000CE6 RID: 3302
		private string hasilGabungan = "-";

		// Token: 0x04000CE7 RID: 3303
		private int dtcCounter = 1;

		// Token: 0x04000CE8 RID: 3304
		private bool dtcTitleAdded;

		// Token: 0x04000CE9 RID: 3305
		private float o2;

		// Token: 0x04000CEA RID: 3306
		private float oxi;

		// Token: 0x04000CEB RID: 3307
		private float o2v;

		// Token: 0x04000CEC RID: 3308
		private float stf;

		// Token: 0x04000CED RID: 3309
		private float afr;

		// Token: 0x04000CEE RID: 3310
		private string fiz = "-";

		// Token: 0x04000CEF RID: 3311
		private string bas = "-";

		// Token: 0x04000CF0 RID: 3312
		private string sss = "-";

		// Token: 0x04000CF1 RID: 3313
		private string ssw = "-";

		// Token: 0x04000CF2 RID: 3314
		private string ggs = "-";

		// Token: 0x04000CF3 RID: 3315
		private string pom = "-";

		// Token: 0x04000CF4 RID: 3316
		private string fan = "-";

		// Token: 0x04000CF5 RID: 3317
		private string ggv = "-";

		// Token: 0x04000CFE RID: 3326
		private Dictionary<string, Label> liveLabels = new Dictionary<string, Label>();

		// Token: 0x04000CFF RID: 3327
		private Dictionary<string, Label> statusLabels = new Dictionary<string, Label>();

		// Token: 0x04000D02 RID: 3330
		private Color colBorder = Color.FromArgb(0, 180, 160);

		// Token: 0x04000D0A RID: 3338
		private readonly List<Diag.ChartSample> chartBuffer = new List<Diag.ChartSample>();

		// Token: 0x04000D0B RID: 3339
		private System.Windows.Forms.Timer chartTimer;

		// Token: 0x04000D0C RID: 3340
		private Diag.DoubleBufferedPanel chartCanvas;

		// Token: 0x02000358 RID: 856
		public class RoundedButton : Button
		{
			// Token: 0x17000029 RID: 41
			// (get) Token: 0x06000BAC RID: 2988 RVA: 0x000088B0 File Offset: 0x000088B0
			// (set) Token: 0x06000BAD RID: 2989 RVA: 0x000088B8 File Offset: 0x000088B8
			public int CornerRadius { get; set; } = 12;

			// Token: 0x1700002A RID: 42
			// (get) Token: 0x06000BAE RID: 2990 RVA: 0x000088C1 File Offset: 0x000088C1
			// (set) Token: 0x06000BAF RID: 2991 RVA: 0x000088C9 File Offset: 0x000088C9
			public Color BorderColor { get; set; } = Color.FromArgb(0, 255, 220);

			// Token: 0x1700002B RID: 43
			// (get) Token: 0x06000BB0 RID: 2992 RVA: 0x000088D2 File Offset: 0x000088D2
			// (set) Token: 0x06000BB1 RID: 2993 RVA: 0x000088DA File Offset: 0x000088DA
			public float BorderWidth { get; set; } = 1.5f;

			// Token: 0x06000BB2 RID: 2994 RVA: 0x00055488 File Offset: 0x00055488
			public RoundedButton()
			{
				this.DoubleBuffered = true;
				base.FlatStyle = FlatStyle.Flat;
				base.FlatAppearance.BorderSize = 0;
				this.BackColor = Color.FromArgb(10, 15, 20);
				this.ForeColor = Color.FromArgb(0, 255, 220);
				this.Cursor = Cursors.Hand;
				this.Font = new Font("Segoe UI Semibold", 12f, FontStyle.Bold);
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			}

			// Token: 0x06000BB3 RID: 2995 RVA: 0x00055534 File Offset: 0x00055534
			protected override void OnPaint(PaintEventArgs e)
			{
				e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
				e.Graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
				Rectangle rect = checked(new Rectangle(1, 1, base.Width - 3, base.Height - 3));
				using (GraphicsPath roundedPath = this.GetRoundedPath(rect, this.CornerRadius))
				{
					using (SolidBrush solidBrush = new SolidBrush(this.BackColor))
					{
						e.Graphics.FillPath(solidBrush, roundedPath);
					}
				}
				using (GraphicsPath roundedPath2 = this.GetRoundedPath(rect, this.CornerRadius))
				{
					using (Pen pen = new Pen(this.BorderColor, this.BorderWidth))
					{
						pen.Alignment = PenAlignment.Center;
						e.Graphics.DrawPath(pen, roundedPath2);
					}
				}
				TextRenderer.DrawText(e.Graphics, this.Text, this.Font, base.ClientRectangle, this.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			}

			// Token: 0x06000BB4 RID: 2996 RVA: 0x00053E1C File Offset: 0x00053E1C
			private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
			{
				GraphicsPath graphicsPath = new GraphicsPath();
				checked
				{
					int num = radius * 2;
					if (num > rect.Width)
					{
						num = rect.Width;
					}
					if (num > rect.Height)
					{
						num = rect.Height;
					}
					graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
					graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
					graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
					graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
					graphicsPath.CloseFigure();
					return graphicsPath;
				}
			}

			// Token: 0x06000BB5 RID: 2997 RVA: 0x000088E3 File Offset: 0x000088E3
			protected override void OnMouseEnter(EventArgs e)
			{
				base.OnMouseEnter(e);
				this.BackColor = Color.FromArgb(0, 70, 90);
				base.Invalidate();
			}

			// Token: 0x06000BB6 RID: 2998 RVA: 0x00008902 File Offset: 0x00008902
			protected override void OnMouseLeave(EventArgs e)
			{
				base.OnMouseLeave(e);
				this.BackColor = Color.FromArgb(10, 15, 20);
				base.Invalidate();
			}
		}

		// Token: 0x02000359 RID: 857
		public class ChartSample
		{
			// Token: 0x04000D11 RID: 3345
			public DateTime Time;

			// Token: 0x04000D12 RID: 3346
			public double Rpm;

			// Token: 0x04000D13 RID: 3347
			public double Tps;

			// Token: 0x04000D14 RID: 3348
			public double Map;

			// Token: 0x04000D15 RID: 3349
			public double Ect;

			// Token: 0x04000D16 RID: 3350
			public double Afr;
		}

		// Token: 0x0200035A RID: 858
		public class RoundedPanel : Panel
		{
			// Token: 0x1700002C RID: 44
			// (get) Token: 0x06000BB8 RID: 3000 RVA: 0x00008922 File Offset: 0x00008922
			// (set) Token: 0x06000BB9 RID: 3001 RVA: 0x0000892A File Offset: 0x0000892A
			public int CornerRadius { get; set; } = 12;

			// Token: 0x1700002D RID: 45
			// (get) Token: 0x06000BBA RID: 3002 RVA: 0x00008933 File Offset: 0x00008933
			// (set) Token: 0x06000BBB RID: 3003 RVA: 0x0000893B File Offset: 0x0000893B
			public Color BorderColor { get; set; } = Color.FromArgb(0, 180, 160);

			// Token: 0x1700002E RID: 46
			// (get) Token: 0x06000BBC RID: 3004 RVA: 0x00008944 File Offset: 0x00008944
			// (set) Token: 0x06000BBD RID: 3005 RVA: 0x0000894C File Offset: 0x0000894C
			public float BorderWidth { get; set; } = 1.5f;

			// Token: 0x06000BBE RID: 3006 RVA: 0x00055664 File Offset: 0x00055664
			public RoundedPanel()
			{
				this.DoubleBuffered = true;
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			}

			// Token: 0x06000BBF RID: 3007 RVA: 0x000556B4 File Offset: 0x000556B4
			protected override void OnPaint(PaintEventArgs e)
			{
				e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				Rectangle rect = checked(new Rectangle(0, 0, base.Width - 1, base.Height - 1));
				using (GraphicsPath roundedPath = this.GetRoundedPath(rect, this.CornerRadius))
				{
					using (SolidBrush solidBrush = new SolidBrush(this.BackColor))
					{
						e.Graphics.FillPath(solidBrush, roundedPath);
					}
				}
				using (GraphicsPath roundedPath2 = this.GetRoundedPath(rect, this.CornerRadius))
				{
					using (Pen pen = new Pen(this.BorderColor, this.BorderWidth))
					{
						e.Graphics.DrawPath(pen, roundedPath2);
					}
				}
				base.OnPaint(e);
			}

			// Token: 0x06000BC0 RID: 3008 RVA: 0x00053E1C File Offset: 0x00053E1C
			private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
			{
				GraphicsPath graphicsPath = new GraphicsPath();
				checked
				{
					int num = radius * 2;
					if (num > rect.Width)
					{
						num = rect.Width;
					}
					if (num > rect.Height)
					{
						num = rect.Height;
					}
					graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
					graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
					graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
					graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
					graphicsPath.CloseFigure();
					return graphicsPath;
				}
			}
		}

		// Token: 0x0200035B RID: 859
		public class DoubleBufferedPanel : Panel
		{
			// Token: 0x06000BC1 RID: 3009 RVA: 0x00008955 File Offset: 0x00008955
			public DoubleBufferedPanel()
			{
				this.DoubleBuffered = true;
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
				base.UpdateStyles();
			}
		}

		// Token: 0x0200035C RID: 860
		public class GaugeDef
		{
			// Token: 0x04000D1A RID: 3354
			public string Label;

			// Token: 0x04000D1B RID: 3355
			public double Value;

			// Token: 0x04000D1C RID: 3356
			public double Max;

			// Token: 0x04000D1D RID: 3357
			public string Unit;

			// Token: 0x04000D1E RID: 3358
			public Color Color;

			// Token: 0x04000D1F RID: 3359
			public Color Dim;
		}
	}
}
