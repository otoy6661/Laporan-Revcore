﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200077C RID: 1916
	public class VersionInfo
	{
		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x0600123D RID: 4669 RVA: 0x0000BF08 File Offset: 0x0000BF08
		// (set) Token: 0x0600123E RID: 4670 RVA: 0x0000BF10 File Offset: 0x0000BF10
		public string Version { get; set; }

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x0600123F RID: 4671 RVA: 0x0000BF19 File Offset: 0x0000BF19
		// (set) Token: 0x06001240 RID: 4672 RVA: 0x0000BF21 File Offset: 0x0000BF21
		public string DownloadUrl { get; set; }

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x06001241 RID: 4673 RVA: 0x0000BF2A File Offset: 0x0000BF2A
		// (set) Token: 0x06001242 RID: 4674 RVA: 0x0000BF32 File Offset: 0x0000BF32
		public string Sha256 { get; set; }

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x06001243 RID: 4675 RVA: 0x0000BF3B File Offset: 0x0000BF3B
		// (set) Token: 0x06001244 RID: 4676 RVA: 0x0000BF43 File Offset: 0x0000BF43
		public long SizeBytes { get; set; }

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x06001245 RID: 4677 RVA: 0x0000BF4C File Offset: 0x0000BF4C
		// (set) Token: 0x06001246 RID: 4678 RVA: 0x0000BF54 File Offset: 0x0000BF54
		public string Notes { get; set; }

		// Token: 0x06001247 RID: 4679 RVA: 0x0000BF5D File Offset: 0x0000BF5D
		public VersionInfo()
		{
			this.Version = "0.0.0.0";
			this.DownloadUrl = string.Empty;
			this.Sha256 = string.Empty;
			this.Notes = string.Empty;
			this.SizeBytes = 0L;
		}
	}
}
