﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000650 RID: 1616
	public partial class OverlayBlur : global::System.Windows.Forms.Form
	{
		// Token: 0x06000F95 RID: 3989 RVA: 0x0006F6A0 File Offset: 0x0006F6A0
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				this._closing = true;
				try
				{
					if (this._parent != null && !this._parent.IsDisposed)
					{
						this._parent.Move -= new global::System.EventHandler(this.Parent_Move);
						this._parent.Resize -= new global::System.EventHandler(this.Parent_Resize);
					}
				}
				catch
				{
				}
				if (this._blurred != null)
				{
					try
					{
						this._blurred.Dispose();
					}
					catch
					{
					}
					this._blurred = null;
				}
			}
			base.Dispose(disposing);
		}

		// Token: 0x04001480 RID: 5248
		private readonly global::System.Windows.Forms.Form _parent;

		// Token: 0x04001481 RID: 5249
		private global::System.Drawing.Bitmap _blurred;

		// Token: 0x04001484 RID: 5252
		private bool _closing;
	}
}
