﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000714 RID: 1812
	public partial class SplashScreenPopup : global::System.Windows.Forms.Form
	{
		// Token: 0x06001066 RID: 4198 RVA: 0x00076860 File Offset: 0x00076860
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (this._animationTimer != null)
				{
					this._animationTimer.Dispose();
				}
				if (this._progressTimer != null)
				{
					this._progressTimer.Dispose();
				}
				if (this._centerFormat != null)
				{
					this._centerFormat.Dispose();
				}
				if (this._leftFormat != null)
				{
					this._leftFormat.Dispose();
				}
				if (this._fontDepploy != null)
				{
					this._fontDepploy.Dispose();
				}
				if (this._fontMapTuning != null)
				{
					this._fontMapTuning.Dispose();
				}
				if (this._loadingFormat != null)
				{
					this._loadingFormat.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		// Token: 0x06001067 RID: 4199 RVA: 0x0000B1C2 File Offset: 0x0000B1C2
		private void InitializeComponent()
		{
			base.SuspendLayout();
			base.Name = "SplashScreen";
			base.ResumeLayout(false);
		}

		// Token: 0x040016F5 RID: 5877
		private global::System.Windows.Forms.Timer _animationTimer;

		// Token: 0x040016F6 RID: 5878
		private global::System.Windows.Forms.Timer _progressTimer;

		// Token: 0x040016FE RID: 5886
		private global::System.Drawing.StringFormat _centerFormat;

		// Token: 0x040016FF RID: 5887
		private global::System.Drawing.StringFormat _leftFormat;

		// Token: 0x04001707 RID: 5895
		private global::System.Drawing.StringFormat _loadingFormat;

		// Token: 0x04001710 RID: 5904
		private global::System.Drawing.Font _fontDepploy;

		// Token: 0x04001711 RID: 5905
		private global::System.Drawing.Font _fontMapTuning;
	}
}
