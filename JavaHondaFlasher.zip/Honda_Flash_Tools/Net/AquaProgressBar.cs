﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020006D5 RID: 1749
	public class AquaProgressBar : ProgressBar
	{
		// Token: 0x17000074 RID: 116
		// (get) Token: 0x0600100E RID: 4110 RVA: 0x0000AE57 File Offset: 0x0000AE57
		// (set) Token: 0x0600100F RID: 4111 RVA: 0x0000AE5F File Offset: 0x0000AE5F
		public Color BarColor { get; set; } = Color.FromArgb(0, 255, 255);

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x06001010 RID: 4112 RVA: 0x0000AE68 File Offset: 0x0000AE68
		// (set) Token: 0x06001011 RID: 4113 RVA: 0x0000AE70 File Offset: 0x0000AE70
		public Color BarColorDark { get; set; } = Color.FromArgb(0, 140, 140);

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x06001012 RID: 4114 RVA: 0x0000AE79 File Offset: 0x0000AE79
		// (set) Token: 0x06001013 RID: 4115 RVA: 0x0000AE81 File Offset: 0x0000AE81
		public Color TrackColor { get; set; } = Color.FromArgb(24, 24, 27);

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x06001014 RID: 4116 RVA: 0x0000AE8A File Offset: 0x0000AE8A
		// (set) Token: 0x06001015 RID: 4117 RVA: 0x0000AE92 File Offset: 0x0000AE92
		public Color BorderColor { get; set; } = Color.FromArgb(0, 180, 180);

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x06001016 RID: 4118 RVA: 0x0000AE9B File Offset: 0x0000AE9B
		// (set) Token: 0x06001017 RID: 4119 RVA: 0x0000AEA3 File Offset: 0x0000AEA3
		public int CornerRadius { get; set; } = 6;

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x06001018 RID: 4120 RVA: 0x0000AEAC File Offset: 0x0000AEAC
		// (set) Token: 0x06001019 RID: 4121 RVA: 0x0000AEB4 File Offset: 0x0000AEB4
		public bool UseGradient { get; set; } = true;

		// Token: 0x0600101A RID: 4122 RVA: 0x00074D20 File Offset: 0x00074D20
		public AquaProgressBar()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.DoubleBuffered = true;
			base.Height = 10;
		}

		// Token: 0x0600101B RID: 4123 RVA: 0x00074DB0 File Offset: 0x00074DB0
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.Clear((base.Parent != null) ? base.Parent.BackColor : this.BackColor);
			Rectangle rect = new Rectangle(0, 0, base.Width - 1, base.Height - 1);
			using (GraphicsPath roundedPath = this.GetRoundedPath(rect, this.CornerRadius))
			{
				using (SolidBrush solidBrush = new SolidBrush(this.TrackColor))
				{
					graphics.FillPath(solidBrush, roundedPath);
				}
			}
			double num = (double)(base.Maximum - base.Minimum);
			double num2 = (num > 0.0) ? ((double)(base.Value - base.Minimum) / num) : 0.0;
			int num3 = (int)((double)rect.Width * num2);
			if (num3 <= 0)
			{
				this.DrawBorder(graphics, rect);
				return;
			}
			Rectangle rect2 = new Rectangle(rect.X, rect.Y, num3, rect.Height);
			using (GraphicsPath roundedPath2 = this.GetRoundedPath(rect2, this.CornerRadius))
			{
				if (this.UseGradient)
				{
					using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(rect2, this.BarColorDark, this.BarColor, LinearGradientMode.Horizontal))
					{
						graphics.FillPath(linearGradientBrush, roundedPath2);
						goto IL_163;
					}
				}
				using (SolidBrush solidBrush2 = new SolidBrush(this.BarColor))
				{
					graphics.FillPath(solidBrush2, roundedPath2);
				}
				IL_163:
				using (Pen pen = new Pen(Color.FromArgb(120, this.BarColor), 2f))
				{
					graphics.DrawPath(pen, roundedPath2);
				}
			}
			this.DrawBorder(graphics, rect);
		}

		// Token: 0x0600101C RID: 4124 RVA: 0x00074FB4 File Offset: 0x00074FB4
		private void DrawBorder(Graphics g, Rectangle rect)
		{
			using (GraphicsPath roundedPath = this.GetRoundedPath(rect, this.CornerRadius))
			{
				using (Pen pen = new Pen(this.BorderColor, 1f))
				{
					g.DrawPath(pen, roundedPath);
				}
			}
		}

		// Token: 0x0600101D RID: 4125 RVA: 0x0007501C File Offset: 0x0007501C
		private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = Math.Max(1, radius * 2);
			if (num > rect.Width)
			{
				num = rect.Width;
			}
			if (num > rect.Height)
			{
				num = rect.Height;
			}
			graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}
	}
}
