﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200054D RID: 1357
	public partial class CustomMessageBox__2 : Form
	{
		// Token: 0x06000D6F RID: 3439 RVA: 0x000664D8 File Offset: 0x000664D8
		public CustomMessageBox__2()
		{
			this._cornerRadius = 14;
			base.FormBorderStyle = FormBorderStyle.None;
			base.StartPosition = FormStartPosition.CenterScreen;
			this.BackColor = CustomMessageBox__2.BgDark;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.ShowInTaskbar = false;
			base.Width = 480;
			base.Height = 520;
			base.TopMost = true;
			base.Padding = new Padding(2);
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		}

		// Token: 0x06000D70 RID: 3440 RVA: 0x00066560 File Offset: 0x00066560
		public static DialogResult Show(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
		{
			DialogResult dialogResult;
			using (CustomMessageBox__2 customMessageBox__ = new CustomMessageBox__2())
			{
				customMessageBox__.SetupDialog(message, title, buttons, icon);
				customMessageBox__.ShowDialog();
				dialogResult = CustomMessageBox__2._dialogResult;
			}
			return dialogResult;
		}

		// Token: 0x06000D71 RID: 3441 RVA: 0x000665A8 File Offset: 0x000665A8
		private void SetupDialog(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
		{
			base.Controls.Clear();
			this.contentPanel = new RoundedPanel();
			this.contentPanel.Dock = DockStyle.Fill;
			this.contentPanel.CornerRadius = this._cornerRadius;
			this.contentPanel.BorderColor = CustomMessageBox__2.Cyan;
			this.contentPanel.BorderWidth = 1f;
			this.contentPanel.InnerBackColor = CustomMessageBox__2.BgPanel;
			this.contentPanel.Padding = new Padding(20);
			base.Controls.Add(this.contentPanel);
			PictureBox pictureBox = new PictureBox
			{
				Location = new Point(18, 22),
				Size = new Size(28, 28),
				SizeMode = PictureBoxSizeMode.StretchImage,
				BackColor = Color.Transparent
			};
			if (icon == MessageBoxIcon.Asterisk || icon == MessageBoxIcon.Asterisk)
			{
				pictureBox.Image = SystemIcons.Information.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Exclamation || icon == MessageBoxIcon.Exclamation)
			{
				pictureBox.Image = SystemIcons.Warning.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Hand || icon == MessageBoxIcon.Hand || icon == MessageBoxIcon.Hand)
			{
				pictureBox.Image = SystemIcons.Error.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Question)
			{
				pictureBox.Image = SystemIcons.Question.ToBitmap();
			}
			this.contentPanel.Controls.Add(pictureBox);
			this.titleLabel = new Label
			{
				Text = title,
				Font = new Font("Segoe UI", 12f, FontStyle.Bold),
				ForeColor = CustomMessageBox__2.TextTitle,
				BackColor = Color.Transparent,
				Location = new Point(56, 18),
				AutoSize = true
			};
			this.contentPanel.Controls.Add(this.titleLabel);
			Panel value = new Panel
			{
				BackColor = CustomMessageBox__2.CyanDark,
				Location = new Point(18, 50),
				Size = new Size(base.Width - 36, 1),
				Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
			};
			this.contentPanel.Controls.Add(value);
			int left = this.contentPanel.Padding.Left;
			int right = this.contentPanel.Padding.Right;
			int bottom = this.contentPanel.Padding.Bottom;
			int num = 90;
			int num2 = 34;
			int num3 = 10;
			int num4 = 64;
			int height = base.Height - num4 - num2 - bottom - 30;
			RichTextBox value2 = new RichTextBox
			{
				Text = message,
				Font = new Font("Consolas", 9.5f),
				ForeColor = CustomMessageBox__2.TextFore,
				BackColor = CustomMessageBox__2.BgPanel,
				BorderStyle = BorderStyle.None,
				Location = new Point(left, num4),
				Width = base.Width - left - right - 8,
				Height = height,
				ReadOnly = true,
				Multiline = true,
				ScrollBars = RichTextBoxScrollBars.Vertical,
				Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right)
			};
			this.contentPanel.Controls.Add(value2);
			int width = this.contentPanel.ClientSize.Width;
			int height2 = this.contentPanel.ClientSize.Height;
			int num5 = width - left - right;
			int num6 = 0;
			if (buttons == MessageBoxButtons.OK)
			{
				num6 = 1;
			}
			else if (buttons == MessageBoxButtons.OKCancel || buttons == MessageBoxButtons.YesNo)
			{
				num6 = 2;
			}
			else if (buttons == MessageBoxButtons.YesNoCancel)
			{
				num6 = 3;
			}
			int num7 = num6 * num + (num6 - 1) * num3;
			int num8 = left + (num5 - num7) / 2;
			int top = height2 - num2 - bottom;
			if (buttons == MessageBoxButtons.OK)
			{
				this.CreateButton("OK", num8, top, num, num2, DialogResult.OK);
				return;
			}
			if (buttons == MessageBoxButtons.OKCancel)
			{
				this.CreateButton("OK", num8, top, num, num2, DialogResult.OK);
				this.CreateButton("Cancel", num8 + num + num3, top, num, num2, DialogResult.Cancel);
				return;
			}
			if (buttons == MessageBoxButtons.YesNo)
			{
				this.CreateButton("Yes", num8, top, num, num2, DialogResult.Yes);
				this.CreateButton("No", num8 + num + num3, top, num, num2, DialogResult.No);
				return;
			}
			if (buttons == MessageBoxButtons.YesNoCancel)
			{
				this.CreateButton("Yes", num8, top, num, num2, DialogResult.Yes);
				this.CreateButton("No", num8 + num + num3, top, num, num2, DialogResult.No);
				this.CreateButton("Cancel", num8 + (num + num3) * 2, top, num, num2, DialogResult.Cancel);
			}
		}

		// Token: 0x06000D72 RID: 3442 RVA: 0x000669EC File Offset: 0x000669EC
		private void CreateButton(string text, int left, int top, int width, int height, DialogResult result)
		{
			RoundedButton roundedButton = new RoundedButton
			{
				Text = text,
				Location = new Point(left, top),
				Size = new Size(width, height),
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				ForeColor = CustomMessageBox__2.Cyan,
				BackColor = CustomMessageBox__2.BgButton,
				CornerRadius = 8,
				BorderColor = CustomMessageBox__2.Cyan,
				BorderWidth = 1f,
				HoverBackColor = CustomMessageBox__2.BgButtonHover,
				Cursor = Cursors.Hand
			};
			roundedButton.Click += delegate(object sender, EventArgs e)
			{
				CustomMessageBox__2._dialogResult = result;
				this.Close();
			};
			this.contentPanel.Controls.Add(roundedButton);
		}

		// Token: 0x06000D73 RID: 3443 RVA: 0x00066ABC File Offset: 0x00066ABC
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.Half;
			graphics.Clear(this.BackColor);
			using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(new RectangleF(1.5f, 1.5f, (float)base.Width - 3f, (float)base.Height - 3f), this._cornerRadius))
			{
				using (Pen pen = new Pen(CustomMessageBox__2.Cyan, 2f))
				{
					pen.Alignment = PenAlignment.Center;
					pen.LineJoin = LineJoin.Round;
					graphics.DrawPath(pen, graphicsPath);
				}
			}
		}

		// Token: 0x06000D74 RID: 3444 RVA: 0x0000962F File Offset: 0x0000962F
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			this.UpdateFormRegion();
		}

		// Token: 0x06000D75 RID: 3445 RVA: 0x0000963E File Offset: 0x0000963E
		protected override void OnMouseDown(MouseEventArgs e)
		{
			base.OnMouseDown(e);
			if (e.Button == MouseButtons.Left)
			{
				CustomMessageBox__2.ReleaseCapture();
				CustomMessageBox__2.SendMessage(base.Handle, 161, 2, 0);
			}
		}

		// Token: 0x06000D76 RID: 3446
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x06000D77 RID: 3447
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		// Token: 0x06000D79 RID: 3449 RVA: 0x0000966D File Offset: 0x0000966D
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.UpdateFormRegion();
			base.Invalidate();
		}

		// Token: 0x06000D7A RID: 3450 RVA: 0x00009682 File Offset: 0x00009682
		private void UpdateFormRegion()
		{
			if (base.Width <= 0 || base.Height <= 0)
			{
				return;
			}
			RoundedHelper.SetRegion(this, this._cornerRadius);
		}

		// Token: 0x040011DD RID: 4573
		private static DialogResult _dialogResult;

		// Token: 0x040011DE RID: 4574
		private const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x040011DF RID: 4575
		private const int HT_CAPTION = 2;

		// Token: 0x040011E0 RID: 4576
		private Label titleLabel;

		// Token: 0x040011E1 RID: 4577
		private static readonly Color Cyan = Color.FromArgb(0, 255, 230);

		// Token: 0x040011E2 RID: 4578
		private static readonly Color CyanDark = Color.FromArgb(0, 145, 135);

		// Token: 0x040011E3 RID: 4579
		private static readonly Color BgDark = Color.FromArgb(18, 23, 29);

		// Token: 0x040011E4 RID: 4580
		private static readonly Color BgPanel = Color.FromArgb(22, 28, 35);

		// Token: 0x040011E5 RID: 4581
		private static readonly Color BgButton = Color.FromArgb(32, 40, 47);

		// Token: 0x040011E6 RID: 4582
		private static readonly Color BgButtonHover = Color.FromArgb(45, 60, 70);

		// Token: 0x040011E7 RID: 4583
		private static readonly Color TextFore = Color.FromArgb(235, 240, 245);

		// Token: 0x040011E8 RID: 4584
		private static readonly Color TextTitle = Color.FromArgb(255, 215, 0);

		// Token: 0x040011E9 RID: 4585
		private RoundedPanel contentPanel;

		// Token: 0x040011EA RID: 4586
		private int _cornerRadius = 14;
	}
}
