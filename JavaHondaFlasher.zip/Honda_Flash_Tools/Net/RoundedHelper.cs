﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020005E2 RID: 1506
	public static class RoundedHelper
	{
		// Token: 0x06000E5A RID: 3674 RVA: 0x00009DD0 File Offset: 0x00009DD0
		public static GraphicsPath RoundedRect(Rectangle bounds, int radius)
		{
			return RoundedHelper.RoundedRectF(new RectangleF((float)bounds.X, (float)bounds.Y, (float)bounds.Width, (float)bounds.Height), radius);
		}

		// Token: 0x06000E5B RID: 3675 RVA: 0x00009DFD File Offset: 0x00009DFD
		public static void ApplyRounded(Control c, int radius)
		{
			RoundedHelper.SetRegion(c, radius);
		}

		// Token: 0x06000E5C RID: 3676 RVA: 0x00069DF8 File Offset: 0x00069DF8
		public static void SetRegion(Control c, int radius)
		{
			if (c == null || c.IsDisposed)
			{
				return;
			}
			if (c.Width <= 0 || c.Height <= 0)
			{
				return;
			}
			if (radius <= 0)
			{
				return;
			}
			try
			{
				using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(new RectangleF(0f, 0f, (float)c.Width, (float)c.Height), radius))
				{
					Region region = c.Region;
					c.Region = new Region(graphicsPath);
					if (region != null)
					{
						region.Dispose();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000E5D RID: 3677 RVA: 0x00069E98 File Offset: 0x00069E98
		public static GraphicsPath RoundedRectF(RectangleF bounds, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			if (bounds.Width <= 0f || bounds.Height <= 0f)
			{
				graphicsPath.AddRectangle(new RectangleF(0f, 0f, 1f, 1f));
				return graphicsPath;
			}
			if (radius <= 0)
			{
				graphicsPath.AddRectangle(bounds);
				return graphicsPath;
			}
			float num = (float)radius * 2f;
			if (num > bounds.Width)
			{
				num = bounds.Width;
			}
			if (num > bounds.Height)
			{
				num = bounds.Height;
			}
			if (num <= 0f)
			{
				graphicsPath.AddRectangle(bounds);
				return graphicsPath;
			}
			RectangleF rect = new RectangleF(bounds.X, bounds.Y, num, num);
			graphicsPath.AddArc(rect, 180f, 90f);
			rect.X = bounds.Right - num;
			graphicsPath.AddArc(rect, 270f, 90f);
			rect.Y = bounds.Bottom - num;
			graphicsPath.AddArc(rect, 0f, 90f);
			rect.X = bounds.X;
			graphicsPath.AddArc(rect, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}
	}
}
