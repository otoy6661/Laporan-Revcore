﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO.Ports;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000678 RID: 1656
	public partial class LIVE_DATA : Form
	{
		// Token: 0x06000FA5 RID: 4005 RVA: 0x0006FD5C File Offset: 0x0006FD5C
		public LIVE_DATA()
		{
			this.InitializeComponent();
			this.InitializeSerialPort();
			this.InitializeTimer();
			this.string_4 = "7205710018020F7100";
			this.string_5 = "";
			this.string_10 = new string[51];
			this.string_15 = new string[31];
			this.int_5 = 0;
			this.int_6 = 0;
			this.bool_4 = false;
			this.byte_2 = new byte[7];
			this.byte_3 = new byte[7];
			this.byte_4 = new byte[7];
			this.byte_5 = new byte[7];
			this.bool_5 = new bool[31];
			this.bool_6 = false;
			this.bool_7 = false;
			this.bool_8 = true;
			this.method_72();
			this.InitializeCircularGauges();
		}

		// Token: 0x06000FA6 RID: 4006 RVA: 0x0006FE24 File Offset: 0x0006FE24
		private double HexToDouble(string hexString)
		{
			if (string.IsNullOrEmpty(hexString))
			{
				return 0.0;
			}
			string value = hexString.Replace("&H", "");
			double result;
			try
			{
				result = (double)Convert.ToInt32(value, 16);
			}
			catch
			{
				result = 0.0;
			}
			return result;
		}

		// Token: 0x06000FA7 RID: 4007 RVA: 0x0006FE80 File Offset: 0x0006FE80
		private List<string> GetAvailableCOMPorts()
		{
			List<string> list = new List<string>();
			try
			{
				string[] portNames = SerialPort.GetPortNames();
				if (portNames != null && portNames.Length != 0)
				{
					foreach (string text in portNames)
					{
						if (!string.IsNullOrEmpty(text) && !list.Contains(text))
						{
							list.Add(text);
						}
					}
				}
			}
			catch
			{
			}
			try
			{
				list.Sort(delegate(string a, string b)
				{
					string s = a.Substring(3);
					string s2 = b.Substring(3);
					int num;
					int value;
					if (int.TryParse(s, out num) && int.TryParse(s2, out value))
					{
						return num.CompareTo(value);
					}
					return string.Compare(a, b, StringComparison.OrdinalIgnoreCase);
				});
			}
			catch
			{
			}
			return list;
		}

		// Token: 0x06000FA8 RID: 4008 RVA: 0x0006FF20 File Offset: 0x0006FF20
		private void method_01()
		{
			try
			{
				List<GClass1> list = GClass1.smethod_0();
				if (list != null)
				{
					string text = "";
					bool flag = false;
					foreach (GClass1 gclass in list)
					{
						if (gclass != null)
						{
							string string_ = gclass.String_1;
							if (string_ != null && (string_.IndexOf("FTDIBUS\\VID_0403+PID_6001+B5") > -1 || string_.IndexOf("USB\\VID_0403+PID_6001+B5") > -1 || string_.IndexOf("FTDIBUS\\VID_0403+PID_6001+A5") > -1 || string_.IndexOf("USB\\VID_0403+PID_6001+A5") > -1 || string_.IndexOf("USB\\VID_0403+PID_6001") > -1 || string_.IndexOf("FTDIBUS\\VID_0403+PID_6001") > -1))
							{
								if (this.txtCOMName != null)
								{
									this.txtCOMName.Text = gclass.String_0;
								}
								flag = true;
								double num;
								if (string_.Length > 33 && double.TryParse(string_.Substring(30, 3), out num))
								{
									text = (num * 2.0).ToString();
								}
								Application.DoEvents();
								break;
							}
						}
					}
					if (!flag)
					{
						List<string> availableCOMPorts = this.GetAvailableCOMPorts();
						if (availableCOMPorts.Count > 0 && this.txtCOMName != null)
						{
							this.txtCOMName.Text = availableCOMPorts[0];
						}
					}
					if (text.Length > 1 && this.stsSNCable != null)
					{
						Thread.Sleep(1000);
						this.stsSNCable.Text = "Cable: " + text;
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000FA9 RID: 4009 RVA: 0x000700D4 File Offset: 0x000700D4
		private void method_11()
		{
			try
			{
				if (this.SerialPort_0 != null && this.SerialPort_0.IsOpen)
				{
					while (this.SerialPort_0.BytesToRead > 0)
					{
						try
						{
							this.byte_0 = checked((byte)this.SerialPort_0.ReadByte());
							base.Invoke(new EventHandler(this.method_12));
						}
						catch (Exception)
						{
						}
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000FAA RID: 4010 RVA: 0x00070154 File Offset: 0x00070154
		public void method_12(object sender, EventArgs e)
		{
			try
			{
				int num = (int)this.byte_0;
				string str = num.ToString("X2");
				if (this.string_9 == null)
				{
					this.string_9 = "";
				}
				this.string_9 += str;
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000FAB RID: 4011 RVA: 0x000701B0 File Offset: 0x000701B0
		private void method_1111()
		{
			if (this.SerialPort_0.IsOpen)
			{
				this.SerialPort_0.Write("MicroCommand");
				return;
			}
			try
			{
				this.SerialPort_0.PortName = this.txtCOMName.Text;
				this.SerialPort_0.BaudRate = 10400;
				this.SerialPort_0.Parity = Parity.None;
				this.SerialPort_0.DataBits = 8;
				this.SerialPort_0.StopBits = StopBits.One;
				this.SerialPort_0.Handshake = Handshake.None;
				this.SerialPort_0.RtsEnable = true;
				this.SerialPort_0.Open();
			}
			catch (Exception)
			{
				MessageBox.Show("Pasang Usb/Modul Remap\r\nUntuk Mulai Menggunakan live Data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x06000FAC RID: 4012 RVA: 0x00070274 File Offset: 0x00070274
		private void method_72()
		{
			this.string_10[6] = "ECM TIDAK DIKETAHUI ATAU KOSONG\r\nHUBUNGI KIEMS TECH TUNER!";
			this.string_10[17] = "Module Remap Tidak Terhubung\r\nHarap periksa Alat Remap Anda";
			this.string_10[27] = "Tidak ada sensor MAP.";
			this.string_10[28] = "Tidak ada sensor Oksigen.";
			this.string_10[29] = "Tidak ada sensor IAT.";
			this.string_10[30] = "LARI..";
			this.string_10[0] = "TOLONG HUBUNGKAN MODULE REMAP KE KOMPUTER";
			this.string_10[1] = "HUBUNGKAN PERANGKAT USB ➤ SUKSES";
			this.string_10[31] = "MULAI";
			this.string_10[32] = "Sensor Posisi Throttle (TPS)";
			this.string_10[33] = "Kecepatan Mesin (RPM)";
			this.string_10[34] = "Waktu Injeksi (INJ)";
			this.string_10[35] = "Waktu Pengapian Maju (IGT)";
			this.string_10[36] = "Suhu Pendingin Mesin (ECT)";
			this.string_10[37] = "Tegangan Sensor Oksigen (O2)";
			this.string_10[38] = "Tegangan baterai dan muatan (BAT)";
			this.string_10[39] = "Rasio Bahan Bakar Udara (A/F)";
			this.string_10[45] = "Manifold Absolute Pressure (MAP)";
			this.string_10[40] = "Selesai Penghapusan Data Eror Di ECM.";
			this.string_10[41] = "Reset ECM berhasil. OFF/ON Kunci Kontak dan jalankan mesin selama 10 menit";
			this.string_10[42] = "DIAGNOSTIC PC";
			this.string_10[43] = "-";
			this.string_10[50] = "Catatan: Parameter referensi pada suhu mesin > 60 *C dan dalam mode jaminan";
		}

		// Token: 0x06000FAD RID: 4013 RVA: 0x000703C0 File Offset: 0x000703C0
		private void method_96()
		{
			byte[] array = new byte[]
			{
				114,
				7,
				114,
				19,
				0,
				14,
				244
			};
			byte[] array2 = new byte[]
			{
				114,
				7,
				114,
				23,
				0,
				15,
				239
			};
			try
			{
				if (!this.SerialPort_0.IsOpen)
				{
					this.SerialPort_0.PortName = this.txtCOMName.Text;
					this.SerialPort_0.Open();
					Thread.Sleep(100);
				}
				this.SerialPort_0.ReadExisting();
				this.SerialPort_0.Write(array, 0, array.Length);
				Thread.Sleep(100);
				this.string_9 = null;
				this.method_11();
				if (!string.IsNullOrEmpty(this.string_9) && this.string_9.Length > 30)
				{
					this.int_3 = 7;
				}
				else
				{
					this.SerialPort_0.ReadExisting();
					Thread.Sleep(100);
					this.SerialPort_0.Write(array2, 0, array2.Length);
					Thread.Sleep(100);
					this.string_9 = null;
					this.method_11();
					if (!string.IsNullOrEmpty(this.string_9) && this.string_9.Length > 30)
					{
						this.int_3 = 4;
						this.int_4 = ((this.string_9.Length > 36 && this.string_9.Substring(32, 4) == "FFFF") ? 4 : 8);
					}
					else
					{
						this.int_3 = 1;
					}
				}
				this.SetCommandBytes();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error initializing: " + ex.Message, "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.Timer_0.Enabled = false;
				this.SerialPort_0.Close();
			}
		}

		// Token: 0x06000FAE RID: 4014 RVA: 0x0000AA31 File Offset: 0x0000AA31
		private void method_134()
		{
			this.Timer_0.Enabled = false;
			Thread.Sleep(3000);
		}

		// Token: 0x06000FAF RID: 4015 RVA: 0x0000AA49 File Offset: 0x0000AA49
		private void Timer_0_Tick(object sender, EventArgs e)
		{
			this.method_99();
		}

		// Token: 0x06000FB0 RID: 4016 RVA: 0x00070570 File Offset: 0x00070570
		private void method_99()
		{
			try
			{
				if (this.SerialPort_0 != null && this.SerialPort_0.IsOpen && this.byte_2 != null && this.byte_3 != null && this.byte_4 != null && this.byte_5 != null)
				{
					this.SerialPort_0.Write(this.byte_2, 0, this.byte_2.Length);
					Thread.Sleep(50);
					this.SerialPort_0.Write(this.byte_3, 0, this.byte_3.Length);
					Thread.Sleep(50);
					this.SerialPort_0.Write(this.byte_4, 0, this.byte_4.Length);
					Thread.Sleep(50);
					this.SerialPort_0.Write(this.byte_5, 0, this.byte_5.Length);
					Thread.Sleep(50);
					this.string_9 = null;
					this.method_11();
					if (!string.IsNullOrEmpty(this.string_9))
					{
						if (this.int_3 == 1)
						{
							this.method_100();
						}
						else if (this.int_3 == 4)
						{
							this.method_101();
						}
						else if (this.int_3 == 7)
						{
							this.method_102();
						}
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000FB1 RID: 4017 RVA: 0x000706B4 File Offset: 0x000706B4
		private void method_100()
		{
			double num = this.HexToDouble(this.string_9.Substring(24, 2)) * 256.0 + this.HexToDouble(this.string_9.Substring(26, 2));
			if (this.int_9 == 1)
			{
				this.method_119(num);
				this.method_126(num);
			}
			if (this.circularRPMGauge != null)
			{
				this.circularRPMGauge.Value = num;
				if (num >= 10000.0)
				{
					this.circularRPMGauge.BarColor = LIVE_DATA.NeonRed;
				}
				else if (num >= 8000.0)
				{
					this.circularRPMGauge.BarColor = LIVE_DATA.NeonAmber;
				}
				else
				{
					this.circularRPMGauge.BarColor = LIVE_DATA.NeonCyan;
				}
				this.circularRPMGauge.Invalidate();
			}
			this.label_rpm.Text = num.ToString();
			if (num >= 10000.0)
			{
				this.label_rpm.ForeColor = LIVE_DATA.NeonRed;
			}
			else if (num >= 9500.0)
			{
				this.label_rpm.ForeColor = Color.DodgerBlue;
			}
			else if (num >= 8000.0)
			{
				this.label_rpm.ForeColor = LIVE_DATA.NeonGreen;
			}
			else
			{
				this.label_rpm.ForeColor = Color.Cyan;
			}
			this.bool_5[0] = !(num < 1300.0 | num > 15000.0);
			this.bool_7 = (num > 1000.0 & num < 2000.0);
			num = (this.HexToDouble(this.string_9.Substring(52, 2)) * 256.0 + this.HexToDouble(this.string_9.Substring(54, 2))) / 250.0;
			num = Math.Round(num, 1);
			if (this.int_9 == 2)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.label_injector.Text = num.ToString() + " ms";
			this.label_injector.ForeColor = ((num >= 4.0) ? LIVE_DATA.NeonRed : ((num >= 3.5) ? Color.DodgerBlue : ((num >= 1.9) ? Color.DodgerBlue : Color.White)));
			this.bool_5[1] = !(num < 1.9 | num > 2.8);
			num = (this.HexToDouble(this.string_9.Substring(56, 2)) - 128.0) * 0.5;
			if (this.int_9 == 3)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.label_ignition.Text = num.ToString() + " deg(°)";
			this.label_ignition.ForeColor = ((num >= 20.0) ? LIVE_DATA.NeonRed : ((num >= 14.7) ? Color.DodgerBlue : ((num >= 13.4) ? LIVE_DATA.NeonGreen : Color.White)));
			this.bool_5[2] = !(num < 5.0 | num > 70.0);
			num = this.HexToDouble(this.string_9.Substring(30, 2)) * 0.5;
			if (this.int_9 == 0)
			{
				this.method_119(num);
				this.method_126(num);
			}
			if (this.circularTPSGauge != null)
			{
				this.circularTPSGauge.Value = num;
				if (num >= 70.0)
				{
					this.circularTPSGauge.BarColor = LIVE_DATA.NeonCyan;
				}
				else if (num >= 30.0)
				{
					this.circularTPSGauge.BarColor = Color.Yellow;
				}
				else
				{
					this.circularTPSGauge.BarColor = LIVE_DATA.NeonRed;
				}
				this.circularTPSGauge.Invalidate();
			}
			this.TPS.Text = num.ToString();
			this.string_15[2] = num.ToString();
			this.bool_5[3] = !(num < 0.0 | num > 79.0);
			num = this.HexToDouble(this.string_9.Substring(28, 2)) * 195.0 / 10.0;
			this.label_tps_volt.Text = Math.Round(num, 0).ToString() + " V";
			this.label_tps_volt.ForeColor = ((num >= 4500.0) ? LIVE_DATA.NeonRed : ((num >= 488.0) ? LIVE_DATA.NeonGreen : ((num >= 400.0) ? Color.DodgerBlue : Color.White)));
			this.bool_5[4] = !(num < 290.0 | num > 4500.0);
			num = this.HexToDouble(this.string_9.Substring(90, 2)) * 195.0 / 10.0;
			num = Math.Round(num, 0);
			if (this.int_9 == 5)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.label_O2_volt.Text = num.ToString() + " V";
			this.label_O2_volt.ForeColor = ((num >= 800.0) ? LIVE_DATA.NeonRed : ((num >= 500.0) ? Color.DodgerBlue : ((num >= 200.0) ? LIVE_DATA.NeonGreen : Color.White)));
			this.bool_5[5] = !(num < 200.0 | num > 800.0);
			num = this.HexToDouble(this.string_9.Substring(92, 2)) * 39.0 / 50.0 - 100.0;
			this.label_fuel_flow.Text = Math.Round(num, 0).ToString() + " %";
			this.bool_5[6] = !(num < -10.0 | num > 10.0);
			num = this.HexToDouble(this.string_9.Substring(34, 2)) - 40.0;
			if (this.int_9 == 4)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.label_suhu.Text = num.ToString() + " °C";
			this.label_suhu.ForeColor = ((num >= 100.0) ? LIVE_DATA.NeonRed : ((num >= 90.0) ? Color.DodgerBlue : ((num >= 80.0) ? LIVE_DATA.NeonGreen : Color.White)));
			this.bool_5[7] = !(num < 0.0 | num > 120.0);
			this.bool_6 = (num > 60.0);
			num = this.HexToDouble(this.string_9.Substring(32, 2)) * 195.0 / 10.0;
			this.ect_volt.Text = Math.Round(num, 0).ToString() + " V";
			this.bool_5[8] = !(num < 430.0 | num > 4540.0);
			num = this.HexToDouble(this.string_9.Substring(38, 2)) - 40.0;
			this.label_iat_temp.Text = num.ToString() + " °C";
			this.label_iat_temp.ForeColor = ((num >= 170.0) ? LIVE_DATA.NeonRed : ((num >= 160.0) ? LIVE_DATA.NeonGreen : ((num >= 80.0) ? Color.DodgerBlue : Color.White)));
			this.bool_5[9] = !(num < 0.0 | num > 60.0);
			num = this.HexToDouble(this.string_9.Substring(36, 2)) * 195.0 / 10.0;
			this.label_iat_volt.Text = Math.Round(num, 0).ToString() + " V";
			this.bool_5[10] = !(num < 1330.0 | num > 4500.0);
			num = this.HexToDouble(this.string_9.Substring(42, 2));
			if (this.int_9 == 8)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.label_map.Text = num.ToString() + " kPa";
			this.bool_5[11] = !(num < 34.0 | num > 98.0);
			this.bool_5[12] = true;
			num = this.HexToDouble(this.string_9.Substring(50, 2));
			this.bool_5[13] = true;
			num = this.HexToDouble(this.string_9.Substring(48, 2)) / 10.0;
			num = Math.Round(num, 1);
			if (this.int_9 == 6)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.label_batrei.Text = num.ToString() + " V";
			this.label_batrei.ForeColor = ((num >= 14.5) ? LIVE_DATA.NeonRed : ((num >= 11.5) ? LIVE_DATA.NeonGreen : ((num >= 10.5) ? Color.DodgerBlue : LIVE_DATA.NeonRed)));
			this.bool_5[14] = !(num < 13.0 | num > 15.0);
			num = this.HexToDouble(this.string_9.Substring(58, 2));
			this.label_iacv.Text = Math.Round(num, 0).ToString() + " st";
			this.bool_5[15] = !(num < 40.0 | num > 70.0);
			this.label_coeffisient.Text = "—";
			this.bool_5[16] = true;
			num = this.HexToDouble(this.string_9.Substring(92, 2));
			if (num >= 128.0)
			{
				num = (num - 128.0) * 100.0 / 87.0 + 147.0;
			}
			else
			{
				num = 147.0 - (128.0 - num) * 100.0 / 87.0;
			}
			num = Math.Round(num / 10.0, 1);
			if (this.int_9 == 7)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.label_afr.Text = num.ToString() + " : 1";
			this.label_afr.ForeColor = ((num >= 14.8) ? Color.DodgerBlue : ((num >= 14.7) ? LIVE_DATA.NeonGreen : ((num >= 13.0) ? LIVE_DATA.NeonCyan : LIVE_DATA.NeonRed)));
			this.bool_5[17] = !(num < 13.2 | num > 16.5);
			double num2;
			if (this.string_9.Length < 115)
			{
				num2 = 0.0;
			}
			else
			{
				num2 = this.HexToDouble(this.string_9.Substring(128, 2));
			}
			checked
			{
				this.label_fuelpump.Text = ((((long)Math.Round(num2) & 1L) > 0L) ? "ON" : "OFF");
				this.label_fuelpump.ForeColor = ((((long)Math.Round(num2) & 1L) > 0L) ? LIVE_DATA.NeonGreen : LIVE_DATA.NeonRed);
				this.bool_5[18] = true;
				num2 = ((this.string_9.Length < 115) ? 0.0 : this.HexToDouble(this.string_9.Substring(120, 2)));
				this.label_stand_samping.Text = ((((long)Math.Round(num2) & 2L) > 0L) ? "ON" : "OFF");
				this.label_stand_samping.ForeColor = ((((long)Math.Round(num2) & 2L) > 0L) ? LIVE_DATA.NeonGreen : LIVE_DATA.NeonRed);
				this.bool_5[19] = true;
				num2 = ((this.string_9.Length < 115) ? 0.0 : this.HexToDouble(this.string_9.Substring(120, 2)));
				this.label_stater.Text = ((((long)Math.Round(num2) & 32L) > 0L) ? "ON" : "OFF");
				this.label_stater.ForeColor = ((((long)Math.Round(num2) & 32L) > 0L) ? LIVE_DATA.NeonGreen : LIVE_DATA.NeonRed);
				this.bool_5[20] = true;
				num2 = ((this.string_9.Length < 115) ? 0.0 : this.HexToDouble(this.string_9.Substring(128, 2)));
				this.label_relay.Text = ((((long)Math.Round(num2) & 144L) > 0L) ? "ON" : "OFF");
				this.label_relay.ForeColor = ((((long)Math.Round(num2) & 144L) > 0L) ? LIVE_DATA.NeonGreen : LIVE_DATA.NeonRed);
				this.bool_5[21] = true;
				num2 = ((this.string_9.Length < 115) ? 0.0 : this.HexToDouble(this.string_9.Substring(158, 2)));
				this.label_miL.Text = ((num2 >= 128.0) ? "ON" : "OFF");
				this.label_miL.ForeColor = ((num2 >= 128.0) ? LIVE_DATA.NeonGreen : LIVE_DATA.NeonRed);
				this.bool_5[22] = true;
			}
		}

		// Token: 0x06000FB2 RID: 4018 RVA: 0x000714CC File Offset: 0x000714CC
		private void method_101()
		{
			if (this.int_4 != 8)
			{
				int num = this.int_4;
			}
			double num2 = this.HexToDouble(this.string_9.Substring(24, 2)) * 256.0 + this.HexToDouble(this.string_9.Substring(26, 2));
			if (this.int_9 == 1)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			if (this.circularRPMGauge != null)
			{
				this.circularRPMGauge.Value = num2;
				if (num2 >= 10000.0)
				{
					this.circularRPMGauge.BarColor = LIVE_DATA.NeonRed;
				}
				else if (num2 >= 8000.0)
				{
					this.circularRPMGauge.BarColor = LIVE_DATA.NeonAmber;
				}
				else
				{
					this.circularRPMGauge.BarColor = LIVE_DATA.NeonCyan;
				}
				this.circularRPMGauge.Invalidate();
			}
			this.label_rpm.Text = num2.ToString();
			this.label_rpm.ForeColor = ((num2 >= 10000.0) ? LIVE_DATA.NeonRed : ((num2 >= 9500.0) ? Color.DodgerBlue : ((num2 >= 8000.0) ? LIVE_DATA.NeonGreen : Color.White)));
			this.bool_5[0] = (num2 >= 1200.0 && num2 <= 15000.0);
			this.bool_7 = (num2 > 1000.0 && num2 < 2000.0);
			num2 = (this.HexToDouble(this.string_9.Substring(46, 2)) * 256.0 + this.HexToDouble(this.string_9.Substring(48, 2))) / 250.0;
			num2 = Math.Round(num2, 1);
			if (this.int_9 == 2)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			this.label_injector.Text = num2.ToString() + " ms";
			this.label_injector.ForeColor = ((num2 >= 4.0) ? LIVE_DATA.NeonRed : ((num2 >= 3.5) ? Color.DodgerBlue : ((num2 >= 1.9) ? Color.DodgerBlue : Color.White)));
			this.bool_5[1] = (num2 >= 1.9 && num2 <= 2.8);
			num2 = (this.HexToDouble(this.string_9.Substring(50, 2)) - 128.0) * 0.5;
			if (this.int_9 == 3)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			this.label_ignition.Text = num2.ToString() + " (°)";
			this.label_ignition.ForeColor = ((num2 >= 20.0) ? LIVE_DATA.NeonRed : ((num2 >= 14.7) ? Color.DodgerBlue : ((num2 >= 13.4) ? LIVE_DATA.NeonGreen : Color.White)));
			this.bool_5[2] = (num2 >= 5.0 && num2 <= 70.0);
			num2 = this.HexToDouble(this.string_9.Substring(30, 2)) * 0.5;
			if (this.int_9 == 0)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			if (this.circularTPSGauge != null)
			{
				this.circularTPSGauge.Value = num2;
				if (num2 >= 70.0)
				{
					this.circularTPSGauge.BarColor = LIVE_DATA.NeonCyan;
				}
				else if (num2 >= 30.0)
				{
					this.circularTPSGauge.BarColor = Color.Yellow;
				}
				else
				{
					this.circularTPSGauge.BarColor = LIVE_DATA.NeonRed;
				}
				this.circularTPSGauge.Invalidate();
			}
			this.TPS.Text = num2.ToString();
			this.bool_5[3] = (num2 >= 0.0 && num2 <= 79.0);
			num2 = this.HexToDouble(this.string_9.Substring(28, 2)) * 195.0 / 10.0;
			this.label_tps_volt.Text = Math.Round(num2, 0).ToString() + " V";
			this.label_tps_volt.ForeColor = ((num2 >= 4500.0) ? LIVE_DATA.NeonRed : ((num2 >= 488.0) ? LIVE_DATA.NeonGreen : ((num2 >= 400.0) ? Color.DodgerBlue : Color.White)));
			this.bool_5[4] = (num2 >= 290.0 && num2 <= 4500.0);
			num2 = this.HexToDouble(this.string_9.Substring(118, 2)) * 195.0 / 10.0;
			num2 = Math.Round(num2, 0);
			if (this.int_9 == 5)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			this.label_O2_volt.Text = num2.ToString() + " V";
			this.label_O2_volt.ForeColor = ((num2 >= 800.0) ? LIVE_DATA.NeonRed : ((num2 >= 500.0) ? Color.DodgerBlue : ((num2 >= 200.0) ? LIVE_DATA.NeonGreen : Color.White)));
			this.bool_5[5] = (num2 >= 200.0 && num2 <= 800.0);
			num2 = this.HexToDouble(this.string_9.Substring(120, 2)) * 39.0 / 50.0 - 100.0;
			this.label_fuel_flow.Text = Math.Round(num2, 0).ToString() + " %";
			this.bool_5[6] = (num2 >= -10.0 && num2 <= 10.0);
			num2 = this.HexToDouble(this.string_9.Substring(34, 2)) - 40.0;
			if (this.int_9 == 4)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			this.label_suhu.Text = num2.ToString() + " °C";
			this.label_suhu.ForeColor = ((num2 >= 100.0) ? LIVE_DATA.NeonRed : ((num2 >= 90.0) ? Color.DodgerBlue : ((num2 >= 80.0) ? LIVE_DATA.NeonGreen : Color.White)));
			this.bool_5[7] = (num2 >= 0.0 && num2 <= 120.0);
			this.bool_6 = (num2 > 60.0);
			num2 = this.HexToDouble(this.string_9.Substring(32, 2)) * 195.0 / 10.0;
			this.ect_volt.Text = Math.Round(num2, 0).ToString() + " V";
			this.bool_5[8] = (num2 >= 430.0 && num2 <= 4540.0);
			num2 = this.HexToDouble(this.string_9.Substring(38, 2)) - 40.0;
			this.label_iat_temp.Text = num2.ToString() + " °C";
			this.label_iat_temp.ForeColor = ((num2 >= 170.0) ? LIVE_DATA.NeonRed : ((num2 >= 160.0) ? LIVE_DATA.NeonGreen : ((num2 >= 80.0) ? Color.DodgerBlue : Color.White)));
			this.bool_5[9] = (num2 >= 0.0 && num2 <= 60.0);
			num2 = this.HexToDouble(this.string_9.Substring(36, 2)) * 195.0 / 10.0;
			this.label_iat_volt.Text = Math.Round(num2, 0).ToString() + " V";
			this.bool_5[10] = (num2 >= 1330.0 && num2 <= 4500.0);
			if (string.Equals(this.string_9.Substring(38, 2), "FF", StringComparison.OrdinalIgnoreCase) && string.Equals(this.string_9.Substring(36, 2), "FF", StringComparison.OrdinalIgnoreCase))
			{
				this.string_15[9] = this.string_10[43];
				this.string_15[10] = this.string_10[43];
				this.bool_5[9] = true;
				this.bool_5[10] = true;
			}
			this.label_map.Text = this.string_10[43];
			this.bool_5[11] = true;
			if (this.int_9 == 8)
			{
				this.method_119(0.0);
				this.method_126(0.0);
			}
			this.label_map_volt.Text = this.string_10[43];
			this.bool_5[12] = true;
			this.bool_5[13] = true;
			num2 = this.HexToDouble(this.string_9.Substring(44, 2)) / 10.0;
			num2 = Math.Round(num2, 1);
			if (this.int_9 == 6)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			this.label_batrei.Text = num2.ToString() + " V";
			this.label_batrei.ForeColor = ((num2 >= 14.5) ? LIVE_DATA.NeonRed : ((num2 >= 11.5) ? LIVE_DATA.NeonGreen : ((num2 >= 10.5) ? Color.DodgerBlue : LIVE_DATA.NeonRed)));
			this.bool_5[14] = (num2 >= 13.0 && num2 <= 15.0);
			num2 = this.HexToDouble(this.string_9.Substring(88, 2));
			if (checked((long)Math.Round(num2)) / 16L == 4L)
			{
				this.label_iacv.Text = "ON";
				this.label_iacv.ForeColor = LIVE_DATA.NeonGreen;
			}
			else
			{
				this.label_iacv.Text = "OFF";
				this.label_iacv.ForeColor = LIVE_DATA.NeonRed;
			}
			this.bool_5[15] = true;
			num2 = this.HexToDouble(this.string_9.Substring(52, 2)) * 39.0 / 50.0 - 100.0;
			this.label_coeffisient.Text = Math.Round(num2, 0).ToString() + " %";
			this.bool_5[16] = (num2 >= -10.0 && num2 <= 10.0);
			num2 = this.HexToDouble(this.string_9.Substring(120, 2));
			if (num2 >= 128.0)
			{
				num2 = (num2 - 128.0) * 100.0 / 87.0 + 147.0;
			}
			else
			{
				num2 = 147.0 - (128.0 - num2) * 100.0 / 87.0;
			}
			num2 = Math.Round(num2 / 10.0, 1);
			if (this.int_9 == 7)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			this.label_afr.Text = num2.ToString() + " : 1";
			this.label_afr.ForeColor = ((num2 >= 14.8) ? Color.DodgerBlue : ((num2 >= 14.7) ? LIVE_DATA.NeonGreen : ((num2 >= 13.0) ? LIVE_DATA.NeonCyan : LIVE_DATA.NeonRed)));
			this.bool_5[17] = (num2 >= 13.2 && num2 <= 16.5);
			double num3;
			double.TryParse(this.label_afr.Text, out num3);
			if (this.string_9.Length < 80)
			{
				num2 = 0.0;
			}
			else
			{
				num2 = this.HexToDouble(this.string_9.Substring(88, 2));
			}
			checked
			{
				this.label_fuelpump.Text = ((((long)Math.Round(num2) & 1L) > 0L) ? "ON" : "OFF");
				this.label_fuelpump.ForeColor = ((((long)Math.Round(num2) & 1L) > 0L) ? LIVE_DATA.NeonGreen : LIVE_DATA.NeonRed);
				this.bool_5[18] = true;
				num2 = ((this.string_9.Length < 78) ? 0.0 : this.HexToDouble(this.string_9.Substring(80, 2)));
				this.label_stand_samping.Text = ((((long)Math.Round(num2) & 2L) > 0L) ? "ON" : "OFF");
				this.label_stand_samping.ForeColor = ((((long)Math.Round(num2) & 2L) > 0L) ? LIVE_DATA.NeonGreen : LIVE_DATA.NeonRed);
				this.bool_5[19] = true;
				num2 = ((this.string_9.Length < 78) ? 0.0 : this.HexToDouble(this.string_9.Substring(80, 2)));
				this.label_stater.Text = ((((long)Math.Round(num2) & 32L) > 0L) ? "ON" : "OFF");
				this.label_stater.ForeColor = ((((long)Math.Round(num2) & 32L) > 0L) ? LIVE_DATA.NeonGreen : LIVE_DATA.NeonRed);
				this.bool_5[20] = true;
				num2 = ((this.string_9.Length < 80) ? 0.0 : this.HexToDouble(this.string_9.Substring(88, 2)));
				this.label_relay.Text = ((((long)Math.Round(num2) & 144L) > 0L) ? "ON" : "OFF");
				this.label_relay.ForeColor = ((((long)Math.Round(num2) & 144L) > 0L) ? LIVE_DATA.NeonGreen : LIVE_DATA.NeonRed);
				this.bool_5[21] = true;
				num2 = ((this.string_9.Length < 140) ? 0.0 : this.HexToDouble(this.string_9.Substring(148, 2)));
				this.label_miL.Text = ((num2 >= 128.0) ? "ON" : "OFF");
				this.label_miL.ForeColor = ((num2 >= 128.0) ? LIVE_DATA.NeonGreen : LIVE_DATA.NeonRed);
				this.bool_5[22] = true;
			}
		}

		// Token: 0x06000FB3 RID: 4019 RVA: 0x000723AC File Offset: 0x000723AC
		private void method_102()
		{
			double num = this.HexToDouble(this.string_9.Substring(24, 2)) * 256.0 + this.HexToDouble(this.string_9.Substring(26, 2));
			if (this.int_9 == 1)
			{
				this.method_119(num);
				this.method_126(num);
			}
			if (this.circularRPMGauge != null)
			{
				this.circularRPMGauge.Value = num;
				if (num >= 10000.0)
				{
					this.circularRPMGauge.BarColor = LIVE_DATA.NeonRed;
				}
				else if (num >= 8000.0)
				{
					this.circularRPMGauge.BarColor = LIVE_DATA.NeonAmber;
				}
				else
				{
					this.circularRPMGauge.BarColor = LIVE_DATA.NeonCyan;
				}
				this.circularRPMGauge.Invalidate();
			}
			this.label_rpm.Text = num.ToString() + " Rpm";
			this.bool_5[0] = !(num < 1300.0 | num > 15000.0);
			this.bool_7 = (num > 1000.0 & num < 2000.0);
			num = (this.HexToDouble(this.string_9.Substring(46, 2)) * 256.0 + this.HexToDouble(this.string_9.Substring(48, 2))) / 250.0;
			num = Math.Round(num, 1);
			if (this.int_9 == 2)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.label_injector.Text = num.ToString() + " ms";
			this.bool_5[1] = !(num < 1.9 | num > 2.8);
			num = (this.HexToDouble(this.string_9.Substring(50, 2)) - 128.0) * 0.5;
			if (this.int_9 == 3)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[2] = num.ToString();
			this.bool_5[2] = !(num < 5.0 | num > 70.0);
			num = this.HexToDouble(this.string_9.Substring(30, 2)) * 0.5;
			if (this.int_9 == 0)
			{
				this.method_119(num);
				this.method_126(num);
			}
			if (this.circularTPSGauge != null)
			{
				this.circularTPSGauge.Value = num;
				if (num >= 70.0)
				{
					this.circularTPSGauge.BarColor = LIVE_DATA.NeonCyan;
				}
				else if (num >= 30.0)
				{
					this.circularTPSGauge.BarColor = Color.Yellow;
				}
				else
				{
					this.circularTPSGauge.BarColor = LIVE_DATA.NeonRed;
				}
				this.circularTPSGauge.Invalidate();
			}
			this.string_15[3] = num.ToString();
			this.bool_5[3] = !(num < 0.0 | num > 79.0);
			num = this.HexToDouble(this.string_9.Substring(28, 2)) * 195.0 / 10.0;
			this.string_15[4] = Math.Round(num, 0).ToString();
			this.bool_5[4] = !(num < 290.0 | num > 4500.0);
			num = this.HexToDouble(this.string_9.Substring(34, 2)) - 40.0;
			if (this.int_9 == 4)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[5] = num.ToString();
			this.bool_5[5] = !(num < 0.0 | num > 120.0);
			this.bool_6 = (num > 60.0);
			num = this.HexToDouble(this.string_9.Substring(32, 2)) * 195.0 / 10.0;
			this.string_15[6] = Math.Round(num, 0).ToString();
			this.bool_5[6] = !(num < 430.0 | num > 4540.0);
			num = this.HexToDouble(this.string_9.Substring(38, 2)) - 40.0;
			this.string_15[7] = num.ToString();
			this.bool_5[7] = !(num < 0.0 | num > 60.0);
			num = this.HexToDouble(this.string_9.Substring(36, 2)) * 195.0 / 10.0;
			this.string_15[8] = Math.Round(num, 0).ToString();
			this.bool_5[8] = !(num < 1330.0 | num > 4500.0);
			num = this.HexToDouble(this.string_9.Substring(42, 2));
			if (this.int_9 == 8)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[9] = num.ToString();
			this.bool_5[9] = !(num < 34.0 | num > 99.0);
			num = this.HexToDouble(this.string_9.Substring(40, 2)) * 195.0 / 10.0;
			this.string_15[10] = Math.Round(num, 0).ToString();
			this.bool_5[10] = !(num < 1000.0 | num > 3000.0);
			num = this.HexToDouble(this.string_9.Substring(44, 2)) / 10.0;
			num = Math.Round(num, 1);
			if (this.int_9 == 6)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.label_batrei.Text = num.ToString();
			this.bool_5[11] = !(num < 13.0 | num > 15.0);
			checked
			{
				num = (double)((long)Math.Round(this.HexToDouble(this.string_9.Substring(78, 2))) & 127L);
				this.string_15[12] = num.ToString();
				this.bool_5[12] = true;
				num = ((this.string_9.Length < 76) ? 0.0 : this.HexToDouble(this.string_9.Substring(78, 2)));
				this.string_15[13] = ((((long)Math.Round(num) & 128L) > 0L) ? "ON" : "OFF");
				this.bool_5[13] = true;
				num = ((this.string_9.Length < 138) ? 0.0 : this.HexToDouble(this.string_9.Substring(140, 2)));
				this.string_15[14] = ((((long)Math.Round(num) & 128L) > 0L) ? "ON" : "OFF");
				this.bool_5[14] = true;
			}
		}

		// Token: 0x06000FB4 RID: 4020 RVA: 0x000026F4 File Offset: 0x000026F4
		private void method_118()
		{
		}

		// Token: 0x06000FB5 RID: 4021 RVA: 0x000026F4 File Offset: 0x000026F4
		private void method_119(double double_6)
		{
		}

		// Token: 0x06000FB6 RID: 4022 RVA: 0x00072AE8 File Offset: 0x00072AE8
		private void method_126(double double_6)
		{
			this.txtCurrentTPS.Text = double_6.ToString();
			if (this.double_0 > double_6)
			{
				this.double_0 = double_6;
			}
			if (this.double_1 < double_6)
			{
				this.double_1 = double_6;
			}
			this.txtMaxTPS.Text = this.double_1.ToString();
			this.txtMaxRPM.Text = this.double_1.ToString() + " Rpm";
		}

		// Token: 0x06000FB7 RID: 4023 RVA: 0x0000AA51 File Offset: 0x0000AA51
		private void comGraphTPS_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.method_150();
		}

		// Token: 0x06000FB8 RID: 4024 RVA: 0x00072B60 File Offset: 0x00072B60
		private void method_140()
		{
			if (this.comGraphTPS.Items.Count < 3)
			{
				string[] array = new string[]
				{
					"Grafik TPS",
					"Grafik RPM",
					"Grafik INJ",
					"Grafik IGN",
					"Grafik ECT",
					"Grafik O2",
					"Grafik BAT",
					"Grafik AFR"
				};
				ComboBox.ObjectCollection items = this.comGraphTPS.Items;
				object[] array2 = array;
				object[] items2 = array2;
				items.AddRange(items2);
				this.comGraphTPS.Text = this.comGraphTPS.Items[1].ToString();
			}
		}

		// Token: 0x06000FB9 RID: 4025 RVA: 0x0000AA59 File Offset: 0x0000AA59
		private void method_143(int int_10, double double_6, double double_7, int int_11)
		{
			this.txtCurrentTPS.Text = "0";
			this.txtMaxTPS.Text = "0";
			this.double_1 = 0.0;
			this.double_0 = (double)int_11;
		}

		// Token: 0x06000FBA RID: 4026 RVA: 0x00072C00 File Offset: 0x00072C00
		private void method_150()
		{
			this.int_9 = this.comGraphTPS.SelectedIndex;
			switch (this.int_9)
			{
			case 0:
				this.method_143(0, 80.0, 10.0, 10);
				return;
			case 1:
				this.method_143(0, 18000.0, 1000.0, 2000);
				return;
			case 2:
				this.method_143(0, 12.0, 2.0, 2);
				return;
			case 3:
				this.method_143(-10, 70.0, 10.0, 15);
				return;
			case 4:
				this.method_143(-40, 180.0, 20.0, 60);
				return;
			case 5:
				this.method_143(0, 4000.0, 200.0, 1400);
				if (this.int_3 == 7)
				{
					MessageBox.Show(this.string_10[28], this.string_10[42], MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					return;
				}
				break;
			case 6:
				this.method_143(0, 18.0, 2.0, 12);
				return;
			case 7:
				this.method_143(6, 20.0, 2.0, 15);
				if (this.int_3 == 7)
				{
					MessageBox.Show(this.string_10[28], this.string_10[42], MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					return;
				}
				break;
			case 8:
				this.method_143(0, 120.0, 20.0, 90);
				if (this.int_3 == 4)
				{
					MessageBox.Show(this.string_10[27], this.string_10[42], MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					return;
				}
				break;
			default:
				return;
			}
		}

		// Token: 0x06000FBB RID: 4027 RVA: 0x00072DC4 File Offset: 0x00072DC4
		private void method_161()
		{
			this.panel1.Refresh();
			this.double_0 = 0.0;
			this.double_1 = 0.0;
			this.method_01();
			this.method_1111();
			this.method_134();
			this.method_96();
			this.Timer_0.Enabled = true;
		}

		// Token: 0x06000FBC RID: 4028 RVA: 0x0000AA93 File Offset: 0x0000AA93
		private void LIVE_DATA_Load(object sender, EventArgs e)
		{
			this.method_118();
			this.method_140();
			this.method_161();
			this.comGraphTPS.Visible = false;
			this.txtMaxTPS.Visible = false;
			this.txtCurrentTPS.Visible = false;
			this.SetupRoundedNeonForm();
		}

		// Token: 0x06000FBD RID: 4029 RVA: 0x00072E20 File Offset: 0x00072E20
		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				SerialPort serialPort_ = this.SerialPort_0;
				if (serialPort_ != null)
				{
					serialPort_.Close();
				}
			}
			catch
			{
			}
			Thread.Sleep(2);
			this.method_140();
			this.method_161();
		}

		// Token: 0x06000FBE RID: 4030 RVA: 0x00072E64 File Offset: 0x00072E64
		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				SerialPort serialPort_ = this.SerialPort_0;
				if (serialPort_ != null)
				{
					serialPort_.Close();
				}
			}
			catch
			{
			}
			this.Timer_0.Enabled = false;
		}

		// Token: 0x06000FBF RID: 4031 RVA: 0x00072EA4 File Offset: 0x00072EA4
		private void LIVE_DATA_FormClosed(object sender, FormClosedEventArgs e)
		{
			try
			{
				this.Timer_0.Enabled = false;
				if (this.SerialPort_0 != null && this.SerialPort_0.IsOpen)
				{
					this.SerialPort_0.Close();
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000FC0 RID: 4032 RVA: 0x000026F4 File Offset: 0x000026F4
		private void button4_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000FC1 RID: 4033 RVA: 0x000026F4 File Offset: 0x000026F4
		private void button3_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000FC2 RID: 4034 RVA: 0x000026F4 File Offset: 0x000026F4
		private void label_fuelpump_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000FC5 RID: 4037 RVA: 0x000739EC File Offset: 0x000739EC
		private void InitializeCircularGauges()
		{
			this.circularRPMGauge = new LIVE_DATA.NeonGauge
			{
				Dock = DockStyle.Fill,
				MinValue = 0.0,
				MaxValue = 15000.0,
				Unit = "RPM",
				BarColor = LIVE_DATA.NeonCyan,
				BackColor = Color.Transparent
			};
			this.circularTPSGauge = new LIVE_DATA.NeonGauge
			{
				Dock = DockStyle.Fill,
				MinValue = 0.0,
				MaxValue = 100.0,
				Unit = "%",
				BarColor = LIVE_DATA.NeonRed,
				BackColor = Color.Transparent
			};
			this.rpmGaugePanel.Controls.Add(this.circularRPMGauge);
			this.tpsGaugePanel.Controls.Add(this.circularTPSGauge);
		}

		// Token: 0x06000FC6 RID: 4038 RVA: 0x0000AAF0 File Offset: 0x0000AAF0
		private void InitializeSerialPort()
		{
			this.SerialPort_0 = new SerialPort
			{
				BaudRate = 10400,
				Parity = Parity.None,
				DataBits = 8,
				StopBits = StopBits.One,
				Handshake = Handshake.None,
				RtsEnable = true
			};
		}

		// Token: 0x06000FC7 RID: 4039 RVA: 0x0000AB2B File Offset: 0x0000AB2B
		private void InitializeTimer()
		{
			this.Timer_0 = new System.Windows.Forms.Timer
			{
				Interval = 500
			};
			this.Timer_0.Tick += this.Timer_0_Tick;
		}

		// Token: 0x06000FC8 RID: 4040 RVA: 0x00073AC8 File Offset: 0x00073AC8
		private void SetCommandBytes()
		{
			if (this.int_3 == 1)
			{
				this.byte_2 = new byte[]
				{
					114,
					7,
					114,
					17,
					0,
					20,
					240
				};
				this.byte_3 = new byte[]
				{
					114,
					7,
					114,
					32,
					0,
					2,
					243
				};
				this.byte_4 = new byte[]
				{
					114,
					7,
					114,
					209,
					0,
					6,
					62
				};
				this.byte_5 = new byte[]
				{
					114,
					7,
					114,
					208,
					0,
					14,
					55
				};
				return;
			}
			if (this.int_3 == 4)
			{
				this.byte_2 = new byte[]
				{
					114,
					7,
					114,
					23,
					0,
					15,
					239
				};
				this.byte_3 = new byte[]
				{
					114,
					7,
					114,
					209,
					0,
					6,
					62
				};
				this.byte_4 = new byte[]
				{
					114,
					7,
					114,
					32,
					0,
					2,
					243
				};
				this.byte_5 = new byte[]
				{
					114,
					7,
					114,
					208,
					0,
					14,
					55
				};
				return;
			}
			if (this.int_3 == 7)
			{
				this.byte_2 = new byte[]
				{
					114,
					7,
					114,
					19,
					0,
					14,
					244
				};
				this.byte_3 = new byte[]
				{
					114,
					7,
					114,
					208,
					0,
					14,
					55
				};
				this.byte_4 = new byte[]
				{
					114,
					7,
					114,
					209,
					0,
					6,
					55
				};
				this.byte_5 = new byte[]
				{
					114,
					7,
					114,
					32,
					0,
					2,
					243
				};
			}
		}

		// Token: 0x06000FC9 RID: 4041
		[DllImport("user32.dll")]
		private static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x06000FCA RID: 4042
		[DllImport("user32.dll")]
		private static extern bool ReleaseCapture();

		// Token: 0x06000FCB RID: 4043 RVA: 0x00073C08 File Offset: 0x00073C08
		private void SetupRoundedNeonForm()
		{
			base.FormBorderStyle = FormBorderStyle.None;
			this.BackColor = LIVE_DATA.BgDark;
			using (GraphicsPath roundedPath = this.GetRoundedPath(new Rectangle(0, 0, base.ClientSize.Width, base.ClientSize.Height), 24))
			{
				base.Region = new Region(roundedPath);
			}
			checked
			{
				base.Paint += delegate(object s, PaintEventArgs e)
				{
					e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
					Rectangle rect = new Rectangle(2, 2, base.ClientSize.Width - 5, base.ClientSize.Height - 5);
					using (GraphicsPath roundedPath2 = this.GetRoundedPath(rect, 22))
					{
						using (Pen pen = new Pen(Color.FromArgb(40, 0, 255, 220), 5f))
						{
							using (Pen pen2 = new Pen(LIVE_DATA.NeonCyan, 2f))
							{
								e.Graphics.DrawPath(pen, roundedPath2);
								e.Graphics.DrawPath(pen2, roundedPath2);
							}
						}
					}
				};
				this.btnClosePopup = new Button
				{
					Text = "✕",
					Font = new Font("Segoe UI", 12f, FontStyle.Bold),
					ForeColor = LIVE_DATA.TextSoft,
					BackColor = Color.FromArgb(35, 40, 48),
					FlatStyle = FlatStyle.Flat,
					Size = new Size(34, 34),
					Location = new Point(base.ClientSize.Width - 50, 15),
					Anchor = (AnchorStyles.Top | AnchorStyles.Right),
					Cursor = Cursors.Hand,
					TabStop = false
				};
				this.btnClosePopup.FlatAppearance.BorderSize = 0;
				GraphicsPath graphicsPath = new GraphicsPath();
				graphicsPath.AddEllipse(0, 0, 34, 34);
				this.btnClosePopup.Region = new Region(graphicsPath);
				this.btnClosePopup.MouseEnter += delegate(object s, EventArgs e)
				{
					this.btnClosePopup.BackColor = LIVE_DATA.NeonRed;
					this.btnClosePopup.ForeColor = Color.White;
				};
				this.btnClosePopup.MouseLeave += delegate(object s, EventArgs e)
				{
					this.btnClosePopup.BackColor = Color.FromArgb(35, 40, 48);
					this.btnClosePopup.ForeColor = LIVE_DATA.TextSoft;
				};
				this.btnClosePopup.Click += delegate(object s, EventArgs e)
				{
					base.Close();
				};
				base.Controls.Add(this.btnClosePopup);
				this.btnClosePopup.BringToFront();
				base.MouseDown += this.LiveData_MouseDown;
			}
		}

		// Token: 0x06000FCC RID: 4044 RVA: 0x0000AB5A File Offset: 0x0000AB5A
		private void LiveData_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				LIVE_DATA.ReleaseCapture();
				LIVE_DATA.SendMessage(base.Handle, 161, 2, 0);
			}
		}

		// Token: 0x06000FCD RID: 4045 RVA: 0x00073DCC File Offset: 0x00073DCC
		private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
		{
			checked
			{
				int num = radius * 2;
				GraphicsPath graphicsPath = new GraphicsPath();
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x06000FCE RID: 4046 RVA: 0x0000AB82 File Offset: 0x0000AB82
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			e.Graphics.Clear(this.BackColor);
		}

		// Token: 0x06000FCF RID: 4047 RVA: 0x00073E70 File Offset: 0x00073E70
		private Label MakeBigValueLabel(Color fore)
		{
			return new Label
			{
				Dock = DockStyle.Fill,
				Font = new Font("Segoe UI", 32f, FontStyle.Bold),
				ForeColor = Color.Aqua,
				BackColor = Color.Transparent,
				Text = "—",
				TextAlign = ContentAlignment.MiddleCenter
			};
		}

		// Token: 0x06000FD0 RID: 4048 RVA: 0x00073EC8 File Offset: 0x00073EC8
		private Panel MakeCard(string title, Label valueLabel, string emoji)
		{
			LIVE_DATA.RoundedCard roundedCard = new LIVE_DATA.RoundedCard();
			roundedCard.Dock = DockStyle.Fill;
			roundedCard.Margin = new Padding(6);
			roundedCard.BackColor = LIVE_DATA.CardDark2;
			roundedCard.BorderColor = Color.FromArgb(60, 0, 255, 220);
			roundedCard.CornerRadius = 12;
			Label value = new Label
			{
				Text = emoji + "  " + title,
				Dock = DockStyle.Top,
				Height = 22,
				Font = new Font("Segoe UI", 8f, FontStyle.Bold),
				ForeColor = Color.FromArgb(140, 165, 180),
				TextAlign = ContentAlignment.MiddleCenter,
				BackColor = Color.Transparent
			};
			valueLabel.Dock = DockStyle.Fill;
			roundedCard.Controls.Add(valueLabel);
			roundedCard.Controls.Add(value);
			return roundedCard;
		}

		// Token: 0x06000FD2 RID: 4050 RVA: 0x0007404C File Offset: 0x0007404C
		private Label MakeSmallValueLabel()
		{
			return new Label
			{
				Dock = DockStyle.Fill,
				Font = new Font("Segoe UI", 15f, FontStyle.Bold),
				ForeColor = LIVE_DATA.NeonCyan,
				BackColor = Color.Transparent,
				Text = "—",
				TextAlign = ContentAlignment.MiddleCenter
			};
		}

		// Token: 0x040014E5 RID: 5349
		private double double_0;

		// Token: 0x040014E6 RID: 5350
		private double double_1;

		// Token: 0x040014E7 RID: 5351
		private bool bool_3;

		// Token: 0x040014E8 RID: 5352
		private bool bool_4;

		// Token: 0x040014E9 RID: 5353
		private bool bool_6;

		// Token: 0x040014EA RID: 5354
		private bool bool_7;

		// Token: 0x040014EB RID: 5355
		private string string_4;

		// Token: 0x040014EC RID: 5356
		private string string_5;

		// Token: 0x040014ED RID: 5357
		private string string_9;

		// Token: 0x040014EE RID: 5358
		private string[] string_10;

		// Token: 0x040014EF RID: 5359
		private byte[] byte_2;

		// Token: 0x040014F0 RID: 5360
		private byte[] byte_3;

		// Token: 0x040014F1 RID: 5361
		private byte[] byte_4;

		// Token: 0x040014F2 RID: 5362
		private byte[] byte_5;

		// Token: 0x040014F3 RID: 5363
		private int int_3;

		// Token: 0x040014F4 RID: 5364
		private int int_4;

		// Token: 0x040014F5 RID: 5365
		private int int_5;

		// Token: 0x040014F6 RID: 5366
		private int int_6;

		// Token: 0x040014F7 RID: 5367
		private int int_9;

		// Token: 0x040014F8 RID: 5368
		private bool[] bool_5;

		// Token: 0x040014F9 RID: 5369
		private bool bool_8;

		// Token: 0x040014FA RID: 5370
		private byte byte_0;

		// Token: 0x040014FB RID: 5371
		private string[] string_15;

		// Token: 0x040014FC RID: 5372
		private int int_1;

		// Token: 0x040014FD RID: 5373
		private int int_7;

		// Token: 0x040014FE RID: 5374
		private double double_2;

		// Token: 0x040014FF RID: 5375
		private double double_3;

		// Token: 0x04001500 RID: 5376
		private double double_4;

		// Token: 0x04001501 RID: 5377
		private double double_5;

		// Token: 0x04001502 RID: 5378
		private int int_8;

		// Token: 0x04001503 RID: 5379
		private int int_0;

		// Token: 0x04001504 RID: 5380
		private const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x04001505 RID: 5381
		private const int HT_CAPTION = 2;

		// Token: 0x04001506 RID: 5382
		private Button btnClosePopup;

		// Token: 0x04001508 RID: 5384
		private static readonly Color CardDark = Color.FromArgb(18, 24, 34);

		// Token: 0x04001509 RID: 5385
		private static readonly Color CardDark2 = Color.FromArgb(22, 30, 42);

		// Token: 0x0400150C RID: 5388
		private static readonly Color NeonRed = Color.FromArgb(255, 80, 100);

		// Token: 0x0400150F RID: 5391
		private LIVE_DATA.NeonGauge circularRPMGauge;

		// Token: 0x04001510 RID: 5392
		private LIVE_DATA.NeonGauge circularTPSGauge;

		// Token: 0x02000679 RID: 1657
		public class RoundedCard : Panel
		{
			// Token: 0x17000064 RID: 100
			// (get) Token: 0x06000FDB RID: 4059 RVA: 0x0000ABDF File Offset: 0x0000ABDF
			// (set) Token: 0x06000FDC RID: 4060 RVA: 0x0000ABE7 File Offset: 0x0000ABE7
			public int CornerRadius { get; set; } = 12;

			// Token: 0x17000065 RID: 101
			// (get) Token: 0x06000FDD RID: 4061 RVA: 0x0000ABF0 File Offset: 0x0000ABF0
			// (set) Token: 0x06000FDE RID: 4062 RVA: 0x0000ABF8 File Offset: 0x0000ABF8
			public Color BorderColor { get; set; } = Color.FromArgb(40, 180, 170);

			// Token: 0x06000FDF RID: 4063 RVA: 0x0000AC01 File Offset: 0x0000AC01
			public RoundedCard()
			{
				this.DoubleBuffered = true;
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			}

			// Token: 0x06000FE0 RID: 4064 RVA: 0x00074184 File Offset: 0x00074184
			protected override void OnPaint(PaintEventArgs e)
			{
				e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				Rectangle rect = checked(new Rectangle(0, 0, base.Width - 1, base.Height - 1));
				using (GraphicsPath roundedPath = this.GetRoundedPath(rect, this.CornerRadius))
				{
					using (SolidBrush solidBrush = new SolidBrush(this.BackColor))
					{
						e.Graphics.FillPath(solidBrush, roundedPath);
					}
				}
				using (GraphicsPath roundedPath2 = this.GetRoundedPath(rect, this.CornerRadius))
				{
					using (Pen pen = new Pen(this.BorderColor, 1.4f))
					{
						e.Graphics.DrawPath(pen, roundedPath2);
					}
				}
				base.OnPaint(e);
			}

			// Token: 0x06000FE1 RID: 4065 RVA: 0x00073DCC File Offset: 0x00073DCC
			private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
			{
				checked
				{
					int num = radius * 2;
					GraphicsPath graphicsPath = new GraphicsPath();
					graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
					graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
					graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
					graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
					graphicsPath.CloseFigure();
					return graphicsPath;
				}
			}
		}

		// Token: 0x0200067A RID: 1658
		public class NeonGauge : Panel
		{
			// Token: 0x17000066 RID: 102
			// (get) Token: 0x06000FE2 RID: 4066 RVA: 0x0000AC3B File Offset: 0x0000AC3B
			// (set) Token: 0x06000FE3 RID: 4067 RVA: 0x0000AC43 File Offset: 0x0000AC43
			public double MinValue { get; set; }

			// Token: 0x17000067 RID: 103
			// (get) Token: 0x06000FE4 RID: 4068 RVA: 0x0000AC4C File Offset: 0x0000AC4C
			// (set) Token: 0x06000FE5 RID: 4069 RVA: 0x0000AC54 File Offset: 0x0000AC54
			public double MaxValue { get; set; } = 100.0;

			// Token: 0x17000068 RID: 104
			// (get) Token: 0x06000FE6 RID: 4070 RVA: 0x0000AC5D File Offset: 0x0000AC5D
			// (set) Token: 0x06000FE7 RID: 4071 RVA: 0x0000AC65 File Offset: 0x0000AC65
			public double Value { get; set; }

			// Token: 0x17000069 RID: 105
			// (get) Token: 0x06000FE8 RID: 4072 RVA: 0x0000AC6E File Offset: 0x0000AC6E
			// (set) Token: 0x06000FE9 RID: 4073 RVA: 0x0000AC76 File Offset: 0x0000AC76
			public string Unit { get; set; } = "";

			// Token: 0x1700006A RID: 106
			// (get) Token: 0x06000FEA RID: 4074 RVA: 0x0000AC7F File Offset: 0x0000AC7F
			// (set) Token: 0x06000FEB RID: 4075 RVA: 0x0000AC87 File Offset: 0x0000AC87
			public Color BarColor { get; set; } = Color.Cyan;

			// Token: 0x06000FEC RID: 4076 RVA: 0x0000AC90 File Offset: 0x0000AC90
			public NeonGauge()
			{
				this.DoubleBuffered = true;
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			}

			// Token: 0x06000FED RID: 4077 RVA: 0x00074274 File Offset: 0x00074274
			protected override void OnPaint(PaintEventArgs e)
			{
				e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				e.Graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
				RectangleF rect;
				float startAngle;
				float num2;
				checked
				{
					int num = Math.Min(base.Width, base.Height) - 40;
					rect = new RectangleF((float)(base.Width - num) / 2f, (float)(base.Height - num) / 2f, (float)num, (float)num);
					using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(18, 24, 34)))
					{
						e.Graphics.FillEllipse(solidBrush, rect);
					}
					startAngle = -90f;
					num2 = 360f;
				}
				RectangleF rect2 = new RectangleF(rect.X + 15f, rect.Y + 15f, rect.Width - 30f, rect.Height - 30f);
				using (Pen pen = new Pen(Color.FromArgb(30, 40, 50), 10f))
				{
					pen.StartCap = LineCap.Round;
					pen.EndCap = LineCap.Round;
					e.Graphics.DrawArc(pen, rect2, startAngle, num2);
				}
				double num3 = Math.Max(0.0, Math.Min(1.0, (this.Value - this.MinValue) / (this.MaxValue - this.MinValue)));
				if (num3 > 0.0)
				{
					using (Pen pen2 = new Pen(Color.FromArgb(50, this.BarColor), 14f))
					{
						using (Pen pen3 = new Pen(this.BarColor, 6f))
						{
							pen2.StartCap = LineCap.Round;
							pen2.EndCap = LineCap.Round;
							pen3.StartCap = LineCap.Round;
							pen3.EndCap = LineCap.Round;
							e.Graphics.DrawArc(pen2, rect2, startAngle, (float)((double)num2 * num3));
							e.Graphics.DrawArc(pen3, rect2, startAngle, (float)((double)num2 * num3));
						}
					}
				}
				string text = (this.MaxValue <= 100.0) ? this.Value.ToString("F1") : Math.Round(this.Value).ToString("N0");
				using (Font font = new Font("Segoe UI", 32f, FontStyle.Bold))
				{
					using (SolidBrush solidBrush2 = new SolidBrush(Color.Cyan))
					{
						SizeF sizeF = e.Graphics.MeasureString(text, font);
						e.Graphics.DrawString(text, font, solidBrush2, (float)base.Width / 2f - sizeF.Width / 2f, (float)base.Height / 2f - sizeF.Height / 2f - 10f);
					}
				}
				using (Font font2 = new Font("Segoe UI", 10f, FontStyle.Bold))
				{
					using (SolidBrush solidBrush3 = new SolidBrush(Color.FromArgb(150, 170, 190)))
					{
						SizeF sizeF2 = e.Graphics.MeasureString(this.Unit, font2);
						e.Graphics.DrawString(this.Unit, font2, solidBrush3, (float)base.Width / 2f - sizeF2.Width / 2f, (float)base.Height / 2f + 22f);
					}
				}
			}
		}
	}
}
