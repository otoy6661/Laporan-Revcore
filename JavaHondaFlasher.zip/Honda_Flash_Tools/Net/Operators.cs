﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000351 RID: 849
	public static class Operators
	{
		// Token: 0x06000B61 RID: 2913 RVA: 0x000086CD File Offset: 0x000086CD
		public static int CompareString(string left, string right, bool textCompare)
		{
			if (textCompare)
			{
				return string.Compare(left, right, StringComparison.OrdinalIgnoreCase);
			}
			return string.Compare(left, right, StringComparison.Ordinal);
		}

		// Token: 0x06000B62 RID: 2914 RVA: 0x00051474 File Offset: 0x00051474
		public static object SubtractObject(object left, object right)
		{
			double num = Conversions.Val(left);
			double num2 = Conversions.Val(right);
			return num - num2;
		}
	}
}
