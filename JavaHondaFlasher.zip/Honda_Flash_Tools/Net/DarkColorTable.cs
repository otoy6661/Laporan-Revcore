﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020005E9 RID: 1513
	public class DarkColorTable : ProfessionalColorTable
	{
		// Token: 0x06000EA7 RID: 3751 RVA: 0x0000A11C File Offset: 0x0000A11C
		public DarkColorTable() : this(Color.FromArgb(0, 255, 230), Color.FromArgb(19, 25, 32), Color.FromArgb(35, 70, 75))
		{
		}

		// Token: 0x06000EA8 RID: 3752 RVA: 0x0000A14A File Offset: 0x0000A14A
		public DarkColorTable(Color accent, Color bg, Color bgHover)
		{
			this._accent = accent;
			this._bg = bg;
			this._bgHover = bgHover;
			base.UseSystemColors = false;
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06000EA9 RID: 3753 RVA: 0x0000A16E File Offset: 0x0000A16E
		public override Color MenuItemSelected
		{
			get
			{
				return this._bgHover;
			}
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06000EAA RID: 3754 RVA: 0x0000A176 File Offset: 0x0000A176
		public override Color MenuItemBorder
		{
			get
			{
				return this._accent;
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x06000EAB RID: 3755 RVA: 0x0000A16E File Offset: 0x0000A16E
		public override Color MenuItemSelectedGradientBegin
		{
			get
			{
				return this._bgHover;
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x06000EAC RID: 3756 RVA: 0x0000A16E File Offset: 0x0000A16E
		public override Color MenuItemSelectedGradientEnd
		{
			get
			{
				return this._bgHover;
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x06000EAD RID: 3757 RVA: 0x0000A17E File Offset: 0x0000A17E
		public override Color MenuItemPressedGradientBegin
		{
			get
			{
				return Color.FromArgb(25, 35, 42);
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x06000EAE RID: 3758 RVA: 0x0000A17E File Offset: 0x0000A17E
		public override Color MenuItemPressedGradientEnd
		{
			get
			{
				return Color.FromArgb(25, 35, 42);
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06000EAF RID: 3759 RVA: 0x0000A176 File Offset: 0x0000A176
		public override Color MenuBorder
		{
			get
			{
				return this._accent;
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x06000EB0 RID: 3760 RVA: 0x0000A18B File Offset: 0x0000A18B
		public override Color ToolStripDropDownBackground
		{
			get
			{
				return this._bg;
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x06000EB1 RID: 3761 RVA: 0x0000A18B File Offset: 0x0000A18B
		public override Color ImageMarginGradientBegin
		{
			get
			{
				return this._bg;
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x06000EB2 RID: 3762 RVA: 0x0000A18B File Offset: 0x0000A18B
		public override Color ImageMarginGradientMiddle
		{
			get
			{
				return this._bg;
			}
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x06000EB3 RID: 3763 RVA: 0x0000A18B File Offset: 0x0000A18B
		public override Color ImageMarginGradientEnd
		{
			get
			{
				return this._bg;
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x06000EB4 RID: 3764 RVA: 0x0000A193 File Offset: 0x0000A193
		public override Color SeparatorDark
		{
			get
			{
				return Color.FromArgb(0, 100, 100);
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x06000EB5 RID: 3765 RVA: 0x0000A19F File Offset: 0x0000A19F
		public override Color SeparatorLight
		{
			get
			{
				return Color.FromArgb(0, 145, 135);
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x06000EB6 RID: 3766 RVA: 0x0000A18B File Offset: 0x0000A18B
		public override Color ToolStripGradientBegin
		{
			get
			{
				return this._bg;
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x06000EB7 RID: 3767 RVA: 0x0000A18B File Offset: 0x0000A18B
		public override Color ToolStripGradientMiddle
		{
			get
			{
				return this._bg;
			}
		}

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x06000EB8 RID: 3768 RVA: 0x0000A18B File Offset: 0x0000A18B
		public override Color ToolStripGradientEnd
		{
			get
			{
				return this._bg;
			}
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x06000EB9 RID: 3769 RVA: 0x0000A176 File Offset: 0x0000A176
		public override Color ToolStripBorder
		{
			get
			{
				return this._accent;
			}
		}

		// Token: 0x04001381 RID: 4993
		private readonly Color _accent;

		// Token: 0x04001382 RID: 4994
		private readonly Color _bg;

		// Token: 0x04001383 RID: 4995
		private readonly Color _bgHover;
	}
}
