﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Honda_Flash_Tools.Net.Properties
{
	// Token: 0x020001F5 RID: 501
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x06000A15 RID: 2581 RVA: 0x00007C48 File Offset: 0x00007C48
		internal Resources()
		{
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x06000A16 RID: 2582 RVA: 0x0004B4C4 File Offset: 0x0004B4C4
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				bool flag = Resources.resourceMan == null;
				bool flag2 = flag;
				if (flag2)
				{
					ResourceManager resourceManager = new ResourceManager("Honda_Flash_Tools.Net.Properties.Resources", typeof(Resources).Assembly);
					Resources.resourceMan = resourceManager;
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x06000A17 RID: 2583 RVA: 0x0004B50C File Offset: 0x0004B50C
		// (set) Token: 0x06000A18 RID: 2584 RVA: 0x00007C52 File Offset: 0x00007C52
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x06000A19 RID: 2585 RVA: 0x00007C5B File Offset: 0x00007C5B
		internal static Bitmap anc_small
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("anc_small", Resources.resourceCulture);
			}
		}

		// Token: 0x04000A15 RID: 2581
		private static ResourceManager resourceMan;

		// Token: 0x04000A16 RID: 2582
		private static CultureInfo resourceCulture;
	}
}
