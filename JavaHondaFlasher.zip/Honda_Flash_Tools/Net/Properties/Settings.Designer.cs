﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace Honda_Flash_Tools.Net.Properties
{
	// Token: 0x020001F6 RID: 502
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0")]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x1700001F RID: 31
		// (get) Token: 0x06000A1A RID: 2586 RVA: 0x0004B524 File Offset: 0x0004B524
		public static Settings Default
		{
			get
			{
				return Settings.defaultInstance;
			}
		}

		// Token: 0x04000A17 RID: 2583
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());
	}
}
