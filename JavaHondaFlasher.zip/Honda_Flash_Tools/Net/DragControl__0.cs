﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000747 RID: 1863
	public class DragControl__0
	{
		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x06001167 RID: 4455 RVA: 0x0000B863 File Offset: 0x0000B863
		// (set) Token: 0x06001168 RID: 4456 RVA: 0x0007FE90 File Offset: 0x0007FE90
		public Control SelecControl
		{
			get
			{
				return this._selectControl;
			}
			set
			{
				this._selectControl = value;
				if (this._selectControl != null)
				{
					this._selectControl.MouseDown += this.OnMouseDown;
					this._selectControl.MouseMove += this.OnMouseMove;
					this._selectControl.MouseUp += this.OnMouseUp;
				}
			}
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x06001169 RID: 4457 RVA: 0x0000B86B File Offset: 0x0000B86B
		// (set) Token: 0x0600116A RID: 4458 RVA: 0x0000B873 File Offset: 0x0000B873
		public Control SelectControl
		{
			get
			{
				return this.SelecControl;
			}
			set
			{
				this.SelecControl = value;
			}
		}

		// Token: 0x0600116B RID: 4459 RVA: 0x0000B87C File Offset: 0x0000B87C
		private void OnMouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this._dragging = true;
				this._startPoint = e.Location;
			}
		}

		// Token: 0x0600116C RID: 4460 RVA: 0x0007FEF4 File Offset: 0x0007FEF4
		private void OnMouseMove(object sender, MouseEventArgs e)
		{
			if (this._dragging && this._selectControl != null)
			{
				Form form = this._selectControl.FindForm();
				if (form != null)
				{
					form.Location = new Point(form.Location.X + (e.X - this._startPoint.X), form.Location.Y + (e.Y - this._startPoint.Y));
				}
			}
		}

		// Token: 0x0600116D RID: 4461 RVA: 0x0000B89E File Offset: 0x0000B89E
		private void OnMouseUp(object sender, MouseEventArgs e)
		{
			this._dragging = false;
		}

		// Token: 0x04001828 RID: 6184
		private Control _selectControl;

		// Token: 0x04001829 RID: 6185
		private bool _dragging;

		// Token: 0x0400182A RID: 6186
		private Point _startPoint;
	}
}
