﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000715 RID: 1813
	public struct Particle__0
	{
		// Token: 0x04001712 RID: 5906
		public float X;

		// Token: 0x04001713 RID: 5907
		public float Y;

		// Token: 0x04001714 RID: 5908
		public float VX;

		// Token: 0x04001715 RID: 5909
		public float VY;

		// Token: 0x04001716 RID: 5910
		public float Life;

		// Token: 0x04001717 RID: 5911
		public float MaxLife;

		// Token: 0x04001718 RID: 5912
		public float Size;

		// Token: 0x04001719 RID: 5913
		public float Rotation;
	}
}
