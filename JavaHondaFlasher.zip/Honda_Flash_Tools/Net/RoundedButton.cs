﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020005E6 RID: 1510
	public class RoundedButton : Button
	{
		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000E7A RID: 3706 RVA: 0x00009F2E File Offset: 0x00009F2E
		// (set) Token: 0x06000E7B RID: 3707 RVA: 0x00009F36 File Offset: 0x00009F36
		public int CornerRadius
		{
			get
			{
				return this._cornerRadius;
			}
			set
			{
				this._cornerRadius = value;
				this.UpdateRegion();
				base.Invalidate();
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000E7C RID: 3708 RVA: 0x00009F4B File Offset: 0x00009F4B
		// (set) Token: 0x06000E7D RID: 3709 RVA: 0x00009F53 File Offset: 0x00009F53
		public Color BorderColor
		{
			get
			{
				return this._borderColor;
			}
			set
			{
				this._borderColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000E7E RID: 3710 RVA: 0x00009F62 File Offset: 0x00009F62
		// (set) Token: 0x06000E7F RID: 3711 RVA: 0x00009F6A File Offset: 0x00009F6A
		public float BorderWidth
		{
			get
			{
				return this._borderWidth;
			}
			set
			{
				this._borderWidth = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x06000E80 RID: 3712 RVA: 0x00009F79 File Offset: 0x00009F79
		// (set) Token: 0x06000E81 RID: 3713 RVA: 0x00009F81 File Offset: 0x00009F81
		public Color HoverBackColor
		{
			get
			{
				return this._hoverBackColor;
			}
			set
			{
				this._hoverBackColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x06000E82 RID: 3714 RVA: 0x0006A5D4 File Offset: 0x0006A5D4
		public RoundedButton()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.FlatStyle = FlatStyle.Flat;
			base.FlatAppearance.BorderSize = 0;
			this.BackColor = Color.FromArgb(34, 40, 48);
			this.ForeColor = Color.FromArgb(235, 240, 245);
		}

		// Token: 0x06000E83 RID: 3715 RVA: 0x00009F90 File Offset: 0x00009F90
		protected override void OnHandleCreated(EventArgs e)
		{
			base.OnHandleCreated(e);
			this.UpdateRegion();
		}

		// Token: 0x06000E84 RID: 3716 RVA: 0x00009F9F File Offset: 0x00009F9F
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.UpdateRegion();
		}

		// Token: 0x06000E85 RID: 3717 RVA: 0x00009FAE File Offset: 0x00009FAE
		protected override void OnMouseEnter(EventArgs e)
		{
			base.OnMouseEnter(e);
			this._isHovering = true;
			base.Invalidate();
		}

		// Token: 0x06000E86 RID: 3718 RVA: 0x00009FC4 File Offset: 0x00009FC4
		protected override void OnMouseLeave(EventArgs e)
		{
			base.OnMouseLeave(e);
			this._isHovering = false;
			base.Invalidate();
		}

		// Token: 0x06000E87 RID: 3719 RVA: 0x00009FDA File Offset: 0x00009FDA
		private void UpdateRegion()
		{
			RoundedHelper.SetRegion(this, this._cornerRadius);
		}

		// Token: 0x06000E88 RID: 3720 RVA: 0x0006A670 File Offset: 0x0006A670
		protected override void OnPaint(PaintEventArgs pevent)
		{
			Graphics graphics = pevent.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.Half;
			Control parent = base.Parent;
			Color color = (parent != null) ? parent.BackColor : this.BackColor;
			graphics.Clear(color);
			using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(new RectangleF(0.5f, 0.5f, (float)base.Width - 1f, (float)base.Height - 1f), this._cornerRadius))
			{
				using (SolidBrush solidBrush = new SolidBrush((this._isHovering && this._hoverBackColor != Color.Empty) ? this._hoverBackColor : this.BackColor))
				{
					graphics.FillPath(solidBrush, graphicsPath);
				}
				if (this._borderWidth > 0f && this._borderColor != Color.Empty)
				{
					using (Pen pen = new Pen(this._borderColor, this._borderWidth))
					{
						pen.Alignment = PenAlignment.Center;
						pen.LineJoin = LineJoin.Round;
						graphics.DrawPath(pen, graphicsPath);
					}
				}
			}
			TextRenderer.DrawText(graphics, this.Text, this.Font, base.ClientRectangle, base.Enabled ? this.ForeColor : Color.Gray, TextFormatFlags.EndEllipsis | TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
		}

		// Token: 0x04001371 RID: 4977
		private int _cornerRadius = 8;

		// Token: 0x04001372 RID: 4978
		private Color _borderColor = Color.FromArgb(0, 255, 230);

		// Token: 0x04001373 RID: 4979
		private float _borderWidth = 1f;

		// Token: 0x04001374 RID: 4980
		private Color _hoverBackColor = Color.Empty;

		// Token: 0x04001375 RID: 4981
		private Color _normalBackColor = Color.Empty;

		// Token: 0x04001376 RID: 4982
		private bool _isHovering;
	}
}
