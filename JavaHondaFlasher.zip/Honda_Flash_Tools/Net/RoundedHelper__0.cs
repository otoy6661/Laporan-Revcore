﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020005E4 RID: 1508
	public static class RoundedHelper__0
	{
		// Token: 0x06000E6B RID: 3691 RVA: 0x0006A2F8 File Offset: 0x0006A2F8
		public static GraphicsPath RoundedRect(Rectangle bounds, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			if (radius <= 0)
			{
				graphicsPath.AddRectangle(bounds);
				return graphicsPath;
			}
			int num = radius * 2;
			if (num > bounds.Width)
			{
				num = bounds.Width;
			}
			if (num > bounds.Height)
			{
				num = bounds.Height;
			}
			Rectangle rect = new Rectangle(bounds.X, bounds.Y, num, num);
			graphicsPath.AddArc(rect, 180f, 90f);
			rect.X = bounds.Right - num;
			graphicsPath.AddArc(rect, 270f, 90f);
			rect.Y = bounds.Bottom - num;
			graphicsPath.AddArc(rect, 0f, 90f);
			rect.X = bounds.X;
			graphicsPath.AddArc(rect, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x06000E6C RID: 3692 RVA: 0x0006A3D0 File Offset: 0x0006A3D0
		public static void SetRegion(Control c, int radius)
		{
			if (c == null || c.IsDisposed)
			{
				return;
			}
			if (c.Width <= 0 || c.Height <= 0)
			{
				return;
			}
			using (GraphicsPath graphicsPath = RoundedHelper__0.RoundedRect(new Rectangle(0, 0, c.Width, c.Height), radius))
			{
				Region region = c.Region;
				c.Region = new Region(graphicsPath);
				if (region != null)
				{
					region.Dispose();
				}
			}
		}
	}
}
