﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200034D RID: 845
	public enum CustomMessageBoxIcon__1
	{
		// Token: 0x04000CB7 RID: 3255
		None,
		// Token: 0x04000CB8 RID: 3256
		Information = 64,
		// Token: 0x04000CB9 RID: 3257
		Question = 32,
		// Token: 0x04000CBA RID: 3258
		Warning = 48,
		// Token: 0x04000CBB RID: 3259
		Error = 16,
		// Token: 0x04000CBC RID: 3260
		Success = 64
	}
}
