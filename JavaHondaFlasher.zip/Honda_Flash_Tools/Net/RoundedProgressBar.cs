﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020006F8 RID: 1784
	public class RoundedProgressBar : Control
	{
		// Token: 0x1700007D RID: 125
		// (get) Token: 0x06001028 RID: 4136 RVA: 0x0000AF4B File Offset: 0x0000AF4B
		// (set) Token: 0x06001029 RID: 4137 RVA: 0x0000AF53 File Offset: 0x0000AF53
		public int CornerRadius
		{
			get
			{
				return this._cornerRadius;
			}
			set
			{
				this._cornerRadius = Math.Max(0, value);
				base.Invalidate();
			}
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x0600102A RID: 4138 RVA: 0x0000AF68 File Offset: 0x0000AF68
		// (set) Token: 0x0600102B RID: 4139 RVA: 0x0000AF70 File Offset: 0x0000AF70
		public Color TrackColor
		{
			get
			{
				return this._trackColor;
			}
			set
			{
				this._trackColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x0600102C RID: 4140 RVA: 0x0000AF7F File Offset: 0x0000AF7F
		// (set) Token: 0x0600102D RID: 4141 RVA: 0x0000AF87 File Offset: 0x0000AF87
		public Color BorderColor
		{
			get
			{
				return this._borderColor;
			}
			set
			{
				this._borderColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x0600102E RID: 4142 RVA: 0x0000AF96 File Offset: 0x0000AF96
		// (set) Token: 0x0600102F RID: 4143 RVA: 0x0000AF9E File Offset: 0x0000AF9E
		public Color BarColor
		{
			get
			{
				return this._barColor;
			}
			set
			{
				this._barColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x06001030 RID: 4144 RVA: 0x0000AFAD File Offset: 0x0000AFAD
		// (set) Token: 0x06001031 RID: 4145 RVA: 0x0000AFB5 File Offset: 0x0000AFB5
		public Color? BarColor2
		{
			get
			{
				return this._barColor2;
			}
			set
			{
				this._barColor2 = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x06001032 RID: 4146 RVA: 0x0000AFC4 File Offset: 0x0000AFC4
		// (set) Token: 0x06001033 RID: 4147 RVA: 0x0000AFCC File Offset: 0x0000AFCC
		public int BorderWidth
		{
			get
			{
				return this._borderWidth;
			}
			set
			{
				this._borderWidth = Math.Max(0, value);
				base.Invalidate();
			}
		}

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x06001034 RID: 4148 RVA: 0x0000AFE1 File Offset: 0x0000AFE1
		// (set) Token: 0x06001035 RID: 4149 RVA: 0x0000AFE9 File Offset: 0x0000AFE9
		public int Minimum
		{
			get
			{
				return this._minimum;
			}
			set
			{
				this._minimum = value;
				if (this._value < this._minimum)
				{
					this._value = this._minimum;
				}
				base.Invalidate();
			}
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x06001036 RID: 4150 RVA: 0x0000B012 File Offset: 0x0000B012
		// (set) Token: 0x06001037 RID: 4151 RVA: 0x0000B01A File Offset: 0x0000B01A
		public int Maximum
		{
			get
			{
				return this._maximum;
			}
			set
			{
				this._maximum = ((value <= 0) ? 1 : value);
				if (this._value > this._maximum)
				{
					this._value = this._maximum;
				}
				base.Invalidate();
			}
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x06001038 RID: 4152 RVA: 0x0000B04A File Offset: 0x0000B04A
		// (set) Token: 0x06001039 RID: 4153 RVA: 0x000752B0 File Offset: 0x000752B0
		public int Value
		{
			get
			{
				return this._value;
			}
			set
			{
				int num = value;
				if (num < this._minimum)
				{
					num = this._minimum;
				}
				if (num > this._maximum)
				{
					num = this._maximum;
				}
				if (this._value == num)
				{
					return;
				}
				this._value = num;
				base.Invalidate();
			}
		}

		// Token: 0x0600103A RID: 4154 RVA: 0x000752F8 File Offset: 0x000752F8
		public RoundedProgressBar()
		{
			this._maximum = 10000;
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.BackColor = Color.Transparent;
			base.Size = new Size(300, 20);
		}

		// Token: 0x0600103B RID: 4155 RVA: 0x0007537C File Offset: 0x0007537C
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
			if (base.Parent != null)
			{
				using (SolidBrush solidBrush = new SolidBrush(base.Parent.BackColor))
				{
					graphics.FillRectangle(solidBrush, base.ClientRectangle);
				}
			}
			Rectangle bounds = new Rectangle(0, 0, base.Width - 1, base.Height - 1);
			using (GraphicsPath graphicsPath = RoundedProgressBar.CreateRoundedRect(bounds, this.CornerRadius))
			{
				using (SolidBrush solidBrush2 = new SolidBrush(this.TrackColor))
				{
					graphics.FillPath(solidBrush2, graphicsPath);
				}
				if (this.BorderWidth > 0)
				{
					using (Pen pen = new Pen(this.BorderColor, (float)this.BorderWidth))
					{
						graphics.DrawPath(pen, graphicsPath);
					}
				}
			}
			if (this._maximum > this._minimum && this._value > this._minimum)
			{
				double num = (double)(this._value - this._minimum) / (double)(this._maximum - this._minimum);
				int num2 = (int)Math.Round((double)bounds.Width * num);
				if (num2 < 1)
				{
					num2 = 1;
				}
				int borderWidth = this.BorderWidth;
				Rectangle rectangle = new Rectangle(bounds.X + borderWidth, bounds.Y + borderWidth, Math.Max(1, num2 - borderWidth * 2), bounds.Height - borderWidth * 2);
				int radius = Math.Min(this.CornerRadius, rectangle.Height / 2);
				if (num2 >= bounds.Width - 1)
				{
					radius = this.CornerRadius;
					rectangle = new Rectangle(bounds.X + borderWidth, bounds.Y + borderWidth, bounds.Width - borderWidth * 2, bounds.Height - borderWidth * 2);
				}
				using (GraphicsPath graphicsPath2 = RoundedProgressBar.CreateRoundedRect(rectangle, radius))
				{
					Brush brush;
					if (this.BarColor2 != null)
					{
						brush = new LinearGradientBrush(rectangle, this.BarColor, this.BarColor2.Value, LinearGradientMode.Horizontal);
					}
					else
					{
						brush = new SolidBrush(this.BarColor);
					}
					using (brush)
					{
						graphics.FillPath(brush, graphicsPath2);
					}
				}
			}
			if (this.ShowPercentage && this._maximum > this._minimum)
			{
				double num3 = (double)(this._value - this._minimum) / (double)(this._maximum - this._minimum);
				string text = string.Format("{0}%", (int)(num3 * 100.0));
				using (Font font = new Font("Segoe UI", Math.Max(6f, (float)base.Height * 0.45f), FontStyle.Bold))
				{
					using (SolidBrush solidBrush3 = new SolidBrush(this.ForeColor))
					{
						SizeF sizeF = graphics.MeasureString(text, font);
						graphics.DrawString(text, font, solidBrush3, ((float)base.Width - sizeF.Width) / 2f, ((float)base.Height - sizeF.Height) / 2f);
					}
				}
			}
		}

		// Token: 0x0600103C RID: 4156 RVA: 0x00075714 File Offset: 0x00075714
		private static GraphicsPath CreateRoundedRect(Rectangle bounds, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			if (bounds.Width <= 0 || bounds.Height <= 0)
			{
				return graphicsPath;
			}
			if (radius <= 0)
			{
				graphicsPath.AddRectangle(bounds);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
			int num = Math.Min(bounds.Width, bounds.Height) / 2;
			if (radius > num)
			{
				radius = num;
			}
			if (radius <= 0)
			{
				graphicsPath.AddRectangle(bounds);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
			int num2 = radius * 2;
			graphicsPath.AddArc(bounds.X, bounds.Y, num2, num2, 180f, 90f);
			graphicsPath.AddArc(bounds.X + bounds.Width - num2, bounds.Y, num2, num2, 270f, 90f);
			graphicsPath.AddArc(bounds.X + bounds.Width - num2, bounds.Y + bounds.Height - num2, num2, num2, 0f, 90f);
			graphicsPath.AddArc(bounds.X, bounds.Y + bounds.Height - num2, num2, num2, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x0600103D RID: 4157 RVA: 0x00075834 File Offset: 0x00075834
		public void AnimateTo(int target)
		{
			this._targetValue = Math.Max(this._minimum, Math.Min(this._maximum, target));
			if (this._animTimer == null)
			{
				this._animTimer = new Timer
				{
					Interval = 15
				};
				this._animTimer.Tick += delegate(object s, EventArgs e)
				{
					if (this._value == this._targetValue)
					{
						this._animTimer.Stop();
						return;
					}
					int value = this._targetValue - this._value;
					int num = Math.Max(1, Math.Abs(value) / 8);
					this.Value += Math.Sign(value) * num;
				};
			}
			this._animTimer.Start();
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x0600103E RID: 4158 RVA: 0x0000B052 File Offset: 0x0000B052
		// (set) Token: 0x0600103F RID: 4159 RVA: 0x0000B05A File Offset: 0x0000B05A
		public bool ShowPercentage
		{
			get
			{
				return this._showPercentage;
			}
			set
			{
				this._showPercentage = value;
				base.Invalidate();
			}
		}

		// Token: 0x04001687 RID: 5767
		private int _value;

		// Token: 0x04001688 RID: 5768
		private int _maximum;

		// Token: 0x04001689 RID: 5769
		private int _minimum;

		// Token: 0x0400168A RID: 5770
		private int _cornerRadius = 8;

		// Token: 0x0400168B RID: 5771
		private Color _trackColor = Color.FromArgb(30, 34, 45);

		// Token: 0x0400168C RID: 5772
		private Color _borderColor = Color.FromArgb(70, 76, 92);

		// Token: 0x0400168D RID: 5773
		private int _borderWidth = 1;

		// Token: 0x0400168E RID: 5774
		private Color _barColor = Color.Gold;

		// Token: 0x0400168F RID: 5775
		private Color? _barColor2;

		// Token: 0x04001690 RID: 5776
		private bool _showPercentage;

		// Token: 0x04001691 RID: 5777
		private Timer _animTimer;

		// Token: 0x04001692 RID: 5778
		private int _targetValue;
	}
}
