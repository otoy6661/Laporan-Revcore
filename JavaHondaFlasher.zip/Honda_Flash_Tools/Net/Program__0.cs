﻿using System;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000597 RID: 1431
	internal static class Program__0
	{
		// Token: 0x06000E59 RID: 3673 RVA: 0x00069DB8 File Offset: 0x00069DB8
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			using (FormMain formMain = new FormMain())
			{
				Application.Run(formMain);
			}
		}
	}
}
