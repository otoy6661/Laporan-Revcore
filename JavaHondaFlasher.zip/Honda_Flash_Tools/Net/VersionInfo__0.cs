﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200078A RID: 1930
	public class VersionInfo__0
	{
		// Token: 0x170000CA RID: 202
		// (get) Token: 0x06001294 RID: 4756 RVA: 0x0000C075 File Offset: 0x0000C075
		// (set) Token: 0x06001295 RID: 4757 RVA: 0x0000C07D File Offset: 0x0000C07D
		public string Version { get; set; }

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x06001296 RID: 4758 RVA: 0x0000C086 File Offset: 0x0000C086
		// (set) Token: 0x06001297 RID: 4759 RVA: 0x0000C08E File Offset: 0x0000C08E
		public string DownloadUrl { get; set; }

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x06001298 RID: 4760 RVA: 0x0000C097 File Offset: 0x0000C097
		// (set) Token: 0x06001299 RID: 4761 RVA: 0x0000C09F File Offset: 0x0000C09F
		public string Sha256 { get; set; }

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x0600129A RID: 4762 RVA: 0x0000C0A8 File Offset: 0x0000C0A8
		// (set) Token: 0x0600129B RID: 4763 RVA: 0x0000C0B0 File Offset: 0x0000C0B0
		public long SizeBytes { get; set; }

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x0600129C RID: 4764 RVA: 0x0000C0B9 File Offset: 0x0000C0B9
		// (set) Token: 0x0600129D RID: 4765 RVA: 0x0000C0C1 File Offset: 0x0000C0C1
		public string Notes { get; set; }

		// Token: 0x0600129E RID: 4766 RVA: 0x0000C0CA File Offset: 0x0000C0CA
		public VersionInfo__0()
		{
			this.Version = "0.0.0.0";
			this.DownloadUrl = string.Empty;
			this.Sha256 = string.Empty;
			this.Notes = string.Empty;
			this.SizeBytes = 0L;
		}
	}
}
