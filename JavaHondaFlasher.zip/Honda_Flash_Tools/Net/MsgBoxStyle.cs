﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000353 RID: 851
	public enum MsgBoxStyle
	{
		// Token: 0x04000CC0 RID: 3264
		OkOnly,
		// Token: 0x04000CC1 RID: 3265
		OkCancel,
		// Token: 0x04000CC2 RID: 3266
		YesNo,
		// Token: 0x04000CC3 RID: 3267
		YesNoCancel
	}
}
