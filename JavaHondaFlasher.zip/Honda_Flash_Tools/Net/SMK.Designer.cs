﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200039B RID: 923
	public partial class SMK : global::System.Windows.Forms.Form
	{
		// Token: 0x06000C51 RID: 3153 RVA: 0x00008D70 File Offset: 0x00008D70
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000C52 RID: 3154 RVA: 0x0005CD90 File Offset: 0x0005CD90
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Honda_Flash_Tools.Net.FormMain));
			this.label1 = new global::System.Windows.Forms.Label();
			this.button2 = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.progressBar1 = new global::Honda_Flash_Tools.Net.RoundedProgressBar();
			this.comboBox1 = new global::System.Windows.Forms.ComboBox();
			this.textBox1 = new global::System.Windows.Forms.TextBox();
			this.button1 = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.textBox2 = new global::System.Windows.Forms.TextBox();
			this.textBox3 = new global::System.Windows.Forms.TextBox();
			this.textBox4 = new global::System.Windows.Forms.TextBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.label3 = new global::System.Windows.Forms.Label();
			this.PERSEN = new global::System.Windows.Forms.Label();
			this.lblStatus = new global::System.Windows.Forms.Label();
			this.button3 = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.pictureBoxBarcode = new global::System.Windows.Forms.PictureBox();
			this.btnCloseX = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.mainPanel = new global::System.Windows.Forms.Panel();
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBoxBarcode).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			base.SuspendLayout();
			this.mainPanel.SuspendLayout();
			this.BackColor = global::Honda_Flash_Tools.Net.SMK.BgBase;
			this.ForeColor = global::Honda_Flash_Tools.Net.SMK.TextPrimary;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.TopMost = true;
			base.ClientSize = new global::System.Drawing.Size(600, 420);
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "\ud83d\ude80 DIAGNOSTIC TOOL - REMAPPING MODE \ud83d\ude80";
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Padding = new global::System.Windows.Forms.Padding(4);
			this.mainPanel.BackColor = global::System.Drawing.Color.Transparent;
			this.mainPanel.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.mainPanel.Font = new global::System.Drawing.Font("Segoe UI", 8.5f, global::System.Drawing.FontStyle.Regular);
			this.mainPanel.ForeColor = global::Honda_Flash_Tools.Net.SMK.TextPrimary;
			this.mainPanel.Location = new global::System.Drawing.Point(4, 4);
			this.mainPanel.Name = "mainPanel";
			this.mainPanel.Padding = new global::System.Windows.Forms.Padding(22);
			base.Controls.Add(this.mainPanel);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.BackColor = global::System.Drawing.Color.Transparent;
			this.pictureBox1.Location = new global::System.Drawing.Point(22, 12);
			this.pictureBox1.Size = new global::System.Drawing.Size(162, 52);
			this.pictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Cursor = global::System.Windows.Forms.Cursors.Default;
			try
			{
				if (base.Icon != null)
				{
					this.pictureBox1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
				}
			}
			catch
			{
				this.pictureBox1.Image = null;
			}
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Segoe UI", 16f, global::System.Drawing.FontStyle.Bold);
			this.label1.ForeColor = global::Honda_Flash_Tools.Net.SMK.Accent;
			this.label1.BackColor = global::System.Drawing.Color.Transparent;
			this.label1.Location = new global::System.Drawing.Point(180, 20);
			this.label1.Text = "\ud83d\udd11 ID SMARTKEY";
			global::System.Windows.Forms.Label label = new global::System.Windows.Forms.Label();
			label.Name = "lblSub";
			label.Text = "Honda smartkey ID reader & resetter";
			label.Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Italic);
			label.ForeColor = global::Honda_Flash_Tools.Net.SMK.TextMuted;
			label.BackColor = global::System.Drawing.Color.Transparent;
			label.AutoSize = true;
			label.Location = new global::System.Drawing.Point(182, 52);
			global::System.Windows.Forms.Panel panel = new global::System.Windows.Forms.Panel();
			panel.Name = "headerDiv";
			panel.BackColor = global::Honda_Flash_Tools.Net.SMK.BorderSoft;
			panel.Location = new global::System.Drawing.Point(22, 78);
			panel.Size = new global::System.Drawing.Size(552, 1);
			this.lblStatus.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.lblStatus.Font = new global::System.Drawing.Font("Segoe UI", 11f, global::System.Drawing.FontStyle.Bold);
			this.lblStatus.ForeColor = global::Honda_Flash_Tools.Net.SMK.Accent;
			this.lblStatus.BackColor = global::Honda_Flash_Tools.Net.SMK.BgSurface;
			this.lblStatus.Location = new global::System.Drawing.Point(22, 92);
			this.lblStatus.Size = new global::System.Drawing.Size(552, 42);
			this.lblStatus.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.lblStatus.Text = "Ready";
			int y = 148;
			int num = 10;
			int num2 = 176;
			int height = 36;
			this.button1.Text = "▶️  READ ID";
			this.button1.Size = new global::System.Drawing.Size(num2, height);
			this.button1.Location = new global::System.Drawing.Point(22, y);
			this.button1.BackColor = global::Honda_Flash_Tools.Net.SMK.BgSurface;
			this.button1.ForeColor = global::Honda_Flash_Tools.Net.SMK.Accent;
			this.button1.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Bold);
			this.button1.CornerRadius = 10;
			this.button1.BorderColor = global::Honda_Flash_Tools.Net.SMK.BorderSoft;
			this.button1.BorderWidth = 1f;
			this.button1.HoverBackColor = global::System.Drawing.Color.FromArgb(0, 60, 70);
			this.button1.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.button2.Text = "♻️  RESET KEIHIN";
			this.button2.Size = new global::System.Drawing.Size(num2, height);
			checked
			{
				this.button2.Location = new global::System.Drawing.Point(22 + num2 + num, y);
				this.button2.BackColor = global::Honda_Flash_Tools.Net.SMK.BgSurface;
				this.button2.ForeColor = global::Honda_Flash_Tools.Net.SMK.Accent;
				this.button2.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Bold);
				this.button2.CornerRadius = 10;
				this.button2.BorderColor = global::Honda_Flash_Tools.Net.SMK.BorderSoft;
				this.button2.BorderWidth = 1f;
				this.button2.HoverBackColor = global::System.Drawing.Color.FromArgb(0, 60, 70);
				this.button2.Cursor = global::System.Windows.Forms.Cursors.Hand;
				this.button2.Click += new global::System.EventHandler(this.button2_Click);
				this.button3.Text = "♻️  RESET SHINDENGEN";
				this.button3.Size = new global::System.Drawing.Size(num2, height);
				this.button3.Location = new global::System.Drawing.Point(22 + 2 * (num2 + num), y);
				this.button3.BackColor = global::Honda_Flash_Tools.Net.SMK.BgSurface;
				this.button3.ForeColor = global::Honda_Flash_Tools.Net.SMK.Accent;
				this.button3.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Bold);
				this.button3.CornerRadius = 10;
				this.button3.BorderColor = global::Honda_Flash_Tools.Net.SMK.BorderSoft;
				this.button3.BorderWidth = 1f;
				this.button3.HoverBackColor = global::System.Drawing.Color.FromArgb(0, 60, 70);
				this.button3.Cursor = global::System.Windows.Forms.Cursors.Hand;
				this.button3.Click += new global::System.EventHandler(this.button3_Click);
				this.textBox2.Font = new global::System.Drawing.Font("Consolas", 30f, global::System.Drawing.FontStyle.Bold);
				this.textBox2.BackColor = global::Honda_Flash_Tools.Net.SMK.BgInput;
				this.textBox2.ForeColor = global::Honda_Flash_Tools.Net.SMK.Accent;
				this.textBox2.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
				this.textBox2.Location = new global::System.Drawing.Point(22, 200);
				this.textBox2.Size = new global::System.Drawing.Size(552, 76);
				this.textBox2.Multiline = true;
				this.textBox2.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
				this.textBox2.Text = "\ud83d\udd11 ---------";
				this.textBox2.ReadOnly = true;
				this.progressBar1.Location = new global::System.Drawing.Point(22, 292);
				this.progressBar1.Size = new global::System.Drawing.Size(552, 16);
				this.progressBar1.CornerRadius = 8;
				this.progressBar1.TrackColor = global::Honda_Flash_Tools.Net.SMK.BgInput;
				this.progressBar1.BorderColor = global::Honda_Flash_Tools.Net.SMK.BorderSoft;
				this.progressBar1.BorderWidth = 1;
				this.progressBar1.BarColor = global::Honda_Flash_Tools.Net.SMK.Accent;
				this.progressBar1.BarColor2 = new global::System.Drawing.Color?(global::System.Drawing.Color.FromArgb(0, 255, 255));
				this.progressBar1.ForeColor = global::System.Drawing.Color.White;
				this.progressBar1.ShowPercentage = false;
				this.progressBar1.Minimum = 0;
				this.progressBar1.Maximum = 10000;
				this.progressBar1.Value = 0;
				this.comboBox1.Location = new global::System.Drawing.Point(22, 322);
				this.comboBox1.Size = new global::System.Drawing.Size(552, 26);
				this.comboBox1.BackColor = global::Honda_Flash_Tools.Net.SMK.BgInput;
				this.comboBox1.ForeColor = global::Honda_Flash_Tools.Net.SMK.Accent;
				this.comboBox1.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Bold);
				this.comboBox1.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
				this.comboBox1.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
				this.comboBox1.SelectedIndexChanged += new global::System.EventHandler(this.comboBox1_SelectedIndexChanged);
				this.textBox1.Visible = false;
				this.textBox3.Visible = false;
				this.textBox4.Visible = false;
				this.label2.Visible = false;
				this.label3.Visible = false;
				this.PERSEN.Visible = false;
				this.pictureBoxBarcode.Visible = false;
				global::System.Windows.Forms.Label label2 = new global::System.Windows.Forms.Label();
				label2.Name = "lblFooter";
				label2.AutoSize = false;
				label2.BackColor = global::System.Drawing.Color.Transparent;
				label2.Font = new global::System.Drawing.Font("Segoe UI", 7f, global::System.Drawing.FontStyle.Italic);
				label2.ForeColor = global::Honda_Flash_Tools.Net.SMK.TextMuted;
				label2.Location = new global::System.Drawing.Point(22, 384);
				label2.Size = new global::System.Drawing.Size(552, 14);
				label2.Text = "© JAVA TECH ELEGANT  •  ESC to close  •  Drag header to move";
				label2.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
				this.mainPanel.Controls.Add(this.pictureBox1);
				this.mainPanel.Controls.Add(this.label1);
				this.mainPanel.Controls.Add(label);
				this.mainPanel.Controls.Add(panel);
				this.mainPanel.Controls.Add(this.lblStatus);
				this.mainPanel.Controls.Add(this.button1);
				this.mainPanel.Controls.Add(this.button2);
				this.mainPanel.Controls.Add(this.button3);
				this.mainPanel.Controls.Add(this.textBox2);
				this.mainPanel.Controls.Add(this.progressBar1);
				this.mainPanel.Controls.Add(this.comboBox1);
				this.mainPanel.Controls.Add(label2);
				this.mainPanel.ResumeLayout(false);
				this.mainPanel.PerformLayout();
				((global::System.ComponentModel.ISupportInitialize)this.pictureBoxBarcode).EndInit();
				((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
				base.ResumeLayout(false);
				base.PerformLayout();
				base.Load += new global::System.EventHandler(this.SMK_Load);
			}
		}

		// Token: 0x04000E23 RID: 3619
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000E24 RID: 3620
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000E25 RID: 3621
		private global::System.Windows.Forms.ComboBox comboBox1;

		// Token: 0x04000E26 RID: 3622
		private global::System.Windows.Forms.TextBox textBox1;

		// Token: 0x04000E27 RID: 3623
		private global::System.Windows.Forms.PictureBox pictureBoxBarcode;

		// Token: 0x04000E28 RID: 3624
		private global::System.Windows.Forms.TextBox textBox2;

		// Token: 0x04000E29 RID: 3625
		private global::System.Windows.Forms.TextBox textBox3;

		// Token: 0x04000E2A RID: 3626
		private global::System.Windows.Forms.TextBox textBox4;

		// Token: 0x04000E2B RID: 3627
		private global::System.Windows.Forms.Label label2;

		// Token: 0x04000E2C RID: 3628
		private global::System.Windows.Forms.Label label3;

		// Token: 0x04000E2D RID: 3629
		private global::System.Windows.Forms.Label PERSEN;

		// Token: 0x04000E2E RID: 3630
		private global::System.Windows.Forms.Label lblStatus;

		// Token: 0x04000E2F RID: 3631
		private static readonly global::System.Drawing.Color BgBase = global::System.Drawing.Color.FromArgb(15, 17, 26);

		// Token: 0x04000E30 RID: 3632
		private static readonly global::System.Drawing.Color BgSurface = global::System.Drawing.Color.FromArgb(24, 27, 38);

		// Token: 0x04000E31 RID: 3633
		private static readonly global::System.Drawing.Color BgInput = global::System.Drawing.Color.FromArgb(32, 36, 50);

		// Token: 0x04000E32 RID: 3634
		private static readonly global::System.Drawing.Color BorderSoft = global::System.Drawing.Color.FromArgb(48, 54, 72);

		// Token: 0x04000E33 RID: 3635
		private static readonly global::System.Drawing.Color Accent = global::System.Drawing.Color.FromArgb(0, 229, 255);

		// Token: 0x04000E35 RID: 3637
		private static readonly global::System.Drawing.Color TextPrimary = global::System.Drawing.Color.FromArgb(235, 240, 250);

		// Token: 0x04000E36 RID: 3638
		private static readonly global::System.Drawing.Color TextMuted = global::System.Drawing.Color.FromArgb(150, 160, 180);

		// Token: 0x04000E3A RID: 3642
		private global::System.Windows.Forms.Panel mainPanel;

		// Token: 0x04000E3B RID: 3643
		private global::Honda_Flash_Tools.Net.RoundedButton button2;

		// Token: 0x04000E3C RID: 3644
		private global::Honda_Flash_Tools.Net.RoundedButton button1;

		// Token: 0x04000E3D RID: 3645
		private global::Honda_Flash_Tools.Net.RoundedButton button3;

		// Token: 0x04000E3E RID: 3646
		private global::Honda_Flash_Tools.Net.RoundedButton btnCloseX;

		// Token: 0x04000E3F RID: 3647
		private global::Honda_Flash_Tools.Net.RoundedProgressBar progressBar1;

		// Token: 0x04000E40 RID: 3648
		private global::System.Windows.Forms.PictureBox pictureBox1;
	}
}
