﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200071F RID: 1823
	public partial class Diag__0 : global::System.Windows.Forms.Form
	{
		// Token: 0x060010D9 RID: 4313 RVA: 0x0000B4C5 File Offset: 0x0000B4C5
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060010DA RID: 4314 RVA: 0x0007C870 File Offset: 0x0007C870
		private void InitializeComponent()
		{
			new global::System.ComponentModel.ComponentResourceManager(typeof(global::Honda_Flash_Tools.Net.Diag__0));
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.panel4 = new global::System.Windows.Forms.Panel();
			this.listBox1 = new global::System.Windows.Forms.ListBox();
			this.panel3 = new global::System.Windows.Forms.Panel();
			this.panel2 = new global::System.Windows.Forms.Panel();
			this.button1 = new global::System.Windows.Forms.Button();
			this.button2 = new global::System.Windows.Forms.Button();
			this.button4 = new global::System.Windows.Forms.Button();
			this.button3 = new global::System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.panel4.SuspendLayout();
			base.SuspendLayout();
			this.panel1.BackColor = global::System.Drawing.Color.Black;
			this.panel1.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.panel1.Controls.Add(this.panel4);
			this.panel1.Controls.Add(this.panel3);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Location = new global::System.Drawing.Point(14, 10);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(915, 549);
			this.panel1.TabIndex = 0;
			this.panel1.Paint += new global::System.Windows.Forms.PaintEventHandler(this.Panel_Paint);
			this.panel4.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.panel4.BackColor = global::System.Drawing.Color.Black;
			this.panel4.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.panel4.Controls.Add(this.listBox1);
			this.panel4.Location = new global::System.Drawing.Point(457, 13);
			this.panel4.Name = "panel4";
			this.panel4.Size = new global::System.Drawing.Size(448, 260);
			this.panel4.TabIndex = 2;
			this.panel4.Paint += new global::System.Windows.Forms.PaintEventHandler(this.Panel_Paint);
			this.listBox1.BackColor = global::System.Drawing.Color.FromArgb(45, 45, 48);
			this.listBox1.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.listBox1.DrawMode = global::System.Windows.Forms.DrawMode.OwnerDrawFixed;
			this.listBox1.Font = new global::System.Drawing.Font("Segoe UI", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.listBox1.ForeColor = global::System.Drawing.Color.Black;
			this.listBox1.ItemHeight = 15;
			this.listBox1.Location = new global::System.Drawing.Point(0, 0);
			this.listBox1.Name = "listBox1";
			this.listBox1.ScrollAlwaysVisible = true;
			this.listBox1.Size = new global::System.Drawing.Size(444, 205);
			this.listBox1.TabIndex = 0;
			this.listBox1.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.listBox1.Margin = new global::System.Windows.Forms.Padding(6);
			this.panel3.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.panel3.AutoSize = false;
			this.panel3.BackColor = global::System.Drawing.Color.FromArgb(45, 45, 48);
			this.panel3.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.panel3.Font = new global::System.Drawing.Font("Cambria", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.panel3.Location = new global::System.Drawing.Point(457, 273);
			this.panel3.Name = "panel3";
			this.panel3.Size = new global::System.Drawing.Size(448, 259);
			this.panel3.TabIndex = 1;
			this.panel3.Paint += new global::System.Windows.Forms.PaintEventHandler(this.Panel_Paint);
			this.panel2.AutoSize = false;
			this.panel2.BackColor = global::System.Drawing.Color.FromArgb(45, 45, 48);
			this.panel2.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.panel2.Font = new global::System.Drawing.Font("Cambria", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.panel2.Location = new global::System.Drawing.Point(5, 13);
			this.panel2.Name = "panel2";
			this.panel2.Size = new global::System.Drawing.Size(448, 519);
			this.panel2.TabIndex = 0;
			this.panel2.Paint += new global::System.Windows.Forms.PaintEventHandler(this.Panel_Paint);
			this.button1.BackColor = global::System.Drawing.Color.FromArgb(45, 50, 65);
			this.button1.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button1.FlatAppearance.BorderSize = 0;
			this.button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button1.Font = new global::System.Drawing.Font("Cambria", 12f, global::System.Drawing.FontStyle.Bold);
			this.button1.ForeColor = global::System.Drawing.Color.White;
			this.button1.Location = new global::System.Drawing.Point(820, 565);
			this.button1.Name = "button1";
			this.button1.Size = new global::System.Drawing.Size(109, 35);
			this.button1.TabIndex = 6;
			this.button1.Text = "Exit";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.button1.Paint += new global::System.Windows.Forms.PaintEventHandler(this.Button_Paint);
			this.button1.Resize += new global::System.EventHandler(this.Button_Resize);
			this.button1.MouseEnter += new global::System.EventHandler(this.Button_MouseEnter);
			this.button1.MouseLeave += new global::System.EventHandler(this.Button_MouseLeave);
			this.button2.BackColor = global::System.Drawing.Color.FromArgb(45, 50, 65);
			this.button2.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button2.FlatAppearance.BorderSize = 0;
			this.button2.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button2.Font = new global::System.Drawing.Font("Cambria", 12f, global::System.Drawing.FontStyle.Bold);
			this.button2.ForeColor = global::System.Drawing.Color.White;
			this.button2.Location = new global::System.Drawing.Point(645, 565);
			this.button2.Name = "button2";
			this.button2.Size = new global::System.Drawing.Size(109, 35);
			this.button2.TabIndex = 7;
			this.button2.Text = "Start";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new global::System.EventHandler(this.button2_Click);
			this.button2.Paint += new global::System.Windows.Forms.PaintEventHandler(this.Button_Paint);
			this.button2.Resize += new global::System.EventHandler(this.Button_Resize);
			this.button2.MouseEnter += new global::System.EventHandler(this.Button_MouseEnter);
			this.button2.MouseLeave += new global::System.EventHandler(this.Button_MouseLeave);
			this.button4.BackColor = global::System.Drawing.Color.FromArgb(45, 50, 65);
			this.button4.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button4.FlatAppearance.BorderSize = 0;
			this.button4.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button4.Font = new global::System.Drawing.Font("Cambria", 12f, global::System.Drawing.FontStyle.Bold);
			this.button4.ForeColor = global::System.Drawing.Color.White;
			this.button4.Location = new global::System.Drawing.Point(470, 565);
			this.button4.Name = "button4";
			this.button4.Size = new global::System.Drawing.Size(109, 35);
			this.button4.TabIndex = 8;
			this.button4.Text = "Reset ECM";
			this.button4.UseVisualStyleBackColor = false;
			this.button4.Click += new global::System.EventHandler(this.button4_Click);
			this.button4.Paint += new global::System.Windows.Forms.PaintEventHandler(this.Button_Paint);
			this.button4.Resize += new global::System.EventHandler(this.Button_Resize);
			this.button4.MouseEnter += new global::System.EventHandler(this.Button_MouseEnter);
			this.button4.MouseLeave += new global::System.EventHandler(this.Button_MouseLeave);
			this.button3.BackColor = global::System.Drawing.Color.FromArgb(45, 50, 65);
			this.button3.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button3.FlatAppearance.BorderSize = 0;
			this.button3.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button3.Font = new global::System.Drawing.Font("Cambria", 12f, global::System.Drawing.FontStyle.Bold);
			this.button3.ForeColor = global::System.Drawing.Color.White;
			this.button3.Location = new global::System.Drawing.Point(585, 565);
			this.button3.Name = "button3";
			this.button3.Size = new global::System.Drawing.Size(109, 35);
			this.button3.TabIndex = 7;
			this.button3.Text = "Read DTC";
			this.button3.UseVisualStyleBackColor = false;
			this.button3.Click += new global::System.EventHandler(this.button3_Click);
			this.button3.Enabled = false;
			this.button3.Paint += new global::System.Windows.Forms.PaintEventHandler(this.Button_Paint);
			this.button3.Resize += new global::System.EventHandler(this.Button_Resize);
			this.button3.MouseEnter += new global::System.EventHandler(this.Button_MouseEnter);
			this.button3.MouseLeave += new global::System.EventHandler(this.Button_MouseLeave);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(4.2f, 10.9f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(9, 9, 11);
			base.ClientSize = new global::System.Drawing.Size(943, 608);
			base.MaximizeBox = false;
			base.MinimizeBox = true;
			base.ControlBox = true;
			base.Controls.Add(this.button4);
			base.Controls.Add(this.button2);
			base.Controls.Add(this.button1);
			base.Controls.Add(this.panel1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Padding = new global::System.Windows.Forms.Padding(2);
			this.DoubleBuffered = true;
			base.SetStyle(global::System.Windows.Forms.ControlStyles.UserPaint | global::System.Windows.Forms.ControlStyles.ResizeRedraw | global::System.Windows.Forms.ControlStyles.AllPaintingInWmPaint | global::System.Windows.Forms.ControlStyles.OptimizedDoubleBuffer, true);
			base.Name = "Diag";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Diag";
			base.Load += new global::System.EventHandler(this.Diag_Load);
			base.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.Diag_MouseDown);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panel4.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		// Token: 0x04001768 RID: 5992
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04001769 RID: 5993
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x0400176A RID: 5994
		private global::System.Windows.Forms.Panel panel3;

		// Token: 0x0400176B RID: 5995
		private global::System.Windows.Forms.Panel panel2;

		// Token: 0x0400176C RID: 5996
		private global::System.Windows.Forms.Panel panel4;

		// Token: 0x0400176D RID: 5997
		private global::System.Windows.Forms.ListBox listBox1;

		// Token: 0x0400176E RID: 5998
		private global::System.Windows.Forms.Button button1;

		// Token: 0x0400176F RID: 5999
		private global::System.Windows.Forms.Button button2;

		// Token: 0x04001770 RID: 6000
		private global::System.Windows.Forms.Button button4;

		// Token: 0x04001771 RID: 6001
		private global::System.Windows.Forms.Button button3;
	}
}
