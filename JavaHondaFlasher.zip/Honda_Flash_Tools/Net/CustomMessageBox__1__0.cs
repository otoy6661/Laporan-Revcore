﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000626 RID: 1574
	public static class CustomMessageBox__1__0
	{
		// Token: 0x06000EEB RID: 3819 RVA: 0x0006BA6C File Offset: 0x0006BA6C
		public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
		{
			DialogResult result;
			using (Form form = new Form())
			{
				form.Text = caption;
				form.FormBorderStyle = FormBorderStyle.None;
				form.StartPosition = FormStartPosition.CenterParent;
				form.BackColor = Color.FromArgb(20, 25, 40);
				form.Size = new Size(400, 200);
				form.ShowInTaskbar = false;
				Panel panel = new Panel
				{
					Dock = DockStyle.Fill,
					BackColor = Color.FromArgb(30, 35, 50),
					Padding = new Padding(3)
				};
				Label value = new Label
				{
					Text = text,
					ForeColor = Color.Cyan,
					Font = new Font("Segoe UI", 9f),
					AutoSize = false,
					TextAlign = ContentAlignment.MiddleCenter,
					Dock = DockStyle.Fill,
					Padding = new Padding(20)
				};
				FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
				{
					Dock = DockStyle.Bottom,
					Height = 45,
					FlowDirection = FlowDirection.RightToLeft,
					BackColor = Color.Transparent,
					Padding = new Padding(0, 5, 10, 5)
				};
				Button btnOk = new Button
				{
					Text = "OK",
					Size = new Size(80, 28),
					FlatStyle = FlatStyle.Flat,
					BackColor = Color.FromArgb(0, 150, 200),
					ForeColor = Color.White,
					Font = new Font("Segoe UI", 8f, FontStyle.Bold),
					Cursor = Cursors.Hand
				};
				btnOk.FlatAppearance.BorderColor = Color.Cyan;
				btnOk.FlatAppearance.BorderSize = 2;
				btnOk.Click += delegate(object s, EventArgs e)
				{
					form.DialogResult = DialogResult.OK;
					form.Close();
				};
				flowLayoutPanel.Controls.Add(btnOk);
				panel.Controls.Add(value);
				panel.Controls.Add(flowLayoutPanel);
				form.Controls.Add(panel);
				form.Paint += delegate(object s, PaintEventArgs e)
				{
					using (Pen pen = new Pen(Color.Cyan, 2f))
					{
						e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
						using (GraphicsPath roundedPath = CustomMessageBox__1__0.GetRoundedPath(new Rectangle(1, 1, form.Width - 2, form.Height - 2), 15))
						{
							e.Graphics.DrawPath(pen, roundedPath);
						}
					}
					using (Pen pen2 = new Pen(Color.FromArgb(80, 0, 255, 255), 4f))
					{
						e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
						using (GraphicsPath roundedPath2 = CustomMessageBox__1__0.GetRoundedPath(new Rectangle(1, 1, form.Width - 2, form.Height - 2), 15))
						{
							e.Graphics.DrawPath(pen2, roundedPath2);
						}
					}
				};
				form.Region = new Region(CustomMessageBox__1__0.GetRoundedPath(new Rectangle(0, 0, form.Width, form.Height), 15));
				btnOk.MouseEnter += delegate(object s, EventArgs e)
				{
					btnOk.BackColor = Color.FromArgb(0, 200, 255);
				};
				btnOk.MouseLeave += delegate(object s, EventArgs e)
				{
					btnOk.BackColor = Color.FromArgb(0, 150, 200);
				};
				result = form.ShowDialog();
			}
			return result;
		}

		// Token: 0x06000EEC RID: 3820 RVA: 0x00068460 File Offset: 0x00068460
		private static GraphicsPath GetRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = radius * 2;
			graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}
	}
}
