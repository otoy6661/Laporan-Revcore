﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020003EA RID: 1002
	public class MyType
	{
	}
}
