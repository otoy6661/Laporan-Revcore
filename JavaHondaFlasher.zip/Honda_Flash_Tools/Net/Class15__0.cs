﻿using System;
using System.Runtime.InteropServices;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200062F RID: 1583
	public static class Class15__0
	{
		// Token: 0x06000F1A RID: 3866
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_Open(uint deviceNumber, ref IntPtr ftHandle);

		// Token: 0x06000F1B RID: 3867
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_Close(IntPtr ftHandle);

		// Token: 0x06000F1C RID: 3868
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_Read(IntPtr ftHandle, byte[] buffer, uint bytesToRead, ref uint bytesReturned);

		// Token: 0x06000F1D RID: 3869
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_Write(IntPtr ftHandle, byte[] buffer, uint bytesToWrite, ref uint bytesWritten);

		// Token: 0x06000F1E RID: 3870
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_SetBaudRate(IntPtr ftHandle, uint baudRate);

		// Token: 0x06000F1F RID: 3871
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_SetDataCharacteristics(IntPtr ftHandle, byte wordLength, byte stopBits, byte parity);

		// Token: 0x06000F20 RID: 3872
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_SetTimeouts(IntPtr ftHandle, uint readTimeout, uint writeTimeout);

		// Token: 0x06000F21 RID: 3873
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_SetLatencyTimer(IntPtr ftHandle, byte latency);

		// Token: 0x06000F22 RID: 3874
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_Purge(IntPtr ftHandle, uint mask);

		// Token: 0x06000F23 RID: 3875
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_SetBitMode(IntPtr ftHandle, byte mask, byte enable);

		// Token: 0x06000F24 RID: 3876
		[DllImport("ftd2xx.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint FT_GetQueueStatus(IntPtr ftHandle, ref uint rxBytes);

		// Token: 0x04001416 RID: 5142
		private const string FTDI_DLL = "ftd2xx.dll";

		// Token: 0x02000630 RID: 1584
		public enum Enum5 : uint
		{
			// Token: 0x04001418 RID: 5144
			const_0,
			// Token: 0x04001419 RID: 5145
			const_1,
			// Token: 0x0400141A RID: 5146
			const_2,
			// Token: 0x0400141B RID: 5147
			const_3,
			// Token: 0x0400141C RID: 5148
			const_4,
			// Token: 0x0400141D RID: 5149
			const_5,
			// Token: 0x0400141E RID: 5150
			const_6,
			// Token: 0x0400141F RID: 5151
			const_7,
			// Token: 0x04001420 RID: 5152
			const_8,
			// Token: 0x04001421 RID: 5153
			const_9,
			// Token: 0x04001422 RID: 5154
			const_10,
			// Token: 0x04001423 RID: 5155
			const_11,
			// Token: 0x04001424 RID: 5156
			const_12,
			// Token: 0x04001425 RID: 5157
			const_13,
			// Token: 0x04001426 RID: 5158
			const_14,
			// Token: 0x04001427 RID: 5159
			const_15,
			// Token: 0x04001428 RID: 5160
			const_16,
			// Token: 0x04001429 RID: 5161
			const_17,
			// Token: 0x0400142A RID: 5162
			const_18,
			// Token: 0x0400142B RID: 5163
			const_19
		}
	}
}
