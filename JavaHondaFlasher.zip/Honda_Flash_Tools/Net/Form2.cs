﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000575 RID: 1397
	public partial class Form2 : Form
	{
		// Token: 0x06000D9B RID: 3483 RVA: 0x000097D3 File Offset: 0x000097D3
		public Form2()
		{
			this.InitializeComponent();
			this.Create3DLabels();
		}

		// Token: 0x06000D9C RID: 3484 RVA: 0x0000282D File Offset: 0x0000282D
		private void button1_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		// Token: 0x06000DA0 RID: 3488 RVA: 0x00067FB0 File Offset: 0x00067FB0
		private void ColorTimer_Tick(object sender, EventArgs e)
		{
			this.hue = checked(this.hue + 1) % 360;
			Color backColor = this.HsvToRgb((double)this.hue, 0.9, 0.3);
			this.BackColor = backColor;
			this.ForeColor = Color.White;
			base.Invalidate();
		}

		// Token: 0x06000DA1 RID: 3489 RVA: 0x0000980D File Offset: 0x0000980D
		protected override void OnFormClosing(FormClosingEventArgs e)
		{
			if (this.colorTimer != null)
			{
				this.colorTimer.Stop();
				this.colorTimer.Dispose();
			}
			base.OnFormClosing(e);
		}

		// Token: 0x06000DA2 RID: 3490 RVA: 0x0006800C File Offset: 0x0006800C
		private Color HsvToRgb(double h, double s, double v)
		{
			double num = v * s;
			double num2 = num * (1.0 - Math.Abs(h / 60.0 % 2.0 - 1.0));
			double num3 = v - num;
			double num4 = 0.0;
			double num5 = 0.0;
			double num6 = 0.0;
			if (h >= 0.0 && h < 60.0)
			{
				num4 = num;
				num5 = num2;
				num6 = 0.0;
			}
			else if (h >= 60.0 && h < 120.0)
			{
				num4 = num2;
				num5 = num;
				num6 = 0.0;
			}
			else if (h >= 120.0 && h < 180.0)
			{
				num4 = 0.0;
				num5 = num;
				num6 = num2;
			}
			else if (h >= 180.0 && h < 240.0)
			{
				num4 = 0.0;
				num5 = num2;
				num6 = num;
			}
			else if (h >= 240.0 && h < 300.0)
			{
				num4 = num2;
				num5 = 0.0;
				num6 = num;
			}
			else if (h >= 300.0 && h < 360.0)
			{
				num4 = num;
				num5 = 0.0;
				num6 = num2;
			}
			return checked(Color.FromArgb((int)(unchecked((num4 + num3) * 255.0)), (int)(unchecked((num5 + num3) * 255.0)), (int)(unchecked((num6 + num3) * 255.0))));
		}

		// Token: 0x06000DA3 RID: 3491 RVA: 0x000681A4 File Offset: 0x000681A4
		private Icon CreateDefaultIcon()
		{
			Bitmap bitmap = new Bitmap(32, 32);
			using (Graphics graphics = Graphics.FromImage(bitmap))
			{
				graphics.Clear(Color.Transparent);
				using (Brush brush = new SolidBrush(Color.Gold))
				{
					graphics.FillRectangle(brush, 4, 4, 24, 24);
				}
				using (Font font = new Font("Arial", 16f, FontStyle.Bold))
				{
					using (Brush brush2 = new SolidBrush(Color.Blue))
					{
						graphics.DrawString("H", font, brush2, 8f, 4f);
					}
				}
			}
			return Icon.FromHandle(bitmap.GetHicon());
		}

		// Token: 0x06000DA4 RID: 3492 RVA: 0x00068288 File Offset: 0x00068288
		private void Create3DLabels()
		{
			Font font = new Font("Impact", 13f, FontStyle.Italic);
			this.lblRenew = new Form2.Label3D
			{
				Text = "DEPPLOY MAP",
				Font = font,
				ForeColor = SystemColors.ButtonShadow,
				ShadowColor = Color.Cyan,
				ShadowOffsetX = 2,
				ShadowOffsetY = 2,
				Depth = 4,
				BackColor = Color.Transparent,
				AutoSize = true,
				Location = new Point(199, 131),
				Anchor = (AnchorStyles.Bottom | AnchorStyles.Right)
			};
			checked
			{
				this.lblRenew.Paint += delegate(object sender, PaintEventArgs e)
				{
					Control control = sender as Control;
					if (control != null)
					{
						e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
						using (Pen pen = new Pen(Color.FromArgb(100, Color.Gold), 3f))
						{
							e.Graphics.DrawRectangle(pen, new Rectangle(0, 0, control.Width - 1, control.Height - 1));
						}
						using (Pen pen2 = new Pen(Color.Gold, 2f))
						{
							e.Graphics.DrawRectangle(pen2, new Rectangle(2, 2, control.Width - 5, control.Height - 5));
						}
					}
				};
				this.lblEcuMode = new Form2.Label3D
				{
					Text = "TUNING PRO",
					Font = font,
					ForeColor = Form2.NeonGreen,
					ShadowColor = Color.Cyan,
					ShadowOffsetX = 2,
					ShadowOffsetY = 2,
					Depth = 4,
					BackColor = Color.Transparent,
					AutoSize = true,
					Location = new Point(220, 151),
					Anchor = (AnchorStyles.Bottom | AnchorStyles.Right)
				};
				this.lblEcuMode.Paint += delegate(object sender, PaintEventArgs e)
				{
					Control control = sender as Control;
					if (control != null)
					{
						e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
						using (Pen pen = new Pen(Color.FromArgb(100, Form2.NeonMagenta), 3f))
						{
							e.Graphics.DrawRectangle(pen, new Rectangle(0, 0, control.Width - 1, control.Height - 1));
						}
						using (Pen pen2 = new Pen(Form2.NeonMagenta, 2f))
						{
							e.Graphics.DrawRectangle(pen2, new Rectangle(2, 2, control.Width - 5, control.Height - 5));
						}
					}
				};
				base.Controls.Add(this.lblRenew);
				base.Controls.Add(this.lblEcuMode);
			}
		}

		// Token: 0x06000DA5 RID: 3493 RVA: 0x0006840C File Offset: 0x0006840C
		private void ApplyRoundedRegion()
		{
			using (GraphicsPath roundedRect = Form2.GetRoundedRect(new Rectangle(0, 0, base.Width - 1, base.Height - 1), 14))
			{
				base.Region = new Region(roundedRect);
			}
		}

		// Token: 0x06000DA6 RID: 3494 RVA: 0x00068460 File Offset: 0x00068460
		private static GraphicsPath GetRoundedRect(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = radius * 2;
			graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x04001242 RID: 4674
		private PictureBox pictureBox1;

		// Token: 0x04001243 RID: 4675
		private Label label1;

		// Token: 0x04001244 RID: 4676
		private Label label2;

		// Token: 0x04001245 RID: 4677
		private Label label3;

		// Token: 0x04001246 RID: 4678
		private Button button1;

		// Token: 0x04001247 RID: 4679
		private Timer colorTimer;

		// Token: 0x04001248 RID: 4680
		private int colorStep;

		// Token: 0x04001249 RID: 4681
		private int direction = 1;

		// Token: 0x0400124A RID: 4682
		private int hue;

		// Token: 0x04001254 RID: 4692
		private static readonly Color NeonMagenta = Color.FromArgb(255, 0, 200);

		// Token: 0x04001258 RID: 4696
		private TableLayoutPanel rootLayout;

		// Token: 0x04001259 RID: 4697
		private TableLayoutPanel infoLayout;

		// Token: 0x0400125A RID: 4698
		private TableLayoutPanel mainLayout;

		// Token: 0x02000576 RID: 1398
		public class Label3D : Label
		{
			// Token: 0x17000031 RID: 49
			// (get) Token: 0x06000DAB RID: 3499 RVA: 0x0000983C File Offset: 0x0000983C
			// (set) Token: 0x06000DAC RID: 3500 RVA: 0x00009844 File Offset: 0x00009844
			public Color ShadowColor { get; set; } = Color.Black;

			// Token: 0x17000032 RID: 50
			// (get) Token: 0x06000DAD RID: 3501 RVA: 0x0000984D File Offset: 0x0000984D
			// (set) Token: 0x06000DAE RID: 3502 RVA: 0x00009855 File Offset: 0x00009855
			public int ShadowOffsetX { get; set; } = 2;

			// Token: 0x17000033 RID: 51
			// (get) Token: 0x06000DAF RID: 3503 RVA: 0x0000985E File Offset: 0x0000985E
			// (set) Token: 0x06000DB0 RID: 3504 RVA: 0x00009866 File Offset: 0x00009866
			public int ShadowOffsetY { get; set; } = 2;

			// Token: 0x17000034 RID: 52
			// (get) Token: 0x06000DB1 RID: 3505 RVA: 0x0000986F File Offset: 0x0000986F
			// (set) Token: 0x06000DB2 RID: 3506 RVA: 0x00009877 File Offset: 0x00009877
			public int Depth { get; set; } = 3;

			// Token: 0x06000DB3 RID: 3507 RVA: 0x000685FC File Offset: 0x000685FC
			protected override void OnPaint(PaintEventArgs e)
			{
				checked
				{
					for (int i = 1; i <= this.Depth; i++)
					{
						using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(100 / i, this.ShadowColor)))
						{
							e.Graphics.DrawString(this.Text, this.Font, solidBrush, (float)(this.ShadowOffsetX * i), (float)(this.ShadowOffsetY * i));
						}
					}
					using (SolidBrush solidBrush2 = new SolidBrush(this.ForeColor))
					{
						e.Graphics.DrawString(this.Text, this.Font, solidBrush2, 0f, 0f);
					}
				}
			}
		}
	}
}
