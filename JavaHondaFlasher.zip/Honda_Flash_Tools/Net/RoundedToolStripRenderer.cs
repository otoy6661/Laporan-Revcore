﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020005EA RID: 1514
	public class RoundedToolStripRenderer : ToolStripProfessionalRenderer
	{
		// Token: 0x06000EBA RID: 3770 RVA: 0x0000A1B1 File Offset: 0x0000A1B1
		public RoundedToolStripRenderer(DarkColorTable table, Color borderColor, int cornerRadius = 8) : base(table)
		{
			this._borderColor = borderColor;
			this._cornerRadius = cornerRadius;
			base.RoundedEdges = false;
		}

		// Token: 0x06000EBB RID: 3771 RVA: 0x000026F4 File Offset: 0x000026F4
		protected override void OnRenderToolStripBorder(ToolStripRenderEventArgs e)
		{
		}

		// Token: 0x04001384 RID: 4996
		private readonly Color _borderColor;

		// Token: 0x04001385 RID: 4997
		private readonly int _cornerRadius;
	}
}
