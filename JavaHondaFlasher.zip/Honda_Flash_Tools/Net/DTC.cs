﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO.Ports;
using System.Threading;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000319 RID: 793
	public partial class DTC : Form
	{
		// Token: 0x06000A26 RID: 2598 RVA: 0x00007CD8 File Offset: 0x00007CD8
		public DTC()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000A27 RID: 2599 RVA: 0x00007CE6 File Offset: 0x00007CE6
		private void method_134()
		{
			this.Timer_0.Enabled = false;
		}

		// Token: 0x06000A28 RID: 2600 RVA: 0x0004BA68 File Offset: 0x0004BA68
		private void method_110()
		{
			int num = 0;
			string[] array = new string[21];
			byte[] array2 = new byte[]
			{
				114,
				5,
				116,
				1,
				20
			};
			byte[] array3 = new byte[]
			{
				114,
				5,
				116,
				2,
				19
			};
			byte[] array4 = new byte[]
			{
				114,
				5,
				116,
				3,
				18
			};
			byte[] array5 = new byte[]
			{
				114,
				5,
				115,
				1,
				21
			};
			byte[] array6 = new byte[]
			{
				114,
				5,
				115,
				2,
				20
			};
			byte[] array7 = new byte[]
			{
				114,
				5,
				115,
				3,
				19
			};
			this.SerialPort_0.ReadExisting();
			this.SerialPort_0.Write(array2, 0, array2.Length);
			Thread.Sleep(50);
			this.SerialPort_0.Write(array3, 0, array3.Length);
			Thread.Sleep(50);
			this.SerialPort_0.Write(array4, 0, array4.Length);
			Thread.Sleep(50);
			this.SerialPort_0.DiscardOutBuffer();
			this.string_9 = null;
			this.method_11();
			checked
			{
				if (this.string_9 != null && this.string_9.Length > 35)
				{
					int num2 = 1;
					do
					{
						try
						{
							string hexString;
							if (num2 < 7)
							{
								hexString = this.string_9.Substring(num2 * 2 + 18, 2);
							}
							else if (num2 < 13)
							{
								hexString = this.string_9.Substring(num2 * 2 + 40, 2);
							}
							else
							{
								hexString = this.string_9.Substring(num2 * 2 + 62, 2);
							}
							array[num2] = this.HexToInt(hexString).ToString();
							double num3;
							double num4;
							if (double.TryParse(array[num2], out num3) && num2 > 0 && double.TryParse(array[num2 - 1], out num4))
							{
								if (num3 == 0.0 && num4 == 0.0)
								{
									break;
								}
								if (num2 % 2 == 0)
								{
									num++;
									string text = this.method_111(int.Parse(array[num2 - 1]));
									this.dataviewFaultCodes.Rows.Add(new object[]
									{
										num,
										array[num2 - 1] + "-" + array[num2],
										text,
										"x"
									});
								}
							}
						}
						catch (Exception ex)
						{
							Console.WriteLine(string.Format("Error processing DTC at index {0}: {1}", num2, ex.Message));
							break;
						}
						num2++;
					}
					while (num2 <= 18);
				}
				this.SerialPort_0.Write(array5, 0, array5.Length);
				Thread.Sleep(50);
				this.SerialPort_0.Write(array6, 0, array6.Length);
				Thread.Sleep(50);
				this.SerialPort_0.Write(array7, 0, array7.Length);
				Thread.Sleep(50);
				this.SerialPort_0.DiscardOutBuffer();
				this.string_9 = null;
				this.method_11();
				if (this.string_9 != null && this.string_9.Length > 35)
				{
					int num5 = 1;
					do
					{
						try
						{
							string hexString2;
							if (num5 < 7)
							{
								hexString2 = this.string_9.Substring(num5 * 2 + 18, 2);
							}
							else if (num5 < 13)
							{
								hexString2 = this.string_9.Substring(num5 * 2 + 40, 2);
							}
							else
							{
								hexString2 = this.string_9.Substring(num5 * 2 + 62, 2);
							}
							array[num5] = this.HexToInt(hexString2).ToString();
							double num6;
							double num7;
							if (double.TryParse(array[num5], out num6) && num5 > 0 && double.TryParse(array[num5 - 1], out num7))
							{
								if (num6 == 0.0 && num7 == 0.0)
								{
									break;
								}
								if (num5 % 2 == 0)
								{
									num++;
									string text2 = this.method_111(int.Parse(array[num5 - 1]));
									this.dataviewFaultCodes.Rows.Add(new object[]
									{
										num,
										array[num5 - 1] + "-" + array[num5],
										text2,
										"",
										"x"
									});
								}
							}
						}
						catch (Exception ex2)
						{
							Console.WriteLine(string.Format("Error processing DTC at index {0}: {1}", num5, ex2.Message));
							break;
						}
						num5++;
					}
					while (num5 <= 18);
				}
				if (num == 0)
				{
					this.dataviewFaultCodes.Rows.Add(new object[]
					{
						"",
						"",
						"Tidak Ada Kode MIL Pada ECM - No DTC"
					});
				}
			}
		}

		// Token: 0x06000A29 RID: 2601 RVA: 0x0004BEEC File Offset: 0x0004BEEC
		public string method_111(int int_10)
		{
			string result;
			try
			{
				if (int_10 <= 57)
				{
					if (int_10 <= 52)
					{
						switch (int_10)
						{
						case 1:
						case 10:
							return "Sensor Manifold Absolute Pressure (MAP).";
						case 2:
							return "Kinerja sensor Manifold Absolute Pressure (MAP)";
						case 7:
							return "Sensor Suhu Pendingin Mesin (ECT/EOT)";
						case 8:
							return "Sensor Posisi Throttle (TP) atau (TP) kinerja buruk";
						case 9:
							return "Sinyal sensor suhu udara masuk IAT";
						case 11:
							return "Rangkaian sinyal sensor kecepatan kendaraan Rusak (Vss)";
						case 12:
							return "Rangkaian kontrol injektor No.1";
						case 14:
							return "Rangkaian kontrol injektor No.3";
						case 15:
							return "Rangkaian kontrol injektor No.4";
						case 16:
							return "Sirkuit kontrol injektor sekunder nomor 1";
						case 17:
							return "Sirkuit kontrol injektor sekunder ke-2";
						case 18:
							return "Sinyal generator sinyal camshaft hilang";
						case 19:
							return "Sinyal generator pulsa pengapian hilang";
						case 20:
							return "Kesalahan tembolok EEPROM di kotak kontrol mesin";
						case 21:
							return "Kesalahan sirkuit sinyal sensor emisi oksigen (O2)";
						case 22:
							return "Kesalahan rangkaian sinyal sensor oksigen ke-2";
						case 23:
							return "Kesalahan rangkaian kontrol koil sensor oksigen(O2)";
						case 24:
							return "Kesalahan rangkaian kontrol koil pemanas sensor oksigen no.2";
						case 29:
							return "katup kontrol kecepatan idle IACV";
						case 33:
							return "(ECM) EEPROM cache error";
						}
						if (int_10 == 52)
						{
							return "sinyal sensor posisi poros engkol CKP";
						}
					}
					else
					{
						if (int_10 == 54)
						{
							return "sinyal sensor kemiringan (BAS)";
						}
						if (int_10 == 57)
						{
							return "sinyal sensor suhu pendingin ";
						}
					}
				}
				else if (int_10 <= 82)
				{
					switch (int_10)
					{
					case 71:
						return "Tegangan sensor TP No.1 di luar jangkauan";
					case 72:
						return "Tegangan sensor Tp No.2 di luar jangkauan";
					case 73:
						return "No. 1 dan 2 TP kesalahan sinkronisasi tegangan sensor posisi throttle";
					default:
						if (int_10 == 82)
						{
							return "Kesalahan katup solenoid idle cepat FISV";
						}
						break;
					}
				}
				else
				{
					switch (int_10)
					{
					case 88:
						return "Kesalahan rangkaian kontrol katup evaporator bahan bakar EVAP";
					case 89:
						return "Kesalahan sirkuit katup perawatan gas yang efectif dengan injeksi udara sekunder (PAIR/AISV)";
					case 91:
						return "Kerusakan sirkuit kontrol koil pengapian primer";
					}
					if (int_10 == 103)
					{
						return "Kesalahan protokol bus CAN dari ECM ke dasbor";
					}
				}
				result = "Kode kesalahan belum ada di database. Harap tunggu pembaruan!";
			}
			catch
			{
				result = "Error processing DTC code";
			}
			return result;
		}

		// Token: 0x06000A2A RID: 2602 RVA: 0x0004C15C File Offset: 0x0004C15C
		private void method_11()
		{
			while (this.SerialPort_0.BytesToRead > 0)
			{
				try
				{
					this.byte_0 = checked((byte)this.SerialPort_0.ReadByte());
					base.Invoke(new EventHandler(this.method_12));
				}
				catch (Exception)
				{
				}
			}
		}

		// Token: 0x06000A2B RID: 2603 RVA: 0x0004C1B4 File Offset: 0x0004C1B4
		private void DTC_Load(object sender, EventArgs e)
		{
			try
			{
				this.stsSNCable.Visible = true;
				this.txtCOMName.Visible = true;
				this.method_01();
				this.method_1111();
				this.method_134();
				this.method_110();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error loading DTC form: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x06000A2C RID: 2604 RVA: 0x0004C224 File Offset: 0x0004C224
		private void button1_Click(object sender, EventArgs e)
		{
			Thread.Sleep(1000);
			byte[] array = new byte[]
			{
				254,
				4,
				114,
				140
			};
			byte[] array2 = new byte[]
			{
				114,
				5,
				0,
				240,
				153
			};
			byte[] array3 = new byte[]
			{
				114,
				5,
				96,
				3,
				38
			};
			if (!this.SerialPort_0.IsOpen)
			{
				this.SerialPort_0.Open();
			}
			this.SerialPort_0.BaudRate = 10400;
			this.SerialPort_0.BreakState = false;
			Thread.Sleep(100);
			this.SerialPort_0.BreakState = true;
			Thread.Sleep(70);
			this.SerialPort_0.BreakState = false;
			this.SerialPort_0.Write(array, 0, array.Length);
			Thread.Sleep(30);
			this.SerialPort_0.Write(array2, 0, array2.Length);
			Thread.Sleep(30);
			this.SerialPort_0.ReadExisting();
			this.SerialPort_0.Write(array3, 0, array3.Length);
			Thread.Sleep(500);
			CustomMessageBox__1.Show("Reset All ECM Completed\rKlik OK Lalu Kontak OFF Tunggu 10 Detik ON", "RESET ALL ECM", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			Thread.Sleep(1000);
			this.method_134();
			this.method_112();
		}

		// Token: 0x06000A2F RID: 2607 RVA: 0x0004CE74 File Offset: 0x0004CE74
		private void method_112()
		{
			byte[] array = new byte[]
			{
				254,
				4,
				114,
				140
			};
			byte[] array2 = new byte[]
			{
				114,
				5,
				0,
				240,
				153
			};
			byte[] array3 = new byte[]
			{
				114,
				5,
				96,
				3,
				38
			};
			byte[] array4 = new byte[]
			{
				114,
				5,
				96,
				1,
				40
			};
			try
			{
				this.dataviewFaultCodes.Rows.Clear();
				this.dataviewFaultCodes.Refresh();
				this.Timer_0.Enabled = false;
				if (!this.SerialPort_0.IsOpen)
				{
					this.SerialPort_0.Open();
				}
				this.SerialPort_0.BaudRate = 10400;
				this.SerialPort_0.BreakState = false;
				Thread.Sleep(100);
				this.SerialPort_0.BreakState = true;
				Thread.Sleep(70);
				this.SerialPort_0.BreakState = false;
				Thread.Sleep(5);
				Thread.Sleep(145);
				this.SerialPort_0.Write(array, 0, array.Length);
				Thread.Sleep(30);
				this.SerialPort_0.Write(array2, 0, array2.Length);
				Thread.Sleep(30);
				this.SerialPort_0.DiscardOutBuffer();
				this.SerialPort_0.ReadExisting();
				this.SerialPort_0.Write(array3, 0, array3.Length);
				Thread.Sleep(50);
				this.SerialPort_0.Write(array4, 0, array4.Length);
				Thread.Sleep(50);
				Thread.Sleep(1000);
				this.method_110();
				this.SerialPort_0.Close();
				Thread.Sleep(1000);
			}
			catch (Exception)
			{
				this.SerialPort_0.Close();
			}
		}

		// Token: 0x06000A30 RID: 2608 RVA: 0x0004D020 File Offset: 0x0004D020
		private void button2_Click(object sender, EventArgs e)
		{
			byte[] array = new byte[]
			{
				254,
				4,
				114,
				140
			};
			byte[] array2 = new byte[]
			{
				114,
				5,
				0,
				240,
				153
			};
			byte[] array3 = new byte[]
			{
				114,
				5,
				96,
				3,
				38
			};
			byte[] array4 = new byte[]
			{
				114,
				5,
				96,
				1,
				40
			};
			try
			{
				this.dataviewFaultCodes.Rows.Clear();
				this.dataviewFaultCodes.Refresh();
				this.Timer_0.Enabled = false;
				if (!this.SerialPort_0.IsOpen)
				{
					this.SerialPort_0.Open();
				}
				this.SerialPort_0.BaudRate = 10400;
				this.SerialPort_0.BreakState = false;
				Thread.Sleep(100);
				this.SerialPort_0.BreakState = true;
				Thread.Sleep(70);
				this.SerialPort_0.BreakState = false;
				Thread.Sleep(5);
				Thread.Sleep(145);
				this.SerialPort_0.Write(array, 0, array.Length);
				Thread.Sleep(30);
				this.SerialPort_0.Write(array2, 0, array2.Length);
				Thread.Sleep(30);
				this.SerialPort_0.DiscardOutBuffer();
				this.SerialPort_0.ReadExisting();
				this.SerialPort_0.Write(array3, 0, array3.Length);
				Thread.Sleep(50);
				this.SerialPort_0.Write(array4, 0, array4.Length);
				Thread.Sleep(50);
				CustomMessageBox__1.Show("Reset All Diagnostic Trouble Code\rKlik OK Untuk Menghapus Kode Kerusakan", "RESET ALL DTC", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				Thread.Sleep(1000);
				this.method_110();
				this.method_134();
				this.method_112();
				this.SerialPort_0.Close();
				Thread.Sleep(1000);
			}
			catch (Exception)
			{
				this.SerialPort_0.Close();
			}
		}

		// Token: 0x06000A31 RID: 2609 RVA: 0x0004D1EC File Offset: 0x0004D1EC
		private double ParseDouble(string hexValue)
		{
			if (string.IsNullOrEmpty(hexValue))
			{
				return 0.0;
			}
			double result;
			try
			{
				hexValue = hexValue.Trim();
				if (hexValue.StartsWith("&H", StringComparison.OrdinalIgnoreCase))
				{
					hexValue = hexValue.Substring(2);
				}
				string text = "";
				foreach (char c in hexValue)
				{
					if ((c < '0' || c > '9') && (c < 'A' || c > 'F') && (c < 'a' || c > 'f'))
					{
						break;
					}
					text += c.ToString();
				}
				if (string.IsNullOrEmpty(text))
				{
					result = 0.0;
				}
				else
				{
					result = (double)Convert.ToInt32(text, 16);
				}
			}
			catch
			{
				result = 0.0;
			}
			return result;
		}

		// Token: 0x06000A32 RID: 2610 RVA: 0x0004D2BC File Offset: 0x0004D2BC
		private int HexToInt(string hexString)
		{
			if (string.IsNullOrEmpty(hexString))
			{
				return 0;
			}
			int i;
			try
			{
				hexString = hexString.Trim();
				string text = "";
				foreach (char c in hexString)
				{
					if ((c < '0' || c > '9') && (c < 'A' || c > 'F') && (c < 'a' || c > 'f'))
					{
						break;
					}
					text += c.ToString();
				}
				if (string.IsNullOrEmpty(text))
				{
					i = 0;
				}
				else
				{
					i = Convert.ToInt32(text, 16);
				}
			}
			catch
			{
				i = 0;
			}
			return i;
		}

		// Token: 0x06000A33 RID: 2611 RVA: 0x0004D358 File Offset: 0x0004D358
		private void method_12(object sender, EventArgs e)
		{
			int num = (int)this.byte_0;
			this.string_9 += num.ToString("X2");
		}

		// Token: 0x06000A34 RID: 2612 RVA: 0x0004D38C File Offset: 0x0004D38C
		private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = radius * 2;
			graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x06000A35 RID: 2613 RVA: 0x0004D430 File Offset: 0x0004D430
		private void method_01()
		{
			try
			{
				List<GClass1> list = GClass1.smethod_0();
				string text = "";
				bool flag = false;
				if (list == null || list.Count == 0)
				{
					this.txtCOMName.Text = "● COM: —";
					this.stsSNCable.Text = "● Cable: Not Detected";
					this.stsSNCable.ForeColor = Color.FromArgb(230, 100, 100);
				}
				else
				{
					foreach (GClass1 gclass in list)
					{
						string string_ = gclass.String_1;
						if (!string.IsNullOrEmpty(string_) && (string_.Contains("FTDIBUS\\VID_0403+PID_6001") || string_.Contains("USB\\VID_0403+PID_6001")))
						{
							this.txtCOMName.Text = "● COM: " + gclass.String_0;
							this.txtCOMName.ForeColor = Color.FromArgb(0, 200, 230);
							string text2 = "";
							if (string_.Length > 30)
							{
								try
								{
									int num = string_.IndexOf("+");
									if (num > 0 && string_.IndexOf("+", num + 1) > num + 1)
									{
										text2 = string_.Substring(num + 1, 3);
									}
								}
								catch
								{
									text2 = "";
								}
							}
							if (!string.IsNullOrEmpty(text2))
							{
								try
								{
									text = (this.ParseDouble(text2) * 2.0).ToString();
									goto IL_162;
								}
								catch
								{
									text = "Unknown";
									goto IL_162;
								}
							}
							text = "Detected";
							IL_162:
							flag = true;
							Application.DoEvents();
							break;
						}
					}
					if (!flag)
					{
						this.txtCOMName.Text = "● COM: Not Found";
						this.stsSNCable.Text = "● Cable: Not Connected";
						this.stsSNCable.ForeColor = Color.FromArgb(230, 100, 100);
					}
					else if (text.Length > 0)
					{
						Thread.Sleep(500);
						this.stsSNCable.Text = "● Cable: " + text;
						this.stsSNCable.ForeColor = Color.FromArgb(120, 200, 120);
					}
				}
			}
			catch (Exception ex)
			{
				this.txtCOMName.Text = "● COM: Error";
				this.stsSNCable.Text = "● Cable: Error - " + ex.Message;
				this.stsSNCable.ForeColor = Color.FromArgb(230, 100, 100);
			}
		}

		// Token: 0x06000A36 RID: 2614 RVA: 0x0004D6F4 File Offset: 0x0004D6F4
		private void method_1111()
		{
			try
			{
				if (string.IsNullOrEmpty(this.txtCOMName.Text) || this.txtCOMName.Text.Contains("Not Found") || this.txtCOMName.Text.Contains("Error"))
				{
					this.AutoDetectCOMPort();
				}
				if (this.SerialPort_0.IsOpen)
				{
					this.SerialPort_0.Write("MicroCommand");
				}
				else
				{
					string text = this.txtCOMName.Text.Replace("● COM: ", "").Trim();
					if (string.IsNullOrEmpty(text) || !text.StartsWith("COM"))
					{
						throw new Exception("Invalid COM port");
					}
					try
					{
						this.SerialPort_0.PortName = text;
						this.SerialPort_0.BaudRate = 10400;
						this.SerialPort_0.Parity = Parity.None;
						this.SerialPort_0.DataBits = 8;
						this.SerialPort_0.StopBits = StopBits.One;
						this.SerialPort_0.Handshake = Handshake.None;
						this.SerialPort_0.RtsEnable = true;
						this.SerialPort_0.Open();
						this.SerialPort_0.Write(new byte[]
						{
							1
						}, 0, 1);
						Thread.Sleep(10);
					}
					catch (UnauthorizedAccessException)
					{
						this.SerialPort_0.Close();
						MessageBox.Show("Port " + text + " sedang digunakan oleh aplikasi lain.\r\nTutup aplikasi lain yang menggunakan port ini.", "Port Busy", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						this.dataviewFaultCodes.Rows.Add(new object[]
						{
							"",
							"",
							"Port COM sedang digunakan"
						});
					}
					catch (Exception ex)
					{
						this.SerialPort_0.Close();
						MessageBox.Show(string.Concat(new string[]
						{
							"Gagal membuka port ",
							text,
							": ",
							ex.Message,
							"\r\nPastikan kabel USB modul terpasang dengan benar."
						}), "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						this.dataviewFaultCodes.Rows.Add(new object[]
						{
							"",
							"",
							"Gagal membuka port COM"
						});
					}
				}
			}
			catch (Exception ex2)
			{
				MessageBox.Show("Error: " + ex2.Message + "\r\nPastikan driver FTDI terinstal dan kabel terhubung.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x06000A37 RID: 2615 RVA: 0x0004D97C File Offset: 0x0004D97C
		private void method_107()
		{
			byte[] array = new byte[]
			{
				254,
				4,
				114,
				140
			};
			byte[] array2 = new byte[]
			{
				114,
				5,
				0,
				240,
				153
			};
			byte[] array3 = new byte[]
			{
				114,
				5,
				96,
				3,
				38
			};
			byte[] array4 = new byte[]
			{
				114,
				5,
				96,
				1,
				40
			};
			try
			{
				this.dataviewFaultCodes.Rows.Clear();
				this.dataviewFaultCodes.Refresh();
				this.Timer_0.Enabled = false;
				if (!this.SerialPort_0.IsOpen)
				{
					this.SerialPort_0.Open();
				}
				this.SerialPort_0.BaudRate = 10400;
				this.SerialPort_0.BreakState = false;
				Thread.Sleep(100);
				this.SerialPort_0.BreakState = true;
				Thread.Sleep(70);
				this.SerialPort_0.BreakState = false;
				Thread.Sleep(5);
				Thread.Sleep(145);
				this.SerialPort_0.Write(array, 0, array.Length);
				Thread.Sleep(30);
				this.SerialPort_0.Write(array2, 0, array2.Length);
				Thread.Sleep(30);
				this.SerialPort_0.DiscardOutBuffer();
				this.SerialPort_0.ReadExisting();
				this.SerialPort_0.Write(array3, 0, array3.Length);
				Thread.Sleep(50);
				this.SerialPort_0.Write(array4, 0, array4.Length);
				Thread.Sleep(50);
				MessageBox.Show("Reset DTC Completed", "RESET DTC");
				Thread.Sleep(1000);
				this.method_110();
				this.SerialPort_0.Close();
				Thread.Sleep(1000);
			}
			catch (Exception)
			{
				this.SerialPort_0.Close();
			}
		}

		// Token: 0x06000A38 RID: 2616 RVA: 0x0004DB38 File Offset: 0x0004DB38
		private void AutoDetectCOMPort()
		{
			try
			{
				string[] portNames = SerialPort.GetPortNames();
				if (portNames.Length == 0)
				{
					this.txtCOMName.Text = "● COM: None";
					this.txtCOMName.ForeColor = Color.FromArgb(230, 100, 100);
				}
				else
				{
					foreach (string text in portNames)
					{
						if (text.StartsWith("COM"))
						{
							this.txtCOMName.Text = "● COM: " + text;
							this.txtCOMName.ForeColor = Color.FromArgb(0, 220, 240);
							return;
						}
					}
					this.txtCOMName.Text = "● COM: " + portNames[0];
					this.txtCOMName.ForeColor = Color.FromArgb(0, 220, 240);
				}
			}
			catch
			{
				this.txtCOMName.Text = "● COM: ?";
				this.txtCOMName.ForeColor = Color.FromArgb(230, 100, 100);
			}
		}

		// Token: 0x04000BC9 RID: 3017
		private byte byte_0;

		// Token: 0x04000BCA RID: 3018
		private string string_9;

		// Token: 0x04000BD4 RID: 3028
		private string string_8;
	}
}
