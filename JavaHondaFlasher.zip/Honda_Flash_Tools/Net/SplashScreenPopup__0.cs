﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000754 RID: 1876
	public partial class SplashScreenPopup__0 : Form
	{
		// Token: 0x06001195 RID: 4501
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x06001196 RID: 4502
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		// Token: 0x06001197 RID: 4503
		[DllImport("Gdi32.dll")]
		private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

		// Token: 0x06001198 RID: 4504 RVA: 0x000803B8 File Offset: 0x000803B8
		public SplashScreenPopup__0()
		{
			this.particleRandom = new Random();
			this.padlockScale = 0.82f;
			base.ClientSize = new Size(500, 300);
			base.FormBorderStyle = FormBorderStyle.None;
			base.StartPosition = FormStartPosition.CenterScreen;
			base.ShowInTaskbar = false;
			this.BackColor = SplashScreenPopup__0.ClrDarkTop;
			this.DoubleBuffered = true;
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.SetRoundedRegion(40);
			this.CreateParticles();
			this.progressTimer = new Timer
			{
				Interval = 15
			};
			this.progressTimer.Tick += this.ProgressTimer_Tick;
			this.progressTimer.Start();
			this.padlockTimer = new Timer
			{
				Interval = 10
			};
			this.padlockTimer.Tick += this.PadlockTimer_Tick;
			this.padlockTimer.Start();
			this.animationTimer = new Timer
			{
				Interval = 16
			};
			this.animationTimer.Tick += delegate(object <p0>, EventArgs <p1>)
			{
				base.Invalidate();
			};
			this.animationTimer.Start();
			base.Paint += this.SplashScreenPopup_Paint;
			base.MouseDown += this.SplashScreenPopup_MouseDown;
			base.Resize += delegate(object <p0>, EventArgs <p1>)
			{
				this.SetRoundedRegion(40);
			};
		}

		// Token: 0x06001199 RID: 4505 RVA: 0x0000B9AD File Offset: 0x0000B9AD
		private void SplashScreenPopup_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				SplashScreenPopup__0.ReleaseCapture();
				SplashScreenPopup__0.SendMessage(base.Handle, 161, 2, 0);
			}
		}

		// Token: 0x0600119A RID: 4506 RVA: 0x00080524 File Offset: 0x00080524
		private void SplashScreenPopup_Paint(object sender, PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.CompositingQuality = CompositingQuality.HighQuality;
			graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
			this.DrawBackground(graphics);
			this.DrawBorder(graphics);
			int cx = base.ClientSize.Width / 2;
			checked
			{
				int num = base.ClientSize.Height / 2 - 20;
				this.DrawProgressRing(graphics, cx, num);
				this.DrawRotatingTechRing(graphics, cx, num);
				this.DrawPadlock4D(graphics, cx, num, this.padlockScale, this.padlockOpenAngle, this.padlockUnlocked, this.padlockGlowIntensity, this.padlockBounceOffset, this.padlockRotation);
				this.DrawPercentage(graphics, cx, num);
				this.DrawLogoText(graphics, cx, num + 110);
				this.DrawParticles(graphics, cx, num);
				this.DrawStatus(graphics);
			}
		}

		// Token: 0x0600119B RID: 4507 RVA: 0x000805F4 File Offset: 0x000805F4
		private void ProgressTimer_Tick(object sender, EventArgs e)
		{
			if (base.IsDisposed || base.Disposing)
			{
				return;
			}
			if (this.progressPercent < 100f)
			{
				this.progressPercent += 2.5f;
				if (this.progressPercent >= 100f)
				{
					this.progressPercent = 100f;
					this.hasReached100 = true;
					this.padlockUnlocked = false;
					this.padlockOpenAngle = 0f;
					this.padlockGlowIntensity = 0f;
					this.padlockBounceOffset = -10f;
					this.padlockScale = 0.82f;
				}
				base.Invalidate();
				return;
			}
			this.progressTimer.Stop();
		}

		// Token: 0x0600119C RID: 4508 RVA: 0x00080698 File Offset: 0x00080698
		private void PadlockTimer_Tick(object sender, EventArgs e)
		{
			if (base.IsDisposed || base.Disposing)
			{
				return;
			}
			this.metallicSweep += 48f;
			if (this.metallicSweep > 360f)
			{
				this.metallicSweep -= 360f;
			}
			this.energyPulse += 0.25f;
			if (!this.hasReached100)
			{
				float num = (float)Environment.TickCount / 1000f;
				this.padlockScale = 0.82f + (float)Math.Sin((double)(num * 3f)) * 0.015f;
				this.padlockRotation = (float)Math.Sin((double)(num * 2.2f)) * 1f;
				this.padlockGlowIntensity = 0.15f;
				this.UpdateParticles();
				base.Invalidate();
				return;
			}
			if (!this.padlockUnlocked)
			{
				if (this.padlockBounceOffset < 0f)
				{
					this.padlockBounceOffset += 3.5f;
					this.padlockScale = 0.82f + Math.Abs(this.padlockBounceOffset) / 55f;
					this.padlockRotation = (float)Math.Sin((double)(this.padlockBounceOffset / 3f)) * 2.5f;
					base.Invalidate();
					return;
				}
				if (this.padlockOpenAngle < 68f)
				{
					this.padlockOpenAngle += 5.5f;
					this.padlockGlowIntensity = Math.Min(1f, this.padlockOpenAngle / 38f);
					this.padlockScale = 0.88f + (float)Math.Sin((double)(this.padlockOpenAngle / 12f)) * 0.035f;
					this.padlockRotation = (float)Math.Sin((double)(this.padlockOpenAngle / 14f)) * 2.2f;
					this.UpdateParticles();
					base.Invalidate();
					return;
				}
				this.padlockUnlocked = true;
				this.padlockGlowIntensity = 1f;
				this.padlockScale = 0.94f;
				this.padlockRotation = 0f;
				base.Invalidate();
				this.CloseSplashAfterUnlockAsync();
			}
		}

		// Token: 0x0600119D RID: 4509 RVA: 0x00080890 File Offset: 0x00080890
		private void CreateParticles()
		{
			this.particles = new Particle__0__0__0[40];
			checked
			{
				for (int i = 0; i < this.particles.Length; i++)
				{
					this.particles[i] = unchecked(new Particle__0__0__0
					{
						X = (float)(this.particleRandom.NextDouble() * 200.0 - 100.0),
						Y = (float)(this.particleRandom.NextDouble() * 180.0 - 90.0),
						VX = (float)(this.particleRandom.NextDouble() * 1.2 - 0.6),
						VY = (float)(this.particleRandom.NextDouble() * 1.2 - 0.6),
						Life = 0f,
						MaxLife = (float)(checked(30 + this.particleRandom.Next(80))),
						Size = 1f + (float)this.particleRandom.NextDouble() * 3f,
						Rotation = (float)this.particleRandom.NextDouble() * 360f
					});
				}
			}
		}

		// Token: 0x0600119E RID: 4510 RVA: 0x000809C0 File Offset: 0x000809C0
		private void UpdateParticles()
		{
			if (!this.hasReached100 || this.particles == null)
			{
				return;
			}
			for (int i = 0; i < this.particles.Length; i = checked(i + 1))
			{
				Particle__0__0__0 particle__0__0__ = this.particles[i];
				particle__0__0__.X += particle__0__0__.VX;
				particle__0__0__.Y += particle__0__0__.VY;
				particle__0__0__.VY -= 0.005f;
				particle__0__0__.Life += 1f;
				particle__0__0__.Rotation += 4f;
				if (particle__0__0__.Life > particle__0__0__.MaxLife)
				{
					particle__0__0__.X = (float)(this.particleRandom.NextDouble() * 80.0 - 40.0);
					particle__0__0__.Y = (float)(this.particleRandom.NextDouble() * 60.0 - 30.0);
					particle__0__0__.VX = (float)(this.particleRandom.NextDouble() * 2.0 - 1.0);
					particle__0__0__.VY = (float)(this.particleRandom.NextDouble() * 2.0 - 1.0);
					particle__0__0__.Life = 0f;
					particle__0__0__.MaxLife = (float)(checked(30 + this.particleRandom.Next(80)));
				}
				this.particles[i] = particle__0__0__;
			}
		}

		// Token: 0x0600119F RID: 4511 RVA: 0x00080B30 File Offset: 0x00080B30
		private void DrawBackground(Graphics g)
		{
			Rectangle clientRectangle = base.ClientRectangle;
			using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(clientRectangle, SplashScreenPopup__0.ClrDarkTop, SplashScreenPopup__0.ClrDarkBottom, LinearGradientMode.Vertical))
			{
				g.FillRectangle(linearGradientBrush, clientRectangle);
			}
			int num = clientRectangle.Width / 2;
			int num2 = clientRectangle.Height / 2;
			int num3 = 160;
			checked
			{
				using (GraphicsPath graphicsPath = new GraphicsPath())
				{
					graphicsPath.AddEllipse(num - num3, num2 - num3, num3 * 2, num3 * 2);
					using (PathGradientBrush pathGradientBrush = new PathGradientBrush(graphicsPath))
					{
						float num4 = unchecked(0.75f + (float)Math.Sin((double)this.energyPulse) * 0.15f);
						pathGradientBrush.CenterColor = Color.FromArgb((int)(unchecked(30f * num4)), SplashScreenPopup__0.ClrNeonCyan);
						pathGradientBrush.SurroundColors = new Color[]
						{
							Color.FromArgb(0, SplashScreenPopup__0.ClrNeonCyan)
						};
						g.FillEllipse(pathGradientBrush, num - num3, num2 - num3, num3 * 2, num3 * 2);
					}
				}
			}
		}

		// Token: 0x060011A0 RID: 4512 RVA: 0x00080C58 File Offset: 0x00080C58
		private void DrawBorder(Graphics g)
		{
			int width = base.ClientSize.Width;
			int height = base.ClientSize.Height;
			if (width <= 10 || height <= 10)
			{
				return;
			}
			Rectangle rect = checked(new Rectangle(3, 3, width - 6, height - 6));
			using (GraphicsPath graphicsPath = this.CreateRoundedRectangle(rect, 30))
			{
				using (Pen pen = new Pen(Color.FromArgb(80, 0, 255, 255), 3f))
				{
					g.DrawPath(pen, graphicsPath);
				}
				using (Pen pen2 = new Pen(SplashScreenPopup__0.ClrNeonCyan, 1.5f))
				{
					g.DrawPath(pen2, graphicsPath);
				}
			}
		}

		// Token: 0x060011A1 RID: 4513 RVA: 0x00080D3C File Offset: 0x00080D3C
		private void DrawProgressRing(Graphics g, int cx, int cy)
		{
			int num = 80;
			checked
			{
				using (Pen pen = new Pen(SplashScreenPopup__0.ClrRingBase, 12f))
				{
					g.DrawEllipse(pen, cx - num, cy - num, num * 2, num * 2);
				}
				float num2 = unchecked(this.progressPercent / 100f * 360f);
				if (num2 <= 0f)
				{
					return;
				}
				using (Pen pen2 = new Pen(Color.FromArgb(80, SplashScreenPopup__0.ClrNeonCyan), 19f))
				{
					pen2.StartCap = LineCap.Round;
					pen2.EndCap = LineCap.Round;
					g.DrawArc(pen2, (float)(cx - num), (float)(cy - num), (float)(num * 2), (float)(num * 2), -90f, num2);
				}
				using (Pen pen3 = new Pen(SplashScreenPopup__0.ClrNeonCyan, 15f))
				{
					pen3.StartCap = LineCap.Round;
					pen3.EndCap = LineCap.Round;
					g.DrawArc(pen3, (float)(cx - num), (float)(cy - num), (float)(num * 2), (float)(num * 2), -90f, num2);
				}
			}
		}

		// Token: 0x060011A2 RID: 4514 RVA: 0x00080E5C File Offset: 0x00080E5C
		private void DrawRotatingTechRing(Graphics g, int cx, int cy)
		{
			int num = 96;
			int num2 = 40;
			float num3 = 8f;
			float num4 = 20f;
			for (int i = 0; i < num2; i = checked(i + 1))
			{
				double num5 = ((double)i * (360.0 / (double)num2) + (double)this.metallicSweep) * 3.141592653589793 / 180.0;
				float num6 = (float)cx + (float)Math.Cos(num5) * ((float)num + num4 / 2f);
				float num7 = (float)cy + (float)Math.Sin(num5) * ((float)num + num4 / 2f);
				float angle = (float)(num5 * 180.0 / 3.141592653589793 + 90.0);
				Matrix transform = g.Transform;
				try
				{
					Matrix matrix = new Matrix();
					matrix.Translate(num6, num7);
					matrix.Rotate(angle);
					matrix.Translate(-num6, -num7);
					g.Transform = matrix;
					int num8;
					int green;
					checked
					{
						num8 = Math.Max(30, 255 - (int)(unchecked((float)i / (float)num2 * 200f)));
						green = Math.Min(255, 200 + (int)(unchecked(55f * (1f - (float)i / (float)num2))));
					}
					using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(new RectangleF(num6 - num3 / 2f, num7 - num4 / 2f, num3, num4), Color.FromArgb(num8, 0, green, 255), Color.FromArgb(Math.Max(0, checked(num8 - 60)), 0, 80, 160), LinearGradientMode.Vertical))
					{
						g.FillRectangle(linearGradientBrush, num6 - num3 / 2f, num7 - num4 / 2f, num3, num4);
					}
					using (Pen pen = new Pen(Color.FromArgb(num8, SplashScreenPopup__0.ClrNeonCyan), 1.2f))
					{
						g.DrawRectangle(pen, num6 - num3 / 2f, num7 - num4 / 2f, num3, num4);
					}
				}
				finally
				{
					g.Transform = transform;
				}
			}
		}

		// Token: 0x060011A3 RID: 4515 RVA: 0x0008109C File Offset: 0x0008109C
		private void DrawPadlock4D(Graphics g, int cx, int cy, float scale, float openAngle, bool unlocked, float glow, float bounce, float rotation)
		{
			if (scale <= 0f)
			{
				return;
			}
			Matrix transform = g.Transform;
			try
			{
				float num = (float)Math.Sin((double)((float)Environment.TickCount / 1000f * 1.2f)) * 0.6f;
				Matrix matrix = new Matrix();
				matrix.Translate((float)cx, (float)cy + bounce * scale);
				matrix.Rotate(rotation + num);
				matrix.Scale(scale, scale);
				checked
				{
					matrix.Translate((float)(0 - cx), (float)(0 - cy));
					g.Transform = matrix;
					int num2 = 84;
					int num3 = 66;
					int num4 = cx - num2 / 2;
					int num5 = cy - num3 / 2 + 10;
				}
			}
			finally
			{
				g.Transform = transform;
			}
		}

		// Token: 0x060011A4 RID: 4516 RVA: 0x0008114C File Offset: 0x0008114C
		private void DrawParticles(Graphics g, int cx, int cy)
		{
			if (!this.hasReached100 || this.particles == null)
			{
				return;
			}
			for (int i = 0; i < this.particles.Length; i = checked(i + 1))
			{
				Particle__0__0__0 particle__0__0__ = this.particles[i];
				float num = 1f - particle__0__0__.Life / particle__0__0__.MaxLife;
				if (num > 0f)
				{
					using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(Math.Max(0, Math.Min(255, checked((int)(unchecked(220f * num))))), SplashScreenPopup__0.ClrNeonCyan)))
					{
						g.FillEllipse(solidBrush, (float)cx + particle__0__0__.X - particle__0__0__.Size, (float)cy + particle__0__0__.Y - particle__0__0__.Size, particle__0__0__.Size * 2f, particle__0__0__.Size * 2f);
					}
				}
			}
		}

		// Token: 0x060011A5 RID: 4517 RVA: 0x0008122C File Offset: 0x0008122C
		private void DrawPercentage(Graphics g, int cx, int cy)
		{
			string text = checked((int)this.progressPercent) + "%";
			using (Font font = new Font("Segoe UI", 22f, FontStyle.Bold))
			{
				SizeF sizeF = g.MeasureString(text, font);
				float num = (float)cx - sizeF.Width / 2f;
				float num2 = (float)cy + 48f;
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(200, 0, 0, 0)))
				{
					g.DrawString(text, font, solidBrush, num + 2f, num2 + 2f);
				}
				using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(new RectangleF(num, num2, sizeF.Width, sizeF.Height), Color.White, SplashScreenPopup__0.ClrNeonCyan, LinearGradientMode.Vertical))
				{
					g.DrawString(text, font, linearGradientBrush, num, num2);
				}
			}
		}

		// Token: 0x060011A6 RID: 4518 RVA: 0x00081338 File Offset: 0x00081338
		private void DrawStatus(Graphics g)
		{
			string text = (!this.hasReached100) ? "INITIALIZING..." : ((!this.padlockUnlocked) ? "SYSTEM READY - UNLOCKING..." : "ACCESS GRANTED");
			Color color = (!this.hasReached100) ? SplashScreenPopup__0.ClrNeonCyan : ((!this.padlockUnlocked) ? SplashScreenPopup__0.ClrNeonOrange : Color.LimeGreen);
			using (Font font = new Font("Segoe UI", 9f, FontStyle.Bold))
			{
				SizeF sizeF = g.MeasureString(text, font);
				float num = ((float)base.ClientSize.Width - sizeF.Width) / 2f;
				float num2 = (float)base.ClientSize.Height - 28f;
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(150, color)))
				{
					g.DrawString(text, font, solidBrush, num + 1f, num2 + 1f);
				}
				using (SolidBrush solidBrush2 = new SolidBrush(color))
				{
					g.DrawString(text, font, solidBrush2, num, num2);
				}
			}
		}

		// Token: 0x060011A7 RID: 4519 RVA: 0x00024C64 File Offset: 0x00024C64
		private GraphicsPath CreateRoundedRectangle(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			checked
			{
				int num = radius * 2;
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x060011A8 RID: 4520 RVA: 0x00081470 File Offset: 0x00081470
		private void SetRoundedRegion(int radius)
		{
			try
			{
				IntPtr hrgn = SplashScreenPopup__0.CreateRoundRectRgn(0, 0, base.Width, base.Height, radius, radius);
				base.Region = Region.FromHrgn(hrgn);
			}
			catch
			{
			}
		}

		// Token: 0x060011A9 RID: 4521 RVA: 0x000814B4 File Offset: 0x000814B4
		private async void CloseSplashAfterUnlockAsync()
		{
			if (!this.closingScheduled)
			{
				this.closingScheduled = true;
				try
				{
					await Task.Delay(800);
					if (!base.IsDisposed && !base.Disposing)
					{
						if (base.InvokeRequired)
						{
							base.BeginInvoke(new MethodInvoker(base.Close));
						}
						else
						{
							base.Close();
						}
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x060011AB RID: 4523 RVA: 0x00081594 File Offset: 0x00081594
		// Note: this type is marked as 'beforefieldinit'.
		static SplashScreenPopup__0()
		{
			SplashScreenPopup__0.ClrDarkTop = Color.FromArgb(10, 15, 20);
			SplashScreenPopup__0.ClrDarkBottom = Color.FromArgb(20, 25, 30);
			SplashScreenPopup__0.ClrRingBase = Color.FromArgb(30, 38, 55);
		}

		// Token: 0x060011AD RID: 4525 RVA: 0x000815FC File Offset: 0x000815FC
		private void DrawLogoText(Graphics g, int cx, int yPos)
		{
			using (Font font = new Font("Segoe UI", 28f, FontStyle.Bold))
			{
				using (Font font2 = new Font("Segoe UI", 24f, FontStyle.Bold))
				{
					SizeF sizeF = g.MeasureString(this.textDepploy, font);
					float x = (float)cx - sizeF.Width / 2f;
					SizeF sizeF2;
					checked
					{
						for (int i = 4; i >= 1; i--)
						{
							using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(30 * i, SplashScreenPopup__0.ClrNeonCyan)))
							{
								g.DrawString(this.textDepploy, font, solidBrush, x, (float)yPos);
							}
						}
						using (SolidBrush solidBrush2 = new SolidBrush(Color.White))
						{
							g.DrawString(this.textDepploy, font, solidBrush2, x, (float)yPos);
						}
						sizeF2 = g.MeasureString(this.textMapTuning, font2);
					}
					float x2 = (float)cx - sizeF2.Width / 2f;
					float y = (float)yPos + sizeF.Height - 10f;
					checked
					{
						for (int j = 4; j >= 1; j--)
						{
							using (SolidBrush solidBrush3 = new SolidBrush(Color.FromArgb(30 * j, SplashScreenPopup__0.ClrNeonOrange)))
							{
								g.DrawString(this.textMapTuning, font2, solidBrush3, x2, y);
							}
						}
						using (SolidBrush solidBrush4 = new SolidBrush(SplashScreenPopup__0.ClrNeonOrange))
						{
							g.DrawString(this.textMapTuning, font2, solidBrush4, x2, y);
						}
					}
				}
			}
		}

		// Token: 0x04001850 RID: 6224
		private Random particleRandom;

		// Token: 0x04001855 RID: 6229
		private float progressPercent;

		// Token: 0x04001856 RID: 6230
		private bool hasReached100;

		// Token: 0x04001857 RID: 6231
		private bool padlockUnlocked;

		// Token: 0x04001858 RID: 6232
		private bool closingScheduled;

		// Token: 0x04001859 RID: 6233
		private float padlockScale;

		// Token: 0x0400185A RID: 6234
		private float padlockOpenAngle;

		// Token: 0x0400185B RID: 6235
		private float padlockGlowIntensity;

		// Token: 0x0400185C RID: 6236
		private float padlockBounceOffset;

		// Token: 0x0400185D RID: 6237
		private float padlockRotation;

		// Token: 0x0400185E RID: 6238
		private float metallicSweep;

		// Token: 0x0400185F RID: 6239
		private float energyPulse;

		// Token: 0x04001860 RID: 6240
		private int jarakDariTengah;

		// Token: 0x04001861 RID: 6241
		private Particle__0__0__0[] particles;

		// Token: 0x04001862 RID: 6242
		private float spinnerAngle;

		// Token: 0x04001863 RID: 6243
		private static readonly Color ClrDarkTop;

		// Token: 0x04001864 RID: 6244
		private static readonly Color ClrDarkBottom;

		// Token: 0x04001865 RID: 6245
		private static readonly Color ClrRingBase;

		// Token: 0x04001866 RID: 6246
		private static readonly Color ClrNeonCyan = Color.FromArgb(0, 255, 255);

		// Token: 0x04001867 RID: 6247
		private static readonly Color ClrNeonOrange = Color.FromArgb(255, 140, 0);

		// Token: 0x04001868 RID: 6248
		private readonly string textDepploy = "depploy";

		// Token: 0x04001869 RID: 6249
		private readonly string textMapTuning = "map tuning";
	}
}
