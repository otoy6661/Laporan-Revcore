﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200054F RID: 1359
	public partial class CustomMessageBox__0 : global::System.Windows.Forms.Form
	{
	}
}
