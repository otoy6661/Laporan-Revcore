﻿using System;
using System.Collections.Generic;
using System.IO.Ports;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000752 RID: 1874
	public class GClass1__0
	{
		// Token: 0x170000AD RID: 173
		// (get) Token: 0x0600118E RID: 4494 RVA: 0x0000B98B File Offset: 0x0000B98B
		// (set) Token: 0x0600118F RID: 4495 RVA: 0x0000B993 File Offset: 0x0000B993
		public string String_0 { get; set; }

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x06001190 RID: 4496 RVA: 0x0000B99C File Offset: 0x0000B99C
		// (set) Token: 0x06001191 RID: 4497 RVA: 0x0000B9A4 File Offset: 0x0000B9A4
		public string String_1 { get; set; }

		// Token: 0x06001192 RID: 4498 RVA: 0x00080320 File Offset: 0x00080320
		public static List<GClass1__0> smethod_0()
		{
			List<GClass1__0> list = new List<GClass1__0>();
			foreach (string text in SerialPort.GetPortNames())
			{
				list.Add(new GClass1__0
				{
					String_0 = text,
					String_1 = "USB\\VID_0403+PID_6001+B5" + text
				});
			}
			return list;
		}
	}
}
