﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000554 RID: 1364
	public partial class CustomMessageBox__3 : Form
	{
		// Token: 0x06000D8D RID: 3469 RVA: 0x00067334 File Offset: 0x00067334
		public CustomMessageBox__3()
		{
			base.FormBorderStyle = FormBorderStyle.None;
			base.StartPosition = FormStartPosition.CenterScreen;
			this.BackColor = CustomMessageBox__3.BgDark;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.ShowInTaskbar = false;
			base.Width = 440;
			base.Height = 340;
			base.TopMost = true;
			base.Padding = new Padding(2);
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		}

		// Token: 0x06000D8E RID: 3470 RVA: 0x000673B4 File Offset: 0x000673B4
		public static DialogResult Show(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
		{
			DialogResult dialogResult;
			using (CustomMessageBox__3 customMessageBox__ = new CustomMessageBox__3())
			{
				customMessageBox__.SetupDialog(message, title, buttons, icon);
				customMessageBox__.ShowDialog();
				dialogResult = CustomMessageBox__3._dialogResult;
			}
			return dialogResult;
		}

		// Token: 0x06000D8F RID: 3471 RVA: 0x000673FC File Offset: 0x000673FC
		private void SetupDialog(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
		{
			base.Controls.Clear();
			this.contentPanel = new RoundedPanel();
			this.contentPanel.Dock = DockStyle.Fill;
			this.contentPanel.CornerRadius = this._cornerRadius;
			this.contentPanel.BorderColor = CustomMessageBox__3.Cyan;
			this.contentPanel.BorderWidth = 1f;
			this.contentPanel.InnerBackColor = CustomMessageBox__3.BgPanel;
			this.contentPanel.Padding = new Padding(20);
			base.Controls.Add(this.contentPanel);
			PictureBox pictureBox = new PictureBox
			{
				Location = new Point(18, 22),
				Size = new Size(28, 28),
				SizeMode = PictureBoxSizeMode.StretchImage,
				BackColor = Color.Transparent
			};
			if (icon == MessageBoxIcon.Asterisk || icon == MessageBoxIcon.Asterisk)
			{
				pictureBox.Image = SystemIcons.Information.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Exclamation || icon == MessageBoxIcon.Exclamation)
			{
				pictureBox.Image = SystemIcons.Warning.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Hand || icon == MessageBoxIcon.Hand || icon == MessageBoxIcon.Hand)
			{
				pictureBox.Image = SystemIcons.Error.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Question)
			{
				pictureBox.Image = SystemIcons.Question.ToBitmap();
			}
			this.contentPanel.Controls.Add(pictureBox);
			this.titleLabel = new Label
			{
				Text = title,
				Font = new Font("Segoe UI", 12f, FontStyle.Bold),
				ForeColor = CustomMessageBox__3.TextTitle,
				BackColor = Color.Transparent,
				Location = new Point(56, 18),
				AutoSize = true
			};
			this.contentPanel.Controls.Add(this.titleLabel);
			Panel value = new Panel
			{
				BackColor = CustomMessageBox__3.CyanDark,
				Location = new Point(18, 50),
				Size = new Size(base.Width - 36, 1),
				Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
			};
			this.contentPanel.Controls.Add(value);
			int left = this.contentPanel.Padding.Left;
			int right = this.contentPanel.Padding.Right;
			int bottom = this.contentPanel.Padding.Bottom;
			int num = 90;
			int num2 = 34;
			int num3 = 10;
			int num4 = 64;
			int height = base.Height - num4 - num2 - bottom - 40;
			Label value2 = new Label
			{
				Text = message,
				Font = new Font("Segoe UI", 9.5f),
				ForeColor = CustomMessageBox__3.TextFore,
				BackColor = Color.Transparent,
				Location = new Point(left, num4),
				Width = base.Width - left - right - 8,
				Height = height,
				AutoSize = false,
				Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
			};
			this.contentPanel.Controls.Add(value2);
			int width = this.contentPanel.ClientSize.Width;
			int height2 = this.contentPanel.ClientSize.Height;
			int num5 = width - left - right;
			int num6 = 0;
			if (buttons == MessageBoxButtons.OK)
			{
				num6 = 1;
			}
			else if (buttons == MessageBoxButtons.OKCancel || buttons == MessageBoxButtons.YesNo)
			{
				num6 = 2;
			}
			else if (buttons == MessageBoxButtons.YesNoCancel)
			{
				num6 = 3;
			}
			int num7 = num6 * num + (num6 - 1) * num3;
			int num8 = left + (num5 - num7) / 2;
			int top = height2 - num2 - bottom;
			if (buttons == MessageBoxButtons.OK)
			{
				this.CreateButton("OK", num8, top, num, num2, DialogResult.OK);
				return;
			}
			if (buttons == MessageBoxButtons.OKCancel)
			{
				this.CreateButton("OK", num8, top, num, num2, DialogResult.OK);
				this.CreateButton("Cancel", num8 + num + num3, top, num, num2, DialogResult.Cancel);
				return;
			}
			if (buttons == MessageBoxButtons.YesNo)
			{
				this.CreateButton("Yes", num8, top, num, num2, DialogResult.Yes);
				this.CreateButton("No", num8 + num + num3, top, num, num2, DialogResult.No);
				return;
			}
			if (buttons == MessageBoxButtons.YesNoCancel)
			{
				this.CreateButton("Yes", num8, top, num, num2, DialogResult.Yes);
				this.CreateButton("No", num8 + num + num3, top, num, num2, DialogResult.No);
				this.CreateButton("Cancel", num8 + (num + num3) * 2, top, num, num2, DialogResult.Cancel);
			}
		}

		// Token: 0x06000D90 RID: 3472 RVA: 0x0006782C File Offset: 0x0006782C
		private void CreateButton(string text, int left, int top, int width, int height, DialogResult result)
		{
			RoundedButton roundedButton = new RoundedButton
			{
				Text = text,
				Location = new Point(left, top),
				Size = new Size(width, height),
				Font = new Font("Segoe UI", 9f, FontStyle.Bold),
				ForeColor = CustomMessageBox__3.Cyan,
				BackColor = CustomMessageBox__3.BgButton,
				CornerRadius = 8,
				BorderColor = CustomMessageBox__3.Cyan,
				BorderWidth = 1f,
				HoverBackColor = CustomMessageBox__3.BgButtonHover,
				Cursor = Cursors.Hand
			};
			roundedButton.Click += delegate(object sender, EventArgs e)
			{
				CustomMessageBox__3._dialogResult = result;
				this.Close();
			};
			this.contentPanel.Controls.Add(roundedButton);
		}

		// Token: 0x06000D91 RID: 3473 RVA: 0x000678FC File Offset: 0x000678FC
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.Half;
			graphics.Clear(this.BackColor);
			using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(new RectangleF(1.5f, 1.5f, (float)base.Width - 3f, (float)base.Height - 3f), this._cornerRadius))
			{
				using (Pen pen = new Pen(CustomMessageBox__3.Cyan, 2f))
				{
					pen.Alignment = PenAlignment.Center;
					pen.LineJoin = LineJoin.Round;
					graphics.DrawPath(pen, graphicsPath);
				}
			}
		}

		// Token: 0x06000D92 RID: 3474 RVA: 0x00009747 File Offset: 0x00009747
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			this.UpdateFormRegion();
		}

		// Token: 0x06000D93 RID: 3475 RVA: 0x00009756 File Offset: 0x00009756
		protected override void OnMouseDown(MouseEventArgs e)
		{
			base.OnMouseDown(e);
			if (e.Button == MouseButtons.Left)
			{
				CustomMessageBox__3.ReleaseCapture();
				CustomMessageBox__3.SendMessage(base.Handle, 161, 2, 0);
			}
		}

		// Token: 0x06000D94 RID: 3476
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x06000D95 RID: 3477
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		// Token: 0x06000D97 RID: 3479 RVA: 0x00009785 File Offset: 0x00009785
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.UpdateFormRegion();
			base.Invalidate();
		}

		// Token: 0x06000D98 RID: 3480 RVA: 0x0000979A File Offset: 0x0000979A
		private void UpdateFormRegion()
		{
			if (base.Width <= 0 || base.Height <= 0)
			{
				return;
			}
			RoundedHelper.SetRegion(this, this._cornerRadius);
		}

		// Token: 0x040011FE RID: 4606
		private static DialogResult _dialogResult;

		// Token: 0x040011FF RID: 4607
		private const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x04001200 RID: 4608
		private const int HT_CAPTION = 2;

		// Token: 0x04001201 RID: 4609
		private Label titleLabel;

		// Token: 0x04001202 RID: 4610
		private static readonly Color Cyan = Color.FromArgb(0, 255, 230);

		// Token: 0x04001203 RID: 4611
		private static readonly Color CyanDark = Color.FromArgb(0, 145, 135);

		// Token: 0x04001204 RID: 4612
		private static readonly Color BgDark = Color.FromArgb(18, 23, 29);

		// Token: 0x04001205 RID: 4613
		private static readonly Color BgPanel = Color.FromArgb(22, 28, 35);

		// Token: 0x04001206 RID: 4614
		private static readonly Color BgButton = Color.FromArgb(32, 40, 47);

		// Token: 0x04001207 RID: 4615
		private static readonly Color BgButtonHover = Color.FromArgb(45, 60, 70);

		// Token: 0x04001208 RID: 4616
		private static readonly Color TextFore = Color.FromArgb(235, 240, 245);

		// Token: 0x04001209 RID: 4617
		private static readonly Color TextTitle = Color.FromArgb(255, 215, 0);

		// Token: 0x0400120A RID: 4618
		private RoundedPanel contentPanel;

		// Token: 0x0400120B RID: 4619
		private int _cornerRadius = 14;
	}
}
