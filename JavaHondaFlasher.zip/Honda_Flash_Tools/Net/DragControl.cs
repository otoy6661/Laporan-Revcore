﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000349 RID: 841
	public class DragControl
	{
		// Token: 0x17000026 RID: 38
		// (get) Token: 0x06000B43 RID: 2883 RVA: 0x000085D5 File Offset: 0x000085D5
		// (set) Token: 0x06000B44 RID: 2884 RVA: 0x00050ABC File Offset: 0x00050ABC
		public Control SeleControl
		{
			get
			{
				return this.control;
			}
			set
			{
				this.control = value;
				if (this.control != null)
				{
					this.control.MouseDown += this.Control_MouseDown;
					this.control.MouseMove += this.Control_MouseMove;
					this.control.MouseUp += this.Control_MouseUp;
				}
			}
		}

		// Token: 0x06000B45 RID: 2885 RVA: 0x000085DD File Offset: 0x000085DD
		private void Control_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.isDragging = true;
				this.startPoint = e.Location;
			}
		}

		// Token: 0x06000B46 RID: 2886 RVA: 0x00050B20 File Offset: 0x00050B20
		private void Control_MouseMove(object sender, MouseEventArgs e)
		{
			if (this.isDragging)
			{
				Form form = this.control.FindForm();
				if (form != null)
				{
					form.Location = new Point(form.Location.X + (e.X - this.startPoint.X), form.Location.Y + (e.Y - this.startPoint.Y));
				}
			}
		}

		// Token: 0x06000B47 RID: 2887 RVA: 0x000085FF File Offset: 0x000085FF
		private void Control_MouseUp(object sender, MouseEventArgs e)
		{
			this.isDragging = false;
		}

		// Token: 0x04000C9E RID: 3230
		private Control control;

		// Token: 0x04000C9F RID: 3231
		private bool isDragging;

		// Token: 0x04000CA0 RID: 3232
		private Point startPoint;
	}
}
