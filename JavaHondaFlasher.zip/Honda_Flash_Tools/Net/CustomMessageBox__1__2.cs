﻿using System;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200074F RID: 1871
	public static class CustomMessageBox__1__2
	{
		// Token: 0x0600117B RID: 4475 RVA: 0x000802A8 File Offset: 0x000802A8
		public static void Show(string text, string caption, MsgBoxStyle__0 style, MsgBoxStyle__0 icon)
		{
			MessageBoxButtons buttons = MessageBoxButtons.OK;
			MessageBoxIcon icon2 = MessageBoxIcon.None;
			switch (style)
			{
			case MsgBoxStyle__0.OkOnly:
				buttons = MessageBoxButtons.OK;
				break;
			case MsgBoxStyle__0.OkCancel:
				buttons = MessageBoxButtons.OKCancel;
				break;
			case MsgBoxStyle__0.YesNoCancel:
				buttons = MessageBoxButtons.YesNoCancel;
				break;
			case MsgBoxStyle__0.YesNo:
				buttons = MessageBoxButtons.YesNo;
				break;
			}
			if ((icon & MsgBoxStyle__0.Information) == MsgBoxStyle__0.Information)
			{
				icon2 = MessageBoxIcon.Asterisk;
			}
			else if ((icon & MsgBoxStyle__0.Warning) == MsgBoxStyle__0.Warning)
			{
				icon2 = MessageBoxIcon.Exclamation;
			}
			else if ((icon & MsgBoxStyle__0.Critical) == MsgBoxStyle__0.Critical)
			{
				icon2 = MessageBoxIcon.Hand;
			}
			else if ((icon & MsgBoxStyle__0.Question) == MsgBoxStyle__0.Question)
			{
				icon2 = MessageBoxIcon.Question;
			}
			MessageBox.Show(text, caption, buttons, icon2);
		}

		// Token: 0x0600117C RID: 4476 RVA: 0x0000B8F8 File Offset: 0x0000B8F8
		public static void Show(string text, string caption, MsgBoxStyle__0 style)
		{
			CustomMessageBox__1__2.Show(text, caption, style, MsgBoxStyle__0.OkOnly);
		}

		// Token: 0x04001839 RID: 6201
		public const MsgBoxStyle__0 OK = MsgBoxStyle__0.OkOnly;

		// Token: 0x0400183A RID: 6202
		public const MsgBoxStyle__0 Information = MsgBoxStyle__0.Information;

		// Token: 0x0400183B RID: 6203
		public const MsgBoxStyle__0 Warning = MsgBoxStyle__0.Warning;

		// Token: 0x0400183C RID: 6204
		public const MsgBoxStyle__0 Critical = MsgBoxStyle__0.Critical;

		// Token: 0x0400183D RID: 6205
		public const MsgBoxStyle__0 Question = MsgBoxStyle__0.Question;

		// Token: 0x0400183E RID: 6206
		public const MsgBoxStyle__0 YesNo = MsgBoxStyle__0.YesNo;
	}
}
