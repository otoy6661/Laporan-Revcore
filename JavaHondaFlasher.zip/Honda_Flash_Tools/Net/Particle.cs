﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000713 RID: 1811
	public struct Particle
	{
		// Token: 0x040016ED RID: 5869
		public float X;

		// Token: 0x040016EE RID: 5870
		public float Y;

		// Token: 0x040016EF RID: 5871
		public float VX;

		// Token: 0x040016F0 RID: 5872
		public float VY;

		// Token: 0x040016F1 RID: 5873
		public float Life;

		// Token: 0x040016F2 RID: 5874
		public float MaxLife;

		// Token: 0x040016F3 RID: 5875
		public float Size;

		// Token: 0x040016F4 RID: 5876
		public float Rotation;
	}
}
