﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000750 RID: 1872
	public enum CustomMessageBoxIcon__1__0
	{
		// Token: 0x04001840 RID: 6208
		None,
		// Token: 0x04001841 RID: 6209
		Information = 64,
		// Token: 0x04001842 RID: 6210
		Warning = 48,
		// Token: 0x04001843 RID: 6211
		Error = 16,
		// Token: 0x04001844 RID: 6212
		Success = 64,
		// Token: 0x04001845 RID: 6213
		Question = 32
	}
}
