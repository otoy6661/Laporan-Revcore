﻿using System;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020001F4 RID: 500
	internal static class Program
	{
		// Token: 0x06000A14 RID: 2580 RVA: 0x00007C2D File Offset: 0x00007C2D
		[STAThread]
		private static void Main(string[] args)
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new FormMain());
		}
	}
}
