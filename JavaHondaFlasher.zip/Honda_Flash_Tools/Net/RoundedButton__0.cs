﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000690 RID: 1680
	public class RoundedButton__0 : Button
	{
		// Token: 0x17000070 RID: 112
		// (get) Token: 0x06001002 RID: 4098 RVA: 0x0000ADFB File Offset: 0x0000ADFB
		// (set) Token: 0x06001003 RID: 4099 RVA: 0x0000AE03 File Offset: 0x0000AE03
		public int CornerRadius
		{
			get
			{
				return this._cornerRadius;
			}
			set
			{
				this._cornerRadius = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x06001004 RID: 4100 RVA: 0x0000AE12 File Offset: 0x0000AE12
		// (set) Token: 0x06001005 RID: 4101 RVA: 0x0000AE1A File Offset: 0x0000AE1A
		public Color BorderColor
		{
			get
			{
				return this._borderColor;
			}
			set
			{
				this._borderColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x06001006 RID: 4102 RVA: 0x0000AE29 File Offset: 0x0000AE29
		// (set) Token: 0x06001007 RID: 4103 RVA: 0x0000AE31 File Offset: 0x0000AE31
		public Color HoverBackColor
		{
			get
			{
				return this._hoverBackColor;
			}
			set
			{
				this._hoverBackColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x06001008 RID: 4104 RVA: 0x0000AE40 File Offset: 0x0000AE40
		// (set) Token: 0x06001009 RID: 4105 RVA: 0x0000AE48 File Offset: 0x0000AE48
		public Color DownBackColor
		{
			get
			{
				return this._downBackColor;
			}
			set
			{
				this._downBackColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x0600100A RID: 4106 RVA: 0x000749F0 File Offset: 0x000749F0
		public RoundedButton__0()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.FlatStyle = FlatStyle.Flat;
			base.FlatAppearance.BorderSize = 0;
			this.BackColor = Color.Transparent;
			base.UseVisualStyleBackColor = false;
			this.Cursor = Cursors.Hand;
		}

		// Token: 0x0600100B RID: 4107 RVA: 0x00074A88 File Offset: 0x00074A88
		private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = radius * 2;
			if (num > rect.Width)
			{
				num = rect.Width;
			}
			if (num > rect.Height)
			{
				num = rect.Height;
			}
			graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x0600100C RID: 4108 RVA: 0x00074B50 File Offset: 0x00074B50
		protected override void OnPaint(PaintEventArgs e)
		{
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			e.Graphics.Clear((base.Parent != null) ? base.Parent.BackColor : Color.Black);
			Rectangle rect = new Rectangle(0, 0, base.Width - 1, base.Height - 1);
			Color color = this._normalBackColor;
			if (Control.MouseButtons == MouseButtons.Left && base.ClientRectangle.Contains(base.PointToClient(Control.MousePosition)))
			{
				color = this._downBackColor;
			}
			else if (base.ClientRectangle.Contains(base.PointToClient(Control.MousePosition)))
			{
				color = this._hoverBackColor;
			}
			using (GraphicsPath roundedPath = this.GetRoundedPath(rect, this._cornerRadius))
			{
				using (SolidBrush solidBrush = new SolidBrush(color))
				{
					e.Graphics.FillPath(solidBrush, roundedPath);
				}
				using (Pen pen = new Pen(this._borderColor, 1.5f))
				{
					e.Graphics.DrawPath(pen, roundedPath);
				}
			}
			TextRenderer.DrawText(e.Graphics, this.Text, this.Font, base.ClientRectangle, this.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
		}

		// Token: 0x0600100D RID: 4109 RVA: 0x00074CC4 File Offset: 0x00074CC4
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			using (GraphicsPath roundedPath = this.GetRoundedPath(new Rectangle(0, 0, base.Width, base.Height), this._cornerRadius))
			{
				base.Region = new Region(roundedPath);
			}
		}

		// Token: 0x04001550 RID: 5456
		private int _cornerRadius = 12;

		// Token: 0x04001551 RID: 5457
		private Color _borderColor = Color.FromArgb(0, 255, 100);

		// Token: 0x04001552 RID: 5458
		private Color _hoverBackColor = Color.FromArgb(40, 60, 45);

		// Token: 0x04001553 RID: 5459
		private Color _downBackColor = Color.FromArgb(50, 75, 55);

		// Token: 0x04001554 RID: 5460
		private Color _normalBackColor = Color.Transparent;
	}
}
