﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using LicenseShared;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000718 RID: 1816
	public partial class ActivationForm : Form
	{
		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06001082 RID: 4226 RVA: 0x0000B2CD File Offset: 0x0000B2CD
		// (set) Token: 0x06001083 RID: 4227 RVA: 0x0000B2D5 File Offset: 0x0000B2D5
		public bool ActivatedSuccessfully { get; private set; }

		// Token: 0x06001084 RID: 4228 RVA: 0x00077B68 File Offset: 0x00077B68
		public ActivationForm()
		{
			this._loadedLicPath = "";
			this.InitializeUI();
			try
			{
				this.txtHardwareID.Text = LicenseShared.HardwareIdProvider.GetHardwareId();
			}
			catch
			{
				this.txtHardwareID.Text = "ERROR-GETTING-HARDWARE-ID";
			}
		}

		// Token: 0x06001085 RID: 4229 RVA: 0x00077BC4 File Offset: 0x00077BC4
		private void InitializeUI()
		{
			this.Text = "Honda Flash Tools - Activation";
			base.ClientSize = new Size(620, 560);
			base.FormBorderStyle = FormBorderStyle.None;
			base.StartPosition = FormStartPosition.CenterScreen;
			this.BackColor = ActivationForm.ClrDarkTop;
			this.ForeColor = ActivationForm.ClrText;
			this.Font = new Font("Segoe UI", 9f);
			this.DoubleBuffered = true;
			base.Padding = new Padding(2);
			Panel panel = new Panel();
			panel.Name = "pnlBorder";
			panel.Location = new Point(0, 0);
			panel.Size = new Size(base.ClientSize.Width, base.ClientSize.Height);
			panel.BackColor = ActivationForm.ClrAqua;
			panel.Padding = new Padding(2);
			base.Controls.Add(panel);
			Panel panel2 = new Panel();
			panel2.Name = "pnlMain";
			panel2.Dock = DockStyle.Fill;
			panel2.BackColor = ActivationForm.ClrDarkTop;
			panel.Controls.Add(panel2);
			Panel panel3 = new Panel();
			panel3.Name = "TitleBar";
			panel3.BackColor = Color.Transparent;
			panel3.Location = new Point(0, 0);
			panel3.Size = new Size(panel2.Width, 44);
			panel3.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			panel3.MouseDown += this.DragForm;
			panel2.Controls.Add(panel3);
			Label label = new Label();
			label.Text = "\ud83d\udd12  ACTIVATION";
			label.Font = new Font("Segoe UI", 11f, FontStyle.Bold);
			label.ForeColor = ActivationForm.ClrAqua;
			label.BackColor = Color.Transparent;
			label.AutoSize = false;
			label.TextAlign = ContentAlignment.MiddleLeft;
			label.Location = new Point(20, 0);
			label.Size = new Size(300, 44);
			label.MouseDown += this.DragForm;
			panel3.Controls.Add(label);
			this.btnCloseX = new Button();
			this.btnCloseX.Text = "✕";
			this.btnCloseX.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
			this.btnCloseX.ForeColor = ActivationForm.ClrTextDim;
			this.btnCloseX.BackColor = Color.Transparent;
			this.btnCloseX.FlatStyle = FlatStyle.Flat;
			this.btnCloseX.Location = new Point(panel3.Width - 42, 6);
			this.btnCloseX.Size = new Size(34, 32);
			this.btnCloseX.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.btnCloseX.Cursor = Cursors.Hand;
			this.btnCloseX.FlatAppearance.BorderSize = 0;
			this.btnCloseX.FlatAppearance.MouseOverBackColor = Color.FromArgb(80, 255, 80, 80);
			this.btnCloseX.Click += delegate(object <p0>, EventArgs <p1>)
			{
				base.DialogResult = DialogResult.Cancel;
				base.Close();
			};
			panel3.Controls.Add(this.btnCloseX);
			Label label2 = new Label();
			label2.Text = "ACTIVATION REQUIRED";
			label2.Font = new Font("Segoe UI", 18f, FontStyle.Bold);
			label2.ForeColor = ActivationForm.ClrAqua;
			label2.BackColor = Color.Transparent;
			label2.AutoSize = false;
			label2.TextAlign = ContentAlignment.MiddleCenter;
			label2.Location = new Point(0, 55);
			label2.Size = new Size(panel2.Width, 34);
			label2.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			panel2.Controls.Add(label2);
			Label label3 = new Label();
			label3.Text = "Aplikasi ini membutuhkan license untuk digunakan";
			label3.Font = new Font("Segoe UI", 9f, FontStyle.Italic);
			label3.ForeColor = ActivationForm.ClrTextDim;
			label3.BackColor = Color.Transparent;
			label3.AutoSize = false;
			label3.TextAlign = ContentAlignment.MiddleCenter;
			label3.Location = new Point(0, 90);
			label3.Size = new Size(panel2.Width, 20);
			label3.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			panel2.Controls.Add(label3);
			GroupBox groupBox = new GroupBox();
			groupBox.Text = "  Hardware ID (PC Ini)  ";
			groupBox.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
			groupBox.ForeColor = ActivationForm.ClrAqua;
			groupBox.BackColor = ActivationForm.ClrPanel;
			groupBox.Location = new Point(25, 125);
			groupBox.Size = new Size(570, 110);
			panel2.Controls.Add(groupBox);
			Label label4 = new Label();
			label4.Text = "Kirim Hardware ID ini ke vendor untuk mendapatkan license.";
			label4.Font = new Font("Segoe UI", 8.5f);
			label4.ForeColor = ActivationForm.ClrTextDim;
			label4.BackColor = Color.Transparent;
			label4.AutoSize = false;
			label4.Location = new Point(15, 25);
			label4.Size = new Size(540, 20);
			groupBox.Controls.Add(label4);
			this.txtHardwareID = new TextBox();
			this.txtHardwareID.BackColor = ActivationForm.ClrPanelAlt;
			this.txtHardwareID.ForeColor = ActivationForm.ClrAqua;
			this.txtHardwareID.BorderStyle = BorderStyle.FixedSingle;
			this.txtHardwareID.Font = new Font("Consolas", 9.5f, FontStyle.Bold);
			this.txtHardwareID.ReadOnly = true;
			this.txtHardwareID.Location = new Point(15, 52);
			this.txtHardwareID.Size = new Size(460, 26);
			this.txtHardwareID.TextAlign = HorizontalAlignment.Center;
			groupBox.Controls.Add(this.txtHardwareID);
			this.btnCopyHW = new Button();
			this.btnCopyHW.Text = "\ud83d\udccb COPY";
			this.btnCopyHW.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
			this.btnCopyHW.BackColor = ActivationForm.ClrAquaDim;
			this.btnCopyHW.ForeColor = Color.White;
			this.btnCopyHW.FlatStyle = FlatStyle.Flat;
			this.btnCopyHW.Location = new Point(485, 51);
			this.btnCopyHW.Size = new Size(70, 28);
			this.btnCopyHW.Cursor = Cursors.Hand;
			this.btnCopyHW.FlatAppearance.BorderColor = ActivationForm.ClrAqua;
			this.btnCopyHW.Click += delegate(object <p0>, EventArgs <p1>)
			{
				try
				{
					if (!string.IsNullOrEmpty(this.txtHardwareID.Text))
					{
						Clipboard.SetText(this.txtHardwareID.Text);
						this.SetStatus("✔ Hardware ID copied to clipboard", ActivationForm.ClrGreen);
					}
				}
				catch (Exception ex)
				{
					this.SetStatus("✘ Clipboard error: " + ex.Message, ActivationForm.ClrRed);
				}
			};
			groupBox.Controls.Add(this.btnCopyHW);
			GroupBox groupBox2 = new GroupBox();
			groupBox2.Text = "  Import File License (.lic)  ";
			groupBox2.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
			groupBox2.ForeColor = ActivationForm.ClrAqua;
			groupBox2.BackColor = ActivationForm.ClrPanel;
			groupBox2.Location = new Point(25, 250);
			groupBox2.Size = new Size(570, 140);
			panel2.Controls.Add(groupBox2);
			this.btnImport = new Button();
			this.btnImport.Text = "\ud83d\udcc1  IMPORT FILE .LIC";
			this.btnImport.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
			this.btnImport.BackColor = ActivationForm.ClrAquaDim;
			this.btnImport.ForeColor = Color.White;
			this.btnImport.FlatStyle = FlatStyle.Flat;
			this.btnImport.Location = new Point(15, 30);
			this.btnImport.Size = new Size(540, 44);
			this.btnImport.Cursor = Cursors.Hand;
			this.btnImport.FlatAppearance.BorderColor = ActivationForm.ClrAqua;
			this.btnImport.Click += this.BtnImport_Click;
			groupBox2.Controls.Add(this.btnImport);
			Label label5 = new Label();
			label5.Text = "File .lic Anda dapatkan dari vendor setelah mengirim Hardware ID di atas.";
			label5.Font = new Font("Segoe UI", 8.5f);
			label5.ForeColor = ActivationForm.ClrTextDim;
			label5.BackColor = Color.Transparent;
			label5.AutoSize = false;
			label5.TextAlign = ContentAlignment.MiddleCenter;
			label5.Location = new Point(15, 85);
			label5.Size = new Size(540, 40);
			groupBox2.Controls.Add(label5);
			this.lblStatus = new Label();
			this.lblStatus.Text = "Status: menunggu file license...";
			this.lblStatus.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
			this.lblStatus.ForeColor = ActivationForm.ClrTextDim;
			this.lblStatus.BackColor = Color.Transparent;
			this.lblStatus.AutoSize = false;
			this.lblStatus.TextAlign = ContentAlignment.MiddleCenter;
			this.lblStatus.Location = new Point(25, 405);
			this.lblStatus.Size = new Size(570, 22);
			panel2.Controls.Add(this.lblStatus);
			this.btnActivate = new Button();
			this.btnActivate.Text = "✔  ACTIVATE";
			this.btnActivate.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
			this.btnActivate.BackColor = Color.FromArgb(0, 120, 60);
			this.btnActivate.ForeColor = Color.White;
			this.btnActivate.FlatStyle = FlatStyle.Flat;
			this.btnActivate.Enabled = false;
			this.btnActivate.Location = new Point(25, 445);
			this.btnActivate.Size = new Size(275, 46);
			this.btnActivate.Cursor = Cursors.Hand;
			this.btnActivate.FlatAppearance.BorderColor = ActivationForm.ClrGreen;
			this.btnActivate.Click += this.BtnActivate_Click;
			panel2.Controls.Add(this.btnActivate);
			this.btnExit = new Button();
			this.btnExit.Text = "✕  EXIT";
			this.btnExit.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
			this.btnExit.BackColor = Color.FromArgb(100, 40, 40);
			this.btnExit.ForeColor = Color.White;
			this.btnExit.FlatStyle = FlatStyle.Flat;
			this.btnExit.Location = new Point(320, 445);
			this.btnExit.Size = new Size(275, 46);
			this.btnExit.Cursor = Cursors.Hand;
			this.btnExit.FlatAppearance.BorderColor = ActivationForm.ClrRed;
			this.btnExit.Click += delegate(object <p0>, EventArgs <p1>)
			{
				base.DialogResult = DialogResult.Cancel;
				base.Close();
			};
			panel2.Controls.Add(this.btnExit);
			Label label6 = new Label();
			label6.Text = "Honda Flash Tools  •  Activation System v1.0";
			label6.Font = new Font("Segoe UI", 7.5f);
			label6.ForeColor = ActivationForm.ClrTextDim;
			label6.BackColor = Color.Transparent;
			label6.AutoSize = false;
			label6.TextAlign = ContentAlignment.MiddleCenter;
			label6.Location = new Point(0, 515);
			label6.Size = new Size(panel2.Width, 18);
			label6.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			panel2.Controls.Add(label6);
			int num = 18;
			base.Region = this.CreateRoundedRegion(new Rectangle(0, 0, base.ClientSize.Width, base.ClientSize.Height), num);
			panel.Region = this.CreateRoundedRegion(new Rectangle(0, 0, panel.Width, panel.Height), num);
			panel2.Region = this.CreateRoundedRegion(new Rectangle(0, 0, panel2.Width, panel2.Height), num - 2);
			groupBox.Region = this.CreateRoundedRegion(new Rectangle(0, 0, groupBox.Width, groupBox.Height), 8);
			groupBox2.Region = this.CreateRoundedRegion(new Rectangle(0, 0, groupBox2.Width, groupBox2.Height), 8);
		}

		// Token: 0x06001086 RID: 4230 RVA: 0x000787F8 File Offset: 0x000787F8
		private void BtnImport_Click(object sender, EventArgs e)
		{
			using (OpenFileDialog openFileDialog = new OpenFileDialog())
			{
				openFileDialog.Title = "Pilih File License";
				openFileDialog.Filter = "License File (*.lic)|*.lic|All Files (*.*)|*.*";
				openFileDialog.CheckFileExists = true;
				openFileDialog.Multiselect = false;
				if (openFileDialog.ShowDialog() == DialogResult.OK)
				{
					try
					{
						LicenseManager.LicenseInfo licenseInfo = LicenseManager.ParseLicenseFile(openFileDialog.FileName);
						if (licenseInfo == null)
						{
							this.SetStatus("✘ File license rusak / tidak valid", ActivationForm.ClrRed);
							this.btnActivate.Enabled = false;
							this._loadedLicPath = "";
						}
						else
						{
							string hardwareId = LicenseManager.GetHardwareId();
							if (!LicenseManager.ValidateKeyFormat(licenseInfo.Key))
							{
								this.SetStatus("✘ Format key tidak valid", ActivationForm.ClrRed);
								this.btnActivate.Enabled = false;
								this._loadedLicPath = "";
							}
							else if (!licenseInfo.IsValid(hardwareId))
							{
								if (!string.IsNullOrEmpty(licenseInfo.HardwareID) && !string.Equals(licenseInfo.HardwareID, hardwareId, StringComparison.OrdinalIgnoreCase))
								{
									this.SetStatus("✘ Hardware ID berbeda (license untuk PC lain)", ActivationForm.ClrRed);
								}
								else if (!licenseInfo.Permanent && licenseInfo.ExpiryDate < DateTime.Now.Date)
								{
									this.SetStatus("✘ License sudah expired", ActivationForm.ClrRed);
								}
								else
								{
									this.SetStatus("✘ License tidak valid", ActivationForm.ClrRed);
								}
								this.btnActivate.Enabled = false;
								this._loadedLicPath = "";
							}
							else
							{
								this._loadedLicPath = openFileDialog.FileName;
								string text = "✔ License OK";
								if (!string.IsNullOrEmpty(licenseInfo.Customer))
								{
									text = text + " — Customer: " + licenseInfo.Customer;
								}
								if (!string.IsNullOrEmpty(licenseInfo.Type))
								{
									text = text + " | Type: " + licenseInfo.Type;
								}
								this.SetStatus(text, ActivationForm.ClrGreen);
								this.btnActivate.Enabled = true;
							}
						}
					}
					catch (Exception ex)
					{
						this._loadedLicPath = "";
						this.SetStatus("✘ Error: " + ex.Message, ActivationForm.ClrRed);
						this.btnActivate.Enabled = false;
					}
				}
			}
		}

		// Token: 0x06001087 RID: 4231 RVA: 0x00078A34 File Offset: 0x00078A34
		private void BtnActivate_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(this._loadedLicPath))
			{
				this.SetStatus("✘ Belum ada file license yang di-import", ActivationForm.ClrRed);
				return;
			}
			this.btnActivate.Enabled = false;
			string str;
			if (LicenseManager.Activate(this._loadedLicPath, out str))
			{
				this.SetStatus("✔ Aktivasi berhasil! Silakan restart aplikasi.", ActivationForm.ClrGreen);
				CustomMessageBox__0.Show("Aktivasi berhasil!\r\n\r\nAplikasi akan dibuka.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				this.ActivatedSuccessfully = true;
				base.DialogResult = DialogResult.OK;
				base.Close();
				return;
			}
			this.btnActivate.Enabled = true;
			this.SetStatus("✘ " + str, ActivationForm.ClrRed);
			CustomMessageBox__0.Show("Aktivasi gagal:\r\n" + str, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x06001088 RID: 4232 RVA: 0x0000B2DE File Offset: 0x0000B2DE
		private void SetStatus(string text, Color color)
		{
			if (this.lblStatus == null)
			{
				return;
			}
			this.lblStatus.Text = text;
			this.lblStatus.ForeColor = color;
			this.lblStatus.Refresh();
		}

		// Token: 0x0600108A RID: 4234
		[DllImport("user32.dll")]
		private static extern bool ReleaseCapture();

		// Token: 0x0600108B RID: 4235
		[DllImport("user32.dll")]
		private static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

		// Token: 0x0600108C RID: 4236 RVA: 0x0000B30C File Offset: 0x0000B30C
		private void DragForm(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				ActivationForm.ReleaseCapture();
				ActivationForm.SendMessage(base.Handle, 161, (IntPtr)2, IntPtr.Zero);
			}
		}

		// Token: 0x06001090 RID: 4240 RVA: 0x00078C30 File Offset: 0x00078C30
		private Region CreateRoundedRegion(Rectangle rectangle, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = radius * 2;
			graphicsPath.AddArc(rectangle.X, rectangle.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(rectangle.Right - num, rectangle.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(rectangle.Right - num, rectangle.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(rectangle.X, rectangle.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return new Region(graphicsPath);
		}

		// Token: 0x04001725 RID: 5925
		private static readonly Color ClrDarkTop = Color.FromArgb(10, 13, 24);

		// Token: 0x04001726 RID: 5926
		private static readonly Color ClrDarkBottom = Color.FromArgb(18, 24, 40);

		// Token: 0x04001727 RID: 5927
		private static readonly Color ClrAqua = Color.FromArgb(0, 229, 255);

		// Token: 0x04001728 RID: 5928
		private static readonly Color ClrAquaDim = Color.FromArgb(0, 140, 180);

		// Token: 0x04001729 RID: 5929
		private static readonly Color ClrPanel = Color.FromArgb(25, 30, 45);

		// Token: 0x0400172A RID: 5930
		private static readonly Color ClrPanelAlt = Color.FromArgb(35, 42, 60);

		// Token: 0x0400172B RID: 5931
		private static readonly Color ClrText = Color.FromArgb(200, 240, 255);

		// Token: 0x0400172C RID: 5932
		private static readonly Color ClrTextDim = Color.FromArgb(120, 170, 200);

		// Token: 0x0400172D RID: 5933
		private static readonly Color ClrGreen = Color.FromArgb(80, 255, 140);

		// Token: 0x0400172E RID: 5934
		private static readonly Color ClrRed = Color.FromArgb(255, 80, 80);

		// Token: 0x0400172F RID: 5935
		private TextBox txtHardwareID;

		// Token: 0x04001730 RID: 5936
		private Button btnCopyHW;

		// Token: 0x04001731 RID: 5937
		private Button btnImport;

		// Token: 0x04001732 RID: 5938
		private Button btnActivate;

		// Token: 0x04001733 RID: 5939
		private Button btnExit;

		// Token: 0x04001734 RID: 5940
		private Label lblStatus;

		// Token: 0x04001735 RID: 5941
		private string _loadedLicPath;

		// Token: 0x04001737 RID: 5943
		private Button btnCloseX;

		// Token: 0x04001738 RID: 5944
		private const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x04001739 RID: 5945
		private const int HT_CAPTION = 2;
	}
}
