﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000554 RID: 1364
	public partial class CustomMessageBox__3 : global::System.Windows.Forms.Form
	{
	}
}
