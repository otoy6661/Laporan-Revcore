﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x020005F6 RID: 1526
	public partial class ProgressPopupForm : global::System.Windows.Forms.Form
	{
		// Token: 0x06000ED5 RID: 3797 RVA: 0x0000A2A5 File Offset: 0x0000A2A5
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.progressBar != null)
			{
				this.progressBar.Dispose();
				this.progressBar = null;
			}
			base.Dispose(disposing);
		}

		// Token: 0x040013B2 RID: 5042
		private global::Honda_Flash_Tools.Net.RoundedProgressBar progressBar;
	}
}
