﻿using System;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000356 RID: 854
	public class CustomMessageBox
	{
		// Token: 0x06000B70 RID: 2928 RVA: 0x000086E3 File Offset: 0x000086E3
		public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
		{
			return MessageBox.Show(text, caption, buttons, icon);
		}
	}
}
