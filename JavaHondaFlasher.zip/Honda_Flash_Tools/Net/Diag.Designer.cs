﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000357 RID: 855
	public partial class Diag : global::System.Windows.Forms.Form
	{
		// Token: 0x06000B99 RID: 2969 RVA: 0x0000883E File Offset: 0x0000883E
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000B9A RID: 2970 RVA: 0x00053624 File Offset: 0x00053624
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			this.panelHeader = new global::System.Windows.Forms.Panel();
			this.lblHeaderTitle = new global::System.Windows.Forms.Label();
			this.lblHeaderSub = new global::System.Windows.Forms.Label();
			this.btnCloseX = new global::System.Windows.Forms.Button();
			this.tlpMainLayout = new global::System.Windows.Forms.TableLayoutPanel();
			this.panelMain = new global::System.Windows.Forms.Panel();
			this.panelGrid = new global::System.Windows.Forms.Panel();
			this.tlpGrid = new global::System.Windows.Forms.TableLayoutPanel();
			this.panelBottomControls = new global::System.Windows.Forms.Panel();
			this.panelChart = new global::System.Windows.Forms.Panel();
			this.button1 = new global::Honda_Flash_Tools.Net.Diag.RoundedButton();
			this.button2 = new global::Honda_Flash_Tools.Net.Diag.RoundedButton();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.panelHeader.SuspendLayout();
			this.tlpMainLayout.SuspendLayout();
			this.panelMain.SuspendLayout();
			this.panelGrid.SuspendLayout();
			this.panelBottomControls.SuspendLayout();
			base.SuspendLayout();
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.BackColor = this.colBg;
			base.ForeColor = this.colText;
			base.ClientSize = new global::System.Drawing.Size(1370, 730);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.TopMost = true;
			base.Padding = new global::System.Windows.Forms.Padding(10);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "Diag";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Data Diagnostic Tools";
			base.KeyPreview = true;
			this.DoubleBuffered = true;
			base.SetStyle(global::System.Windows.Forms.ControlStyles.UserPaint | global::System.Windows.Forms.ControlStyles.ResizeRedraw | global::System.Windows.Forms.ControlStyles.AllPaintingInWmPaint | global::System.Windows.Forms.ControlStyles.OptimizedDoubleBuffer, true);
			this.panelHeader.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.panelHeader.Height = 58;
			this.panelHeader.BackColor = this.colCard;
			this.panelHeader.Padding = new global::System.Windows.Forms.Padding(15, 0, 15, 0);
			base.Controls.Add(this.panelHeader);
			global::System.Windows.Forms.PictureBox pictureBox = new global::System.Windows.Forms.PictureBox
			{
				Name = "pictureBox1",
				BackColor = global::System.Drawing.Color.Transparent,
				Location = new global::System.Drawing.Point(10, 0),
				Size = new global::System.Drawing.Size(180, 55),
				SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.Zoom,
				TabStop = false
			};
			try
			{
				global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Honda_Flash_Tools.Net.FormMain));
				pictureBox.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			}
			catch
			{
				pictureBox.Image = null;
			}
			this.panelHeader.Controls.Add(pictureBox);
			this.lblHeaderTitle.Text = "AUTO DIAGNOSTIC DASHBOARD";
			this.lblHeaderTitle.Font = new global::System.Drawing.Font("Segoe UI", 16f, global::System.Drawing.FontStyle.Bold);
			this.lblHeaderTitle.ForeColor = this.colCyan;
			this.lblHeaderTitle.AutoSize = true;
			this.lblHeaderTitle.Location = new global::System.Drawing.Point(200, 8);
			this.panelHeader.Controls.Add(this.lblHeaderTitle);
			this.lblHeaderSub.Text = "Real-Time ECU Telemetry Cards";
			this.lblHeaderSub.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Italic);
			this.lblHeaderSub.ForeColor = global::System.Drawing.Color.FromArgb(135, 158, 174);
			this.lblHeaderSub.AutoSize = true;
			this.lblHeaderSub.Location = new global::System.Drawing.Point(202, 38);
			this.panelHeader.Controls.Add(this.lblHeaderSub);
			this.btnCloseX.Text = "✕";
			this.btnCloseX.Size = new global::System.Drawing.Size(40, 35);
			this.btnCloseX.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnCloseX.BackColor = this.colBg;
			this.btnCloseX.ForeColor = global::System.Drawing.Color.FromArgb(255, 90, 105);
			this.btnCloseX.Font = new global::System.Drawing.Font("Segoe UI", 12f, global::System.Drawing.FontStyle.Bold);
			this.btnCloseX.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.btnCloseX.TabStop = false;
			this.btnCloseX.FlatAppearance.BorderSize = 0;
			this.btnCloseX.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.FromArgb(220, 50, 60);
			this.btnCloseX.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.btnCloseX.Click += delegate(object s, global::System.EventArgs e)
			{
				base.Close();
			};
			this.panelHeader.Controls.Add(this.btnCloseX);
			this.tlpMainLayout.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.tlpMainLayout.ColumnCount = 1;
			this.tlpMainLayout.RowCount = 3;
			this.tlpMainLayout.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Percent, 100f));
			this.tlpMainLayout.RowStyles.Add(new global::System.Windows.Forms.RowStyle(global::System.Windows.Forms.SizeType.Percent, 55f));
			this.tlpMainLayout.RowStyles.Add(new global::System.Windows.Forms.RowStyle(global::System.Windows.Forms.SizeType.Percent, 45f));
			this.tlpMainLayout.RowStyles.Add(new global::System.Windows.Forms.RowStyle(global::System.Windows.Forms.SizeType.Absolute, 90f));
			this.tlpMainLayout.Padding = new global::System.Windows.Forms.Padding(10, 6, 10, 10);
			base.Controls.Add(this.tlpMainLayout);
			this.panelChart.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.panelChart.BackColor = this.colCard;
			this.panelChart.Padding = new global::System.Windows.Forms.Padding(10);
			this.tlpMainLayout.Controls.Add(this.panelChart, 0, 0);
			this.panelMain.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.panelMain.BackColor = this.colCard;
			this.panelMain.Padding = new global::System.Windows.Forms.Padding(0);
			this.tlpMainLayout.Controls.Add(this.panelMain, 0, 1);
			this.panelGrid.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.panelGrid.BackColor = this.colCard;
			this.panelGrid.Padding = new global::System.Windows.Forms.Padding(10);
			this.panelMain.Controls.Add(this.panelGrid);
			this.tlpGrid.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.tlpGrid.BackColor = global::System.Drawing.Color.Transparent;
			this.tlpGrid.Padding = new global::System.Windows.Forms.Padding(0);
			this.panelGrid.Controls.Add(this.tlpGrid);
			this.panelBottomControls.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.panelBottomControls.BackColor = this.colCard;
			this.panelBottomControls.Padding = new global::System.Windows.Forms.Padding(10);
			this.tlpMainLayout.Controls.Add(this.panelBottomControls, 0, 2);
			global::System.Windows.Forms.TableLayoutPanel tableLayoutPanel = new global::System.Windows.Forms.TableLayoutPanel
			{
				Dock = global::System.Windows.Forms.DockStyle.Fill,
				ColumnCount = 2,
				RowCount = 1
			};
			tableLayoutPanel.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Percent, 50f));
			tableLayoutPanel.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Percent, 50f));
			this.panelBottomControls.Controls.Add(tableLayoutPanel);
			this.SetupButton(this.button2, "▶️ START", tableLayoutPanel, 0);
			this.SetupButton(this.button1, "❎ EXIT", tableLayoutPanel, 1);
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.button2.Click += new global::System.EventHandler(this.button2_Click);
			this.timer1.Tick += new global::System.EventHandler(this.timer1_Tick);
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.Diag_FormClosing);
			base.Load += new global::System.EventHandler(this.Diag_Load);
			base.Paint += new global::System.Windows.Forms.PaintEventHandler(this.Diag_Paint);
			base.Resize += delegate(object s, global::System.EventArgs e)
			{
				using (global::System.Drawing.Drawing2D.GraphicsPath roundedPath = this.GetRoundedPath(new global::System.Drawing.Rectangle(0, 0, base.Width, base.Height), 14))
				{
					base.Region = new global::System.Drawing.Region(roundedPath);
				}
				this.btnCloseX.Location = new global::System.Drawing.Point(checked(this.panelHeader.Width - 55), 10);
				base.Invalidate();
			};
			base.KeyDown += delegate(object s, global::System.Windows.Forms.KeyEventArgs e)
			{
				if (e.KeyCode == global::System.Windows.Forms.Keys.Escape)
				{
					base.Close();
				}
			};
			this.panelHeader.ResumeLayout(false);
			this.panelHeader.PerformLayout();
			this.tlpMainLayout.ResumeLayout(false);
			this.panelMain.ResumeLayout(false);
			this.panelGrid.ResumeLayout(false);
			this.panelBottomControls.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		// Token: 0x04000CF6 RID: 3318
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000CF7 RID: 3319
		private global::System.Windows.Forms.Timer timer1;

		// Token: 0x04000CF8 RID: 3320
		private global::System.Windows.Forms.Button button1;

		// Token: 0x04000CF9 RID: 3321
		private global::System.Windows.Forms.Button button2;

		// Token: 0x04000CFA RID: 3322
		private global::System.Windows.Forms.Button btnCloseX;

		// Token: 0x04000CFB RID: 3323
		private global::System.Windows.Forms.Panel panelHeader;

		// Token: 0x04000CFC RID: 3324
		private global::System.Windows.Forms.Label lblHeaderTitle;

		// Token: 0x04000CFD RID: 3325
		private global::System.Windows.Forms.Label lblHeaderSub;

		// Token: 0x04000D00 RID: 3328
		private global::System.Drawing.Color colBg = global::System.Drawing.Color.FromArgb(10, 15, 20);

		// Token: 0x04000D01 RID: 3329
		private global::System.Drawing.Color colCard = global::System.Drawing.Color.FromArgb(18, 25, 35);

		// Token: 0x04000D03 RID: 3331
		private global::System.Drawing.Color colText = global::System.Drawing.Color.FromArgb(225, 238, 245);

		// Token: 0x04000D04 RID: 3332
		private global::System.Drawing.Color colCyan = global::System.Drawing.Color.FromArgb(0, 255, 220);

		// Token: 0x04000D05 RID: 3333
		private global::System.Windows.Forms.Panel panelMain;

		// Token: 0x04000D06 RID: 3334
		private global::System.Windows.Forms.Panel panelGrid;

		// Token: 0x04000D07 RID: 3335
		private global::System.Windows.Forms.Panel panelBottomControls;

		// Token: 0x04000D08 RID: 3336
		private global::System.Windows.Forms.TableLayoutPanel tlpGrid;

		// Token: 0x04000D09 RID: 3337
		private global::System.Windows.Forms.Panel panelChart;

		// Token: 0x04000D0D RID: 3341
		private global::System.Windows.Forms.TableLayoutPanel tlpMainLayout;
	}
}
