﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x020006D6 RID: 1750
	public class AquaSpinner : Control
	{
		// Token: 0x0600101E RID: 4126 RVA: 0x000750EC File Offset: 0x000750EC
		public AquaSpinner()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.BackColor = Color.Transparent;
			base.Size = new Size(28, 28);
			this._timer = new Timer
			{
				Interval = 60
			};
			this._timer.Tick += delegate(object s, EventArgs e)
			{
				this._angle = (this._angle + 30f) % 360f;
				base.Invalidate();
			};
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x0600101F RID: 4127 RVA: 0x0000AEBD File Offset: 0x0000AEBD
		// (set) Token: 0x06001020 RID: 4128 RVA: 0x0000AEC5 File Offset: 0x0000AEC5
		public Color SpinnerColor
		{
			get
			{
				return this._spinnerColor;
			}
			set
			{
				this._spinnerColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x06001021 RID: 4129 RVA: 0x0000AED4 File Offset: 0x0000AED4
		// (set) Token: 0x06001022 RID: 4130 RVA: 0x0000AEDC File Offset: 0x0000AEDC
		public int DotCount
		{
			get
			{
				return this._dotCount;
			}
			set
			{
				this._dotCount = Math.Max(4, value);
				base.Invalidate();
			}
		}

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x06001023 RID: 4131 RVA: 0x0000AEF1 File Offset: 0x0000AEF1
		// (set) Token: 0x06001024 RID: 4132 RVA: 0x0000AEFE File Offset: 0x0000AEFE
		public new bool Enabled
		{
			get
			{
				return this._timer.Enabled;
			}
			set
			{
				if (value)
				{
					this._timer.Start();
					return;
				}
				this._timer.Stop();
				this._angle = 0f;
				base.Invalidate();
			}
		}

		// Token: 0x06001025 RID: 4133 RVA: 0x0007516C File Offset: 0x0007516C
		protected override void OnPaint(PaintEventArgs e)
		{
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			float num = (float)base.Width / 2f;
			float num2 = (float)base.Height / 2f;
			float num3 = Math.Min(num, num2) - 3f;
			float num4 = Math.Max(2f, num3 / 3.5f);
			for (int i = 0; i < this._dotCount; i++)
			{
				float num5 = (this._angle + 360f / (float)this._dotCount * (float)i) * 3.1415927f / 180f;
				float x = num + num3 * (float)Math.Cos((double)num5) - num4 / 2f;
				float y = num2 + num3 * (float)Math.Sin((double)num5) - num4 / 2f;
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(40 + (int)(215f * ((float)i / (float)this._dotCount)), this._spinnerColor)))
				{
					e.Graphics.FillEllipse(solidBrush, x, y, num4, num4);
				}
			}
		}

		// Token: 0x06001026 RID: 4134 RVA: 0x00075288 File Offset: 0x00075288
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				Timer timer = this._timer;
				if (timer != null)
				{
					timer.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		// Token: 0x040015D6 RID: 5590
		private readonly Timer _timer;

		// Token: 0x040015D7 RID: 5591
		private float _angle;

		// Token: 0x040015D8 RID: 5592
		private int _dotCount = 8;

		// Token: 0x040015D9 RID: 5593
		private Color _spinnerColor = Color.FromArgb(0, 255, 255);
	}
}
