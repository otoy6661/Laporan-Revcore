﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000710 RID: 1808
	public partial class DarkWebPopup : Form
	{
		// Token: 0x1700008A RID: 138
		// (get) Token: 0x0600104A RID: 4170 RVA: 0x0000B09C File Offset: 0x0000B09C
		// (set) Token: 0x0600104B RID: 4171 RVA: 0x0000B0A4 File Offset: 0x0000B0A4
		public bool Result { get; private set; }

		// Token: 0x0600104C RID: 4172 RVA: 0x00075A74 File Offset: 0x00075A74
		public DarkWebPopup(string title, string message, PopupType type = PopupType.Info, bool showButtons = true, int autoCloseMs = 0)
		{
			this._type = type;
			this._title = (title ?? "");
			this._message = (message ?? "");
			this._showButtons = (showButtons && type != PopupType.Loading);
			base.FormBorderStyle = FormBorderStyle.None;
			base.StartPosition = FormStartPosition.CenterParent;
			base.ShowInTaskbar = false;
			base.TopMost = true;
			this.BackColor = Color.FromArgb(12, 16, 24);
			this.DoubleBuffered = true;
			base.KeyPreview = true;
			base.ClientSize = new Size(460, this._showButtons ? 240 : 200);
			base.Padding = new Padding(6);
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.UpdateStyles();
			this._animTimer = new Timer
			{
				Interval = 40
			};
			this._animTimer.Tick += delegate(object s, EventArgs e)
			{
				this._glowPhase += 0.08f;
				if (this._glowPhase > 6.2831855f)
				{
					this._glowPhase -= 6.2831855f;
				}
				if (this._type == PopupType.Loading)
				{
					this._spinnerAngle = (this._spinnerAngle + 12) % 360;
				}
				base.Invalidate();
			};
			this._animTimer.Start();
			if (autoCloseMs > 0)
			{
				Timer autoT = new Timer
				{
					Interval = autoCloseMs
				};
				autoT.Tick += delegate(object s, EventArgs e)
				{
					autoT.Stop();
					this.Close();
				};
				autoT.Start();
			}
			base.KeyDown += delegate(object s, KeyEventArgs e)
			{
				if (e.KeyCode == Keys.Escape)
				{
					this.Result = false;
					base.Close();
				}
				if (e.KeyCode == Keys.Return && this._showButtons)
				{
					this.Result = true;
					base.Close();
				}
			};
			bool dragging = false;
			Point dragStart = Point.Empty;
			base.MouseDown += delegate(object s, MouseEventArgs e)
			{
				if (e.Button == MouseButtons.Left)
				{
					dragging = true;
					dragStart = e.Location;
				}
			};
			base.MouseMove += delegate(object s, MouseEventArgs e)
			{
				if (dragging)
				{
					this.Location = new Point(this.Location.X + e.X - dragStart.X, this.Location.Y + e.Y - dragStart.Y);
				}
			};
			base.MouseUp += delegate(object s, MouseEventArgs e)
			{
				dragging = false;
			};
			if (this._showButtons)
			{
				Button button = this.MakeButton("OK", true);
				Button button2 = this.MakeButton("CANCEL", false);
				button.Click += delegate(object s, EventArgs e)
				{
					this.Result = true;
					base.Close();
				};
				button2.Click += delegate(object s, EventArgs e)
				{
					this.Result = false;
					base.Close();
				};
				base.Controls.Add(button);
				base.Controls.Add(button2);
				int num = 150;
				int num2 = 42;
				int num3 = 12;
				int num4 = num * 2 + num3;
				int num5 = (base.ClientSize.Width - num4) / 2;
				int y = base.ClientSize.Height - num2 - 22;
				button2.Bounds = new Rectangle(num5, y, num, num2);
				button.Bounds = new Rectangle(num5 + num + num3, y, num, num2);
			}
			base.Paint += this.DarkWebPopup_Paint;
		}

		// Token: 0x0600104D RID: 4173 RVA: 0x00075D08 File Offset: 0x00075D08
		private Button MakeButton(string text, bool primary)
		{
			Color color = primary ? Color.FromArgb(0, 255, 220) : Color.FromArgb(255, 80, 100);
			return new Button
			{
				Text = text,
				FlatStyle = FlatStyle.Flat,
				BackColor = Color.FromArgb(18, 24, 34),
				ForeColor = color,
				Font = new Font("Segoe UI Semibold", 10.5f, FontStyle.Bold),
				Cursor = Cursors.Hand,
				TabStop = false,
				FlatAppearance = 
				{
					BorderSize = 1,
					BorderColor = color,
					MouseOverBackColor = (primary ? Color.FromArgb(0, 80, 90) : Color.FromArgb(90, 25, 35)),
					MouseDownBackColor = (primary ? Color.FromArgb(0, 120, 130) : Color.FromArgb(140, 40, 55))
				}
			};
		}

		// Token: 0x0600104E RID: 4174 RVA: 0x00075DF4 File Offset: 0x00075DF4
		private void DarkWebPopup_Paint(object sender, PaintEventArgs e)
		{
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			e.Graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
			int width = base.ClientSize.Width;
			int height = base.ClientSize.Height;
			Color accentColor = DarkWebPopup.GetAccentColor(this._type);
			string icon = DarkWebPopup.GetIcon(this._type);
			float num = 0.5f + 0.5f * (float)Math.Sin((double)this._glowPhase);
			using (Pen pen = new Pen(Color.FromArgb((int)(40f + 60f * num), accentColor), 1f))
			{
				using (GraphicsPath roundedPath = this.GetRoundedPath(new Rectangle(4, 4, width - 9, height - 9), 14))
				{
					e.Graphics.DrawPath(pen, roundedPath);
				}
			}
			using (Pen pen2 = new Pen(Color.FromArgb(140, accentColor), 1f))
			{
				using (GraphicsPath roundedPath2 = this.GetRoundedPath(new Rectangle(2, 2, width - 5, height - 5), 12))
				{
					e.Graphics.DrawPath(pen2, roundedPath2);
				}
			}
			using (Pen pen3 = new Pen(Color.FromArgb(255, accentColor), 1f))
			{
				using (GraphicsPath roundedPath3 = this.GetRoundedPath(new Rectangle(5, 5, width - 11, height - 11), 11))
				{
					e.Graphics.DrawPath(pen3, roundedPath3);
				}
			}
			using (Brush brush = new LinearGradientBrush(new Rectangle(0, 0, width, 46), Color.FromArgb(40, accentColor), Color.FromArgb(0, accentColor), LinearGradientMode.Vertical))
			{
				e.Graphics.FillRectangle(brush, new Rectangle(6, 6, width - 12, 46));
			}
			using (Font font = new Font("Segoe UI Emoji", 22f, FontStyle.Regular))
			{
				using (Brush brush2 = new SolidBrush(accentColor))
				{
					e.Graphics.DrawString(icon, font, brush2, 22f, 14f);
				}
			}
			using (Font font2 = new Font("Segoe UI Semibold", 13f, FontStyle.Bold))
			{
				using (Brush brush3 = new SolidBrush(accentColor))
				{
					e.Graphics.DrawString(this._title, font2, brush3, 68f, 18f);
				}
			}
			using (Pen pen4 = new Pen(Color.FromArgb(80, accentColor), 1f))
			{
				e.Graphics.DrawLine(pen4, 20, 64, width - 20, 64);
			}
			using (Font font3 = new Font("Segoe UI", 10.5f, FontStyle.Regular))
			{
				using (Brush brush4 = new SolidBrush(Color.FromArgb(215, 230, 240)))
				{
					RectangleF layoutRectangle = new RectangleF(24f, 82f, (float)(width - 48), (float)(height - 160));
					StringFormat format = new StringFormat
					{
						Alignment = StringAlignment.Near,
						LineAlignment = StringAlignment.Near,
						Trimming = StringTrimming.EllipsisWord
					};
					e.Graphics.DrawString(this._message, font3, brush4, layoutRectangle, format);
				}
			}
			if (this._type == PopupType.Loading)
			{
				int num2 = width / 2;
				int num3 = height - 60;
				int num4 = 16;
				using (Pen pen5 = new Pen(Color.FromArgb(60, accentColor), 3f))
				{
					e.Graphics.DrawEllipse(pen5, num2 - num4, num3 - num4, num4 * 2, num4 * 2);
				}
				using (Pen pen6 = new Pen(accentColor, 3f))
				{
					pen6.StartCap = LineCap.Round;
					pen6.EndCap = LineCap.Round;
					e.Graphics.DrawArc(pen6, num2 - num4, num3 - num4, num4 * 2, num4 * 2, this._spinnerAngle, 90);
				}
				using (Font font4 = new Font("Segoe UI", 9f, FontStyle.Italic))
				{
					using (Brush brush5 = new SolidBrush(Color.FromArgb(180, accentColor)))
					{
						string text = "Processing...";
						SizeF sizeF = e.Graphics.MeasureString(text, font4);
						e.Graphics.DrawString(text, font4, brush5, (float)num2 - sizeF.Width / 2f, (float)(num3 + num4 + 4));
					}
				}
			}
		}

		// Token: 0x0600104F RID: 4175 RVA: 0x00076354 File Offset: 0x00076354
		private static Color GetAccentColor(PopupType t)
		{
			switch (t)
			{
			case PopupType.Success:
				return Color.FromArgb(0, 255, 180);
			case PopupType.Warning:
				return Color.FromArgb(255, 200, 0);
			case PopupType.Error:
				return Color.FromArgb(255, 80, 100);
			case PopupType.Loading:
				return Color.FromArgb(0, 255, 220);
			default:
				return Color.FromArgb(0, 255, 220);
			}
		}

		// Token: 0x06001050 RID: 4176 RVA: 0x0000B0AD File Offset: 0x0000B0AD
		private static string GetIcon(PopupType t)
		{
			switch (t)
			{
			case PopupType.Success:
				return "✅";
			case PopupType.Warning:
				return "⚠️";
			case PopupType.Error:
				return "⛔";
			case PopupType.Loading:
				return "⚙️";
			default:
				return "ℹ️";
			}
		}

		// Token: 0x06001051 RID: 4177 RVA: 0x0004D38C File Offset: 0x0004D38C
		private GraphicsPath GetRoundedPath(Rectangle r, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = radius * 2;
			graphicsPath.AddArc(r.X, r.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(r.Right - num, r.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(r.Right - num, r.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(r.X, r.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x06001052 RID: 4178 RVA: 0x000763D0 File Offset: 0x000763D0
		public static void Info(IWin32Window owner, string title, string message)
		{
			using (DarkWebPopup darkWebPopup = new DarkWebPopup(title, message, PopupType.Info, false, 2200))
			{
				darkWebPopup.ShowDialog(owner);
			}
		}

		// Token: 0x06001053 RID: 4179 RVA: 0x00076410 File Offset: 0x00076410
		public static bool Confirm(IWin32Window owner, string title, string message)
		{
			bool result;
			using (DarkWebPopup darkWebPopup = new DarkWebPopup(title, message, PopupType.Warning, true, 0))
			{
				result = (darkWebPopup.ShowDialog(owner) == DialogResult.OK || darkWebPopup.Result);
			}
			return result;
		}

		// Token: 0x06001054 RID: 4180 RVA: 0x0007645C File Offset: 0x0007645C
		public static void Error(IWin32Window owner, string title, string message)
		{
			using (DarkWebPopup darkWebPopup = new DarkWebPopup(title, message, PopupType.Error, true, 0))
			{
				darkWebPopup.ShowDialog(owner);
			}
		}

		// Token: 0x06001055 RID: 4181 RVA: 0x00076498 File Offset: 0x00076498
		public static void Success(IWin32Window owner, string title, string message)
		{
			using (DarkWebPopup darkWebPopup = new DarkWebPopup(title, message, PopupType.Success, false, 2000))
			{
				darkWebPopup.ShowDialog(owner);
			}
		}

		// Token: 0x06001056 RID: 4182 RVA: 0x0000B0E6 File Offset: 0x0000B0E6
		public static DarkWebPopup ShowLoading(IWin32Window owner, string title, string message)
		{
			DarkWebPopup darkWebPopup = new DarkWebPopup(title, message, PopupType.Loading, false, 0);
			darkWebPopup.Show(owner);
			return darkWebPopup;
		}

		// Token: 0x06001057 RID: 4183 RVA: 0x0000B0F9 File Offset: 0x0000B0F9
		protected override void OnFormClosed(FormClosedEventArgs e)
		{
			Timer animTimer = this._animTimer;
			if (animTimer != null)
			{
				animTimer.Stop();
			}
			Timer animTimer2 = this._animTimer;
			if (animTimer2 != null)
			{
				animTimer2.Dispose();
			}
			base.OnFormClosed(e);
		}

		// Token: 0x040016E0 RID: 5856
		private readonly PopupType _type;

		// Token: 0x040016E1 RID: 5857
		private readonly string _title;

		// Token: 0x040016E2 RID: 5858
		private readonly string _message;

		// Token: 0x040016E3 RID: 5859
		private readonly bool _showButtons;

		// Token: 0x040016E4 RID: 5860
		private readonly Timer _animTimer;

		// Token: 0x040016E5 RID: 5861
		private float _glowPhase;

		// Token: 0x040016E6 RID: 5862
		private int _spinnerAngle;
	}
}
