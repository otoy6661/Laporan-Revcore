﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000361 RID: 865
	public partial class pass : global::System.Windows.Forms.Form
	{
		// Token: 0x06000BCA RID: 3018 RVA: 0x00055A24 File Offset: 0x00055A24
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.Windows.Forms.Panel panel = new global::System.Windows.Forms.Panel();
			panel.Location = new global::System.Drawing.Point(0, 0);
			panel.Size = new global::System.Drawing.Size(400, 60);
			panel.BackColor = global::System.Drawing.Color.FromArgb(0, 60, 120);
			global::System.Windows.Forms.Label label = new global::System.Windows.Forms.Label();
			label.Location = new global::System.Drawing.Point(10, 10);
			label.Size = new global::System.Drawing.Size(360, 40);
			label.Text = "KEIHIN FLASH COUNTER RESET";
			label.Font = new global::System.Drawing.Font("Arial", 14f, global::System.Drawing.FontStyle.Bold);
			label.ForeColor = global::System.Drawing.Color.White;
			label.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.lblStatus = new global::System.Windows.Forms.Label();
			this.lblStatus.Location = new global::System.Drawing.Point(10, 10);
			this.lblStatus.Size = new global::System.Drawing.Size(360, 30);
			this.lblStatus.Text = "READY TO RESET";
			this.lblStatus.Font = new global::System.Drawing.Font("Arial", 10f, global::System.Drawing.FontStyle.Bold);
			this.lblStatus.ForeColor = global::System.Drawing.Color.Lime;
			this.lblStatus.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.lblStatus.BackColor = global::System.Drawing.Color.FromArgb(30, 30, 40);
			this.lblStatus.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.progressBar = new global::System.Windows.Forms.ProgressBar();
			this.progressBar.Location = new global::System.Drawing.Point(10, 50);
			this.progressBar.Size = new global::System.Drawing.Size(360, 20);
			this.progressBar.Style = global::System.Windows.Forms.ProgressBarStyle.Continuous;
			this.progressBar.Minimum = 0;
			this.progressBar.Maximum = 128;
			this.lblProgress = new global::System.Windows.Forms.Label();
			this.lblProgress.Location = new global::System.Drawing.Point(0, 75);
			this.lblProgress.Size = new global::System.Drawing.Size(160, 20);
			this.lblProgress.Text = "Progress: 0/128 (0%)";
			this.lblProgress.Font = new global::System.Drawing.Font("Arial", 9f);
			this.lblProgress.ForeColor = global::System.Drawing.Color.Lime;
			this.lblProgress.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.lblTime = new global::System.Windows.Forms.Label();
			this.lblTime.Location = new global::System.Drawing.Point(250, 75);
			this.lblTime.Size = new global::System.Drawing.Size(160, 20);
			this.lblTime.Text = "Time: 0.0s";
			this.lblTime.Font = new global::System.Drawing.Font("Arial", 9f);
			this.lblTime.ForeColor = global::System.Drawing.Color.Lime;
			this.lblTime.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			global::System.Windows.Forms.Panel panel2 = new global::System.Windows.Forms.Panel();
			panel2.Location = new global::System.Drawing.Point(20, 185);
			panel2.Size = new global::System.Drawing.Size(360, 220);
			panel2.BackColor = global::System.Drawing.Color.FromArgb(10, 10, 15);
			panel2.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			global::System.Windows.Forms.Label label2 = new global::System.Windows.Forms.Label();
			label2.Location = new global::System.Drawing.Point(0, 0);
			label2.Size = new global::System.Drawing.Size(360, 25);
			label2.Text = "PROCESS LOG";
			label2.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Bold);
			label2.ForeColor = global::System.Drawing.Color.Cyan;
			label2.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			label2.BackColor = global::System.Drawing.Color.FromArgb(20, 20, 30);
			this.txtLog = new global::System.Windows.Forms.TextBox();
			this.txtLog.Location = new global::System.Drawing.Point(5, 30);
			this.txtLog.Size = new global::System.Drawing.Size(350, 185);
			this.txtLog.Multiline = true;
			this.txtLog.ScrollBars = global::System.Windows.Forms.ScrollBars.Vertical;
			this.txtLog.Font = new global::System.Drawing.Font("Consolas", 8f);
			this.txtLog.BackColor = global::System.Drawing.Color.FromArgb(5, 5, 10);
			this.txtLog.ForeColor = global::System.Drawing.Color.Lime;
			this.txtLog.ReadOnly = true;
			this.txtLog.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.btnReset = new global::System.Windows.Forms.Button();
			this.btnReset.Location = new global::System.Drawing.Point(10, 105);
			this.btnReset.Size = new global::System.Drawing.Size(260, 40);
			this.btnReset.Text = "START RESET";
			this.btnReset.Font = new global::System.Drawing.Font("Arial", 10f, global::System.Drawing.FontStyle.Bold);
			this.btnReset.BackColor = global::System.Drawing.Color.FromArgb(0, 100, 0);
			this.btnReset.ForeColor = global::System.Drawing.Color.White;
			this.btnReset.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnReset.FlatAppearance.BorderSize = 0;
			this.btnReset.Click += new global::System.EventHandler(this.btnReset_Click);
			this.btnExit = new global::System.Windows.Forms.Button();
			this.btnExit.Location = new global::System.Drawing.Point(280, 105);
			this.btnExit.Size = new global::System.Drawing.Size(90, 40);
			this.btnExit.Text = "EXIT";
			this.btnExit.Font = new global::System.Drawing.Font("Arial", 10f);
			this.btnExit.BackColor = global::System.Drawing.Color.FromArgb(100, 0, 0);
			this.btnExit.ForeColor = global::System.Drawing.Color.White;
			this.btnExit.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnExit.FlatAppearance.BorderSize = 0;
			this.btnExit.Click += new global::System.EventHandler(this.btnExit_Click);
			global::System.Windows.Forms.Label label3 = new global::System.Windows.Forms.Label();
			label3.Location = new global::System.Drawing.Point(20, 460);
			label3.Size = new global::System.Drawing.Size(360, 30);
			label3.Text = "1. Connect FTDI  2. Key ON  3. Click START";
			label3.Font = new global::System.Drawing.Font("Arial", 8f);
			label3.ForeColor = global::System.Drawing.Color.Gray;
			label3.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			base.Controls.Add(this.lblStatus);
			base.Controls.Add(this.progressBar);
			base.Controls.Add(this.lblProgress);
			base.Controls.Add(this.lblTime);
			base.Controls.Add(this.btnReset);
			base.Controls.Add(this.btnExit);
			base.Controls.Add(label3);
			base.ClientSize = new global::System.Drawing.Size(400, 300);
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.pass_FormClosing);
		}

		// Token: 0x04000D5B RID: 3419
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000D5C RID: 3420
		private global::System.Windows.Forms.Button btnExit;

		// Token: 0x04000D5D RID: 3421
		private global::System.Windows.Forms.Label lblStatus;

		// Token: 0x04000D5E RID: 3422
		private global::System.Windows.Forms.TextBox txtLog;

		// Token: 0x04000D60 RID: 3424
		private global::System.Windows.Forms.ProgressBar progressBar;

		// Token: 0x04000D61 RID: 3425
		private global::System.Windows.Forms.Label lblProgress;

		// Token: 0x04000D62 RID: 3426
		private global::System.Windows.Forms.Label lblTime;

		// Token: 0x04000D63 RID: 3427
		private global::System.Windows.Forms.Button btnReset;
	}
}
