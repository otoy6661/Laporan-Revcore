﻿using System;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200074E RID: 1870
	public static class Interaction__0
	{
		// Token: 0x06001178 RID: 4472 RVA: 0x00080200 File Offset: 0x00080200
		public static MsgBoxResult MsgBox(string prompt, MsgBoxStyle__0 style, string title)
		{
			MessageBoxButtons buttons = MessageBoxButtons.OK;
			MessageBoxIcon icon = MessageBoxIcon.None;
			switch (style)
			{
			case MsgBoxStyle__0.OkOnly:
				buttons = MessageBoxButtons.OK;
				break;
			case MsgBoxStyle__0.OkCancel:
				buttons = MessageBoxButtons.OKCancel;
				break;
			case MsgBoxStyle__0.YesNoCancel:
				buttons = MessageBoxButtons.YesNoCancel;
				break;
			case MsgBoxStyle__0.YesNo:
				buttons = MessageBoxButtons.YesNo;
				break;
			}
			if ((style & MsgBoxStyle__0.Information) == MsgBoxStyle__0.Information)
			{
				icon = MessageBoxIcon.Asterisk;
			}
			else if ((style & MsgBoxStyle__0.Warning) == MsgBoxStyle__0.Warning)
			{
				icon = MessageBoxIcon.Exclamation;
			}
			else if ((style & MsgBoxStyle__0.Critical) == MsgBoxStyle__0.Critical)
			{
				icon = MessageBoxIcon.Hand;
			}
			else if ((style & MsgBoxStyle__0.Question) == MsgBoxStyle__0.Question)
			{
				icon = MessageBoxIcon.Question;
			}
			switch (MessageBox.Show(prompt, title, buttons, icon))
			{
			case DialogResult.OK:
				return MsgBoxResult.OK;
			case DialogResult.Cancel:
				return MsgBoxResult.Cancel;
			case DialogResult.Yes:
				return MsgBoxResult.Yes;
			case DialogResult.No:
				return MsgBoxResult.No;
			}
			return MsgBoxResult.OK;
		}

		// Token: 0x06001179 RID: 4473 RVA: 0x0000B8E0 File Offset: 0x0000B8E0
		public static MsgBoxResult MsgBox(string prompt)
		{
			MessageBox.Show(prompt);
			return MsgBoxResult.OK;
		}

		// Token: 0x0600117A RID: 4474 RVA: 0x0000B8EA File Offset: 0x0000B8EA
		public static MsgBoxResult MsgBox(string prompt, MsgBoxStyle__0 style)
		{
			return Interaction__0.MsgBox(prompt, style, "");
		}
	}
}
