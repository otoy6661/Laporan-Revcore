﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000749 RID: 1865
	public static class Conversions__0
	{
		// Token: 0x06001170 RID: 4464 RVA: 0x0000B8A7 File Offset: 0x0000B8A7
		public static string ToString(object value)
		{
			if (value == null)
			{
				return "";
			}
			return value.ToString();
		}

		// Token: 0x06001171 RID: 4465 RVA: 0x0007FF70 File Offset: 0x0007FF70
		public static int ToInteger(object value)
		{
			if (value == null)
			{
				return 0;
			}
			int result;
			if (int.TryParse(value.ToString(), out result))
			{
				return result;
			}
			double num;
			if (double.TryParse(value.ToString(), out num))
			{
				return (int)num;
			}
			return 0;
		}

		// Token: 0x06001172 RID: 4466 RVA: 0x0007FFA8 File Offset: 0x0007FFA8
		public static double ToDouble(object value)
		{
			if (value == null)
			{
				return 0.0;
			}
			double result;
			if (double.TryParse(value.ToString(), out result))
			{
				return result;
			}
			return 0.0;
		}

		// Token: 0x06001173 RID: 4467 RVA: 0x0007FFDC File Offset: 0x0007FFDC
		public static bool ToBoolean(object value)
		{
			bool flag;
			return value != null && bool.TryParse(value.ToString(), out flag) && flag;
		}
	}
}
