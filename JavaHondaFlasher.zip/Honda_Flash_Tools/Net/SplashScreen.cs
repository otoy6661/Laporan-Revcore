﻿using System;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000748 RID: 1864
	public partial class SplashScreen : Form
	{
	}
}
