﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000531 RID: 1329
	public partial class Form1 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000D1E RID: 3358 RVA: 0x0006217C File Offset: 0x0006217C
		[global::System.Diagnostics.DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && this.components != null)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000D1F RID: 3359 RVA: 0x000621BC File Offset: 0x000621BC
		[global::System.Diagnostics.DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			new global::System.ComponentModel.ComponentResourceManager(typeof(global::Honda_Flash_Tools.Net.Form1));
			this.OpenFileDialog1 = new global::System.Windows.Forms.OpenFileDialog();
			this.mainPanel = new global::System.Windows.Forms.Panel();
			this.btnAbout = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.btnSupport = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.btnCorrection = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.btnOpenFile = new global::Honda_Flash_Tools.Net.RoundedButton();
			this.lblStatus = new global::System.Windows.Forms.Label();
			this.PictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.TextBox2 = new global::System.Windows.Forms.TextBox();
			this.lblECMRegion = new global::System.Windows.Forms.Label();
			this.lblECMModel = new global::System.Windows.Forms.Label();
			this.lblFileSize = new global::System.Windows.Forms.Label();
			this.lblMCU = new global::System.Windows.Forms.Label();
			this.lblPartNumber = new global::System.Windows.Forms.Label();
			this.lblBikeMaker = new global::System.Windows.Forms.Label();
			this.txtIDRegion = new global::System.Windows.Forms.TextBox();
			this.txtIDModel = new global::System.Windows.Forms.TextBox();
			this.txtSize = new global::System.Windows.Forms.TextBox();
			this.txtMCU = new global::System.Windows.Forms.TextBox();
			this.txtTipeEcu = new global::System.Windows.Forms.TextBox();
			this.txtMotor = new global::System.Windows.Forms.TextBox();
			this.TextBox1 = new global::System.Windows.Forms.TextBox();
			this.lblHonda = new global::System.Windows.Forms.Label();
			this.lblJavaTech = new global::System.Windows.Forms.Label();
			this.mainPanel.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.PictureBox1).BeginInit();
			base.SuspendLayout();
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.BackColor = global::Honda_Flash_Tools.Net.Form1.BgBase;
			base.ClientSize = new global::System.Drawing.Size(600, 460);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "Form1";
			base.Padding = new global::System.Windows.Forms.Padding(4);
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			base.Text = "KZR Shindengen Bin Validator";
			base.TopMost = true;
			base.TransparencyKey = global::System.Drawing.Color.Empty;
			this.mainPanel.BackColor = global::System.Drawing.Color.Transparent;
			this.mainPanel.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.mainPanel.Font = new global::System.Drawing.Font("Segoe UI", 8.5f, global::System.Drawing.FontStyle.Regular);
			this.mainPanel.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextPrimary;
			this.mainPanel.Location = new global::System.Drawing.Point(4, 4);
			this.mainPanel.Name = "mainPanel";
			this.mainPanel.TabIndex = 0;
			this.mainPanel.Padding = new global::System.Windows.Forms.Padding(24);
			base.Controls.Add(this.mainPanel);
			this.lblHonda.Text = "HONDA";
			this.lblHonda.Font = new global::System.Drawing.Font("Impact", 20f, global::System.Drawing.FontStyle.Italic);
			this.lblHonda.ForeColor = global::Honda_Flash_Tools.Net.Form1.Accent;
			this.lblHonda.BackColor = global::System.Drawing.Color.Transparent;
			this.lblHonda.AutoSize = true;
			this.lblHonda.Location = new global::System.Drawing.Point(24, 22);
			this.lblJavaTech.Text = "FLASH ECU";
			this.lblJavaTech.Font = new global::System.Drawing.Font("Impact", 20f, global::System.Drawing.FontStyle.Italic);
			this.lblJavaTech.ForeColor = global::Honda_Flash_Tools.Net.Form1.AccentSoft;
			this.lblJavaTech.BackColor = global::System.Drawing.Color.Transparent;
			this.lblJavaTech.AutoSize = true;
			this.lblJavaTech.Location = new global::System.Drawing.Point(110, 22);
			this.btnSupport.AutoSize = false;
			this.btnSupport.BackColor = global::Honda_Flash_Tools.Net.Form1.BgSurface;
			this.btnSupport.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.btnSupport.Font = new global::System.Drawing.Font("Segoe UI", 7.5f, global::System.Drawing.FontStyle.Bold);
			this.btnSupport.ForeColor = global::Honda_Flash_Tools.Net.Form1.AccentSoft;
			this.btnSupport.Location = new global::System.Drawing.Point(390, 24);
			this.btnSupport.Name = "btnSupport";
			this.btnSupport.Size = new global::System.Drawing.Size(80, 26);
			this.btnSupport.TabIndex = 25;
			this.btnSupport.Text = "SUPPORT";
			this.btnSupport.CornerRadius = 13;
			this.btnSupport.BorderColor = global::Honda_Flash_Tools.Net.Form1.BorderSoft;
			this.btnSupport.BorderWidth = 1f;
			this.btnSupport.HoverBackColor = global::System.Drawing.Color.FromArgb(0, 60, 70);
			this.btnSupport.Click += new global::System.EventHandler(this.btnSupport_Click);
			this.btnAbout.AutoSize = false;
			this.btnAbout.BackColor = global::Honda_Flash_Tools.Net.Form1.BgSurface;
			this.btnAbout.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.btnAbout.Font = new global::System.Drawing.Font("Segoe UI", 7.5f, global::System.Drawing.FontStyle.Bold);
			this.btnAbout.ForeColor = global::Honda_Flash_Tools.Net.Form1.AccentSoft;
			this.btnAbout.Location = new global::System.Drawing.Point(478, 24);
			this.btnAbout.Name = "btnAbout";
			this.btnAbout.Size = new global::System.Drawing.Size(80, 26);
			this.btnAbout.TabIndex = 26;
			this.btnAbout.Text = "ABOUT";
			this.btnAbout.CornerRadius = 13;
			this.btnAbout.BorderColor = global::Honda_Flash_Tools.Net.Form1.BorderSoft;
			this.btnAbout.BorderWidth = 1f;
			this.btnAbout.HoverBackColor = global::System.Drawing.Color.FromArgb(0, 60, 70);
			this.btnAbout.Click += new global::System.EventHandler(this.btnAbout_Click);
			this.PictureBox1.BackColor = global::Honda_Flash_Tools.Net.Form1.BgBase;
			this.PictureBox1.Location = new global::System.Drawing.Point(24, 62);
			this.PictureBox1.Name = "PictureBox1";
			this.PictureBox1.Size = new global::System.Drawing.Size(534, 26);
			this.PictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.PictureBox1.TabIndex = 18;
			this.PictureBox1.TabStop = false;
			global::System.Drawing.Bitmap image = new global::System.Drawing.Bitmap(534, 26);
			using (global::System.Drawing.Graphics graphics = global::System.Drawing.Graphics.FromImage(image))
			{
				graphics.SmoothingMode = global::System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
				graphics.Clear(global::Honda_Flash_Tools.Net.Form1.BgBase);
				graphics.DrawString("KZR CHECKSUM VALIDATOR", new global::System.Drawing.Font("Segoe UI", 9.5f, global::System.Drawing.FontStyle.Bold), new global::System.Drawing.SolidBrush(global::Honda_Flash_Tools.Net.Form1.AccentSoft), 0f, 4f);
				graphics.DrawString("•  Shindengen ECU bin file validation", new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Regular), new global::System.Drawing.SolidBrush(global::Honda_Flash_Tools.Net.Form1.TextMuted), 210f, 6f);
			}
			this.PictureBox1.Image = image;
			this.TextBox1.BackColor = global::Honda_Flash_Tools.Net.Form1.BgInput;
			this.TextBox1.Font = new global::System.Drawing.Font("Consolas", 8.5f);
			this.TextBox1.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextPrimary;
			this.TextBox1.Location = new global::System.Drawing.Point(24, 104);
			this.TextBox1.MaxLength = 32767;
			this.TextBox1.Name = "TextBox1";
			this.TextBox1.ReadOnly = false;
			this.TextBox1.Size = new global::System.Drawing.Size(414, 22);
			this.TextBox1.TabIndex = 0;
			this.TextBox1.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Left;
			this.TextBox1.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.btnOpenFile.BackColor = global::Honda_Flash_Tools.Net.Form1.Accent;
			this.btnOpenFile.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.btnOpenFile.Font = new global::System.Drawing.Font("Segoe UI", 8f, global::System.Drawing.FontStyle.Bold);
			this.btnOpenFile.ForeColor = global::System.Drawing.Color.FromArgb(10, 15, 25);
			this.btnOpenFile.Location = new global::System.Drawing.Point(444, 103);
			this.btnOpenFile.Name = "btnOpenFile";
			this.btnOpenFile.Size = new global::System.Drawing.Size(114, 26);
			this.btnOpenFile.TabIndex = 20;
			this.btnOpenFile.Text = "\ud83d\udcc2  OPEN FILE";
			this.btnOpenFile.CornerRadius = 13;
			this.btnOpenFile.BorderColor = global::System.Drawing.Color.Transparent;
			this.btnOpenFile.BorderWidth = 0f;
			this.btnOpenFile.HoverBackColor = global::System.Drawing.Color.FromArgb(0, 200, 230);
			this.btnOpenFile.Click += new global::System.EventHandler(this.btnOpenFile_Click);
			global::System.Drawing.Font font = new global::System.Drawing.Font("Segoe UI", 7.5f, global::System.Drawing.FontStyle.Bold);
			global::System.Drawing.Font font2 = new global::System.Drawing.Font("Consolas", 8.5f, global::System.Drawing.FontStyle.Bold);
			this.lblBikeMaker.AutoSize = false;
			this.lblBikeMaker.BackColor = global::System.Drawing.Color.Transparent;
			this.lblBikeMaker.Font = font;
			this.lblBikeMaker.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextMuted;
			this.lblBikeMaker.Location = new global::System.Drawing.Point(24, 158);
			this.lblBikeMaker.Name = "lblBikeMaker";
			this.lblBikeMaker.Size = new global::System.Drawing.Size(70, 14);
			this.lblBikeMaker.TabIndex = 8;
			this.lblBikeMaker.Text = "BIKE";
			this.txtMotor.BackColor = global::Honda_Flash_Tools.Net.Form1.BgInput;
			this.txtMotor.Font = font2;
			this.txtMotor.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextPrimary;
			this.txtMotor.ImeMode = global::System.Windows.Forms.ImeMode.NoControl;
			this.txtMotor.Location = new global::System.Drawing.Point(100, 155);
			this.txtMotor.MaxLength = 32767;
			this.txtMotor.Name = "txtMotor";
			this.txtMotor.ReadOnly = true;
			this.txtMotor.Size = new global::System.Drawing.Size(150, 22);
			this.txtMotor.TabIndex = 2;
			this.txtMotor.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Left;
			this.txtMotor.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblPartNumber.AutoSize = false;
			this.lblPartNumber.BackColor = global::System.Drawing.Color.Transparent;
			this.lblPartNumber.Font = font;
			this.lblPartNumber.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextMuted;
			this.lblPartNumber.Location = new global::System.Drawing.Point(24, 192);
			this.lblPartNumber.Name = "lblPartNumber";
			this.lblPartNumber.Size = new global::System.Drawing.Size(70, 14);
			this.lblPartNumber.TabIndex = 9;
			this.lblPartNumber.Text = "PART NO";
			this.txtTipeEcu.BackColor = global::Honda_Flash_Tools.Net.Form1.BgInput;
			this.txtTipeEcu.Font = font2;
			this.txtTipeEcu.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextPrimary;
			this.txtTipeEcu.Location = new global::System.Drawing.Point(100, 189);
			this.txtTipeEcu.MaxLength = 32767;
			this.txtTipeEcu.Name = "txtTipeEcu";
			this.txtTipeEcu.ReadOnly = true;
			this.txtTipeEcu.Size = new global::System.Drawing.Size(150, 22);
			this.txtTipeEcu.TabIndex = 3;
			this.txtTipeEcu.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Left;
			this.txtTipeEcu.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblFileSize.AutoSize = false;
			this.lblFileSize.BackColor = global::System.Drawing.Color.Transparent;
			this.lblFileSize.Font = font;
			this.lblFileSize.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextMuted;
			this.lblFileSize.Location = new global::System.Drawing.Point(24, 226);
			this.lblFileSize.Name = "lblFileSize";
			this.lblFileSize.Size = new global::System.Drawing.Size(70, 14);
			this.lblFileSize.TabIndex = 11;
			this.lblFileSize.Text = "SIZE";
			this.txtSize.BackColor = global::Honda_Flash_Tools.Net.Form1.BgInput;
			this.txtSize.Font = font2;
			this.txtSize.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextPrimary;
			this.txtSize.Location = new global::System.Drawing.Point(100, 223);
			this.txtSize.MaxLength = 32767;
			this.txtSize.Name = "txtSize";
			this.txtSize.ReadOnly = true;
			this.txtSize.Size = new global::System.Drawing.Size(150, 22);
			this.txtSize.TabIndex = 5;
			this.txtSize.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Left;
			this.txtSize.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblMCU.AutoSize = false;
			this.lblMCU.BackColor = global::System.Drawing.Color.Transparent;
			this.lblMCU.Font = font;
			this.lblMCU.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextMuted;
			this.lblMCU.Location = new global::System.Drawing.Point(310, 158);
			this.lblMCU.Name = "lblMCU";
			this.lblMCU.Size = new global::System.Drawing.Size(70, 14);
			this.lblMCU.TabIndex = 10;
			this.lblMCU.Text = "MCU";
			this.txtMCU.BackColor = global::Honda_Flash_Tools.Net.Form1.BgInput;
			this.txtMCU.Font = font2;
			this.txtMCU.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextPrimary;
			this.txtMCU.Location = new global::System.Drawing.Point(400, 155);
			this.txtMCU.MaxLength = 32767;
			this.txtMCU.Name = "txtMCU";
			this.txtMCU.ReadOnly = true;
			this.txtMCU.Size = new global::System.Drawing.Size(158, 22);
			this.txtMCU.TabIndex = 4;
			this.txtMCU.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Left;
			this.txtMCU.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblECMModel.AutoSize = false;
			this.lblECMModel.BackColor = global::System.Drawing.Color.Transparent;
			this.lblECMModel.Font = font;
			this.lblECMModel.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextMuted;
			this.lblECMModel.Location = new global::System.Drawing.Point(310, 192);
			this.lblECMModel.Name = "lblECMModel";
			this.lblECMModel.Size = new global::System.Drawing.Size(80, 14);
			this.lblECMModel.TabIndex = 12;
			this.lblECMModel.Text = "ECM MODEL";
			this.txtIDModel.BackColor = global::Honda_Flash_Tools.Net.Form1.BgInput;
			this.txtIDModel.Font = font2;
			this.txtIDModel.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextPrimary;
			this.txtIDModel.Location = new global::System.Drawing.Point(400, 189);
			this.txtIDModel.MaxLength = 32767;
			this.txtIDModel.Name = "txtIDModel";
			this.txtIDModel.ReadOnly = true;
			this.txtIDModel.Size = new global::System.Drawing.Size(158, 22);
			this.txtIDModel.TabIndex = 6;
			this.txtIDModel.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Left;
			this.txtIDModel.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblECMRegion.AutoSize = false;
			this.lblECMRegion.BackColor = global::System.Drawing.Color.Transparent;
			this.lblECMRegion.Font = font;
			this.lblECMRegion.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextMuted;
			this.lblECMRegion.Location = new global::System.Drawing.Point(310, 226);
			this.lblECMRegion.Name = "lblECMRegion";
			this.lblECMRegion.Size = new global::System.Drawing.Size(80, 14);
			this.lblECMRegion.TabIndex = 13;
			this.lblECMRegion.Text = "ECM REGION";
			this.txtIDRegion.BackColor = global::Honda_Flash_Tools.Net.Form1.BgInput;
			this.txtIDRegion.Font = font2;
			this.txtIDRegion.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextPrimary;
			this.txtIDRegion.Location = new global::System.Drawing.Point(400, 223);
			this.txtIDRegion.MaxLength = 32767;
			this.txtIDRegion.Name = "txtIDRegion";
			this.txtIDRegion.ReadOnly = true;
			this.txtIDRegion.Size = new global::System.Drawing.Size(158, 22);
			this.txtIDRegion.TabIndex = 7;
			this.txtIDRegion.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Left;
			this.txtIDRegion.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblStatus.AutoSize = false;
			this.lblStatus.BackColor = global::System.Drawing.Color.Transparent;
			this.lblStatus.Font = new global::System.Drawing.Font("Segoe UI", 8.5f, global::System.Drawing.FontStyle.Bold);
			this.lblStatus.ForeColor = global::Honda_Flash_Tools.Net.Form1.AccentSoft;
			this.lblStatus.Location = new global::System.Drawing.Point(24, 268);
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Size = new global::System.Drawing.Size(534, 22);
			this.lblStatus.TabIndex = 19;
			this.lblStatus.Text = "⏺  Ready — open a bin file to validate";
			this.lblStatus.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.lblStatus.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.TextBox2.BackColor = global::Honda_Flash_Tools.Net.Form1.BorderSoft;
			this.TextBox2.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.TextBox2.Enabled = false;
			this.TextBox2.Location = new global::System.Drawing.Point(24, 300);
			this.TextBox2.Name = "TextBox2";
			this.TextBox2.Size = new global::System.Drawing.Size(534, 1);
			this.TextBox2.TabIndex = 15;
			this.btnCorrection.BackColor = global::Honda_Flash_Tools.Net.Form1.BgSurface;
			this.btnCorrection.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.btnCorrection.Enabled = false;
			this.btnCorrection.Font = new global::System.Drawing.Font("Segoe UI", 10f, global::System.Drawing.FontStyle.Bold);
			this.btnCorrection.ForeColor = global::Honda_Flash_Tools.Net.Form1.Accent;
			this.btnCorrection.Location = new global::System.Drawing.Point(24, 320);
			this.btnCorrection.Name = "btnCorrection";
			this.btnCorrection.Size = new global::System.Drawing.Size(534, 46);
			this.btnCorrection.TabIndex = 21;
			this.btnCorrection.Text = "⚡  CORRECT CHECKSUM";
			this.btnCorrection.CornerRadius = 12;
			this.btnCorrection.BorderColor = global::Honda_Flash_Tools.Net.Form1.Accent;
			this.btnCorrection.BorderWidth = 1f;
			this.btnCorrection.HoverBackColor = global::System.Drawing.Color.FromArgb(0, 60, 70);
			this.btnCorrection.Click += new global::System.EventHandler(this.btnCorrection_Click);
			global::System.Windows.Forms.Label label = new global::System.Windows.Forms.Label();
			label.AutoSize = false;
			label.BackColor = global::System.Drawing.Color.Transparent;
			label.Font = new global::System.Drawing.Font("Segoe UI", 7.5f);
			label.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextMuted;
			label.Location = new global::System.Drawing.Point(24, 380);
			label.Size = new global::System.Drawing.Size(534, 16);
			label.Text = "© JAVA TECH ELEGANT  •  v1.0";
			label.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			global::System.Windows.Forms.Label label2 = new global::System.Windows.Forms.Label();
			label2.AutoSize = false;
			label2.BackColor = global::System.Drawing.Color.Transparent;
			label2.Font = new global::System.Drawing.Font("Segoe UI", 7f, global::System.Drawing.FontStyle.Italic);
			label2.ForeColor = global::Honda_Flash_Tools.Net.Form1.TextMuted;
			label2.Location = new global::System.Drawing.Point(24, 398);
			label2.Size = new global::System.Drawing.Size(534, 16);
			label2.Text = "ESC to close  •  Drag header to move";
			label2.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.mainPanel.Controls.Add(this.lblHonda);
			this.mainPanel.Controls.Add(this.lblJavaTech);
			this.mainPanel.Controls.Add(this.btnAbout);
			this.mainPanel.Controls.Add(this.btnSupport);
			this.mainPanel.Controls.Add(this.PictureBox1);
			this.mainPanel.Controls.Add(this.TextBox1);
			this.mainPanel.Controls.Add(this.btnOpenFile);
			this.mainPanel.Controls.Add(this.lblBikeMaker);
			this.mainPanel.Controls.Add(this.txtMotor);
			this.mainPanel.Controls.Add(this.lblPartNumber);
			this.mainPanel.Controls.Add(this.txtTipeEcu);
			this.mainPanel.Controls.Add(this.lblFileSize);
			this.mainPanel.Controls.Add(this.txtSize);
			this.mainPanel.Controls.Add(this.lblMCU);
			this.mainPanel.Controls.Add(this.txtMCU);
			this.mainPanel.Controls.Add(this.lblECMModel);
			this.mainPanel.Controls.Add(this.txtIDModel);
			this.mainPanel.Controls.Add(this.lblECMRegion);
			this.mainPanel.Controls.Add(this.txtIDRegion);
			this.mainPanel.Controls.Add(this.lblStatus);
			this.mainPanel.Controls.Add(this.TextBox2);
			this.mainPanel.Controls.Add(this.btnCorrection);
			this.mainPanel.Controls.Add(label);
			this.mainPanel.Controls.Add(label2);
			global::System.Windows.Forms.Label lblPathPlaceholder = new global::System.Windows.Forms.Label();
			lblPathPlaceholder.Name = "lblPathPlaceholder";
			lblPathPlaceholder.Text = "No file selected...";
			lblPathPlaceholder.Font = new global::System.Drawing.Font("Consolas", 8.5f, global::System.Drawing.FontStyle.Italic);
			lblPathPlaceholder.ForeColor = global::Honda_Flash_Tools.Net.Form1.PlaceholderColor;
			lblPathPlaceholder.BackColor = global::Honda_Flash_Tools.Net.Form1.BgInput;
			lblPathPlaceholder.AutoSize = false;
			lblPathPlaceholder.Location = new global::System.Drawing.Point(27, 106);
			lblPathPlaceholder.Size = new global::System.Drawing.Size(408, 18);
			lblPathPlaceholder.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			lblPathPlaceholder.Cursor = global::System.Windows.Forms.Cursors.IBeam;
			lblPathPlaceholder.Click += delegate(object s, global::System.EventArgs e)
			{
				this.TextBox1.Focus();
			};
			this.mainPanel.Controls.Add(lblPathPlaceholder);
			lblPathPlaceholder.BringToFront();
			this.TextBox1.TextChanged += delegate(object s, global::System.EventArgs e)
			{
				lblPathPlaceholder.Visible = string.IsNullOrEmpty(this.TextBox1.Text);
			};
			this.mainPanel.ResumeLayout(false);
			this.mainPanel.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.PictureBox1).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x04001160 RID: 4448
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04001161 RID: 4449
		private global::System.Windows.Forms.Panel mainPanel;

		// Token: 0x04001162 RID: 4450
		private global::System.Windows.Forms.Label lblStatus;

		// Token: 0x04001163 RID: 4451
		private global::System.Windows.Forms.PictureBox PictureBox1;

		// Token: 0x04001164 RID: 4452
		private global::System.Windows.Forms.TextBox TextBox2;

		// Token: 0x04001165 RID: 4453
		private global::System.Windows.Forms.Label lblECMRegion;

		// Token: 0x04001166 RID: 4454
		private global::System.Windows.Forms.Label lblECMModel;

		// Token: 0x04001167 RID: 4455
		private global::System.Windows.Forms.Label lblFileSize;

		// Token: 0x04001168 RID: 4456
		private global::System.Windows.Forms.Label lblMCU;

		// Token: 0x04001169 RID: 4457
		private global::System.Windows.Forms.Label lblPartNumber;

		// Token: 0x0400116A RID: 4458
		private global::System.Windows.Forms.Label lblBikeMaker;

		// Token: 0x0400116B RID: 4459
		private global::System.Windows.Forms.TextBox txtIDRegion;

		// Token: 0x0400116C RID: 4460
		private global::System.Windows.Forms.TextBox txtIDModel;

		// Token: 0x0400116D RID: 4461
		private global::System.Windows.Forms.TextBox txtSize;

		// Token: 0x0400116E RID: 4462
		private global::System.Windows.Forms.TextBox txtMCU;

		// Token: 0x0400116F RID: 4463
		private global::System.Windows.Forms.TextBox txtTipeEcu;

		// Token: 0x04001170 RID: 4464
		private global::System.Windows.Forms.TextBox txtMotor;

		// Token: 0x04001171 RID: 4465
		private global::System.Windows.Forms.TextBox TextBox1;

		// Token: 0x04001172 RID: 4466
		private global::System.Windows.Forms.Label lblHonda;

		// Token: 0x04001173 RID: 4467
		private global::System.Windows.Forms.Label lblJavaTech;

		// Token: 0x04001174 RID: 4468
		private global::System.Windows.Forms.OpenFileDialog OpenFileDialog1;

		// Token: 0x04001175 RID: 4469
		private static readonly global::System.Drawing.Color BgBase = global::System.Drawing.Color.FromArgb(15, 17, 26);

		// Token: 0x04001176 RID: 4470
		private static readonly global::System.Drawing.Color BgSurface = global::System.Drawing.Color.FromArgb(24, 27, 38);

		// Token: 0x04001177 RID: 4471
		private static readonly global::System.Drawing.Color BgInput = global::System.Drawing.Color.FromArgb(32, 36, 50);

		// Token: 0x04001178 RID: 4472
		private static readonly global::System.Drawing.Color BorderSoft = global::System.Drawing.Color.FromArgb(48, 54, 72);

		// Token: 0x04001179 RID: 4473
		private static readonly global::System.Drawing.Color Accent = global::System.Drawing.Color.FromArgb(0, 229, 255);

		// Token: 0x0400117A RID: 4474
		private static readonly global::System.Drawing.Color AccentSoft = global::System.Drawing.Color.FromArgb(120, 200, 230);

		// Token: 0x0400117B RID: 4475
		private static readonly global::System.Drawing.Color TextPrimary = global::System.Drawing.Color.FromArgb(235, 240, 250);

		// Token: 0x0400117C RID: 4476
		private static readonly global::System.Drawing.Color TextMuted = global::System.Drawing.Color.FromArgb(150, 160, 180);

		// Token: 0x0400117D RID: 4477
		private static readonly global::System.Drawing.Color PlaceholderColor = global::System.Drawing.Color.FromArgb(110, 120, 140);

		// Token: 0x04001181 RID: 4481
		private global::Honda_Flash_Tools.Net.RoundedButton btnAbout;

		// Token: 0x04001182 RID: 4482
		private global::Honda_Flash_Tools.Net.RoundedButton btnSupport;

		// Token: 0x04001183 RID: 4483
		private global::Honda_Flash_Tools.Net.RoundedButton btnCorrection;

		// Token: 0x04001184 RID: 4484
		private global::Honda_Flash_Tools.Net.RoundedButton btnOpenFile;
	}
}
