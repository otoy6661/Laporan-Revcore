﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000652 RID: 1618
	public partial class BlurOverlay : Form
	{
		// Token: 0x06000F9A RID: 3994 RVA: 0x0006FA04 File Offset: 0x0006FA04
		public BlurOverlay(Form parent, int blurRadius = 8, bool useUnsafeBlur = true)
		{
			this._parent = parent;
			this._blurRadius = blurRadius;
			if (parent == null)
			{
				throw new ArgumentNullException("parent");
			}
			Bitmap bitmap = null;
			try
			{
				bitmap = BlurHelper.CaptureForm(parent);
				if (useUnsafeBlur)
				{
					this._blurred = BlurHelper.BoxBlur(bitmap, blurRadius);
				}
				else
				{
					this._blurred = BlurHelper.SimpleBlur(bitmap, blurRadius);
				}
			}
			finally
			{
				if (bitmap != null)
				{
					bitmap.Dispose();
				}
			}
			base.FormBorderStyle = FormBorderStyle.None;
			base.StartPosition = FormStartPosition.Manual;
			base.Bounds = parent.Bounds;
			base.ShowInTaskbar = false;
			base.TopMost = false;
			base.ControlBox = false;
			base.MinimizeBox = false;
			base.MaximizeBox = false;
			this.DoubleBuffered = true;
			base.TabStop = false;
			parent.Move += this.Parent_Move;
			parent.Resize += this.Parent_Resize;
		}

		// Token: 0x06000F9B RID: 3995 RVA: 0x0006FAE8 File Offset: 0x0006FAE8
		private void Parent_Move(object sender, EventArgs e)
		{
			try
			{
				if (!base.IsDisposed && !base.Disposing)
				{
					if (this._parent != null && !this._parent.IsDisposed && !this._parent.Disposing)
					{
						base.Bounds = this._parent.Bounds;
						this.RefreshBlur();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000F9C RID: 3996 RVA: 0x0006FAE8 File Offset: 0x0006FAE8
		private void Parent_Resize(object sender, EventArgs e)
		{
			try
			{
				if (!base.IsDisposed && !base.Disposing)
				{
					if (this._parent != null && !this._parent.IsDisposed && !this._parent.Disposing)
					{
						base.Bounds = this._parent.Bounds;
						this.RefreshBlur();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000F9D RID: 3997 RVA: 0x0006FB58 File Offset: 0x0006FB58
		private void RefreshBlur()
		{
			try
			{
				if (!base.IsDisposed && !base.Disposing)
				{
					if (this._parent != null && !this._parent.IsDisposed && !this._parent.Disposing)
					{
						Bitmap blurred = this._blurred;
						this._blurred = null;
						if (blurred != null)
						{
							try
							{
								blurred.Dispose();
							}
							catch
							{
							}
						}
						Bitmap bitmap = null;
						try
						{
							bitmap = BlurHelper.CaptureForm(this._parent);
							this._blurred = BlurHelper.BoxBlur(bitmap, this._blurRadius);
						}
						finally
						{
							if (bitmap != null)
							{
								bitmap.Dispose();
							}
						}
						base.Invalidate();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000F9E RID: 3998 RVA: 0x0006FC18 File Offset: 0x0006FC18
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			try
			{
				if (this._blurred != null)
				{
					e.Graphics.DrawImage(this._blurred, 0, 0);
				}
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(60, 0, 0, 0)))
				{
					e.Graphics.FillRectangle(solidBrush, base.ClientRectangle);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000F9F RID: 3999 RVA: 0x0006FC98 File Offset: 0x0006FC98
		protected override void OnFormClosed(FormClosedEventArgs e)
		{
			try
			{
				if (this._parent != null && !this._parent.IsDisposed)
				{
					this._parent.Move -= this.Parent_Move;
					this._parent.Resize -= this.Parent_Resize;
				}
				if (this._blurred != null)
				{
					this._blurred.Dispose();
					this._blurred = null;
				}
			}
			catch
			{
			}
			base.OnFormClosed(e);
		}

		// Token: 0x06000FA0 RID: 4000 RVA: 0x0006FD20 File Offset: 0x0006FD20
		public void SetTopMost(bool topMost)
		{
			try
			{
				if (!base.IsDisposed && !base.Disposing)
				{
					base.TopMost = topMost;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000FA1 RID: 4001 RVA: 0x0000A9F1 File Offset: 0x0000A9F1
		protected override void WndProc(ref Message m)
		{
			if (m.Msg == 132)
			{
				m.Result = new IntPtr(-1);
				return;
			}
			base.WndProc(ref m);
		}

		// Token: 0x06000FA2 RID: 4002 RVA: 0x000026F4 File Offset: 0x000026F4
		protected override void OnActivated(EventArgs e)
		{
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06000FA3 RID: 4003 RVA: 0x0000AA14 File Offset: 0x0000AA14
		protected override CreateParams CreateParams
		{
			get
			{
				CreateParams createParams = base.CreateParams;
				createParams.ExStyle |= 134217888;
				return createParams;
			}
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x06000FA4 RID: 4004 RVA: 0x0000AA2E File Offset: 0x0000AA2E
		protected override bool ShowWithoutActivation
		{
			get
			{
				return true;
			}
		}

		// Token: 0x04001485 RID: 5253
		private readonly Form _parent;

		// Token: 0x04001486 RID: 5254
		private Bitmap _blurred;

		// Token: 0x04001487 RID: 5255
		private const int WS_EX_TRANSPARENT = 32;

		// Token: 0x04001488 RID: 5256
		private const int WS_EX_NOACTIVATE = 134217728;

		// Token: 0x04001489 RID: 5257
		private const int WS_EX_TOOLWINDOW = 128;

		// Token: 0x0400148A RID: 5258
		private const int WM_NCHITTEST = 132;

		// Token: 0x0400148B RID: 5259
		private const int HTTRANSPARENT = -1;

		// Token: 0x0400148C RID: 5260
		private readonly int _blurRadius;
	}
}
