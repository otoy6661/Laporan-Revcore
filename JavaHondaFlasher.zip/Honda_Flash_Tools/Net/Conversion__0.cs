﻿using System;
using System.Globalization;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200074A RID: 1866
	public static class Conversion__0
	{
		// Token: 0x06001174 RID: 4468 RVA: 0x00080000 File Offset: 0x00080000
		public static double Val(string input)
		{
			if (string.IsNullOrEmpty(input))
			{
				return 0.0;
			}
			input = input.Trim();
			if (input.StartsWith("&H", StringComparison.OrdinalIgnoreCase))
			{
				string text = input.Substring(2);
				string text2 = "";
				foreach (char character in text)
				{
					if (!Uri.IsHexDigit(character))
					{
						break;
					}
					text2 += character.ToString();
				}
				long num;
				if (long.TryParse(text2, NumberStyles.HexNumber, null, out num))
				{
					return (double)num;
				}
				return 0.0;
			}
			else
			{
				if (input.StartsWith("&O", StringComparison.OrdinalIgnoreCase))
				{
					string value = input.Substring(2);
					try
					{
						return (double)Convert.ToInt64(value, 8);
					}
					catch
					{
						return 0.0;
					}
				}
				string text4 = "";
				bool flag = false;
				bool flag2 = false;
				foreach (char c in input)
				{
					if (char.IsDigit(c) || c == '.')
					{
						if (c == '.')
						{
							if (flag)
							{
								break;
							}
							flag = true;
						}
						text4 += c.ToString();
					}
					else if ((c == '-' || c == '+') && text4.Length == 0 && !flag2)
					{
						text4 += c.ToString();
						flag2 = true;
					}
					else if (text4.Length > 0)
					{
						break;
					}
				}
				double result;
				if (double.TryParse(text4, out result))
				{
					return result;
				}
				return 0.0;
			}
		}
	}
}
