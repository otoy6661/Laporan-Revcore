﻿namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200034A RID: 842
	public partial class CustomMessageBox__1 : global::System.Windows.Forms.Form
	{
	}
}
