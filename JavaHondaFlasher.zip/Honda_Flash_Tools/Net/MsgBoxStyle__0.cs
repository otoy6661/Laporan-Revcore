﻿using System;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x0200074C RID: 1868
	public enum MsgBoxStyle__0
	{
		// Token: 0x0400182C RID: 6188
		OkOnly,
		// Token: 0x0400182D RID: 6189
		OkCancel,
		// Token: 0x0400182E RID: 6190
		YesNo = 4,
		// Token: 0x0400182F RID: 6191
		YesNoCancel = 3,
		// Token: 0x04001830 RID: 6192
		Information = 64,
		// Token: 0x04001831 RID: 6193
		Warning = 48,
		// Token: 0x04001832 RID: 6194
		Critical = 16,
		// Token: 0x04001833 RID: 6195
		Question = 32
	}
}
