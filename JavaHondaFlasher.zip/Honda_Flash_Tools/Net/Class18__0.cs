﻿using System;
using System.Globalization;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000753 RID: 1875
	public static class Class18__0
	{
		// Token: 0x06001194 RID: 4500 RVA: 0x00080370 File Offset: 0x00080370
		public static double smethod_0(string input)
		{
			if (string.IsNullOrEmpty(input))
			{
				return 0.0;
			}
			long num;
			if (long.TryParse(input, NumberStyles.HexNumber, null, out num))
			{
				return (double)num;
			}
			double result;
			if (double.TryParse(input, out result))
			{
				return result;
			}
			return 0.0;
		}
	}
}
