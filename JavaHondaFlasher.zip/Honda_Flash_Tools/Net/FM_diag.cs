﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO.Ports;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Honda_Flash_Tools.Net
{
	// Token: 0x02000756 RID: 1878
	public partial class FM_diag : Form
	{
		// Token: 0x060011B2 RID: 4530 RVA: 0x00081920 File Offset: 0x00081920
		public FM_diag()
		{
			this.string_4 = "7205710018020F7100";
			this.string_5 = "";
			this.string_10 = new string[51];
			this.string_15 = new string[31];
			this.int_5 = 0;
			this.int_6 = 0;
			this.bool_4 = false;
			this.byte_2 = new byte[7];
			this.byte_3 = new byte[7];
			this.byte_4 = new byte[7];
			this.byte_5 = new byte[7];
			this.bool_5 = new bool[31];
			this.bool_6 = false;
			this.bool_7 = false;
			this.bool_8 = true;
			this.ChartTPS = new CustomChart__0();
			this.ChartVoltage = new CustomChart__0();
			this.ChartSensor = new CustomChart__0();
			this.InitializeComponent();
			this.method_72();
		}

		// Token: 0x060011B3 RID: 4531 RVA: 0x00081A08 File Offset: 0x00081A08
		private void method_72()
		{
			this.string_10[2] = "\r\nTIDAK TERHUBUNG: \r\n1. Colokkan perangkat ke port usb\r\n2. Tekan tombol 'Hubungkan'\r\n";
			this.string_10[3] = "Remap parameter penyiapan Alat... Mohon tunggu 30 detik\r\n";
			this.string_10[4] = "Mulai hubungkan ECM. Hidupkan Kunci Kontak.\r\n";
			this.string_10[5] = "Koneksi Gagal. Harap periksa daya Aki 12V. OFF/ON Kontak 10s\r\n";
			this.string_10[6] = "ECM TIDAK DIKETAHUI ATAU KOSONG\r\nHUBUNGI DOKTER LAIN!";
			this.string_10[7] = "Hubungkan ECM ke Remap...\r\n";
			this.string_10[8] = "Sambungkan ECM: Oke. Mohon tunggu 14 detik\r\n";
			this.string_10[9] = "Gagal terhubung. OFF/ON Kontak 10s\r\n";
			this.string_10[10] = "UMPAN BALIK YANG SALAH. ECM TIDAK DUKUNGAN\r\nPLS HUBUNGI AUTOSHOP UNTUK MEMPERBARUI";
			this.string_10[11] = "Penghapusan Data: ...\r\n";
			this.string_10[12] = "Hapus ECM x1: Selesai\r\n";
			this.string_10[13] = "Hapus ECM x2: Selesai\r\n";
			this.string_10[14] = "Tidak mungkin menghapus data. OFF/ON Kontak 10s lalu sambungkan lagi\r\n";
			this.string_10[15] = "TIDAK SUKSES. OFF/ON Kontak 10s lalu sambungkan lagi";
			this.string_10[16] = "Menulis data...\r\n";
			this.string_10[18] = "Selesai Remap ECM!\r\n";
			this.string_10[19] = "Selesai Remap ECM. OFF/ON Kunci Kontak 10s dan Reset ECM.";
			this.string_10[20] = "TULIS TIDAK SUKSES\r\n";
			this.string_10[21] = "ECM Putus atau file ECM MAP salah. Harap periksa daya, Kline. OFF/ON Kontak 10s lalu sambungkan lagi\r\n";
			this.string_10[22] = "ECM Putus atau file ECM MAP salah. Harap periksa daya, Kline. OFF/ON Kontak 10s lalu sambungkan lagi";
			this.string_10[23] = "Ada versi perangkat lunak baru. Klik 'OK' untuk mengunduh.";
			this.string_10[24] = "ECM dalam mode Boot. Pilih file yang benar untuk memulihkan ECM!";
			this.string_10[25] = "Ukuran bin salah. Harap periksa jenis ECU: 48Kb, 56Kb atau 64Kb!";
			this.string_10[26] = "Mohon pilih jenis ECM: 48Kb, 56Kb, 64Kb sebelum program.";
			this.string_10[27] = "Tidak ada sensor MAP.";
			this.string_10[28] = "Tidak ada sensor Oksigen.";
			this.string_10[29] = "Tidak ada sensor IAT.";
			this.string_10[30] = "LARI..";
			this.string_10[0] = "TOLONG HUBUNGKAN MODULE REMAP KE KOMPUTER";
			this.string_10[1] = "HUBUNGKAN PERANGKAT USB ➤ SUKSES";
			this.string_10[31] = "MULAI";
			this.string_10[32] = "             Sensor Posisi Throttle (TPS)";
			this.string_10[33] = "             Kecepatan Mesin (RPM)";
			this.string_10[34] = "             Waktu Injeksi (INJ)";
			this.string_10[35] = "             Waktu Pengapian Maju (IGT)";
			this.string_10[36] = "             Suhu Pendingin Mesin (ECT)";
			this.string_10[37] = "             Tegangan Sensor Oksigen (O2)";
			this.string_10[38] = "             Tegangan baterai dan muatan (BAT)";
			this.string_10[39] = "             Rasio Bahan Bakar Udara (A/F)";
			this.string_10[45] = "             Manifold Absolute Pressure (MAP)";
			this.string_10[40] = "Selesai Penghapusan Data Eror Di ECM.";
			this.string_10[41] = "Reset ECM berhasil. OFF/ON Kunci Kontak dan jalankan mesin selama 10 menit";
			this.string_10[43] = "... N/A";
			this.string_10[46] = "Silakan pilih file terlebih dahulu!";
			this.string_10[47] = "Jenis ECM salah. Apakah Anda ingin melompat Remap Keihin Tab?";
			this.string_10[48] = "Jenis ECM salah. Apakah Anda ingin melompati Remap Shindengen Tab?";
			this.string_10[49] = "Koneksi internet terputus. Lompat lembut untuk menemukan Manual MOTOR";
			this.string_10[50] = "Catatan: Parameter referensi pada suhu mesin > 60 *C dan dalam mode jaminan";
		}

		// Token: 0x060011B5 RID: 4533 RVA: 0x000837C0 File Offset: 0x000837C0
		private void method_140()
		{
			checked
			{
				if (this.comGraphTPS.Items.Count < 3)
				{
					string[] array = new string[]
					{
						"TPS",
						"RPM",
						"INJ",
						"IGT",
						"ECT",
						"O2",
						"AcQuy - BAT",
						"A/F",
						"MAP"
					};
					for (int i = 0; i <= array.Length - 1; i++)
					{
						this.comGraphTPS.Items.Add(array[i]);
					}
					this.comGraphTPS.Text = Conversions__0.ToString(this.comGraphTPS.Items[0]);
				}
			}
		}

		// Token: 0x060011B6 RID: 4534 RVA: 0x00083878 File Offset: 0x00083878
		private void method_161()
		{
			this.bool_6 = false;
			this.bool_7 = false;
			this.dataviewLiveData.Rows.Clear();
			this.dataviewLiveData.Refresh();
			this.double_0 = 0.0;
			this.double_1 = 0.0;
			this.method_01();
			this.method_1111();
			this.method_134();
			this.method_25();
			this.method_96();
			this.Timer_0.Enabled = base.Enabled;
		}

		// Token: 0x060011B7 RID: 4535 RVA: 0x000838FC File Offset: 0x000838FC
		private void method_1()
		{
			FM_diag.CustomMessageBox__0.Show("CONTACT OFF WAIT 10 SECOND THEN ON \r\n FOR ECM RESET PROCESS \r\n By: PROGRAM HONDA KLINE", "HONDA FLASH PROGRAM TOOLS", MsgBoxStyle__0.OkOnly, MsgBoxStyle__0.Information);
			Thread.Sleep(1000);
			byte[] array = new byte[]
			{
				254,
				4,
				114,
				140
			};
			byte[] array2 = new byte[]
			{
				114,
				5,
				0,
				240,
				153
			};
			byte[] array3 = new byte[]
			{
				114,
				5,
				96,
				3,
				38
			};
			if (!this.SerialPort_0.IsOpen)
			{
				this.SerialPort_0.Open();
			}
			this.SerialPort_0.BaudRate = 10400;
			this.SerialPort_0.BreakState = false;
			Thread.Sleep(100);
			this.SerialPort_0.BreakState = true;
			Thread.Sleep(70);
			this.SerialPort_0.BreakState = false;
			this.SerialPort_0.Write(array, 0, array.Length);
			Thread.Sleep(30);
			this.SerialPort_0.Write(array2, 0, array2.Length);
			Thread.Sleep(30);
			this.SerialPort_0.ReadExisting();
			this.SerialPort_0.Write(array3, 0, array3.Length);
			Thread.Sleep(500);
			FM_diag.CustomMessageBox__0.Show("RESET ECM DONE\r\nCONTACT OFF WAIT 10 SECOND THEN ON \r\nby: PROGRAM HONDA KLINE", "HONDA FLASH PROGRAM TOOLS", MsgBoxStyle__0.OkOnly, MsgBoxStyle__0.Information);
			this.SerialPort_0.Close();
			this.bool_6 = false;
			this.bool_7 = false;
			this.dataviewLiveData.Rows.Clear();
			this.dataviewLiveData.Refresh();
			this.double_0 = 0.0;
			this.double_1 = 0.0;
			this.method_01();
			this.method_1111();
			this.method_134();
			this.method_25();
			this.method_96();
			this.Timer_0.Enabled = base.Enabled;
		}

		// Token: 0x060011B8 RID: 4536 RVA: 0x00083AA0 File Offset: 0x00083AA0
		private void method_141()
		{
			this.comboSensor.Items.Clear();
			this.comboVoltage.Items.Clear();
			string[] array = new string[]
			{
				"Kecepatan Mesin - RPM",
				"Posisi Throttle - TPS (*)",
				"Suhu Mesin - ECT (*C)",
				"Suhu Udara Asupan - IAT (*C)",
				"MAP Tekanan Mutlak Manifold (kPa)",
				"Rasio Bahan Bakar Udara A/F",
				"Aliran Bahan Bakar (%)",
				"Durasi injektor (ms)",
				"Pengapian maju (*)"
			};
			string[] array2 = new string[]
			{
				"Tegangan Baterai (V)",
				"Tegangan TPS (mV)",
				"Tegangan ECT (mV)",
				"Tegangan IAT (mV)",
				"Peta Tegangan (mV)",
				"Tegangan Sensor O2 (mV)",
				"Posisi Throttle - TPS (*)",
				"Suhu Mesin - ECT (*C)",
				"Suhu Udara Asupan - IAT (*C)",
				"Rasio Bahan Bakar Udara A/F",
				"Aliran Bahan Bakar (%)",
				"Durasi injektor (ms)",
				"Pengapian maju (*)"
			};
			checked
			{
				for (int i = 0; i <= array.Length - 1; i++)
				{
					this.comboSensor.Items.Add(array[i]);
				}
				for (int j = 0; j <= array2.Length - 1; j++)
				{
					this.comboVoltage.Items.Add(array2[j]);
				}
				this.comboSensor.Text = Conversions__0.ToString(this.comboSensor.Items[0]);
				this.comboVoltage.Text = Conversions__0.ToString(this.comboVoltage.Items[0]);
			}
		}

		// Token: 0x060011B9 RID: 4537 RVA: 0x00083C1C File Offset: 0x00083C1C
		private void method_128()
		{
			try
			{
				this.SerialPort_0.Write(this.byte_2, 0, this.byte_2.Length);
				Thread.Sleep(50);
				this.SerialPort_0.Write(this.byte_3, 0, this.byte_3.Length);
				Thread.Sleep(50);
				this.SerialPort_0.Write(this.byte_4, 0, this.byte_4.Length);
				Thread.Sleep(50);
				this.SerialPort_0.Write(this.byte_5, 0, this.byte_5.Length);
				Thread.Sleep(50);
				this.string_9 = null;
				this.method_11();
				if (this.int_3 == 1)
				{
					this.method_129(this.int_7, this.int_8);
				}
				else if (this.int_3 == 4)
				{
					this.method_130();
				}
				else if (this.int_3 == 7)
				{
					this.method_131();
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060011BA RID: 4538 RVA: 0x0000B9FD File Offset: 0x0000B9FD
		private void method_134()
		{
			this.Timer_2.Enabled = false;
			this.Timer_0.Enabled = false;
			Thread.Sleep(3000);
		}

		// Token: 0x060011BB RID: 4539 RVA: 0x00083D0C File Offset: 0x00083D0C
		private void method_142()
		{
			this.ChartSensor.Series[0].Points.Clear();
			this.ChartSensor.Series[0].Points.AddXY(0.0, 0.0);
			this.ChartSensor.Series[0].IsValueShownAsLabel = false;
			this.ChartSensor.Series[0].ChartType = 1;
			this.ChartSensor.ChartAreas[0].AxisX.Enabled = false;
			this.ChartSensor.ChartAreas[0].AxisX.Minimum = 0.0;
			this.ChartSensor.ChartAreas[0].AxisX.Maximum = 50.0;
			this.ChartSensor.ChartAreas[0].AxisX.Interval = 1.0;
			this.ChartSensor.Series[0].IsVisibleInLegend = false;
			this.ChartVoltage.Series[0].Points.Clear();
			this.ChartVoltage.Series[0].Points.AddXY(0.0, 0.0);
			this.ChartVoltage.Series[0].IsValueShownAsLabel = false;
			this.ChartVoltage.Series[0].ChartType = 1;
			this.ChartVoltage.ChartAreas[0].AxisX.Enabled = false;
			this.ChartVoltage.ChartAreas[0].AxisX.Minimum = 0.0;
			this.ChartVoltage.ChartAreas[0].AxisX.Maximum = 50.0;
			this.ChartVoltage.ChartAreas[0].AxisX.Interval = 1.0;
			this.ChartVoltage.Series[0].IsVisibleInLegend = false;
		}

		// Token: 0x060011BC RID: 4540 RVA: 0x00083F44 File Offset: 0x00083F44
		private void method_148()
		{
			this.int_7 = this.comboSensor.SelectedIndex;
			this.ChartVoltage.ChartAreas[0].AxisX.Enabled = false;
			this.ChartVoltage.ChartAreas[0].AxisX.Minimum = 0.0;
			this.ChartVoltage.ChartAreas[0].AxisX.Maximum = 50.0;
			this.ChartVoltage.ChartAreas[0].AxisX.Interval = 1.0;
			this.ChartSensor.ChartAreas[0].AxisX.Enabled = false;
			this.ChartSensor.ChartAreas[0].AxisX.Minimum = 0.0;
			this.ChartSensor.ChartAreas[0].AxisX.Maximum = 50.0;
			this.ChartSensor.ChartAreas[0].AxisX.Interval = 1.0;
			switch (this.int_7)
			{
			case 0:
				this.method_144(0, 14000, 1000, 2000);
				return;
			case 1:
				this.method_144(0, 80, 10, 5);
				return;
			case 2:
			case 3:
				this.method_144(-40, 180, 20, 60);
				return;
			case 4:
				this.method_144(0, 120, 20, 90);
				if (this.int_3 == 4)
				{
					Interaction__0.MsgBox(this.string_10[27], MsgBoxStyle__0.OkOnly, this.string_10[42]);
					return;
				}
				break;
			case 5:
				this.method_144(6, 20, 2, 15);
				if (this.int_3 == 7)
				{
					Interaction__0.MsgBox(this.string_10[28], MsgBoxStyle__0.OkOnly, this.string_10[42]);
					return;
				}
				break;
			case 6:
				this.method_144(-30, 30, 5, 0);
				if (this.int_3 == 7)
				{
					Interaction__0.MsgBox(this.string_10[28], MsgBoxStyle__0.OkOnly, this.string_10[42]);
					return;
				}
				break;
			case 7:
				this.method_144(0, 12, 2, 2);
				return;
			case 8:
				this.method_144(-10, 70, 10, 15);
				return;
			default:
				return;
			}
		}

		// Token: 0x060011BD RID: 4541 RVA: 0x00084188 File Offset: 0x00084188
		private void method_150()
		{
			this.int_9 = this.comGraphTPS.SelectedIndex;
			switch (this.int_9)
			{
			case 0:
				this.method_143(0, 80.0, 10.0, 10);
				this.lblGrapTPS.Text = this.string_10[32];
				return;
			case 1:
				this.method_143(0, 14000.0, 1000.0, 2000);
				this.lblGrapTPS.Text = this.string_10[33];
				return;
			case 2:
				this.method_143(0, 12.0, 2.0, 2);
				this.lblGrapTPS.Text = this.string_10[34];
				return;
			case 3:
				this.method_143(-10, 70.0, 10.0, 15);
				this.lblGrapTPS.Text = this.string_10[35];
				return;
			case 4:
				this.method_143(-40, 180.0, 20.0, 60);
				this.lblGrapTPS.Text = this.string_10[36];
				return;
			case 5:
				this.method_143(0, 1400.0, 200.0, 1400);
				this.lblGrapTPS.Text = this.string_10[37];
				if (this.int_3 == 7)
				{
					Interaction__0.MsgBox(this.string_10[28], MsgBoxStyle__0.OkOnly, this.string_10[42]);
					return;
				}
				break;
			case 6:
				this.method_143(0, 18.0, 2.0, 12);
				this.lblGrapTPS.Text = this.string_10[38];
				return;
			case 7:
				this.method_143(6, 20.0, 2.0, 15);
				this.lblGrapTPS.Text = this.string_10[39];
				if (this.int_3 == 7)
				{
					Interaction__0.MsgBox(this.string_10[28], MsgBoxStyle__0.OkOnly, this.string_10[42]);
					return;
				}
				break;
			case 8:
				this.method_143(0, 120.0, 20.0, 90);
				this.lblGrapTPS.Text = this.string_10[45];
				if (this.int_3 == 4)
				{
					Interaction__0.MsgBox(this.string_10[27], MsgBoxStyle__0.OkOnly, this.string_10[42]);
					return;
				}
				break;
			default:
				return;
			}
		}

		// Token: 0x060011BE RID: 4542 RVA: 0x000843F8 File Offset: 0x000843F8
		private void method_99()
		{
			try
			{
				this.SerialPort_0.Write(this.byte_2, 0, this.byte_2.Length);
				Thread.Sleep(50);
				this.SerialPort_0.Write(this.byte_3, 0, this.byte_3.Length);
				Thread.Sleep(50);
				this.SerialPort_0.Write(this.byte_4, 0, this.byte_4.Length);
				Thread.Sleep(50);
				this.SerialPort_0.Write(this.byte_5, 0, this.byte_5.Length);
				Thread.Sleep(50);
				this.string_9 = null;
				this.method_11();
				if (this.int_3 == 1)
				{
					this.method_100();
				}
				else if (this.int_3 == 4)
				{
					this.method_101();
				}
				else if (this.int_3 == 7)
				{
					this.method_102();
				}
				this.method_97();
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060011C0 RID: 4544 RVA: 0x0000BA5E File Offset: 0x0000BA5E
		private void button1_Click(object sender, EventArgs e)
		{
			if (this.SerialPort_0 != null && this.SerialPort_0.IsOpen)
			{
				this.SerialPort_0.Close();
			}
			this.Timer_0.Enabled = false;
			base.Close();
		}

		// Token: 0x060011C1 RID: 4545 RVA: 0x000844E4 File Offset: 0x000844E4
		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				this.method_161();
			}
			catch (Exception ex)
			{
				Interaction__0.MsgBox("Gagal memulai live data: " + ex.Message, MsgBoxStyle__0.OkOnly, "Error");
			}
		}

		// Token: 0x060011C2 RID: 4546 RVA: 0x00084528 File Offset: 0x00084528
		private void method_96()
		{
			byte[] array = new byte[]
			{
				114,
				7,
				114,
				19,
				0,
				14,
				244
			};
			byte[] array2 = new byte[]
			{
				114,
				7,
				114,
				23,
				0,
				15,
				239
			};
			try
			{
				if (!this.SerialPort_0.IsOpen)
				{
					this.SerialPort_0.Open();
				}
				this.SerialPort_0.ReadExisting();
				this.SerialPort_0.Write(array, 0, array.Length);
				Thread.Sleep(30);
				this.string_9 = null;
				this.method_11();
				if (this.string_9.Length > 30)
				{
					this.int_3 = 7;
				}
				else
				{
					this.SerialPort_0.ReadExisting();
					Thread.Sleep(30);
					this.SerialPort_0.Write(array2, 0, array2.Length);
					Thread.Sleep(50);
					this.string_9 = null;
					this.method_11();
					if (this.string_9.Length > 30)
					{
						this.int_3 = 4;
						if (Operators__0.CompareString(this.string_9.Substring(32, 4), "FFFF", false) == 0)
						{
							this.int_4 = 4;
						}
						else
						{
							this.int_4 = 8;
						}
					}
					else
					{
						this.int_3 = 1;
					}
				}
				this.SerialPort_0.ReadExisting();
				this.method_98();
				if (this.int_3 == 1)
				{
					this.byte_2 = new byte[]
					{
						114,
						7,
						114,
						17,
						0,
						20,
						240
					};
					this.byte_3 = new byte[]
					{
						114,
						7,
						114,
						32,
						0,
						2,
						243
					};
					this.byte_4 = new byte[]
					{
						114,
						7,
						114,
						209,
						0,
						6,
						62
					};
					this.byte_5 = new byte[]
					{
						114,
						7,
						114,
						208,
						0,
						14,
						55
					};
				}
				else if (this.int_3 == 4)
				{
					this.byte_2 = new byte[]
					{
						114,
						7,
						114,
						23,
						0,
						15,
						239
					};
					this.byte_3 = new byte[]
					{
						114,
						7,
						114,
						209,
						0,
						6,
						62
					};
					this.byte_4 = new byte[]
					{
						114,
						7,
						114,
						32,
						0,
						2,
						243
					};
					this.byte_5 = new byte[]
					{
						114,
						7,
						114,
						208,
						0,
						14,
						55
					};
				}
				else if (this.int_3 == 7)
				{
					this.byte_2 = new byte[]
					{
						114,
						7,
						114,
						19,
						0,
						14,
						244
					};
					this.byte_3 = new byte[]
					{
						114,
						7,
						114,
						208,
						0,
						14,
						55
					};
					this.byte_4 = new byte[]
					{
						114,
						7,
						114,
						209,
						0,
						6,
						55
					};
					this.byte_5 = new byte[]
					{
						114,
						7,
						114,
						32,
						0,
						2,
						243
					};
				}
			}
			catch (Exception)
			{
				this.Timer_0.Enabled = false;
				Thread.Sleep(100);
				if (this.SerialPort_0 != null && this.SerialPort_0.IsOpen)
				{
					this.SerialPort_0.Close();
				}
			}
		}

		// Token: 0x060011C3 RID: 4547 RVA: 0x000847DC File Offset: 0x000847DC
		private void method_98()
		{
			checked
			{
				if (this.dataviewLiveData.Rows.Count <= 5)
				{
					if (this.int_3 == 1)
					{
						this.string_12 = new string[]
						{
							"Kecepatan mesin",
							"Durasi injektor",
							"Pengapian maju",
							"S1-Posisi Throttle (TPS)",
							"Tegangan S1-TPS",
							"Tegangan Sensor O2",
							"Aliran Bahan Bakar",
							"S3-Suhu Mesin (ECT)",
							"Tegangan S3-ECT/EOT",
							"S4-Suhu Udara Asupan (IAT)",
							"Tegangan S4-IAT",
							"S2-Tekanan Mutlak Manifold",
							"Tegangan S2-MAP",
							"Kecepatan kendaraan",
							"Tegangan Baterai",
							"IACV - Katup Kontrol Udara Masuk",
							"koefisien lingkungan",
							"Rasio Bahan Bakar Udara A/F",
							"Pompa bahan bakar",
							"Sakelar Dudukan Samping",
							"Sinyal Mulai",
							"Mulai Relai",
							"MIL"
						};
						this.string_14 = new string[]
						{
							"RPM",
							"ms",
							"deg",
							"deg",
							"mV",
							"mV",
							"%",
							"deg.C",
							"mV",
							"deg.C",
							"mV",
							"kPa",
							"mV",
							"Km/h",
							"V",
							"Step",
							"%",
							"",
							"",
							"",
							"",
							"",
							""
						};
						this.string_13 = new string[]
						{
							"1200÷1700",
							"1.9÷2.8",
							"5÷15",
							"0",
							"290÷710",
							"200÷800",
							"-10÷10",
							"60÷120",
							"1550÷310",
							"20÷60",
							"3510÷1330",
							"34÷98",
							"1000÷3000",
							"",
							"13÷15",
							"40÷70",
							"-10÷10",
							"13.2÷16.5",
							"",
							"",
							"",
							"",
							""
						};
					}
					else if (this.int_3 == 4)
					{
						this.string_12 = new string[]
						{
							"Kecepatan mesin",
							"Durasi injektor",
							"Pengapian maju",
							"S1-Posisi Throttle (TPS)",
							"Tegangan S1-TPS",
							"Tegangan Sensor O2",
							"Aliran Bahan Bakar",
							"S3-Suhu Mesin (ECT)",
							"Tegangan S3-ECT/EOT",
							"S4-Suhu Udara Asupan (IAT)",
							"Tegangan S4-IAT",
							"S2-Tekanan Mutlak Manifold",
							"Tegangan S2-MAP",
							"Kecepatan kendaraan",
							"Tegangan Baterai",
							"FISV - Kecepatan Idle Cepat",
							"koefisien lingkungan",
							"Rasio Bahan Bakar Udara A/F",
							"Pompa bahan bakar",
							"Sakelar Dudukan Samping",
							"Sinyal Mulai",
							"Mulai Relai",
							"MIL"
						};
						this.string_14 = new string[]
						{
							"RPM",
							"ms",
							"deg",
							"deg",
							"mV",
							"mV",
							"%",
							"deg.C",
							"mV",
							"deg.C",
							"mV",
							"kPa",
							"mV",
							"Km/h",
							"V",
							"",
							"%",
							"",
							"",
							"",
							"",
							"",
							""
						};
						this.string_13 = new string[]
						{
							"1200÷1700",
							"1.9÷2.8",
							"5÷15",
							"0",
							"290÷710",
							"200÷800",
							"-10÷10",
							"60÷120",
							"1550÷310",
							"20÷60",
							"3510÷1.33",
							"34÷98",
							"1000÷3000",
							"",
							"13÷15",
							"",
							"-10÷10",
							"13.2÷16.5",
							"",
							"",
							"",
							"",
							""
						};
					}
					else if (this.int_3 == 7)
					{
						this.string_12 = new string[]
						{
							"Kecepatan mesin",
							"Durasi injektor",
							"Pengapian maju",
							"S1-Posisi Throttle (TPS)",
							"Tegangan S1-TPS",
							"S3-Suhu Mesin (ECT)",
							"Tegangan S3-ECT/EOT",
							"S4-Suhu Udara Asupan (IAT)",
							"Tegangan S4-IAT",
							"S2-Tekanan Mutlak Manifold",
							"Tegangan S2-MAP",
							"Tegangan Baterai",
							"Jumlah DTC",
							"Pompa bahan bakar",
							"MIL"
						};
						this.string_14 = new string[]
						{
							"RPM",
							"ms",
							"deg",
							"deg",
							"mV",
							"deg.C",
							"mV",
							"deg.C",
							"mV",
							"kPa",
							"mV",
							"V",
							"",
							"",
							""
						};
						this.string_13 = new string[]
						{
							"1200÷1700",
							"1.9÷2.8",
							"5÷15",
							"0",
							"290÷710",
							"60÷120",
							"1550÷310",
							"20÷60",
							"3510÷1330",
							"34÷98",
							"1000÷3000",
							"13÷15",
							"",
							"",
							""
						};
					}
					this.int_6 = 0;
					while (this.int_6 <= this.string_12.Length - 1)
					{
						int index = this.dataviewLiveData.Rows.Add(new object[]
						{
							this.int_6 + 1,
							this.string_12[this.int_6],
							this.int_5,
							this.string_14[this.int_6],
							this.string_13[this.int_6]
						});
						if (this.int_6 % 2 == 0)
						{
							this.dataviewLiveData.Rows[index].DefaultCellStyle.BackColor = FM_diag.RowAlt1;
						}
						else
						{
							this.dataviewLiveData.Rows[index].DefaultCellStyle.BackColor = FM_diag.RowAlt2;
						}
						this.int_6++;
					}
				}
			}
		}

		// Token: 0x060011C4 RID: 4548 RVA: 0x00084FA0 File Offset: 0x00084FA0
		private void method_25()
		{
			byte[] array = new byte[]
			{
				254,
				4,
				114,
				140
			};
			byte[] array2 = new byte[]
			{
				114,
				5,
				113,
				0,
				24
			};
			try
			{
				this.string_5 = "0";
				if (!this.SerialPort_0.IsOpen)
				{
					this.SerialPort_0.Open();
				}
				this.SerialPort_0.BaudRate = 10400;
				Application.DoEvents();
				this.SerialPort_0.BreakState = false;
				Thread.Sleep(100);
				this.SerialPort_0.BreakState = true;
				Thread.Sleep(70);
				this.SerialPort_0.BreakState = false;
				Thread.Sleep(5);
				Thread.Sleep(145);
				this.SerialPort_0.Write(array, 0, array.Length);
				Thread.Sleep(30);
				this.SerialPort_0.DiscardOutBuffer();
				this.SerialPort_0.ReadExisting();
				this.SerialPort_0.Write(array2, 0, array2.Length);
				Thread.Sleep(50);
				this.SerialPort_0.DiscardOutBuffer();
				this.string_9 = null;
				this.method_11();
				if (this.string_9.Trim().IndexOf(this.string_4) > -1)
				{
					this.bool_3 = true;
					this.string_5 = this.string_9.Substring(18, 10);
					Application.DoEvents();
					this.SerialPort_0.Close();
				}
				else
				{
					this.bool_3 = false;
					Interaction__0.MsgBox(this.string_10[9], MsgBoxStyle__0.OkOnly, this.string_10[42]);
					this.bool_4 = true;
					Application.DoEvents();
					this.SerialPort_0.Close();
				}
			}
			catch (Exception)
			{
				if (this.SerialPort_0 != null && this.SerialPort_0.IsOpen)
				{
					this.SerialPort_0.Close();
				}
			}
		}

		// Token: 0x060011C5 RID: 4549 RVA: 0x00085168 File Offset: 0x00085168
		private void method_11()
		{
			while (this.SerialPort_0.BytesToRead > 0)
			{
				try
				{
					this.byte_0 = checked((byte)this.SerialPort_0.ReadByte());
					base.Invoke(new EventHandler(this.method_12));
				}
				catch (Exception)
				{
				}
			}
		}

		// Token: 0x060011C6 RID: 4550 RVA: 0x000851C0 File Offset: 0x000851C0
		public void method_12(object sender, EventArgs e)
		{
			string str = this.string_9;
			int num = (int)this.byte_0;
			this.string_9 = str + num.ToString("X2");
		}

		// Token: 0x060011C7 RID: 4551 RVA: 0x000851F4 File Offset: 0x000851F4
		private void method_01()
		{
			List<GClass1__0> list = GClass1__0.smethod_0();
			string text = "";
			bool flag = false;
			foreach (GClass1__0 gclass1__ in list)
			{
				string string_ = gclass1__.String_1;
				if (string_.IndexOf("FTDIBUS\\VID_0403+PID_6001+B5") > -1 || string_.IndexOf("USB\\VID_0403+PID_6001+B5") > -1 || string_.IndexOf("FTDIBUS\\VID_0403+PID_6001+A5") > -1 || string_.IndexOf("USB\\VID_0403+PID_6001+A5") > -1)
				{
					this.txtCOMName.Text = gclass1__.String_0;
					string input = "";
					if (string_.Length > 33)
					{
						input = string_.Substring(30, 3);
					}
					text = (Class18__0.smethod_0(input) * 2.0).ToString();
					flag = true;
					Application.DoEvents();
					break;
				}
			}
			if (!flag && list.Count > 0)
			{
				this.txtCOMName.Text = list[0].String_0;
				text = "Generic USB";
				flag = true;
			}
			if (text.Length > 1 && flag)
			{
				Thread.Sleep(1000);
				this.stsSNCable.Text = "Cable: " + text;
				return;
			}
			this.stsSNCable.Text = "Cable: Not detected";
		}

		// Token: 0x060011C8 RID: 4552 RVA: 0x00085354 File Offset: 0x00085354
		private void method_1111()
		{
			if (this.SerialPort_0.IsOpen)
			{
				this.SerialPort_0.Write("MicroCommand");
				return;
			}
			string text = this.txtCOMName.Text;
			if (string.IsNullOrEmpty(text) || text == "-")
			{
				Interaction__0.MsgBox("Tidak ada port COM yang terdeteksi.\n\n1. Pastikan kabel USB terhubung\n2. Install driver FTDI jika diperlukan\n3. Klik OK dan coba lagi", MsgBoxStyle__0.OkOnly, "Error Port");
				return;
			}
			if (!text.ToUpper().StartsWith("COM"))
			{
				string[] portNames = SerialPort.GetPortNames();
				if (portNames.Length == 0)
				{
					Interaction__0.MsgBox("Tidak ada port COM yang tersedia.\nPeriksa koneksi kabel USB.", MsgBoxStyle__0.OkOnly, "Error");
					return;
				}
				text = portNames[0];
				this.txtCOMName.Text = text;
			}
			try
			{
				this.SerialPort_0.PortName = text;
				this.SerialPort_0.BaudRate = 10400;
				this.SerialPort_0.Parity = Parity.None;
				this.SerialPort_0.DataBits = 8;
				this.SerialPort_0.StopBits = StopBits.One;
				this.SerialPort_0.Handshake = Handshake.None;
				this.SerialPort_0.RtsEnable = true;
				this.SerialPort_0.Open();
				this.stsSNCable.Text = "Connected to: " + text;
			}
			catch (Exception ex)
			{
				Interaction__0.MsgBox("Gagal membuka port " + text + "\n\nError: " + ex.Message, MsgBoxStyle__0.OkOnly, "Error Port");
			}
		}

		// Token: 0x060011C9 RID: 4553 RVA: 0x0000BA92 File Offset: 0x0000BA92
		private void button4_Click(object sender, EventArgs e)
		{
			this.method_1();
		}

		// Token: 0x060011CA RID: 4554 RVA: 0x0000BA5E File Offset: 0x0000BA5E
		private void button2_Click(object sender, EventArgs e)
		{
			if (this.SerialPort_0 != null && this.SerialPort_0.IsOpen)
			{
				this.SerialPort_0.Close();
			}
			this.Timer_0.Enabled = false;
			base.Close();
		}

		// Token: 0x060011CB RID: 4555 RVA: 0x0000BA9A File Offset: 0x0000BA9A
		private void Timer_0_Tick(object sender, EventArgs e)
		{
			this.method_99();
		}

		// Token: 0x060011CC RID: 4556 RVA: 0x000854A4 File Offset: 0x000854A4
		private void method_97()
		{
			this.int_6 = 0;
			checked
			{
				while (this.int_6 <= this.string_12.Length - 1)
				{
					DataGridViewRow dataGridViewRow = this.dataviewLiveData.Rows[this.int_6];
					int num = Conversions__0.ToInteger(Operators__0.SubtractObject(dataGridViewRow.Cells[0].Value, 1));
					dataGridViewRow.Cells[2].Value = this.string_15[num];
					if (this.bool_7 & this.bool_6)
					{
						if (this.bool_5[num])
						{
							dataGridViewRow.Cells[2].Style.ForeColor = FM_diag.NeonGreen;
						}
						else
						{
							dataGridViewRow.Cells[2].Style.ForeColor = FM_diag.NeonRed;
						}
					}
					else
					{
						dataGridViewRow.Cells[2].Style.ForeColor = FM_diag.TextSoft;
					}
					this.int_6++;
				}
			}
		}

		// Token: 0x060011CD RID: 4557 RVA: 0x000855A0 File Offset: 0x000855A0
		private void method_100()
		{
			double num = Conversion__0.Val("&H" + this.string_9.Substring(24, 2)) * 256.0 + Conversion__0.Val("&H" + this.string_9.Substring(26, 2));
			if (this.int_9 == 1)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[0] = num.ToString();
			this.bool_5[0] = !(num < 1300.0 | num > 15000.0);
			this.bool_7 = (num > 1000.0 & num < 2000.0);
			num = (Conversion__0.Val("&H" + this.string_9.Substring(52, 2)) * 256.0 + Conversion__0.Val("&H" + this.string_9.Substring(54, 2))) / 250.0;
			num = Math.Round(num, 1);
			if (this.int_9 == 2)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[1] = num.ToString();
			this.bool_5[1] = !(num < 1.9 | num > 2.8);
			num = (Conversion__0.Val("&H" + this.string_9.Substring(56, 2)) - 128.0) * 0.5;
			if (this.int_9 == 3)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[2] = num.ToString();
			this.bool_5[2] = !(num < 5.0 | num > 70.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(30, 2)) * 0.5;
			if (this.int_9 == 0)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[3] = num.ToString();
			this.bool_5[3] = !(num < 0.0 | num > 79.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(28, 2)) * 195.0 / 10.0;
			this.string_15[4] = Math.Round(num, 0).ToString();
			this.bool_5[4] = !(num < 290.0 | num > 4500.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(90, 2)) * 195.0 / 10.0;
			num = Math.Round(num, 0);
			if (this.int_9 == 5)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[5] = num.ToString();
			this.bool_5[5] = !(num < 200.0 | num > 800.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(92, 2)) * 39.0 / 50.0 - 100.0;
			this.string_15[6] = Math.Round(num, 0).ToString();
			this.bool_5[6] = !(num < -10.0 | num > 10.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(34, 2)) - 40.0;
			if (this.int_9 == 4)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[7] = num.ToString();
			this.bool_5[7] = !(num < 0.0 | num > 120.0);
			this.bool_6 = (num > 60.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(32, 2)) * 195.0 / 10.0;
			this.string_15[8] = Math.Round(num, 0).ToString();
			this.bool_5[8] = !(num < 430.0 | num > 4540.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(38, 2)) - 40.0;
			this.string_15[9] = num.ToString();
			this.bool_5[9] = !(num < 0.0 | num > 60.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(36, 2)) * 195.0 / 10.0;
			this.string_15[10] = Math.Round(num, 0).ToString();
			this.bool_5[10] = !(num < 1330.0 | num > 4500.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(42, 2));
			if (this.int_9 == 8)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[11] = num.ToString();
			this.bool_5[11] = !(num < 34.0 | num > 98.0);
			this.bool_5[12] = true;
			num = Conversion__0.Val("&H" + this.string_9.Substring(50, 2));
			this.string_15[13] = num.ToString();
			this.bool_5[13] = true;
			num = Conversion__0.Val("&H" + this.string_9.Substring(48, 2)) / 10.0;
			num = Math.Round(num, 1);
			if (this.int_9 == 6)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[14] = num.ToString();
			this.bool_5[14] = !(num < 13.0 | num > 15.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(58, 2));
			this.string_15[15] = Math.Round(num, 0).ToString();
			this.bool_5[15] = !(num < 40.0 | num > 70.0);
			this.string_15[16] = "";
			this.bool_5[16] = true;
			num = Conversion__0.Val("&H" + this.string_9.Substring(92, 2));
			if (num >= 128.0)
			{
				num = (num - 128.0) * 100.0 / 87.0 + 147.0;
			}
			else
			{
				num = 147.0 - (128.0 - num) * 100.0 / 87.0;
			}
			num = Math.Round(num / 10.0, 1);
			if (this.int_9 == 7)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[17] = num.ToString();
			this.bool_5[17] = !(num < 13.2 | num > 16.5);
			num = ((this.string_9.Length < 115) ? 0.0 : Conversion__0.Val("&H" + this.string_9.Substring(128, 2)));
			checked
			{
				this.string_15[18] = ((((long)Math.Round(num) & 1L) > 0L) ? "ON" : "OFF");
				this.bool_5[18] = true;
				num = ((this.string_9.Length < 115) ? 0.0 : Conversion__0.Val("&H" + this.string_9.Substring(120, 2)));
				this.string_15[19] = ((((long)Math.Round(num) & 2L) > 0L) ? "ON" : "OFF");
				this.bool_5[19] = true;
				num = ((this.string_9.Length < 115) ? 0.0 : Conversion__0.Val("&H" + this.string_9.Substring(120, 2)));
				this.string_15[20] = ((((long)Math.Round(num) & 32L) > 0L) ? "ON" : "OFF");
				this.bool_5[20] = true;
				num = ((this.string_9.Length < 115) ? 0.0 : Conversion__0.Val("&H" + this.string_9.Substring(128, 2)));
				this.string_15[21] = ((((long)Math.Round(num) & 144L) > 0L) ? "ON" : "OFF");
				this.bool_5[21] = true;
				num = ((this.string_9.Length < 115) ? 0.0 : Conversion__0.Val("&H" + this.string_9.Substring(158, 2)));
				this.string_15[22] = ((num >= 128.0) ? "ON" : "OFF");
				this.bool_5[22] = true;
			}
		}

		// Token: 0x060011CE RID: 4558 RVA: 0x00085F90 File Offset: 0x00085F90
		private void method_101()
		{
			if (this.int_4 != 8)
			{
				int num = this.int_4;
			}
			double num2 = Conversion__0.Val("&H" + this.string_9.Substring(24, 2)) * 256.0 + Conversion__0.Val("&H" + this.string_9.Substring(26, 2));
			if (this.int_9 == 1)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			this.string_15[0] = num2.ToString();
			this.bool_5[0] = (num2 >= 1300.0 && num2 <= 15000.0);
			this.bool_7 = (num2 > 1000.0 & num2 < 2000.0);
			num2 = (Conversion__0.Val("&H" + this.string_9.Substring(46, 2)) * 256.0 + Conversion__0.Val("&H" + this.string_9.Substring(48, 2))) / 250.0;
			num2 = Math.Round(num2, 1);
			if (this.int_9 == 2)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			this.string_15[1] = num2.ToString();
			this.bool_5[1] = (num2 >= 1.9 && num2 <= 2.8);
			num2 = (Conversion__0.Val("&H" + this.string_9.Substring(50, 2)) - 128.0) * 0.5;
			if (this.int_9 == 3)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			this.string_15[2] = num2.ToString();
			this.bool_5[2] = (num2 >= 5.0 && num2 <= 70.0);
			num2 = Conversion__0.Val("&H" + this.string_9.Substring(30, 2)) * 0.5;
			if (this.int_9 == 0)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			this.string_15[3] = num2.ToString();
			this.bool_5[3] = (num2 >= 0.0 && num2 <= 79.0);
			num2 = Conversion__0.Val("&H" + this.string_9.Substring(28, 2)) * 195.0 / 10.0;
			this.string_15[4] = Math.Round(num2, 0).ToString();
			this.bool_5[4] = (num2 >= 290.0 && num2 <= 4500.0);
			num2 = Conversion__0.Val("&H" + this.string_9.Substring(118, 2)) * 195.0 / 10.0;
			num2 = Math.Round(num2, 0);
			if (this.int_9 == 5)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			this.string_15[5] = num2.ToString();
			this.bool_5[5] = (num2 >= 200.0 && num2 <= 800.0);
			num2 = Conversion__0.Val("&H" + this.string_9.Substring(120, 2)) * 39.0 / 50.0 - 100.0;
			this.string_15[6] = Math.Round(num2, 0).ToString();
			this.bool_5[6] = (num2 >= -10.0 && num2 <= 10.0);
			num2 = Conversion__0.Val("&H" + this.string_9.Substring(34, 2)) - 40.0;
			if (this.int_9 == 4)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			this.string_15[7] = num2.ToString();
			this.bool_5[7] = (num2 >= 0.0 && num2 <= 120.0);
			this.bool_6 = (num2 > 60.0);
			num2 = Conversion__0.Val("&H" + this.string_9.Substring(32, 2)) * 195.0 / 10.0;
			this.string_15[8] = Math.Round(num2, 0).ToString();
			this.bool_5[8] = (num2 >= 430.0 && num2 <= 4540.0);
			num2 = Conversion__0.Val("&H" + this.string_9.Substring(38, 2)) - 40.0;
			this.string_15[9] = num2.ToString();
			this.bool_5[9] = (num2 >= 0.0 && num2 <= 60.0);
			num2 = Conversion__0.Val("&H" + this.string_9.Substring(36, 2)) * 195.0 / 10.0;
			this.string_15[10] = Math.Round(num2, 0).ToString();
			this.bool_5[10] = (num2 >= 1330.0 && num2 <= 4500.0);
			if (Operators__0.CompareString(this.string_9.Substring(38, 2), "FF", false) == 0 & Operators__0.CompareString(this.string_9.Substring(36, 2), "FF", false) == 0)
			{
				this.string_15[9] = this.string_10[43];
				this.string_15[10] = this.string_10[43];
				this.bool_5[9] = true;
				this.bool_5[10] = true;
			}
			this.string_15[11] = this.string_10[43];
			this.bool_5[11] = true;
			if (this.int_9 == 8)
			{
				this.method_119(0.0);
				this.method_126(0.0);
			}
			this.string_15[12] = this.string_10[43];
			this.bool_5[12] = true;
			this.string_15[13] = this.string_10[43];
			this.bool_5[13] = true;
			num2 = Conversion__0.Val("&H" + this.string_9.Substring(44, 2)) / 10.0;
			num2 = Math.Round(num2, 1);
			if (this.int_9 == 6)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			this.string_15[14] = num2.ToString();
			this.bool_5[14] = (num2 >= 13.0 && num2 <= 15.0);
			num2 = Conversion__0.Val("&H" + this.string_9.Substring(88, 2));
			if (checked((long)Math.Round(num2)) / 16L == 4L)
			{
				this.string_15[15] = "ON";
			}
			else
			{
				this.string_15[15] = "OFF";
			}
			this.bool_5[15] = true;
			num2 = Conversion__0.Val("&H" + this.string_9.Substring(52, 2)) * 39.0 / 50.0 - 100.0;
			this.string_15[16] = Math.Round(num2, 0).ToString();
			this.bool_5[16] = (num2 >= -10.0 && num2 <= 10.0);
			num2 = Conversion__0.Val("&H" + this.string_9.Substring(120, 2));
			if (num2 >= 128.0)
			{
				num2 = (num2 - 128.0) * 100.0 / 87.0 + 147.0;
			}
			else
			{
				num2 = 147.0 - (128.0 - num2) * 100.0 / 87.0;
			}
			num2 = Math.Round(num2 / 10.0, 1);
			if (this.int_9 == 7)
			{
				this.method_119(num2);
				this.method_126(num2);
			}
			this.string_15[17] = num2.ToString();
			this.bool_5[17] = (num2 >= 13.2 && num2 <= 16.5);
			if (this.string_9.Length < 80)
			{
				num2 = 0.0;
			}
			else
			{
				num2 = Conversion__0.Val("&H" + this.string_9.Substring(88, 2));
			}
			checked
			{
				this.string_15[18] = ((((long)Math.Round(num2) & 1L) > 0L) ? "ON" : "OFF");
				this.bool_5[18] = true;
				if (this.string_9.Length < 78)
				{
					num2 = 0.0;
				}
				else
				{
					num2 = Conversion__0.Val("&H" + this.string_9.Substring(80, 2));
				}
				this.string_15[19] = ((((long)Math.Round(num2) & 2L) > 0L) ? "ON" : "OFF");
				this.bool_5[19] = true;
				if (this.string_9.Length < 78)
				{
					num2 = 0.0;
				}
				else
				{
					num2 = Conversion__0.Val("&H" + this.string_9.Substring(80, 2));
				}
				this.string_15[20] = ((((long)Math.Round(num2) & 32L) > 0L) ? "ON" : "OFF");
				this.bool_5[20] = true;
				if (this.string_9.Length < 80)
				{
					num2 = 0.0;
				}
				else
				{
					num2 = Conversion__0.Val("&H" + this.string_9.Substring(88, 2));
				}
				this.string_15[21] = ((((long)Math.Round(num2) & 144L) > 0L) ? "ON" : "OFF");
				this.bool_5[21] = true;
				if (this.string_9.Length < 140)
				{
					num2 = 0.0;
				}
				else
				{
					num2 = Conversion__0.Val("&H" + this.string_9.Substring(148, 2));
				}
				this.string_15[22] = ((num2 >= 128.0) ? "ON" : "OFF");
				this.bool_5[22] = true;
			}
		}

		// Token: 0x060011CF RID: 4559 RVA: 0x00086A4C File Offset: 0x00086A4C
		private void method_102()
		{
			double num = Conversion__0.Val("&H" + this.string_9.Substring(24, 2)) * 256.0 + Conversion__0.Val("&H" + this.string_9.Substring(26, 2));
			if (this.int_9 == 1)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[0] = num.ToString();
			this.bool_5[0] = (num >= 1300.0 && num <= 15000.0);
			this.bool_7 = (num > 1000.0 & num < 2000.0);
			num = (Conversion__0.Val("&H" + this.string_9.Substring(46, 2)) * 256.0 + Conversion__0.Val("&H" + this.string_9.Substring(48, 2))) / 250.0;
			num = Math.Round(num, 1);
			if (this.int_9 == 2)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[1] = num.ToString();
			this.bool_5[1] = (num >= 1.9 && num <= 2.8);
			num = (Conversion__0.Val("&H" + this.string_9.Substring(50, 2)) - 128.0) * 0.5;
			if (this.int_9 == 3)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[2] = num.ToString();
			this.bool_5[2] = (num >= 5.0 && num <= 70.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(30, 2)) * 0.5;
			if (this.int_9 == 0)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[3] = num.ToString();
			this.bool_5[3] = (num >= 0.0 && num <= 79.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(28, 2)) * 195.0 / 10.0;
			this.string_15[4] = Math.Round(num, 0).ToString();
			this.bool_5[4] = (num >= 290.0 && num <= 4500.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(34, 2)) - 40.0;
			if (this.int_9 == 4)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[5] = num.ToString();
			this.bool_5[5] = (num >= 0.0 && num <= 120.0);
			this.bool_6 = (num > 60.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(32, 2)) * 195.0 / 10.0;
			this.string_15[6] = Math.Round(num, 0).ToString();
			this.bool_5[6] = (num >= 430.0 && num <= 4540.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(38, 2)) - 40.0;
			this.string_15[7] = num.ToString();
			this.bool_5[7] = (num >= 0.0 && num <= 60.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(36, 2)) * 195.0 / 10.0;
			this.string_15[8] = Math.Round(num, 0).ToString();
			this.bool_5[8] = (num >= 1330.0 && num <= 4500.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(42, 2));
			if (this.int_9 == 8)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[9] = num.ToString();
			this.bool_5[9] = (num >= 34.0 && num <= 99.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(40, 2)) * 195.0 / 10.0;
			this.string_15[10] = Math.Round(num, 0).ToString();
			this.bool_5[10] = (num >= 1000.0 && num <= 3000.0);
			num = Conversion__0.Val("&H" + this.string_9.Substring(44, 2)) / 10.0;
			num = Math.Round(num, 1);
			if (this.int_9 == 6)
			{
				this.method_119(num);
				this.method_126(num);
			}
			this.string_15[11] = num.ToString();
			this.bool_5[11] = (num >= 13.0 && num <= 15.0);
			checked
			{
				num = (double)((long)Math.Round(Conversion__0.Val("&H" + this.string_9.Substring(78, 2))) & 127L);
				this.string_15[12] = num.ToString();
				this.bool_5[12] = true;
				if (this.string_9.Length < 76)
				{
					num = 0.0;
				}
				else
				{
					num = Conversion__0.Val("&H" + this.string_9.Substring(78, 2));
				}
				this.string_15[13] = ((((long)Math.Round(num) & 128L) > 0L) ? "ON" : "OFF");
				this.bool_5[13] = true;
				if (this.string_9.Length < 138)
				{
					num = 0.0;
				}
				else
				{
					num = Conversion__0.Val("&H" + this.string_9.Substring(140, 2));
				}
				this.string_15[14] = ((((long)Math.Round(num) & 128L) > 0L) ? "ON" : "OFF");
				this.bool_5[14] = true;
			}
		}

		// Token: 0x060011D0 RID: 4560 RVA: 0x00087148 File Offset: 0x00087148
		private void method_119(double double_6)
		{
			this.ChartTPS.Series[0].Points.AddY(double_6);
			if (this.ChartTPS.Series[0].Points.Count == 50)
			{
				this.ChartTPS.Series[0].Points.RemoveAt(0);
			}
		}

		// Token: 0x060011D1 RID: 4561 RVA: 0x000871AC File Offset: 0x000871AC
		private void method_126(double double_6)
		{
			this.txtCurrentTPS.Text = double_6.ToString();
			if (this.double_0 > double_6)
			{
				this.double_0 = double_6;
			}
			if (this.double_1 < double_6)
			{
				this.double_1 = double_6;
			}
			this.txtMinTPS.Text = this.double_0.ToString();
			this.txtMaxTPS.Text = this.double_1.ToString();
		}

		// Token: 0x060011D2 RID: 4562 RVA: 0x0000BAA2 File Offset: 0x0000BAA2
		private void button5_Click(object sender, EventArgs e)
		{
			base.WindowState = FormWindowState.Minimized;
		}

		// Token: 0x060011D3 RID: 4563 RVA: 0x000026F4 File Offset: 0x000026F4
		private void textBox2_TextChanged(object sender, EventArgs e)
		{
		}

		// Token: 0x060011D4 RID: 4564 RVA: 0x0000BAAB File Offset: 0x0000BAAB
		private void comGraphTPS_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.method_150();
		}

		// Token: 0x060011D5 RID: 4565 RVA: 0x00087218 File Offset: 0x00087218
		private void method_143(int int_10, double double_6, double double_7, int int_11)
		{
			this.ChartTPS.Series[0].Points.Clear();
			this.ChartTPS.ChartAreas[0].AxisY.Minimum = (double)int_10;
			this.ChartTPS.ChartAreas[0].AxisY.Maximum = double_6;
			this.ChartTPS.ChartAreas[0].AxisY.Interval = double_7;
			this.txtCurrentTPS.Text = "0";
			this.txtMaxTPS.Text = "0";
			this.txtMinTPS.Text = int_11.ToString();
			this.double_1 = 0.0;
			this.double_0 = (double)int_11;
		}

		// Token: 0x060011D6 RID: 4566 RVA: 0x0000BAB3 File Offset: 0x0000BAB3
		private void button6_Click(object sender, EventArgs e)
		{
			this.int_1 = 4;
			this.method_141();
			this.method_128();
			if (this.bool_8)
			{
				this.method_134();
				this.method_142();
			}
		}

		// Token: 0x060011D7 RID: 4567 RVA: 0x0000BADC File Offset: 0x0000BADC
		private void method_41()
		{
			this.method_141();
		}

		// Token: 0x060011D8 RID: 4568 RVA: 0x000872E0 File Offset: 0x000872E0
		private void method_118()
		{
			this.ChartTPS.Series[0].Points.Clear();
			this.ChartTPS.Series[0].Points.AddY(0.0);
			this.ChartTPS.Series[0].IsValueShownAsLabel = false;
			this.ChartTPS.Series[0].ChartType = 1;
			this.ChartTPS.ChartAreas["ChartArea1"].AxisX.Enabled = false;
			this.ChartTPS.ChartAreas[0].AxisX.Minimum = 0.0;
			this.ChartTPS.ChartAreas[0].AxisX.Maximum = 50.0;
			this.ChartTPS.ChartAreas[0].AxisX.Interval = 2.0;
			this.ChartTPS.Series[0].IsVisibleInLegend = false;
		}

		// Token: 0x060011D9 RID: 4569 RVA: 0x0000BAE4 File Offset: 0x0000BAE4
		private void comboSensor_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.method_134();
			this.method_148();
			this.method_128();
		}

		// Token: 0x060011DA RID: 4570 RVA: 0x00087400 File Offset: 0x00087400
		private void method_144(int int_10, int int_11, int int_12, int int_13)
		{
			this.ChartSensor.Series[0].Points.Clear();
			this.ChartSensor.ChartAreas[0].AxisY.Minimum = (double)int_10;
			this.ChartSensor.ChartAreas[0].AxisY.Maximum = (double)int_11;
			this.ChartSensor.ChartAreas[0].AxisY.Interval = (double)int_12;
			this.txtValue1.Text = "0";
			this.txtValue1_Max.Text = "0";
			this.txtValue1_Min.Text = int_13.ToString();
			this.double_3 = 0.0;
			this.double_2 = (double)int_13;
		}

		// Token: 0x060011DB RID: 4571 RVA: 0x0000BAF8 File Offset: 0x0000BAF8
		private void Timer_2_Tick(object sender, EventArgs e)
		{
			this.method_128();
		}

		// Token: 0x060011DC RID: 4572 RVA: 0x000874CC File Offset: 0x000874CC
		private void method_129(int int_10, int int_11)
		{
			double num = 0.0;
			switch (int_10)
			{
			case 0:
				num = Conversion__0.Val("&H" + this.string_9.Substring(24, 2)) * 256.0 + Conversion__0.Val("&H" + this.string_9.Substring(26, 2));
				break;
			case 1:
				num = Conversion__0.Val("&H" + this.string_9.Substring(30, 2)) * 0.5;
				break;
			case 2:
				num = Conversion__0.Val("&H" + this.string_9.Substring(34, 2)) - 40.0;
				break;
			case 3:
				num = Conversion__0.Val("&H" + this.string_9.Substring(38, 2)) - 40.0;
				break;
			case 4:
				num = Conversion__0.Val("&H" + this.string_9.Substring(42, 2));
				break;
			case 5:
				num = Conversion__0.Val("&H" + this.string_9.Substring(92, 2));
				if (num >= 128.0)
				{
					num = (num - 128.0) * 100.0 / 87.0 + 147.0;
				}
				else
				{
					num = 147.0 - (128.0 - num) * 100.0 / 87.0;
				}
				num = Math.Round(num / 10.0, 1);
				break;
			case 6:
				num = Conversion__0.Val("&H" + this.string_9.Substring(92, 2)) * 39.0 / 50.0 - 100.0;
				num = Math.Round(num, 0);
				break;
			case 7:
				num = (Conversion__0.Val("&H" + this.string_9.Substring(52, 2)) * 256.0 + Conversion__0.Val("&H" + this.string_9.Substring(54, 2))) / 250.0;
				num = Math.Round(num, 1);
				break;
			case 8:
				num = (Conversion__0.Val("&H" + this.string_9.Substring(56, 2)) - 128.0) * 0.5;
				num = 0.0;
				break;
			}
			this.method_132(num);
			this.method_120(num);
			switch (int_11)
			{
			case 0:
				num = Conversion__0.Val("&H" + this.string_9.Substring(48, 2)) / 10.0;
				num = Math.Round(num, 1);
				break;
			case 1:
				num = Conversion__0.Val("&H" + this.string_9.Substring(28, 2)) * 195.0 / 10.0;
				num = Math.Round(num, 0);
				break;
			case 2:
				num = Conversion__0.Val("&H" + this.string_9.Substring(32, 2)) * 195.0 / 10.0;
				num = Math.Round(num, 0);
				break;
			case 3:
				num = Conversion__0.Val("&H" + this.string_9.Substring(36, 2)) * 195.0 / 10.0;
				num = Math.Round(num, 0);
				break;
			case 4:
				num = Conversion__0.Val("&H" + this.string_9.Substring(40, 2)) * 195.0 / 10.0;
				num = Math.Round(num, 0);
				break;
			case 5:
				num = Conversion__0.Val("&H" + this.string_9.Substring(90, 2)) * 195.0 / 10.0;
				num = Math.Round(num, 0);
				break;
			case 6:
				num = Conversion__0.Val("&H" + this.string_9.Substring(30, 2)) * 0.5;
				break;
			case 7:
				num = Conversion__0.Val("&H" + this.string_9.Substring(34, 2)) - 40.0;
				break;
			case 8:
				num = Conversion__0.Val("&H" + this.string_9.Substring(38, 2)) - 40.0;
				break;
			case 9:
				num = Conversion__0.Val("&H" + this.string_9.Substring(92, 2));
				if (num >= 128.0)
				{
					num = (num - 128.0) * 100.0 / 87.0 + 147.0;
				}
				else
				{
					num = 147.0 - (128.0 - num) * 100.0 / 87.0;
				}
				num = Math.Round(num / 10.0, 1);
				break;
			case 10:
				num = Conversion__0.Val("&H" + this.string_9.Substring(92, 2)) * 39.0 / 50.0 - 100.0;
				num = Math.Round(num, 0);
				break;
			case 11:
				num = (Conversion__0.Val("&H" + this.string_9.Substring(52, 2)) * 256.0 + Conversion__0.Val("&H" + this.string_9.Substring(54, 2))) / 250.0;
				num = Math.Round(num, 1);
				break;
			case 12:
				num = (Conversion__0.Val("&H" + this.string_9.Substring(56, 2)) - 128.0) * 0.5;
				num = 0.0;
				break;
			}
			this.method_133(num);
			this.method_121(num);
		}

		// Token: 0x060011DD RID: 4573 RVA: 0x00087B48 File Offset: 0x00087B48
		private void method_132(double double_6)
		{
			this.txtValue1.Text = double_6.ToString();
			if (this.double_2 > double_6)
			{
				this.double_2 = double_6;
			}
			if (this.double_3 < double_6)
			{
				this.double_3 = double_6;
			}
			this.txtValue1_Min.Text = this.double_2.ToString();
			this.txtValue1_Max.Text = this.double_3.ToString();
		}

		// Token: 0x060011DE RID: 4574 RVA: 0x00087BB4 File Offset: 0x00087BB4
		private void method_133(double double_6)
		{
			this.txtValue2.Text = double_6.ToString();
			if (this.double_4 > double_6)
			{
				this.double_4 = double_6;
			}
			if (this.double_5 < double_6)
			{
				this.double_5 = double_6;
			}
			this.txtValue2_Min.Text = this.double_4.ToString();
			this.txtValue2_Max.Text = this.double_5.ToString();
		}

		// Token: 0x060011DF RID: 4575 RVA: 0x00087C20 File Offset: 0x00087C20
		private void method_120(double double_6)
		{
			if (this.int_7 != 9)
			{
				this.ChartSensor.Series[0].Points.AddY(double_6);
			}
			if (this.ChartSensor.Series[0].Points.Count == 50)
			{
				this.ChartSensor.Series[0].Points.RemoveAt(0);
			}
		}

		// Token: 0x060011E0 RID: 4576 RVA: 0x00087C90 File Offset: 0x00087C90
		private void method_121(double double_6)
		{
			if (this.int_8 != 13)
			{
				this.ChartVoltage.Series[0].Points.AddY(double_6);
			}
			if (this.ChartVoltage.Series[0].Points.Count == 50)
			{
				this.ChartVoltage.Series[0].Points.RemoveAt(0);
			}
		}

		// Token: 0x060011E1 RID: 4577 RVA: 0x000026F4 File Offset: 0x000026F4
		private void method_130()
		{
		}

		// Token: 0x060011E2 RID: 4578 RVA: 0x000026F4 File Offset: 0x000026F4
		private void method_131()
		{
		}

		// Token: 0x060011E3 RID: 4579 RVA: 0x00087D00 File Offset: 0x00087D00
		private void method_173(string s, float f, FontStyle fs)
		{
			this.comGraphTPS.Font = new Font(s, f, fs);
			this.txtMinTPS.Font = new Font(s, f, fs);
			this.txtCurrentTPS.Font = new Font(s, f, fs);
			this.txtMaxTPS.Font = new Font(s, f, fs);
			this.comboSensor.Font = new Font(s, f, fs);
			this.txtValue1.Font = new Font(s, f, fs);
			this.txtValue1_Min.Font = new Font(s, f, fs);
			this.txtValue1_Max.Font = new Font(s, f, fs);
			this.comboVoltage.Font = new Font(s, f, fs);
			this.txtValue2.Font = new Font(s, f, fs);
			this.txtValue2_Min.Font = new Font(s, f, fs);
			this.txtValue2_Max.Font = new Font(s, f, fs);
		}

		// Token: 0x060011E4 RID: 4580 RVA: 0x000026F4 File Offset: 0x000026F4
		private void dataviewLiveData_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
		}

		// Token: 0x060011E5 RID: 4581 RVA: 0x0000BB00 File Offset: 0x0000BB00
		private void FM_diag_Load(object sender, EventArgs e)
		{
			this.method_140();
			this.method_161();
		}

		// Token: 0x060011E6 RID: 4582 RVA: 0x000026F4 File Offset: 0x000026F4
		private void label4_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060011E7 RID: 4583 RVA: 0x00087DF4 File Offset: 0x00087DF4
		private void BorderTimer_Tick(object sender, EventArgs e)
		{
			this.borderGlowPulse += 0.05f * this.borderGlowDirection;
			if (this.borderGlowPulse >= 1f)
			{
				this.borderGlowPulse = 1f;
				this.borderGlowDirection = -1f;
			}
			else if (this.borderGlowPulse <= 0f)
			{
				this.borderGlowPulse = 0f;
				this.borderGlowDirection = 1f;
			}
			base.Invalidate();
		}

		// Token: 0x060011E8 RID: 4584 RVA: 0x0000BB0E File Offset: 0x0000BB0E
		private void FM_diag_Paint(object sender, PaintEventArgs e)
		{
			this.DrawNeonBorder(e.Graphics);
		}

		// Token: 0x060011E9 RID: 4585 RVA: 0x00087E68 File Offset: 0x00087E68
		private void FM_diag_Resize(object sender, EventArgs e)
		{
			checked
			{
				try
				{
					GraphicsPath graphicsPath = new GraphicsPath();
					int num = 16;
					graphicsPath.AddArc(0, 0, num, num, 180f, 90f);
					graphicsPath.AddArc(base.Width - num, 0, num, num, 270f, 90f);
					graphicsPath.AddArc(base.Width - num, base.Height - num, num, num, 0f, 90f);
					graphicsPath.AddArc(0, base.Height - num, num, num, 90f, 90f);
					graphicsPath.CloseAllFigures();
					base.Region = new Region(graphicsPath);
				}
				catch
				{
				}
			}
		}

		// Token: 0x060011EA RID: 4586 RVA: 0x00087F14 File Offset: 0x00087F14
		private void DrawNeonBorder(Graphics g)
		{
			g.SmoothingMode = SmoothingMode.AntiAlias;
			g.PixelOffsetMode = PixelOffsetMode.HighQuality;
			g.CompositingQuality = CompositingQuality.HighQuality;
			int width = base.ClientSize.Width;
			int height = base.ClientSize.Height;
			if (width <= 2 || height <= 2)
			{
				return;
			}
			int radius = 16;
			checked
			{
				for (int i = 3; i >= 1; i--)
				{
					int val = (int)(unchecked((float)(checked(8 + i * 8)) * (0.6f + 0.4f * this.borderGlowPulse)));
					float width2 = unchecked(0.5f + (float)i * 0.5f);
					int num = i;
					using (Pen pen = new Pen(Color.FromArgb(Math.Min(255, val), 0, 229, 255), width2))
					{
						pen.Alignment = PenAlignment.Center;
						pen.LineJoin = LineJoin.Round;
						Rectangle rect = new Rectangle(num, num, width - num * 2 - 1, height - num * 2 - 1);
						using (GraphicsPath graphicsPath = this.CreateRoundedRectangle(rect, radius))
						{
							g.DrawPath(pen, graphicsPath);
						}
					}
				}
				Rectangle rect2 = new Rectangle(1, 1, width - 3, height - 3);
				using (GraphicsPath graphicsPath2 = this.CreateRoundedRectangle(rect2, radius))
				{
					int val2 = (int)(unchecked(160f + 60f * this.borderGlowPulse));
					using (Pen pen2 = new Pen(Color.FromArgb(Math.Min(255, val2), 0, 229, 255), 1.5f))
					{
						pen2.LineJoin = LineJoin.Round;
						g.DrawPath(pen2, graphicsPath2);
					}
					using (Pen pen3 = new Pen(Color.FromArgb(180, 220, 255, 255), 0.6f))
					{
						pen3.LineJoin = LineJoin.Round;
						g.DrawPath(pen3, graphicsPath2);
					}
				}
			}
		}

		// Token: 0x060011EB RID: 4587 RVA: 0x00053E1C File Offset: 0x00053E1C
		private GraphicsPath CreateRoundedRectangle(Rectangle rect, int radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			checked
			{
				int num = radius * 2;
				if (num > rect.Width)
				{
					num = rect.Width;
				}
				if (num > rect.Height)
				{
					num = rect.Height;
				}
				graphicsPath.AddArc(rect.X, rect.Y, num, num, 180f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Y, num, num, 270f, 90f);
				graphicsPath.AddArc(rect.Right - num, rect.Bottom - num, num, num, 0f, 90f);
				graphicsPath.AddArc(rect.X, rect.Bottom - num, num, num, 90f, 90f);
				graphicsPath.CloseFigure();
				return graphicsPath;
			}
		}

		// Token: 0x060011EC RID: 4588 RVA: 0x0000BB0E File Offset: 0x0000BB0E
		private void BorderOverlay_Paint(object sender, PaintEventArgs e)
		{
			this.DrawNeonBorder(e.Graphics);
		}

		// Token: 0x060011ED RID: 4589 RVA: 0x0000BB1C File Offset: 0x0000BB1C
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			this.DrawNeonBorder(e.Graphics);
		}

		// Token: 0x060011EE RID: 4590 RVA: 0x00088130 File Offset: 0x00088130
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			using (SolidBrush solidBrush = new SolidBrush(this.BackColor))
			{
				e.Graphics.FillRectangle(solidBrush, base.ClientRectangle);
			}
		}

		// Token: 0x060011EF RID: 4591 RVA: 0x00088178 File Offset: 0x00088178
		private void SetRoundedButton(Button btn, int radius)
		{
			if (btn == null)
			{
				return;
			}
			int width = (btn.Width <= 0) ? 100 : btn.Width;
			int height = (btn.Height <= 0) ? 30 : btn.Height;
			using (GraphicsPath graphicsPath = this.CreateRoundedRectangle(new Rectangle(0, 0, width, height), radius))
			{
				btn.Region = new Region(graphicsPath);
			}
			btn.FlatAppearance.BorderSize = 0;
			btn.Tag = radius;
			try
			{
				PropertyInfo property = typeof(Control).GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic);
				if (property != null)
				{
					property.SetValue(btn, true, null);
				}
			}
			catch
			{
			}
			btn.Paint -= this.RoundedButton_Paint;
			btn.Resize -= this.RoundedButton_Resize;
			btn.Paint += this.RoundedButton_Paint;
			btn.Resize += this.RoundedButton_Resize;
			btn.Invalidate();
		}

		// Token: 0x060011F1 RID: 4593 RVA: 0x00088354 File Offset: 0x00088354
		private void button7_Click(object sender, EventArgs e)
		{
			try
			{
				this.Timer_2.Enabled = false;
			}
			catch (Exception ex)
			{
				Interaction__0.MsgBox("Gagal stop graph: " + ex.Message, MsgBoxStyle__0.OkOnly, "Error");
			}
		}

		// Token: 0x060011F2 RID: 4594 RVA: 0x000883A0 File Offset: 0x000883A0
		private void RoundedButton_Paint(object sender, PaintEventArgs e)
		{
			Button button = sender as Button;
			if (button == null)
			{
				return;
			}
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			int radius = (button.Tag is int) ? ((int)button.Tag) : 8;
			Rectangle rect = checked(new Rectangle(0, 0, button.Width - 1, button.Height - 1));
			using (GraphicsPath graphicsPath = this.CreateRoundedRectangle(rect, radius))
			{
				using (SolidBrush solidBrush = new SolidBrush(button.BackColor))
				{
					graphics.FillPath(solidBrush, graphicsPath);
				}
				Color color = button.FlatAppearance.BorderColor;
				if (color == Color.Empty)
				{
					color = button.ForeColor;
				}
				using (Pen pen = new Pen(color, 1f))
				{
					pen.Alignment = PenAlignment.Inset;
					graphics.DrawPath(pen, graphicsPath);
				}
			}
			TextRenderer.DrawText(graphics, button.Text, button.Font, button.ClientRectangle, button.ForeColor, TextFormatFlags.EndEllipsis | TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
		}

		// Token: 0x060011F3 RID: 4595 RVA: 0x000884DC File Offset: 0x000884DC
		private void RoundedButton_Resize(object sender, EventArgs e)
		{
			Button button = sender as Button;
			if (button == null)
			{
				return;
			}
			int radius = (button.Tag is int) ? ((int)button.Tag) : 8;
			using (GraphicsPath graphicsPath = this.CreateRoundedRectangle(new Rectangle(0, 0, button.Width, button.Height), radius))
			{
				button.Region = new Region(graphicsPath);
			}
		}

		// Token: 0x04001890 RID: 6288
		private string string_4;

		// Token: 0x04001891 RID: 6289
		private string string_5;

		// Token: 0x04001892 RID: 6290
		private string[] string_10;

		// Token: 0x04001893 RID: 6291
		private string[] string_15;

		// Token: 0x04001894 RID: 6292
		private int int_5;

		// Token: 0x04001895 RID: 6293
		private int int_6;

		// Token: 0x04001896 RID: 6294
		private int int_3;

		// Token: 0x04001897 RID: 6295
		private int int_4;

		// Token: 0x04001898 RID: 6296
		private int int_9;

		// Token: 0x04001899 RID: 6297
		private int int_1 = 4;

		// Token: 0x0400189A RID: 6298
		private int int_7;

		// Token: 0x0400189B RID: 6299
		private int int_8;

		// Token: 0x0400189C RID: 6300
		private bool bool_3;

		// Token: 0x0400189D RID: 6301
		private bool bool_4;

		// Token: 0x0400189E RID: 6302
		private bool bool_6;

		// Token: 0x0400189F RID: 6303
		private bool bool_7;

		// Token: 0x040018A0 RID: 6304
		private bool bool_8 = true;

		// Token: 0x040018A1 RID: 6305
		private byte[] byte_2;

		// Token: 0x040018A2 RID: 6306
		private byte[] byte_3;

		// Token: 0x040018A3 RID: 6307
		private byte[] byte_4;

		// Token: 0x040018A4 RID: 6308
		private byte[] byte_5;

		// Token: 0x040018A5 RID: 6309
		private byte byte_0;

		// Token: 0x040018A6 RID: 6310
		private string string_9;

		// Token: 0x040018A7 RID: 6311
		private string[] string_12;

		// Token: 0x040018A8 RID: 6312
		private string[] string_13;

		// Token: 0x040018A9 RID: 6313
		private string[] string_14;

		// Token: 0x040018AA RID: 6314
		private bool[] bool_5;

		// Token: 0x040018AB RID: 6315
		private double double_0;

		// Token: 0x040018AC RID: 6316
		private double double_1;

		// Token: 0x040018AD RID: 6317
		private double double_2;

		// Token: 0x040018AE RID: 6318
		private double double_3;

		// Token: 0x040018AF RID: 6319
		private double double_4;

		// Token: 0x040018B0 RID: 6320
		private double double_5;

		// Token: 0x040018B8 RID: 6328
		private float borderGlowPulse;

		// Token: 0x040018B9 RID: 6329
		private float borderGlowDirection;

		// Token: 0x040018BA RID: 6330
		private Panel borderOverlay;

		// Token: 0x040018C4 RID: 6340
		private static readonly Color RowAlt2 = Color.FromArgb(28, 36, 48);

		// Token: 0x02000757 RID: 1879
		public class CustomMessageBox__0 : Form
		{
			// Token: 0x060011F4 RID: 4596 RVA: 0x00088554 File Offset: 0x00088554
			public CustomMessageBox__0()
			{
				base.FormBorderStyle = FormBorderStyle.None;
				base.StartPosition = FormStartPosition.CenterScreen;
				this.BackColor = FM_diag.CustomMessageBox__0.BgDark;
				base.MaximizeBox = false;
				base.MinimizeBox = false;
				base.ShowInTaskbar = false;
				base.Width = 440;
				base.Height = 300;
				base.TopMost = true;
				base.Padding = new Padding(2);
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
				base.UpdateStyles();
			}

			// Token: 0x060011F5 RID: 4597 RVA: 0x000885D8 File Offset: 0x000885D8
			public static DialogResult Show(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
			{
				DialogResult dialogResult;
				using (FM_diag.CustomMessageBox__0 customMessageBox__ = new FM_diag.CustomMessageBox__0())
				{
					customMessageBox__.SetupDialog(message, title, buttons, icon);
					customMessageBox__.ShowDialog();
					dialogResult = FM_diag.CustomMessageBox__0._dialogResult;
				}
				return dialogResult;
			}

			// Token: 0x060011F6 RID: 4598 RVA: 0x0000BB31 File Offset: 0x0000BB31
			public static DialogResult Show(string message, string title, MsgBoxStyle__0 buttons, MsgBoxStyle__0 icon)
			{
				return FM_diag.CustomMessageBox__0.Show(message, title, FM_diag.CustomMessageBox__0.ToButtons(buttons), FM_diag.CustomMessageBox__0.ToIcon(icon));
			}

			// Token: 0x060011F7 RID: 4599 RVA: 0x0000BB46 File Offset: 0x0000BB46
			private static MessageBoxButtons ToButtons(MsgBoxStyle__0 style)
			{
				if (style == MsgBoxStyle__0.OkCancel)
				{
					return MessageBoxButtons.OKCancel;
				}
				if (style != MsgBoxStyle__0.YesNo)
				{
					return MessageBoxButtons.OK;
				}
				return MessageBoxButtons.YesNo;
			}

			// Token: 0x060011F8 RID: 4600 RVA: 0x0000BB57 File Offset: 0x0000BB57
			private static MessageBoxIcon ToIcon(MsgBoxStyle__0 style)
			{
				if (style == MsgBoxStyle__0.Information)
				{
					return MessageBoxIcon.Asterisk;
				}
				return MessageBoxIcon.None;
			}

			// Token: 0x060011F9 RID: 4601 RVA: 0x00088620 File Offset: 0x00088620
			private void SetupDialog(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
			{
				base.Controls.Clear();
				this.contentPanel = new RoundedPanel();
				this.contentPanel.Dock = DockStyle.Fill;
				this.contentPanel.CornerRadius = this._cornerRadius;
				this.contentPanel.BorderColor = FM_diag.CustomMessageBox__0.Cyan;
				this.contentPanel.BorderWidth = 1f;
				this.contentPanel.InnerBackColor = FM_diag.CustomMessageBox__0.BgPanel;
				this.contentPanel.Padding = new Padding(20);
				base.Controls.Add(this.contentPanel);
				PictureBox pictureBox = new PictureBox
				{
					Location = new Point(18, 22),
					Size = new Size(28, 28),
					SizeMode = PictureBoxSizeMode.StretchImage,
					BackColor = Color.Transparent
				};
				if (icon <= MessageBoxIcon.Question)
				{
					if (icon == MessageBoxIcon.Hand)
					{
						pictureBox.Image = SystemIcons.Error.ToBitmap();
						goto IL_134;
					}
					if (icon == MessageBoxIcon.Question)
					{
						pictureBox.Image = SystemIcons.Question.ToBitmap();
						goto IL_134;
					}
				}
				else
				{
					if (icon == MessageBoxIcon.Exclamation)
					{
						pictureBox.Image = SystemIcons.Warning.ToBitmap();
						goto IL_134;
					}
					if (icon == MessageBoxIcon.Asterisk)
					{
						pictureBox.Image = SystemIcons.Information.ToBitmap();
						goto IL_134;
					}
				}
				pictureBox.Image = SystemIcons.Application.ToBitmap();
				IL_134:
				this.contentPanel.Controls.Add(pictureBox);
				this.titleLabel = new Label
				{
					Text = title,
					Font = new Font("Segoe UI", 12f, FontStyle.Bold),
					ForeColor = FM_diag.CustomMessageBox__0.TextTitle,
					BackColor = Color.Transparent,
					Location = new Point(56, 18),
					AutoSize = true
				};
				this.contentPanel.Controls.Add(this.titleLabel);
				checked
				{
					Panel value = new Panel
					{
						BackColor = FM_diag.CustomMessageBox__0.CyanDark,
						Location = new Point(18, 50),
						Size = new Size(base.Width - 36, 1),
						Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
					};
					this.contentPanel.Controls.Add(value);
					Label value2 = new Label
					{
						Text = message,
						Font = new Font("Segoe UI", 9.5f),
						ForeColor = FM_diag.CustomMessageBox__0.TextFore,
						BackColor = Color.Transparent,
						Location = new Point(20, 64),
						Width = base.Width - 80,
						Height = 120,
						AutoSize = false,
						Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
					};
					this.contentPanel.Controls.Add(value2);
					int num = 90;
					int num2 = 34;
					int num3 = 10;
					int width = this.contentPanel.ClientSize.Width;
					int height = this.contentPanel.ClientSize.Height;
					int left = this.contentPanel.Padding.Left;
					int right = this.contentPanel.Padding.Right;
					int bottom = this.contentPanel.Padding.Bottom;
					int num4 = width - left - right;
					int num5 = 0;
					if (buttons == MessageBoxButtons.OK)
					{
						num5 = 1;
					}
					else if (buttons == MessageBoxButtons.OKCancel || buttons == MessageBoxButtons.YesNo)
					{
						num5 = 2;
					}
					else if (buttons == MessageBoxButtons.YesNoCancel)
					{
						num5 = 3;
					}
					int num6 = num5 * num + (num5 - 1) * num3;
					int num7 = left + (num4 - num6) / 2;
					int top = height - num2 - bottom;
					if (buttons == MessageBoxButtons.OK)
					{
						this.CreateButton("OK", num7, top, num, num2, DialogResult.OK);
						return;
					}
					if (buttons == MessageBoxButtons.OKCancel)
					{
						this.CreateButton("OK", num7, top, num, num2, DialogResult.OK);
						this.CreateButton("Cancel", num7 + num + num3, top, num, num2, DialogResult.Cancel);
						return;
					}
					if (buttons == MessageBoxButtons.YesNo)
					{
						this.CreateButton("Yes", num7, top, num, num2, DialogResult.Yes);
						this.CreateButton("No", num7 + num + num3, top, num, num2, DialogResult.No);
						return;
					}
					if (buttons == MessageBoxButtons.YesNoCancel)
					{
						this.CreateButton("Yes", num7, top, num, num2, DialogResult.Yes);
						this.CreateButton("No", num7 + num + num3, top, num, num2, DialogResult.No);
						this.CreateButton("Cancel", num7 + (num + num3) * 2, top, num, num2, DialogResult.Cancel);
					}
				}
			}

			// Token: 0x060011FA RID: 4602 RVA: 0x00088A2C File Offset: 0x00088A2C
			private void CreateButton(string text, int left, int top, int width, int height, DialogResult result)
			{
				RoundedButton roundedButton = new RoundedButton
				{
					Text = text,
					Location = new Point(left, top),
					Size = new Size(width, height),
					Font = new Font("Segoe UI", 9f, FontStyle.Bold),
					ForeColor = FM_diag.CustomMessageBox__0.Cyan,
					BackColor = FM_diag.CustomMessageBox__0.BgButton,
					CornerRadius = 8,
					BorderColor = FM_diag.CustomMessageBox__0.Cyan,
					BorderWidth = 1f,
					HoverBackColor = FM_diag.CustomMessageBox__0.BgButtonHover,
					Cursor = Cursors.Hand
				};
				roundedButton.Click += delegate(object sender, EventArgs e)
				{
					FM_diag.CustomMessageBox__0._dialogResult = result;
					this.Close();
				};
				this.contentPanel.Controls.Add(roundedButton);
			}

			// Token: 0x060011FB RID: 4603 RVA: 0x00088AFC File Offset: 0x00088AFC
			protected override void OnPaint(PaintEventArgs e)
			{
				base.OnPaint(e);
				Graphics graphics = e.Graphics;
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				graphics.PixelOffsetMode = PixelOffsetMode.Half;
				graphics.Clear(this.BackColor);
				using (GraphicsPath graphicsPath = RoundedHelper.RoundedRectF(new RectangleF(1.5f, 1.5f, (float)base.Width - 3f, (float)base.Height - 3f), this._cornerRadius))
				{
					using (Pen pen = new Pen(FM_diag.CustomMessageBox__0.Cyan, 2f))
					{
						pen.Alignment = PenAlignment.Center;
						pen.LineJoin = LineJoin.Round;
						graphics.DrawPath(pen, graphicsPath);
					}
				}
			}

			// Token: 0x060011FC RID: 4604 RVA: 0x0000BB62 File Offset: 0x0000BB62
			protected override void OnLoad(EventArgs e)
			{
				base.OnLoad(e);
				this.UpdateFormRegion();
			}

			// Token: 0x060011FD RID: 4605 RVA: 0x0000BB71 File Offset: 0x0000BB71
			protected override void OnMouseDown(MouseEventArgs e)
			{
				base.OnMouseDown(e);
				if (e.Button == MouseButtons.Left)
				{
					FM_diag.CustomMessageBox__0.ReleaseCapture();
					FM_diag.CustomMessageBox__0.SendMessage(base.Handle, 161, 2, 0);
				}
			}

			// Token: 0x060011FE RID: 4606
			[DllImport("user32.dll")]
			public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

			// Token: 0x060011FF RID: 4607
			[DllImport("user32.dll")]
			public static extern bool ReleaseCapture();

			// Token: 0x06001200 RID: 4608 RVA: 0x0000BBA0 File Offset: 0x0000BBA0
			protected override void OnResize(EventArgs e)
			{
				base.OnResize(e);
				this.UpdateFormRegion();
				base.Invalidate();
			}

			// Token: 0x06001201 RID: 4609 RVA: 0x0000BBB5 File Offset: 0x0000BBB5
			private void UpdateFormRegion()
			{
				if (base.Width <= 0 || base.Height <= 0)
				{
					return;
				}
				RoundedHelper.SetRegion(this, this._cornerRadius);
			}

			// Token: 0x040018C5 RID: 6341
			private static DialogResult _dialogResult;

			// Token: 0x040018C6 RID: 6342
			private const int WM_NCLBUTTONDOWN = 161;

			// Token: 0x040018C7 RID: 6343
			private const int HT_CAPTION = 2;

			// Token: 0x040018C8 RID: 6344
			private Label titleLabel;

			// Token: 0x040018C9 RID: 6345
			private static readonly Color Cyan = Color.FromArgb(0, 255, 230);

			// Token: 0x040018CA RID: 6346
			private static readonly Color CyanDark = Color.FromArgb(0, 145, 135);

			// Token: 0x040018CB RID: 6347
			private static readonly Color BgDark = Color.FromArgb(18, 23, 29);

			// Token: 0x040018CC RID: 6348
			private static readonly Color BgPanel = Color.FromArgb(22, 28, 35);

			// Token: 0x040018CD RID: 6349
			private static readonly Color BgButton = Color.FromArgb(32, 40, 47);

			// Token: 0x040018CE RID: 6350
			private static readonly Color BgButtonHover = Color.FromArgb(45, 60, 70);

			// Token: 0x040018CF RID: 6351
			private static readonly Color TextFore = Color.FromArgb(235, 240, 245);

			// Token: 0x040018D0 RID: 6352
			private static readonly Color TextTitle = Color.FromArgb(255, 215, 0);

			// Token: 0x040018D1 RID: 6353
			private RoundedPanel contentPanel;

			// Token: 0x040018D2 RID: 6354
			private int _cornerRadius = 14;
		}
	}
}
