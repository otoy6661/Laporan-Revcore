﻿namespace Honda_Flash_Tools.2
{
	// Token: 0x020002B4 RID: 692
	public partial class FormMain : global::System.Windows.Forms.Form
	{
		// Token: 0x06000A1E RID: 2590 RVA: 0x0004B53C File Offset: 0x0004B53C
		private void InitializeComponent()
		{
			this.Text = "Honda Flash Tools";
			base.Width = 800;
			base.Height = 450;
			this.btnReset = new global::System.Windows.Forms.Button();
			this.btnReset.Text = "Reset Count Shindengen";
			this.btnReset.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.btnReset.Height = 40;
			this.btnReset.Click += new global::System.EventHandler(this.resetCountShindengenToolStripMenuItem_Click);
			base.Controls.Add(this.btnReset);
		}

		// Token: 0x04000B54 RID: 2900
		private global::System.Windows.Forms.Button btnReset;
	}
}
