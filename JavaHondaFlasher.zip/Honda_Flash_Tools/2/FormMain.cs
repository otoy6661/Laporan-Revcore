﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Ports;
using System.Threading;
using System.Windows.Forms;

namespace Honda_Flash_Tools.2
{
	// Token: 0x020002B4 RID: 692
	public partial class FormMain : Form
	{
		// Token: 0x06000A1D RID: 2589 RVA: 0x00007C95 File Offset: 0x00007C95
		public FormMain()
		{
			this.InitializeComponent();
			this.InitSerialPort("COM3", 10400, Parity.None, 8, StopBits.One);
		}

		// Token: 0x06000A1F RID: 2591 RVA: 0x0004B5C8 File Offset: 0x0004B5C8
		private void InitSerialPort(string portName, int baudRate = 10400, Parity parity = Parity.None, int dataBits = 8, StopBits stopBits = StopBits.One)
		{
			try
			{
				this._port = new SerialPort(portName, baudRate, parity, dataBits, stopBits)
				{
					Handshake = Handshake.None,
					ReadTimeout = 200,
					WriteTimeout = 500,
					DtrEnable = true,
					RtsEnable = false,
					NewLine = "\r"
				};
				if (!this._port.IsOpen)
				{
					this._port.Open();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Gagal membuka " + portName + ": " + ex.Message, "Port Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x06000A20 RID: 2592 RVA: 0x0004B670 File Offset: 0x0004B670
		public void SetPort(string portName, int baudRate = 10400)
		{
			try
			{
				if (this._port != null)
				{
					if (this._port.IsOpen)
					{
						this._port.Close();
					}
					this._port.Dispose();
				}
			}
			catch
			{
			}
			this.InitSerialPort(portName, baudRate, Parity.None, 8, StopBits.One);
		}

		// Token: 0x06000A21 RID: 2593 RVA: 0x0004B6C8 File Offset: 0x0004B6C8
		private void EnsurePort()
		{
			if (this._port == null)
			{
				this.InitSerialPort("COM3", 10400, Parity.None, 8, StopBits.One);
			}
			if (!this._port.IsOpen)
			{
				try
				{
					this._port.Open();
				}
				catch (Exception ex)
				{
					MessageBox.Show("Tidak bisa membuka " + this._port.PortName + ": " + ex.Message, "Port Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		// Token: 0x06000A22 RID: 2594 RVA: 0x0004B74C File Offset: 0x0004B74C
		private bool SendCommand(byte[] command, int commandLength, ref byte[] responseBuffer, ref uint responseLength, int totalTimeoutMs)
		{
			if (command == null)
			{
				throw new ArgumentNullException("command");
			}
			if (commandLength <= 0 || commandLength > command.Length)
			{
				commandLength = command.Length;
			}
			if (responseBuffer == null || responseBuffer.Length < 256)
			{
				responseBuffer = new byte[256];
			}
			this.EnsurePort();
			object ioLock = this._ioLock;
			bool result;
			lock (ioLock)
			{
				try
				{
					this._port.DiscardInBuffer();
					this._port.DiscardOutBuffer();
					this._port.Write(command, 0, commandLength);
					Thread.Sleep(10);
					using (MemoryStream memoryStream = new MemoryStream())
					{
						Stopwatch stopwatch = Stopwatch.StartNew();
						long elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
						int num = (totalTimeoutMs > 0) ? totalTimeoutMs : 1500;
						for (;;)
						{
							int num2;
							try
							{
								num2 = this._port.ReadByte();
							}
							catch (TimeoutException)
							{
								num2 = -1;
							}
							if (num2 >= 0)
							{
								memoryStream.WriteByte((byte)num2);
								elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
							}
							else if ((stopwatch.ElapsedMilliseconds - elapsedMilliseconds >= 50L && memoryStream.Length > 0L) || stopwatch.ElapsedMilliseconds >= (long)num)
							{
								break;
							}
						}
						byte[] array = memoryStream.ToArray();
						if (responseBuffer.Length < array.Length)
						{
							responseBuffer = new byte[Math.Max(256, array.Length)];
						}
						Array.Copy(array, responseBuffer, array.Length);
						responseLength = (uint)array.Length;
					}
					result = true;
				}
				catch (Exception ex)
				{
					responseLength = 0U;
					MessageBox.Show("Gagal mengirim/terima data: " + ex.Message, "Komunikasi ECU", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06000A23 RID: 2595 RVA: 0x0004B930 File Offset: 0x0004B930
		private void resetCountShindengenToolStripMenuItem_Click(object sender, EventArgs e)
		{
			MessageBox.Show("MATIKAN KONTAK OFF/ON\r\n lalu klik OK", "Honda Java Tech & Read Id Smartkey", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			byte[] array = new byte[]
			{
				145,
				145,
				13,
				223,
				158,
				141,
				154,
				134,
				144,
				138,
				140,
				155,
				136
			};
			byte[] array2 = new byte[]
			{
				145,
				145,
				13,
				223,
				146,
				158,
				134,
				150,
				139,
				141,
				134,
				192,
				106
			};
			byte[] array3 = new byte[]
			{
				145,
				145,
				9,
				65,
				14,
				0,
				0,
				0,
				168
			};
			byte[] array4 = new byte[256];
			uint num = 0U;
			bool flag = this.SendCommand(array, array.Length, ref array4, ref num, 1000);
			Thread.Sleep(30);
			bool flag2 = this.SendCommand(array2, array2.Length, ref array4, ref num, 1000);
			Thread.Sleep(30);
			bool flag3 = this.SendCommand(array3, array3.Length, ref array4, ref num, 1200);
			if (flag && flag2 && flag3)
			{
				MessageBox.Show("MATIKAN KUNCI KONTAK OFF/ON\r\nlalu klik OK\r\n\r\nRESET FLASH COUNT COMPLETED\r\nAND SUCCESSFUL!!!", "Honda Java Tech & Read Id Smartkey", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
			MessageBox.Show("RESET FLASH COUNT MUNGKIN GAGAL.\r\nPeriksa koneksi/COM port/baudrate.", "Honda Java Tech & Read Id Smartkey", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}

		// Token: 0x06000A24 RID: 2596 RVA: 0x0004BA14 File Offset: 0x0004BA14
		protected override void OnFormClosed(FormClosedEventArgs e)
		{
			try
			{
				if (this._port != null)
				{
					if (this._port.IsOpen)
					{
						this._port.Close();
					}
					this._port.Dispose();
				}
			}
			catch
			{
			}
			base.OnFormClosed(e);
		}

		// Token: 0x06000A25 RID: 2597 RVA: 0x00007CC1 File Offset: 0x00007CC1
		[STAThread]
		public static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new FormMain());
		}

		// Token: 0x04000B52 RID: 2898
		private SerialPort _port;

		// Token: 0x04000B53 RID: 2899
		private readonly object _ioLock = new object();
	}
}
