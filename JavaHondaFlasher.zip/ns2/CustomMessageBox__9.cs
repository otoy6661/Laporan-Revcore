﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ns2
{
	// Token: 0x020003E7 RID: 999
	public partial class CustomMessageBox__9 : Form
	{
		// Token: 0x06000CD4 RID: 3284 RVA: 0x0005F3F8 File Offset: 0x0005F3F8
		public CustomMessageBox__9()
		{
			base.FormBorderStyle = FormBorderStyle.FixedSingle;
			base.StartPosition = FormStartPosition.CenterScreen;
			this.BackColor = Color.FromArgb(45, 45, 65);
			base.MaximizeBox = false;
			base.Width = 420;
			base.Height = 220;
			base.TopMost = true;
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer, true);
		}

		// Token: 0x06000CD5 RID: 3285 RVA: 0x0005F45C File Offset: 0x0005F45C
		public static DialogResult Show(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
		{
			DialogResult dialogResult;
			using (CustomMessageBox__9 customMessageBox__ = new CustomMessageBox__9())
			{
				customMessageBox__.SetupDialog(message, title, buttons, icon);
				customMessageBox__.ShowDialog();
				dialogResult = CustomMessageBox__9._dialogResult;
			}
			return dialogResult;
		}

		// Token: 0x06000CD6 RID: 3286 RVA: 0x0005F4A4 File Offset: 0x0005F4A4
		private void SetupDialog(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
		{
			base.Controls.Clear();
			this.titleLabel = new Label
			{
				Text = title,
				Font = new Font("Segoe UI", 12f, FontStyle.Bold),
				ForeColor = Color.Gold,
				Location = new Point(20, 12),
				AutoSize = true
			};
			base.Controls.Add(this.titleLabel);
			Label label = new Label
			{
				Text = message,
				Font = new Font("Segoe UI", 9f),
				ForeColor = Color.FromArgb(220, 220, 200),
				Location = new Point(60, 45),
				Width = 340,
				AutoSize = true
			};
			base.Controls.Add(label);
			PictureBox pictureBox = new PictureBox
			{
				Location = new Point(20, 45),
				Size = new Size(32, 32),
				SizeMode = PictureBoxSizeMode.StretchImage
			};
			if (icon == MessageBoxIcon.Asterisk || icon == MessageBoxIcon.Asterisk)
			{
				pictureBox.Image = SystemIcons.Information.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Exclamation)
			{
				pictureBox.Image = SystemIcons.Warning.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Hand || icon == MessageBoxIcon.Hand)
			{
				pictureBox.Image = SystemIcons.Error.ToBitmap();
			}
			else if (icon == MessageBoxIcon.Question)
			{
				pictureBox.Image = SystemIcons.Question.ToBitmap();
			}
			base.Controls.Add(pictureBox);
			int num = Math.Max(label.Bottom, pictureBox.Bottom) + 20;
			int num2 = 90;
			int num3 = 32;
			int num4 = 10;
			int num5 = 0;
			if (buttons == MessageBoxButtons.OK)
			{
				num5 = num2;
			}
			else if (buttons == MessageBoxButtons.OKCancel || buttons == MessageBoxButtons.YesNo)
			{
				num5 = num2 * 2 + num4;
			}
			else if (buttons == MessageBoxButtons.YesNoCancel)
			{
				num5 = num2 * 3 + num4 * 2;
			}
			int num6 = (base.Width - num5) / 2;
			if (buttons == MessageBoxButtons.OK)
			{
				this.CreateButton("OK", num6, num, num2, num3, DialogResult.OK);
				return;
			}
			if (buttons == MessageBoxButtons.OKCancel)
			{
				this.CreateButton("OK", num6, num, num2, num3, DialogResult.OK);
				this.CreateButton("Cancel", num6 + num2 + num4, num, num2, num3, DialogResult.Cancel);
				return;
			}
			if (buttons == MessageBoxButtons.YesNo)
			{
				this.CreateButton("Yes", num6, num, num2, num3, DialogResult.Yes);
				this.CreateButton("No", num6 + num2 + num4, num, num2, num3, DialogResult.No);
				return;
			}
			if (buttons == MessageBoxButtons.YesNoCancel)
			{
				this.CreateButton("Yes", num6, num, num2, num3, DialogResult.Yes);
				this.CreateButton("No", num6 + num2 + num4, num, num2, num3, DialogResult.No);
				this.CreateButton("Cancel", num6 + (num2 + num4) * 2, num, num2, num3, DialogResult.Cancel);
			}
			base.Height = num + num3 + 30;
		}

		// Token: 0x06000CD7 RID: 3287 RVA: 0x0005F740 File Offset: 0x0005F740
		private void CreateButton(string text, int left, int top, int width, int height, DialogResult result)
		{
			Color originalBackColor = Color.FromArgb(45, 45, 65);
			Color hoverBackColor = Color.FromArgb(70, 70, 90);
			Color downBackColor = Color.FromArgb(100, 100, 120);
			Button button = new Button
			{
				Text = text,
				Location = new Point(left, top),
				Size = new Size(width, height),
				Font = new Font("Segoe UI", 9f),
				ForeColor = Color.Gold,
				BackColor = originalBackColor,
				Cursor = Cursors.Hand,
				FlatStyle = FlatStyle.Flat,
				UseVisualStyleBackColor = false,
				TextAlign = ContentAlignment.MiddleCenter
			};
			button.FlatAppearance.BorderSize = 1;
			button.FlatAppearance.BorderColor = Color.Gold;
			button.MouseEnter += delegate(object sender, EventArgs e)
			{
				button.BackColor = hoverBackColor;
			};
			button.MouseLeave += delegate(object sender, EventArgs e)
			{
				button.BackColor = originalBackColor;
			};
			button.MouseDown += delegate(object sender, MouseEventArgs e)
			{
				button.BackColor = downBackColor;
			};
			button.MouseUp += delegate(object sender, MouseEventArgs e)
			{
				button.BackColor = hoverBackColor;
			};
			button.Click += delegate(object sender, EventArgs e)
			{
				CustomMessageBox__9._dialogResult = result;
				this.Close();
			};
			base.Controls.Add(button);
		}

		// Token: 0x06000CD8 RID: 3288 RVA: 0x0005F8BC File Offset: 0x0005F8BC
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Graphics graphics = e.Graphics;
			Rectangle rect = new Rectangle(0, 0, base.Width - 1, base.Height - 1);
			using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(rect, Color.FromArgb(212, 175, 55), Color.FromArgb(184, 134, 11), LinearGradientMode.Vertical))
			{
				graphics.DrawRectangle(new Pen(linearGradientBrush, 2f), rect);
			}
			if (this.titleLabel != null)
			{
				using (Pen pen = new Pen(Color.FromArgb(212, 175, 55), 1f))
				{
					graphics.DrawLine(pen, 20, this.titleLabel.Bottom + 4, base.Width - 20, this.titleLabel.Bottom + 4);
				}
			}
		}

		// Token: 0x06000CD9 RID: 3289
		[DllImport("Gdi32.dll")]
		private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

		// Token: 0x06000CDA RID: 3290
		[DllImport("dwmapi.dll")]
		private static extern int DwmExtendFrameIntoClientArea(IntPtr hWnd, ref CustomMessageBox__9.MARGINS pMarInset);

		// Token: 0x06000CDB RID: 3291
		[DllImport("dwmapi.dll")]
		private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

		// Token: 0x06000CDC RID: 3292 RVA: 0x0005F9B0 File Offset: 0x0005F9B0
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			if (Environment.OSVersion.Version.Major >= 6)
			{
				int num = 2;
				CustomMessageBox__9.DwmSetWindowAttribute(base.Handle, 2, ref num, 4);
				CustomMessageBox__9.MARGINS margins = new CustomMessageBox__9.MARGINS
				{
					Left = 1,
					Right = 1,
					Top = 1,
					Bottom = 1
				};
				CustomMessageBox__9.DwmExtendFrameIntoClientArea(base.Handle, ref margins);
			}
			base.Region = Region.FromHrgn(CustomMessageBox__9.CreateRoundRectRgn(0, 0, base.Width, base.Height, 10, 10));
		}

		// Token: 0x06000CDD RID: 3293 RVA: 0x00009139 File Offset: 0x00009139
		protected override void OnMouseDown(MouseEventArgs e)
		{
			base.OnMouseDown(e);
			if (e.Button == MouseButtons.Left)
			{
				CustomMessageBox__9.ReleaseCapture();
				CustomMessageBox__9.SendMessage(base.Handle, 161, 2, 0);
			}
		}

		// Token: 0x06000CDE RID: 3294
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x06000CDF RID: 3295
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		// Token: 0x04000EED RID: 3821
		private static DialogResult _dialogResult;

		// Token: 0x04000EEE RID: 3822
		private const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x04000EEF RID: 3823
		private const int HT_CAPTION = 2;

		// Token: 0x04000EF0 RID: 3824
		private Label titleLabel;

		// Token: 0x020003E8 RID: 1000
		private struct MARGINS
		{
			// Token: 0x04000EF1 RID: 3825
			public int Left;

			// Token: 0x04000EF2 RID: 3826
			public int Right;

			// Token: 0x04000EF3 RID: 3827
			public int Top;

			// Token: 0x04000EF4 RID: 3828
			public int Bottom;
		}
	}
}
