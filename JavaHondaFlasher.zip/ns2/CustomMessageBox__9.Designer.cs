﻿namespace ns2
{
	// Token: 0x020003E7 RID: 999
	public partial class CustomMessageBox__9 : global::System.Windows.Forms.Form
	{
	}
}
